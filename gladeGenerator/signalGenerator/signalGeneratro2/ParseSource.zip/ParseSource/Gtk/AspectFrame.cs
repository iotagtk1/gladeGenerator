﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x02000130 RID: 304
	public class AspectFrame : Frame
	{
		// Token: 0x06000D62 RID: 3426 RVA: 0x000288F7 File Offset: 0x00026AF7
		public AspectFrame(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000D63 RID: 3427 RVA: 0x00028900 File Offset: 0x00026B00
		public AspectFrame(string label, float xalign, float yalign, float ratio, bool obey_child) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(AspectFrame))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				list2.Add("label");
				list.Add(new Value(label));
				list2.Add("xalign");
				list.Add(new Value(xalign));
				list2.Add("yalign");
				list.Add(new Value(yalign));
				list2.Add("ratio");
				list.Add(new Value(ratio));
				list2.Add("obey_child");
				list.Add(new Value(obey_child));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(label);
			this.Raw = AspectFrame.gtk_aspect_frame_new(intPtr, xalign, yalign, ratio, obey_child);
			Marshaller.Free(intPtr);
		}

		// Token: 0x170002E2 RID: 738
		// (get) Token: 0x06000D64 RID: 3428 RVA: 0x000289EC File Offset: 0x00026BEC
		// (set) Token: 0x06000D65 RID: 3429 RVA: 0x00028A14 File Offset: 0x00026C14
		[Property("xalign")]
		public float Xalign
		{
			get
			{
				Value property = base.GetProperty("xalign");
				float result = (float)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("xalign", val);
				val.Dispose();
			}
		}

		// Token: 0x170002E3 RID: 739
		// (get) Token: 0x06000D66 RID: 3430 RVA: 0x00028A3C File Offset: 0x00026C3C
		// (set) Token: 0x06000D67 RID: 3431 RVA: 0x00028A64 File Offset: 0x00026C64
		[Property("yalign")]
		public float Yalign
		{
			get
			{
				Value property = base.GetProperty("yalign");
				float result = (float)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("yalign", val);
				val.Dispose();
			}
		}

		// Token: 0x170002E4 RID: 740
		// (get) Token: 0x06000D68 RID: 3432 RVA: 0x00028A8C File Offset: 0x00026C8C
		// (set) Token: 0x06000D69 RID: 3433 RVA: 0x00028AB4 File Offset: 0x00026CB4
		[Property("ratio")]
		public float Ratio
		{
			get
			{
				Value property = base.GetProperty("ratio");
				float result = (float)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("ratio", val);
				val.Dispose();
			}
		}

		// Token: 0x170002E5 RID: 741
		// (get) Token: 0x06000D6A RID: 3434 RVA: 0x00028ADC File Offset: 0x00026CDC
		// (set) Token: 0x06000D6B RID: 3435 RVA: 0x00028B04 File Offset: 0x00026D04
		[Property("obey-child")]
		public bool ObeyChild
		{
			get
			{
				Value property = base.GetProperty("obey-child");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("obey-child", val);
				val.Dispose();
			}
		}

		// Token: 0x170002E6 RID: 742
		// (get) Token: 0x06000D6C RID: 3436 RVA: 0x00028B2C File Offset: 0x00026D2C
		public new static AbiStruct class_abi
		{
			get
			{
				if (AspectFrame._class_abi == null)
				{
					AspectFrame._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("_gtk_reserved1", Frame.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return AspectFrame._class_abi;
			}
		}

		// Token: 0x170002E7 RID: 743
		// (get) Token: 0x06000D6D RID: 3437 RVA: 0x00028C48 File Offset: 0x00026E48
		public new static GType GType
		{
			get
			{
				IntPtr val = AspectFrame.gtk_aspect_frame_get_type();
				return new GType(val);
			}
		}

		// Token: 0x06000D6E RID: 3438 RVA: 0x00028C66 File Offset: 0x00026E66
		public void Set(float xalign, float yalign, float ratio, bool obey_child)
		{
			AspectFrame.gtk_aspect_frame_set(base.Handle, xalign, yalign, ratio, obey_child);
		}

		// Token: 0x170002E8 RID: 744
		// (get) Token: 0x06000D6F RID: 3439 RVA: 0x00028C80 File Offset: 0x00026E80
		public new static AbiStruct abi_info
		{
			get
			{
				if (AspectFrame._abi_info == null)
				{
					AspectFrame._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Frame.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return AspectFrame._abi_info;
			}
		}

		// Token: 0x04000685 RID: 1669
		private static AspectFrame.d_gtk_aspect_frame_new gtk_aspect_frame_new = FuncLoader.LoadFunction<AspectFrame.d_gtk_aspect_frame_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_aspect_frame_new"));

		// Token: 0x04000686 RID: 1670
		private static AbiStruct _class_abi = null;

		// Token: 0x04000687 RID: 1671
		private static AspectFrame.d_gtk_aspect_frame_get_type gtk_aspect_frame_get_type = FuncLoader.LoadFunction<AspectFrame.d_gtk_aspect_frame_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_aspect_frame_get_type"));

		// Token: 0x04000688 RID: 1672
		private static AspectFrame.d_gtk_aspect_frame_set gtk_aspect_frame_set = FuncLoader.LoadFunction<AspectFrame.d_gtk_aspect_frame_set>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_aspect_frame_set"));

		// Token: 0x04000689 RID: 1673
		private static AbiStruct _abi_info = null;

		// Token: 0x02000A74 RID: 2676
		// (Invoke) Token: 0x060050D7 RID: 20695
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_aspect_frame_new(IntPtr label, float xalign, float yalign, float ratio, bool obey_child);

		// Token: 0x02000A75 RID: 2677
		// (Invoke) Token: 0x060050DB RID: 20699
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_aspect_frame_get_type();

		// Token: 0x02000A76 RID: 2678
		// (Invoke) Token: 0x060050DF RID: 20703
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_aspect_frame_set(IntPtr raw, float xalign, float yalign, float ratio, bool obey_child);
	}
}
