﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000126 RID: 294
	[Flags]
	[GType(typeof(ApplicationInhibitFlagsGType))]
	public enum ApplicationInhibitFlags
	{
		// Token: 0x04000651 RID: 1617
		Logout = 1,
		// Token: 0x04000652 RID: 1618
		Switch = 2,
		// Token: 0x04000653 RID: 1619
		Suspend = 4,
		// Token: 0x04000654 RID: 1620
		Idle = 8
	}
}
