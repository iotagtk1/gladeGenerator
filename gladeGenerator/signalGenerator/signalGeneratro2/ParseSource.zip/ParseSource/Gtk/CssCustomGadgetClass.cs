﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001C2 RID: 450
	public class CssCustomGadgetClass : Opaque
	{
		// Token: 0x0600117F RID: 4479 RVA: 0x00033CF1 File Offset: 0x00031EF1
		public CssCustomGadgetClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000413 RID: 1043
		// (get) Token: 0x06001180 RID: 4480 RVA: 0x00033CFA File Offset: 0x00031EFA
		public static AbiStruct abi_info
		{
			get
			{
				if (CssCustomGadgetClass._abi_info == null)
				{
					CssCustomGadgetClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssCustomGadgetClass._abi_info;
			}
		}

		// Token: 0x04000822 RID: 2082
		private static AbiStruct _abi_info;
	}
}
