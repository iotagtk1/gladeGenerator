﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x0200016D RID: 365
	public class CellEditableEventBox : Opaque
	{
		// Token: 0x06000F66 RID: 3942 RVA: 0x0002E89B File Offset: 0x0002CA9B
		public CellEditableEventBox(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700035D RID: 861
		// (get) Token: 0x06000F67 RID: 3943 RVA: 0x0002E8A4 File Offset: 0x0002CAA4
		public static AbiStruct abi_info
		{
			get
			{
				if (CellEditableEventBox._abi_info == null)
				{
					CellEditableEventBox._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CellEditableEventBox._abi_info;
			}
		}

		// Token: 0x0400078C RID: 1932
		private static AbiStruct _abi_info;
	}
}
