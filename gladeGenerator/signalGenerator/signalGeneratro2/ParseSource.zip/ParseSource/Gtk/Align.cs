﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x0200011A RID: 282
	[GType(typeof(AlignGType))]
	public enum Align
	{
		// Token: 0x0400060A RID: 1546
		Fill,
		// Token: 0x0400060B RID: 1547
		Start,
		// Token: 0x0400060C RID: 1548
		End,
		// Token: 0x0400060D RID: 1549
		Center,
		// Token: 0x0400060E RID: 1550
		Baseline
	}
}
