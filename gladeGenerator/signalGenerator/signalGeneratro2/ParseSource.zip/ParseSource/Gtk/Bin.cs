﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x020000D6 RID: 214
	public class Bin : Container
	{
		// Token: 0x17000089 RID: 137
		// (get) Token: 0x060004CA RID: 1226 RVA: 0x0000CB28 File Offset: 0x0000AD28
		// (set) Token: 0x060004CB RID: 1227 RVA: 0x0000CB64 File Offset: 0x0000AD64
		public new Widget Child
		{
			get
			{
				IntPtr intPtr = Bin.gtk_bin_get_child(base.Handle);
				Widget result;
				if (intPtr == IntPtr.Zero)
				{
					result = null;
				}
				else
				{
					result = (Widget)Object.GetObject(intPtr);
				}
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("child", val);
				val.Dispose();
			}
		}

		// Token: 0x060004CC RID: 1228 RVA: 0x0000CB8C File Offset: 0x0000AD8C
		public Bin(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x060004CD RID: 1229 RVA: 0x0000CB95 File Offset: 0x0000AD95
		protected Bin() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x060004CE RID: 1230 RVA: 0x0000CBB4 File Offset: 0x0000ADB4
		public new static AbiStruct class_abi
		{
			get
			{
				if (Bin._class_abi == null)
				{
					Bin._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("_gtk_reserved1", Container.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Bin._class_abi;
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x060004CF RID: 1231 RVA: 0x0000CCD0 File Offset: 0x0000AED0
		public new static GType GType
		{
			get
			{
				IntPtr val = Bin.gtk_bin_get_type();
				return new GType(val);
			}
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x060004D0 RID: 1232 RVA: 0x0000CCF0 File Offset: 0x0000AEF0
		public new static AbiStruct abi_info
		{
			get
			{
				if (Bin._abi_info == null)
				{
					Bin._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Container.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Bin._abi_info;
			}
		}

		// Token: 0x04000286 RID: 646
		private static Bin.d_gtk_bin_get_child gtk_bin_get_child = FuncLoader.LoadFunction<Bin.d_gtk_bin_get_child>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_bin_get_child"));

		// Token: 0x04000287 RID: 647
		private static AbiStruct _class_abi = null;

		// Token: 0x04000288 RID: 648
		private static Bin.d_gtk_bin_get_type gtk_bin_get_type = FuncLoader.LoadFunction<Bin.d_gtk_bin_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_bin_get_type"));

		// Token: 0x04000289 RID: 649
		private static AbiStruct _abi_info = null;

		// Token: 0x020006C5 RID: 1733
		// (Invoke) Token: 0x0600422D RID: 16941
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_bin_get_child(IntPtr raw);

		// Token: 0x020006C6 RID: 1734
		// (Invoke) Token: 0x06004231 RID: 16945
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_bin_get_type();
	}
}
