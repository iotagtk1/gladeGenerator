﻿using System;
using Gdk;

namespace Gtk
{
	// Token: 0x020000D7 RID: 215
	[AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
	public sealed class BindingAttribute : Attribute
	{
		// Token: 0x060004D2 RID: 1234 RVA: 0x0000CDA3 File Offset: 0x0000AFA3
		public BindingAttribute(Key key, string handler, params object[] parms) : this(key, ModifierType.None, handler, parms)
		{
		}

		// Token: 0x060004D3 RID: 1235 RVA: 0x0000CDAF File Offset: 0x0000AFAF
		public BindingAttribute(Key key, ModifierType mod, string handler, params object[] parms)
		{
			this.key = key;
			this.mod = mod;
			this.handler = handler;
			this.parms = parms;
		}

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x060004D4 RID: 1236 RVA: 0x0000CDD4 File Offset: 0x0000AFD4
		public Key Key
		{
			get
			{
				return this.key;
			}
		}

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x060004D5 RID: 1237 RVA: 0x0000CDDC File Offset: 0x0000AFDC
		public ModifierType Mod
		{
			get
			{
				return this.mod;
			}
		}

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x060004D6 RID: 1238 RVA: 0x0000CDE4 File Offset: 0x0000AFE4
		public string Handler
		{
			get
			{
				return this.handler;
			}
		}

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x060004D7 RID: 1239 RVA: 0x0000CDEC File Offset: 0x0000AFEC
		public object[] Parms
		{
			get
			{
				return this.parms;
			}
		}

		// Token: 0x0400028A RID: 650
		private Key key;

		// Token: 0x0400028B RID: 651
		private ModifierType mod;

		// Token: 0x0400028C RID: 652
		private string handler;

		// Token: 0x0400028D RID: 653
		private object[] parms;
	}
}
