﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x02000150 RID: 336
	public class BuiltinIconClass : Opaque
	{
		// Token: 0x06000E33 RID: 3635 RVA: 0x0002AAE6 File Offset: 0x00028CE6
		public BuiltinIconClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700031B RID: 795
		// (get) Token: 0x06000E34 RID: 3636 RVA: 0x0002AAEF File Offset: 0x00028CEF
		public static AbiStruct abi_info
		{
			get
			{
				if (BuiltinIconClass._abi_info == null)
				{
					BuiltinIconClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return BuiltinIconClass._abi_info;
			}
		}

		// Token: 0x04000708 RID: 1800
		private static AbiStruct _abi_info;
	}
}
