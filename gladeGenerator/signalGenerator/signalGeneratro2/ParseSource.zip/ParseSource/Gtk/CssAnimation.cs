﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001BF RID: 447
	public class CssAnimation : Opaque
	{
		// Token: 0x06001179 RID: 4473 RVA: 0x00033C7F File Offset: 0x00031E7F
		public CssAnimation(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000410 RID: 1040
		// (get) Token: 0x0600117A RID: 4474 RVA: 0x00033C88 File Offset: 0x00031E88
		public static AbiStruct abi_info
		{
			get
			{
				if (CssAnimation._abi_info == null)
				{
					CssAnimation._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssAnimation._abi_info;
			}
		}

		// Token: 0x0400081F RID: 2079
		private static AbiStruct _abi_info;
	}
}
