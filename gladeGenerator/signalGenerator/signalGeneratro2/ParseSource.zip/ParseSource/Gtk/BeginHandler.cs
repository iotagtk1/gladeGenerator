﻿using System;

namespace Gtk
{
	// Token: 0x0200013A RID: 314
	// (Invoke) Token: 0x06000DCE RID: 3534
	public delegate void BeginHandler(object o, BeginArgs args);
}
