﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x0200021F RID: 543
	public class DeletedTextArgs : SignalArgs
	{
		// Token: 0x17000473 RID: 1139
		// (get) Token: 0x0600126B RID: 4715 RVA: 0x00035216 File Offset: 0x00033416
		public uint Position
		{
			get
			{
				return (uint)base.Args[0];
			}
		}

		// Token: 0x17000474 RID: 1140
		// (get) Token: 0x0600126C RID: 4716 RVA: 0x00035225 File Offset: 0x00033425
		public uint NChars
		{
			get
			{
				return (uint)base.Args[1];
			}
		}
	}
}
