﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001E9 RID: 489
	public class CssNode : Opaque
	{
		// Token: 0x060011CD RID: 4557 RVA: 0x000342BB File Offset: 0x000324BB
		public CssNode(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700043A RID: 1082
		// (get) Token: 0x060011CE RID: 4558 RVA: 0x000342C4 File Offset: 0x000324C4
		public static AbiStruct abi_info
		{
			get
			{
				if (CssNode._abi_info == null)
				{
					CssNode._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssNode._abi_info;
			}
		}

		// Token: 0x04000849 RID: 2121
		private static AbiStruct _abi_info;
	}
}
