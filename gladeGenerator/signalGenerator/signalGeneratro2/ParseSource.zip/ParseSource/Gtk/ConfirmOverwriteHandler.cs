﻿using System;

namespace Gtk
{
	// Token: 0x020001AE RID: 430
	// (Invoke) Token: 0x0600114E RID: 4430
	public delegate void ConfirmOverwriteHandler(object o, ConfirmOverwriteArgs args);
}
