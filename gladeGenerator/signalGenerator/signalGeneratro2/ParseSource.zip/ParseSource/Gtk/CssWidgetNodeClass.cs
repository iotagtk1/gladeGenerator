﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x0200020C RID: 524
	public class CssWidgetNodeClass : Opaque
	{
		// Token: 0x06001232 RID: 4658 RVA: 0x00035089 File Offset: 0x00033289
		public CssWidgetNodeClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000467 RID: 1127
		// (get) Token: 0x06001233 RID: 4659 RVA: 0x00035092 File Offset: 0x00033292
		public static AbiStruct abi_info
		{
			get
			{
				if (CssWidgetNodeClass._abi_info == null)
				{
					CssWidgetNodeClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssWidgetNodeClass._abi_info;
			}
		}

		// Token: 0x04000892 RID: 2194
		private static AbiStruct _abi_info;
	}
}
