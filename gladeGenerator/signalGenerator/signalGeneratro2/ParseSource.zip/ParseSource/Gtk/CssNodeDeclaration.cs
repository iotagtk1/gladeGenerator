﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001EB RID: 491
	public class CssNodeDeclaration : Opaque
	{
		// Token: 0x060011D1 RID: 4561 RVA: 0x00034307 File Offset: 0x00032507
		public CssNodeDeclaration(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700043C RID: 1084
		// (get) Token: 0x060011D2 RID: 4562 RVA: 0x00034310 File Offset: 0x00032510
		public static AbiStruct abi_info
		{
			get
			{
				if (CssNodeDeclaration._abi_info == null)
				{
					CssNodeDeclaration._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssNodeDeclaration._abi_info;
			}
		}

		// Token: 0x0400084B RID: 2123
		private static AbiStruct _abi_info;
	}
}
