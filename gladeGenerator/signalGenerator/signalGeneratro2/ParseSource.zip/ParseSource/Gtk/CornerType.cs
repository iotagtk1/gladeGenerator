﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x020001B2 RID: 434
	[GType(typeof(CornerTypeGType))]
	public enum CornerType
	{
		// Token: 0x04000817 RID: 2071
		TopLeft,
		// Token: 0x04000818 RID: 2072
		BottomLeft,
		// Token: 0x04000819 RID: 2073
		TopRight,
		// Token: 0x0400081A RID: 2074
		BottomRight
	}
}
