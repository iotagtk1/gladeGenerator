﻿using System;
using System.Runtime.InteropServices;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x0200013E RID: 318
	public class Bindings
	{
		// Token: 0x06000DD9 RID: 3545 RVA: 0x00029D9E File Offset: 0x00027F9E
		public static bool ActivateEvent(Object objekt, EventKey evnt)
		{
			return Bindings.gtk_bindings_activate_event((objekt == null) ? IntPtr.Zero : objekt.Handle, (evnt == null) ? IntPtr.Zero : evnt.Handle);
		}

		// Token: 0x040006C1 RID: 1729
		private static Bindings.d_gtk_bindings_activate_event gtk_bindings_activate_event = FuncLoader.LoadFunction<Bindings.d_gtk_bindings_activate_event>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_bindings_activate_event"));

		// Token: 0x02000A9D RID: 2717
		// (Invoke) Token: 0x06005184 RID: 20868
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_bindings_activate_event(IntPtr objekt, IntPtr evnt);
	}
}
