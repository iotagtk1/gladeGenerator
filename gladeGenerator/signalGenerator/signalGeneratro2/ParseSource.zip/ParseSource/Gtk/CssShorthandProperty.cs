﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001FC RID: 508
	public class CssShorthandProperty : Opaque
	{
		// Token: 0x06001212 RID: 4626 RVA: 0x00034E29 File Offset: 0x00033029
		public CssShorthandProperty(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000457 RID: 1111
		// (get) Token: 0x06001213 RID: 4627 RVA: 0x00034E32 File Offset: 0x00033032
		public static AbiStruct abi_info
		{
			get
			{
				if (CssShorthandProperty._abi_info == null)
				{
					CssShorthandProperty._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssShorthandProperty._abi_info;
			}
		}

		// Token: 0x04000882 RID: 2178
		private static AbiStruct _abi_info;
	}
}
