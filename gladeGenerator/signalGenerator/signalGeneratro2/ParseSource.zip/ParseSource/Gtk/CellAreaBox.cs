﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;
using GtkSharp;

namespace Gtk
{
	// Token: 0x020000DB RID: 219
	public class CellAreaBox : CellArea, ICellLayout, IWrapper, IOrientable
	{
		// Token: 0x060005C9 RID: 1481 RVA: 0x0000FEB0 File Offset: 0x0000E0B0
		public void SetAttributes(CellRenderer cell, params object[] attrs)
		{
			if (attrs.Length % 2 != 0)
			{
				throw new ArgumentException("attrs should contain pairs of attribute/col");
			}
			this.ClearAttributes(cell);
			for (int i = 0; i < attrs.Length - 1; i += 2)
			{
				this.AddAttribute(cell, (string)attrs[i], (int)attrs[i + 1]);
			}
		}

		// Token: 0x060005CA RID: 1482 RVA: 0x0000FEFF File Offset: 0x0000E0FF
		public CellAreaBox(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x060005CB RID: 1483 RVA: 0x0000FF08 File Offset: 0x0000E108
		public CellAreaBox() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(CellAreaBox))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = CellAreaBox.gtk_cell_area_box_new();
		}

		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x060005CC RID: 1484 RVA: 0x0000FF5A File Offset: 0x0000E15A
		// (set) Token: 0x060005CD RID: 1485 RVA: 0x0000FF6C File Offset: 0x0000E16C
		[Property("spacing")]
		public int Spacing
		{
			get
			{
				return CellAreaBox.gtk_cell_area_box_get_spacing(base.Handle);
			}
			set
			{
				CellAreaBox.gtk_cell_area_box_set_spacing(base.Handle, value);
			}
		}

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x060005CE RID: 1486 RVA: 0x0000FF80 File Offset: 0x0000E180
		// (set) Token: 0x060005CF RID: 1487 RVA: 0x0000FFA8 File Offset: 0x0000E1A8
		[Property("expand")]
		public bool Expand
		{
			get
			{
				Value property = base.GetProperty("expand");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("expand", val);
				val.Dispose();
			}
		}

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x060005D0 RID: 1488 RVA: 0x0000FFD0 File Offset: 0x0000E1D0
		// (set) Token: 0x060005D1 RID: 1489 RVA: 0x0000FFF8 File Offset: 0x0000E1F8
		[Property("align")]
		public bool Align
		{
			get
			{
				Value property = base.GetProperty("align");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("align", val);
				val.Dispose();
			}
		}

		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x060005D2 RID: 1490 RVA: 0x00010020 File Offset: 0x0000E220
		// (set) Token: 0x060005D3 RID: 1491 RVA: 0x00010048 File Offset: 0x0000E248
		[Property("fixed-size")]
		public bool FixedSize
		{
			get
			{
				Value property = base.GetProperty("fixed-size");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("fixed-size", val);
				val.Dispose();
			}
		}

		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x060005D4 RID: 1492 RVA: 0x00010070 File Offset: 0x0000E270
		// (set) Token: 0x060005D5 RID: 1493 RVA: 0x0001009C File Offset: 0x0000E29C
		[Property("pack-type")]
		public PackType PackType
		{
			get
			{
				Value property = base.GetProperty("pack-type");
				PackType result = (PackType)((Enum)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("pack-type", val);
				val.Dispose();
			}
		}

		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x060005D6 RID: 1494 RVA: 0x000100CC File Offset: 0x0000E2CC
		public new static AbiStruct class_abi
		{
			get
			{
				if (CellAreaBox._class_abi == null)
				{
					CellAreaBox._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("_gtk_reserved1", CellArea.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellAreaBox._class_abi;
			}
		}

		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x060005D7 RID: 1495 RVA: 0x000101E8 File Offset: 0x0000E3E8
		public new static GType GType
		{
			get
			{
				IntPtr val = CellAreaBox.gtk_cell_area_box_get_type();
				return new GType(val);
			}
		}

		// Token: 0x060005D8 RID: 1496 RVA: 0x00010206 File Offset: 0x0000E406
		public void PackEnd(CellRenderer renderer, bool expand, bool align, bool mfixed)
		{
			CellAreaBox.gtk_cell_area_box_pack_end(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle, expand, align, mfixed);
		}

		// Token: 0x060005D9 RID: 1497 RVA: 0x0001022C File Offset: 0x0000E42C
		public void PackStart(CellRenderer renderer, bool expand, bool align, bool mfixed)
		{
			CellAreaBox.gtk_cell_area_box_pack_start(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle, expand, align, mfixed);
		}

		// Token: 0x060005DA RID: 1498 RVA: 0x00010254 File Offset: 0x0000E454
		public void AddAttribute(CellRenderer cell, string attribute, int column)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(attribute);
			CellAreaBox.gtk_cell_layout_add_attribute(base.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, intPtr, column);
			Marshaller.Free(intPtr);
		}

		// Token: 0x060005DB RID: 1499 RVA: 0x00010290 File Offset: 0x0000E490
		public void Clear()
		{
			CellAreaBox.gtk_cell_layout_clear(base.Handle);
		}

		// Token: 0x060005DC RID: 1500 RVA: 0x000102A2 File Offset: 0x0000E4A2
		public void ClearAttributes(CellRenderer cell)
		{
			CellAreaBox.gtk_cell_layout_clear_attributes(base.Handle, (cell == null) ? IntPtr.Zero : cell.Handle);
		}

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x060005DD RID: 1501 RVA: 0x000102C4 File Offset: 0x0000E4C4
		public CellArea Area
		{
			get
			{
				return Object.GetObject(CellAreaBox.gtk_cell_layout_get_area(base.Handle)) as CellArea;
			}
		}

		// Token: 0x170000DA RID: 218
		// (get) Token: 0x060005DE RID: 1502 RVA: 0x000102E0 File Offset: 0x0000E4E0
		public CellRenderer[] Cells
		{
			get
			{
				return (CellRenderer[])Marshaller.ListPtrToArray(CellAreaBox.gtk_cell_layout_get_cells(base.Handle), typeof(List), true, false, typeof(CellRenderer));
			}
		}

		// Token: 0x060005DF RID: 1503 RVA: 0x00010312 File Offset: 0x0000E512
		public void PackEnd(CellRenderer cell, bool expand)
		{
			CellAreaBox.gtk_cell_layout_pack_end(base.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, expand);
		}

		// Token: 0x060005E0 RID: 1504 RVA: 0x00010335 File Offset: 0x0000E535
		public void PackStart(CellRenderer cell, bool expand)
		{
			CellAreaBox.gtk_cell_layout_pack_start(base.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, expand);
		}

		// Token: 0x060005E1 RID: 1505 RVA: 0x00010358 File Offset: 0x0000E558
		public void Reorder(CellRenderer cell, int position)
		{
			CellAreaBox.gtk_cell_layout_reorder(base.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, position);
		}

		// Token: 0x060005E2 RID: 1506 RVA: 0x0001037C File Offset: 0x0000E57C
		public void SetCellDataFunc(CellRenderer cell, CellLayoutDataFunc func)
		{
			CellLayoutDataFuncWrapper cellLayoutDataFuncWrapper = new CellLayoutDataFuncWrapper(func);
			IntPtr func_data;
			DestroyNotify destroy;
			if (func == null)
			{
				func_data = IntPtr.Zero;
				destroy = null;
			}
			else
			{
				func_data = (IntPtr)GCHandle.Alloc(cellLayoutDataFuncWrapper);
				destroy = DestroyHelper.NotifyHandler;
			}
			CellAreaBox.gtk_cell_layout_set_cell_data_func(base.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, cellLayoutDataFuncWrapper.NativeDelegate, func_data, destroy);
		}

		// Token: 0x170000DB RID: 219
		// (get) Token: 0x060005E3 RID: 1507 RVA: 0x000103D7 File Offset: 0x0000E5D7
		// (set) Token: 0x060005E4 RID: 1508 RVA: 0x000103E9 File Offset: 0x0000E5E9
		[Property("orientation")]
		public Orientation Orientation
		{
			get
			{
				return (Orientation)CellAreaBox.gtk_orientable_get_orientation(base.Handle);
			}
			set
			{
				CellAreaBox.gtk_orientable_set_orientation(base.Handle, (int)value);
			}
		}

		// Token: 0x170000DC RID: 220
		// (get) Token: 0x060005E5 RID: 1509 RVA: 0x000103FC File Offset: 0x0000E5FC
		public new static AbiStruct abi_info
		{
			get
			{
				if (CellAreaBox._abi_info == null)
				{
					CellAreaBox._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", CellArea.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellAreaBox._abi_info;
			}
		}

		// Token: 0x040002EB RID: 747
		private static CellAreaBox.d_gtk_cell_area_box_new gtk_cell_area_box_new = FuncLoader.LoadFunction<CellAreaBox.d_gtk_cell_area_box_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_box_new"));

		// Token: 0x040002EC RID: 748
		private static CellAreaBox.d_gtk_cell_area_box_get_spacing gtk_cell_area_box_get_spacing = FuncLoader.LoadFunction<CellAreaBox.d_gtk_cell_area_box_get_spacing>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_box_get_spacing"));

		// Token: 0x040002ED RID: 749
		private static CellAreaBox.d_gtk_cell_area_box_set_spacing gtk_cell_area_box_set_spacing = FuncLoader.LoadFunction<CellAreaBox.d_gtk_cell_area_box_set_spacing>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_box_set_spacing"));

		// Token: 0x040002EE RID: 750
		private static AbiStruct _class_abi = null;

		// Token: 0x040002EF RID: 751
		private static CellAreaBox.d_gtk_cell_area_box_get_type gtk_cell_area_box_get_type = FuncLoader.LoadFunction<CellAreaBox.d_gtk_cell_area_box_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_box_get_type"));

		// Token: 0x040002F0 RID: 752
		private static CellAreaBox.d_gtk_cell_area_box_pack_end gtk_cell_area_box_pack_end = FuncLoader.LoadFunction<CellAreaBox.d_gtk_cell_area_box_pack_end>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_box_pack_end"));

		// Token: 0x040002F1 RID: 753
		private static CellAreaBox.d_gtk_cell_area_box_pack_start gtk_cell_area_box_pack_start = FuncLoader.LoadFunction<CellAreaBox.d_gtk_cell_area_box_pack_start>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_box_pack_start"));

		// Token: 0x040002F2 RID: 754
		private static CellAreaBox.d_gtk_cell_layout_add_attribute gtk_cell_layout_add_attribute = FuncLoader.LoadFunction<CellAreaBox.d_gtk_cell_layout_add_attribute>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_add_attribute"));

		// Token: 0x040002F3 RID: 755
		private static CellAreaBox.d_gtk_cell_layout_clear gtk_cell_layout_clear = FuncLoader.LoadFunction<CellAreaBox.d_gtk_cell_layout_clear>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_clear"));

		// Token: 0x040002F4 RID: 756
		private static CellAreaBox.d_gtk_cell_layout_clear_attributes gtk_cell_layout_clear_attributes = FuncLoader.LoadFunction<CellAreaBox.d_gtk_cell_layout_clear_attributes>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_clear_attributes"));

		// Token: 0x040002F5 RID: 757
		private static CellAreaBox.d_gtk_cell_layout_get_area gtk_cell_layout_get_area = FuncLoader.LoadFunction<CellAreaBox.d_gtk_cell_layout_get_area>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_get_area"));

		// Token: 0x040002F6 RID: 758
		private static CellAreaBox.d_gtk_cell_layout_get_cells gtk_cell_layout_get_cells = FuncLoader.LoadFunction<CellAreaBox.d_gtk_cell_layout_get_cells>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_get_cells"));

		// Token: 0x040002F7 RID: 759
		private static CellAreaBox.d_gtk_cell_layout_pack_end gtk_cell_layout_pack_end = FuncLoader.LoadFunction<CellAreaBox.d_gtk_cell_layout_pack_end>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_pack_end"));

		// Token: 0x040002F8 RID: 760
		private static CellAreaBox.d_gtk_cell_layout_pack_start gtk_cell_layout_pack_start = FuncLoader.LoadFunction<CellAreaBox.d_gtk_cell_layout_pack_start>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_pack_start"));

		// Token: 0x040002F9 RID: 761
		private static CellAreaBox.d_gtk_cell_layout_reorder gtk_cell_layout_reorder = FuncLoader.LoadFunction<CellAreaBox.d_gtk_cell_layout_reorder>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_reorder"));

		// Token: 0x040002FA RID: 762
		private static CellAreaBox.d_gtk_cell_layout_set_cell_data_func gtk_cell_layout_set_cell_data_func = FuncLoader.LoadFunction<CellAreaBox.d_gtk_cell_layout_set_cell_data_func>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_set_cell_data_func"));

		// Token: 0x040002FB RID: 763
		private static CellAreaBox.d_gtk_orientable_get_orientation gtk_orientable_get_orientation = FuncLoader.LoadFunction<CellAreaBox.d_gtk_orientable_get_orientation>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_orientable_get_orientation"));

		// Token: 0x040002FC RID: 764
		private static CellAreaBox.d_gtk_orientable_set_orientation gtk_orientable_set_orientation = FuncLoader.LoadFunction<CellAreaBox.d_gtk_orientable_set_orientation>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_orientable_set_orientation"));

		// Token: 0x040002FD RID: 765
		private static AbiStruct _abi_info = null;

		// Token: 0x02000721 RID: 1825
		// (Invoke) Token: 0x060043A8 RID: 17320
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_area_box_new();

		// Token: 0x02000722 RID: 1826
		// (Invoke) Token: 0x060043AC RID: 17324
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_cell_area_box_get_spacing(IntPtr raw);

		// Token: 0x02000723 RID: 1827
		// (Invoke) Token: 0x060043B0 RID: 17328
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_box_set_spacing(IntPtr raw, int spacing);

		// Token: 0x02000724 RID: 1828
		// (Invoke) Token: 0x060043B4 RID: 17332
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_area_box_get_type();

		// Token: 0x02000725 RID: 1829
		// (Invoke) Token: 0x060043B8 RID: 17336
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_box_pack_end(IntPtr raw, IntPtr renderer, bool expand, bool align, bool mfixed);

		// Token: 0x02000726 RID: 1830
		// (Invoke) Token: 0x060043BC RID: 17340
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_box_pack_start(IntPtr raw, IntPtr renderer, bool expand, bool align, bool mfixed);

		// Token: 0x02000727 RID: 1831
		// (Invoke) Token: 0x060043C0 RID: 17344
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_add_attribute(IntPtr raw, IntPtr cell, IntPtr attribute, int column);

		// Token: 0x02000728 RID: 1832
		// (Invoke) Token: 0x060043C4 RID: 17348
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_clear(IntPtr raw);

		// Token: 0x02000729 RID: 1833
		// (Invoke) Token: 0x060043C8 RID: 17352
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_clear_attributes(IntPtr raw, IntPtr cell);

		// Token: 0x0200072A RID: 1834
		// (Invoke) Token: 0x060043CC RID: 17356
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_layout_get_area(IntPtr raw);

		// Token: 0x0200072B RID: 1835
		// (Invoke) Token: 0x060043D0 RID: 17360
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_layout_get_cells(IntPtr raw);

		// Token: 0x0200072C RID: 1836
		// (Invoke) Token: 0x060043D4 RID: 17364
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_pack_end(IntPtr raw, IntPtr cell, bool expand);

		// Token: 0x0200072D RID: 1837
		// (Invoke) Token: 0x060043D8 RID: 17368
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_pack_start(IntPtr raw, IntPtr cell, bool expand);

		// Token: 0x0200072E RID: 1838
		// (Invoke) Token: 0x060043DC RID: 17372
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_reorder(IntPtr raw, IntPtr cell, int position);

		// Token: 0x0200072F RID: 1839
		// (Invoke) Token: 0x060043E0 RID: 17376
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_set_cell_data_func(IntPtr raw, IntPtr cell, CellLayoutDataFuncNative func, IntPtr func_data, DestroyNotify destroy);

		// Token: 0x02000730 RID: 1840
		// (Invoke) Token: 0x060043E4 RID: 17380
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_orientable_get_orientation(IntPtr raw);

		// Token: 0x02000731 RID: 1841
		// (Invoke) Token: 0x060043E8 RID: 17384
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_orientable_set_orientation(IntPtr raw, int orientation);
	}
}
