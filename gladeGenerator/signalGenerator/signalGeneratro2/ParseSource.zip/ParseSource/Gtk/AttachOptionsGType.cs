﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x02000137 RID: 311
	internal class AttachOptionsGType
	{
		// Token: 0x170002FA RID: 762
		// (get) Token: 0x06000DC7 RID: 3527 RVA: 0x00029D04 File Offset: 0x00027F04
		public static GType GType
		{
			get
			{
				return new GType(AttachOptionsGType.gtk_attach_options_get_type());
			}
		}

		// Token: 0x040006BB RID: 1723
		private static AttachOptionsGType.d_gtk_attach_options_get_type gtk_attach_options_get_type = FuncLoader.LoadFunction<AttachOptionsGType.d_gtk_attach_options_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_attach_options_get_type"));

		// Token: 0x02000A9B RID: 2715
		// (Invoke) Token: 0x0600517C RID: 20860
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_attach_options_get_type();
	}
}
