﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000186 RID: 390
	public class ChildActivatedArgs : SignalArgs
	{
		// Token: 0x170003CB RID: 971
		// (get) Token: 0x06001077 RID: 4215 RVA: 0x00031CFB File Offset: 0x0002FEFB
		public FlowBoxChild Child
		{
			get
			{
				return (FlowBoxChild)base.Args[0];
			}
		}
	}
}
