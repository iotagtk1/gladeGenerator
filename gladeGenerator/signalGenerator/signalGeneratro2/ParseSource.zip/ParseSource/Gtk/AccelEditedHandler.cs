﻿using System;

namespace Gtk
{
	// Token: 0x020000F6 RID: 246
	// (Invoke) Token: 0x06000B17 RID: 2839
	public delegate void AccelEditedHandler(object o, AccelEditedArgs args);
}
