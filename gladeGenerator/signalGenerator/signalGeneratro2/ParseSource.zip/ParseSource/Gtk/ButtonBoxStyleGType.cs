﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x02000153 RID: 339
	internal class ButtonBoxStyleGType
	{
		// Token: 0x17000326 RID: 806
		// (get) Token: 0x06000E48 RID: 3656 RVA: 0x0002AFB9 File Offset: 0x000291B9
		public static GType GType
		{
			get
			{
				return new GType(ButtonBoxStyleGType.gtk_button_box_style_get_type());
			}
		}

		// Token: 0x0400071A RID: 1818
		private static ButtonBoxStyleGType.d_gtk_button_box_style_get_type gtk_button_box_style_get_type = FuncLoader.LoadFunction<ButtonBoxStyleGType.d_gtk_button_box_style_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_button_box_style_get_type"));

		// Token: 0x02000ABC RID: 2748
		// (Invoke) Token: 0x06005201 RID: 20993
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_button_box_style_get_type();
	}
}
