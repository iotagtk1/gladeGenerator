﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x0200014E RID: 334
	internal class BuilderErrorGType
	{
		// Token: 0x17000319 RID: 793
		// (get) Token: 0x06000E2E RID: 3630 RVA: 0x0002AA8A File Offset: 0x00028C8A
		public static GType GType
		{
			get
			{
				return new GType(BuilderErrorGType.gtk_builder_error_get_type());
			}
		}

		// Token: 0x04000706 RID: 1798
		private static BuilderErrorGType.d_gtk_builder_error_get_type gtk_builder_error_get_type = FuncLoader.LoadFunction<BuilderErrorGType.d_gtk_builder_error_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_builder_error_get_type"));

		// Token: 0x02000AB2 RID: 2738
		// (Invoke) Token: 0x060051D8 RID: 20952
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_builder_error_get_type();
	}
}
