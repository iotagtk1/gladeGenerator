﻿using System;

namespace Gtk
{
	// Token: 0x02000110 RID: 272
	// (Invoke) Token: 0x06000C65 RID: 3173
	public delegate void ActivateCursorItemHandler(object o, ActivateCursorItemArgs args);
}
