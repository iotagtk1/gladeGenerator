﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x020000ED RID: 237
	public class AboutDialog : Dialog
	{
		// Token: 0x06000ACD RID: 2765 RVA: 0x00020CB1 File Offset: 0x0001EEB1
		public AboutDialog(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000ACE RID: 2766 RVA: 0x00020CBC File Offset: 0x0001EEBC
		public AboutDialog() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(AboutDialog))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = AboutDialog.gtk_about_dialog_new();
		}

		// Token: 0x1700022E RID: 558
		// (get) Token: 0x06000ACF RID: 2767 RVA: 0x00020D0E File Offset: 0x0001EF0E
		// (set) Token: 0x06000AD0 RID: 2768 RVA: 0x00020D28 File Offset: 0x0001EF28
		[Property("program-name")]
		public string ProgramName
		{
			get
			{
				return Marshaller.Utf8PtrToString(AboutDialog.gtk_about_dialog_get_program_name(base.Handle));
			}
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				AboutDialog.gtk_about_dialog_set_program_name(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x1700022F RID: 559
		// (get) Token: 0x06000AD1 RID: 2769 RVA: 0x00020D53 File Offset: 0x0001EF53
		// (set) Token: 0x06000AD2 RID: 2770 RVA: 0x00020D6C File Offset: 0x0001EF6C
		[Property("version")]
		public string Version
		{
			get
			{
				return Marshaller.Utf8PtrToString(AboutDialog.gtk_about_dialog_get_version(base.Handle));
			}
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				AboutDialog.gtk_about_dialog_set_version(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x17000230 RID: 560
		// (get) Token: 0x06000AD3 RID: 2771 RVA: 0x00020D97 File Offset: 0x0001EF97
		// (set) Token: 0x06000AD4 RID: 2772 RVA: 0x00020DB0 File Offset: 0x0001EFB0
		[Property("copyright")]
		public string Copyright
		{
			get
			{
				return Marshaller.Utf8PtrToString(AboutDialog.gtk_about_dialog_get_copyright(base.Handle));
			}
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				AboutDialog.gtk_about_dialog_set_copyright(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x17000231 RID: 561
		// (get) Token: 0x06000AD5 RID: 2773 RVA: 0x00020DDB File Offset: 0x0001EFDB
		// (set) Token: 0x06000AD6 RID: 2774 RVA: 0x00020DF4 File Offset: 0x0001EFF4
		[Property("comments")]
		public string Comments
		{
			get
			{
				return Marshaller.Utf8PtrToString(AboutDialog.gtk_about_dialog_get_comments(base.Handle));
			}
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				AboutDialog.gtk_about_dialog_set_comments(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x17000232 RID: 562
		// (get) Token: 0x06000AD7 RID: 2775 RVA: 0x00020E1F File Offset: 0x0001F01F
		// (set) Token: 0x06000AD8 RID: 2776 RVA: 0x00020E38 File Offset: 0x0001F038
		[Property("license")]
		public string License
		{
			get
			{
				return Marshaller.Utf8PtrToString(AboutDialog.gtk_about_dialog_get_license(base.Handle));
			}
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				AboutDialog.gtk_about_dialog_set_license(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x17000233 RID: 563
		// (get) Token: 0x06000AD9 RID: 2777 RVA: 0x00020E63 File Offset: 0x0001F063
		// (set) Token: 0x06000ADA RID: 2778 RVA: 0x00020E75 File Offset: 0x0001F075
		[Property("license-type")]
		public License LicenseType
		{
			get
			{
				return (License)AboutDialog.gtk_about_dialog_get_license_type(base.Handle);
			}
			set
			{
				AboutDialog.gtk_about_dialog_set_license_type(base.Handle, (int)value);
			}
		}

		// Token: 0x17000234 RID: 564
		// (get) Token: 0x06000ADB RID: 2779 RVA: 0x00020E88 File Offset: 0x0001F088
		// (set) Token: 0x06000ADC RID: 2780 RVA: 0x00020EA0 File Offset: 0x0001F0A0
		[Property("website")]
		public string Website
		{
			get
			{
				return Marshaller.Utf8PtrToString(AboutDialog.gtk_about_dialog_get_website(base.Handle));
			}
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				AboutDialog.gtk_about_dialog_set_website(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x17000235 RID: 565
		// (get) Token: 0x06000ADD RID: 2781 RVA: 0x00020ECB File Offset: 0x0001F0CB
		// (set) Token: 0x06000ADE RID: 2782 RVA: 0x00020EE4 File Offset: 0x0001F0E4
		[Property("website-label")]
		public string WebsiteLabel
		{
			get
			{
				return Marshaller.Utf8PtrToString(AboutDialog.gtk_about_dialog_get_website_label(base.Handle));
			}
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				AboutDialog.gtk_about_dialog_set_website_label(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x17000236 RID: 566
		// (get) Token: 0x06000ADF RID: 2783 RVA: 0x00020F0F File Offset: 0x0001F10F
		// (set) Token: 0x06000AE0 RID: 2784 RVA: 0x00020F28 File Offset: 0x0001F128
		[Property("authors")]
		public string[] Authors
		{
			get
			{
				return Marshaller.NullTermPtrToStringArray(AboutDialog.gtk_about_dialog_get_authors(base.Handle), false);
			}
			set
			{
				int num = (value == null) ? 0 : value.Length;
				IntPtr[] array = new IntPtr[num + 1];
				for (int i = 0; i < num; i++)
				{
					array[i] = Marshaller.StringToPtrGStrdup(value[i]);
				}
				array[num] = IntPtr.Zero;
				AboutDialog.gtk_about_dialog_set_authors(base.Handle, array);
				for (int j = 0; j < array.Length - 1; j++)
				{
					value[j] = Marshaller.Utf8PtrToString(array[j]);
					Marshaller.Free(array[j]);
				}
			}
		}

		// Token: 0x17000237 RID: 567
		// (get) Token: 0x06000AE1 RID: 2785 RVA: 0x00020F9B File Offset: 0x0001F19B
		// (set) Token: 0x06000AE2 RID: 2786 RVA: 0x00020FB4 File Offset: 0x0001F1B4
		[Property("documenters")]
		public string[] Documenters
		{
			get
			{
				return Marshaller.NullTermPtrToStringArray(AboutDialog.gtk_about_dialog_get_documenters(base.Handle), false);
			}
			set
			{
				int num = (value == null) ? 0 : value.Length;
				IntPtr[] array = new IntPtr[num + 1];
				for (int i = 0; i < num; i++)
				{
					array[i] = Marshaller.StringToPtrGStrdup(value[i]);
				}
				array[num] = IntPtr.Zero;
				AboutDialog.gtk_about_dialog_set_documenters(base.Handle, array);
				for (int j = 0; j < array.Length - 1; j++)
				{
					value[j] = Marshaller.Utf8PtrToString(array[j]);
					Marshaller.Free(array[j]);
				}
			}
		}

		// Token: 0x17000238 RID: 568
		// (get) Token: 0x06000AE3 RID: 2787 RVA: 0x00021027 File Offset: 0x0001F227
		// (set) Token: 0x06000AE4 RID: 2788 RVA: 0x00021040 File Offset: 0x0001F240
		[Property("artists")]
		public string[] Artists
		{
			get
			{
				return Marshaller.NullTermPtrToStringArray(AboutDialog.gtk_about_dialog_get_artists(base.Handle), false);
			}
			set
			{
				int num = (value == null) ? 0 : value.Length;
				IntPtr[] array = new IntPtr[num + 1];
				for (int i = 0; i < num; i++)
				{
					array[i] = Marshaller.StringToPtrGStrdup(value[i]);
				}
				array[num] = IntPtr.Zero;
				AboutDialog.gtk_about_dialog_set_artists(base.Handle, array);
				for (int j = 0; j < array.Length - 1; j++)
				{
					value[j] = Marshaller.Utf8PtrToString(array[j]);
					Marshaller.Free(array[j]);
				}
			}
		}

		// Token: 0x17000239 RID: 569
		// (get) Token: 0x06000AE5 RID: 2789 RVA: 0x000210B3 File Offset: 0x0001F2B3
		// (set) Token: 0x06000AE6 RID: 2790 RVA: 0x000210CC File Offset: 0x0001F2CC
		[Property("translator-credits")]
		public string TranslatorCredits
		{
			get
			{
				return Marshaller.Utf8PtrToString(AboutDialog.gtk_about_dialog_get_translator_credits(base.Handle));
			}
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				AboutDialog.gtk_about_dialog_set_translator_credits(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x1700023A RID: 570
		// (get) Token: 0x06000AE7 RID: 2791 RVA: 0x000210F7 File Offset: 0x0001F2F7
		// (set) Token: 0x06000AE8 RID: 2792 RVA: 0x00021113 File Offset: 0x0001F313
		[Property("logo")]
		public Pixbuf Logo
		{
			get
			{
				return Object.GetObject(AboutDialog.gtk_about_dialog_get_logo(base.Handle)) as Pixbuf;
			}
			set
			{
				AboutDialog.gtk_about_dialog_set_logo(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x1700023B RID: 571
		// (get) Token: 0x06000AE9 RID: 2793 RVA: 0x00021135 File Offset: 0x0001F335
		// (set) Token: 0x06000AEA RID: 2794 RVA: 0x0002114C File Offset: 0x0001F34C
		[Property("logo-icon-name")]
		public string LogoIconName
		{
			get
			{
				return Marshaller.Utf8PtrToString(AboutDialog.gtk_about_dialog_get_logo_icon_name(base.Handle));
			}
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				AboutDialog.gtk_about_dialog_set_logo_icon_name(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x1700023C RID: 572
		// (get) Token: 0x06000AEB RID: 2795 RVA: 0x00021177 File Offset: 0x0001F377
		// (set) Token: 0x06000AEC RID: 2796 RVA: 0x00021189 File Offset: 0x0001F389
		[Property("wrap-license")]
		public bool WrapLicense
		{
			get
			{
				return AboutDialog.gtk_about_dialog_get_wrap_license(base.Handle);
			}
			set
			{
				AboutDialog.gtk_about_dialog_set_wrap_license(base.Handle, value);
			}
		}

		// Token: 0x1400004A RID: 74
		// (add) Token: 0x06000AED RID: 2797 RVA: 0x0002119C File Offset: 0x0001F39C
		// (remove) Token: 0x06000AEE RID: 2798 RVA: 0x000211B4 File Offset: 0x0001F3B4
		[Signal("activate-link")]
		public event ActivateLinkHandler ActivateLink
		{
			add
			{
				base.AddSignalHandler("activate-link", value, typeof(ActivateLinkArgs));
			}
			remove
			{
				base.RemoveSignalHandler("activate-link", value);
			}
		}

		// Token: 0x1700023D RID: 573
		// (get) Token: 0x06000AEF RID: 2799 RVA: 0x000211C2 File Offset: 0x0001F3C2
		private static AboutDialog.ActivateLinkNativeDelegate ActivateLinkVMCallback
		{
			get
			{
				if (AboutDialog.ActivateLink_cb_delegate == null)
				{
					AboutDialog.ActivateLink_cb_delegate = new AboutDialog.ActivateLinkNativeDelegate(AboutDialog.ActivateLink_cb);
				}
				return AboutDialog.ActivateLink_cb_delegate;
			}
		}

		// Token: 0x06000AF0 RID: 2800 RVA: 0x000211E1 File Offset: 0x0001F3E1
		private static void OverrideActivateLink(GType gtype)
		{
			AboutDialog.OverrideActivateLink(gtype, AboutDialog.ActivateLinkVMCallback);
		}

		// Token: 0x06000AF1 RID: 2801 RVA: 0x000211F0 File Offset: 0x0001F3F0
		private unsafe static void OverrideActivateLink(GType gtype, AboutDialog.ActivateLinkNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + AboutDialog.class_abi.GetFieldOffset("activate_link");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000AF2 RID: 2802 RVA: 0x00021224 File Offset: 0x0001F424
		private static bool ActivateLink_cb(IntPtr inst, IntPtr uri)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as AboutDialog).OnActivateLink(Marshaller.Utf8PtrToString(uri));
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000AF3 RID: 2803 RVA: 0x00021264 File Offset: 0x0001F464
		[DefaultSignalHandler(Type = typeof(AboutDialog), ConnectionMethod = "OverrideActivateLink")]
		protected virtual bool OnActivateLink(string uri)
		{
			return this.InternalActivateLink(uri);
		}

		// Token: 0x06000AF4 RID: 2804 RVA: 0x00021270 File Offset: 0x0001F470
		private bool InternalActivateLink(string uri)
		{
			AboutDialog.ActivateLinkNativeDelegate activateLinkNativeDelegate = AboutDialog.class_abi.BaseOverride(base.LookupGType(), "activate_link");
			if (activateLinkNativeDelegate == null)
			{
				return false;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(uri);
			bool result = activateLinkNativeDelegate(base.Handle, intPtr);
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x1700023E RID: 574
		// (get) Token: 0x06000AF5 RID: 2805 RVA: 0x000212B4 File Offset: 0x0001F4B4
		public new static AbiStruct class_abi
		{
			get
			{
				if (AboutDialog._class_abi == null)
				{
					AboutDialog._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("activate_link", Dialog.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved1", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved1", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "activate_link", "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return AboutDialog._class_abi;
			}
		}

		// Token: 0x06000AF6 RID: 2806 RVA: 0x0002140C File Offset: 0x0001F60C
		public void AddCreditSection(string section_name, string people)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(section_name);
			IntPtr intPtr2 = Marshaller.StringToPtrGStrdup(people);
			AboutDialog.gtk_about_dialog_add_credit_section(base.Handle, intPtr, intPtr2);
			Marshaller.Free(intPtr);
			Marshaller.Free(intPtr2);
		}

		// Token: 0x1700023F RID: 575
		// (get) Token: 0x06000AF7 RID: 2807 RVA: 0x00021448 File Offset: 0x0001F648
		public new static GType GType
		{
			get
			{
				IntPtr val = AboutDialog.gtk_about_dialog_get_type();
				return new GType(val);
			}
		}

		// Token: 0x17000240 RID: 576
		// (get) Token: 0x06000AF8 RID: 2808 RVA: 0x00021468 File Offset: 0x0001F668
		public new static AbiStruct abi_info
		{
			get
			{
				if (AboutDialog._abi_info == null)
				{
					AboutDialog._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Dialog.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return AboutDialog._abi_info;
			}
		}

		// Token: 0x04000541 RID: 1345
		private static AboutDialog.d_gtk_about_dialog_new gtk_about_dialog_new = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_new"));

		// Token: 0x04000542 RID: 1346
		private static AboutDialog.d_gtk_about_dialog_get_program_name gtk_about_dialog_get_program_name = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_get_program_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_get_program_name"));

		// Token: 0x04000543 RID: 1347
		private static AboutDialog.d_gtk_about_dialog_set_program_name gtk_about_dialog_set_program_name = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_set_program_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_set_program_name"));

		// Token: 0x04000544 RID: 1348
		private static AboutDialog.d_gtk_about_dialog_get_version gtk_about_dialog_get_version = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_get_version>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_get_version"));

		// Token: 0x04000545 RID: 1349
		private static AboutDialog.d_gtk_about_dialog_set_version gtk_about_dialog_set_version = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_set_version>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_set_version"));

		// Token: 0x04000546 RID: 1350
		private static AboutDialog.d_gtk_about_dialog_get_copyright gtk_about_dialog_get_copyright = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_get_copyright>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_get_copyright"));

		// Token: 0x04000547 RID: 1351
		private static AboutDialog.d_gtk_about_dialog_set_copyright gtk_about_dialog_set_copyright = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_set_copyright>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_set_copyright"));

		// Token: 0x04000548 RID: 1352
		private static AboutDialog.d_gtk_about_dialog_get_comments gtk_about_dialog_get_comments = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_get_comments>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_get_comments"));

		// Token: 0x04000549 RID: 1353
		private static AboutDialog.d_gtk_about_dialog_set_comments gtk_about_dialog_set_comments = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_set_comments>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_set_comments"));

		// Token: 0x0400054A RID: 1354
		private static AboutDialog.d_gtk_about_dialog_get_license gtk_about_dialog_get_license = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_get_license>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_get_license"));

		// Token: 0x0400054B RID: 1355
		private static AboutDialog.d_gtk_about_dialog_set_license gtk_about_dialog_set_license = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_set_license>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_set_license"));

		// Token: 0x0400054C RID: 1356
		private static AboutDialog.d_gtk_about_dialog_get_license_type gtk_about_dialog_get_license_type = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_get_license_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_get_license_type"));

		// Token: 0x0400054D RID: 1357
		private static AboutDialog.d_gtk_about_dialog_set_license_type gtk_about_dialog_set_license_type = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_set_license_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_set_license_type"));

		// Token: 0x0400054E RID: 1358
		private static AboutDialog.d_gtk_about_dialog_get_website gtk_about_dialog_get_website = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_get_website>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_get_website"));

		// Token: 0x0400054F RID: 1359
		private static AboutDialog.d_gtk_about_dialog_set_website gtk_about_dialog_set_website = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_set_website>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_set_website"));

		// Token: 0x04000550 RID: 1360
		private static AboutDialog.d_gtk_about_dialog_get_website_label gtk_about_dialog_get_website_label = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_get_website_label>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_get_website_label"));

		// Token: 0x04000551 RID: 1361
		private static AboutDialog.d_gtk_about_dialog_set_website_label gtk_about_dialog_set_website_label = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_set_website_label>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_set_website_label"));

		// Token: 0x04000552 RID: 1362
		private static AboutDialog.d_gtk_about_dialog_get_authors gtk_about_dialog_get_authors = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_get_authors>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_get_authors"));

		// Token: 0x04000553 RID: 1363
		private static AboutDialog.d_gtk_about_dialog_set_authors gtk_about_dialog_set_authors = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_set_authors>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_set_authors"));

		// Token: 0x04000554 RID: 1364
		private static AboutDialog.d_gtk_about_dialog_get_documenters gtk_about_dialog_get_documenters = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_get_documenters>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_get_documenters"));

		// Token: 0x04000555 RID: 1365
		private static AboutDialog.d_gtk_about_dialog_set_documenters gtk_about_dialog_set_documenters = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_set_documenters>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_set_documenters"));

		// Token: 0x04000556 RID: 1366
		private static AboutDialog.d_gtk_about_dialog_get_artists gtk_about_dialog_get_artists = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_get_artists>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_get_artists"));

		// Token: 0x04000557 RID: 1367
		private static AboutDialog.d_gtk_about_dialog_set_artists gtk_about_dialog_set_artists = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_set_artists>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_set_artists"));

		// Token: 0x04000558 RID: 1368
		private static AboutDialog.d_gtk_about_dialog_get_translator_credits gtk_about_dialog_get_translator_credits = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_get_translator_credits>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_get_translator_credits"));

		// Token: 0x04000559 RID: 1369
		private static AboutDialog.d_gtk_about_dialog_set_translator_credits gtk_about_dialog_set_translator_credits = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_set_translator_credits>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_set_translator_credits"));

		// Token: 0x0400055A RID: 1370
		private static AboutDialog.d_gtk_about_dialog_get_logo gtk_about_dialog_get_logo = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_get_logo>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_get_logo"));

		// Token: 0x0400055B RID: 1371
		private static AboutDialog.d_gtk_about_dialog_set_logo gtk_about_dialog_set_logo = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_set_logo>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_set_logo"));

		// Token: 0x0400055C RID: 1372
		private static AboutDialog.d_gtk_about_dialog_get_logo_icon_name gtk_about_dialog_get_logo_icon_name = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_get_logo_icon_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_get_logo_icon_name"));

		// Token: 0x0400055D RID: 1373
		private static AboutDialog.d_gtk_about_dialog_set_logo_icon_name gtk_about_dialog_set_logo_icon_name = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_set_logo_icon_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_set_logo_icon_name"));

		// Token: 0x0400055E RID: 1374
		private static AboutDialog.d_gtk_about_dialog_get_wrap_license gtk_about_dialog_get_wrap_license = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_get_wrap_license>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_get_wrap_license"));

		// Token: 0x0400055F RID: 1375
		private static AboutDialog.d_gtk_about_dialog_set_wrap_license gtk_about_dialog_set_wrap_license = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_set_wrap_license>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_set_wrap_license"));

		// Token: 0x04000560 RID: 1376
		private static AboutDialog.ActivateLinkNativeDelegate ActivateLink_cb_delegate;

		// Token: 0x04000561 RID: 1377
		private static AbiStruct _class_abi = null;

		// Token: 0x04000562 RID: 1378
		private static AboutDialog.d_gtk_about_dialog_add_credit_section gtk_about_dialog_add_credit_section = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_add_credit_section>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_add_credit_section"));

		// Token: 0x04000563 RID: 1379
		private static AboutDialog.d_gtk_about_dialog_get_type gtk_about_dialog_get_type = FuncLoader.LoadFunction<AboutDialog.d_gtk_about_dialog_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_about_dialog_get_type"));

		// Token: 0x04000564 RID: 1380
		private static AbiStruct _abi_info = null;

		// Token: 0x02000967 RID: 2407
		// (Invoke) Token: 0x06004CB2 RID: 19634
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_about_dialog_new();

		// Token: 0x02000968 RID: 2408
		// (Invoke) Token: 0x06004CB6 RID: 19638
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_about_dialog_get_program_name(IntPtr raw);

		// Token: 0x02000969 RID: 2409
		// (Invoke) Token: 0x06004CBA RID: 19642
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_about_dialog_set_program_name(IntPtr raw, IntPtr name);

		// Token: 0x0200096A RID: 2410
		// (Invoke) Token: 0x06004CBE RID: 19646
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_about_dialog_get_version(IntPtr raw);

		// Token: 0x0200096B RID: 2411
		// (Invoke) Token: 0x06004CC2 RID: 19650
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_about_dialog_set_version(IntPtr raw, IntPtr version);

		// Token: 0x0200096C RID: 2412
		// (Invoke) Token: 0x06004CC6 RID: 19654
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_about_dialog_get_copyright(IntPtr raw);

		// Token: 0x0200096D RID: 2413
		// (Invoke) Token: 0x06004CCA RID: 19658
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_about_dialog_set_copyright(IntPtr raw, IntPtr copyright);

		// Token: 0x0200096E RID: 2414
		// (Invoke) Token: 0x06004CCE RID: 19662
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_about_dialog_get_comments(IntPtr raw);

		// Token: 0x0200096F RID: 2415
		// (Invoke) Token: 0x06004CD2 RID: 19666
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_about_dialog_set_comments(IntPtr raw, IntPtr comments);

		// Token: 0x02000970 RID: 2416
		// (Invoke) Token: 0x06004CD6 RID: 19670
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_about_dialog_get_license(IntPtr raw);

		// Token: 0x02000971 RID: 2417
		// (Invoke) Token: 0x06004CDA RID: 19674
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_about_dialog_set_license(IntPtr raw, IntPtr license);

		// Token: 0x02000972 RID: 2418
		// (Invoke) Token: 0x06004CDE RID: 19678
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_about_dialog_get_license_type(IntPtr raw);

		// Token: 0x02000973 RID: 2419
		// (Invoke) Token: 0x06004CE2 RID: 19682
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_about_dialog_set_license_type(IntPtr raw, int license_type);

		// Token: 0x02000974 RID: 2420
		// (Invoke) Token: 0x06004CE6 RID: 19686
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_about_dialog_get_website(IntPtr raw);

		// Token: 0x02000975 RID: 2421
		// (Invoke) Token: 0x06004CEA RID: 19690
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_about_dialog_set_website(IntPtr raw, IntPtr website);

		// Token: 0x02000976 RID: 2422
		// (Invoke) Token: 0x06004CEE RID: 19694
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_about_dialog_get_website_label(IntPtr raw);

		// Token: 0x02000977 RID: 2423
		// (Invoke) Token: 0x06004CF2 RID: 19698
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_about_dialog_set_website_label(IntPtr raw, IntPtr website_label);

		// Token: 0x02000978 RID: 2424
		// (Invoke) Token: 0x06004CF6 RID: 19702
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_about_dialog_get_authors(IntPtr raw);

		// Token: 0x02000979 RID: 2425
		// (Invoke) Token: 0x06004CFA RID: 19706
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_about_dialog_set_authors(IntPtr raw, IntPtr[] authors);

		// Token: 0x0200097A RID: 2426
		// (Invoke) Token: 0x06004CFE RID: 19710
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_about_dialog_get_documenters(IntPtr raw);

		// Token: 0x0200097B RID: 2427
		// (Invoke) Token: 0x06004D02 RID: 19714
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_about_dialog_set_documenters(IntPtr raw, IntPtr[] documenters);

		// Token: 0x0200097C RID: 2428
		// (Invoke) Token: 0x06004D06 RID: 19718
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_about_dialog_get_artists(IntPtr raw);

		// Token: 0x0200097D RID: 2429
		// (Invoke) Token: 0x06004D0A RID: 19722
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_about_dialog_set_artists(IntPtr raw, IntPtr[] artists);

		// Token: 0x0200097E RID: 2430
		// (Invoke) Token: 0x06004D0E RID: 19726
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_about_dialog_get_translator_credits(IntPtr raw);

		// Token: 0x0200097F RID: 2431
		// (Invoke) Token: 0x06004D12 RID: 19730
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_about_dialog_set_translator_credits(IntPtr raw, IntPtr translator_credits);

		// Token: 0x02000980 RID: 2432
		// (Invoke) Token: 0x06004D16 RID: 19734
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_about_dialog_get_logo(IntPtr raw);

		// Token: 0x02000981 RID: 2433
		// (Invoke) Token: 0x06004D1A RID: 19738
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_about_dialog_set_logo(IntPtr raw, IntPtr logo);

		// Token: 0x02000982 RID: 2434
		// (Invoke) Token: 0x06004D1E RID: 19742
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_about_dialog_get_logo_icon_name(IntPtr raw);

		// Token: 0x02000983 RID: 2435
		// (Invoke) Token: 0x06004D22 RID: 19746
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_about_dialog_set_logo_icon_name(IntPtr raw, IntPtr icon_name);

		// Token: 0x02000984 RID: 2436
		// (Invoke) Token: 0x06004D26 RID: 19750
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_about_dialog_get_wrap_license(IntPtr raw);

		// Token: 0x02000985 RID: 2437
		// (Invoke) Token: 0x06004D2A RID: 19754
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_about_dialog_set_wrap_license(IntPtr raw, bool wrap_license);

		// Token: 0x02000986 RID: 2438
		// (Invoke) Token: 0x06004D2E RID: 19758
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool ActivateLinkNativeDelegate(IntPtr inst, IntPtr uri);

		// Token: 0x02000987 RID: 2439
		// (Invoke) Token: 0x06004D32 RID: 19762
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_about_dialog_add_credit_section(IntPtr raw, IntPtr section_name, IntPtr people);

		// Token: 0x02000988 RID: 2440
		// (Invoke) Token: 0x06004D36 RID: 19766
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_about_dialog_get_type();
	}
}
