﻿using System;
using System.Runtime.InteropServices;
using Cairo;
using Gdk;

namespace Gtk
{
	// Token: 0x0200015D RID: 349
	public class CairoHelper
	{
		// Token: 0x06000E5F RID: 3679 RVA: 0x0002B0AF File Offset: 0x000292AF
		public static bool ShouldDrawWindow(Context cr, Window window)
		{
			return CairoHelper.gtk_cairo_should_draw_window((cr == null) ? IntPtr.Zero : cr.Handle, (window == null) ? IntPtr.Zero : window.Handle);
		}

		// Token: 0x06000E60 RID: 3680 RVA: 0x0002B0DB File Offset: 0x000292DB
		public static void TransformToWindow(Context cr, Widget widget, Window window)
		{
			CairoHelper.gtk_cairo_transform_to_window((cr == null) ? IntPtr.Zero : cr.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, (window == null) ? IntPtr.Zero : window.Handle);
		}

		// Token: 0x04000729 RID: 1833
		private static CairoHelper.d_gtk_cairo_should_draw_window gtk_cairo_should_draw_window = FuncLoader.LoadFunction<CairoHelper.d_gtk_cairo_should_draw_window>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cairo_should_draw_window"));

		// Token: 0x0400072A RID: 1834
		private static CairoHelper.d_gtk_cairo_transform_to_window gtk_cairo_transform_to_window = FuncLoader.LoadFunction<CairoHelper.d_gtk_cairo_transform_to_window>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cairo_transform_to_window"));

		// Token: 0x02000ABF RID: 2751
		// (Invoke) Token: 0x0600520D RID: 21005
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_cairo_should_draw_window(IntPtr cr, IntPtr window);

		// Token: 0x02000AC0 RID: 2752
		// (Invoke) Token: 0x06005211 RID: 21009
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cairo_transform_to_window(IntPtr cr, IntPtr widget, IntPtr window);
	}
}
