﻿using System;

namespace Gtk
{
	// Token: 0x02000187 RID: 391
	// (Invoke) Token: 0x0600107A RID: 4218
	public delegate void ChildAnchorInsertedHandler(object o, ChildAnchorInsertedArgs args);
}
