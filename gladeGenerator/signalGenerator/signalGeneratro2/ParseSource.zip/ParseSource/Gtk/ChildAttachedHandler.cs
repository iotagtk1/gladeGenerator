﻿using System;

namespace Gtk
{
	// Token: 0x02000189 RID: 393
	// (Invoke) Token: 0x06001081 RID: 4225
	public delegate void ChildAttachedHandler(object o, ChildAttachedArgs args);
}
