﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001D2 RID: 466
	public class CssImageIconThemeClass : Opaque
	{
		// Token: 0x0600119F RID: 4511 RVA: 0x00033F51 File Offset: 0x00032151
		public CssImageIconThemeClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000423 RID: 1059
		// (get) Token: 0x060011A0 RID: 4512 RVA: 0x00033F5A File Offset: 0x0003215A
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImageIconThemeClass._abi_info == null)
				{
					CssImageIconThemeClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImageIconThemeClass._abi_info;
			}
		}

		// Token: 0x04000832 RID: 2098
		private static AbiStruct _abi_info;
	}
}
