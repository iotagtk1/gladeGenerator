﻿using System;

namespace Gtk
{
	// Token: 0x02000124 RID: 292
	// (Invoke) Token: 0x06000D06 RID: 3334
	public delegate void ApplicationActivatedHandler(object o, ApplicationActivatedArgs args);
}
