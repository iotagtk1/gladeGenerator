﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x0200012B RID: 299
	public class Arrow : Misc
	{
		// Token: 0x06000D51 RID: 3409 RVA: 0x0002851A File Offset: 0x0002671A
		public Arrow(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000D52 RID: 3410 RVA: 0x00028524 File Offset: 0x00026724
		public Arrow(ArrowType arrow_type, ShadowType shadow_type) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Arrow))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				list2.Add("arrow_type");
				list.Add(new Value(arrow_type));
				list2.Add("shadow_type");
				list.Add(new Value(shadow_type));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			this.Raw = Arrow.gtk_arrow_new((int)arrow_type, (int)shadow_type);
		}

		// Token: 0x170002DA RID: 730
		// (get) Token: 0x06000D53 RID: 3411 RVA: 0x000285BC File Offset: 0x000267BC
		// (set) Token: 0x06000D54 RID: 3412 RVA: 0x000285E8 File Offset: 0x000267E8
		[Property("arrow-type")]
		public ArrowType ArrowType
		{
			get
			{
				Value property = base.GetProperty("arrow-type");
				ArrowType result = (ArrowType)((Enum)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("arrow-type", val);
				val.Dispose();
			}
		}

		// Token: 0x170002DB RID: 731
		// (get) Token: 0x06000D55 RID: 3413 RVA: 0x00028618 File Offset: 0x00026818
		// (set) Token: 0x06000D56 RID: 3414 RVA: 0x00028644 File Offset: 0x00026844
		[Property("shadow-type")]
		public ShadowType ShadowType
		{
			get
			{
				Value property = base.GetProperty("shadow-type");
				ShadowType result = (ShadowType)((Enum)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("shadow-type", val);
				val.Dispose();
			}
		}

		// Token: 0x170002DC RID: 732
		// (get) Token: 0x06000D57 RID: 3415 RVA: 0x00028674 File Offset: 0x00026874
		[Property("arrow-scaling")]
		public float ArrowScaling
		{
			get
			{
				Value property = base.GetProperty("arrow-scaling");
				float result = (float)property;
				property.Dispose();
				return result;
			}
		}

		// Token: 0x170002DD RID: 733
		// (get) Token: 0x06000D58 RID: 3416 RVA: 0x0002869C File Offset: 0x0002689C
		public new static AbiStruct class_abi
		{
			get
			{
				if (Arrow._class_abi == null)
				{
					Arrow._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("_gtk_reserved1", Misc.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Arrow._class_abi;
			}
		}

		// Token: 0x170002DE RID: 734
		// (get) Token: 0x06000D59 RID: 3417 RVA: 0x000287B8 File Offset: 0x000269B8
		[Obsolete]
		public new static GType GType
		{
			get
			{
				IntPtr val = Arrow.gtk_arrow_get_type();
				return new GType(val);
			}
		}

		// Token: 0x170002DF RID: 735
		// (get) Token: 0x06000D5A RID: 3418 RVA: 0x000287D8 File Offset: 0x000269D8
		public new static AbiStruct abi_info
		{
			get
			{
				if (Arrow._abi_info == null)
				{
					Arrow._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Misc.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Arrow._abi_info;
			}
		}

		// Token: 0x04000675 RID: 1653
		private static Arrow.d_gtk_arrow_new gtk_arrow_new = FuncLoader.LoadFunction<Arrow.d_gtk_arrow_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_arrow_new"));

		// Token: 0x04000676 RID: 1654
		private static AbiStruct _class_abi = null;

		// Token: 0x04000677 RID: 1655
		private static Arrow.d_gtk_arrow_get_type gtk_arrow_get_type = FuncLoader.LoadFunction<Arrow.d_gtk_arrow_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_arrow_get_type"));

		// Token: 0x04000678 RID: 1656
		private static AbiStruct _abi_info = null;

		// Token: 0x02000A70 RID: 2672
		// (Invoke) Token: 0x060050C7 RID: 20679
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_arrow_new(int arrow_type, int shadow_type);

		// Token: 0x02000A71 RID: 2673
		// (Invoke) Token: 0x060050CB RID: 20683
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_arrow_get_type();
	}
}
