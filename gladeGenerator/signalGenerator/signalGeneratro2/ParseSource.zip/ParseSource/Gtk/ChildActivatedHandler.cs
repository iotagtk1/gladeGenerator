﻿using System;

namespace Gtk
{
	// Token: 0x02000185 RID: 389
	// (Invoke) Token: 0x06001074 RID: 4212
	public delegate void ChildActivatedHandler(object o, ChildActivatedArgs args);
}
