﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001CB RID: 459
	public class CssImageCrossFade : Opaque
	{
		// Token: 0x06001191 RID: 4497 RVA: 0x00033E47 File Offset: 0x00032047
		public CssImageCrossFade(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700041C RID: 1052
		// (get) Token: 0x06001192 RID: 4498 RVA: 0x00033E50 File Offset: 0x00032050
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImageCrossFade._abi_info == null)
				{
					CssImageCrossFade._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImageCrossFade._abi_info;
			}
		}

		// Token: 0x0400082B RID: 2091
		private static AbiStruct _abi_info;
	}
}
