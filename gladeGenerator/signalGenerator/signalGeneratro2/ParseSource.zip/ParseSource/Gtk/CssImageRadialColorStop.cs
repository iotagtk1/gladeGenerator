﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001D8 RID: 472
	public class CssImageRadialColorStop : Opaque
	{
		// Token: 0x060011AB RID: 4523 RVA: 0x00034035 File Offset: 0x00032235
		public CssImageRadialColorStop(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000429 RID: 1065
		// (get) Token: 0x060011AC RID: 4524 RVA: 0x0003403E File Offset: 0x0003223E
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImageRadialColorStop._abi_info == null)
				{
					CssImageRadialColorStop._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImageRadialColorStop._abi_info;
			}
		}

		// Token: 0x04000838 RID: 2104
		private static AbiStruct _abi_info;
	}
}
