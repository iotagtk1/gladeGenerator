﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x020000FF RID: 255
	public class AccelLabel : Label
	{
		// Token: 0x06000B5D RID: 2909 RVA: 0x000223DE File Offset: 0x000205DE
		public AccelLabel(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000B5E RID: 2910 RVA: 0x000223E8 File Offset: 0x000205E8
		public AccelLabel(string str1ng) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(AccelLabel))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				list2.Add("label");
				list.Add(new Value(str1ng));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(str1ng);
			this.Raw = AccelLabel.gtk_accel_label_new(intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x17000257 RID: 599
		// (get) Token: 0x06000B5F RID: 2911 RVA: 0x0002246C File Offset: 0x0002066C
		// (set) Token: 0x06000B60 RID: 2912 RVA: 0x00022492 File Offset: 0x00020692
		[Property("accel-closure")]
		public IntPtr AccelClosure
		{
			get
			{
				Value property = base.GetProperty("accel-closure");
				IntPtr result = (IntPtr)property;
				property.Dispose();
				return result;
			}
			set
			{
				AccelLabel.gtk_accel_label_set_accel_closure(base.Handle, value);
			}
		}

		// Token: 0x17000258 RID: 600
		// (get) Token: 0x06000B61 RID: 2913 RVA: 0x000224A5 File Offset: 0x000206A5
		// (set) Token: 0x06000B62 RID: 2914 RVA: 0x000224C1 File Offset: 0x000206C1
		[Property("accel-widget")]
		public Widget AccelWidget
		{
			get
			{
				return Object.GetObject(AccelLabel.gtk_accel_label_get_accel_widget(base.Handle)) as Widget;
			}
			set
			{
				AccelLabel.gtk_accel_label_set_accel_widget(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x17000259 RID: 601
		// (get) Token: 0x06000B63 RID: 2915 RVA: 0x000224E4 File Offset: 0x000206E4
		public new static AbiStruct class_abi
		{
			get
			{
				if (AccelLabel._class_abi == null)
				{
					AccelLabel._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("signal_quote1", Label.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "signal_quote2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("signal_quote2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "signal_quote1", "mod_name_shift", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("mod_name_shift", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "signal_quote2", "mod_name_control", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("mod_name_control", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "mod_name_shift", "mod_name_alt", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("mod_name_alt", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "mod_name_control", "mod_separator", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("mod_separator", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "mod_name_alt", "_gtk_reserved1", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved1", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "mod_separator", "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return AccelLabel._class_abi;
			}
		}

		// Token: 0x06000B64 RID: 2916 RVA: 0x00022768 File Offset: 0x00020968
		public void GetAccel(out uint accelerator_key, out ModifierType accelerator_mods)
		{
			int num;
			AccelLabel.gtk_accel_label_get_accel(base.Handle, out accelerator_key, out num);
			accelerator_mods = (ModifierType)num;
		}

		// Token: 0x1700025A RID: 602
		// (get) Token: 0x06000B65 RID: 2917 RVA: 0x0002278B File Offset: 0x0002098B
		public uint AccelWidth
		{
			get
			{
				return AccelLabel.gtk_accel_label_get_accel_width(base.Handle);
			}
		}

		// Token: 0x1700025B RID: 603
		// (get) Token: 0x06000B66 RID: 2918 RVA: 0x000227A0 File Offset: 0x000209A0
		public new static GType GType
		{
			get
			{
				IntPtr val = AccelLabel.gtk_accel_label_get_type();
				return new GType(val);
			}
		}

		// Token: 0x06000B67 RID: 2919 RVA: 0x000227BE File Offset: 0x000209BE
		public bool Refetch()
		{
			return AccelLabel.gtk_accel_label_refetch(base.Handle);
		}

		// Token: 0x06000B68 RID: 2920 RVA: 0x000227D0 File Offset: 0x000209D0
		public void SetAccel(uint accelerator_key, ModifierType accelerator_mods)
		{
			AccelLabel.gtk_accel_label_set_accel(base.Handle, accelerator_key, (int)accelerator_mods);
		}

		// Token: 0x1700025C RID: 604
		// (get) Token: 0x06000B69 RID: 2921 RVA: 0x000227E4 File Offset: 0x000209E4
		public new static AbiStruct abi_info
		{
			get
			{
				if (AccelLabel._abi_info == null)
				{
					AccelLabel._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Label.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return AccelLabel._abi_info;
			}
		}

		// Token: 0x04000589 RID: 1417
		private static AccelLabel.d_gtk_accel_label_new gtk_accel_label_new = FuncLoader.LoadFunction<AccelLabel.d_gtk_accel_label_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_label_new"));

		// Token: 0x0400058A RID: 1418
		private static AccelLabel.d_gtk_accel_label_set_accel_closure gtk_accel_label_set_accel_closure = FuncLoader.LoadFunction<AccelLabel.d_gtk_accel_label_set_accel_closure>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_label_set_accel_closure"));

		// Token: 0x0400058B RID: 1419
		private static AccelLabel.d_gtk_accel_label_get_accel_widget gtk_accel_label_get_accel_widget = FuncLoader.LoadFunction<AccelLabel.d_gtk_accel_label_get_accel_widget>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_label_get_accel_widget"));

		// Token: 0x0400058C RID: 1420
		private static AccelLabel.d_gtk_accel_label_set_accel_widget gtk_accel_label_set_accel_widget = FuncLoader.LoadFunction<AccelLabel.d_gtk_accel_label_set_accel_widget>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_label_set_accel_widget"));

		// Token: 0x0400058D RID: 1421
		private static AbiStruct _class_abi = null;

		// Token: 0x0400058E RID: 1422
		private static AccelLabel.d_gtk_accel_label_get_accel gtk_accel_label_get_accel = FuncLoader.LoadFunction<AccelLabel.d_gtk_accel_label_get_accel>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_label_get_accel"));

		// Token: 0x0400058F RID: 1423
		private static AccelLabel.d_gtk_accel_label_get_accel_width gtk_accel_label_get_accel_width = FuncLoader.LoadFunction<AccelLabel.d_gtk_accel_label_get_accel_width>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_label_get_accel_width"));

		// Token: 0x04000590 RID: 1424
		private static AccelLabel.d_gtk_accel_label_get_type gtk_accel_label_get_type = FuncLoader.LoadFunction<AccelLabel.d_gtk_accel_label_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_label_get_type"));

		// Token: 0x04000591 RID: 1425
		private static AccelLabel.d_gtk_accel_label_refetch gtk_accel_label_refetch = FuncLoader.LoadFunction<AccelLabel.d_gtk_accel_label_refetch>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_label_refetch"));

		// Token: 0x04000592 RID: 1426
		private static AccelLabel.d_gtk_accel_label_set_accel gtk_accel_label_set_accel = FuncLoader.LoadFunction<AccelLabel.d_gtk_accel_label_set_accel>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_label_set_accel"));

		// Token: 0x04000593 RID: 1427
		private static AbiStruct _abi_info = null;

		// Token: 0x020009A3 RID: 2467
		// (Invoke) Token: 0x06004DA2 RID: 19874
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_accel_label_new(IntPtr str1ng);

		// Token: 0x020009A4 RID: 2468
		// (Invoke) Token: 0x06004DA6 RID: 19878
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accel_label_set_accel_closure(IntPtr raw, IntPtr accel_closure);

		// Token: 0x020009A5 RID: 2469
		// (Invoke) Token: 0x06004DAA RID: 19882
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_accel_label_get_accel_widget(IntPtr raw);

		// Token: 0x020009A6 RID: 2470
		// (Invoke) Token: 0x06004DAE RID: 19886
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accel_label_set_accel_widget(IntPtr raw, IntPtr accel_widget);

		// Token: 0x020009A7 RID: 2471
		// (Invoke) Token: 0x06004DB2 RID: 19890
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accel_label_get_accel(IntPtr raw, out uint accelerator_key, out int accelerator_mods);

		// Token: 0x020009A8 RID: 2472
		// (Invoke) Token: 0x06004DB6 RID: 19894
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gtk_accel_label_get_accel_width(IntPtr raw);

		// Token: 0x020009A9 RID: 2473
		// (Invoke) Token: 0x06004DBA RID: 19898
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_accel_label_get_type();

		// Token: 0x020009AA RID: 2474
		// (Invoke) Token: 0x06004DBE RID: 19902
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_accel_label_refetch(IntPtr raw);

		// Token: 0x020009AB RID: 2475
		// (Invoke) Token: 0x06004DC2 RID: 19906
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accel_label_set_accel(IntPtr raw, uint accelerator_key, int accelerator_mods);
	}
}
