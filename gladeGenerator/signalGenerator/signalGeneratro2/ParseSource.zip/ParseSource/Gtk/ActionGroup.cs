﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;
using GtkSharp;

namespace Gtk
{
	// Token: 0x020000D2 RID: 210
	public class ActionGroup : Object
	{
		// Token: 0x17000063 RID: 99
		public Action this[string name]
		{
			get
			{
				return this.GetAction(name);
			}
		}

		// Token: 0x06000429 RID: 1065 RVA: 0x0000A6B0 File Offset: 0x000088B0
		public void Add(ActionEntry[] entries)
		{
			foreach (ActionEntry actionEntry in entries)
			{
				Action action = new Action(actionEntry.name, actionEntry.label, actionEntry.tooltip, actionEntry.stock_id);
				if (actionEntry.activated != null)
				{
					action.Activated += actionEntry.activated;
				}
				if (actionEntry.accelerator == null)
				{
					this.Add(action);
				}
				else
				{
					this.Add(action, actionEntry.accelerator);
				}
			}
		}

		// Token: 0x0600042A RID: 1066 RVA: 0x0000A728 File Offset: 0x00008928
		public void Add(ToggleActionEntry[] entries)
		{
			foreach (ToggleActionEntry toggleActionEntry in entries)
			{
				ToggleAction toggleAction = new ToggleAction(toggleActionEntry.name, toggleActionEntry.label, toggleActionEntry.tooltip, toggleActionEntry.stock_id);
				toggleAction.Active = toggleActionEntry.active;
				if (toggleActionEntry.activated != null)
				{
					toggleAction.Activated += toggleActionEntry.activated;
				}
				if (toggleActionEntry.accelerator == null)
				{
					this.Add(toggleAction);
				}
				else
				{
					this.Add(toggleAction, toggleActionEntry.accelerator);
				}
			}
		}

		// Token: 0x0600042B RID: 1067 RVA: 0x0000A7AC File Offset: 0x000089AC
		public void Add(RadioActionEntry[] entries, int value, ChangedHandler changed)
		{
			RadioAction[] group = null;
			RadioAction[] array = new RadioAction[entries.Length];
			for (int i = 0; i < entries.Length; i++)
			{
				array[i] = new RadioAction(entries[i].name, entries[i].label, entries[i].tooltip, entries[i].stock_id, entries[i].value);
				array[i].Group = group;
				group = array[i].Group;
				array[i].Active = (value == entries[i].value);
				if (entries[i].accelerator == null)
				{
					this.Add(array[i]);
				}
				else
				{
					this.Add(array[i], entries[i].accelerator);
				}
			}
			if (changed != null)
			{
				array[0].Changed += changed;
			}
		}

		// Token: 0x0600042C RID: 1068 RVA: 0x0000A880 File Offset: 0x00008A80
		public Action[] ListActions()
		{
			List list = new List(ActionGroup.gtk_action_group_list_actions(base.Handle));
			Action[] array = new Action[list.Count];
			for (int i = 0; i < list.Count; i++)
			{
				array[i] = (list[i] as Action);
			}
			return array;
		}

		// Token: 0x0600042D RID: 1069 RVA: 0x0000A8D0 File Offset: 0x00008AD0
		public ActionGroup(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x0600042E RID: 1070 RVA: 0x0000A8DC File Offset: 0x00008ADC
		public ActionGroup(string name) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(ActionGroup))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				list2.Add("name");
				list.Add(new Value(name));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(name);
			this.Raw = ActionGroup.gtk_action_group_new(intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x0600042F RID: 1071 RVA: 0x0000A95F File Offset: 0x00008B5F
		[Obsolete]
		[Property("name")]
		public string Name
		{
			get
			{
				return Marshaller.Utf8PtrToString(ActionGroup.gtk_action_group_get_name(base.Handle));
			}
		}

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x06000430 RID: 1072 RVA: 0x0000A976 File Offset: 0x00008B76
		// (set) Token: 0x06000431 RID: 1073 RVA: 0x0000A988 File Offset: 0x00008B88
		[Obsolete]
		[Property("sensitive")]
		public bool Sensitive
		{
			get
			{
				return ActionGroup.gtk_action_group_get_sensitive(base.Handle);
			}
			set
			{
				ActionGroup.gtk_action_group_set_sensitive(base.Handle, value);
			}
		}

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x06000432 RID: 1074 RVA: 0x0000A99B File Offset: 0x00008B9B
		// (set) Token: 0x06000433 RID: 1075 RVA: 0x0000A9AD File Offset: 0x00008BAD
		[Obsolete]
		[Property("visible")]
		public bool Visible
		{
			get
			{
				return ActionGroup.gtk_action_group_get_visible(base.Handle);
			}
			set
			{
				ActionGroup.gtk_action_group_set_visible(base.Handle, value);
			}
		}

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x06000434 RID: 1076 RVA: 0x0000A9C0 File Offset: 0x00008BC0
		// (set) Token: 0x06000435 RID: 1077 RVA: 0x0000A9DC File Offset: 0x00008BDC
		[Obsolete]
		[Property("accel-group")]
		public AccelGroup AccelGroup
		{
			get
			{
				return Object.GetObject(ActionGroup.gtk_action_group_get_accel_group(base.Handle)) as AccelGroup;
			}
			set
			{
				ActionGroup.gtk_action_group_set_accel_group(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x14000002 RID: 2
		// (add) Token: 0x06000436 RID: 1078 RVA: 0x0000A9FE File Offset: 0x00008BFE
		// (remove) Token: 0x06000437 RID: 1079 RVA: 0x0000AA16 File Offset: 0x00008C16
		[Signal("connect-proxy")]
		public event ConnectProxyHandler ConnectProxy
		{
			add
			{
				base.AddSignalHandler("connect-proxy", value, typeof(ConnectProxyArgs));
			}
			remove
			{
				base.RemoveSignalHandler("connect-proxy", value);
			}
		}

		// Token: 0x14000003 RID: 3
		// (add) Token: 0x06000438 RID: 1080 RVA: 0x0000AA24 File Offset: 0x00008C24
		// (remove) Token: 0x06000439 RID: 1081 RVA: 0x0000AA3C File Offset: 0x00008C3C
		[Signal("pre-activate")]
		public event PreActivateHandler PreActivate
		{
			add
			{
				base.AddSignalHandler("pre-activate", value, typeof(PreActivateArgs));
			}
			remove
			{
				base.RemoveSignalHandler("pre-activate", value);
			}
		}

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x0600043A RID: 1082 RVA: 0x0000AA4A File Offset: 0x00008C4A
		// (remove) Token: 0x0600043B RID: 1083 RVA: 0x0000AA62 File Offset: 0x00008C62
		[Signal("post-activate")]
		public event PostActivateHandler PostActivate
		{
			add
			{
				base.AddSignalHandler("post-activate", value, typeof(PostActivateArgs));
			}
			remove
			{
				base.RemoveSignalHandler("post-activate", value);
			}
		}

		// Token: 0x14000005 RID: 5
		// (add) Token: 0x0600043C RID: 1084 RVA: 0x0000AA70 File Offset: 0x00008C70
		// (remove) Token: 0x0600043D RID: 1085 RVA: 0x0000AA88 File Offset: 0x00008C88
		[Signal("disconnect-proxy")]
		public event DisconnectProxyHandler DisconnectProxy
		{
			add
			{
				base.AddSignalHandler("disconnect-proxy", value, typeof(DisconnectProxyArgs));
			}
			remove
			{
				base.RemoveSignalHandler("disconnect-proxy", value);
			}
		}

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x0600043E RID: 1086 RVA: 0x0000AA96 File Offset: 0x00008C96
		private static ActionGroup.ConnectProxyNativeDelegate ConnectProxyVMCallback
		{
			get
			{
				if (ActionGroup.ConnectProxy_cb_delegate == null)
				{
					ActionGroup.ConnectProxy_cb_delegate = new ActionGroup.ConnectProxyNativeDelegate(ActionGroup.ConnectProxy_cb);
				}
				return ActionGroup.ConnectProxy_cb_delegate;
			}
		}

		// Token: 0x0600043F RID: 1087 RVA: 0x0000AAB5 File Offset: 0x00008CB5
		private static void OverrideConnectProxy(GType gtype)
		{
			ActionGroup.OverrideConnectProxy(gtype, ActionGroup.ConnectProxyVMCallback);
		}

		// Token: 0x06000440 RID: 1088 RVA: 0x0000AAC2 File Offset: 0x00008CC2
		private static void OverrideConnectProxy(GType gtype, ActionGroup.ConnectProxyNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "connect-proxy", callback);
		}

		// Token: 0x06000441 RID: 1089 RVA: 0x0000AAD0 File Offset: 0x00008CD0
		private static void ConnectProxy_cb(IntPtr inst, IntPtr action, IntPtr proxy)
		{
			try
			{
				(Object.GetObject(inst, false) as ActionGroup).OnConnectProxy(Object.GetObject(action) as Action, Object.GetObject(proxy) as Widget);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000442 RID: 1090 RVA: 0x0000AB20 File Offset: 0x00008D20
		[DefaultSignalHandler(Type = typeof(ActionGroup), ConnectionMethod = "OverrideConnectProxy")]
		protected virtual void OnConnectProxy(Action action, Widget proxy)
		{
			this.InternalConnectProxy(action, proxy);
		}

		// Token: 0x06000443 RID: 1091 RVA: 0x0000AB2C File Offset: 0x00008D2C
		private void InternalConnectProxy(Action action, Widget proxy)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(3U);
			Value[] array = new Value[3];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(action);
			valueArray.Append(array[1]);
			array[2] = new Value(proxy);
			valueArray.Append(array[2]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x06000444 RID: 1092 RVA: 0x0000ABD2 File Offset: 0x00008DD2
		private static ActionGroup.DisconnectProxyNativeDelegate DisconnectProxyVMCallback
		{
			get
			{
				if (ActionGroup.DisconnectProxy_cb_delegate == null)
				{
					ActionGroup.DisconnectProxy_cb_delegate = new ActionGroup.DisconnectProxyNativeDelegate(ActionGroup.DisconnectProxy_cb);
				}
				return ActionGroup.DisconnectProxy_cb_delegate;
			}
		}

		// Token: 0x06000445 RID: 1093 RVA: 0x0000ABF1 File Offset: 0x00008DF1
		private static void OverrideDisconnectProxy(GType gtype)
		{
			ActionGroup.OverrideDisconnectProxy(gtype, ActionGroup.DisconnectProxyVMCallback);
		}

		// Token: 0x06000446 RID: 1094 RVA: 0x0000ABFE File Offset: 0x00008DFE
		private static void OverrideDisconnectProxy(GType gtype, ActionGroup.DisconnectProxyNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "disconnect-proxy", callback);
		}

		// Token: 0x06000447 RID: 1095 RVA: 0x0000AC0C File Offset: 0x00008E0C
		private static void DisconnectProxy_cb(IntPtr inst, IntPtr action, IntPtr proxy)
		{
			try
			{
				(Object.GetObject(inst, false) as ActionGroup).OnDisconnectProxy(Object.GetObject(action) as Action, Object.GetObject(proxy) as Widget);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000448 RID: 1096 RVA: 0x0000AC5C File Offset: 0x00008E5C
		[DefaultSignalHandler(Type = typeof(ActionGroup), ConnectionMethod = "OverrideDisconnectProxy")]
		protected virtual void OnDisconnectProxy(Action action, Widget proxy)
		{
			this.InternalDisconnectProxy(action, proxy);
		}

		// Token: 0x06000449 RID: 1097 RVA: 0x0000AC68 File Offset: 0x00008E68
		private void InternalDisconnectProxy(Action action, Widget proxy)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(3U);
			Value[] array = new Value[3];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(action);
			valueArray.Append(array[1]);
			array[2] = new Value(proxy);
			valueArray.Append(array[2]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x0600044A RID: 1098 RVA: 0x0000AD0E File Offset: 0x00008F0E
		private static ActionGroup.PreActivateNativeDelegate PreActivateVMCallback
		{
			get
			{
				if (ActionGroup.PreActivate_cb_delegate == null)
				{
					ActionGroup.PreActivate_cb_delegate = new ActionGroup.PreActivateNativeDelegate(ActionGroup.PreActivate_cb);
				}
				return ActionGroup.PreActivate_cb_delegate;
			}
		}

		// Token: 0x0600044B RID: 1099 RVA: 0x0000AD2D File Offset: 0x00008F2D
		private static void OverridePreActivate(GType gtype)
		{
			ActionGroup.OverridePreActivate(gtype, ActionGroup.PreActivateVMCallback);
		}

		// Token: 0x0600044C RID: 1100 RVA: 0x0000AD3A File Offset: 0x00008F3A
		private static void OverridePreActivate(GType gtype, ActionGroup.PreActivateNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "pre-activate", callback);
		}

		// Token: 0x0600044D RID: 1101 RVA: 0x0000AD48 File Offset: 0x00008F48
		private static void PreActivate_cb(IntPtr inst, IntPtr action)
		{
			try
			{
				(Object.GetObject(inst, false) as ActionGroup).OnPreActivate(Object.GetObject(action) as Action);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x0600044E RID: 1102 RVA: 0x0000AD8C File Offset: 0x00008F8C
		[DefaultSignalHandler(Type = typeof(ActionGroup), ConnectionMethod = "OverridePreActivate")]
		protected virtual void OnPreActivate(Action action)
		{
			this.InternalPreActivate(action);
		}

		// Token: 0x0600044F RID: 1103 RVA: 0x0000AD98 File Offset: 0x00008F98
		private void InternalPreActivate(Action action)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(2U);
			Value[] array = new Value[2];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(action);
			valueArray.Append(array[1]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x06000450 RID: 1104 RVA: 0x0000AE24 File Offset: 0x00009024
		private static ActionGroup.PostActivateNativeDelegate PostActivateVMCallback
		{
			get
			{
				if (ActionGroup.PostActivate_cb_delegate == null)
				{
					ActionGroup.PostActivate_cb_delegate = new ActionGroup.PostActivateNativeDelegate(ActionGroup.PostActivate_cb);
				}
				return ActionGroup.PostActivate_cb_delegate;
			}
		}

		// Token: 0x06000451 RID: 1105 RVA: 0x0000AE43 File Offset: 0x00009043
		private static void OverridePostActivate(GType gtype)
		{
			ActionGroup.OverridePostActivate(gtype, ActionGroup.PostActivateVMCallback);
		}

		// Token: 0x06000452 RID: 1106 RVA: 0x0000AE50 File Offset: 0x00009050
		private static void OverridePostActivate(GType gtype, ActionGroup.PostActivateNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "post-activate", callback);
		}

		// Token: 0x06000453 RID: 1107 RVA: 0x0000AE60 File Offset: 0x00009060
		private static void PostActivate_cb(IntPtr inst, IntPtr action)
		{
			try
			{
				(Object.GetObject(inst, false) as ActionGroup).OnPostActivate(Object.GetObject(action) as Action);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000454 RID: 1108 RVA: 0x0000AEA4 File Offset: 0x000090A4
		[DefaultSignalHandler(Type = typeof(ActionGroup), ConnectionMethod = "OverridePostActivate")]
		protected virtual void OnPostActivate(Action action)
		{
			this.InternalPostActivate(action);
		}

		// Token: 0x06000455 RID: 1109 RVA: 0x0000AEB0 File Offset: 0x000090B0
		private void InternalPostActivate(Action action)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(2U);
			Value[] array = new Value[2];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(action);
			valueArray.Append(array[1]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x06000456 RID: 1110 RVA: 0x0000AF3C File Offset: 0x0000913C
		private static ActionGroup.GetActionNativeDelegate GetActionVMCallback
		{
			get
			{
				if (ActionGroup.GetAction_cb_delegate == null)
				{
					ActionGroup.GetAction_cb_delegate = new ActionGroup.GetActionNativeDelegate(ActionGroup.GetAction_cb);
				}
				return ActionGroup.GetAction_cb_delegate;
			}
		}

		// Token: 0x06000457 RID: 1111 RVA: 0x0000AF5B File Offset: 0x0000915B
		private static void OverrideGetAction(GType gtype)
		{
			ActionGroup.OverrideGetAction(gtype, ActionGroup.GetActionVMCallback);
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x0000AF68 File Offset: 0x00009168
		private unsafe static void OverrideGetAction(GType gtype, ActionGroup.GetActionNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + ActionGroup.class_abi.GetFieldOffset("get_action");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000459 RID: 1113 RVA: 0x0000AF9C File Offset: 0x0000919C
		private static IntPtr GetAction_cb(IntPtr inst, IntPtr action_name)
		{
			IntPtr result;
			try
			{
				Action action = (Object.GetObject(inst, false) as ActionGroup).OnGetAction(Marshaller.Utf8PtrToString(action_name));
				result = ((action == null) ? IntPtr.Zero : action.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600045A RID: 1114 RVA: 0x0000AFF0 File Offset: 0x000091F0
		[DefaultSignalHandler(Type = typeof(ActionGroup), ConnectionMethod = "OverrideGetAction")]
		protected virtual Action OnGetAction(string action_name)
		{
			return this.InternalGetAction(action_name);
		}

		// Token: 0x0600045B RID: 1115 RVA: 0x0000AFFC File Offset: 0x000091FC
		private Action InternalGetAction(string action_name)
		{
			ActionGroup.GetActionNativeDelegate getActionNativeDelegate = ActionGroup.class_abi.BaseOverride(base.LookupGType(), "get_action");
			if (getActionNativeDelegate == null)
			{
				return null;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			IntPtr o = getActionNativeDelegate(base.Handle, intPtr);
			Marshaller.Free(intPtr);
			return Object.GetObject(o) as Action;
		}

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x0600045C RID: 1116 RVA: 0x0000B048 File Offset: 0x00009248
		public new static AbiStruct class_abi
		{
			get
			{
				if (ActionGroup._class_abi == null)
				{
					ActionGroup._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("get_action", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved1", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved1", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_action", "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return ActionGroup._class_abi;
			}
		}

		// Token: 0x0600045D RID: 1117 RVA: 0x0000B19F File Offset: 0x0000939F
		[Obsolete]
		public void Add(Action action)
		{
			ActionGroup.gtk_action_group_add_action(base.Handle, (action == null) ? IntPtr.Zero : action.Handle);
		}

		// Token: 0x0600045E RID: 1118 RVA: 0x0000B1C4 File Offset: 0x000093C4
		[Obsolete]
		public void Add(Action action, string accelerator)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(accelerator);
			ActionGroup.gtk_action_group_add_action_with_accel(base.Handle, (action == null) ? IntPtr.Zero : action.Handle, intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x0600045F RID: 1119 RVA: 0x0000B200 File Offset: 0x00009400
		[Obsolete]
		public Action GetAction(string action_name)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			Action result = Object.GetObject(ActionGroup.gtk_action_group_get_action(base.Handle, intPtr)) as Action;
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x06000460 RID: 1120 RVA: 0x0000B238 File Offset: 0x00009438
		[Obsolete]
		public new static GType GType
		{
			get
			{
				IntPtr val = ActionGroup.gtk_action_group_get_type();
				return new GType(val);
			}
		}

		// Token: 0x06000461 RID: 1121 RVA: 0x0000B256 File Offset: 0x00009456
		[Obsolete]
		public void Remove(Action action)
		{
			ActionGroup.gtk_action_group_remove_action(base.Handle, (action == null) ? IntPtr.Zero : action.Handle);
		}

		// Token: 0x1700006F RID: 111
		// (set) Token: 0x06000462 RID: 1122 RVA: 0x0000B278 File Offset: 0x00009478
		[Obsolete]
		public TranslateFunc TranslateFunc
		{
			set
			{
				TranslateFuncWrapper translateFuncWrapper = new TranslateFuncWrapper(value);
				IntPtr data;
				DestroyNotify notify;
				if (value == null)
				{
					data = IntPtr.Zero;
					notify = null;
				}
				else
				{
					data = (IntPtr)GCHandle.Alloc(translateFuncWrapper);
					notify = DestroyHelper.NotifyHandler;
				}
				ActionGroup.gtk_action_group_set_translate_func(base.Handle, translateFuncWrapper.NativeDelegate, data, notify);
			}
		}

		// Token: 0x17000070 RID: 112
		// (set) Token: 0x06000463 RID: 1123 RVA: 0x0000B2C4 File Offset: 0x000094C4
		[Obsolete]
		public string TranslationDomain
		{
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				ActionGroup.gtk_action_group_set_translation_domain(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x06000464 RID: 1124 RVA: 0x0000B2F0 File Offset: 0x000094F0
		[Obsolete]
		public string TranslateString(string str1ng)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(str1ng);
			string result = Marshaller.Utf8PtrToString(ActionGroup.gtk_action_group_translate_string(base.Handle, intPtr));
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x06000465 RID: 1125 RVA: 0x0000B320 File Offset: 0x00009520
		public new static AbiStruct abi_info
		{
			get
			{
				if (ActionGroup._abi_info == null)
				{
					ActionGroup._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Object.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return ActionGroup._abi_info;
			}
		}

		// Token: 0x04000231 RID: 561
		private static ActionGroup.d_gtk_action_group_list_actions gtk_action_group_list_actions = FuncLoader.LoadFunction<ActionGroup.d_gtk_action_group_list_actions>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_group_list_actions"));

		// Token: 0x04000232 RID: 562
		private static ActionGroup.d_gtk_action_group_new gtk_action_group_new = FuncLoader.LoadFunction<ActionGroup.d_gtk_action_group_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_group_new"));

		// Token: 0x04000233 RID: 563
		private static ActionGroup.d_gtk_action_group_get_name gtk_action_group_get_name = FuncLoader.LoadFunction<ActionGroup.d_gtk_action_group_get_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_group_get_name"));

		// Token: 0x04000234 RID: 564
		private static ActionGroup.d_gtk_action_group_get_sensitive gtk_action_group_get_sensitive = FuncLoader.LoadFunction<ActionGroup.d_gtk_action_group_get_sensitive>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_group_get_sensitive"));

		// Token: 0x04000235 RID: 565
		private static ActionGroup.d_gtk_action_group_set_sensitive gtk_action_group_set_sensitive = FuncLoader.LoadFunction<ActionGroup.d_gtk_action_group_set_sensitive>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_group_set_sensitive"));

		// Token: 0x04000236 RID: 566
		private static ActionGroup.d_gtk_action_group_get_visible gtk_action_group_get_visible = FuncLoader.LoadFunction<ActionGroup.d_gtk_action_group_get_visible>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_group_get_visible"));

		// Token: 0x04000237 RID: 567
		private static ActionGroup.d_gtk_action_group_set_visible gtk_action_group_set_visible = FuncLoader.LoadFunction<ActionGroup.d_gtk_action_group_set_visible>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_group_set_visible"));

		// Token: 0x04000238 RID: 568
		private static ActionGroup.d_gtk_action_group_get_accel_group gtk_action_group_get_accel_group = FuncLoader.LoadFunction<ActionGroup.d_gtk_action_group_get_accel_group>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_group_get_accel_group"));

		// Token: 0x04000239 RID: 569
		private static ActionGroup.d_gtk_action_group_set_accel_group gtk_action_group_set_accel_group = FuncLoader.LoadFunction<ActionGroup.d_gtk_action_group_set_accel_group>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_group_set_accel_group"));

		// Token: 0x0400023A RID: 570
		private static ActionGroup.ConnectProxyNativeDelegate ConnectProxy_cb_delegate;

		// Token: 0x0400023B RID: 571
		private static ActionGroup.DisconnectProxyNativeDelegate DisconnectProxy_cb_delegate;

		// Token: 0x0400023C RID: 572
		private static ActionGroup.PreActivateNativeDelegate PreActivate_cb_delegate;

		// Token: 0x0400023D RID: 573
		private static ActionGroup.PostActivateNativeDelegate PostActivate_cb_delegate;

		// Token: 0x0400023E RID: 574
		private static ActionGroup.GetActionNativeDelegate GetAction_cb_delegate;

		// Token: 0x0400023F RID: 575
		private static AbiStruct _class_abi = null;

		// Token: 0x04000240 RID: 576
		private static ActionGroup.d_gtk_action_group_add_action gtk_action_group_add_action = FuncLoader.LoadFunction<ActionGroup.d_gtk_action_group_add_action>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_group_add_action"));

		// Token: 0x04000241 RID: 577
		private static ActionGroup.d_gtk_action_group_add_action_with_accel gtk_action_group_add_action_with_accel = FuncLoader.LoadFunction<ActionGroup.d_gtk_action_group_add_action_with_accel>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_group_add_action_with_accel"));

		// Token: 0x04000242 RID: 578
		private static ActionGroup.d_gtk_action_group_get_action gtk_action_group_get_action = FuncLoader.LoadFunction<ActionGroup.d_gtk_action_group_get_action>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_group_get_action"));

		// Token: 0x04000243 RID: 579
		private static ActionGroup.d_gtk_action_group_get_type gtk_action_group_get_type = FuncLoader.LoadFunction<ActionGroup.d_gtk_action_group_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_group_get_type"));

		// Token: 0x04000244 RID: 580
		private static ActionGroup.d_gtk_action_group_remove_action gtk_action_group_remove_action = FuncLoader.LoadFunction<ActionGroup.d_gtk_action_group_remove_action>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_group_remove_action"));

		// Token: 0x04000245 RID: 581
		private static ActionGroup.d_gtk_action_group_set_translate_func gtk_action_group_set_translate_func = FuncLoader.LoadFunction<ActionGroup.d_gtk_action_group_set_translate_func>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_group_set_translate_func"));

		// Token: 0x04000246 RID: 582
		private static ActionGroup.d_gtk_action_group_set_translation_domain gtk_action_group_set_translation_domain = FuncLoader.LoadFunction<ActionGroup.d_gtk_action_group_set_translation_domain>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_group_set_translation_domain"));

		// Token: 0x04000247 RID: 583
		private static ActionGroup.d_gtk_action_group_translate_string gtk_action_group_translate_string = FuncLoader.LoadFunction<ActionGroup.d_gtk_action_group_translate_string>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_group_translate_string"));

		// Token: 0x04000248 RID: 584
		private static AbiStruct _abi_info = null;

		// Token: 0x02000677 RID: 1655
		// (Invoke) Token: 0x060040F6 RID: 16630
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_group_list_actions(IntPtr raw);

		// Token: 0x02000678 RID: 1656
		// (Invoke) Token: 0x060040FA RID: 16634
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_group_new(IntPtr name);

		// Token: 0x02000679 RID: 1657
		// (Invoke) Token: 0x060040FE RID: 16638
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_group_get_name(IntPtr raw);

		// Token: 0x0200067A RID: 1658
		// (Invoke) Token: 0x06004102 RID: 16642
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_action_group_get_sensitive(IntPtr raw);

		// Token: 0x0200067B RID: 1659
		// (Invoke) Token: 0x06004106 RID: 16646
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_group_set_sensitive(IntPtr raw, bool sensitive);

		// Token: 0x0200067C RID: 1660
		// (Invoke) Token: 0x0600410A RID: 16650
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_action_group_get_visible(IntPtr raw);

		// Token: 0x0200067D RID: 1661
		// (Invoke) Token: 0x0600410E RID: 16654
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_group_set_visible(IntPtr raw, bool visible);

		// Token: 0x0200067E RID: 1662
		// (Invoke) Token: 0x06004112 RID: 16658
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_group_get_accel_group(IntPtr raw);

		// Token: 0x0200067F RID: 1663
		// (Invoke) Token: 0x06004116 RID: 16662
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_group_set_accel_group(IntPtr raw, IntPtr accel_group);

		// Token: 0x02000680 RID: 1664
		// (Invoke) Token: 0x0600411A RID: 16666
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ConnectProxyNativeDelegate(IntPtr inst, IntPtr action, IntPtr proxy);

		// Token: 0x02000681 RID: 1665
		// (Invoke) Token: 0x0600411E RID: 16670
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DisconnectProxyNativeDelegate(IntPtr inst, IntPtr action, IntPtr proxy);

		// Token: 0x02000682 RID: 1666
		// (Invoke) Token: 0x06004122 RID: 16674
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void PreActivateNativeDelegate(IntPtr inst, IntPtr action);

		// Token: 0x02000683 RID: 1667
		// (Invoke) Token: 0x06004126 RID: 16678
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void PostActivateNativeDelegate(IntPtr inst, IntPtr action);

		// Token: 0x02000684 RID: 1668
		// (Invoke) Token: 0x0600412A RID: 16682
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetActionNativeDelegate(IntPtr inst, IntPtr action_name);

		// Token: 0x02000685 RID: 1669
		// (Invoke) Token: 0x0600412E RID: 16686
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_group_add_action(IntPtr raw, IntPtr action);

		// Token: 0x02000686 RID: 1670
		// (Invoke) Token: 0x06004132 RID: 16690
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_group_add_action_with_accel(IntPtr raw, IntPtr action, IntPtr accelerator);

		// Token: 0x02000687 RID: 1671
		// (Invoke) Token: 0x06004136 RID: 16694
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_group_get_action(IntPtr raw, IntPtr action_name);

		// Token: 0x02000688 RID: 1672
		// (Invoke) Token: 0x0600413A RID: 16698
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_group_get_type();

		// Token: 0x02000689 RID: 1673
		// (Invoke) Token: 0x0600413E RID: 16702
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_group_remove_action(IntPtr raw, IntPtr action);

		// Token: 0x0200068A RID: 1674
		// (Invoke) Token: 0x06004142 RID: 16706
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_group_set_translate_func(IntPtr raw, TranslateFuncNative func, IntPtr data, DestroyNotify notify);

		// Token: 0x0200068B RID: 1675
		// (Invoke) Token: 0x06004146 RID: 16710
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_group_set_translation_domain(IntPtr raw, IntPtr domain);

		// Token: 0x0200068C RID: 1676
		// (Invoke) Token: 0x0600414A RID: 16714
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_group_translate_string(IntPtr raw, IntPtr str1ng);
	}
}
