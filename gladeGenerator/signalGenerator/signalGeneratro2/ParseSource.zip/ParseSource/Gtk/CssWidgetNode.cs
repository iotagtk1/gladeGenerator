﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x0200020B RID: 523
	public class CssWidgetNode : Opaque
	{
		// Token: 0x06001230 RID: 4656 RVA: 0x00035063 File Offset: 0x00033263
		public CssWidgetNode(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000466 RID: 1126
		// (get) Token: 0x06001231 RID: 4657 RVA: 0x0003506C File Offset: 0x0003326C
		public static AbiStruct abi_info
		{
			get
			{
				if (CssWidgetNode._abi_info == null)
				{
					CssWidgetNode._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssWidgetNode._abi_info;
			}
		}

		// Token: 0x04000891 RID: 2193
		private static AbiStruct _abi_info;
	}
}
