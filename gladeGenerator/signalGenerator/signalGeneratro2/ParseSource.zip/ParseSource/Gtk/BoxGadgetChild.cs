﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x0200014A RID: 330
	public class BoxGadgetChild : Opaque
	{
		// Token: 0x06000E26 RID: 3622 RVA: 0x0002AA3E File Offset: 0x00028C3E
		public BoxGadgetChild(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000317 RID: 791
		// (get) Token: 0x06000E27 RID: 3623 RVA: 0x0002AA47 File Offset: 0x00028C47
		public static AbiStruct abi_info
		{
			get
			{
				if (BoxGadgetChild._abi_info == null)
				{
					BoxGadgetChild._abi_info = new AbiStruct(new List<AbiField>());
				}
				return BoxGadgetChild._abi_info;
			}
		}

		// Token: 0x040006F5 RID: 1781
		private static AbiStruct _abi_info;
	}
}
