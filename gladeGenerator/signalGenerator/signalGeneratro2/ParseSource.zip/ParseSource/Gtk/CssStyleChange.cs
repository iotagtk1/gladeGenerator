﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x02000201 RID: 513
	public class CssStyleChange : Opaque
	{
		// Token: 0x0600121C RID: 4636 RVA: 0x00034EE7 File Offset: 0x000330E7
		public CssStyleChange(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700045C RID: 1116
		// (get) Token: 0x0600121D RID: 4637 RVA: 0x00034EF0 File Offset: 0x000330F0
		public static AbiStruct abi_info
		{
			get
			{
				if (CssStyleChange._abi_info == null)
				{
					CssStyleChange._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssStyleChange._abi_info;
			}
		}

		// Token: 0x04000887 RID: 2183
		private static AbiStruct _abi_info;
	}
}
