﻿using System;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x02000163 RID: 355
	public class CancelArgs : SignalArgs
	{
		// Token: 0x1700032D RID: 813
		// (get) Token: 0x06000E72 RID: 3698 RVA: 0x0002B18D File Offset: 0x0002938D
		public EventSequence Sequence
		{
			get
			{
				return (EventSequence)base.Args[0];
			}
		}
	}
}
