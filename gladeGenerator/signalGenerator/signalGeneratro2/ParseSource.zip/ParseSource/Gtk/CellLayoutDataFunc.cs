﻿using System;

namespace Gtk
{
	// Token: 0x0200016E RID: 366
	// (Invoke) Token: 0x06000F69 RID: 3945
	public delegate void CellLayoutDataFunc(ICellLayout cell_layout, CellRenderer cell, ITreeModel tree_model, TreeIter iter);
}
