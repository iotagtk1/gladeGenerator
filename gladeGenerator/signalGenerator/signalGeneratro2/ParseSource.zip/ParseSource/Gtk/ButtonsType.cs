﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x0200015A RID: 346
	[GType(typeof(ButtonsTypeGType))]
	public enum ButtonsType
	{
		// Token: 0x04000721 RID: 1825
		None,
		// Token: 0x04000722 RID: 1826
		Ok,
		// Token: 0x04000723 RID: 1827
		Close,
		// Token: 0x04000724 RID: 1828
		Cancel,
		// Token: 0x04000725 RID: 1829
		YesNo,
		// Token: 0x04000726 RID: 1830
		OkCancel
	}
}
