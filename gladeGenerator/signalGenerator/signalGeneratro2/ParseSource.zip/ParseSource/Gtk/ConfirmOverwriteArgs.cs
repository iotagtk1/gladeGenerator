﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x020001AF RID: 431
	public class ConfirmOverwriteArgs : SignalArgs
	{
	}
}
