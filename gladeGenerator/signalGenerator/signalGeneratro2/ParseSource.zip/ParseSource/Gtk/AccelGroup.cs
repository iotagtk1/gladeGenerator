﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Gdk;
using GLib;
using GtkSharp;

namespace Gtk
{
	// Token: 0x020000FB RID: 251
	public class AccelGroup : Object
	{
		// Token: 0x06000B2D RID: 2861 RVA: 0x00021B6A File Offset: 0x0001FD6A
		public AccelGroup(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000B2E RID: 2862 RVA: 0x00021B74 File Offset: 0x0001FD74
		public AccelGroup() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(AccelGroup))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = AccelGroup.gtk_accel_group_new();
		}

		// Token: 0x1700024F RID: 591
		// (get) Token: 0x06000B2F RID: 2863 RVA: 0x00021BC6 File Offset: 0x0001FDC6
		[Property("is-locked")]
		public bool IsLocked
		{
			get
			{
				return AccelGroup.gtk_accel_group_get_is_locked(base.Handle);
			}
		}

		// Token: 0x17000250 RID: 592
		// (get) Token: 0x06000B30 RID: 2864 RVA: 0x00021BD8 File Offset: 0x0001FDD8
		[Property("modifier-mask")]
		public ModifierType ModifierMask
		{
			get
			{
				return (ModifierType)AccelGroup.gtk_accel_group_get_modifier_mask(base.Handle);
			}
		}

		// Token: 0x1400004B RID: 75
		// (add) Token: 0x06000B31 RID: 2865 RVA: 0x00021BEA File Offset: 0x0001FDEA
		// (remove) Token: 0x06000B32 RID: 2866 RVA: 0x00021C02 File Offset: 0x0001FE02
		[Signal("accel-activate")]
		public event AccelActivateHandler AccelActivate
		{
			add
			{
				base.AddSignalHandler("accel-activate", value, typeof(AccelActivateArgs));
			}
			remove
			{
				base.RemoveSignalHandler("accel-activate", value);
			}
		}

		// Token: 0x1400004C RID: 76
		// (add) Token: 0x06000B33 RID: 2867 RVA: 0x00021C10 File Offset: 0x0001FE10
		// (remove) Token: 0x06000B34 RID: 2868 RVA: 0x00021C28 File Offset: 0x0001FE28
		[Signal("accel-changed")]
		public event AccelChangedHandler AccelChanged
		{
			add
			{
				base.AddSignalHandler("accel-changed", value, typeof(AccelChangedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("accel-changed", value);
			}
		}

		// Token: 0x17000251 RID: 593
		// (get) Token: 0x06000B35 RID: 2869 RVA: 0x00021C36 File Offset: 0x0001FE36
		private static AccelGroup.AccelActivateNativeDelegate AccelActivateVMCallback
		{
			get
			{
				if (AccelGroup.AccelActivate_cb_delegate == null)
				{
					AccelGroup.AccelActivate_cb_delegate = new AccelGroup.AccelActivateNativeDelegate(AccelGroup.AccelActivate_cb);
				}
				return AccelGroup.AccelActivate_cb_delegate;
			}
		}

		// Token: 0x06000B36 RID: 2870 RVA: 0x00021C55 File Offset: 0x0001FE55
		private static void OverrideAccelActivate(GType gtype)
		{
			AccelGroup.OverrideAccelActivate(gtype, AccelGroup.AccelActivateVMCallback);
		}

		// Token: 0x06000B37 RID: 2871 RVA: 0x00021C62 File Offset: 0x0001FE62
		private static void OverrideAccelActivate(GType gtype, AccelGroup.AccelActivateNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "accel-activate", callback);
		}

		// Token: 0x06000B38 RID: 2872 RVA: 0x00021C70 File Offset: 0x0001FE70
		private static bool AccelActivate_cb(IntPtr inst, IntPtr acceleratable, uint keyval, int modifier)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as AccelGroup).OnAccelActivate(Object.GetObject(acceleratable), keyval, (ModifierType)modifier);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000B39 RID: 2873 RVA: 0x00021CB4 File Offset: 0x0001FEB4
		[DefaultSignalHandler(Type = typeof(AccelGroup), ConnectionMethod = "OverrideAccelActivate")]
		protected virtual bool OnAccelActivate(Object acceleratable, uint keyval, ModifierType modifier)
		{
			return this.InternalAccelActivate(acceleratable, keyval, modifier);
		}

		// Token: 0x06000B3A RID: 2874 RVA: 0x00021CC0 File Offset: 0x0001FEC0
		private bool InternalAccelActivate(Object acceleratable, uint keyval, ModifierType modifier)
		{
			Value val = new Value(GType.Boolean);
			ValueArray valueArray = new ValueArray(4U);
			Value[] array = new Value[4];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(acceleratable);
			valueArray.Append(array[1]);
			array[2] = new Value(keyval);
			valueArray.Append(array[2]);
			array[3] = new Value(modifier);
			valueArray.Append(array[3]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref val);
			foreach (Value value in array)
			{
				value.Dispose();
			}
			bool result = (bool)val;
			val.Dispose();
			return result;
		}

		// Token: 0x17000252 RID: 594
		// (get) Token: 0x06000B3B RID: 2875 RVA: 0x00021D98 File Offset: 0x0001FF98
		private static AccelGroup.AccelChangedNativeDelegate AccelChangedVMCallback
		{
			get
			{
				if (AccelGroup.AccelChanged_cb_delegate == null)
				{
					AccelGroup.AccelChanged_cb_delegate = new AccelGroup.AccelChangedNativeDelegate(AccelGroup.AccelChanged_cb);
				}
				return AccelGroup.AccelChanged_cb_delegate;
			}
		}

		// Token: 0x06000B3C RID: 2876 RVA: 0x00021DB7 File Offset: 0x0001FFB7
		private static void OverrideAccelChanged(GType gtype)
		{
			AccelGroup.OverrideAccelChanged(gtype, AccelGroup.AccelChangedVMCallback);
		}

		// Token: 0x06000B3D RID: 2877 RVA: 0x00021DC4 File Offset: 0x0001FFC4
		private unsafe static void OverrideAccelChanged(GType gtype, AccelGroup.AccelChangedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + AccelGroup.class_abi.GetFieldOffset("accel_changed");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000B3E RID: 2878 RVA: 0x00021DF8 File Offset: 0x0001FFF8
		private static void AccelChanged_cb(IntPtr inst, uint keyval, int modifier, IntPtr accel_closure)
		{
			try
			{
				(Object.GetObject(inst, false) as AccelGroup).OnAccelChanged(keyval, (ModifierType)modifier, accel_closure);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000B3F RID: 2879 RVA: 0x00021E34 File Offset: 0x00020034
		[DefaultSignalHandler(Type = typeof(AccelGroup), ConnectionMethod = "OverrideAccelChanged")]
		protected virtual void OnAccelChanged(uint keyval, ModifierType modifier, IntPtr accel_closure)
		{
			this.InternalAccelChanged(keyval, modifier, accel_closure);
		}

		// Token: 0x06000B40 RID: 2880 RVA: 0x00021E40 File Offset: 0x00020040
		private void InternalAccelChanged(uint keyval, ModifierType modifier, IntPtr accel_closure)
		{
			AccelGroup.AccelChangedNativeDelegate accelChangedNativeDelegate = AccelGroup.class_abi.BaseOverride(base.LookupGType(), "accel_changed");
			if (accelChangedNativeDelegate == null)
			{
				return;
			}
			accelChangedNativeDelegate(base.Handle, keyval, (int)modifier, accel_closure);
		}

		// Token: 0x17000253 RID: 595
		// (get) Token: 0x06000B41 RID: 2881 RVA: 0x00021E78 File Offset: 0x00020078
		public new static AbiStruct class_abi
		{
			get
			{
				if (AccelGroup._class_abi == null)
				{
					AccelGroup._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("accel_changed", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved1", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved1", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "accel_changed", "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return AccelGroup._class_abi;
			}
		}

		// Token: 0x06000B42 RID: 2882 RVA: 0x00021FCF File Offset: 0x000201CF
		public bool Activate(int accel_quark, Object acceleratable, uint accel_key, ModifierType accel_mods)
		{
			return AccelGroup.gtk_accel_group_activate(base.Handle, accel_quark, (acceleratable == null) ? IntPtr.Zero : acceleratable.Handle, accel_key, (int)accel_mods);
		}

		// Token: 0x06000B43 RID: 2883 RVA: 0x00021FF5 File Offset: 0x000201F5
		public void Connect(uint accel_key, ModifierType accel_mods, AccelFlags accel_flags, IntPtr closure)
		{
			AccelGroup.gtk_accel_group_connect(base.Handle, accel_key, (int)accel_mods, (int)accel_flags, closure);
		}

		// Token: 0x06000B44 RID: 2884 RVA: 0x0002200C File Offset: 0x0002020C
		public void ConnectByPath(string accel_path, IntPtr closure)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(accel_path);
			AccelGroup.gtk_accel_group_connect_by_path(base.Handle, intPtr, closure);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000B45 RID: 2885 RVA: 0x00022038 File Offset: 0x00020238
		public bool Disconnect(IntPtr closure)
		{
			return AccelGroup.gtk_accel_group_disconnect(base.Handle, closure);
		}

		// Token: 0x06000B46 RID: 2886 RVA: 0x0002204B File Offset: 0x0002024B
		public bool DisconnectKey(uint accel_key, ModifierType accel_mods)
		{
			return AccelGroup.gtk_accel_group_disconnect_key(base.Handle, accel_key, (int)accel_mods);
		}

		// Token: 0x06000B47 RID: 2887 RVA: 0x00022060 File Offset: 0x00020260
		public AccelKey Find(AccelGroupFindFunc find_func)
		{
			AccelGroupFindFuncWrapper accelGroupFindFuncWrapper = new AccelGroupFindFuncWrapper(find_func);
			return AccelKey.New(AccelGroup.gtk_accel_group_find(base.Handle, accelGroupFindFuncWrapper.NativeDelegate, IntPtr.Zero));
		}

		// Token: 0x06000B48 RID: 2888 RVA: 0x00022094 File Offset: 0x00020294
		public static AccelGroup FromAccelClosure(IntPtr closure)
		{
			return Object.GetObject(AccelGroup.gtk_accel_group_from_accel_closure(closure)) as AccelGroup;
		}

		// Token: 0x17000254 RID: 596
		// (get) Token: 0x06000B49 RID: 2889 RVA: 0x000220AC File Offset: 0x000202AC
		public new static GType GType
		{
			get
			{
				IntPtr val = AccelGroup.gtk_accel_group_get_type();
				return new GType(val);
			}
		}

		// Token: 0x06000B4A RID: 2890 RVA: 0x000220CA File Offset: 0x000202CA
		public void Lock()
		{
			AccelGroup.gtk_accel_group_lock(base.Handle);
		}

		// Token: 0x06000B4B RID: 2891 RVA: 0x000220DC File Offset: 0x000202DC
		public AccelGroupEntry Query(uint accel_key, ModifierType accel_mods, out uint n_entries)
		{
			return AccelGroupEntry.New(AccelGroup.gtk_accel_group_query(base.Handle, accel_key, (int)accel_mods, out n_entries));
		}

		// Token: 0x06000B4C RID: 2892 RVA: 0x000220F6 File Offset: 0x000202F6
		public void Unlock()
		{
			AccelGroup.gtk_accel_group_unlock(base.Handle);
		}

		// Token: 0x17000255 RID: 597
		// (get) Token: 0x06000B4D RID: 2893 RVA: 0x00022108 File Offset: 0x00020308
		public new static AbiStruct abi_info
		{
			get
			{
				if (AccelGroup._abi_info == null)
				{
					AccelGroup._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Object.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return AccelGroup._abi_info;
			}
		}

		// Token: 0x04000573 RID: 1395
		private static AccelGroup.d_gtk_accel_group_new gtk_accel_group_new = FuncLoader.LoadFunction<AccelGroup.d_gtk_accel_group_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_group_new"));

		// Token: 0x04000574 RID: 1396
		private static AccelGroup.d_gtk_accel_group_get_is_locked gtk_accel_group_get_is_locked = FuncLoader.LoadFunction<AccelGroup.d_gtk_accel_group_get_is_locked>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_group_get_is_locked"));

		// Token: 0x04000575 RID: 1397
		private static AccelGroup.d_gtk_accel_group_get_modifier_mask gtk_accel_group_get_modifier_mask = FuncLoader.LoadFunction<AccelGroup.d_gtk_accel_group_get_modifier_mask>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_group_get_modifier_mask"));

		// Token: 0x04000576 RID: 1398
		private static AccelGroup.AccelActivateNativeDelegate AccelActivate_cb_delegate;

		// Token: 0x04000577 RID: 1399
		private static AccelGroup.AccelChangedNativeDelegate AccelChanged_cb_delegate;

		// Token: 0x04000578 RID: 1400
		private static AbiStruct _class_abi = null;

		// Token: 0x04000579 RID: 1401
		private static AccelGroup.d_gtk_accel_group_activate gtk_accel_group_activate = FuncLoader.LoadFunction<AccelGroup.d_gtk_accel_group_activate>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_group_activate"));

		// Token: 0x0400057A RID: 1402
		private static AccelGroup.d_gtk_accel_group_connect gtk_accel_group_connect = FuncLoader.LoadFunction<AccelGroup.d_gtk_accel_group_connect>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_group_connect"));

		// Token: 0x0400057B RID: 1403
		private static AccelGroup.d_gtk_accel_group_connect_by_path gtk_accel_group_connect_by_path = FuncLoader.LoadFunction<AccelGroup.d_gtk_accel_group_connect_by_path>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_group_connect_by_path"));

		// Token: 0x0400057C RID: 1404
		private static AccelGroup.d_gtk_accel_group_disconnect gtk_accel_group_disconnect = FuncLoader.LoadFunction<AccelGroup.d_gtk_accel_group_disconnect>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_group_disconnect"));

		// Token: 0x0400057D RID: 1405
		private static AccelGroup.d_gtk_accel_group_disconnect_key gtk_accel_group_disconnect_key = FuncLoader.LoadFunction<AccelGroup.d_gtk_accel_group_disconnect_key>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_group_disconnect_key"));

		// Token: 0x0400057E RID: 1406
		private static AccelGroup.d_gtk_accel_group_find gtk_accel_group_find = FuncLoader.LoadFunction<AccelGroup.d_gtk_accel_group_find>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_group_find"));

		// Token: 0x0400057F RID: 1407
		private static AccelGroup.d_gtk_accel_group_from_accel_closure gtk_accel_group_from_accel_closure = FuncLoader.LoadFunction<AccelGroup.d_gtk_accel_group_from_accel_closure>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_group_from_accel_closure"));

		// Token: 0x04000580 RID: 1408
		private static AccelGroup.d_gtk_accel_group_get_type gtk_accel_group_get_type = FuncLoader.LoadFunction<AccelGroup.d_gtk_accel_group_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_group_get_type"));

		// Token: 0x04000581 RID: 1409
		private static AccelGroup.d_gtk_accel_group_lock gtk_accel_group_lock = FuncLoader.LoadFunction<AccelGroup.d_gtk_accel_group_lock>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_group_lock"));

		// Token: 0x04000582 RID: 1410
		private static AccelGroup.d_gtk_accel_group_query gtk_accel_group_query = FuncLoader.LoadFunction<AccelGroup.d_gtk_accel_group_query>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_group_query"));

		// Token: 0x04000583 RID: 1411
		private static AccelGroup.d_gtk_accel_group_unlock gtk_accel_group_unlock = FuncLoader.LoadFunction<AccelGroup.d_gtk_accel_group_unlock>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_group_unlock"));

		// Token: 0x04000584 RID: 1412
		private static AbiStruct _abi_info = null;

		// Token: 0x02000993 RID: 2451
		// (Invoke) Token: 0x06004D62 RID: 19810
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_accel_group_new();

		// Token: 0x02000994 RID: 2452
		// (Invoke) Token: 0x06004D66 RID: 19814
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_accel_group_get_is_locked(IntPtr raw);

		// Token: 0x02000995 RID: 2453
		// (Invoke) Token: 0x06004D6A RID: 19818
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_accel_group_get_modifier_mask(IntPtr raw);

		// Token: 0x02000996 RID: 2454
		// (Invoke) Token: 0x06004D6E RID: 19822
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool AccelActivateNativeDelegate(IntPtr inst, IntPtr acceleratable, uint keyval, int modifier);

		// Token: 0x02000997 RID: 2455
		// (Invoke) Token: 0x06004D72 RID: 19826
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void AccelChangedNativeDelegate(IntPtr inst, uint keyval, int modifier, IntPtr accel_closure);

		// Token: 0x02000998 RID: 2456
		// (Invoke) Token: 0x06004D76 RID: 19830
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_accel_group_activate(IntPtr raw, int accel_quark, IntPtr acceleratable, uint accel_key, int accel_mods);

		// Token: 0x02000999 RID: 2457
		// (Invoke) Token: 0x06004D7A RID: 19834
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accel_group_connect(IntPtr raw, uint accel_key, int accel_mods, int accel_flags, IntPtr closure);

		// Token: 0x0200099A RID: 2458
		// (Invoke) Token: 0x06004D7E RID: 19838
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accel_group_connect_by_path(IntPtr raw, IntPtr accel_path, IntPtr closure);

		// Token: 0x0200099B RID: 2459
		// (Invoke) Token: 0x06004D82 RID: 19842
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_accel_group_disconnect(IntPtr raw, IntPtr closure);

		// Token: 0x0200099C RID: 2460
		// (Invoke) Token: 0x06004D86 RID: 19846
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_accel_group_disconnect_key(IntPtr raw, uint accel_key, int accel_mods);

		// Token: 0x0200099D RID: 2461
		// (Invoke) Token: 0x06004D8A RID: 19850
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_accel_group_find(IntPtr raw, AccelGroupFindFuncNative find_func, IntPtr data);

		// Token: 0x0200099E RID: 2462
		// (Invoke) Token: 0x06004D8E RID: 19854
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_accel_group_from_accel_closure(IntPtr closure);

		// Token: 0x0200099F RID: 2463
		// (Invoke) Token: 0x06004D92 RID: 19858
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_accel_group_get_type();

		// Token: 0x020009A0 RID: 2464
		// (Invoke) Token: 0x06004D96 RID: 19862
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accel_group_lock(IntPtr raw);

		// Token: 0x020009A1 RID: 2465
		// (Invoke) Token: 0x06004D9A RID: 19866
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_accel_group_query(IntPtr raw, uint accel_key, int accel_mods, out uint n_entries);

		// Token: 0x020009A2 RID: 2466
		// (Invoke) Token: 0x06004D9E RID: 19870
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accel_group_unlock(IntPtr raw);
	}
}
