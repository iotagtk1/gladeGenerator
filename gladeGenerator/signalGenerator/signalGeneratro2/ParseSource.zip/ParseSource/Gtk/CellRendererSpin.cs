﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x02000177 RID: 375
	public class CellRendererSpin : CellRendererText
	{
		// Token: 0x06000FD0 RID: 4048 RVA: 0x0002FE11 File Offset: 0x0002E011
		public CellRendererSpin(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000FD1 RID: 4049 RVA: 0x0002FE1C File Offset: 0x0002E01C
		public CellRendererSpin() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(CellRendererSpin))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = CellRendererSpin.gtk_cell_renderer_spin_new();
		}

		// Token: 0x17000386 RID: 902
		// (get) Token: 0x06000FD2 RID: 4050 RVA: 0x0002FE70 File Offset: 0x0002E070
		// (set) Token: 0x06000FD3 RID: 4051 RVA: 0x0002FE9C File Offset: 0x0002E09C
		[Property("adjustment")]
		public Adjustment Adjustment
		{
			get
			{
				Value property = base.GetProperty("adjustment");
				Adjustment result = (Adjustment)((Object)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("adjustment", val);
				val.Dispose();
			}
		}

		// Token: 0x17000387 RID: 903
		// (get) Token: 0x06000FD4 RID: 4052 RVA: 0x0002FEC4 File Offset: 0x0002E0C4
		// (set) Token: 0x06000FD5 RID: 4053 RVA: 0x0002FEEC File Offset: 0x0002E0EC
		[Property("climb-rate")]
		public double ClimbRate
		{
			get
			{
				Value property = base.GetProperty("climb-rate");
				double result = (double)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("climb-rate", val);
				val.Dispose();
			}
		}

		// Token: 0x17000388 RID: 904
		// (get) Token: 0x06000FD6 RID: 4054 RVA: 0x0002FF14 File Offset: 0x0002E114
		// (set) Token: 0x06000FD7 RID: 4055 RVA: 0x0002FF3C File Offset: 0x0002E13C
		[Property("digits")]
		public uint Digits
		{
			get
			{
				Value property = base.GetProperty("digits");
				uint result = (uint)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("digits", val);
				val.Dispose();
			}
		}

		// Token: 0x17000389 RID: 905
		// (get) Token: 0x06000FD8 RID: 4056 RVA: 0x0002FF64 File Offset: 0x0002E164
		public new static AbiStruct class_abi
		{
			get
			{
				if (CellRendererSpin._class_abi == null)
				{
					CellRendererSpin._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("_gtk_reserved1", CellRendererText.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellRendererSpin._class_abi;
			}
		}

		// Token: 0x1700038A RID: 906
		// (get) Token: 0x06000FD9 RID: 4057 RVA: 0x00030080 File Offset: 0x0002E280
		public new static GType GType
		{
			get
			{
				IntPtr val = CellRendererSpin.gtk_cell_renderer_spin_get_type();
				return new GType(val);
			}
		}

		// Token: 0x1700038B RID: 907
		// (get) Token: 0x06000FDA RID: 4058 RVA: 0x000300A0 File Offset: 0x0002E2A0
		public new static AbiStruct abi_info
		{
			get
			{
				if (CellRendererSpin._abi_info == null)
				{
					CellRendererSpin._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", CellRendererText.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellRendererSpin._abi_info;
			}
		}

		// Token: 0x040007AB RID: 1963
		private static CellRendererSpin.d_gtk_cell_renderer_spin_new gtk_cell_renderer_spin_new = FuncLoader.LoadFunction<CellRendererSpin.d_gtk_cell_renderer_spin_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_spin_new"));

		// Token: 0x040007AC RID: 1964
		private static AbiStruct _class_abi = null;

		// Token: 0x040007AD RID: 1965
		private static CellRendererSpin.d_gtk_cell_renderer_spin_get_type gtk_cell_renderer_spin_get_type = FuncLoader.LoadFunction<CellRendererSpin.d_gtk_cell_renderer_spin_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_spin_get_type"));

		// Token: 0x040007AE RID: 1966
		private static AbiStruct _abi_info = null;

		// Token: 0x02000B23 RID: 2851
		// (Invoke) Token: 0x06005399 RID: 21401
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_renderer_spin_new();

		// Token: 0x02000B24 RID: 2852
		// (Invoke) Token: 0x0600539D RID: 21405
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_renderer_spin_get_type();
	}
}
