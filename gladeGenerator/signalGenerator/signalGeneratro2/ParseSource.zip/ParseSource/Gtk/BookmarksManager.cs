﻿using System;
using System.Runtime.InteropServices;
using GLib;
using GtkSharp;

namespace Gtk
{
	// Token: 0x02000142 RID: 322
	public struct BookmarksManager : IEquatable<BookmarksManager>
	{
		// Token: 0x17000301 RID: 769
		// (get) Token: 0x06000DEA RID: 3562 RVA: 0x00029EFD File Offset: 0x000280FD
		// (set) Token: 0x06000DEB RID: 3563 RVA: 0x00029F0F File Offset: 0x0002810F
		public FileMonitor BookmarksMonitor
		{
			get
			{
				return Object.GetObject(this._bookmarks_monitor) as FileMonitor;
			}
			set
			{
				this._bookmarks_monitor = ((value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x17000302 RID: 770
		// (get) Token: 0x06000DEC RID: 3564 RVA: 0x00029F27 File Offset: 0x00028127
		// (set) Token: 0x06000DED RID: 3565 RVA: 0x00029F34 File Offset: 0x00028134
		public ulong BookmarksMonitorChangedId
		{
			get
			{
				return (ulong)this.bookmarks_monitor_changed_id;
			}
			set
			{
				this.bookmarks_monitor_changed_id = new UIntPtr(value);
			}
		}

		// Token: 0x17000303 RID: 771
		// (get) Token: 0x06000DEE RID: 3566 RVA: 0x00029F42 File Offset: 0x00028142
		public BookmarksChangedFunc ChangedFunc
		{
			get
			{
				return BookmarksChangedFuncWrapper.GetManagedDelegate(this._changed_func);
			}
		}

		// Token: 0x06000DEF RID: 3567 RVA: 0x00029F4F File Offset: 0x0002814F
		public static BookmarksManager New(IntPtr raw)
		{
			if (raw == IntPtr.Zero)
			{
				return BookmarksManager.Zero;
			}
			return (BookmarksManager)Marshal.PtrToStructure(raw, typeof(BookmarksManager));
		}

		// Token: 0x06000DF0 RID: 3568 RVA: 0x00029F7C File Offset: 0x0002817C
		public bool Equals(BookmarksManager other)
		{
			return this._bookmarks.Equals(other._bookmarks) && this.BookmarksMonitor.Equals(other.BookmarksMonitor) && this.BookmarksMonitorChangedId.Equals(other.BookmarksMonitorChangedId) && this._changed_func_data.Equals(other._changed_func_data) && this.ChangedFunc.Equals(other.ChangedFunc);
		}

		// Token: 0x06000DF1 RID: 3569 RVA: 0x00029FF8 File Offset: 0x000281F8
		public override bool Equals(object other)
		{
			return other is BookmarksManager && this.Equals((BookmarksManager)other);
		}

		// Token: 0x06000DF2 RID: 3570 RVA: 0x0002A010 File Offset: 0x00028210
		public override int GetHashCode()
		{
			return base.GetType().FullName.GetHashCode() ^ this._bookmarks.GetHashCode() ^ this.BookmarksMonitor.GetHashCode() ^ this.BookmarksMonitorChangedId.GetHashCode() ^ this._changed_func_data.GetHashCode() ^ this.ChangedFunc.GetHashCode();
		}

		// Token: 0x17000304 RID: 772
		// (get) Token: 0x06000DF3 RID: 3571 RVA: 0x0002A076 File Offset: 0x00028276
		private static GType GType
		{
			get
			{
				return GType.Pointer;
			}
		}

		// Token: 0x040006C6 RID: 1734
		private IntPtr _bookmarks;

		// Token: 0x040006C7 RID: 1735
		private IntPtr _bookmarks_monitor;

		// Token: 0x040006C8 RID: 1736
		private UIntPtr bookmarks_monitor_changed_id;

		// Token: 0x040006C9 RID: 1737
		private IntPtr _changed_func_data;

		// Token: 0x040006CA RID: 1738
		private BookmarksChangedFuncNative _changed_func;

		// Token: 0x040006CB RID: 1739
		public static BookmarksManager Zero;
	}
}
