﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x0200019B RID: 411
	public class ColorChooserDialog : Dialog, IColorChooser, IWrapper
	{
		// Token: 0x060010F1 RID: 4337 RVA: 0x00032ACC File Offset: 0x00030CCC
		public ColorChooserDialog(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x060010F2 RID: 4338 RVA: 0x00032AD8 File Offset: 0x00030CD8
		public ColorChooserDialog(string title, Window parent) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(ColorChooserDialog))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				list2.Add("title");
				list.Add(new Value(title));
				if (parent != null)
				{
					list2.Add("parent");
					list.Add(new Value(parent));
				}
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(title);
			this.Raw = ColorChooserDialog.gtk_color_chooser_dialog_new(intPtr, (parent == null) ? IntPtr.Zero : parent.Handle);
			Marshaller.Free(intPtr);
		}

		// Token: 0x170003E6 RID: 998
		// (get) Token: 0x060010F3 RID: 4339 RVA: 0x00032B88 File Offset: 0x00030D88
		// (set) Token: 0x060010F4 RID: 4340 RVA: 0x00032BB0 File Offset: 0x00030DB0
		[Property("show-editor")]
		public bool ShowEditor
		{
			get
			{
				Value property = base.GetProperty("show-editor");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("show-editor", val);
				val.Dispose();
			}
		}

		// Token: 0x170003E7 RID: 999
		// (get) Token: 0x060010F5 RID: 4341 RVA: 0x00032BD8 File Offset: 0x00030DD8
		public new static AbiStruct class_abi
		{
			get
			{
				if (ColorChooserDialog._class_abi == null)
				{
					ColorChooserDialog._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("_gtk_reserved1", Dialog.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return ColorChooserDialog._class_abi;
			}
		}

		// Token: 0x170003E8 RID: 1000
		// (get) Token: 0x060010F6 RID: 4342 RVA: 0x00032CF4 File Offset: 0x00030EF4
		public new static GType GType
		{
			get
			{
				IntPtr val = ColorChooserDialog.gtk_color_chooser_dialog_get_type();
				return new GType(val);
			}
		}

		// Token: 0x060010F7 RID: 4343 RVA: 0x00032D14 File Offset: 0x00030F14
		public void AddPalette(Orientation orientation, int colors_per_line, int n_colors, RGBA colors)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(colors);
			ColorChooserDialog.gtk_color_chooser_add_palette(base.Handle, (int)orientation, colors_per_line, n_colors, intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x170003E9 RID: 1001
		// (get) Token: 0x060010F8 RID: 4344 RVA: 0x00032D48 File Offset: 0x00030F48
		// (set) Token: 0x060010F9 RID: 4345 RVA: 0x00032D88 File Offset: 0x00030F88
		[Property("rgba")]
		public RGBA Rgba
		{
			get
			{
				IntPtr intPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(RGBA)));
				ColorChooserDialog.gtk_color_chooser_get_rgba(base.Handle, intPtr);
				RGBA result = RGBA.New(intPtr);
				Marshal.FreeHGlobal(intPtr);
				return result;
			}
			set
			{
				IntPtr intPtr = Marshaller.StructureToPtrAlloc(value);
				ColorChooserDialog.gtk_color_chooser_set_rgba(base.Handle, intPtr);
				Marshal.FreeHGlobal(intPtr);
			}
		}

		// Token: 0x170003EA RID: 1002
		// (get) Token: 0x060010FA RID: 4346 RVA: 0x00032DB8 File Offset: 0x00030FB8
		// (set) Token: 0x060010FB RID: 4347 RVA: 0x00032DCA File Offset: 0x00030FCA
		[Property("use-alpha")]
		public bool UseAlpha
		{
			get
			{
				return ColorChooserDialog.gtk_color_chooser_get_use_alpha(base.Handle);
			}
			set
			{
				ColorChooserDialog.gtk_color_chooser_set_use_alpha(base.Handle, value);
			}
		}

		// Token: 0x1400006A RID: 106
		// (add) Token: 0x060010FC RID: 4348 RVA: 0x00032DDD File Offset: 0x00030FDD
		// (remove) Token: 0x060010FD RID: 4349 RVA: 0x00032DF5 File Offset: 0x00030FF5
		[Signal("color-activated")]
		public event ColorActivatedHandler ColorActivated
		{
			add
			{
				base.AddSignalHandler("color-activated", value, typeof(ColorActivatedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("color-activated", value);
			}
		}

		// Token: 0x170003EB RID: 1003
		// (get) Token: 0x060010FE RID: 4350 RVA: 0x00032E03 File Offset: 0x00031003
		private static ColorChooserDialog.ColorActivatedNativeDelegate ColorActivatedVMCallback
		{
			get
			{
				if (ColorChooserDialog.ColorActivated_cb_delegate == null)
				{
					ColorChooserDialog.ColorActivated_cb_delegate = new ColorChooserDialog.ColorActivatedNativeDelegate(ColorChooserDialog.ColorActivated_cb);
				}
				return ColorChooserDialog.ColorActivated_cb_delegate;
			}
		}

		// Token: 0x060010FF RID: 4351 RVA: 0x00032E22 File Offset: 0x00031022
		private static void OverrideColorActivated(GType gtype)
		{
			ColorChooserDialog.OverrideColorActivated(gtype, ColorChooserDialog.ColorActivatedVMCallback);
		}

		// Token: 0x06001100 RID: 4352 RVA: 0x00032E2F File Offset: 0x0003102F
		private static void OverrideColorActivated(GType gtype, ColorChooserDialog.ColorActivatedNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "color-activated", callback);
		}

		// Token: 0x06001101 RID: 4353 RVA: 0x00032E40 File Offset: 0x00031040
		private static void ColorActivated_cb(IntPtr inst, IntPtr color)
		{
			try
			{
				(Object.GetObject(inst, false) as ColorChooserDialog).OnColorActivated(RGBA.New(color));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06001102 RID: 4354 RVA: 0x00032E80 File Offset: 0x00031080
		[DefaultSignalHandler(Type = typeof(ColorChooserDialog), ConnectionMethod = "OverrideColorActivated")]
		protected virtual void OnColorActivated(RGBA color)
		{
			this.InternalColorActivated(color);
		}

		// Token: 0x06001103 RID: 4355 RVA: 0x00032E8C File Offset: 0x0003108C
		private void InternalColorActivated(RGBA color)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(2U);
			Value[] array = new Value[2];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(color);
			valueArray.Append(array[1]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x170003EC RID: 1004
		// (get) Token: 0x06001104 RID: 4356 RVA: 0x00032F20 File Offset: 0x00031120
		public new static AbiStruct abi_info
		{
			get
			{
				if (ColorChooserDialog._abi_info == null)
				{
					ColorChooserDialog._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Dialog.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return ColorChooserDialog._abi_info;
			}
		}

		// Token: 0x040007F3 RID: 2035
		private static ColorChooserDialog.d_gtk_color_chooser_dialog_new gtk_color_chooser_dialog_new = FuncLoader.LoadFunction<ColorChooserDialog.d_gtk_color_chooser_dialog_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_dialog_new"));

		// Token: 0x040007F4 RID: 2036
		private static AbiStruct _class_abi = null;

		// Token: 0x040007F5 RID: 2037
		private static ColorChooserDialog.d_gtk_color_chooser_dialog_get_type gtk_color_chooser_dialog_get_type = FuncLoader.LoadFunction<ColorChooserDialog.d_gtk_color_chooser_dialog_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_dialog_get_type"));

		// Token: 0x040007F6 RID: 2038
		private static ColorChooserDialog.d_gtk_color_chooser_add_palette gtk_color_chooser_add_palette = FuncLoader.LoadFunction<ColorChooserDialog.d_gtk_color_chooser_add_palette>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_add_palette"));

		// Token: 0x040007F7 RID: 2039
		private static ColorChooserDialog.d_gtk_color_chooser_get_rgba gtk_color_chooser_get_rgba = FuncLoader.LoadFunction<ColorChooserDialog.d_gtk_color_chooser_get_rgba>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_get_rgba"));

		// Token: 0x040007F8 RID: 2040
		private static ColorChooserDialog.d_gtk_color_chooser_set_rgba gtk_color_chooser_set_rgba = FuncLoader.LoadFunction<ColorChooserDialog.d_gtk_color_chooser_set_rgba>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_set_rgba"));

		// Token: 0x040007F9 RID: 2041
		private static ColorChooserDialog.d_gtk_color_chooser_get_use_alpha gtk_color_chooser_get_use_alpha = FuncLoader.LoadFunction<ColorChooserDialog.d_gtk_color_chooser_get_use_alpha>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_get_use_alpha"));

		// Token: 0x040007FA RID: 2042
		private static ColorChooserDialog.d_gtk_color_chooser_set_use_alpha gtk_color_chooser_set_use_alpha = FuncLoader.LoadFunction<ColorChooserDialog.d_gtk_color_chooser_set_use_alpha>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_set_use_alpha"));

		// Token: 0x040007FB RID: 2043
		private static ColorChooserDialog.ColorActivatedNativeDelegate ColorActivated_cb_delegate;

		// Token: 0x040007FC RID: 2044
		private static AbiStruct _abi_info = null;

		// Token: 0x02000B53 RID: 2899
		// (Invoke) Token: 0x06005455 RID: 21589
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_color_chooser_dialog_new(IntPtr title, IntPtr parent);

		// Token: 0x02000B54 RID: 2900
		// (Invoke) Token: 0x06005459 RID: 21593
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_color_chooser_dialog_get_type();

		// Token: 0x02000B55 RID: 2901
		// (Invoke) Token: 0x0600545D RID: 21597
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_chooser_add_palette(IntPtr raw, int orientation, int colors_per_line, int n_colors, IntPtr colors);

		// Token: 0x02000B56 RID: 2902
		// (Invoke) Token: 0x06005461 RID: 21601
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_chooser_get_rgba(IntPtr raw, IntPtr color);

		// Token: 0x02000B57 RID: 2903
		// (Invoke) Token: 0x06005465 RID: 21605
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_chooser_set_rgba(IntPtr raw, IntPtr value);

		// Token: 0x02000B58 RID: 2904
		// (Invoke) Token: 0x06005469 RID: 21609
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_color_chooser_get_use_alpha(IntPtr raw);

		// Token: 0x02000B59 RID: 2905
		// (Invoke) Token: 0x0600546D RID: 21613
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_chooser_set_use_alpha(IntPtr raw, bool use_alpha);

		// Token: 0x02000B5A RID: 2906
		// (Invoke) Token: 0x06005471 RID: 21617
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ColorActivatedNativeDelegate(IntPtr inst, IntPtr color);
	}
}
