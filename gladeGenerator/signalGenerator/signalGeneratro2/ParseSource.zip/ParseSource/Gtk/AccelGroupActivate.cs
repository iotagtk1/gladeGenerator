﻿using System;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x020000FC RID: 252
	// (Invoke) Token: 0x06000B50 RID: 2896
	public delegate bool AccelGroupActivate(AccelGroup accel_group, Object acceleratable, uint keyval, ModifierType modifier);
}
