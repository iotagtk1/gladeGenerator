﻿using System;

namespace Gtk
{
	// Token: 0x0200021A RID: 538
	// (Invoke) Token: 0x0600125E RID: 4702
	public delegate void DamageEventHandler(object o, DamageEventArgs args);
}
