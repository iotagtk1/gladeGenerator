﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000170 RID: 368
	[GType(typeof(CellRendererAccelModeGType))]
	public enum CellRendererAccelMode
	{
		// Token: 0x04000794 RID: 1940
		Gtk,
		// Token: 0x04000795 RID: 1941
		Other
	}
}
