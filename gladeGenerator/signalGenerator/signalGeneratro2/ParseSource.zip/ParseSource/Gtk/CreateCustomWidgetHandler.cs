﻿using System;

namespace Gtk
{
	// Token: 0x020001B7 RID: 439
	// (Invoke) Token: 0x06001164 RID: 4452
	public delegate void CreateCustomWidgetHandler(object o, CreateCustomWidgetArgs args);
}
