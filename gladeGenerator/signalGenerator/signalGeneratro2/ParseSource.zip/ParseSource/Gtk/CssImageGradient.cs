﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001CF RID: 463
	public class CssImageGradient : Opaque
	{
		// Token: 0x06001199 RID: 4505 RVA: 0x00033EDF File Offset: 0x000320DF
		public CssImageGradient(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000420 RID: 1056
		// (get) Token: 0x0600119A RID: 4506 RVA: 0x00033EE8 File Offset: 0x000320E8
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImageGradient._abi_info == null)
				{
					CssImageGradient._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImageGradient._abi_info;
			}
		}

		// Token: 0x0400082F RID: 2095
		private static AbiStruct _abi_info;
	}
}
