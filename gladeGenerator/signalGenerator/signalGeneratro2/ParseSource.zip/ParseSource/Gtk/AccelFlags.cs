﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x020000F9 RID: 249
	[Flags]
	[GType(typeof(AccelFlagsGType))]
	public enum AccelFlags
	{
		// Token: 0x0400056F RID: 1391
		Visible = 1,
		// Token: 0x04000570 RID: 1392
		Locked = 2,
		// Token: 0x04000571 RID: 1393
		Mask = 7
	}
}
