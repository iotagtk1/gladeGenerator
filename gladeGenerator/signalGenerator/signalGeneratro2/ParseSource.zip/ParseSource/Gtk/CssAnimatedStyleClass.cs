﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001BE RID: 446
	public class CssAnimatedStyleClass : Opaque
	{
		// Token: 0x06001177 RID: 4471 RVA: 0x00033C59 File Offset: 0x00031E59
		public CssAnimatedStyleClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700040F RID: 1039
		// (get) Token: 0x06001178 RID: 4472 RVA: 0x00033C62 File Offset: 0x00031E62
		public static AbiStruct abi_info
		{
			get
			{
				if (CssAnimatedStyleClass._abi_info == null)
				{
					CssAnimatedStyleClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssAnimatedStyleClass._abi_info;
			}
		}

		// Token: 0x0400081E RID: 2078
		private static AbiStruct _abi_info;
	}
}
