﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x02000206 RID: 518
	public class CssTransientNodeClass : Opaque
	{
		// Token: 0x06001226 RID: 4646 RVA: 0x00034FA5 File Offset: 0x000331A5
		public CssTransientNodeClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000461 RID: 1121
		// (get) Token: 0x06001227 RID: 4647 RVA: 0x00034FAE File Offset: 0x000331AE
		public static AbiStruct abi_info
		{
			get
			{
				if (CssTransientNodeClass._abi_info == null)
				{
					CssTransientNodeClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssTransientNodeClass._abi_info;
			}
		}

		// Token: 0x0400088C RID: 2188
		private static AbiStruct _abi_info;
	}
}
