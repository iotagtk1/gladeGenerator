﻿using System;

namespace Gtk
{
	// Token: 0x0200013C RID: 316
	// (Invoke) Token: 0x06000DD4 RID: 3540
	public delegate void BeginPrintHandler(object o, BeginPrintArgs args);
}
