﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001C3 RID: 451
	public class CssCustomProperty : Opaque
	{
		// Token: 0x06001181 RID: 4481 RVA: 0x00033D17 File Offset: 0x00031F17
		public CssCustomProperty(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000414 RID: 1044
		// (get) Token: 0x06001182 RID: 4482 RVA: 0x00033D20 File Offset: 0x00031F20
		public static AbiStruct abi_info
		{
			get
			{
				if (CssCustomProperty._abi_info == null)
				{
					CssCustomProperty._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssCustomProperty._abi_info;
			}
		}

		// Token: 0x04000823 RID: 2083
		private static AbiStruct _abi_info;
	}
}
