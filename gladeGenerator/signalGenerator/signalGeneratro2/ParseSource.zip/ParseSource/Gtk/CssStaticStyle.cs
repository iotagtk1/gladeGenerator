﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001FE RID: 510
	public class CssStaticStyle : Opaque
	{
		// Token: 0x06001216 RID: 4630 RVA: 0x00034E75 File Offset: 0x00033075
		public CssStaticStyle(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000459 RID: 1113
		// (get) Token: 0x06001217 RID: 4631 RVA: 0x00034E7E File Offset: 0x0003307E
		public static AbiStruct abi_info
		{
			get
			{
				if (CssStaticStyle._abi_info == null)
				{
					CssStaticStyle._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssStaticStyle._abi_info;
			}
		}

		// Token: 0x04000884 RID: 2180
		private static AbiStruct _abi_info;
	}
}
