﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001D6 RID: 470
	public class CssImageRadial : Opaque
	{
		// Token: 0x060011A7 RID: 4519 RVA: 0x00033FE9 File Offset: 0x000321E9
		public CssImageRadial(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000427 RID: 1063
		// (get) Token: 0x060011A8 RID: 4520 RVA: 0x00033FF2 File Offset: 0x000321F2
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImageRadial._abi_info == null)
				{
					CssImageRadial._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImageRadial._abi_info;
			}
		}

		// Token: 0x04000836 RID: 2102
		private static AbiStruct _abi_info;
	}
}
