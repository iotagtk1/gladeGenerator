﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x02000174 RID: 372
	internal class CellRendererModeGType
	{
		// Token: 0x1700036F RID: 879
		// (get) Token: 0x06000FA1 RID: 4001 RVA: 0x0002F427 File Offset: 0x0002D627
		public static GType GType
		{
			get
			{
				return new GType(CellRendererModeGType.gtk_cell_renderer_mode_get_type());
			}
		}

		// Token: 0x040007A0 RID: 1952
		private static CellRendererModeGType.d_gtk_cell_renderer_mode_get_type gtk_cell_renderer_mode_get_type = FuncLoader.LoadFunction<CellRendererModeGType.d_gtk_cell_renderer_mode_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_mode_get_type"));

		// Token: 0x02000B1C RID: 2844
		// (Invoke) Token: 0x0600537D RID: 21373
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_renderer_mode_get_type();
	}
}
