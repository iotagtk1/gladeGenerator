﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001D9 RID: 473
	public class CssImageRecolor : Opaque
	{
		// Token: 0x060011AD RID: 4525 RVA: 0x0003405B File Offset: 0x0003225B
		public CssImageRecolor(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700042A RID: 1066
		// (get) Token: 0x060011AE RID: 4526 RVA: 0x00034064 File Offset: 0x00032264
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImageRecolor._abi_info == null)
				{
					CssImageRecolor._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImageRecolor._abi_info;
			}
		}

		// Token: 0x04000839 RID: 2105
		private static AbiStruct _abi_info;
	}
}
