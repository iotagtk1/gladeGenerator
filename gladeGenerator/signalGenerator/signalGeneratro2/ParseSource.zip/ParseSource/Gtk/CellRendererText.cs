﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Gdk;
using GLib;
using Pango;

namespace Gtk
{
	// Token: 0x0200017B RID: 379
	public class CellRendererText : CellRenderer
	{
		// Token: 0x06000FEB RID: 4075 RVA: 0x000304D1 File Offset: 0x0002E6D1
		public CellRendererText(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000FEC RID: 4076 RVA: 0x000304DC File Offset: 0x0002E6DC
		public CellRendererText() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(CellRendererText))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = CellRendererText.gtk_cell_renderer_text_new();
		}

		// Token: 0x17000393 RID: 915
		// (get) Token: 0x06000FED RID: 4077 RVA: 0x00030530 File Offset: 0x0002E730
		// (set) Token: 0x06000FEE RID: 4078 RVA: 0x00030558 File Offset: 0x0002E758
		[Property("text")]
		public string Text
		{
			get
			{
				Value property = base.GetProperty("text");
				string result = (string)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("text", val);
				val.Dispose();
			}
		}

		// Token: 0x17000394 RID: 916
		// (set) Token: 0x06000FEF RID: 4079 RVA: 0x00030580 File Offset: 0x0002E780
		[Property("markup")]
		public string Markup
		{
			set
			{
				Value val = new Value(value);
				base.SetProperty("markup", val);
				val.Dispose();
			}
		}

		// Token: 0x17000395 RID: 917
		// (get) Token: 0x06000FF0 RID: 4080 RVA: 0x000305A8 File Offset: 0x0002E7A8
		// (set) Token: 0x06000FF1 RID: 4081 RVA: 0x000305D4 File Offset: 0x0002E7D4
		[Property("attributes")]
		public AttrList Attributes
		{
			get
			{
				Value property = base.GetProperty("attributes");
				AttrList result = (AttrList)((Opaque)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value, "PangoAttrList");
				base.SetProperty("attributes", val);
				val.Dispose();
			}
		}

		// Token: 0x17000396 RID: 918
		// (get) Token: 0x06000FF2 RID: 4082 RVA: 0x00030604 File Offset: 0x0002E804
		// (set) Token: 0x06000FF3 RID: 4083 RVA: 0x0003062C File Offset: 0x0002E82C
		[Property("single-paragraph-mode")]
		public bool SingleParagraphMode
		{
			get
			{
				Value property = base.GetProperty("single-paragraph-mode");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("single-paragraph-mode", val);
				val.Dispose();
			}
		}

		// Token: 0x17000397 RID: 919
		// (set) Token: 0x06000FF4 RID: 4084 RVA: 0x00030654 File Offset: 0x0002E854
		[Property("background")]
		public string Background
		{
			set
			{
				Value val = new Value(value);
				base.SetProperty("background", val);
				val.Dispose();
			}
		}

		// Token: 0x17000398 RID: 920
		// (get) Token: 0x06000FF5 RID: 4085 RVA: 0x0003067C File Offset: 0x0002E87C
		// (set) Token: 0x06000FF6 RID: 4086 RVA: 0x000306A4 File Offset: 0x0002E8A4
		[Property("background-gdk")]
		public Gdk.Color BackgroundGdk
		{
			get
			{
				Value property = base.GetProperty("background-gdk");
				Gdk.Color result = (Gdk.Color)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = (Value)value;
				base.SetProperty("background-gdk", val);
				val.Dispose();
			}
		}

		// Token: 0x17000399 RID: 921
		// (get) Token: 0x06000FF7 RID: 4087 RVA: 0x000306CC File Offset: 0x0002E8CC
		// (set) Token: 0x06000FF8 RID: 4088 RVA: 0x000306F4 File Offset: 0x0002E8F4
		[Property("background-rgba")]
		public RGBA BackgroundRgba
		{
			get
			{
				Value property = base.GetProperty("background-rgba");
				RGBA result = (RGBA)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("background-rgba", val);
				val.Dispose();
			}
		}

		// Token: 0x1700039A RID: 922
		// (set) Token: 0x06000FF9 RID: 4089 RVA: 0x00030724 File Offset: 0x0002E924
		[Property("foreground")]
		public string Foreground
		{
			set
			{
				Value val = new Value(value);
				base.SetProperty("foreground", val);
				val.Dispose();
			}
		}

		// Token: 0x1700039B RID: 923
		// (get) Token: 0x06000FFA RID: 4090 RVA: 0x0003074C File Offset: 0x0002E94C
		// (set) Token: 0x06000FFB RID: 4091 RVA: 0x00030774 File Offset: 0x0002E974
		[Property("foreground-gdk")]
		public Gdk.Color ForegroundGdk
		{
			get
			{
				Value property = base.GetProperty("foreground-gdk");
				Gdk.Color result = (Gdk.Color)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = (Value)value;
				base.SetProperty("foreground-gdk", val);
				val.Dispose();
			}
		}

		// Token: 0x1700039C RID: 924
		// (get) Token: 0x06000FFC RID: 4092 RVA: 0x0003079C File Offset: 0x0002E99C
		// (set) Token: 0x06000FFD RID: 4093 RVA: 0x000307C4 File Offset: 0x0002E9C4
		[Property("foreground-rgba")]
		public RGBA ForegroundRgba
		{
			get
			{
				Value property = base.GetProperty("foreground-rgba");
				RGBA result = (RGBA)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("foreground-rgba", val);
				val.Dispose();
			}
		}

		// Token: 0x1700039D RID: 925
		// (get) Token: 0x06000FFE RID: 4094 RVA: 0x000307F4 File Offset: 0x0002E9F4
		// (set) Token: 0x06000FFF RID: 4095 RVA: 0x0003081C File Offset: 0x0002EA1C
		[Property("editable")]
		public bool Editable
		{
			get
			{
				Value property = base.GetProperty("editable");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("editable", val);
				val.Dispose();
			}
		}

		// Token: 0x1700039E RID: 926
		// (get) Token: 0x06001000 RID: 4096 RVA: 0x00030844 File Offset: 0x0002EA44
		// (set) Token: 0x06001001 RID: 4097 RVA: 0x0003086C File Offset: 0x0002EA6C
		[Property("font")]
		public string Font
		{
			get
			{
				Value property = base.GetProperty("font");
				string result = (string)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("font", val);
				val.Dispose();
			}
		}

		// Token: 0x1700039F RID: 927
		// (get) Token: 0x06001002 RID: 4098 RVA: 0x00030894 File Offset: 0x0002EA94
		// (set) Token: 0x06001003 RID: 4099 RVA: 0x000308C0 File Offset: 0x0002EAC0
		[Property("font-desc")]
		public FontDescription FontDesc
		{
			get
			{
				Value property = base.GetProperty("font-desc");
				FontDescription result = (FontDescription)((Opaque)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value, "PangoFontDescription");
				base.SetProperty("font-desc", val);
				val.Dispose();
			}
		}

		// Token: 0x170003A0 RID: 928
		// (get) Token: 0x06001004 RID: 4100 RVA: 0x000308F0 File Offset: 0x0002EAF0
		// (set) Token: 0x06001005 RID: 4101 RVA: 0x00030918 File Offset: 0x0002EB18
		[Property("family")]
		public string Family
		{
			get
			{
				Value property = base.GetProperty("family");
				string result = (string)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("family", val);
				val.Dispose();
			}
		}

		// Token: 0x170003A1 RID: 929
		// (get) Token: 0x06001006 RID: 4102 RVA: 0x00030940 File Offset: 0x0002EB40
		// (set) Token: 0x06001007 RID: 4103 RVA: 0x0003096C File Offset: 0x0002EB6C
		[Property("style")]
		public Style Style
		{
			get
			{
				Value property = base.GetProperty("style");
				Style result = (Style)((Enum)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("style", val);
				val.Dispose();
			}
		}

		// Token: 0x170003A2 RID: 930
		// (get) Token: 0x06001008 RID: 4104 RVA: 0x0003099C File Offset: 0x0002EB9C
		// (set) Token: 0x06001009 RID: 4105 RVA: 0x000309C8 File Offset: 0x0002EBC8
		[Property("variant")]
		public Pango.Variant Variant
		{
			get
			{
				Value property = base.GetProperty("variant");
				Pango.Variant result = (Pango.Variant)((Enum)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("variant", val);
				val.Dispose();
			}
		}

		// Token: 0x170003A3 RID: 931
		// (get) Token: 0x0600100A RID: 4106 RVA: 0x000309F8 File Offset: 0x0002EBF8
		// (set) Token: 0x0600100B RID: 4107 RVA: 0x00030A20 File Offset: 0x0002EC20
		[Property("weight")]
		public int Weight
		{
			get
			{
				Value property = base.GetProperty("weight");
				int result = (int)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("weight", val);
				val.Dispose();
			}
		}

		// Token: 0x170003A4 RID: 932
		// (get) Token: 0x0600100C RID: 4108 RVA: 0x00030A48 File Offset: 0x0002EC48
		// (set) Token: 0x0600100D RID: 4109 RVA: 0x00030A74 File Offset: 0x0002EC74
		[Property("stretch")]
		public Stretch Stretch
		{
			get
			{
				Value property = base.GetProperty("stretch");
				Stretch result = (Stretch)((Enum)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("stretch", val);
				val.Dispose();
			}
		}

		// Token: 0x170003A5 RID: 933
		// (get) Token: 0x0600100E RID: 4110 RVA: 0x00030AA4 File Offset: 0x0002ECA4
		// (set) Token: 0x0600100F RID: 4111 RVA: 0x00030ACC File Offset: 0x0002ECCC
		[Property("size")]
		public int Size
		{
			get
			{
				Value property = base.GetProperty("size");
				int result = (int)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("size", val);
				val.Dispose();
			}
		}

		// Token: 0x170003A6 RID: 934
		// (get) Token: 0x06001010 RID: 4112 RVA: 0x00030AF4 File Offset: 0x0002ECF4
		// (set) Token: 0x06001011 RID: 4113 RVA: 0x00030B1C File Offset: 0x0002ED1C
		[Property("size-points")]
		public double SizePoints
		{
			get
			{
				Value property = base.GetProperty("size-points");
				double result = (double)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("size-points", val);
				val.Dispose();
			}
		}

		// Token: 0x170003A7 RID: 935
		// (get) Token: 0x06001012 RID: 4114 RVA: 0x00030B44 File Offset: 0x0002ED44
		// (set) Token: 0x06001013 RID: 4115 RVA: 0x00030B6C File Offset: 0x0002ED6C
		[Property("scale")]
		public double Scale
		{
			get
			{
				Value property = base.GetProperty("scale");
				double result = (double)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("scale", val);
				val.Dispose();
			}
		}

		// Token: 0x170003A8 RID: 936
		// (get) Token: 0x06001014 RID: 4116 RVA: 0x00030B94 File Offset: 0x0002ED94
		// (set) Token: 0x06001015 RID: 4117 RVA: 0x00030BBC File Offset: 0x0002EDBC
		[Property("rise")]
		public int Rise
		{
			get
			{
				Value property = base.GetProperty("rise");
				int result = (int)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("rise", val);
				val.Dispose();
			}
		}

		// Token: 0x170003A9 RID: 937
		// (get) Token: 0x06001016 RID: 4118 RVA: 0x00030BE4 File Offset: 0x0002EDE4
		// (set) Token: 0x06001017 RID: 4119 RVA: 0x00030C0C File Offset: 0x0002EE0C
		[Property("strikethrough")]
		public bool Strikethrough
		{
			get
			{
				Value property = base.GetProperty("strikethrough");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("strikethrough", val);
				val.Dispose();
			}
		}

		// Token: 0x170003AA RID: 938
		// (get) Token: 0x06001018 RID: 4120 RVA: 0x00030C34 File Offset: 0x0002EE34
		// (set) Token: 0x06001019 RID: 4121 RVA: 0x00030C60 File Offset: 0x0002EE60
		[Property("underline")]
		public Underline Underline
		{
			get
			{
				Value property = base.GetProperty("underline");
				Underline result = (Underline)((Enum)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("underline", val);
				val.Dispose();
			}
		}

		// Token: 0x170003AB RID: 939
		// (get) Token: 0x0600101A RID: 4122 RVA: 0x00030C90 File Offset: 0x0002EE90
		// (set) Token: 0x0600101B RID: 4123 RVA: 0x00030CB8 File Offset: 0x0002EEB8
		[Property("language")]
		public string Language
		{
			get
			{
				Value property = base.GetProperty("language");
				string result = (string)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("language", val);
				val.Dispose();
			}
		}

		// Token: 0x170003AC RID: 940
		// (get) Token: 0x0600101C RID: 4124 RVA: 0x00030CE0 File Offset: 0x0002EEE0
		// (set) Token: 0x0600101D RID: 4125 RVA: 0x00030D0C File Offset: 0x0002EF0C
		[Property("ellipsize")]
		public EllipsizeMode Ellipsize
		{
			get
			{
				Value property = base.GetProperty("ellipsize");
				EllipsizeMode result = (EllipsizeMode)((Enum)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("ellipsize", val);
				val.Dispose();
			}
		}

		// Token: 0x170003AD RID: 941
		// (get) Token: 0x0600101E RID: 4126 RVA: 0x00030D3C File Offset: 0x0002EF3C
		// (set) Token: 0x0600101F RID: 4127 RVA: 0x00030D64 File Offset: 0x0002EF64
		[Property("width-chars")]
		public int WidthChars
		{
			get
			{
				Value property = base.GetProperty("width-chars");
				int result = (int)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("width-chars", val);
				val.Dispose();
			}
		}

		// Token: 0x170003AE RID: 942
		// (get) Token: 0x06001020 RID: 4128 RVA: 0x00030D8C File Offset: 0x0002EF8C
		// (set) Token: 0x06001021 RID: 4129 RVA: 0x00030DB4 File Offset: 0x0002EFB4
		[Property("max-width-chars")]
		public int MaxWidthChars
		{
			get
			{
				Value property = base.GetProperty("max-width-chars");
				int result = (int)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("max-width-chars", val);
				val.Dispose();
			}
		}

		// Token: 0x170003AF RID: 943
		// (get) Token: 0x06001022 RID: 4130 RVA: 0x00030DDC File Offset: 0x0002EFDC
		// (set) Token: 0x06001023 RID: 4131 RVA: 0x00030E08 File Offset: 0x0002F008
		[Property("wrap-mode")]
		public WrapMode WrapMode
		{
			get
			{
				Value property = base.GetProperty("wrap-mode");
				WrapMode result = (WrapMode)((Enum)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("wrap-mode", val);
				val.Dispose();
			}
		}

		// Token: 0x170003B0 RID: 944
		// (get) Token: 0x06001024 RID: 4132 RVA: 0x00030E38 File Offset: 0x0002F038
		// (set) Token: 0x06001025 RID: 4133 RVA: 0x00030E60 File Offset: 0x0002F060
		[Property("wrap-width")]
		public int WrapWidth
		{
			get
			{
				Value property = base.GetProperty("wrap-width");
				int result = (int)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("wrap-width", val);
				val.Dispose();
			}
		}

		// Token: 0x170003B1 RID: 945
		// (get) Token: 0x06001026 RID: 4134 RVA: 0x00030E88 File Offset: 0x0002F088
		// (set) Token: 0x06001027 RID: 4135 RVA: 0x00030EB4 File Offset: 0x0002F0B4
		[Property("alignment")]
		public Alignment Alignment
		{
			get
			{
				Value property = base.GetProperty("alignment");
				Alignment result = (Alignment)((Enum)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("alignment", val);
				val.Dispose();
			}
		}

		// Token: 0x170003B2 RID: 946
		// (get) Token: 0x06001028 RID: 4136 RVA: 0x00030EE4 File Offset: 0x0002F0E4
		// (set) Token: 0x06001029 RID: 4137 RVA: 0x00030F0C File Offset: 0x0002F10C
		[Property("placeholder-text")]
		public string PlaceholderText
		{
			get
			{
				Value property = base.GetProperty("placeholder-text");
				string result = (string)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("placeholder-text", val);
				val.Dispose();
			}
		}

		// Token: 0x14000065 RID: 101
		// (add) Token: 0x0600102A RID: 4138 RVA: 0x00030F34 File Offset: 0x0002F134
		// (remove) Token: 0x0600102B RID: 4139 RVA: 0x00030F4C File Offset: 0x0002F14C
		[Signal("edited")]
		public event EditedHandler Edited
		{
			add
			{
				base.AddSignalHandler("edited", value, typeof(EditedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("edited", value);
			}
		}

		// Token: 0x170003B3 RID: 947
		// (get) Token: 0x0600102C RID: 4140 RVA: 0x00030F5A File Offset: 0x0002F15A
		private static CellRendererText.EditedNativeDelegate EditedVMCallback
		{
			get
			{
				if (CellRendererText.Edited_cb_delegate == null)
				{
					CellRendererText.Edited_cb_delegate = new CellRendererText.EditedNativeDelegate(CellRendererText.Edited_cb);
				}
				return CellRendererText.Edited_cb_delegate;
			}
		}

		// Token: 0x0600102D RID: 4141 RVA: 0x00030F79 File Offset: 0x0002F179
		private static void OverrideEdited(GType gtype)
		{
			CellRendererText.OverrideEdited(gtype, CellRendererText.EditedVMCallback);
		}

		// Token: 0x0600102E RID: 4142 RVA: 0x00030F88 File Offset: 0x0002F188
		private unsafe static void OverrideEdited(GType gtype, CellRendererText.EditedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellRendererText.class_abi.GetFieldOffset("edited");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600102F RID: 4143 RVA: 0x00030FBC File Offset: 0x0002F1BC
		private static void Edited_cb(IntPtr inst, IntPtr path, IntPtr new_text)
		{
			try
			{
				(Object.GetObject(inst, false) as CellRendererText).OnEdited(Marshaller.Utf8PtrToString(path), Marshaller.Utf8PtrToString(new_text));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06001030 RID: 4144 RVA: 0x00031000 File Offset: 0x0002F200
		[DefaultSignalHandler(Type = typeof(CellRendererText), ConnectionMethod = "OverrideEdited")]
		protected virtual void OnEdited(string path, string new_text)
		{
			this.InternalEdited(path, new_text);
		}

		// Token: 0x06001031 RID: 4145 RVA: 0x0003100C File Offset: 0x0002F20C
		private void InternalEdited(string path, string new_text)
		{
			CellRendererText.EditedNativeDelegate editedNativeDelegate = CellRendererText.class_abi.BaseOverride(base.LookupGType(), "edited");
			if (editedNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(path);
			IntPtr intPtr2 = Marshaller.StringToPtrGStrdup(new_text);
			editedNativeDelegate(base.Handle, intPtr, intPtr2);
			Marshaller.Free(intPtr);
			Marshaller.Free(intPtr2);
		}

		// Token: 0x170003B4 RID: 948
		// (get) Token: 0x06001032 RID: 4146 RVA: 0x0003105C File Offset: 0x0002F25C
		public new static AbiStruct class_abi
		{
			get
			{
				if (CellRendererText._class_abi == null)
				{
					CellRendererText._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("edited", CellRenderer.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved1", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved1", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "edited", "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellRendererText._class_abi;
			}
		}

		// Token: 0x170003B5 RID: 949
		// (get) Token: 0x06001033 RID: 4147 RVA: 0x000311B4 File Offset: 0x0002F3B4
		public new static GType GType
		{
			get
			{
				IntPtr val = CellRendererText.gtk_cell_renderer_text_get_type();
				return new GType(val);
			}
		}

		// Token: 0x170003B6 RID: 950
		// (set) Token: 0x06001034 RID: 4148 RVA: 0x000311D2 File Offset: 0x0002F3D2
		public int FixedHeightFromFont
		{
			set
			{
				CellRendererText.gtk_cell_renderer_text_set_fixed_height_from_font(base.Handle, value);
			}
		}

		// Token: 0x170003B7 RID: 951
		// (get) Token: 0x06001035 RID: 4149 RVA: 0x000311E8 File Offset: 0x0002F3E8
		public new static AbiStruct abi_info
		{
			get
			{
				if (CellRendererText._abi_info == null)
				{
					CellRendererText._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", CellRenderer.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellRendererText._abi_info;
			}
		}

		// Token: 0x040007BC RID: 1980
		private static CellRendererText.d_gtk_cell_renderer_text_new gtk_cell_renderer_text_new = FuncLoader.LoadFunction<CellRendererText.d_gtk_cell_renderer_text_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_text_new"));

		// Token: 0x040007BD RID: 1981
		private static CellRendererText.EditedNativeDelegate Edited_cb_delegate;

		// Token: 0x040007BE RID: 1982
		private static AbiStruct _class_abi = null;

		// Token: 0x040007BF RID: 1983
		private static CellRendererText.d_gtk_cell_renderer_text_get_type gtk_cell_renderer_text_get_type = FuncLoader.LoadFunction<CellRendererText.d_gtk_cell_renderer_text_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_text_get_type"));

		// Token: 0x040007C0 RID: 1984
		private static CellRendererText.d_gtk_cell_renderer_text_set_fixed_height_from_font gtk_cell_renderer_text_set_fixed_height_from_font = FuncLoader.LoadFunction<CellRendererText.d_gtk_cell_renderer_text_set_fixed_height_from_font>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_text_set_fixed_height_from_font"));

		// Token: 0x040007C1 RID: 1985
		private static AbiStruct _abi_info = null;

		// Token: 0x02000B28 RID: 2856
		// (Invoke) Token: 0x060053AD RID: 21421
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_renderer_text_new();

		// Token: 0x02000B29 RID: 2857
		// (Invoke) Token: 0x060053B1 RID: 21425
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void EditedNativeDelegate(IntPtr inst, IntPtr path, IntPtr new_text);

		// Token: 0x02000B2A RID: 2858
		// (Invoke) Token: 0x060053B5 RID: 21429
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_renderer_text_get_type();

		// Token: 0x02000B2B RID: 2859
		// (Invoke) Token: 0x060053B9 RID: 21433
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_text_set_fixed_height_from_font(IntPtr raw, int number_of_rows);
	}
}
