﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001A6 RID: 422
	public class ColorStop : Opaque
	{
		// Token: 0x06001139 RID: 4409 RVA: 0x00033A96 File Offset: 0x00031C96
		public ColorStop(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000401 RID: 1025
		// (get) Token: 0x0600113A RID: 4410 RVA: 0x00033A9F File Offset: 0x00031C9F
		public static AbiStruct abi_info
		{
			get
			{
				if (ColorStop._abi_info == null)
				{
					ColorStop._abi_info = new AbiStruct(new List<AbiField>());
				}
				return ColorStop._abi_info;
			}
		}

		// Token: 0x04000812 RID: 2066
		private static AbiStruct _abi_info;
	}
}
