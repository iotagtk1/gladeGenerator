﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001A1 RID: 417
	public class ColorScale : Opaque
	{
		// Token: 0x06001123 RID: 4387 RVA: 0x00033712 File Offset: 0x00031912
		public ColorScale(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170003F8 RID: 1016
		// (get) Token: 0x06001124 RID: 4388 RVA: 0x0003371B File Offset: 0x0003191B
		public static AbiStruct abi_info
		{
			get
			{
				if (ColorScale._abi_info == null)
				{
					ColorScale._abi_info = new AbiStruct(new List<AbiField>());
				}
				return ColorScale._abi_info;
			}
		}

		// Token: 0x0400080B RID: 2059
		private static AbiStruct _abi_info;
	}
}
