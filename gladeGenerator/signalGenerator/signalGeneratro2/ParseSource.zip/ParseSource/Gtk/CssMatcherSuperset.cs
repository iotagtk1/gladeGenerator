﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001E7 RID: 487
	public class CssMatcherSuperset : Opaque
	{
		// Token: 0x060011C9 RID: 4553 RVA: 0x0003426F File Offset: 0x0003246F
		public CssMatcherSuperset(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000438 RID: 1080
		// (get) Token: 0x060011CA RID: 4554 RVA: 0x00034278 File Offset: 0x00032478
		public static AbiStruct abi_info
		{
			get
			{
				if (CssMatcherSuperset._abi_info == null)
				{
					CssMatcherSuperset._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssMatcherSuperset._abi_info;
			}
		}

		// Token: 0x04000847 RID: 2119
		private static AbiStruct _abi_info;
	}
}
