﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000158 RID: 344
	[GType(typeof(ButtonRoleGType))]
	public enum ButtonRole
	{
		// Token: 0x0400071C RID: 1820
		Normal,
		// Token: 0x0400071D RID: 1821
		Check,
		// Token: 0x0400071E RID: 1822
		Radio
	}
}
