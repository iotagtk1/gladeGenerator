﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001FA RID: 506
	public class CssSelectorTree : Opaque
	{
		// Token: 0x0600120E RID: 4622 RVA: 0x00034DDD File Offset: 0x00032FDD
		public CssSelectorTree(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000455 RID: 1109
		// (get) Token: 0x0600120F RID: 4623 RVA: 0x00034DE6 File Offset: 0x00032FE6
		public static AbiStruct abi_info
		{
			get
			{
				if (CssSelectorTree._abi_info == null)
				{
					CssSelectorTree._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssSelectorTree._abi_info;
			}
		}

		// Token: 0x04000880 RID: 2176
		private static AbiStruct _abi_info;
	}
}
