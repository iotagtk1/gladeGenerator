﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Atk;
using Gdk;
using GLib;
using GtkSharp;

namespace Gtk
{
	// Token: 0x020000E3 RID: 227
	public class ComboBox : Bin, ICellLayout, IWrapper, ICellEditable
	{
		// Token: 0x0600071C RID: 1820 RVA: 0x000152AC File Offset: 0x000134AC
		public ComboBox(string[] entries) : this(new ListStore(new Type[]
		{
			typeof(string)
		}))
		{
			ListStore listStore = this.Model as ListStore;
			CellRendererText cell = new CellRendererText();
			this.PackStart(cell, true);
			this.SetAttributes(cell, new object[]
			{
				"text",
				0
			});
			foreach (string text in entries)
			{
				listStore.AppendValues(new object[]
				{
					text
				});
			}
		}

		// Token: 0x0600071D RID: 1821 RVA: 0x00015338 File Offset: 0x00013538
		protected ComboBox(bool with_entry) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(ComboBox))
			{
				this.CreateNativeObject(new string[]
				{
					"has-entry"
				}, new Value[]
				{
					new Value(with_entry)
				});
				return;
			}
			if (with_entry)
			{
				this.Raw = ComboBox.gtk_combo_box_new_with_entry();
				return;
			}
			this.Raw = ComboBox.gtk_combo_box_new();
		}

		// Token: 0x17000131 RID: 305
		// (get) Token: 0x0600071E RID: 1822 RVA: 0x000153B3 File Offset: 0x000135B3
		public Entry Entry
		{
			get
			{
				return base.Child as Entry;
			}
		}

		// Token: 0x0600071F RID: 1823 RVA: 0x000153C0 File Offset: 0x000135C0
		public void SetAttributes(CellRenderer cell, params object[] attrs)
		{
			if (attrs.Length % 2 != 0)
			{
				throw new ArgumentException("attrs should contain pairs of attribute/col");
			}
			this.ClearAttributes(cell);
			for (int i = 0; i < attrs.Length - 1; i += 2)
			{
				this.AddAttribute(cell, (string)attrs[i], (int)attrs[i + 1]);
			}
		}

		// Token: 0x06000720 RID: 1824 RVA: 0x0001540F File Offset: 0x0001360F
		public ComboBox(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000721 RID: 1825 RVA: 0x00015418 File Offset: 0x00013618
		public ComboBox() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(ComboBox))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = ComboBox.gtk_combo_box_new();
		}

		// Token: 0x06000722 RID: 1826 RVA: 0x0001546C File Offset: 0x0001366C
		public ComboBox(CellArea area) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(ComboBox))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			this.Raw = ComboBox.gtk_combo_box_new_with_area((area == null) ? IntPtr.Zero : area.Handle);
		}

		// Token: 0x06000723 RID: 1827 RVA: 0x000154DA File Offset: 0x000136DA
		public static ComboBox NewWithAreaAndEntry(CellArea area)
		{
			return new ComboBox(ComboBox.gtk_combo_box_new_with_area_and_entry((area == null) ? IntPtr.Zero : area.Handle));
		}

		// Token: 0x06000724 RID: 1828 RVA: 0x000154FB File Offset: 0x000136FB
		public static ComboBox NewWithEntry()
		{
			return new ComboBox(ComboBox.gtk_combo_box_new_with_entry());
		}

		// Token: 0x06000725 RID: 1829 RVA: 0x0001550C File Offset: 0x0001370C
		public ComboBox(ITreeModel model) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(ComboBox))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				if (model != null)
				{
					list2.Add("model");
					list.Add(new Value(model));
				}
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			this.Raw = ComboBox.gtk_combo_box_new_with_model((model == null) ? IntPtr.Zero : ((model is GLib.Object) ? (model as GLib.Object).Handle : (model as TreeModelAdapter).Handle));
		}

		// Token: 0x06000726 RID: 1830 RVA: 0x000155AE File Offset: 0x000137AE
		public static ComboBox NewWithModelAndEntry(ITreeModel model)
		{
			return new ComboBox(ComboBox.gtk_combo_box_new_with_model_and_entry((model == null) ? IntPtr.Zero : ((model is GLib.Object) ? (model as GLib.Object).Handle : (model as TreeModelAdapter).Handle)));
		}

		// Token: 0x17000132 RID: 306
		// (get) Token: 0x06000727 RID: 1831 RVA: 0x000155E9 File Offset: 0x000137E9
		// (set) Token: 0x06000728 RID: 1832 RVA: 0x00015601 File Offset: 0x00013801
		[Property("model")]
		public ITreeModel Model
		{
			get
			{
				return TreeModelAdapter.GetObject(ComboBox.gtk_combo_box_get_model(base.Handle), false);
			}
			set
			{
				ComboBox.gtk_combo_box_set_model(base.Handle, (value == null) ? IntPtr.Zero : ((value is GLib.Object) ? (value as GLib.Object).Handle : (value as TreeModelAdapter).Handle));
			}
		}

		// Token: 0x17000133 RID: 307
		// (get) Token: 0x06000729 RID: 1833 RVA: 0x0001563D File Offset: 0x0001383D
		// (set) Token: 0x0600072A RID: 1834 RVA: 0x0001564F File Offset: 0x0001384F
		[Property("wrap-width")]
		public int WrapWidth
		{
			get
			{
				return ComboBox.gtk_combo_box_get_wrap_width(base.Handle);
			}
			set
			{
				ComboBox.gtk_combo_box_set_wrap_width(base.Handle, value);
			}
		}

		// Token: 0x17000134 RID: 308
		// (get) Token: 0x0600072B RID: 1835 RVA: 0x00015662 File Offset: 0x00013862
		// (set) Token: 0x0600072C RID: 1836 RVA: 0x00015674 File Offset: 0x00013874
		[Property("row-span-column")]
		public int RowSpanColumn
		{
			get
			{
				return ComboBox.gtk_combo_box_get_row_span_column(base.Handle);
			}
			set
			{
				ComboBox.gtk_combo_box_set_row_span_column(base.Handle, value);
			}
		}

		// Token: 0x17000135 RID: 309
		// (get) Token: 0x0600072D RID: 1837 RVA: 0x00015687 File Offset: 0x00013887
		// (set) Token: 0x0600072E RID: 1838 RVA: 0x00015699 File Offset: 0x00013899
		[Property("column-span-column")]
		public int ColumnSpanColumn
		{
			get
			{
				return ComboBox.gtk_combo_box_get_column_span_column(base.Handle);
			}
			set
			{
				ComboBox.gtk_combo_box_set_column_span_column(base.Handle, value);
			}
		}

		// Token: 0x17000136 RID: 310
		// (get) Token: 0x0600072F RID: 1839 RVA: 0x000156AC File Offset: 0x000138AC
		// (set) Token: 0x06000730 RID: 1840 RVA: 0x000156BE File Offset: 0x000138BE
		[Property("active")]
		public int Active
		{
			get
			{
				return ComboBox.gtk_combo_box_get_active(base.Handle);
			}
			set
			{
				ComboBox.gtk_combo_box_set_active(base.Handle, value);
			}
		}

		// Token: 0x17000137 RID: 311
		// (get) Token: 0x06000731 RID: 1841 RVA: 0x000156D1 File Offset: 0x000138D1
		// (set) Token: 0x06000732 RID: 1842 RVA: 0x000156E3 File Offset: 0x000138E3
		[Obsolete]
		[Property("add-tearoffs")]
		public bool AddTearoffs
		{
			get
			{
				return ComboBox.gtk_combo_box_get_add_tearoffs(base.Handle);
			}
			set
			{
				ComboBox.gtk_combo_box_set_add_tearoffs(base.Handle, value);
			}
		}

		// Token: 0x17000138 RID: 312
		// (get) Token: 0x06000733 RID: 1843 RVA: 0x000156F8 File Offset: 0x000138F8
		// (set) Token: 0x06000734 RID: 1844 RVA: 0x00015720 File Offset: 0x00013920
		[Property("has-frame")]
		public bool HasFrame
		{
			get
			{
				Value property = base.GetProperty("has-frame");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("has-frame", val);
				val.Dispose();
			}
		}

		// Token: 0x17000139 RID: 313
		// (get) Token: 0x06000735 RID: 1845 RVA: 0x00015748 File Offset: 0x00013948
		// (set) Token: 0x06000736 RID: 1846 RVA: 0x00015760 File Offset: 0x00013960
		[Obsolete]
		[Property("tearoff-title")]
		public string TearoffTitle
		{
			get
			{
				return Marshaller.Utf8PtrToString(ComboBox.gtk_combo_box_get_title(base.Handle));
			}
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				ComboBox.gtk_combo_box_set_title(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x1700013A RID: 314
		// (get) Token: 0x06000737 RID: 1847 RVA: 0x0001578C File Offset: 0x0001398C
		[Property("popup-shown")]
		public bool PopupShown
		{
			get
			{
				Value property = base.GetProperty("popup-shown");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
		}

		// Token: 0x1700013B RID: 315
		// (get) Token: 0x06000738 RID: 1848 RVA: 0x000157B2 File Offset: 0x000139B2
		// (set) Token: 0x06000739 RID: 1849 RVA: 0x000157C4 File Offset: 0x000139C4
		[Property("button-sensitivity")]
		public SensitivityType ButtonSensitivity
		{
			get
			{
				return (SensitivityType)ComboBox.gtk_combo_box_get_button_sensitivity(base.Handle);
			}
			set
			{
				ComboBox.gtk_combo_box_set_button_sensitivity(base.Handle, (int)value);
			}
		}

		// Token: 0x1700013C RID: 316
		// (get) Token: 0x0600073A RID: 1850 RVA: 0x000157D7 File Offset: 0x000139D7
		[Property("has-entry")]
		public bool HasEntry
		{
			get
			{
				return ComboBox.gtk_combo_box_get_has_entry(base.Handle);
			}
		}

		// Token: 0x1700013D RID: 317
		// (get) Token: 0x0600073B RID: 1851 RVA: 0x000157E9 File Offset: 0x000139E9
		// (set) Token: 0x0600073C RID: 1852 RVA: 0x000157FB File Offset: 0x000139FB
		[Property("entry-text-column")]
		public int EntryTextColumn
		{
			get
			{
				return ComboBox.gtk_combo_box_get_entry_text_column(base.Handle);
			}
			set
			{
				ComboBox.gtk_combo_box_set_entry_text_column(base.Handle, value);
			}
		}

		// Token: 0x1700013E RID: 318
		// (get) Token: 0x0600073D RID: 1853 RVA: 0x0001580E File Offset: 0x00013A0E
		// (set) Token: 0x0600073E RID: 1854 RVA: 0x00015820 File Offset: 0x00013A20
		[Property("id-column")]
		public int IdColumn
		{
			get
			{
				return ComboBox.gtk_combo_box_get_id_column(base.Handle);
			}
			set
			{
				ComboBox.gtk_combo_box_set_id_column(base.Handle, value);
			}
		}

		// Token: 0x1700013F RID: 319
		// (get) Token: 0x0600073F RID: 1855 RVA: 0x00015833 File Offset: 0x00013A33
		// (set) Token: 0x06000740 RID: 1856 RVA: 0x0001584C File Offset: 0x00013A4C
		[Property("active-id")]
		public string ActiveId
		{
			get
			{
				return Marshaller.Utf8PtrToString(ComboBox.gtk_combo_box_get_active_id(base.Handle));
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("active-id", val);
				val.Dispose();
			}
		}

		// Token: 0x17000140 RID: 320
		// (get) Token: 0x06000741 RID: 1857 RVA: 0x00015874 File Offset: 0x00013A74
		// (set) Token: 0x06000742 RID: 1858 RVA: 0x00015886 File Offset: 0x00013A86
		[Property("popup-fixed-width")]
		public bool PopupFixedWidth
		{
			get
			{
				return ComboBox.gtk_combo_box_get_popup_fixed_width(base.Handle);
			}
			set
			{
				ComboBox.gtk_combo_box_set_popup_fixed_width(base.Handle, value);
			}
		}

		// Token: 0x17000141 RID: 321
		// (get) Token: 0x06000743 RID: 1859 RVA: 0x0001589C File Offset: 0x00013A9C
		[Property("cell-area")]
		public CellArea CellArea
		{
			get
			{
				Value property = base.GetProperty("cell-area");
				CellArea result = (CellArea)((GLib.Object)property);
				property.Dispose();
				return result;
			}
		}

		// Token: 0x17000142 RID: 322
		// (get) Token: 0x06000744 RID: 1860 RVA: 0x000158C8 File Offset: 0x00013AC8
		[Property("appears-as-list")]
		public bool AppearsAsList
		{
			get
			{
				Value property = base.GetProperty("appears-as-list");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
		}

		// Token: 0x17000143 RID: 323
		// (get) Token: 0x06000745 RID: 1861 RVA: 0x000158F0 File Offset: 0x00013AF0
		[Property("arrow-size")]
		public int ArrowSize
		{
			get
			{
				Value property = base.GetProperty("arrow-size");
				int result = (int)property;
				property.Dispose();
				return result;
			}
		}

		// Token: 0x17000144 RID: 324
		// (get) Token: 0x06000746 RID: 1862 RVA: 0x00015918 File Offset: 0x00013B18
		[Property("arrow-scaling")]
		public float ArrowScaling
		{
			get
			{
				Value property = base.GetProperty("arrow-scaling");
				float result = (float)property;
				property.Dispose();
				return result;
			}
		}

		// Token: 0x17000145 RID: 325
		// (get) Token: 0x06000747 RID: 1863 RVA: 0x00015940 File Offset: 0x00013B40
		[Property("shadow-type")]
		public ShadowType ShadowType
		{
			get
			{
				Value property = base.GetProperty("shadow-type");
				ShadowType result = (ShadowType)((Enum)property);
				property.Dispose();
				return result;
			}
		}

		// Token: 0x1400001C RID: 28
		// (add) Token: 0x06000748 RID: 1864 RVA: 0x0001596B File Offset: 0x00013B6B
		// (remove) Token: 0x06000749 RID: 1865 RVA: 0x00015983 File Offset: 0x00013B83
		[Signal("popdown")]
		public event PoppedDownHandler PoppedDown
		{
			add
			{
				base.AddSignalHandler("popdown", value, typeof(PoppedDownArgs));
			}
			remove
			{
				base.RemoveSignalHandler("popdown", value);
			}
		}

		// Token: 0x1400001D RID: 29
		// (add) Token: 0x0600074A RID: 1866 RVA: 0x00015991 File Offset: 0x00013B91
		// (remove) Token: 0x0600074B RID: 1867 RVA: 0x0001599F File Offset: 0x00013B9F
		[Signal("popup")]
		public event EventHandler PoppedUp
		{
			add
			{
				base.AddSignalHandler("popup", value);
			}
			remove
			{
				base.RemoveSignalHandler("popup", value);
			}
		}

		// Token: 0x1400001E RID: 30
		// (add) Token: 0x0600074C RID: 1868 RVA: 0x000159AD File Offset: 0x00013BAD
		// (remove) Token: 0x0600074D RID: 1869 RVA: 0x000159C5 File Offset: 0x00013BC5
		[Signal("move-active")]
		public event MoveActiveHandler MoveActive
		{
			add
			{
				base.AddSignalHandler("move-active", value, typeof(MoveActiveArgs));
			}
			remove
			{
				base.RemoveSignalHandler("move-active", value);
			}
		}

		// Token: 0x1400001F RID: 31
		// (add) Token: 0x0600074E RID: 1870 RVA: 0x000159D3 File Offset: 0x00013BD3
		// (remove) Token: 0x0600074F RID: 1871 RVA: 0x000159EB File Offset: 0x00013BEB
		[Signal("format-entry-text")]
		public event FormatEntryTextHandler FormatEntryText
		{
			add
			{
				base.AddSignalHandler("format-entry-text", value, typeof(FormatEntryTextArgs));
			}
			remove
			{
				base.RemoveSignalHandler("format-entry-text", value);
			}
		}

		// Token: 0x14000020 RID: 32
		// (add) Token: 0x06000750 RID: 1872 RVA: 0x000159F9 File Offset: 0x00013BF9
		// (remove) Token: 0x06000751 RID: 1873 RVA: 0x00015A07 File Offset: 0x00013C07
		[Signal("changed")]
		public event EventHandler Changed
		{
			add
			{
				base.AddSignalHandler("changed", value);
			}
			remove
			{
				base.RemoveSignalHandler("changed", value);
			}
		}

		// Token: 0x17000146 RID: 326
		// (get) Token: 0x06000752 RID: 1874 RVA: 0x00015A15 File Offset: 0x00013C15
		private static ComboBox.MoveActiveNativeDelegate MoveActiveVMCallback
		{
			get
			{
				if (ComboBox.MoveActive_cb_delegate == null)
				{
					ComboBox.MoveActive_cb_delegate = new ComboBox.MoveActiveNativeDelegate(ComboBox.MoveActive_cb);
				}
				return ComboBox.MoveActive_cb_delegate;
			}
		}

		// Token: 0x06000753 RID: 1875 RVA: 0x00015A34 File Offset: 0x00013C34
		private static void OverrideMoveActive(GType gtype)
		{
			ComboBox.OverrideMoveActive(gtype, ComboBox.MoveActiveVMCallback);
		}

		// Token: 0x06000754 RID: 1876 RVA: 0x00015A41 File Offset: 0x00013C41
		private static void OverrideMoveActive(GType gtype, ComboBox.MoveActiveNativeDelegate callback)
		{
			GLib.Object.OverrideVirtualMethod(gtype, "move-active", callback);
		}

		// Token: 0x06000755 RID: 1877 RVA: 0x00015A50 File Offset: 0x00013C50
		private static void MoveActive_cb(IntPtr inst, int p0)
		{
			try
			{
				(GLib.Object.GetObject(inst, false) as ComboBox).OnMoveActive((ScrollType)p0);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000756 RID: 1878 RVA: 0x00015A8C File Offset: 0x00013C8C
		[DefaultSignalHandler(Type = typeof(ComboBox), ConnectionMethod = "OverrideMoveActive")]
		protected virtual void OnMoveActive(ScrollType p0)
		{
			this.InternalMoveActive(p0);
		}

		// Token: 0x06000757 RID: 1879 RVA: 0x00015A98 File Offset: 0x00013C98
		private void InternalMoveActive(ScrollType p0)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(2U);
			Value[] array = new Value[2];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(p0);
			valueArray.Append(array[1]);
			GLib.Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x17000147 RID: 327
		// (get) Token: 0x06000758 RID: 1880 RVA: 0x00015B29 File Offset: 0x00013D29
		private static ComboBox.PoppedUpNativeDelegate PoppedUpVMCallback
		{
			get
			{
				if (ComboBox.PoppedUp_cb_delegate == null)
				{
					ComboBox.PoppedUp_cb_delegate = new ComboBox.PoppedUpNativeDelegate(ComboBox.PoppedUp_cb);
				}
				return ComboBox.PoppedUp_cb_delegate;
			}
		}

		// Token: 0x06000759 RID: 1881 RVA: 0x00015B48 File Offset: 0x00013D48
		private static void OverridePoppedUp(GType gtype)
		{
			ComboBox.OverridePoppedUp(gtype, ComboBox.PoppedUpVMCallback);
		}

		// Token: 0x0600075A RID: 1882 RVA: 0x00015B55 File Offset: 0x00013D55
		private static void OverridePoppedUp(GType gtype, ComboBox.PoppedUpNativeDelegate callback)
		{
			GLib.Object.OverrideVirtualMethod(gtype, "popup", callback);
		}

		// Token: 0x0600075B RID: 1883 RVA: 0x00015B64 File Offset: 0x00013D64
		private static void PoppedUp_cb(IntPtr inst)
		{
			try
			{
				(GLib.Object.GetObject(inst, false) as ComboBox).OnPoppedUp();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x0600075C RID: 1884 RVA: 0x00015B9C File Offset: 0x00013D9C
		[DefaultSignalHandler(Type = typeof(ComboBox), ConnectionMethod = "OverridePoppedUp")]
		protected virtual void OnPoppedUp()
		{
			this.InternalPoppedUp();
		}

		// Token: 0x0600075D RID: 1885 RVA: 0x00015BA4 File Offset: 0x00013DA4
		private void InternalPoppedUp()
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(1U);
			Value[] array = new Value[]
			{
				new Value(this)
			};
			valueArray.Append(array[0]);
			GLib.Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x17000148 RID: 328
		// (get) Token: 0x0600075E RID: 1886 RVA: 0x00015C16 File Offset: 0x00013E16
		private static ComboBox.PoppedDownNativeDelegate PoppedDownVMCallback
		{
			get
			{
				if (ComboBox.PoppedDown_cb_delegate == null)
				{
					ComboBox.PoppedDown_cb_delegate = new ComboBox.PoppedDownNativeDelegate(ComboBox.PoppedDown_cb);
				}
				return ComboBox.PoppedDown_cb_delegate;
			}
		}

		// Token: 0x0600075F RID: 1887 RVA: 0x00015C35 File Offset: 0x00013E35
		private static void OverridePoppedDown(GType gtype)
		{
			ComboBox.OverridePoppedDown(gtype, ComboBox.PoppedDownVMCallback);
		}

		// Token: 0x06000760 RID: 1888 RVA: 0x00015C42 File Offset: 0x00013E42
		private static void OverridePoppedDown(GType gtype, ComboBox.PoppedDownNativeDelegate callback)
		{
			GLib.Object.OverrideVirtualMethod(gtype, "popdown", callback);
		}

		// Token: 0x06000761 RID: 1889 RVA: 0x00015C50 File Offset: 0x00013E50
		private static bool PoppedDown_cb(IntPtr inst)
		{
			bool result;
			try
			{
				result = (GLib.Object.GetObject(inst, false) as ComboBox).OnPoppedDown();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000762 RID: 1890 RVA: 0x00015C8C File Offset: 0x00013E8C
		[DefaultSignalHandler(Type = typeof(ComboBox), ConnectionMethod = "OverridePoppedDown")]
		protected virtual bool OnPoppedDown()
		{
			return this.InternalPoppedDown();
		}

		// Token: 0x06000763 RID: 1891 RVA: 0x00015C94 File Offset: 0x00013E94
		private bool InternalPoppedDown()
		{
			Value val = new Value(GType.Boolean);
			ValueArray valueArray = new ValueArray(1U);
			Value[] array = new Value[]
			{
				new Value(this)
			};
			valueArray.Append(array[0]);
			GLib.Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref val);
			foreach (Value value in array)
			{
				value.Dispose();
			}
			bool result = (bool)val;
			val.Dispose();
			return result;
		}

		// Token: 0x17000149 RID: 329
		// (get) Token: 0x06000764 RID: 1892 RVA: 0x00015D19 File Offset: 0x00013F19
		private static ComboBox.ChangedNativeDelegate ChangedVMCallback
		{
			get
			{
				if (ComboBox.Changed_cb_delegate == null)
				{
					ComboBox.Changed_cb_delegate = new ComboBox.ChangedNativeDelegate(ComboBox.Changed_cb);
				}
				return ComboBox.Changed_cb_delegate;
			}
		}

		// Token: 0x06000765 RID: 1893 RVA: 0x00015D38 File Offset: 0x00013F38
		private static void OverrideChanged(GType gtype)
		{
			ComboBox.OverrideChanged(gtype, ComboBox.ChangedVMCallback);
		}

		// Token: 0x06000766 RID: 1894 RVA: 0x00015D48 File Offset: 0x00013F48
		private unsafe static void OverrideChanged(GType gtype, ComboBox.ChangedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + ComboBox.class_abi.GetFieldOffset("changed");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000767 RID: 1895 RVA: 0x00015D7C File Offset: 0x00013F7C
		private static void Changed_cb(IntPtr inst)
		{
			try
			{
				(GLib.Object.GetObject(inst, false) as ComboBox).OnChanged();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000768 RID: 1896 RVA: 0x00015DB4 File Offset: 0x00013FB4
		[DefaultSignalHandler(Type = typeof(ComboBox), ConnectionMethod = "OverrideChanged")]
		protected virtual void OnChanged()
		{
			this.InternalChanged();
		}

		// Token: 0x06000769 RID: 1897 RVA: 0x00015DBC File Offset: 0x00013FBC
		private void InternalChanged()
		{
			ComboBox.ChangedNativeDelegate changedNativeDelegate = ComboBox.class_abi.BaseOverride(base.LookupGType(), "changed");
			if (changedNativeDelegate == null)
			{
				return;
			}
			changedNativeDelegate(base.Handle);
		}

		// Token: 0x1700014A RID: 330
		// (get) Token: 0x0600076A RID: 1898 RVA: 0x00015DEF File Offset: 0x00013FEF
		private static ComboBox.FormatEntryTextNativeDelegate FormatEntryTextVMCallback
		{
			get
			{
				if (ComboBox.FormatEntryText_cb_delegate == null)
				{
					ComboBox.FormatEntryText_cb_delegate = new ComboBox.FormatEntryTextNativeDelegate(ComboBox.FormatEntryText_cb);
				}
				return ComboBox.FormatEntryText_cb_delegate;
			}
		}

		// Token: 0x0600076B RID: 1899 RVA: 0x00015E0E File Offset: 0x0001400E
		private static void OverrideFormatEntryText(GType gtype)
		{
			ComboBox.OverrideFormatEntryText(gtype, ComboBox.FormatEntryTextVMCallback);
		}

		// Token: 0x0600076C RID: 1900 RVA: 0x00015E1C File Offset: 0x0001401C
		private unsafe static void OverrideFormatEntryText(GType gtype, ComboBox.FormatEntryTextNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + ComboBox.class_abi.GetFieldOffset("format_entry_text");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600076D RID: 1901 RVA: 0x00015E50 File Offset: 0x00014050
		private static IntPtr FormatEntryText_cb(IntPtr inst, IntPtr path)
		{
			IntPtr result;
			try
			{
				result = Marshaller.StringToPtrGStrdup((GLib.Object.GetObject(inst, false) as ComboBox).OnFormatEntryText(Marshaller.Utf8PtrToString(path)));
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600076E RID: 1902 RVA: 0x00015E98 File Offset: 0x00014098
		[DefaultSignalHandler(Type = typeof(ComboBox), ConnectionMethod = "OverrideFormatEntryText")]
		protected virtual string OnFormatEntryText(string path)
		{
			return this.InternalFormatEntryText(path);
		}

		// Token: 0x0600076F RID: 1903 RVA: 0x00015EA4 File Offset: 0x000140A4
		private string InternalFormatEntryText(string path)
		{
			ComboBox.FormatEntryTextNativeDelegate formatEntryTextNativeDelegate = ComboBox.class_abi.BaseOverride(base.LookupGType(), "format_entry_text");
			if (formatEntryTextNativeDelegate == null)
			{
				return null;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(path);
			IntPtr ptr = formatEntryTextNativeDelegate(base.Handle, intPtr);
			Marshaller.Free(intPtr);
			return Marshaller.PtrToStringGFree(ptr);
		}

		// Token: 0x1700014B RID: 331
		// (get) Token: 0x06000770 RID: 1904 RVA: 0x00015EEC File Offset: 0x000140EC
		public new static AbiStruct class_abi
		{
			get
			{
				if (ComboBox._class_abi == null)
				{
					ComboBox._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("changed", Bin.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "format_entry_text", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("format_entry_text", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "changed", "_gtk_reserved1", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved1", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "format_entry_text", "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return ComboBox._class_abi;
			}
		}

		// Token: 0x06000771 RID: 1905 RVA: 0x00016044 File Offset: 0x00014244
		public bool GetActiveIter(out TreeIter iter)
		{
			IntPtr intPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(TreeIter)));
			bool result = ComboBox.gtk_combo_box_get_active_iter(base.Handle, intPtr);
			iter = TreeIter.New(intPtr);
			Marshal.FreeHGlobal(intPtr);
			return result;
		}

		// Token: 0x1700014C RID: 332
		// (get) Token: 0x06000772 RID: 1906 RVA: 0x00016089 File Offset: 0x00014289
		public Atk.Object PopupAccessible
		{
			get
			{
				return GLib.Object.GetObject(ComboBox.gtk_combo_box_get_popup_accessible(base.Handle)) as Atk.Object;
			}
		}

		// Token: 0x1700014D RID: 333
		// (get) Token: 0x06000773 RID: 1907 RVA: 0x000160A5 File Offset: 0x000142A5
		// (set) Token: 0x06000774 RID: 1908 RVA: 0x000160BC File Offset: 0x000142BC
		public TreeViewRowSeparatorFunc RowSeparatorFunc
		{
			get
			{
				return TreeViewRowSeparatorFuncWrapper.GetManagedDelegate(ComboBox.gtk_combo_box_get_row_separator_func(base.Handle));
			}
			set
			{
				TreeViewRowSeparatorFuncWrapper treeViewRowSeparatorFuncWrapper = new TreeViewRowSeparatorFuncWrapper(value);
				IntPtr data;
				DestroyNotify destroy;
				if (value == null)
				{
					data = IntPtr.Zero;
					destroy = null;
				}
				else
				{
					data = (IntPtr)GCHandle.Alloc(treeViewRowSeparatorFuncWrapper);
					destroy = DestroyHelper.NotifyHandler;
				}
				ComboBox.gtk_combo_box_set_row_separator_func(base.Handle, treeViewRowSeparatorFuncWrapper.NativeDelegate, data, destroy);
			}
		}

		// Token: 0x1700014E RID: 334
		// (get) Token: 0x06000775 RID: 1909 RVA: 0x00016108 File Offset: 0x00014308
		public new static GType GType
		{
			get
			{
				IntPtr val = ComboBox.gtk_combo_box_get_type();
				return new GType(val);
			}
		}

		// Token: 0x06000776 RID: 1910 RVA: 0x00016126 File Offset: 0x00014326
		public void Popdown()
		{
			ComboBox.gtk_combo_box_popdown(base.Handle);
		}

		// Token: 0x06000777 RID: 1911 RVA: 0x00016138 File Offset: 0x00014338
		public void Popup()
		{
			ComboBox.gtk_combo_box_popup(base.Handle);
		}

		// Token: 0x06000778 RID: 1912 RVA: 0x0001614A File Offset: 0x0001434A
		public void PopupForDevice(Device device)
		{
			ComboBox.gtk_combo_box_popup_for_device(base.Handle, (device == null) ? IntPtr.Zero : device.Handle);
		}

		// Token: 0x06000779 RID: 1913 RVA: 0x0001616C File Offset: 0x0001436C
		public bool SetActiveId(string active_id)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(active_id);
			bool result = ComboBox.gtk_combo_box_set_active_id(base.Handle, intPtr);
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x0600077A RID: 1914 RVA: 0x00016198 File Offset: 0x00014398
		public void SetActiveIter(TreeIter iter)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(iter);
			ComboBox.gtk_combo_box_set_active_iter(base.Handle, intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x0600077B RID: 1915 RVA: 0x000161C8 File Offset: 0x000143C8
		public void AddAttribute(CellRenderer cell, string attribute, int column)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(attribute);
			ComboBox.gtk_cell_layout_add_attribute(base.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, intPtr, column);
			Marshaller.Free(intPtr);
		}

		// Token: 0x0600077C RID: 1916 RVA: 0x00016204 File Offset: 0x00014404
		public void Clear()
		{
			ComboBox.gtk_cell_layout_clear(base.Handle);
		}

		// Token: 0x0600077D RID: 1917 RVA: 0x00016216 File Offset: 0x00014416
		public void ClearAttributes(CellRenderer cell)
		{
			ComboBox.gtk_cell_layout_clear_attributes(base.Handle, (cell == null) ? IntPtr.Zero : cell.Handle);
		}

		// Token: 0x1700014F RID: 335
		// (get) Token: 0x0600077E RID: 1918 RVA: 0x00016238 File Offset: 0x00014438
		public CellArea Area
		{
			get
			{
				return GLib.Object.GetObject(ComboBox.gtk_cell_layout_get_area(base.Handle)) as CellArea;
			}
		}

		// Token: 0x17000150 RID: 336
		// (get) Token: 0x0600077F RID: 1919 RVA: 0x00016254 File Offset: 0x00014454
		public CellRenderer[] Cells
		{
			get
			{
				return (CellRenderer[])Marshaller.ListPtrToArray(ComboBox.gtk_cell_layout_get_cells(base.Handle), typeof(List), true, false, typeof(CellRenderer));
			}
		}

		// Token: 0x06000780 RID: 1920 RVA: 0x00016286 File Offset: 0x00014486
		public void PackEnd(CellRenderer cell, bool expand)
		{
			ComboBox.gtk_cell_layout_pack_end(base.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, expand);
		}

		// Token: 0x06000781 RID: 1921 RVA: 0x000162A9 File Offset: 0x000144A9
		public void PackStart(CellRenderer cell, bool expand)
		{
			ComboBox.gtk_cell_layout_pack_start(base.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, expand);
		}

		// Token: 0x06000782 RID: 1922 RVA: 0x000162CC File Offset: 0x000144CC
		public void Reorder(CellRenderer cell, int position)
		{
			ComboBox.gtk_cell_layout_reorder(base.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, position);
		}

		// Token: 0x06000783 RID: 1923 RVA: 0x000162F0 File Offset: 0x000144F0
		public void SetCellDataFunc(CellRenderer cell, CellLayoutDataFunc func)
		{
			CellLayoutDataFuncWrapper cellLayoutDataFuncWrapper = new CellLayoutDataFuncWrapper(func);
			IntPtr func_data;
			DestroyNotify destroy;
			if (func == null)
			{
				func_data = IntPtr.Zero;
				destroy = null;
			}
			else
			{
				func_data = (IntPtr)GCHandle.Alloc(cellLayoutDataFuncWrapper);
				destroy = DestroyHelper.NotifyHandler;
			}
			ComboBox.gtk_cell_layout_set_cell_data_func(base.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, cellLayoutDataFuncWrapper.NativeDelegate, func_data, destroy);
		}

		// Token: 0x06000784 RID: 1924 RVA: 0x0001634B File Offset: 0x0001454B
		public void FinishEditing()
		{
			ComboBox.gtk_cell_editable_editing_done(base.Handle);
		}

		// Token: 0x06000785 RID: 1925 RVA: 0x0001635D File Offset: 0x0001455D
		public void RemoveWidget()
		{
			ComboBox.gtk_cell_editable_remove_widget(base.Handle);
		}

		// Token: 0x06000786 RID: 1926 RVA: 0x0001636F File Offset: 0x0001456F
		public void StartEditing(Event evnt)
		{
			ComboBox.gtk_cell_editable_start_editing(base.Handle, (evnt == null) ? IntPtr.Zero : evnt.Handle);
		}

		// Token: 0x14000021 RID: 33
		// (add) Token: 0x06000787 RID: 1927 RVA: 0x00016391 File Offset: 0x00014591
		// (remove) Token: 0x06000788 RID: 1928 RVA: 0x0001639F File Offset: 0x0001459F
		[Signal("editing-done")]
		public event EventHandler EditingDone
		{
			add
			{
				base.AddSignalHandler("editing-done", value);
			}
			remove
			{
				base.RemoveSignalHandler("editing-done", value);
			}
		}

		// Token: 0x14000022 RID: 34
		// (add) Token: 0x06000789 RID: 1929 RVA: 0x000163AD File Offset: 0x000145AD
		// (remove) Token: 0x0600078A RID: 1930 RVA: 0x000163BB File Offset: 0x000145BB
		[Signal("remove-widget")]
		public event EventHandler WidgetRemoved
		{
			add
			{
				base.AddSignalHandler("remove-widget", value);
			}
			remove
			{
				base.RemoveSignalHandler("remove-widget", value);
			}
		}

		// Token: 0x17000151 RID: 337
		// (get) Token: 0x0600078B RID: 1931 RVA: 0x000163C9 File Offset: 0x000145C9
		private static ComboBox.EditingDoneNativeDelegate EditingDoneVMCallback
		{
			get
			{
				if (ComboBox.EditingDone_cb_delegate == null)
				{
					ComboBox.EditingDone_cb_delegate = new ComboBox.EditingDoneNativeDelegate(ComboBox.EditingDone_cb);
				}
				return ComboBox.EditingDone_cb_delegate;
			}
		}

		// Token: 0x0600078C RID: 1932 RVA: 0x000163E8 File Offset: 0x000145E8
		private static void OverrideEditingDone(GType gtype)
		{
			ComboBox.OverrideEditingDone(gtype, ComboBox.EditingDoneVMCallback);
		}

		// Token: 0x0600078D RID: 1933 RVA: 0x000163F5 File Offset: 0x000145F5
		private static void OverrideEditingDone(GType gtype, ComboBox.EditingDoneNativeDelegate callback)
		{
			GLib.Object.OverrideVirtualMethod(gtype, "editing-done", callback);
		}

		// Token: 0x0600078E RID: 1934 RVA: 0x00016404 File Offset: 0x00014604
		private static void EditingDone_cb(IntPtr inst)
		{
			try
			{
				(GLib.Object.GetObject(inst, false) as ComboBox).OnEditingDone();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x0600078F RID: 1935 RVA: 0x0001643C File Offset: 0x0001463C
		[DefaultSignalHandler(Type = typeof(ComboBox), ConnectionMethod = "OverrideEditingDone")]
		protected virtual void OnEditingDone()
		{
			this.InternalEditingDone();
		}

		// Token: 0x06000790 RID: 1936 RVA: 0x00016444 File Offset: 0x00014644
		private void InternalEditingDone()
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(1U);
			Value[] array = new Value[]
			{
				new Value(this)
			};
			valueArray.Append(array[0]);
			GLib.Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x17000152 RID: 338
		// (get) Token: 0x06000791 RID: 1937 RVA: 0x000164B6 File Offset: 0x000146B6
		private static ComboBox.WidgetRemovedNativeDelegate WidgetRemovedVMCallback
		{
			get
			{
				if (ComboBox.WidgetRemoved_cb_delegate == null)
				{
					ComboBox.WidgetRemoved_cb_delegate = new ComboBox.WidgetRemovedNativeDelegate(ComboBox.WidgetRemoved_cb);
				}
				return ComboBox.WidgetRemoved_cb_delegate;
			}
		}

		// Token: 0x06000792 RID: 1938 RVA: 0x000164D5 File Offset: 0x000146D5
		private static void OverrideWidgetRemoved(GType gtype)
		{
			ComboBox.OverrideWidgetRemoved(gtype, ComboBox.WidgetRemovedVMCallback);
		}

		// Token: 0x06000793 RID: 1939 RVA: 0x000164E2 File Offset: 0x000146E2
		private static void OverrideWidgetRemoved(GType gtype, ComboBox.WidgetRemovedNativeDelegate callback)
		{
			GLib.Object.OverrideVirtualMethod(gtype, "remove-widget", callback);
		}

		// Token: 0x06000794 RID: 1940 RVA: 0x000164F0 File Offset: 0x000146F0
		private static void WidgetRemoved_cb(IntPtr inst)
		{
			try
			{
				(GLib.Object.GetObject(inst, false) as ComboBox).OnWidgetRemoved();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000795 RID: 1941 RVA: 0x00016528 File Offset: 0x00014728
		[DefaultSignalHandler(Type = typeof(ComboBox), ConnectionMethod = "OverrideWidgetRemoved")]
		protected virtual void OnWidgetRemoved()
		{
			this.InternalWidgetRemoved();
		}

		// Token: 0x06000796 RID: 1942 RVA: 0x00016530 File Offset: 0x00014730
		private void InternalWidgetRemoved()
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(1U);
			Value[] array = new Value[]
			{
				new Value(this)
			};
			valueArray.Append(array[0]);
			GLib.Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x17000153 RID: 339
		// (get) Token: 0x06000797 RID: 1943 RVA: 0x000165A4 File Offset: 0x000147A4
		public new static AbiStruct abi_info
		{
			get
			{
				if (ComboBox._abi_info == null)
				{
					ComboBox._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Bin.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return ComboBox._abi_info;
			}
		}

		// Token: 0x04000398 RID: 920
		private static ComboBox.d_gtk_combo_box_new gtk_combo_box_new = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_new"));

		// Token: 0x04000399 RID: 921
		private static ComboBox.d_gtk_combo_box_new_with_area gtk_combo_box_new_with_area = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_new_with_area>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_new_with_area"));

		// Token: 0x0400039A RID: 922
		private static ComboBox.d_gtk_combo_box_new_with_area_and_entry gtk_combo_box_new_with_area_and_entry = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_new_with_area_and_entry>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_new_with_area_and_entry"));

		// Token: 0x0400039B RID: 923
		private static ComboBox.d_gtk_combo_box_new_with_entry gtk_combo_box_new_with_entry = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_new_with_entry>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_new_with_entry"));

		// Token: 0x0400039C RID: 924
		private static ComboBox.d_gtk_combo_box_new_with_model gtk_combo_box_new_with_model = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_new_with_model>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_new_with_model"));

		// Token: 0x0400039D RID: 925
		private static ComboBox.d_gtk_combo_box_new_with_model_and_entry gtk_combo_box_new_with_model_and_entry = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_new_with_model_and_entry>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_new_with_model_and_entry"));

		// Token: 0x0400039E RID: 926
		private static ComboBox.d_gtk_combo_box_get_model gtk_combo_box_get_model = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_get_model>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_get_model"));

		// Token: 0x0400039F RID: 927
		private static ComboBox.d_gtk_combo_box_set_model gtk_combo_box_set_model = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_set_model>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_set_model"));

		// Token: 0x040003A0 RID: 928
		private static ComboBox.d_gtk_combo_box_get_wrap_width gtk_combo_box_get_wrap_width = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_get_wrap_width>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_get_wrap_width"));

		// Token: 0x040003A1 RID: 929
		private static ComboBox.d_gtk_combo_box_set_wrap_width gtk_combo_box_set_wrap_width = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_set_wrap_width>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_set_wrap_width"));

		// Token: 0x040003A2 RID: 930
		private static ComboBox.d_gtk_combo_box_get_row_span_column gtk_combo_box_get_row_span_column = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_get_row_span_column>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_get_row_span_column"));

		// Token: 0x040003A3 RID: 931
		private static ComboBox.d_gtk_combo_box_set_row_span_column gtk_combo_box_set_row_span_column = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_set_row_span_column>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_set_row_span_column"));

		// Token: 0x040003A4 RID: 932
		private static ComboBox.d_gtk_combo_box_get_column_span_column gtk_combo_box_get_column_span_column = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_get_column_span_column>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_get_column_span_column"));

		// Token: 0x040003A5 RID: 933
		private static ComboBox.d_gtk_combo_box_set_column_span_column gtk_combo_box_set_column_span_column = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_set_column_span_column>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_set_column_span_column"));

		// Token: 0x040003A6 RID: 934
		private static ComboBox.d_gtk_combo_box_get_active gtk_combo_box_get_active = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_get_active>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_get_active"));

		// Token: 0x040003A7 RID: 935
		private static ComboBox.d_gtk_combo_box_set_active gtk_combo_box_set_active = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_set_active>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_set_active"));

		// Token: 0x040003A8 RID: 936
		private static ComboBox.d_gtk_combo_box_get_add_tearoffs gtk_combo_box_get_add_tearoffs = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_get_add_tearoffs>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_get_add_tearoffs"));

		// Token: 0x040003A9 RID: 937
		private static ComboBox.d_gtk_combo_box_set_add_tearoffs gtk_combo_box_set_add_tearoffs = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_set_add_tearoffs>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_set_add_tearoffs"));

		// Token: 0x040003AA RID: 938
		private static ComboBox.d_gtk_combo_box_get_title gtk_combo_box_get_title = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_get_title>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_get_title"));

		// Token: 0x040003AB RID: 939
		private static ComboBox.d_gtk_combo_box_set_title gtk_combo_box_set_title = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_set_title>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_set_title"));

		// Token: 0x040003AC RID: 940
		private static ComboBox.d_gtk_combo_box_get_button_sensitivity gtk_combo_box_get_button_sensitivity = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_get_button_sensitivity>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_get_button_sensitivity"));

		// Token: 0x040003AD RID: 941
		private static ComboBox.d_gtk_combo_box_set_button_sensitivity gtk_combo_box_set_button_sensitivity = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_set_button_sensitivity>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_set_button_sensitivity"));

		// Token: 0x040003AE RID: 942
		private static ComboBox.d_gtk_combo_box_get_has_entry gtk_combo_box_get_has_entry = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_get_has_entry>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_get_has_entry"));

		// Token: 0x040003AF RID: 943
		private static ComboBox.d_gtk_combo_box_get_entry_text_column gtk_combo_box_get_entry_text_column = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_get_entry_text_column>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_get_entry_text_column"));

		// Token: 0x040003B0 RID: 944
		private static ComboBox.d_gtk_combo_box_set_entry_text_column gtk_combo_box_set_entry_text_column = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_set_entry_text_column>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_set_entry_text_column"));

		// Token: 0x040003B1 RID: 945
		private static ComboBox.d_gtk_combo_box_get_id_column gtk_combo_box_get_id_column = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_get_id_column>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_get_id_column"));

		// Token: 0x040003B2 RID: 946
		private static ComboBox.d_gtk_combo_box_set_id_column gtk_combo_box_set_id_column = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_set_id_column>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_set_id_column"));

		// Token: 0x040003B3 RID: 947
		private static ComboBox.d_gtk_combo_box_get_active_id gtk_combo_box_get_active_id = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_get_active_id>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_get_active_id"));

		// Token: 0x040003B4 RID: 948
		private static ComboBox.d_gtk_combo_box_get_popup_fixed_width gtk_combo_box_get_popup_fixed_width = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_get_popup_fixed_width>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_get_popup_fixed_width"));

		// Token: 0x040003B5 RID: 949
		private static ComboBox.d_gtk_combo_box_set_popup_fixed_width gtk_combo_box_set_popup_fixed_width = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_set_popup_fixed_width>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_set_popup_fixed_width"));

		// Token: 0x040003B6 RID: 950
		private static ComboBox.MoveActiveNativeDelegate MoveActive_cb_delegate;

		// Token: 0x040003B7 RID: 951
		private static ComboBox.PoppedUpNativeDelegate PoppedUp_cb_delegate;

		// Token: 0x040003B8 RID: 952
		private static ComboBox.PoppedDownNativeDelegate PoppedDown_cb_delegate;

		// Token: 0x040003B9 RID: 953
		private static ComboBox.ChangedNativeDelegate Changed_cb_delegate;

		// Token: 0x040003BA RID: 954
		private static ComboBox.FormatEntryTextNativeDelegate FormatEntryText_cb_delegate;

		// Token: 0x040003BB RID: 955
		private static AbiStruct _class_abi = null;

		// Token: 0x040003BC RID: 956
		private static ComboBox.d_gtk_combo_box_get_active_iter gtk_combo_box_get_active_iter = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_get_active_iter>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_get_active_iter"));

		// Token: 0x040003BD RID: 957
		private static ComboBox.d_gtk_combo_box_get_popup_accessible gtk_combo_box_get_popup_accessible = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_get_popup_accessible>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_get_popup_accessible"));

		// Token: 0x040003BE RID: 958
		private static ComboBox.d_gtk_combo_box_get_row_separator_func gtk_combo_box_get_row_separator_func = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_get_row_separator_func>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_get_row_separator_func"));

		// Token: 0x040003BF RID: 959
		private static ComboBox.d_gtk_combo_box_set_row_separator_func gtk_combo_box_set_row_separator_func = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_set_row_separator_func>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_set_row_separator_func"));

		// Token: 0x040003C0 RID: 960
		private static ComboBox.d_gtk_combo_box_get_type gtk_combo_box_get_type = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_get_type"));

		// Token: 0x040003C1 RID: 961
		private static ComboBox.d_gtk_combo_box_popdown gtk_combo_box_popdown = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_popdown>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_popdown"));

		// Token: 0x040003C2 RID: 962
		private static ComboBox.d_gtk_combo_box_popup gtk_combo_box_popup = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_popup>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_popup"));

		// Token: 0x040003C3 RID: 963
		private static ComboBox.d_gtk_combo_box_popup_for_device gtk_combo_box_popup_for_device = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_popup_for_device>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_popup_for_device"));

		// Token: 0x040003C4 RID: 964
		private static ComboBox.d_gtk_combo_box_set_active_id gtk_combo_box_set_active_id = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_set_active_id>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_set_active_id"));

		// Token: 0x040003C5 RID: 965
		private static ComboBox.d_gtk_combo_box_set_active_iter gtk_combo_box_set_active_iter = FuncLoader.LoadFunction<ComboBox.d_gtk_combo_box_set_active_iter>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_set_active_iter"));

		// Token: 0x040003C6 RID: 966
		private static ComboBox.d_gtk_cell_layout_add_attribute gtk_cell_layout_add_attribute = FuncLoader.LoadFunction<ComboBox.d_gtk_cell_layout_add_attribute>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_add_attribute"));

		// Token: 0x040003C7 RID: 967
		private static ComboBox.d_gtk_cell_layout_clear gtk_cell_layout_clear = FuncLoader.LoadFunction<ComboBox.d_gtk_cell_layout_clear>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_clear"));

		// Token: 0x040003C8 RID: 968
		private static ComboBox.d_gtk_cell_layout_clear_attributes gtk_cell_layout_clear_attributes = FuncLoader.LoadFunction<ComboBox.d_gtk_cell_layout_clear_attributes>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_clear_attributes"));

		// Token: 0x040003C9 RID: 969
		private static ComboBox.d_gtk_cell_layout_get_area gtk_cell_layout_get_area = FuncLoader.LoadFunction<ComboBox.d_gtk_cell_layout_get_area>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_get_area"));

		// Token: 0x040003CA RID: 970
		private static ComboBox.d_gtk_cell_layout_get_cells gtk_cell_layout_get_cells = FuncLoader.LoadFunction<ComboBox.d_gtk_cell_layout_get_cells>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_get_cells"));

		// Token: 0x040003CB RID: 971
		private static ComboBox.d_gtk_cell_layout_pack_end gtk_cell_layout_pack_end = FuncLoader.LoadFunction<ComboBox.d_gtk_cell_layout_pack_end>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_pack_end"));

		// Token: 0x040003CC RID: 972
		private static ComboBox.d_gtk_cell_layout_pack_start gtk_cell_layout_pack_start = FuncLoader.LoadFunction<ComboBox.d_gtk_cell_layout_pack_start>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_pack_start"));

		// Token: 0x040003CD RID: 973
		private static ComboBox.d_gtk_cell_layout_reorder gtk_cell_layout_reorder = FuncLoader.LoadFunction<ComboBox.d_gtk_cell_layout_reorder>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_reorder"));

		// Token: 0x040003CE RID: 974
		private static ComboBox.d_gtk_cell_layout_set_cell_data_func gtk_cell_layout_set_cell_data_func = FuncLoader.LoadFunction<ComboBox.d_gtk_cell_layout_set_cell_data_func>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_set_cell_data_func"));

		// Token: 0x040003CF RID: 975
		private static ComboBox.d_gtk_cell_editable_editing_done gtk_cell_editable_editing_done = FuncLoader.LoadFunction<ComboBox.d_gtk_cell_editable_editing_done>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_editable_editing_done"));

		// Token: 0x040003D0 RID: 976
		private static ComboBox.d_gtk_cell_editable_remove_widget gtk_cell_editable_remove_widget = FuncLoader.LoadFunction<ComboBox.d_gtk_cell_editable_remove_widget>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_editable_remove_widget"));

		// Token: 0x040003D1 RID: 977
		private static ComboBox.d_gtk_cell_editable_start_editing gtk_cell_editable_start_editing = FuncLoader.LoadFunction<ComboBox.d_gtk_cell_editable_start_editing>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_editable_start_editing"));

		// Token: 0x040003D2 RID: 978
		private static ComboBox.EditingDoneNativeDelegate EditingDone_cb_delegate;

		// Token: 0x040003D3 RID: 979
		private static ComboBox.WidgetRemovedNativeDelegate WidgetRemoved_cb_delegate;

		// Token: 0x040003D4 RID: 980
		private static AbiStruct _abi_info = null;

		// Token: 0x020007CA RID: 1994
		// (Invoke) Token: 0x06004648 RID: 17992
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_combo_box_new();

		// Token: 0x020007CB RID: 1995
		// (Invoke) Token: 0x0600464C RID: 17996
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_combo_box_new_with_area(IntPtr area);

		// Token: 0x020007CC RID: 1996
		// (Invoke) Token: 0x06004650 RID: 18000
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_combo_box_new_with_area_and_entry(IntPtr area);

		// Token: 0x020007CD RID: 1997
		// (Invoke) Token: 0x06004654 RID: 18004
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_combo_box_new_with_entry();

		// Token: 0x020007CE RID: 1998
		// (Invoke) Token: 0x06004658 RID: 18008
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_combo_box_new_with_model(IntPtr model);

		// Token: 0x020007CF RID: 1999
		// (Invoke) Token: 0x0600465C RID: 18012
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_combo_box_new_with_model_and_entry(IntPtr model);

		// Token: 0x020007D0 RID: 2000
		// (Invoke) Token: 0x06004660 RID: 18016
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_combo_box_get_model(IntPtr raw);

		// Token: 0x020007D1 RID: 2001
		// (Invoke) Token: 0x06004664 RID: 18020
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_set_model(IntPtr raw, IntPtr model);

		// Token: 0x020007D2 RID: 2002
		// (Invoke) Token: 0x06004668 RID: 18024
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_combo_box_get_wrap_width(IntPtr raw);

		// Token: 0x020007D3 RID: 2003
		// (Invoke) Token: 0x0600466C RID: 18028
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_set_wrap_width(IntPtr raw, int width);

		// Token: 0x020007D4 RID: 2004
		// (Invoke) Token: 0x06004670 RID: 18032
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_combo_box_get_row_span_column(IntPtr raw);

		// Token: 0x020007D5 RID: 2005
		// (Invoke) Token: 0x06004674 RID: 18036
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_set_row_span_column(IntPtr raw, int row_span);

		// Token: 0x020007D6 RID: 2006
		// (Invoke) Token: 0x06004678 RID: 18040
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_combo_box_get_column_span_column(IntPtr raw);

		// Token: 0x020007D7 RID: 2007
		// (Invoke) Token: 0x0600467C RID: 18044
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_set_column_span_column(IntPtr raw, int column_span);

		// Token: 0x020007D8 RID: 2008
		// (Invoke) Token: 0x06004680 RID: 18048
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_combo_box_get_active(IntPtr raw);

		// Token: 0x020007D9 RID: 2009
		// (Invoke) Token: 0x06004684 RID: 18052
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_set_active(IntPtr raw, int index_);

		// Token: 0x020007DA RID: 2010
		// (Invoke) Token: 0x06004688 RID: 18056
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_combo_box_get_add_tearoffs(IntPtr raw);

		// Token: 0x020007DB RID: 2011
		// (Invoke) Token: 0x0600468C RID: 18060
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_set_add_tearoffs(IntPtr raw, bool add_tearoffs);

		// Token: 0x020007DC RID: 2012
		// (Invoke) Token: 0x06004690 RID: 18064
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_combo_box_get_title(IntPtr raw);

		// Token: 0x020007DD RID: 2013
		// (Invoke) Token: 0x06004694 RID: 18068
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_set_title(IntPtr raw, IntPtr title);

		// Token: 0x020007DE RID: 2014
		// (Invoke) Token: 0x06004698 RID: 18072
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_combo_box_get_button_sensitivity(IntPtr raw);

		// Token: 0x020007DF RID: 2015
		// (Invoke) Token: 0x0600469C RID: 18076
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_set_button_sensitivity(IntPtr raw, int sensitivity);

		// Token: 0x020007E0 RID: 2016
		// (Invoke) Token: 0x060046A0 RID: 18080
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_combo_box_get_has_entry(IntPtr raw);

		// Token: 0x020007E1 RID: 2017
		// (Invoke) Token: 0x060046A4 RID: 18084
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_combo_box_get_entry_text_column(IntPtr raw);

		// Token: 0x020007E2 RID: 2018
		// (Invoke) Token: 0x060046A8 RID: 18088
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_set_entry_text_column(IntPtr raw, int text_column);

		// Token: 0x020007E3 RID: 2019
		// (Invoke) Token: 0x060046AC RID: 18092
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_combo_box_get_id_column(IntPtr raw);

		// Token: 0x020007E4 RID: 2020
		// (Invoke) Token: 0x060046B0 RID: 18096
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_set_id_column(IntPtr raw, int id_column);

		// Token: 0x020007E5 RID: 2021
		// (Invoke) Token: 0x060046B4 RID: 18100
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_combo_box_get_active_id(IntPtr raw);

		// Token: 0x020007E6 RID: 2022
		// (Invoke) Token: 0x060046B8 RID: 18104
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_combo_box_get_popup_fixed_width(IntPtr raw);

		// Token: 0x020007E7 RID: 2023
		// (Invoke) Token: 0x060046BC RID: 18108
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_set_popup_fixed_width(IntPtr raw, bool mfixed);

		// Token: 0x020007E8 RID: 2024
		// (Invoke) Token: 0x060046C0 RID: 18112
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void MoveActiveNativeDelegate(IntPtr inst, int p0);

		// Token: 0x020007E9 RID: 2025
		// (Invoke) Token: 0x060046C4 RID: 18116
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void PoppedUpNativeDelegate(IntPtr inst);

		// Token: 0x020007EA RID: 2026
		// (Invoke) Token: 0x060046C8 RID: 18120
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool PoppedDownNativeDelegate(IntPtr inst);

		// Token: 0x020007EB RID: 2027
		// (Invoke) Token: 0x060046CC RID: 18124
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ChangedNativeDelegate(IntPtr inst);

		// Token: 0x020007EC RID: 2028
		// (Invoke) Token: 0x060046D0 RID: 18128
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr FormatEntryTextNativeDelegate(IntPtr inst, IntPtr path);

		// Token: 0x020007ED RID: 2029
		// (Invoke) Token: 0x060046D4 RID: 18132
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_combo_box_get_active_iter(IntPtr raw, IntPtr iter);

		// Token: 0x020007EE RID: 2030
		// (Invoke) Token: 0x060046D8 RID: 18136
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_combo_box_get_popup_accessible(IntPtr raw);

		// Token: 0x020007EF RID: 2031
		// (Invoke) Token: 0x060046DC RID: 18140
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate TreeViewRowSeparatorFuncNative d_gtk_combo_box_get_row_separator_func(IntPtr raw);

		// Token: 0x020007F0 RID: 2032
		// (Invoke) Token: 0x060046E0 RID: 18144
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_set_row_separator_func(IntPtr raw, TreeViewRowSeparatorFuncNative func, IntPtr data, DestroyNotify destroy);

		// Token: 0x020007F1 RID: 2033
		// (Invoke) Token: 0x060046E4 RID: 18148
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_combo_box_get_type();

		// Token: 0x020007F2 RID: 2034
		// (Invoke) Token: 0x060046E8 RID: 18152
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_popdown(IntPtr raw);

		// Token: 0x020007F3 RID: 2035
		// (Invoke) Token: 0x060046EC RID: 18156
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_popup(IntPtr raw);

		// Token: 0x020007F4 RID: 2036
		// (Invoke) Token: 0x060046F0 RID: 18160
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_popup_for_device(IntPtr raw, IntPtr device);

		// Token: 0x020007F5 RID: 2037
		// (Invoke) Token: 0x060046F4 RID: 18164
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_combo_box_set_active_id(IntPtr raw, IntPtr active_id);

		// Token: 0x020007F6 RID: 2038
		// (Invoke) Token: 0x060046F8 RID: 18168
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_set_active_iter(IntPtr raw, IntPtr iter);

		// Token: 0x020007F7 RID: 2039
		// (Invoke) Token: 0x060046FC RID: 18172
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_add_attribute(IntPtr raw, IntPtr cell, IntPtr attribute, int column);

		// Token: 0x020007F8 RID: 2040
		// (Invoke) Token: 0x06004700 RID: 18176
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_clear(IntPtr raw);

		// Token: 0x020007F9 RID: 2041
		// (Invoke) Token: 0x06004704 RID: 18180
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_clear_attributes(IntPtr raw, IntPtr cell);

		// Token: 0x020007FA RID: 2042
		// (Invoke) Token: 0x06004708 RID: 18184
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_layout_get_area(IntPtr raw);

		// Token: 0x020007FB RID: 2043
		// (Invoke) Token: 0x0600470C RID: 18188
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_layout_get_cells(IntPtr raw);

		// Token: 0x020007FC RID: 2044
		// (Invoke) Token: 0x06004710 RID: 18192
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_pack_end(IntPtr raw, IntPtr cell, bool expand);

		// Token: 0x020007FD RID: 2045
		// (Invoke) Token: 0x06004714 RID: 18196
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_pack_start(IntPtr raw, IntPtr cell, bool expand);

		// Token: 0x020007FE RID: 2046
		// (Invoke) Token: 0x06004718 RID: 18200
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_reorder(IntPtr raw, IntPtr cell, int position);

		// Token: 0x020007FF RID: 2047
		// (Invoke) Token: 0x0600471C RID: 18204
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_set_cell_data_func(IntPtr raw, IntPtr cell, CellLayoutDataFuncNative func, IntPtr func_data, DestroyNotify destroy);

		// Token: 0x02000800 RID: 2048
		// (Invoke) Token: 0x06004720 RID: 18208
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_editable_editing_done(IntPtr raw);

		// Token: 0x02000801 RID: 2049
		// (Invoke) Token: 0x06004724 RID: 18212
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_editable_remove_widget(IntPtr raw);

		// Token: 0x02000802 RID: 2050
		// (Invoke) Token: 0x06004728 RID: 18216
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_editable_start_editing(IntPtr raw, IntPtr evnt);

		// Token: 0x02000803 RID: 2051
		// (Invoke) Token: 0x0600472C RID: 18220
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void EditingDoneNativeDelegate(IntPtr inst);

		// Token: 0x02000804 RID: 2052
		// (Invoke) Token: 0x06004730 RID: 18224
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void WidgetRemovedNativeDelegate(IntPtr inst);
	}
}
