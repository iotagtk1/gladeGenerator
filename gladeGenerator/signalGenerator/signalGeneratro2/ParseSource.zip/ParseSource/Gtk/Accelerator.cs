﻿using System;
using System.Runtime.InteropServices;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x020000F8 RID: 248
	public class Accelerator
	{
		// Token: 0x1700024D RID: 589
		// (get) Token: 0x06000B1F RID: 2847 RVA: 0x0002193C File Offset: 0x0001FB3C
		// (set) Token: 0x06000B20 RID: 2848 RVA: 0x00021948 File Offset: 0x0001FB48
		public static ModifierType DefaultModMask
		{
			get
			{
				return (ModifierType)Accelerator.gtk_accelerator_get_default_mod_mask();
			}
			set
			{
				Accelerator.gtk_accelerator_set_default_mod_mask((int)value);
			}
		}

		// Token: 0x06000B21 RID: 2849 RVA: 0x00021955 File Offset: 0x0001FB55
		public static string GetLabel(uint accelerator_key, ModifierType accelerator_mods)
		{
			return Marshaller.PtrToStringGFree(Accelerator.gtk_accelerator_get_label(accelerator_key, (int)accelerator_mods));
		}

		// Token: 0x06000B22 RID: 2850 RVA: 0x00021968 File Offset: 0x0001FB68
		public static string GetLabelWithKeycode(Display display, uint accelerator_key, uint keycode, ModifierType accelerator_mods)
		{
			return Marshaller.PtrToStringGFree(Accelerator.gtk_accelerator_get_label_with_keycode((display == null) ? IntPtr.Zero : display.Handle, accelerator_key, keycode, (int)accelerator_mods));
		}

		// Token: 0x06000B23 RID: 2851 RVA: 0x0002198C File Offset: 0x0001FB8C
		public static string Name(uint accelerator_key, ModifierType accelerator_mods)
		{
			return Marshaller.PtrToStringGFree(Accelerator.gtk_accelerator_name(accelerator_key, (int)accelerator_mods));
		}

		// Token: 0x06000B24 RID: 2852 RVA: 0x0002199F File Offset: 0x0001FB9F
		public static string NameWithKeycode(Display display, uint accelerator_key, uint keycode, ModifierType accelerator_mods)
		{
			return Marshaller.PtrToStringGFree(Accelerator.gtk_accelerator_name_with_keycode((display == null) ? IntPtr.Zero : display.Handle, accelerator_key, keycode, (int)accelerator_mods));
		}

		// Token: 0x06000B25 RID: 2853 RVA: 0x000219C4 File Offset: 0x0001FBC4
		public static void Parse(string accelerator, out uint accelerator_key, out ModifierType accelerator_mods)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(accelerator);
			int num;
			Accelerator.gtk_accelerator_parse(intPtr, out accelerator_key, out num);
			Marshaller.Free(intPtr);
			accelerator_mods = (ModifierType)num;
		}

		// Token: 0x06000B26 RID: 2854 RVA: 0x000219F0 File Offset: 0x0001FBF0
		public static void ParseWithKeycode(string accelerator, out uint accelerator_key, out uint accelerator_codes, out ModifierType accelerator_mods)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(accelerator);
			int num;
			Accelerator.gtk_accelerator_parse_with_keycode(intPtr, out accelerator_key, out accelerator_codes, out num);
			Marshaller.Free(intPtr);
			accelerator_mods = (ModifierType)num;
		}

		// Token: 0x06000B27 RID: 2855 RVA: 0x00021A1C File Offset: 0x0001FC1C
		public static bool Valid(uint keyval, ModifierType modifiers)
		{
			return Accelerator.gtk_accelerator_valid(keyval, (int)modifiers);
		}

		// Token: 0x04000565 RID: 1381
		private static Accelerator.d_gtk_accelerator_get_default_mod_mask gtk_accelerator_get_default_mod_mask = FuncLoader.LoadFunction<Accelerator.d_gtk_accelerator_get_default_mod_mask>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accelerator_get_default_mod_mask"));

		// Token: 0x04000566 RID: 1382
		private static Accelerator.d_gtk_accelerator_set_default_mod_mask gtk_accelerator_set_default_mod_mask = FuncLoader.LoadFunction<Accelerator.d_gtk_accelerator_set_default_mod_mask>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accelerator_set_default_mod_mask"));

		// Token: 0x04000567 RID: 1383
		private static Accelerator.d_gtk_accelerator_get_label gtk_accelerator_get_label = FuncLoader.LoadFunction<Accelerator.d_gtk_accelerator_get_label>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accelerator_get_label"));

		// Token: 0x04000568 RID: 1384
		private static Accelerator.d_gtk_accelerator_get_label_with_keycode gtk_accelerator_get_label_with_keycode = FuncLoader.LoadFunction<Accelerator.d_gtk_accelerator_get_label_with_keycode>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accelerator_get_label_with_keycode"));

		// Token: 0x04000569 RID: 1385
		private static Accelerator.d_gtk_accelerator_name gtk_accelerator_name = FuncLoader.LoadFunction<Accelerator.d_gtk_accelerator_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accelerator_name"));

		// Token: 0x0400056A RID: 1386
		private static Accelerator.d_gtk_accelerator_name_with_keycode gtk_accelerator_name_with_keycode = FuncLoader.LoadFunction<Accelerator.d_gtk_accelerator_name_with_keycode>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accelerator_name_with_keycode"));

		// Token: 0x0400056B RID: 1387
		private static Accelerator.d_gtk_accelerator_parse gtk_accelerator_parse = FuncLoader.LoadFunction<Accelerator.d_gtk_accelerator_parse>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accelerator_parse"));

		// Token: 0x0400056C RID: 1388
		private static Accelerator.d_gtk_accelerator_parse_with_keycode gtk_accelerator_parse_with_keycode = FuncLoader.LoadFunction<Accelerator.d_gtk_accelerator_parse_with_keycode>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accelerator_parse_with_keycode"));

		// Token: 0x0400056D RID: 1389
		private static Accelerator.d_gtk_accelerator_valid gtk_accelerator_valid = FuncLoader.LoadFunction<Accelerator.d_gtk_accelerator_valid>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accelerator_valid"));

		// Token: 0x02000989 RID: 2441
		// (Invoke) Token: 0x06004D3A RID: 19770
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_accelerator_get_default_mod_mask();

		// Token: 0x0200098A RID: 2442
		// (Invoke) Token: 0x06004D3E RID: 19774
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accelerator_set_default_mod_mask(int default_mod_mask);

		// Token: 0x0200098B RID: 2443
		// (Invoke) Token: 0x06004D42 RID: 19778
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_accelerator_get_label(uint accelerator_key, int accelerator_mods);

		// Token: 0x0200098C RID: 2444
		// (Invoke) Token: 0x06004D46 RID: 19782
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_accelerator_get_label_with_keycode(IntPtr display, uint accelerator_key, uint keycode, int accelerator_mods);

		// Token: 0x0200098D RID: 2445
		// (Invoke) Token: 0x06004D4A RID: 19786
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_accelerator_name(uint accelerator_key, int accelerator_mods);

		// Token: 0x0200098E RID: 2446
		// (Invoke) Token: 0x06004D4E RID: 19790
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_accelerator_name_with_keycode(IntPtr display, uint accelerator_key, uint keycode, int accelerator_mods);

		// Token: 0x0200098F RID: 2447
		// (Invoke) Token: 0x06004D52 RID: 19794
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accelerator_parse(IntPtr accelerator, out uint accelerator_key, out int accelerator_mods);

		// Token: 0x02000990 RID: 2448
		// (Invoke) Token: 0x06004D56 RID: 19798
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accelerator_parse_with_keycode(IntPtr accelerator, out uint accelerator_key, out uint accelerator_codes, out int accelerator_mods);

		// Token: 0x02000991 RID: 2449
		// (Invoke) Token: 0x06004D5A RID: 19802
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_accelerator_valid(uint keyval, int modifiers);
	}
}
