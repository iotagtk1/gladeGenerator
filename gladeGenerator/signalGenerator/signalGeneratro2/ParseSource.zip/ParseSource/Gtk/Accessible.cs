﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Atk;
using GLib;

namespace Gtk
{
	// Token: 0x02000104 RID: 260
	public class Accessible : Atk.Object
	{
		// Token: 0x06000B8F RID: 2959 RVA: 0x00022ECF File Offset: 0x000210CF
		public Accessible(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000B90 RID: 2960 RVA: 0x00022ED8 File Offset: 0x000210D8
		protected Accessible() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x17000261 RID: 609
		// (get) Token: 0x06000B91 RID: 2961 RVA: 0x00022EF7 File Offset: 0x000210F7
		// (set) Token: 0x06000B92 RID: 2962 RVA: 0x00022F13 File Offset: 0x00021113
		[Property("widget")]
		public Widget Widget
		{
			get
			{
				return GLib.Object.GetObject(Accessible.gtk_accessible_get_widget(base.Handle)) as Widget;
			}
			set
			{
				Accessible.gtk_accessible_set_widget(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x17000262 RID: 610
		// (get) Token: 0x06000B93 RID: 2963 RVA: 0x00022F35 File Offset: 0x00021135
		private static Accessible.ConnectWidgetDestroyedNativeDelegate ConnectWidgetDestroyedVMCallback
		{
			get
			{
				if (Accessible.ConnectWidgetDestroyed_cb_delegate == null)
				{
					Accessible.ConnectWidgetDestroyed_cb_delegate = new Accessible.ConnectWidgetDestroyedNativeDelegate(Accessible.ConnectWidgetDestroyed_cb);
				}
				return Accessible.ConnectWidgetDestroyed_cb_delegate;
			}
		}

		// Token: 0x06000B94 RID: 2964 RVA: 0x00022F54 File Offset: 0x00021154
		private static void OverrideConnectWidgetDestroyed(GType gtype)
		{
			Accessible.OverrideConnectWidgetDestroyed(gtype, Accessible.ConnectWidgetDestroyedVMCallback);
		}

		// Token: 0x06000B95 RID: 2965 RVA: 0x00022F64 File Offset: 0x00021164
		private unsafe static void OverrideConnectWidgetDestroyed(GType gtype, Accessible.ConnectWidgetDestroyedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Accessible.class_abi.GetFieldOffset("connect_widget_destroyed");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000B96 RID: 2966 RVA: 0x00022F98 File Offset: 0x00021198
		private static void ConnectWidgetDestroyed_cb(IntPtr inst)
		{
			try
			{
				(GLib.Object.GetObject(inst, false) as Accessible).OnConnectWidgetDestroyed();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000B97 RID: 2967 RVA: 0x00022FD0 File Offset: 0x000211D0
		[DefaultSignalHandler(Type = typeof(Accessible), ConnectionMethod = "OverrideConnectWidgetDestroyed")]
		protected virtual void OnConnectWidgetDestroyed()
		{
			this.InternalConnectWidgetDestroyed();
		}

		// Token: 0x06000B98 RID: 2968 RVA: 0x00022FD8 File Offset: 0x000211D8
		private void InternalConnectWidgetDestroyed()
		{
			Accessible.ConnectWidgetDestroyedNativeDelegate connectWidgetDestroyedNativeDelegate = Accessible.class_abi.BaseOverride(base.LookupGType(), "connect_widget_destroyed");
			if (connectWidgetDestroyedNativeDelegate == null)
			{
				return;
			}
			connectWidgetDestroyedNativeDelegate(base.Handle);
		}

		// Token: 0x17000263 RID: 611
		// (get) Token: 0x06000B99 RID: 2969 RVA: 0x0002300B File Offset: 0x0002120B
		private static Accessible.WidgetSetNativeDelegate WidgetSetVMCallback
		{
			get
			{
				if (Accessible.WidgetSet_cb_delegate == null)
				{
					Accessible.WidgetSet_cb_delegate = new Accessible.WidgetSetNativeDelegate(Accessible.WidgetSet_cb);
				}
				return Accessible.WidgetSet_cb_delegate;
			}
		}

		// Token: 0x06000B9A RID: 2970 RVA: 0x0002302A File Offset: 0x0002122A
		private static void OverrideWidgetSet(GType gtype)
		{
			Accessible.OverrideWidgetSet(gtype, Accessible.WidgetSetVMCallback);
		}

		// Token: 0x06000B9B RID: 2971 RVA: 0x00023038 File Offset: 0x00021238
		private unsafe static void OverrideWidgetSet(GType gtype, Accessible.WidgetSetNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Accessible.class_abi.GetFieldOffset("widget_set");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000B9C RID: 2972 RVA: 0x0002306C File Offset: 0x0002126C
		private static void WidgetSet_cb(IntPtr inst)
		{
			try
			{
				(GLib.Object.GetObject(inst, false) as Accessible).OnWidgetSet();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000B9D RID: 2973 RVA: 0x000230A4 File Offset: 0x000212A4
		[DefaultSignalHandler(Type = typeof(Accessible), ConnectionMethod = "OverrideWidgetSet")]
		protected virtual void OnWidgetSet()
		{
			this.InternalWidgetSet();
		}

		// Token: 0x06000B9E RID: 2974 RVA: 0x000230AC File Offset: 0x000212AC
		private void InternalWidgetSet()
		{
			Accessible.WidgetSetNativeDelegate widgetSetNativeDelegate = Accessible.class_abi.BaseOverride(base.LookupGType(), "widget_set");
			if (widgetSetNativeDelegate == null)
			{
				return;
			}
			widgetSetNativeDelegate(base.Handle);
		}

		// Token: 0x17000264 RID: 612
		// (get) Token: 0x06000B9F RID: 2975 RVA: 0x000230DF File Offset: 0x000212DF
		private static Accessible.WidgetUnsetNativeDelegate WidgetUnsetVMCallback
		{
			get
			{
				if (Accessible.WidgetUnset_cb_delegate == null)
				{
					Accessible.WidgetUnset_cb_delegate = new Accessible.WidgetUnsetNativeDelegate(Accessible.WidgetUnset_cb);
				}
				return Accessible.WidgetUnset_cb_delegate;
			}
		}

		// Token: 0x06000BA0 RID: 2976 RVA: 0x000230FE File Offset: 0x000212FE
		private static void OverrideWidgetUnset(GType gtype)
		{
			Accessible.OverrideWidgetUnset(gtype, Accessible.WidgetUnsetVMCallback);
		}

		// Token: 0x06000BA1 RID: 2977 RVA: 0x0002310C File Offset: 0x0002130C
		private unsafe static void OverrideWidgetUnset(GType gtype, Accessible.WidgetUnsetNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Accessible.class_abi.GetFieldOffset("widget_unset");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000BA2 RID: 2978 RVA: 0x00023140 File Offset: 0x00021340
		private static void WidgetUnset_cb(IntPtr inst)
		{
			try
			{
				(GLib.Object.GetObject(inst, false) as Accessible).OnWidgetUnset();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000BA3 RID: 2979 RVA: 0x00023178 File Offset: 0x00021378
		[DefaultSignalHandler(Type = typeof(Accessible), ConnectionMethod = "OverrideWidgetUnset")]
		protected virtual void OnWidgetUnset()
		{
			this.InternalWidgetUnset();
		}

		// Token: 0x06000BA4 RID: 2980 RVA: 0x00023180 File Offset: 0x00021380
		private void InternalWidgetUnset()
		{
			Accessible.WidgetUnsetNativeDelegate widgetUnsetNativeDelegate = Accessible.class_abi.BaseOverride(base.LookupGType(), "widget_unset");
			if (widgetUnsetNativeDelegate == null)
			{
				return;
			}
			widgetUnsetNativeDelegate(base.Handle);
		}

		// Token: 0x17000265 RID: 613
		// (get) Token: 0x06000BA5 RID: 2981 RVA: 0x000231B4 File Offset: 0x000213B4
		public new static AbiStruct class_abi
		{
			get
			{
				if (Accessible._class_abi == null)
				{
					Accessible._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("connect_widget_destroyed", Atk.Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "widget_set", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("widget_set", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "connect_widget_destroyed", "widget_unset", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("widget_unset", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "widget_set", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "widget_unset", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Accessible._class_abi;
			}
		}

		// Token: 0x06000BA6 RID: 2982 RVA: 0x0002330B File Offset: 0x0002150B
		[Obsolete]
		public void ConnectWidgetDestroyed()
		{
			Accessible.gtk_accessible_connect_widget_destroyed(base.Handle);
		}

		// Token: 0x17000266 RID: 614
		// (get) Token: 0x06000BA7 RID: 2983 RVA: 0x00023320 File Offset: 0x00021520
		public new static GType GType
		{
			get
			{
				IntPtr val = Accessible.gtk_accessible_get_type();
				return new GType(val);
			}
		}

		// Token: 0x17000267 RID: 615
		// (get) Token: 0x06000BA8 RID: 2984 RVA: 0x00023340 File Offset: 0x00021540
		public new static AbiStruct abi_info
		{
			get
			{
				if (Accessible._abi_info == null)
				{
					Accessible._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Atk.Object.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Accessible._abi_info;
			}
		}

		// Token: 0x040005A5 RID: 1445
		private static Accessible.d_gtk_accessible_get_widget gtk_accessible_get_widget = FuncLoader.LoadFunction<Accessible.d_gtk_accessible_get_widget>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accessible_get_widget"));

		// Token: 0x040005A6 RID: 1446
		private static Accessible.d_gtk_accessible_set_widget gtk_accessible_set_widget = FuncLoader.LoadFunction<Accessible.d_gtk_accessible_set_widget>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accessible_set_widget"));

		// Token: 0x040005A7 RID: 1447
		private static Accessible.ConnectWidgetDestroyedNativeDelegate ConnectWidgetDestroyed_cb_delegate;

		// Token: 0x040005A8 RID: 1448
		private static Accessible.WidgetSetNativeDelegate WidgetSet_cb_delegate;

		// Token: 0x040005A9 RID: 1449
		private static Accessible.WidgetUnsetNativeDelegate WidgetUnset_cb_delegate;

		// Token: 0x040005AA RID: 1450
		private static AbiStruct _class_abi = null;

		// Token: 0x040005AB RID: 1451
		private static Accessible.d_gtk_accessible_connect_widget_destroyed gtk_accessible_connect_widget_destroyed = FuncLoader.LoadFunction<Accessible.d_gtk_accessible_connect_widget_destroyed>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accessible_connect_widget_destroyed"));

		// Token: 0x040005AC RID: 1452
		private static Accessible.d_gtk_accessible_get_type gtk_accessible_get_type = FuncLoader.LoadFunction<Accessible.d_gtk_accessible_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accessible_get_type"));

		// Token: 0x040005AD RID: 1453
		private static AbiStruct _abi_info = null;

		// Token: 0x020009BB RID: 2491
		// (Invoke) Token: 0x06004E02 RID: 19970
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_accessible_get_widget(IntPtr raw);

		// Token: 0x020009BC RID: 2492
		// (Invoke) Token: 0x06004E06 RID: 19974
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accessible_set_widget(IntPtr raw, IntPtr widget);

		// Token: 0x020009BD RID: 2493
		// (Invoke) Token: 0x06004E0A RID: 19978
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ConnectWidgetDestroyedNativeDelegate(IntPtr inst);

		// Token: 0x020009BE RID: 2494
		// (Invoke) Token: 0x06004E0E RID: 19982
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void WidgetSetNativeDelegate(IntPtr inst);

		// Token: 0x020009BF RID: 2495
		// (Invoke) Token: 0x06004E12 RID: 19986
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void WidgetUnsetNativeDelegate(IntPtr inst);

		// Token: 0x020009C0 RID: 2496
		// (Invoke) Token: 0x06004E16 RID: 19990
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accessible_connect_widget_destroyed(IntPtr raw);

		// Token: 0x020009C1 RID: 2497
		// (Invoke) Token: 0x06004E1A RID: 19994
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_accessible_get_type();
	}
}
