﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x020001BA RID: 442
	public class CreateMenuProxyArgs : SignalArgs
	{
	}
}
