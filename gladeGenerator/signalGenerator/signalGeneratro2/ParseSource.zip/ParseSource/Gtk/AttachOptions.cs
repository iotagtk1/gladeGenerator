﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000136 RID: 310
	[Flags]
	[GType(typeof(AttachOptionsGType))]
	public enum AttachOptions
	{
		// Token: 0x040006B8 RID: 1720
		Expand = 1,
		// Token: 0x040006B9 RID: 1721
		Shrink = 2,
		// Token: 0x040006BA RID: 1722
		Fill = 4
	}
}
