﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x020000F1 RID: 241
	public class AccelCanActivateArgs : SignalArgs
	{
		// Token: 0x17000244 RID: 580
		// (get) Token: 0x06000B06 RID: 2822 RVA: 0x00021895 File Offset: 0x0001FA95
		public uint SignalId
		{
			get
			{
				return (uint)base.Args[0];
			}
		}
	}
}
