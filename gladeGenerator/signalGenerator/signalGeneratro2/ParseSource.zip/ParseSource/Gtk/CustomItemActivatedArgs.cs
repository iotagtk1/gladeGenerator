﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000210 RID: 528
	public class CustomItemActivatedArgs : SignalArgs
	{
		// Token: 0x1700046A RID: 1130
		// (get) Token: 0x0600123F RID: 4671 RVA: 0x000350DA File Offset: 0x000332DA
		public string ItemName
		{
			get
			{
				return (string)base.Args[0];
			}
		}
	}
}
