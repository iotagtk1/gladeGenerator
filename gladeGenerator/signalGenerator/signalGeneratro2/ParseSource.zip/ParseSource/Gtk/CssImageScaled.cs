﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001DB RID: 475
	public class CssImageScaled : Opaque
	{
		// Token: 0x060011B1 RID: 4529 RVA: 0x000340A7 File Offset: 0x000322A7
		public CssImageScaled(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700042C RID: 1068
		// (get) Token: 0x060011B2 RID: 4530 RVA: 0x000340B0 File Offset: 0x000322B0
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImageScaled._abi_info == null)
				{
					CssImageScaled._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImageScaled._abi_info;
			}
		}

		// Token: 0x0400083B RID: 2107
		private static AbiStruct _abi_info;
	}
}
