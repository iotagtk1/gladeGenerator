﻿using System;
using Gdk;

namespace Gtk
{
	// Token: 0x02000194 RID: 404
	// (Invoke) Token: 0x060010A5 RID: 4261
	public delegate void ClipboardTargetsReceivedFunc(Clipboard clipboard, Atom atoms, int n_atoms);
}
