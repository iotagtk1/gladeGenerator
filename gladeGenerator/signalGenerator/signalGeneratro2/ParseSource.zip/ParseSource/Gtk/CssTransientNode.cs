﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x02000205 RID: 517
	public class CssTransientNode : Opaque
	{
		// Token: 0x06001224 RID: 4644 RVA: 0x00034F7F File Offset: 0x0003317F
		public CssTransientNode(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000460 RID: 1120
		// (get) Token: 0x06001225 RID: 4645 RVA: 0x00034F88 File Offset: 0x00033188
		public static AbiStruct abi_info
		{
			get
			{
				if (CssTransientNode._abi_info == null)
				{
					CssTransientNode._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssTransientNode._abi_info;
			}
		}

		// Token: 0x0400088B RID: 2187
		private static AbiStruct _abi_info;
	}
}
