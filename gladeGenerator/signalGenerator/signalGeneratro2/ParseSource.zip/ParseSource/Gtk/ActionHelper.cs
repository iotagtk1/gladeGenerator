﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x02000109 RID: 265
	public class ActionHelper : Object, IActionObserver, IWrapper
	{
		// Token: 0x06000BD0 RID: 3024 RVA: 0x00023BAF File Offset: 0x00021DAF
		public ActionHelper(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000BD1 RID: 3025 RVA: 0x00023BB8 File Offset: 0x00021DB8
		public ActionHelper(IActionable widget) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(ActionHelper))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			this.Raw = ActionHelper.gtk_action_helper_new((widget == null) ? IntPtr.Zero : ((widget is Object) ? (widget as Object).Handle : (widget as ActionableAdapter).Handle));
		}

		// Token: 0x17000276 RID: 630
		// (get) Token: 0x06000BD2 RID: 3026 RVA: 0x00023C40 File Offset: 0x00021E40
		[Property("enabled")]
		public bool Enabled
		{
			get
			{
				return ActionHelper.gtk_action_helper_get_enabled(base.Handle);
			}
		}

		// Token: 0x17000277 RID: 631
		// (get) Token: 0x06000BD3 RID: 3027 RVA: 0x00023C52 File Offset: 0x00021E52
		[Property("active")]
		public bool Active
		{
			get
			{
				return ActionHelper.gtk_action_helper_get_active(base.Handle);
			}
		}

		// Token: 0x17000278 RID: 632
		// (get) Token: 0x06000BD4 RID: 3028 RVA: 0x00023C64 File Offset: 0x00021E64
		[Property("role")]
		public ButtonRole Role
		{
			get
			{
				Value property = base.GetProperty("role");
				ButtonRole result = (ButtonRole)((Enum)property);
				property.Dispose();
				return result;
			}
		}

		// Token: 0x06000BD5 RID: 3029 RVA: 0x00023C8F File Offset: 0x00021E8F
		public void Activate()
		{
			ActionHelper.gtk_action_helper_activate(base.Handle);
		}

		// Token: 0x17000279 RID: 633
		// (get) Token: 0x06000BD6 RID: 3030 RVA: 0x00023CA1 File Offset: 0x00021EA1
		// (set) Token: 0x06000BD7 RID: 3031 RVA: 0x00023CB8 File Offset: 0x00021EB8
		public string ActionName
		{
			get
			{
				return Marshaller.Utf8PtrToString(ActionHelper.gtk_action_helper_get_action_name(base.Handle));
			}
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				ActionHelper.gtk_action_helper_set_action_name(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x1700027A RID: 634
		// (get) Token: 0x06000BD8 RID: 3032 RVA: 0x00023CE3 File Offset: 0x00021EE3
		// (set) Token: 0x06000BD9 RID: 3033 RVA: 0x00023CFA File Offset: 0x00021EFA
		public Variant ActionTargetValue
		{
			get
			{
				return new Variant(ActionHelper.gtk_action_helper_get_action_target_value(base.Handle));
			}
			set
			{
				ActionHelper.gtk_action_helper_set_action_target_value(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x1700027B RID: 635
		// (get) Token: 0x06000BDA RID: 3034 RVA: 0x00023D1C File Offset: 0x00021F1C
		public new static GType GType
		{
			get
			{
				IntPtr val = ActionHelper.gtk_action_helper_get_type();
				return new GType(val);
			}
		}

		// Token: 0x06000BDB RID: 3035 RVA: 0x00023D3C File Offset: 0x00021F3C
		public void ActionAdded(IActionObservable observable, string action_name, VariantType parameter_type, bool enabled, Variant state)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			ActionHelper.gtk_action_observer_action_added(base.Handle, (observable == null) ? IntPtr.Zero : ((observable is Object) ? (observable as Object).Handle : (observable as ActionObservableAdapter).Handle), intPtr, (parameter_type == null) ? IntPtr.Zero : parameter_type.Handle, enabled, (state == null) ? IntPtr.Zero : state.Handle);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000BDC RID: 3036 RVA: 0x00023DB8 File Offset: 0x00021FB8
		public void ActionEnabledChanged(IActionObservable observable, string action_name, bool enabled)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			ActionHelper.gtk_action_observer_action_enabled_changed(base.Handle, (observable == null) ? IntPtr.Zero : ((observable is Object) ? (observable as Object).Handle : (observable as ActionObservableAdapter).Handle), intPtr, enabled);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000BDD RID: 3037 RVA: 0x00023E10 File Offset: 0x00022010
		public void ActionRemoved(IActionObservable observable, string action_name)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			ActionHelper.gtk_action_observer_action_removed(base.Handle, (observable == null) ? IntPtr.Zero : ((observable is Object) ? (observable as Object).Handle : (observable as ActionObservableAdapter).Handle), intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000BDE RID: 3038 RVA: 0x00023E68 File Offset: 0x00022068
		public void ActionStateChanged(IActionObservable observable, string action_name, Variant state)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			ActionHelper.gtk_action_observer_action_state_changed(base.Handle, (observable == null) ? IntPtr.Zero : ((observable is Object) ? (observable as Object).Handle : (observable as ActionObservableAdapter).Handle), intPtr, (state == null) ? IntPtr.Zero : state.Handle);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000BDF RID: 3039 RVA: 0x00023ED0 File Offset: 0x000220D0
		public void PrimaryAccelChanged(IActionObservable observable, string action_name, string action_and_target)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			IntPtr intPtr2 = Marshaller.StringToPtrGStrdup(action_and_target);
			ActionHelper.gtk_action_observer_primary_accel_changed(base.Handle, (observable == null) ? IntPtr.Zero : ((observable is Object) ? (observable as Object).Handle : (observable as ActionObservableAdapter).Handle), intPtr, intPtr2);
			Marshaller.Free(intPtr);
			Marshaller.Free(intPtr2);
		}

		// Token: 0x040005C0 RID: 1472
		private static ActionHelper.d_gtk_action_helper_new gtk_action_helper_new = FuncLoader.LoadFunction<ActionHelper.d_gtk_action_helper_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_helper_new"));

		// Token: 0x040005C1 RID: 1473
		private static ActionHelper.d_gtk_action_helper_get_enabled gtk_action_helper_get_enabled = FuncLoader.LoadFunction<ActionHelper.d_gtk_action_helper_get_enabled>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_helper_get_enabled"));

		// Token: 0x040005C2 RID: 1474
		private static ActionHelper.d_gtk_action_helper_get_active gtk_action_helper_get_active = FuncLoader.LoadFunction<ActionHelper.d_gtk_action_helper_get_active>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_helper_get_active"));

		// Token: 0x040005C3 RID: 1475
		private static ActionHelper.d_gtk_action_helper_activate gtk_action_helper_activate = FuncLoader.LoadFunction<ActionHelper.d_gtk_action_helper_activate>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_helper_activate"));

		// Token: 0x040005C4 RID: 1476
		private static ActionHelper.d_gtk_action_helper_get_action_name gtk_action_helper_get_action_name = FuncLoader.LoadFunction<ActionHelper.d_gtk_action_helper_get_action_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_helper_get_action_name"));

		// Token: 0x040005C5 RID: 1477
		private static ActionHelper.d_gtk_action_helper_set_action_name gtk_action_helper_set_action_name = FuncLoader.LoadFunction<ActionHelper.d_gtk_action_helper_set_action_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_helper_set_action_name"));

		// Token: 0x040005C6 RID: 1478
		private static ActionHelper.d_gtk_action_helper_get_action_target_value gtk_action_helper_get_action_target_value = FuncLoader.LoadFunction<ActionHelper.d_gtk_action_helper_get_action_target_value>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_helper_get_action_target_value"));

		// Token: 0x040005C7 RID: 1479
		private static ActionHelper.d_gtk_action_helper_set_action_target_value gtk_action_helper_set_action_target_value = FuncLoader.LoadFunction<ActionHelper.d_gtk_action_helper_set_action_target_value>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_helper_set_action_target_value"));

		// Token: 0x040005C8 RID: 1480
		private static ActionHelper.d_gtk_action_helper_get_type gtk_action_helper_get_type = FuncLoader.LoadFunction<ActionHelper.d_gtk_action_helper_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_helper_get_type"));

		// Token: 0x040005C9 RID: 1481
		private static ActionHelper.d_gtk_action_observer_action_added gtk_action_observer_action_added = FuncLoader.LoadFunction<ActionHelper.d_gtk_action_observer_action_added>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_observer_action_added"));

		// Token: 0x040005CA RID: 1482
		private static ActionHelper.d_gtk_action_observer_action_enabled_changed gtk_action_observer_action_enabled_changed = FuncLoader.LoadFunction<ActionHelper.d_gtk_action_observer_action_enabled_changed>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_observer_action_enabled_changed"));

		// Token: 0x040005CB RID: 1483
		private static ActionHelper.d_gtk_action_observer_action_removed gtk_action_observer_action_removed = FuncLoader.LoadFunction<ActionHelper.d_gtk_action_observer_action_removed>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_observer_action_removed"));

		// Token: 0x040005CC RID: 1484
		private static ActionHelper.d_gtk_action_observer_action_state_changed gtk_action_observer_action_state_changed = FuncLoader.LoadFunction<ActionHelper.d_gtk_action_observer_action_state_changed>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_observer_action_state_changed"));

		// Token: 0x040005CD RID: 1485
		private static ActionHelper.d_gtk_action_observer_primary_accel_changed gtk_action_observer_primary_accel_changed = FuncLoader.LoadFunction<ActionHelper.d_gtk_action_observer_primary_accel_changed>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_observer_primary_accel_changed"));

		// Token: 0x020009D4 RID: 2516
		// (Invoke) Token: 0x06004E63 RID: 20067
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_helper_new(IntPtr widget);

		// Token: 0x020009D5 RID: 2517
		// (Invoke) Token: 0x06004E67 RID: 20071
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_action_helper_get_enabled(IntPtr raw);

		// Token: 0x020009D6 RID: 2518
		// (Invoke) Token: 0x06004E6B RID: 20075
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_action_helper_get_active(IntPtr raw);

		// Token: 0x020009D7 RID: 2519
		// (Invoke) Token: 0x06004E6F RID: 20079
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_helper_activate(IntPtr raw);

		// Token: 0x020009D8 RID: 2520
		// (Invoke) Token: 0x06004E73 RID: 20083
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_helper_get_action_name(IntPtr raw);

		// Token: 0x020009D9 RID: 2521
		// (Invoke) Token: 0x06004E77 RID: 20087
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_helper_set_action_name(IntPtr raw, IntPtr action_name);

		// Token: 0x020009DA RID: 2522
		// (Invoke) Token: 0x06004E7B RID: 20091
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_helper_get_action_target_value(IntPtr raw);

		// Token: 0x020009DB RID: 2523
		// (Invoke) Token: 0x06004E7F RID: 20095
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_helper_set_action_target_value(IntPtr raw, IntPtr action_target);

		// Token: 0x020009DC RID: 2524
		// (Invoke) Token: 0x06004E83 RID: 20099
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_helper_get_type();

		// Token: 0x020009DD RID: 2525
		// (Invoke) Token: 0x06004E87 RID: 20103
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_observer_action_added(IntPtr raw, IntPtr observable, IntPtr action_name, IntPtr parameter_type, bool enabled, IntPtr state);

		// Token: 0x020009DE RID: 2526
		// (Invoke) Token: 0x06004E8B RID: 20107
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_observer_action_enabled_changed(IntPtr raw, IntPtr observable, IntPtr action_name, bool enabled);

		// Token: 0x020009DF RID: 2527
		// (Invoke) Token: 0x06004E8F RID: 20111
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_observer_action_removed(IntPtr raw, IntPtr observable, IntPtr action_name);

		// Token: 0x020009E0 RID: 2528
		// (Invoke) Token: 0x06004E93 RID: 20115
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_observer_action_state_changed(IntPtr raw, IntPtr observable, IntPtr action_name, IntPtr state);

		// Token: 0x020009E1 RID: 2529
		// (Invoke) Token: 0x06004E97 RID: 20119
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_observer_primary_accel_changed(IntPtr raw, IntPtr observable, IntPtr action_name, IntPtr action_and_target);
	}
}
