﻿using System;

namespace Gtk
{
	// Token: 0x020000E0 RID: 224
	public sealed class ChildPropertyAttribute : Attribute
	{
		// Token: 0x060006CF RID: 1743 RVA: 0x00013FDB File Offset: 0x000121DB
		public ChildPropertyAttribute(string name)
		{
			this.name = name;
		}

		// Token: 0x1700011D RID: 285
		// (get) Token: 0x060006D0 RID: 1744 RVA: 0x00013FEA File Offset: 0x000121EA
		// (set) Token: 0x060006D1 RID: 1745 RVA: 0x00013FF2 File Offset: 0x000121F2
		public string Name
		{
			get
			{
				return this.name;
			}
			set
			{
				this.name = value;
			}
		}

		// Token: 0x0400035F RID: 863
		private string name;
	}
}
