﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Cairo;
using GLib;

namespace Gtk
{
	// Token: 0x02000183 RID: 387
	public class CheckButton : ToggleButton
	{
		// Token: 0x06001061 RID: 4193 RVA: 0x0003184E File Offset: 0x0002FA4E
		public CheckButton(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06001062 RID: 4194 RVA: 0x00031858 File Offset: 0x0002FA58
		public CheckButton() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(CheckButton))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = CheckButton.gtk_check_button_new();
		}

		// Token: 0x06001063 RID: 4195 RVA: 0x000318AC File Offset: 0x0002FAAC
		public new static CheckButton NewWithLabel(string label)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(label);
			CheckButton result = new CheckButton(CheckButton.gtk_check_button_new_with_label(intPtr));
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x06001064 RID: 4196 RVA: 0x000318D8 File Offset: 0x0002FAD8
		public CheckButton(string label) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(CheckButton))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				list2.Add("label");
				list.Add(new Value(label));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(label);
			this.Raw = CheckButton.gtk_check_button_new_with_mnemonic(intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x170003C4 RID: 964
		// (get) Token: 0x06001065 RID: 4197 RVA: 0x0003195C File Offset: 0x0002FB5C
		[Property("indicator-size")]
		public int IndicatorSize
		{
			get
			{
				Value property = base.GetProperty("indicator-size");
				int result = (int)property;
				property.Dispose();
				return result;
			}
		}

		// Token: 0x170003C5 RID: 965
		// (get) Token: 0x06001066 RID: 4198 RVA: 0x00031984 File Offset: 0x0002FB84
		[Property("indicator-spacing")]
		public int IndicatorSpacing
		{
			get
			{
				Value property = base.GetProperty("indicator-spacing");
				int result = (int)property;
				property.Dispose();
				return result;
			}
		}

		// Token: 0x170003C6 RID: 966
		// (get) Token: 0x06001067 RID: 4199 RVA: 0x000319AA File Offset: 0x0002FBAA
		private static CheckButton.DrawIndicatorNativeDelegate DrawIndicatorVMCallback
		{
			get
			{
				if (CheckButton.DrawIndicator_cb_delegate == null)
				{
					CheckButton.DrawIndicator_cb_delegate = new CheckButton.DrawIndicatorNativeDelegate(CheckButton.DrawIndicator_cb);
				}
				return CheckButton.DrawIndicator_cb_delegate;
			}
		}

		// Token: 0x06001068 RID: 4200 RVA: 0x000319C9 File Offset: 0x0002FBC9
		private static void OverrideDrawIndicator(GType gtype)
		{
			CheckButton.OverrideDrawIndicator(gtype, CheckButton.DrawIndicatorVMCallback);
		}

		// Token: 0x06001069 RID: 4201 RVA: 0x000319D8 File Offset: 0x0002FBD8
		private unsafe static void OverrideDrawIndicator(GType gtype, CheckButton.DrawIndicatorNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CheckButton.class_abi.GetFieldOffset("draw_indicator");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600106A RID: 4202 RVA: 0x00031A0C File Offset: 0x0002FC0C
		private static void DrawIndicator_cb(IntPtr inst, IntPtr cr)
		{
			Context context = null;
			try
			{
				CheckButton checkButton = Object.GetObject(inst, false) as CheckButton;
				context = new Context(cr, false);
				checkButton.OnDrawIndicator(context);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
			finally
			{
				IDisposable disposable = context;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
		}

		// Token: 0x0600106B RID: 4203 RVA: 0x00031A68 File Offset: 0x0002FC68
		[DefaultSignalHandler(Type = typeof(CheckButton), ConnectionMethod = "OverrideDrawIndicator")]
		protected virtual void OnDrawIndicator(Context cr)
		{
			this.InternalDrawIndicator(cr);
		}

		// Token: 0x0600106C RID: 4204 RVA: 0x00031A74 File Offset: 0x0002FC74
		private void InternalDrawIndicator(Context cr)
		{
			CheckButton.DrawIndicatorNativeDelegate drawIndicatorNativeDelegate = CheckButton.class_abi.BaseOverride(base.LookupGType(), "draw_indicator");
			if (drawIndicatorNativeDelegate == null)
			{
				return;
			}
			drawIndicatorNativeDelegate(base.Handle, (cr == null) ? IntPtr.Zero : cr.Handle);
		}

		// Token: 0x170003C7 RID: 967
		// (get) Token: 0x0600106D RID: 4205 RVA: 0x00031AB8 File Offset: 0x0002FCB8
		public new static AbiStruct class_abi
		{
			get
			{
				if (CheckButton._class_abi == null)
				{
					CheckButton._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("draw_indicator", ToggleButton.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved1", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved1", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "draw_indicator", "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CheckButton._class_abi;
			}
		}

		// Token: 0x170003C8 RID: 968
		// (get) Token: 0x0600106E RID: 4206 RVA: 0x00031C10 File Offset: 0x0002FE10
		public new static GType GType
		{
			get
			{
				IntPtr val = CheckButton.gtk_check_button_get_type();
				return new GType(val);
			}
		}

		// Token: 0x170003C9 RID: 969
		// (get) Token: 0x0600106F RID: 4207 RVA: 0x00031C2E File Offset: 0x0002FE2E
		public new static AbiStruct abi_info
		{
			get
			{
				if (CheckButton._abi_info == null)
				{
					CheckButton._abi_info = new AbiStruct(ToggleButton.abi_info.Fields);
				}
				return CheckButton._abi_info;
			}
		}

		// Token: 0x040007CD RID: 1997
		private static CheckButton.d_gtk_check_button_new gtk_check_button_new = FuncLoader.LoadFunction<CheckButton.d_gtk_check_button_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_check_button_new"));

		// Token: 0x040007CE RID: 1998
		private static CheckButton.d_gtk_check_button_new_with_label gtk_check_button_new_with_label = FuncLoader.LoadFunction<CheckButton.d_gtk_check_button_new_with_label>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_check_button_new_with_label"));

		// Token: 0x040007CF RID: 1999
		private static CheckButton.d_gtk_check_button_new_with_mnemonic gtk_check_button_new_with_mnemonic = FuncLoader.LoadFunction<CheckButton.d_gtk_check_button_new_with_mnemonic>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_check_button_new_with_mnemonic"));

		// Token: 0x040007D0 RID: 2000
		private static CheckButton.DrawIndicatorNativeDelegate DrawIndicator_cb_delegate;

		// Token: 0x040007D1 RID: 2001
		private static AbiStruct _class_abi = null;

		// Token: 0x040007D2 RID: 2002
		private static CheckButton.d_gtk_check_button_get_type gtk_check_button_get_type = FuncLoader.LoadFunction<CheckButton.d_gtk_check_button_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_check_button_get_type"));

		// Token: 0x040007D3 RID: 2003
		private static AbiStruct _abi_info = null;

		// Token: 0x02000B35 RID: 2869
		// (Invoke) Token: 0x060053E1 RID: 21473
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_check_button_new();

		// Token: 0x02000B36 RID: 2870
		// (Invoke) Token: 0x060053E5 RID: 21477
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_check_button_new_with_label(IntPtr label);

		// Token: 0x02000B37 RID: 2871
		// (Invoke) Token: 0x060053E9 RID: 21481
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_check_button_new_with_mnemonic(IntPtr label);

		// Token: 0x02000B38 RID: 2872
		// (Invoke) Token: 0x060053ED RID: 21485
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DrawIndicatorNativeDelegate(IntPtr inst, IntPtr cr);

		// Token: 0x02000B39 RID: 2873
		// (Invoke) Token: 0x060053F1 RID: 21489
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_check_button_get_type();
	}
}
