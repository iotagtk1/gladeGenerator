﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001F9 RID: 505
	public class CssSelectorClass : Opaque
	{
		// Token: 0x0600120C RID: 4620 RVA: 0x00034DB7 File Offset: 0x00032FB7
		public CssSelectorClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000454 RID: 1108
		// (get) Token: 0x0600120D RID: 4621 RVA: 0x00034DC0 File Offset: 0x00032FC0
		public static AbiStruct abi_info
		{
			get
			{
				if (CssSelectorClass._abi_info == null)
				{
					CssSelectorClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssSelectorClass._abi_info;
			}
		}

		// Token: 0x0400087F RID: 2175
		private static AbiStruct _abi_info;
	}
}
