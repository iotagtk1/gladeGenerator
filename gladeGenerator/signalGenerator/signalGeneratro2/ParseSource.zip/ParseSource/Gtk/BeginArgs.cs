﻿using System;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x0200013B RID: 315
	public class BeginArgs : SignalArgs
	{
		// Token: 0x170002FC RID: 764
		// (get) Token: 0x06000DD1 RID: 3537 RVA: 0x00029D70 File Offset: 0x00027F70
		public EventSequence Sequence
		{
			get
			{
				return (EventSequence)base.Args[0];
			}
		}
	}
}
