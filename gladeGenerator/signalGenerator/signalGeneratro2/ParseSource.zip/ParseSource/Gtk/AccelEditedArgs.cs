﻿using System;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x020000F7 RID: 247
	public class AccelEditedArgs : SignalArgs
	{
		// Token: 0x17000249 RID: 585
		// (get) Token: 0x06000B1A RID: 2842 RVA: 0x000218F8 File Offset: 0x0001FAF8
		public string PathString
		{
			get
			{
				return (string)base.Args[0];
			}
		}

		// Token: 0x1700024A RID: 586
		// (get) Token: 0x06000B1B RID: 2843 RVA: 0x00021907 File Offset: 0x0001FB07
		public uint AccelKey
		{
			get
			{
				return (uint)base.Args[1];
			}
		}

		// Token: 0x1700024B RID: 587
		// (get) Token: 0x06000B1C RID: 2844 RVA: 0x00021916 File Offset: 0x0001FB16
		public ModifierType AccelMods
		{
			get
			{
				return (ModifierType)base.Args[2];
			}
		}

		// Token: 0x1700024C RID: 588
		// (get) Token: 0x06000B1D RID: 2845 RVA: 0x00021925 File Offset: 0x0001FB25
		public uint HardwareKeycode
		{
			get
			{
				return (uint)base.Args[3];
			}
		}
	}
}
