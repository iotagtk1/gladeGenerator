﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x0200018A RID: 394
	public class ChildAttachedArgs : SignalArgs
	{
		// Token: 0x170003CE RID: 974
		// (get) Token: 0x06001084 RID: 4228 RVA: 0x00031D38 File Offset: 0x0002FF38
		public Widget Child
		{
			get
			{
				return (Widget)base.Args[0];
			}
		}
	}
}
