﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x0200010D RID: 269
	public class ActivatableAdapter : GInterfaceAdapter, IActivatable, IWrapper
	{
		// Token: 0x06000C4B RID: 3147 RVA: 0x00025920 File Offset: 0x00023B20
		static ActivatableAdapter()
		{
			GType.Register(ActivatableAdapter._gtype, typeof(ActivatableAdapter));
			ActivatableAdapter.iface.SyncActionProperties = new ActivatableAdapter.SyncActionPropertiesNativeDelegate(ActivatableAdapter.SyncActionProperties_cb);
		}

		// Token: 0x06000C4C RID: 3148 RVA: 0x00025A34 File Offset: 0x00023C34
		private static void SyncActionProperties_cb(IntPtr inst, IntPtr action)
		{
			try
			{
				(Object.GetObject(inst, false) as IActivatableImplementor).SyncActionProperties(Object.GetObject(action) as Action);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000C4D RID: 3149 RVA: 0x00025A78 File Offset: 0x00023C78
		private static void Initialize(IntPtr ptr, IntPtr data)
		{
			IntPtr ptr2 = new IntPtr(ptr.ToInt64() + (long)ActivatableAdapter.class_offset);
			ActivatableAdapter.GtkActivatableIface structure = (ActivatableAdapter.GtkActivatableIface)Marshal.PtrToStructure(ptr2, typeof(ActivatableAdapter.GtkActivatableIface));
			structure.SyncActionProperties = ActivatableAdapter.iface.SyncActionProperties;
			Marshal.StructureToPtr<ActivatableAdapter.GtkActivatableIface>(structure, ptr2, false);
		}

		// Token: 0x06000C4E RID: 3150 RVA: 0x00025AC9 File Offset: 0x00023CC9
		public ActivatableAdapter()
		{
			base.InitHandler = new GInterfaceInitHandler(ActivatableAdapter.Initialize);
		}

		// Token: 0x06000C4F RID: 3151 RVA: 0x00025AE3 File Offset: 0x00023CE3
		public ActivatableAdapter(IActivatableImplementor implementor)
		{
			if (implementor == null)
			{
				throw new ArgumentNullException("implementor");
			}
			if (!(implementor is Object))
			{
				throw new ArgumentException("implementor must be a subclass of GLib.Object");
			}
			this.implementor = (implementor as Object);
		}

		// Token: 0x06000C50 RID: 3152 RVA: 0x00025B18 File Offset: 0x00023D18
		public ActivatableAdapter(IntPtr handle)
		{
			if (!ActivatableAdapter._gtype.IsInstance(handle))
			{
				throw new ArgumentException("The gobject doesn't implement the GInterface of this adapter", "handle");
			}
			this.implementor = Object.GetObject(handle);
		}

		// Token: 0x1700028D RID: 653
		// (get) Token: 0x06000C51 RID: 3153 RVA: 0x00025B49 File Offset: 0x00023D49
		public static GType GType
		{
			get
			{
				return ActivatableAdapter._gtype;
			}
		}

		// Token: 0x1700028E RID: 654
		// (get) Token: 0x06000C52 RID: 3154 RVA: 0x00025B50 File Offset: 0x00023D50
		public override GType GInterfaceGType
		{
			get
			{
				return ActivatableAdapter._gtype;
			}
		}

		// Token: 0x1700028F RID: 655
		// (get) Token: 0x06000C53 RID: 3155 RVA: 0x00025B57 File Offset: 0x00023D57
		public override IntPtr Handle
		{
			get
			{
				return this.implementor.Handle;
			}
		}

		// Token: 0x17000290 RID: 656
		// (get) Token: 0x06000C54 RID: 3156 RVA: 0x00025B64 File Offset: 0x00023D64
		public IntPtr OwnedHandle
		{
			get
			{
				return this.implementor.OwnedHandle;
			}
		}

		// Token: 0x06000C55 RID: 3157 RVA: 0x00025B71 File Offset: 0x00023D71
		public static IActivatable GetObject(IntPtr handle, bool owned)
		{
			return ActivatableAdapter.GetObject(Object.GetObject(handle, owned));
		}

		// Token: 0x06000C56 RID: 3158 RVA: 0x00025B7F File Offset: 0x00023D7F
		public static IActivatable GetObject(Object obj)
		{
			if (obj == null)
			{
				return null;
			}
			if (obj is IActivatableImplementor)
			{
				return new ActivatableAdapter(obj as IActivatableImplementor);
			}
			if (!(obj is IActivatable))
			{
				return new ActivatableAdapter(obj.Handle);
			}
			return obj as IActivatable;
		}

		// Token: 0x17000291 RID: 657
		// (get) Token: 0x06000C57 RID: 3159 RVA: 0x00025BB4 File Offset: 0x00023DB4
		public IActivatableImplementor Implementor
		{
			get
			{
				return this.implementor as IActivatableImplementor;
			}
		}

		// Token: 0x17000292 RID: 658
		// (get) Token: 0x06000C58 RID: 3160 RVA: 0x00025BC1 File Offset: 0x00023DC1
		// (set) Token: 0x06000C59 RID: 3161 RVA: 0x00025BDD File Offset: 0x00023DDD
		[Obsolete]
		[Property("related-action")]
		public Action RelatedAction
		{
			get
			{
				return Object.GetObject(ActivatableAdapter.gtk_activatable_get_related_action(this.Handle)) as Action;
			}
			set
			{
				ActivatableAdapter.gtk_activatable_set_related_action(this.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x17000293 RID: 659
		// (get) Token: 0x06000C5A RID: 3162 RVA: 0x00025BFF File Offset: 0x00023DFF
		// (set) Token: 0x06000C5B RID: 3163 RVA: 0x00025C11 File Offset: 0x00023E11
		[Obsolete]
		[Property("use-action-appearance")]
		public bool UseActionAppearance
		{
			get
			{
				return ActivatableAdapter.gtk_activatable_get_use_action_appearance(this.Handle);
			}
			set
			{
				ActivatableAdapter.gtk_activatable_set_use_action_appearance(this.Handle, value);
			}
		}

		// Token: 0x06000C5C RID: 3164 RVA: 0x00025C24 File Offset: 0x00023E24
		[Obsolete]
		public void DoSetRelatedAction(Action action)
		{
			ActivatableAdapter.gtk_activatable_do_set_related_action(this.Handle, (action == null) ? IntPtr.Zero : action.Handle);
		}

		// Token: 0x06000C5D RID: 3165 RVA: 0x00025C46 File Offset: 0x00023E46
		[Obsolete]
		public void SyncActionProperties(Action action)
		{
			ActivatableAdapter.gtk_activatable_sync_action_properties(this.Handle, (action == null) ? IntPtr.Zero : action.Handle);
		}

		// Token: 0x040005FE RID: 1534
		private static ActivatableAdapter.GtkActivatableIface iface;

		// Token: 0x040005FF RID: 1535
		private static int class_offset = 2 * IntPtr.Size;

		// Token: 0x04000600 RID: 1536
		private Object implementor;

		// Token: 0x04000601 RID: 1537
		private static ActivatableAdapter.d_gtk_activatable_get_type gtk_activatable_get_type = FuncLoader.LoadFunction<ActivatableAdapter.d_gtk_activatable_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_activatable_get_type"));

		// Token: 0x04000602 RID: 1538
		private static GType _gtype = new GType(ActivatableAdapter.gtk_activatable_get_type());

		// Token: 0x04000603 RID: 1539
		private static ActivatableAdapter.d_gtk_activatable_get_related_action gtk_activatable_get_related_action = FuncLoader.LoadFunction<ActivatableAdapter.d_gtk_activatable_get_related_action>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_activatable_get_related_action"));

		// Token: 0x04000604 RID: 1540
		private static ActivatableAdapter.d_gtk_activatable_set_related_action gtk_activatable_set_related_action = FuncLoader.LoadFunction<ActivatableAdapter.d_gtk_activatable_set_related_action>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_activatable_set_related_action"));

		// Token: 0x04000605 RID: 1541
		private static ActivatableAdapter.d_gtk_activatable_get_use_action_appearance gtk_activatable_get_use_action_appearance = FuncLoader.LoadFunction<ActivatableAdapter.d_gtk_activatable_get_use_action_appearance>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_activatable_get_use_action_appearance"));

		// Token: 0x04000606 RID: 1542
		private static ActivatableAdapter.d_gtk_activatable_set_use_action_appearance gtk_activatable_set_use_action_appearance = FuncLoader.LoadFunction<ActivatableAdapter.d_gtk_activatable_set_use_action_appearance>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_activatable_set_use_action_appearance"));

		// Token: 0x04000607 RID: 1543
		private static ActivatableAdapter.d_gtk_activatable_do_set_related_action gtk_activatable_do_set_related_action = FuncLoader.LoadFunction<ActivatableAdapter.d_gtk_activatable_do_set_related_action>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_activatable_do_set_related_action"));

		// Token: 0x04000608 RID: 1544
		private static ActivatableAdapter.d_gtk_activatable_sync_action_properties gtk_activatable_sync_action_properties = FuncLoader.LoadFunction<ActivatableAdapter.d_gtk_activatable_sync_action_properties>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_activatable_sync_action_properties"));

		// Token: 0x02000A13 RID: 2579
		private struct GtkActivatableIface
		{
			// Token: 0x04001E65 RID: 7781
			private IntPtr Update;

			// Token: 0x04001E66 RID: 7782
			public ActivatableAdapter.SyncActionPropertiesNativeDelegate SyncActionProperties;
		}

		// Token: 0x02000A14 RID: 2580
		// (Invoke) Token: 0x06004F57 RID: 20311
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void SyncActionPropertiesNativeDelegate(IntPtr inst, IntPtr action);

		// Token: 0x02000A15 RID: 2581
		// (Invoke) Token: 0x06004F5B RID: 20315
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_activatable_get_type();

		// Token: 0x02000A16 RID: 2582
		// (Invoke) Token: 0x06004F5F RID: 20319
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_activatable_get_related_action(IntPtr raw);

		// Token: 0x02000A17 RID: 2583
		// (Invoke) Token: 0x06004F63 RID: 20323
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_activatable_set_related_action(IntPtr raw, IntPtr action);

		// Token: 0x02000A18 RID: 2584
		// (Invoke) Token: 0x06004F67 RID: 20327
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_activatable_get_use_action_appearance(IntPtr raw);

		// Token: 0x02000A19 RID: 2585
		// (Invoke) Token: 0x06004F6B RID: 20331
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_activatable_set_use_action_appearance(IntPtr raw, bool use_appearance);

		// Token: 0x02000A1A RID: 2586
		// (Invoke) Token: 0x06004F6F RID: 20335
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_activatable_do_set_related_action(IntPtr raw, IntPtr action);

		// Token: 0x02000A1B RID: 2587
		// (Invoke) Token: 0x06004F73 RID: 20339
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_activatable_sync_action_properties(IntPtr raw, IntPtr action);
	}
}
