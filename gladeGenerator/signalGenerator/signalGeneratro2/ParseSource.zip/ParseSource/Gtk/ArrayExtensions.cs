﻿using System;

namespace Gtk
{
	// Token: 0x020000D5 RID: 213
	internal static class ArrayExtensions
	{
		// Token: 0x060004C9 RID: 1225 RVA: 0x0000CB00 File Offset: 0x0000AD00
		public static object[] Explode(this Array arr)
		{
			if (arr == null)
			{
				return null;
			}
			object[] array = new object[arr.Length];
			arr.CopyTo(array, 0);
			return array;
		}
	}
}
