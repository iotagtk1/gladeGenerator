﻿using System;
using Gdk;

namespace Gtk
{
	// Token: 0x02000191 RID: 401
	// (Invoke) Token: 0x0600109B RID: 4251
	public delegate void ClipboardImageReceivedFunc(Clipboard clipboard, Pixbuf pixbuf);
}
