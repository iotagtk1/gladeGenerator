﻿using System;

namespace Gtk
{
	// Token: 0x02000112 RID: 274
	// (Invoke) Token: 0x06000C6A RID: 3178
	public delegate void ActivateLinkHandler(object o, ActivateLinkArgs args);
}
