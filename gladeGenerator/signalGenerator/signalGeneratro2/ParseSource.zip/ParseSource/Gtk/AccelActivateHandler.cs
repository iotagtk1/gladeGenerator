﻿using System;

namespace Gtk
{
	// Token: 0x020000EE RID: 238
	// (Invoke) Token: 0x06000AFB RID: 2811
	public delegate void AccelActivateHandler(object o, AccelActivateArgs args);
}
