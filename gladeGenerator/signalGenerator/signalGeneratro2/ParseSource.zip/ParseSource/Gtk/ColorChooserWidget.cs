﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x0200019C RID: 412
	public class ColorChooserWidget : Box, IColorChooser, IWrapper
	{
		// Token: 0x06001106 RID: 4358 RVA: 0x0003305A File Offset: 0x0003125A
		public ColorChooserWidget(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06001107 RID: 4359 RVA: 0x00033064 File Offset: 0x00031264
		public ColorChooserWidget() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(ColorChooserWidget))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = ColorChooserWidget.gtk_color_chooser_widget_new();
		}

		// Token: 0x170003ED RID: 1005
		// (get) Token: 0x06001108 RID: 4360 RVA: 0x000330B8 File Offset: 0x000312B8
		// (set) Token: 0x06001109 RID: 4361 RVA: 0x000330E0 File Offset: 0x000312E0
		[Property("show-editor")]
		public bool ShowEditor
		{
			get
			{
				Value property = base.GetProperty("show-editor");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("show-editor", val);
				val.Dispose();
			}
		}

		// Token: 0x170003EE RID: 1006
		// (get) Token: 0x0600110A RID: 4362 RVA: 0x00033108 File Offset: 0x00031308
		public new static AbiStruct class_abi
		{
			get
			{
				if (ColorChooserWidget._class_abi == null)
				{
					ColorChooserWidget._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("_gtk_reserved1", Box.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", "_gtk_reserved5", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved5", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved4", "_gtk_reserved6", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved6", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved5", "_gtk_reserved7", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved7", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved6", "_gtk_reserved8", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved8", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved7", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return ColorChooserWidget._class_abi;
			}
		}

		// Token: 0x170003EF RID: 1007
		// (get) Token: 0x0600110B RID: 4363 RVA: 0x00033314 File Offset: 0x00031514
		public new static GType GType
		{
			get
			{
				IntPtr val = ColorChooserWidget.gtk_color_chooser_widget_get_type();
				return new GType(val);
			}
		}

		// Token: 0x0600110C RID: 4364 RVA: 0x00033334 File Offset: 0x00031534
		public void AddPalette(Orientation orientation, int colors_per_line, int n_colors, RGBA colors)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(colors);
			ColorChooserWidget.gtk_color_chooser_add_palette(base.Handle, (int)orientation, colors_per_line, n_colors, intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x170003F0 RID: 1008
		// (get) Token: 0x0600110D RID: 4365 RVA: 0x00033368 File Offset: 0x00031568
		// (set) Token: 0x0600110E RID: 4366 RVA: 0x000333A8 File Offset: 0x000315A8
		[Property("rgba")]
		public RGBA Rgba
		{
			get
			{
				IntPtr intPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(RGBA)));
				ColorChooserWidget.gtk_color_chooser_get_rgba(base.Handle, intPtr);
				RGBA result = RGBA.New(intPtr);
				Marshal.FreeHGlobal(intPtr);
				return result;
			}
			set
			{
				IntPtr intPtr = Marshaller.StructureToPtrAlloc(value);
				ColorChooserWidget.gtk_color_chooser_set_rgba(base.Handle, intPtr);
				Marshal.FreeHGlobal(intPtr);
			}
		}

		// Token: 0x170003F1 RID: 1009
		// (get) Token: 0x0600110F RID: 4367 RVA: 0x000333D8 File Offset: 0x000315D8
		// (set) Token: 0x06001110 RID: 4368 RVA: 0x000333EA File Offset: 0x000315EA
		[Property("use-alpha")]
		public bool UseAlpha
		{
			get
			{
				return ColorChooserWidget.gtk_color_chooser_get_use_alpha(base.Handle);
			}
			set
			{
				ColorChooserWidget.gtk_color_chooser_set_use_alpha(base.Handle, value);
			}
		}

		// Token: 0x1400006B RID: 107
		// (add) Token: 0x06001111 RID: 4369 RVA: 0x000333FD File Offset: 0x000315FD
		// (remove) Token: 0x06001112 RID: 4370 RVA: 0x00033415 File Offset: 0x00031615
		[Signal("color-activated")]
		public event ColorActivatedHandler ColorActivated
		{
			add
			{
				base.AddSignalHandler("color-activated", value, typeof(ColorActivatedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("color-activated", value);
			}
		}

		// Token: 0x170003F2 RID: 1010
		// (get) Token: 0x06001113 RID: 4371 RVA: 0x00033423 File Offset: 0x00031623
		private static ColorChooserWidget.ColorActivatedNativeDelegate ColorActivatedVMCallback
		{
			get
			{
				if (ColorChooserWidget.ColorActivated_cb_delegate == null)
				{
					ColorChooserWidget.ColorActivated_cb_delegate = new ColorChooserWidget.ColorActivatedNativeDelegate(ColorChooserWidget.ColorActivated_cb);
				}
				return ColorChooserWidget.ColorActivated_cb_delegate;
			}
		}

		// Token: 0x06001114 RID: 4372 RVA: 0x00033442 File Offset: 0x00031642
		private static void OverrideColorActivated(GType gtype)
		{
			ColorChooserWidget.OverrideColorActivated(gtype, ColorChooserWidget.ColorActivatedVMCallback);
		}

		// Token: 0x06001115 RID: 4373 RVA: 0x0003344F File Offset: 0x0003164F
		private static void OverrideColorActivated(GType gtype, ColorChooserWidget.ColorActivatedNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "color-activated", callback);
		}

		// Token: 0x06001116 RID: 4374 RVA: 0x00033460 File Offset: 0x00031660
		private static void ColorActivated_cb(IntPtr inst, IntPtr color)
		{
			try
			{
				(Object.GetObject(inst, false) as ColorChooserWidget).OnColorActivated(RGBA.New(color));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06001117 RID: 4375 RVA: 0x000334A0 File Offset: 0x000316A0
		[DefaultSignalHandler(Type = typeof(ColorChooserWidget), ConnectionMethod = "OverrideColorActivated")]
		protected virtual void OnColorActivated(RGBA color)
		{
			this.InternalColorActivated(color);
		}

		// Token: 0x06001118 RID: 4376 RVA: 0x000334AC File Offset: 0x000316AC
		private void InternalColorActivated(RGBA color)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(2U);
			Value[] array = new Value[2];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(color);
			valueArray.Append(array[1]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x170003F3 RID: 1011
		// (get) Token: 0x06001119 RID: 4377 RVA: 0x00033540 File Offset: 0x00031740
		public new static AbiStruct abi_info
		{
			get
			{
				if (ColorChooserWidget._abi_info == null)
				{
					ColorChooserWidget._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Box.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return ColorChooserWidget._abi_info;
			}
		}

		// Token: 0x040007FD RID: 2045
		private static ColorChooserWidget.d_gtk_color_chooser_widget_new gtk_color_chooser_widget_new = FuncLoader.LoadFunction<ColorChooserWidget.d_gtk_color_chooser_widget_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_widget_new"));

		// Token: 0x040007FE RID: 2046
		private static AbiStruct _class_abi = null;

		// Token: 0x040007FF RID: 2047
		private static ColorChooserWidget.d_gtk_color_chooser_widget_get_type gtk_color_chooser_widget_get_type = FuncLoader.LoadFunction<ColorChooserWidget.d_gtk_color_chooser_widget_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_widget_get_type"));

		// Token: 0x04000800 RID: 2048
		private static ColorChooserWidget.d_gtk_color_chooser_add_palette gtk_color_chooser_add_palette = FuncLoader.LoadFunction<ColorChooserWidget.d_gtk_color_chooser_add_palette>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_add_palette"));

		// Token: 0x04000801 RID: 2049
		private static ColorChooserWidget.d_gtk_color_chooser_get_rgba gtk_color_chooser_get_rgba = FuncLoader.LoadFunction<ColorChooserWidget.d_gtk_color_chooser_get_rgba>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_get_rgba"));

		// Token: 0x04000802 RID: 2050
		private static ColorChooserWidget.d_gtk_color_chooser_set_rgba gtk_color_chooser_set_rgba = FuncLoader.LoadFunction<ColorChooserWidget.d_gtk_color_chooser_set_rgba>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_set_rgba"));

		// Token: 0x04000803 RID: 2051
		private static ColorChooserWidget.d_gtk_color_chooser_get_use_alpha gtk_color_chooser_get_use_alpha = FuncLoader.LoadFunction<ColorChooserWidget.d_gtk_color_chooser_get_use_alpha>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_get_use_alpha"));

		// Token: 0x04000804 RID: 2052
		private static ColorChooserWidget.d_gtk_color_chooser_set_use_alpha gtk_color_chooser_set_use_alpha = FuncLoader.LoadFunction<ColorChooserWidget.d_gtk_color_chooser_set_use_alpha>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_set_use_alpha"));

		// Token: 0x04000805 RID: 2053
		private static ColorChooserWidget.ColorActivatedNativeDelegate ColorActivated_cb_delegate;

		// Token: 0x04000806 RID: 2054
		private static AbiStruct _abi_info = null;

		// Token: 0x02000B5B RID: 2907
		// (Invoke) Token: 0x06005475 RID: 21621
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_color_chooser_widget_new();

		// Token: 0x02000B5C RID: 2908
		// (Invoke) Token: 0x06005479 RID: 21625
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_color_chooser_widget_get_type();

		// Token: 0x02000B5D RID: 2909
		// (Invoke) Token: 0x0600547D RID: 21629
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_chooser_add_palette(IntPtr raw, int orientation, int colors_per_line, int n_colors, IntPtr colors);

		// Token: 0x02000B5E RID: 2910
		// (Invoke) Token: 0x06005481 RID: 21633
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_chooser_get_rgba(IntPtr raw, IntPtr color);

		// Token: 0x02000B5F RID: 2911
		// (Invoke) Token: 0x06005485 RID: 21637
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_chooser_set_rgba(IntPtr raw, IntPtr value);

		// Token: 0x02000B60 RID: 2912
		// (Invoke) Token: 0x06005489 RID: 21641
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_color_chooser_get_use_alpha(IntPtr raw);

		// Token: 0x02000B61 RID: 2913
		// (Invoke) Token: 0x0600548D RID: 21645
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_chooser_set_use_alpha(IntPtr raw, bool use_alpha);

		// Token: 0x02000B62 RID: 2914
		// (Invoke) Token: 0x06005491 RID: 21649
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ColorActivatedNativeDelegate(IntPtr inst, IntPtr color);
	}
}
