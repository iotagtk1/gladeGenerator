﻿using System;
using System.Runtime.InteropServices;
using Gdk;
using GLib;
using GtkSharp;

namespace Gtk
{
	// Token: 0x020000CE RID: 206
	public class Accel
	{
		// Token: 0x060003B5 RID: 949 RVA: 0x00008DE8 File Offset: 0x00006FE8
		[Obsolete("Moved to AccelMap class. Use AccelMap.Save instead")]
		public static void MapSave(string file_name)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(file_name);
			Accel.gtk_accel_map_save(intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x060003B6 RID: 950 RVA: 0x00008E10 File Offset: 0x00007010
		[Obsolete("Moved to AccelMap class. Use AccelMap.AddFilter instead")]
		public static void MapAddFilter(string filter_pattern)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(filter_pattern);
			Accel.gtk_accel_map_add_filter(intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x060003B7 RID: 951 RVA: 0x00008E38 File Offset: 0x00007038
		[Obsolete("Moved to AccelMap class. Use AccelMap.ForeachUnfiltered instead")]
		public static void MapForeachUnfiltered(IntPtr data, AccelMapForeach foreach_func)
		{
			AccelMapForeachWrapper accelMapForeachWrapper = new AccelMapForeachWrapper(foreach_func);
			Accel.gtk_accel_map_foreach_unfiltered(data, accelMapForeachWrapper.NativeDelegate);
		}

		// Token: 0x060003B8 RID: 952 RVA: 0x00008E5D File Offset: 0x0000705D
		[Obsolete("Moved to AccelMap class. Use AccelMap.SaveFd instead")]
		public static void MapSaveFd(int fd)
		{
			Accel.gtk_accel_map_save_fd(fd);
		}

		// Token: 0x060003B9 RID: 953 RVA: 0x00008E6C File Offset: 0x0000706C
		[Obsolete("Moved to AccelMap class. Use AccelMap.AddEntry instead")]
		public static void MapAddEntry(string accel_path, uint accel_key, ModifierType accel_mods)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(accel_path);
			Accel.gtk_accel_map_add_entry(intPtr, accel_key, (int)accel_mods);
			Marshaller.Free(intPtr);
		}

		// Token: 0x060003BA RID: 954 RVA: 0x00008E93 File Offset: 0x00007093
		[Obsolete("Moved to AccelMap class. Use AccelMap.LoadFd instead")]
		public static void MapLoadFd(int fd)
		{
			Accel.gtk_accel_map_load_fd(fd);
		}

		// Token: 0x060003BB RID: 955 RVA: 0x00008EA0 File Offset: 0x000070A0
		[Obsolete("Moved to AccelMap class. Use AccelMap.LookupEntry instead")]
		public static bool MapLookupEntry(string accel_path, AccelKey key)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(accel_path);
			bool result = Accel.gtk_accel_map_lookup_entry(intPtr, ref key);
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x060003BC RID: 956 RVA: 0x00008EC8 File Offset: 0x000070C8
		[Obsolete("Moved to AccelMap class. Use AccelMap.ChangeEntry instead")]
		public static bool MapChangeEntry(string accel_path, uint accel_key, ModifierType accel_mods, bool replace)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(accel_path);
			bool result = Accel.gtk_accel_map_change_entry(intPtr, accel_key, (int)accel_mods, replace);
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x060003BD RID: 957 RVA: 0x00008EF0 File Offset: 0x000070F0
		[Obsolete("Moved to AccelMap class. Use AccelMap.Load instead")]
		public static void MapLoad(string file_name)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(file_name);
			Accel.gtk_accel_map_load(intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x060003BE RID: 958 RVA: 0x00008F18 File Offset: 0x00007118
		[Obsolete("Moved to AccelMap class. Use AccelMap.Foreach instead")]
		public static void MapForeach(IntPtr data, AccelMapForeach foreach_func)
		{
			AccelMapForeachWrapper accelMapForeachWrapper = new AccelMapForeachWrapper(foreach_func);
			Accel.gtk_accel_map_foreach(data, accelMapForeachWrapper.NativeDelegate);
		}

		// Token: 0x060003BF RID: 959 RVA: 0x00008F40 File Offset: 0x00007140
		public static AccelGroup[] GroupsFromObject(Object obj)
		{
			IntPtr intPtr = Accel.gtk_accel_groups_from_object(obj.Handle);
			if (intPtr == IntPtr.Zero)
			{
				return new AccelGroup[0];
			}
			SList slist = new SList(intPtr);
			AccelGroup[] array = new AccelGroup[slist.Count];
			for (int i = 0; i < slist.Count; i++)
			{
				array[i] = (slist[i] as AccelGroup);
			}
			return array;
		}

		// Token: 0x060003C0 RID: 960 RVA: 0x00008FA6 File Offset: 0x000071A6
		public static bool GroupsActivate(Object objekt, uint accel_key, ModifierType accel_mods)
		{
			return Accel.gtk_accel_groups_activate((objekt == null) ? IntPtr.Zero : objekt.Handle, accel_key, (int)accel_mods);
		}

		// Token: 0x040001E9 RID: 489
		private static Accel.d_gtk_accel_map_save gtk_accel_map_save = FuncLoader.LoadFunction<Accel.d_gtk_accel_map_save>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_map_save"));

		// Token: 0x040001EA RID: 490
		private static Accel.d_gtk_accel_map_add_filter gtk_accel_map_add_filter = FuncLoader.LoadFunction<Accel.d_gtk_accel_map_add_filter>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_map_add_filter"));

		// Token: 0x040001EB RID: 491
		private static Accel.d_gtk_accel_map_foreach_unfiltered gtk_accel_map_foreach_unfiltered = FuncLoader.LoadFunction<Accel.d_gtk_accel_map_foreach_unfiltered>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_map_foreach_unfiltered"));

		// Token: 0x040001EC RID: 492
		private static Accel.d_gtk_accel_map_save_fd gtk_accel_map_save_fd = FuncLoader.LoadFunction<Accel.d_gtk_accel_map_save_fd>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_map_save_fd"));

		// Token: 0x040001ED RID: 493
		private static Accel.d_gtk_accel_map_add_entry gtk_accel_map_add_entry = FuncLoader.LoadFunction<Accel.d_gtk_accel_map_add_entry>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_map_add_entry"));

		// Token: 0x040001EE RID: 494
		private static Accel.d_gtk_accel_map_load_fd gtk_accel_map_load_fd = FuncLoader.LoadFunction<Accel.d_gtk_accel_map_load_fd>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_map_load_fd"));

		// Token: 0x040001EF RID: 495
		private static Accel.d_gtk_accel_map_lookup_entry gtk_accel_map_lookup_entry = FuncLoader.LoadFunction<Accel.d_gtk_accel_map_lookup_entry>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_map_lookup_entry"));

		// Token: 0x040001F0 RID: 496
		private static Accel.d_gtk_accel_map_change_entry gtk_accel_map_change_entry = FuncLoader.LoadFunction<Accel.d_gtk_accel_map_change_entry>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_map_change_entry"));

		// Token: 0x040001F1 RID: 497
		private static Accel.d_gtk_accel_map_load gtk_accel_map_load = FuncLoader.LoadFunction<Accel.d_gtk_accel_map_load>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_map_load"));

		// Token: 0x040001F2 RID: 498
		private static Accel.d_gtk_accel_map_foreach gtk_accel_map_foreach = FuncLoader.LoadFunction<Accel.d_gtk_accel_map_foreach>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_map_foreach"));

		// Token: 0x040001F3 RID: 499
		private static Accel.d_gtk_accel_groups_from_object gtk_accel_groups_from_object = FuncLoader.LoadFunction<Accel.d_gtk_accel_groups_from_object>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_groups_from_object"));

		// Token: 0x040001F4 RID: 500
		private static Accel.d_gtk_accel_groups_activate gtk_accel_groups_activate = FuncLoader.LoadFunction<Accel.d_gtk_accel_groups_activate>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_groups_activate"));

		// Token: 0x02000639 RID: 1593
		// (Invoke) Token: 0x06004006 RID: 16390
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accel_map_save(IntPtr file_name);

		// Token: 0x0200063A RID: 1594
		// (Invoke) Token: 0x0600400A RID: 16394
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accel_map_add_filter(IntPtr filter_pattern);

		// Token: 0x0200063B RID: 1595
		// (Invoke) Token: 0x0600400E RID: 16398
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accel_map_foreach_unfiltered(IntPtr data, AccelMapForeachNative foreach_func);

		// Token: 0x0200063C RID: 1596
		// (Invoke) Token: 0x06004012 RID: 16402
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accel_map_save_fd(int fd);

		// Token: 0x0200063D RID: 1597
		// (Invoke) Token: 0x06004016 RID: 16406
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accel_map_add_entry(IntPtr accel_path, uint accel_key, int accel_mods);

		// Token: 0x0200063E RID: 1598
		// (Invoke) Token: 0x0600401A RID: 16410
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accel_map_load_fd(int fd);

		// Token: 0x0200063F RID: 1599
		// (Invoke) Token: 0x0600401E RID: 16414
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_accel_map_lookup_entry(IntPtr accel_path, ref AccelKey key);

		// Token: 0x02000640 RID: 1600
		// (Invoke) Token: 0x06004022 RID: 16418
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_accel_map_change_entry(IntPtr accel_path, uint accel_key, int accel_mods, bool replace);

		// Token: 0x02000641 RID: 1601
		// (Invoke) Token: 0x06004026 RID: 16422
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accel_map_load(IntPtr file_name);

		// Token: 0x02000642 RID: 1602
		// (Invoke) Token: 0x0600402A RID: 16426
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_accel_map_foreach(IntPtr data, AccelMapForeachNative foreach_func);

		// Token: 0x02000643 RID: 1603
		// (Invoke) Token: 0x0600402E RID: 16430
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_accel_groups_from_object(IntPtr obj);

		// Token: 0x02000644 RID: 1604
		// (Invoke) Token: 0x06004032 RID: 16434
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_accel_groups_activate(IntPtr objekt, uint accel_key, int accel_mods);
	}
}
