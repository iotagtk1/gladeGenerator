﻿using System;

namespace Gtk
{
	// Token: 0x020001B5 RID: 437
	// (Invoke) Token: 0x0600115F RID: 4447
	public delegate void CreateContextHandler(object o, CreateContextArgs args);
}
