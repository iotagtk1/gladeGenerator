﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000103 RID: 259
	public class AcceptPositionArgs : SignalArgs
	{
	}
}
