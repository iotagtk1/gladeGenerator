﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x0200016F RID: 367
	public class CellRendererAccel : CellRendererText
	{
		// Token: 0x06000F6C RID: 3948 RVA: 0x0002E8C1 File Offset: 0x0002CAC1
		public CellRendererAccel(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000F6D RID: 3949 RVA: 0x0002E8CC File Offset: 0x0002CACC
		public CellRendererAccel() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(CellRendererAccel))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = CellRendererAccel.gtk_cell_renderer_accel_new();
		}

		// Token: 0x1700035E RID: 862
		// (get) Token: 0x06000F6E RID: 3950 RVA: 0x0002E920 File Offset: 0x0002CB20
		// (set) Token: 0x06000F6F RID: 3951 RVA: 0x0002E948 File Offset: 0x0002CB48
		[Property("accel-key")]
		public uint AccelKey
		{
			get
			{
				Value property = base.GetProperty("accel-key");
				uint result = (uint)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("accel-key", val);
				val.Dispose();
			}
		}

		// Token: 0x1700035F RID: 863
		// (get) Token: 0x06000F70 RID: 3952 RVA: 0x0002E970 File Offset: 0x0002CB70
		// (set) Token: 0x06000F71 RID: 3953 RVA: 0x0002E99C File Offset: 0x0002CB9C
		[Property("accel-mods")]
		public ModifierType AccelMods
		{
			get
			{
				Value property = base.GetProperty("accel-mods");
				ModifierType result = (ModifierType)((Enum)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("accel-mods", val);
				val.Dispose();
			}
		}

		// Token: 0x17000360 RID: 864
		// (get) Token: 0x06000F72 RID: 3954 RVA: 0x0002E9CC File Offset: 0x0002CBCC
		// (set) Token: 0x06000F73 RID: 3955 RVA: 0x0002E9F4 File Offset: 0x0002CBF4
		[Property("keycode")]
		public uint Keycode
		{
			get
			{
				Value property = base.GetProperty("keycode");
				uint result = (uint)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("keycode", val);
				val.Dispose();
			}
		}

		// Token: 0x17000361 RID: 865
		// (get) Token: 0x06000F74 RID: 3956 RVA: 0x0002EA1C File Offset: 0x0002CC1C
		// (set) Token: 0x06000F75 RID: 3957 RVA: 0x0002EA48 File Offset: 0x0002CC48
		[Property("accel-mode")]
		public CellRendererAccelMode AccelMode
		{
			get
			{
				Value property = base.GetProperty("accel-mode");
				CellRendererAccelMode result = (CellRendererAccelMode)((Enum)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("accel-mode", val);
				val.Dispose();
			}
		}

		// Token: 0x14000062 RID: 98
		// (add) Token: 0x06000F76 RID: 3958 RVA: 0x0002EA75 File Offset: 0x0002CC75
		// (remove) Token: 0x06000F77 RID: 3959 RVA: 0x0002EA8D File Offset: 0x0002CC8D
		[Signal("accel-cleared")]
		public event AccelClearedHandler AccelCleared
		{
			add
			{
				base.AddSignalHandler("accel-cleared", value, typeof(AccelClearedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("accel-cleared", value);
			}
		}

		// Token: 0x14000063 RID: 99
		// (add) Token: 0x06000F78 RID: 3960 RVA: 0x0002EA9B File Offset: 0x0002CC9B
		// (remove) Token: 0x06000F79 RID: 3961 RVA: 0x0002EAB3 File Offset: 0x0002CCB3
		[Signal("accel-edited")]
		public event AccelEditedHandler AccelEdited
		{
			add
			{
				base.AddSignalHandler("accel-edited", value, typeof(AccelEditedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("accel-edited", value);
			}
		}

		// Token: 0x17000362 RID: 866
		// (get) Token: 0x06000F7A RID: 3962 RVA: 0x0002EAC1 File Offset: 0x0002CCC1
		private static CellRendererAccel.AccelEditedNativeDelegate AccelEditedVMCallback
		{
			get
			{
				if (CellRendererAccel.AccelEdited_cb_delegate == null)
				{
					CellRendererAccel.AccelEdited_cb_delegate = new CellRendererAccel.AccelEditedNativeDelegate(CellRendererAccel.AccelEdited_cb);
				}
				return CellRendererAccel.AccelEdited_cb_delegate;
			}
		}

		// Token: 0x06000F7B RID: 3963 RVA: 0x0002EAE0 File Offset: 0x0002CCE0
		private static void OverrideAccelEdited(GType gtype)
		{
			CellRendererAccel.OverrideAccelEdited(gtype, CellRendererAccel.AccelEditedVMCallback);
		}

		// Token: 0x06000F7C RID: 3964 RVA: 0x0002EAF0 File Offset: 0x0002CCF0
		private unsafe static void OverrideAccelEdited(GType gtype, CellRendererAccel.AccelEditedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellRendererAccel.class_abi.GetFieldOffset("accel_edited");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000F7D RID: 3965 RVA: 0x0002EB24 File Offset: 0x0002CD24
		private static void AccelEdited_cb(IntPtr inst, IntPtr path_string, uint accel_key, int accel_mods, uint hardware_keycode)
		{
			try
			{
				(Object.GetObject(inst, false) as CellRendererAccel).OnAccelEdited(Marshaller.Utf8PtrToString(path_string), accel_key, (ModifierType)accel_mods, hardware_keycode);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000F7E RID: 3966 RVA: 0x0002EB68 File Offset: 0x0002CD68
		[DefaultSignalHandler(Type = typeof(CellRendererAccel), ConnectionMethod = "OverrideAccelEdited")]
		protected virtual void OnAccelEdited(string path_string, uint accel_key, ModifierType accel_mods, uint hardware_keycode)
		{
			this.InternalAccelEdited(path_string, accel_key, accel_mods, hardware_keycode);
		}

		// Token: 0x06000F7F RID: 3967 RVA: 0x0002EB78 File Offset: 0x0002CD78
		private void InternalAccelEdited(string path_string, uint accel_key, ModifierType accel_mods, uint hardware_keycode)
		{
			CellRendererAccel.AccelEditedNativeDelegate accelEditedNativeDelegate = CellRendererAccel.class_abi.BaseOverride(base.LookupGType(), "accel_edited");
			if (accelEditedNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(path_string);
			accelEditedNativeDelegate(base.Handle, intPtr, accel_key, (int)accel_mods, hardware_keycode);
			Marshaller.Free(intPtr);
		}

		// Token: 0x17000363 RID: 867
		// (get) Token: 0x06000F80 RID: 3968 RVA: 0x0002EBBD File Offset: 0x0002CDBD
		private static CellRendererAccel.AccelClearedNativeDelegate AccelClearedVMCallback
		{
			get
			{
				if (CellRendererAccel.AccelCleared_cb_delegate == null)
				{
					CellRendererAccel.AccelCleared_cb_delegate = new CellRendererAccel.AccelClearedNativeDelegate(CellRendererAccel.AccelCleared_cb);
				}
				return CellRendererAccel.AccelCleared_cb_delegate;
			}
		}

		// Token: 0x06000F81 RID: 3969 RVA: 0x0002EBDC File Offset: 0x0002CDDC
		private static void OverrideAccelCleared(GType gtype)
		{
			CellRendererAccel.OverrideAccelCleared(gtype, CellRendererAccel.AccelClearedVMCallback);
		}

		// Token: 0x06000F82 RID: 3970 RVA: 0x0002EBEC File Offset: 0x0002CDEC
		private unsafe static void OverrideAccelCleared(GType gtype, CellRendererAccel.AccelClearedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellRendererAccel.class_abi.GetFieldOffset("accel_cleared");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000F83 RID: 3971 RVA: 0x0002EC20 File Offset: 0x0002CE20
		private static void AccelCleared_cb(IntPtr inst, IntPtr path_string)
		{
			try
			{
				(Object.GetObject(inst, false) as CellRendererAccel).OnAccelCleared(Marshaller.Utf8PtrToString(path_string));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000F84 RID: 3972 RVA: 0x0002EC60 File Offset: 0x0002CE60
		[DefaultSignalHandler(Type = typeof(CellRendererAccel), ConnectionMethod = "OverrideAccelCleared")]
		protected virtual void OnAccelCleared(string path_string)
		{
			this.InternalAccelCleared(path_string);
		}

		// Token: 0x06000F85 RID: 3973 RVA: 0x0002EC6C File Offset: 0x0002CE6C
		private void InternalAccelCleared(string path_string)
		{
			CellRendererAccel.AccelClearedNativeDelegate accelClearedNativeDelegate = CellRendererAccel.class_abi.BaseOverride(base.LookupGType(), "accel_cleared");
			if (accelClearedNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(path_string);
			accelClearedNativeDelegate(base.Handle, intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x17000364 RID: 868
		// (get) Token: 0x06000F86 RID: 3974 RVA: 0x0002ECB0 File Offset: 0x0002CEB0
		public new static AbiStruct class_abi
		{
			get
			{
				if (CellRendererAccel._class_abi == null)
				{
					CellRendererAccel._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("accel_edited", CellRendererText.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "accel_cleared", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("accel_cleared", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "accel_edited", "_gtk_reserved0", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved0", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "accel_cleared", "_gtk_reserved1", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved1", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved0", "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellRendererAccel._class_abi;
			}
		}

		// Token: 0x17000365 RID: 869
		// (get) Token: 0x06000F87 RID: 3975 RVA: 0x0002EE80 File Offset: 0x0002D080
		public new static GType GType
		{
			get
			{
				IntPtr val = CellRendererAccel.gtk_cell_renderer_accel_get_type();
				return new GType(val);
			}
		}

		// Token: 0x17000366 RID: 870
		// (get) Token: 0x06000F88 RID: 3976 RVA: 0x0002EEA0 File Offset: 0x0002D0A0
		public new static AbiStruct abi_info
		{
			get
			{
				if (CellRendererAccel._abi_info == null)
				{
					CellRendererAccel._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", CellRendererText.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellRendererAccel._abi_info;
			}
		}

		// Token: 0x0400078D RID: 1933
		private static CellRendererAccel.d_gtk_cell_renderer_accel_new gtk_cell_renderer_accel_new = FuncLoader.LoadFunction<CellRendererAccel.d_gtk_cell_renderer_accel_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_accel_new"));

		// Token: 0x0400078E RID: 1934
		private static CellRendererAccel.AccelEditedNativeDelegate AccelEdited_cb_delegate;

		// Token: 0x0400078F RID: 1935
		private static CellRendererAccel.AccelClearedNativeDelegate AccelCleared_cb_delegate;

		// Token: 0x04000790 RID: 1936
		private static AbiStruct _class_abi = null;

		// Token: 0x04000791 RID: 1937
		private static CellRendererAccel.d_gtk_cell_renderer_accel_get_type gtk_cell_renderer_accel_get_type = FuncLoader.LoadFunction<CellRendererAccel.d_gtk_cell_renderer_accel_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_accel_get_type"));

		// Token: 0x04000792 RID: 1938
		private static AbiStruct _abi_info = null;

		// Token: 0x02000B14 RID: 2836
		// (Invoke) Token: 0x0600535D RID: 21341
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_renderer_accel_new();

		// Token: 0x02000B15 RID: 2837
		// (Invoke) Token: 0x06005361 RID: 21345
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void AccelEditedNativeDelegate(IntPtr inst, IntPtr path_string, uint accel_key, int accel_mods, uint hardware_keycode);

		// Token: 0x02000B16 RID: 2838
		// (Invoke) Token: 0x06005365 RID: 21349
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void AccelClearedNativeDelegate(IntPtr inst, IntPtr path_string);

		// Token: 0x02000B17 RID: 2839
		// (Invoke) Token: 0x06005369 RID: 21353
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_renderer_accel_get_type();
	}
}
