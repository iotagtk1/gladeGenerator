﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001FB RID: 507
	public class CssSelectorTreeBuilder : Opaque
	{
		// Token: 0x06001210 RID: 4624 RVA: 0x00034E03 File Offset: 0x00033003
		public CssSelectorTreeBuilder(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000456 RID: 1110
		// (get) Token: 0x06001211 RID: 4625 RVA: 0x00034E0C File Offset: 0x0003300C
		public static AbiStruct abi_info
		{
			get
			{
				if (CssSelectorTreeBuilder._abi_info == null)
				{
					CssSelectorTreeBuilder._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssSelectorTreeBuilder._abi_info;
			}
		}

		// Token: 0x04000881 RID: 2177
		private static AbiStruct _abi_info;
	}
}
