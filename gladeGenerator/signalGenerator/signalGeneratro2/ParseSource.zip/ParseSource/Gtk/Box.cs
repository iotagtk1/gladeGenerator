﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x02000148 RID: 328
	public class Box : Container, IOrientable, IWrapper
	{
		// Token: 0x06000E05 RID: 3589 RVA: 0x0002A2B4 File Offset: 0x000284B4
		public Box(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000E06 RID: 3590 RVA: 0x0002A2C0 File Offset: 0x000284C0
		public Box(Orientation orientation, int spacing) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Box))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				list2.Add("orientation");
				list.Add(new Value(orientation));
				list2.Add("spacing");
				list.Add(new Value(spacing));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			this.Raw = Box.gtk_box_new((int)orientation, spacing);
		}

		// Token: 0x17000309 RID: 777
		// (get) Token: 0x06000E07 RID: 3591 RVA: 0x0002A353 File Offset: 0x00028553
		// (set) Token: 0x06000E08 RID: 3592 RVA: 0x0002A365 File Offset: 0x00028565
		[Property("spacing")]
		public int Spacing
		{
			get
			{
				return Box.gtk_box_get_spacing(base.Handle);
			}
			set
			{
				Box.gtk_box_set_spacing(base.Handle, value);
			}
		}

		// Token: 0x1700030A RID: 778
		// (get) Token: 0x06000E09 RID: 3593 RVA: 0x0002A378 File Offset: 0x00028578
		// (set) Token: 0x06000E0A RID: 3594 RVA: 0x0002A38A File Offset: 0x0002858A
		[Property("homogeneous")]
		public bool Homogeneous
		{
			get
			{
				return Box.gtk_box_get_homogeneous(base.Handle);
			}
			set
			{
				Box.gtk_box_set_homogeneous(base.Handle, value);
			}
		}

		// Token: 0x1700030B RID: 779
		// (get) Token: 0x06000E0B RID: 3595 RVA: 0x0002A39D File Offset: 0x0002859D
		// (set) Token: 0x06000E0C RID: 3596 RVA: 0x0002A3AF File Offset: 0x000285AF
		[Property("baseline-position")]
		public BaselinePosition BaselinePosition
		{
			get
			{
				return (BaselinePosition)Box.gtk_box_get_baseline_position(base.Handle);
			}
			set
			{
				Box.gtk_box_set_baseline_position(base.Handle, (int)value);
			}
		}

		// Token: 0x1700030C RID: 780
		// (get) Token: 0x06000E0D RID: 3597 RVA: 0x0002A3C4 File Offset: 0x000285C4
		// (set) Token: 0x06000E0E RID: 3598 RVA: 0x0002A3EC File Offset: 0x000285EC
		[Property("expand")]
		public new bool Expand
		{
			get
			{
				Value property = base.GetProperty("expand");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("expand", val);
				val.Dispose();
			}
		}

		// Token: 0x1700030D RID: 781
		// (get) Token: 0x06000E0F RID: 3599 RVA: 0x0002A414 File Offset: 0x00028614
		// (set) Token: 0x06000E10 RID: 3600 RVA: 0x0002A43C File Offset: 0x0002863C
		[Property("fill")]
		public bool Fill
		{
			get
			{
				Value property = base.GetProperty("fill");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("fill", val);
				val.Dispose();
			}
		}

		// Token: 0x1700030E RID: 782
		// (get) Token: 0x06000E11 RID: 3601 RVA: 0x0002A464 File Offset: 0x00028664
		// (set) Token: 0x06000E12 RID: 3602 RVA: 0x0002A48C File Offset: 0x0002868C
		[Property("padding")]
		public uint Padding
		{
			get
			{
				Value property = base.GetProperty("padding");
				uint result = (uint)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("padding", val);
				val.Dispose();
			}
		}

		// Token: 0x1700030F RID: 783
		// (get) Token: 0x06000E13 RID: 3603 RVA: 0x0002A4B4 File Offset: 0x000286B4
		// (set) Token: 0x06000E14 RID: 3604 RVA: 0x0002A4E0 File Offset: 0x000286E0
		[Property("pack-type")]
		public PackType PackType
		{
			get
			{
				Value property = base.GetProperty("pack-type");
				PackType result = (PackType)((Enum)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("pack-type", val);
				val.Dispose();
			}
		}

		// Token: 0x17000310 RID: 784
		// (get) Token: 0x06000E15 RID: 3605 RVA: 0x0002A510 File Offset: 0x00028710
		// (set) Token: 0x06000E16 RID: 3606 RVA: 0x0002A538 File Offset: 0x00028738
		[Property("position")]
		public int Position
		{
			get
			{
				Value property = base.GetProperty("position");
				int result = (int)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("position", val);
				val.Dispose();
			}
		}

		// Token: 0x17000311 RID: 785
		// (get) Token: 0x06000E17 RID: 3607 RVA: 0x0002A560 File Offset: 0x00028760
		public new static AbiStruct class_abi
		{
			get
			{
				if (Box._class_abi == null)
				{
					Box._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("_gtk_reserved1", Container.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Box._class_abi;
			}
		}

		// Token: 0x17000312 RID: 786
		// (get) Token: 0x06000E18 RID: 3608 RVA: 0x0002A67B File Offset: 0x0002887B
		// (set) Token: 0x06000E19 RID: 3609 RVA: 0x0002A697 File Offset: 0x00028897
		public Widget CenterWidget
		{
			get
			{
				return Object.GetObject(Box.gtk_box_get_center_widget(base.Handle)) as Widget;
			}
			set
			{
				Box.gtk_box_set_center_widget(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x17000313 RID: 787
		// (get) Token: 0x06000E1A RID: 3610 RVA: 0x0002A6BC File Offset: 0x000288BC
		public new static GType GType
		{
			get
			{
				IntPtr val = Box.gtk_box_get_type();
				return new GType(val);
			}
		}

		// Token: 0x06000E1B RID: 3611 RVA: 0x0002A6DA File Offset: 0x000288DA
		public void PackEnd(Widget child, bool expand, bool fill, uint padding)
		{
			Box.gtk_box_pack_end(base.Handle, (child == null) ? IntPtr.Zero : child.Handle, expand, fill, padding);
		}

		// Token: 0x06000E1C RID: 3612 RVA: 0x0002A700 File Offset: 0x00028900
		public void PackStart(Widget child, bool expand, bool fill, uint padding)
		{
			Box.gtk_box_pack_start(base.Handle, (child == null) ? IntPtr.Zero : child.Handle, expand, fill, padding);
		}

		// Token: 0x06000E1D RID: 3613 RVA: 0x0002A728 File Offset: 0x00028928
		public void QueryChildPacking(Widget child, out bool expand, out bool fill, out uint padding, out PackType pack_type)
		{
			int num;
			Box.gtk_box_query_child_packing(base.Handle, (child == null) ? IntPtr.Zero : child.Handle, out expand, out fill, out padding, out num);
			pack_type = (PackType)num;
		}

		// Token: 0x06000E1E RID: 3614 RVA: 0x0002A75F File Offset: 0x0002895F
		public void ReorderChild(Widget child, int position)
		{
			Box.gtk_box_reorder_child(base.Handle, (child == null) ? IntPtr.Zero : child.Handle, position);
		}

		// Token: 0x06000E1F RID: 3615 RVA: 0x0002A782 File Offset: 0x00028982
		public void SetChildPacking(Widget child, bool expand, bool fill, uint padding, PackType pack_type)
		{
			Box.gtk_box_set_child_packing(base.Handle, (child == null) ? IntPtr.Zero : child.Handle, expand, fill, padding, (int)pack_type);
		}

		// Token: 0x17000314 RID: 788
		// (get) Token: 0x06000E20 RID: 3616 RVA: 0x0002A7AA File Offset: 0x000289AA
		// (set) Token: 0x06000E21 RID: 3617 RVA: 0x0002A7BC File Offset: 0x000289BC
		[Property("orientation")]
		public Orientation Orientation
		{
			get
			{
				return (Orientation)Box.gtk_orientable_get_orientation(base.Handle);
			}
			set
			{
				Box.gtk_orientable_set_orientation(base.Handle, (int)value);
			}
		}

		// Token: 0x17000315 RID: 789
		// (get) Token: 0x06000E22 RID: 3618 RVA: 0x0002A7D0 File Offset: 0x000289D0
		public new static AbiStruct abi_info
		{
			get
			{
				if (Box._abi_info == null)
				{
					Box._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Container.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Box._abi_info;
			}
		}

		// Token: 0x040006E1 RID: 1761
		private static Box.d_gtk_box_new gtk_box_new = FuncLoader.LoadFunction<Box.d_gtk_box_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_box_new"));

		// Token: 0x040006E2 RID: 1762
		private static Box.d_gtk_box_get_spacing gtk_box_get_spacing = FuncLoader.LoadFunction<Box.d_gtk_box_get_spacing>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_box_get_spacing"));

		// Token: 0x040006E3 RID: 1763
		private static Box.d_gtk_box_set_spacing gtk_box_set_spacing = FuncLoader.LoadFunction<Box.d_gtk_box_set_spacing>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_box_set_spacing"));

		// Token: 0x040006E4 RID: 1764
		private static Box.d_gtk_box_get_homogeneous gtk_box_get_homogeneous = FuncLoader.LoadFunction<Box.d_gtk_box_get_homogeneous>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_box_get_homogeneous"));

		// Token: 0x040006E5 RID: 1765
		private static Box.d_gtk_box_set_homogeneous gtk_box_set_homogeneous = FuncLoader.LoadFunction<Box.d_gtk_box_set_homogeneous>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_box_set_homogeneous"));

		// Token: 0x040006E6 RID: 1766
		private static Box.d_gtk_box_get_baseline_position gtk_box_get_baseline_position = FuncLoader.LoadFunction<Box.d_gtk_box_get_baseline_position>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_box_get_baseline_position"));

		// Token: 0x040006E7 RID: 1767
		private static Box.d_gtk_box_set_baseline_position gtk_box_set_baseline_position = FuncLoader.LoadFunction<Box.d_gtk_box_set_baseline_position>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_box_set_baseline_position"));

		// Token: 0x040006E8 RID: 1768
		private static AbiStruct _class_abi = null;

		// Token: 0x040006E9 RID: 1769
		private static Box.d_gtk_box_get_center_widget gtk_box_get_center_widget = FuncLoader.LoadFunction<Box.d_gtk_box_get_center_widget>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_box_get_center_widget"));

		// Token: 0x040006EA RID: 1770
		private static Box.d_gtk_box_set_center_widget gtk_box_set_center_widget = FuncLoader.LoadFunction<Box.d_gtk_box_set_center_widget>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_box_set_center_widget"));

		// Token: 0x040006EB RID: 1771
		private static Box.d_gtk_box_get_type gtk_box_get_type = FuncLoader.LoadFunction<Box.d_gtk_box_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_box_get_type"));

		// Token: 0x040006EC RID: 1772
		private static Box.d_gtk_box_pack_end gtk_box_pack_end = FuncLoader.LoadFunction<Box.d_gtk_box_pack_end>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_box_pack_end"));

		// Token: 0x040006ED RID: 1773
		private static Box.d_gtk_box_pack_start gtk_box_pack_start = FuncLoader.LoadFunction<Box.d_gtk_box_pack_start>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_box_pack_start"));

		// Token: 0x040006EE RID: 1774
		private static Box.d_gtk_box_query_child_packing gtk_box_query_child_packing = FuncLoader.LoadFunction<Box.d_gtk_box_query_child_packing>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_box_query_child_packing"));

		// Token: 0x040006EF RID: 1775
		private static Box.d_gtk_box_reorder_child gtk_box_reorder_child = FuncLoader.LoadFunction<Box.d_gtk_box_reorder_child>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_box_reorder_child"));

		// Token: 0x040006F0 RID: 1776
		private static Box.d_gtk_box_set_child_packing gtk_box_set_child_packing = FuncLoader.LoadFunction<Box.d_gtk_box_set_child_packing>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_box_set_child_packing"));

		// Token: 0x040006F1 RID: 1777
		private static Box.d_gtk_orientable_get_orientation gtk_orientable_get_orientation = FuncLoader.LoadFunction<Box.d_gtk_orientable_get_orientation>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_orientable_get_orientation"));

		// Token: 0x040006F2 RID: 1778
		private static Box.d_gtk_orientable_set_orientation gtk_orientable_set_orientation = FuncLoader.LoadFunction<Box.d_gtk_orientable_set_orientation>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_orientable_set_orientation"));

		// Token: 0x040006F3 RID: 1779
		private static AbiStruct _abi_info = null;

		// Token: 0x02000AA1 RID: 2721
		// (Invoke) Token: 0x06005194 RID: 20884
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_box_new(int orientation, int spacing);

		// Token: 0x02000AA2 RID: 2722
		// (Invoke) Token: 0x06005198 RID: 20888
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_box_get_spacing(IntPtr raw);

		// Token: 0x02000AA3 RID: 2723
		// (Invoke) Token: 0x0600519C RID: 20892
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_box_set_spacing(IntPtr raw, int spacing);

		// Token: 0x02000AA4 RID: 2724
		// (Invoke) Token: 0x060051A0 RID: 20896
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_box_get_homogeneous(IntPtr raw);

		// Token: 0x02000AA5 RID: 2725
		// (Invoke) Token: 0x060051A4 RID: 20900
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_box_set_homogeneous(IntPtr raw, bool homogeneous);

		// Token: 0x02000AA6 RID: 2726
		// (Invoke) Token: 0x060051A8 RID: 20904
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_box_get_baseline_position(IntPtr raw);

		// Token: 0x02000AA7 RID: 2727
		// (Invoke) Token: 0x060051AC RID: 20908
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_box_set_baseline_position(IntPtr raw, int position);

		// Token: 0x02000AA8 RID: 2728
		// (Invoke) Token: 0x060051B0 RID: 20912
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_box_get_center_widget(IntPtr raw);

		// Token: 0x02000AA9 RID: 2729
		// (Invoke) Token: 0x060051B4 RID: 20916
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_box_set_center_widget(IntPtr raw, IntPtr widget);

		// Token: 0x02000AAA RID: 2730
		// (Invoke) Token: 0x060051B8 RID: 20920
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_box_get_type();

		// Token: 0x02000AAB RID: 2731
		// (Invoke) Token: 0x060051BC RID: 20924
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_box_pack_end(IntPtr raw, IntPtr child, bool expand, bool fill, uint padding);

		// Token: 0x02000AAC RID: 2732
		// (Invoke) Token: 0x060051C0 RID: 20928
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_box_pack_start(IntPtr raw, IntPtr child, bool expand, bool fill, uint padding);

		// Token: 0x02000AAD RID: 2733
		// (Invoke) Token: 0x060051C4 RID: 20932
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_box_query_child_packing(IntPtr raw, IntPtr child, out bool expand, out bool fill, out uint padding, out int pack_type);

		// Token: 0x02000AAE RID: 2734
		// (Invoke) Token: 0x060051C8 RID: 20936
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_box_reorder_child(IntPtr raw, IntPtr child, int position);

		// Token: 0x02000AAF RID: 2735
		// (Invoke) Token: 0x060051CC RID: 20940
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_box_set_child_packing(IntPtr raw, IntPtr child, bool expand, bool fill, uint padding, int pack_type);

		// Token: 0x02000AB0 RID: 2736
		// (Invoke) Token: 0x060051D0 RID: 20944
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_orientable_get_orientation(IntPtr raw);

		// Token: 0x02000AB1 RID: 2737
		// (Invoke) Token: 0x060051D4 RID: 20948
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_orientable_set_orientation(IntPtr raw, int orientation);
	}
}
