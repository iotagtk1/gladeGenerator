﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x02000121 RID: 289
	public class AppChooserDialog : Dialog, IAppChooser, IWrapper
	{
		// Token: 0x06000CC8 RID: 3272 RVA: 0x00026A17 File Offset: 0x00024C17
		public AppChooserDialog(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000CC9 RID: 3273 RVA: 0x00026A20 File Offset: 0x00024C20
		public AppChooserDialog(Window parent, DialogFlags flags, IFile file) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(AppChooserDialog))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				if (parent != null)
				{
					list2.Add("parent");
					list.Add(new Value(parent));
				}
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			this.Raw = AppChooserDialog.gtk_app_chooser_dialog_new((parent == null) ? IntPtr.Zero : parent.Handle, (int)flags, (file == null) ? IntPtr.Zero : ((file is Object) ? (file as Object).Handle : (file as FileAdapter).Handle));
		}

		// Token: 0x06000CCA RID: 3274 RVA: 0x00026AD4 File Offset: 0x00024CD4
		public AppChooserDialog(Window parent, DialogFlags flags, string content_type) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(AppChooserDialog))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				if (parent != null)
				{
					list2.Add("parent");
					list.Add(new Value(parent));
				}
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(content_type);
			this.Raw = AppChooserDialog.gtk_app_chooser_dialog_new_for_content_type((parent == null) ? IntPtr.Zero : parent.Handle, (int)flags, intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x170002B6 RID: 694
		// (get) Token: 0x06000CCB RID: 3275 RVA: 0x00026B6C File Offset: 0x00024D6C
		[Property("gfile")]
		public IFile Gfile
		{
			get
			{
				Value property = base.GetProperty("gfile");
				IFile @object = FileAdapter.GetObject((Object)property);
				property.Dispose();
				return @object;
			}
		}

		// Token: 0x170002B7 RID: 695
		// (get) Token: 0x06000CCC RID: 3276 RVA: 0x00026B97 File Offset: 0x00024D97
		// (set) Token: 0x06000CCD RID: 3277 RVA: 0x00026BB0 File Offset: 0x00024DB0
		[Property("heading")]
		public string Heading
		{
			get
			{
				return Marshaller.Utf8PtrToString(AppChooserDialog.gtk_app_chooser_dialog_get_heading(base.Handle));
			}
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				AppChooserDialog.gtk_app_chooser_dialog_set_heading(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x170002B8 RID: 696
		// (get) Token: 0x06000CCE RID: 3278 RVA: 0x00026BDC File Offset: 0x00024DDC
		public new static AbiStruct class_abi
		{
			get
			{
				if (AppChooserDialog._class_abi == null)
				{
					AppChooserDialog._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("padding", Dialog.class_abi.Fields, (uint)(Marshal.SizeOf(typeof(IntPtr)) * 16), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return AppChooserDialog._class_abi;
			}
		}

		// Token: 0x170002B9 RID: 697
		// (get) Token: 0x06000CCF RID: 3279 RVA: 0x00026C44 File Offset: 0x00024E44
		public new static GType GType
		{
			get
			{
				IntPtr val = AppChooserDialog.gtk_app_chooser_dialog_get_type();
				return new GType(val);
			}
		}

		// Token: 0x170002BA RID: 698
		// (get) Token: 0x06000CD0 RID: 3280 RVA: 0x00026C62 File Offset: 0x00024E62
		public Widget Widget
		{
			get
			{
				return Object.GetObject(AppChooserDialog.gtk_app_chooser_dialog_get_widget(base.Handle)) as Widget;
			}
		}

		// Token: 0x170002BB RID: 699
		// (get) Token: 0x06000CD1 RID: 3281 RVA: 0x00026C7E File Offset: 0x00024E7E
		public IAppInfo AppInfo
		{
			get
			{
				return AppInfoAdapter.GetObject(AppChooserDialog.gtk_app_chooser_get_app_info(base.Handle), false);
			}
		}

		// Token: 0x170002BC RID: 700
		// (get) Token: 0x06000CD2 RID: 3282 RVA: 0x00026C96 File Offset: 0x00024E96
		public string ContentType
		{
			get
			{
				return Marshaller.PtrToStringGFree(AppChooserDialog.gtk_app_chooser_get_content_type(base.Handle));
			}
		}

		// Token: 0x06000CD3 RID: 3283 RVA: 0x00026CAD File Offset: 0x00024EAD
		public void Refresh()
		{
			AppChooserDialog.gtk_app_chooser_refresh(base.Handle);
		}

		// Token: 0x170002BD RID: 701
		// (get) Token: 0x06000CD4 RID: 3284 RVA: 0x00026CC0 File Offset: 0x00024EC0
		public new static AbiStruct abi_info
		{
			get
			{
				if (AppChooserDialog._abi_info == null)
				{
					AppChooserDialog._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Dialog.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return AppChooserDialog._abi_info;
			}
		}

		// Token: 0x0400062E RID: 1582
		private static AppChooserDialog.d_gtk_app_chooser_dialog_new gtk_app_chooser_dialog_new = FuncLoader.LoadFunction<AppChooserDialog.d_gtk_app_chooser_dialog_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_dialog_new"));

		// Token: 0x0400062F RID: 1583
		private static AppChooserDialog.d_gtk_app_chooser_dialog_new_for_content_type gtk_app_chooser_dialog_new_for_content_type = FuncLoader.LoadFunction<AppChooserDialog.d_gtk_app_chooser_dialog_new_for_content_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_dialog_new_for_content_type"));

		// Token: 0x04000630 RID: 1584
		private static AppChooserDialog.d_gtk_app_chooser_dialog_get_heading gtk_app_chooser_dialog_get_heading = FuncLoader.LoadFunction<AppChooserDialog.d_gtk_app_chooser_dialog_get_heading>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_dialog_get_heading"));

		// Token: 0x04000631 RID: 1585
		private static AppChooserDialog.d_gtk_app_chooser_dialog_set_heading gtk_app_chooser_dialog_set_heading = FuncLoader.LoadFunction<AppChooserDialog.d_gtk_app_chooser_dialog_set_heading>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_dialog_set_heading"));

		// Token: 0x04000632 RID: 1586
		private static AbiStruct _class_abi = null;

		// Token: 0x04000633 RID: 1587
		private static AppChooserDialog.d_gtk_app_chooser_dialog_get_type gtk_app_chooser_dialog_get_type = FuncLoader.LoadFunction<AppChooserDialog.d_gtk_app_chooser_dialog_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_dialog_get_type"));

		// Token: 0x04000634 RID: 1588
		private static AppChooserDialog.d_gtk_app_chooser_dialog_get_widget gtk_app_chooser_dialog_get_widget = FuncLoader.LoadFunction<AppChooserDialog.d_gtk_app_chooser_dialog_get_widget>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_dialog_get_widget"));

		// Token: 0x04000635 RID: 1589
		private static AppChooserDialog.d_gtk_app_chooser_get_app_info gtk_app_chooser_get_app_info = FuncLoader.LoadFunction<AppChooserDialog.d_gtk_app_chooser_get_app_info>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_get_app_info"));

		// Token: 0x04000636 RID: 1590
		private static AppChooserDialog.d_gtk_app_chooser_get_content_type gtk_app_chooser_get_content_type = FuncLoader.LoadFunction<AppChooserDialog.d_gtk_app_chooser_get_content_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_get_content_type"));

		// Token: 0x04000637 RID: 1591
		private static AppChooserDialog.d_gtk_app_chooser_refresh gtk_app_chooser_refresh = FuncLoader.LoadFunction<AppChooserDialog.d_gtk_app_chooser_refresh>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_refresh"));

		// Token: 0x04000638 RID: 1592
		private static AbiStruct _abi_info = null;

		// Token: 0x02000A35 RID: 2613
		// (Invoke) Token: 0x06004FDB RID: 20443
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_app_chooser_dialog_new(IntPtr parent, int flags, IntPtr file);

		// Token: 0x02000A36 RID: 2614
		// (Invoke) Token: 0x06004FDF RID: 20447
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_app_chooser_dialog_new_for_content_type(IntPtr parent, int flags, IntPtr content_type);

		// Token: 0x02000A37 RID: 2615
		// (Invoke) Token: 0x06004FE3 RID: 20451
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_app_chooser_dialog_get_heading(IntPtr raw);

		// Token: 0x02000A38 RID: 2616
		// (Invoke) Token: 0x06004FE7 RID: 20455
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_app_chooser_dialog_set_heading(IntPtr raw, IntPtr heading);

		// Token: 0x02000A39 RID: 2617
		// (Invoke) Token: 0x06004FEB RID: 20459
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_app_chooser_dialog_get_type();

		// Token: 0x02000A3A RID: 2618
		// (Invoke) Token: 0x06004FEF RID: 20463
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_app_chooser_dialog_get_widget(IntPtr raw);

		// Token: 0x02000A3B RID: 2619
		// (Invoke) Token: 0x06004FF3 RID: 20467
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_app_chooser_get_app_info(IntPtr raw);

		// Token: 0x02000A3C RID: 2620
		// (Invoke) Token: 0x06004FF7 RID: 20471
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_app_chooser_get_content_type(IntPtr raw);

		// Token: 0x02000A3D RID: 2621
		// (Invoke) Token: 0x06004FFB RID: 20475
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_app_chooser_refresh(IntPtr raw);
	}
}
