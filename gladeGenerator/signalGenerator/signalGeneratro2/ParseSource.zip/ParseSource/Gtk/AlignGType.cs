﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x0200011B RID: 283
	internal class AlignGType
	{
		// Token: 0x17000298 RID: 664
		// (get) Token: 0x06000C80 RID: 3200 RVA: 0x00025CD4 File Offset: 0x00023ED4
		public static GType GType
		{
			get
			{
				return new GType(AlignGType.gtk_align_get_type());
			}
		}

		// Token: 0x0400060F RID: 1551
		private static AlignGType.d_gtk_align_get_type gtk_align_get_type = FuncLoader.LoadFunction<AlignGType.d_gtk_align_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_align_get_type"));

		// Token: 0x02000A1C RID: 2588
		// (Invoke) Token: 0x06004F77 RID: 20343
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_align_get_type();
	}
}
