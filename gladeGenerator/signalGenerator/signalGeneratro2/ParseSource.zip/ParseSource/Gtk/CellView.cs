﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Gdk;
using GLib;
using GtkSharp;

namespace Gtk
{
	// Token: 0x020000DE RID: 222
	public class CellView : Widget, ICellLayout, IWrapper, IOrientable
	{
		// Token: 0x0600068A RID: 1674 RVA: 0x00012DCC File Offset: 0x00010FCC
		public void SetAttributes(CellRenderer cell, params object[] attrs)
		{
			if (attrs.Length % 2 != 0)
			{
				throw new ArgumentException("attrs should contain pairs of attribute/col");
			}
			this.ClearAttributes(cell);
			for (int i = 0; i < attrs.Length - 1; i += 2)
			{
				this.AddAttribute(cell, (string)attrs[i], (int)attrs[i + 1]);
			}
		}

		// Token: 0x0600068B RID: 1675 RVA: 0x00012E1B File Offset: 0x0001101B
		public CellView(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x0600068C RID: 1676 RVA: 0x00012E24 File Offset: 0x00011024
		public CellView() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(CellView))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = CellView.gtk_cell_view_new();
		}

		// Token: 0x0600068D RID: 1677 RVA: 0x00012E78 File Offset: 0x00011078
		public CellView(CellArea area, CellAreaContext context) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(CellView))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			this.Raw = CellView.gtk_cell_view_new_with_context((area == null) ? IntPtr.Zero : area.Handle, (context == null) ? IntPtr.Zero : context.Handle);
		}

		// Token: 0x0600068E RID: 1678 RVA: 0x00012EF8 File Offset: 0x000110F8
		public CellView(string markup) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(CellView))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(markup);
			this.Raw = CellView.gtk_cell_view_new_with_markup(intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x0600068F RID: 1679 RVA: 0x00012F64 File Offset: 0x00011164
		public CellView(Pixbuf pixbuf) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(CellView))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			this.Raw = CellView.gtk_cell_view_new_with_pixbuf((pixbuf == null) ? IntPtr.Zero : pixbuf.Handle);
		}

		// Token: 0x06000690 RID: 1680 RVA: 0x00012FD4 File Offset: 0x000111D4
		public static CellView NewWithText(string text)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(text);
			CellView result = new CellView(CellView.gtk_cell_view_new_with_text(intPtr));
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x17000104 RID: 260
		// (set) Token: 0x06000691 RID: 1681 RVA: 0x00013000 File Offset: 0x00011200
		[Property("background")]
		public string Background
		{
			set
			{
				Value val = new Value(value);
				base.SetProperty("background", val);
				val.Dispose();
			}
		}

		// Token: 0x17000105 RID: 261
		// (get) Token: 0x06000692 RID: 1682 RVA: 0x00013028 File Offset: 0x00011228
		// (set) Token: 0x06000693 RID: 1683 RVA: 0x00013050 File Offset: 0x00011250
		[Property("background-gdk")]
		public Color BackgroundGdk
		{
			get
			{
				Value property = base.GetProperty("background-gdk");
				Color result = (Color)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = (Value)value;
				base.SetProperty("background-gdk", val);
				val.Dispose();
			}
		}

		// Token: 0x17000106 RID: 262
		// (get) Token: 0x06000694 RID: 1684 RVA: 0x00013078 File Offset: 0x00011278
		// (set) Token: 0x06000695 RID: 1685 RVA: 0x000130A0 File Offset: 0x000112A0
		[Property("background-rgba")]
		public RGBA BackgroundRgba
		{
			get
			{
				Value property = base.GetProperty("background-rgba");
				RGBA result = (RGBA)property;
				property.Dispose();
				return result;
			}
			set
			{
				IntPtr intPtr = Marshaller.StructureToPtrAlloc(value);
				CellView.gtk_cell_view_set_background_rgba(base.Handle, intPtr);
				Marshal.FreeHGlobal(intPtr);
			}
		}

		// Token: 0x17000107 RID: 263
		// (get) Token: 0x06000696 RID: 1686 RVA: 0x000130D0 File Offset: 0x000112D0
		// (set) Token: 0x06000697 RID: 1687 RVA: 0x000130E8 File Offset: 0x000112E8
		[Property("model")]
		public ITreeModel Model
		{
			get
			{
				return TreeModelAdapter.GetObject(CellView.gtk_cell_view_get_model(base.Handle), false);
			}
			set
			{
				CellView.gtk_cell_view_set_model(base.Handle, (value == null) ? IntPtr.Zero : ((value is Object) ? (value as Object).Handle : (value as TreeModelAdapter).Handle));
			}
		}

		// Token: 0x17000108 RID: 264
		// (get) Token: 0x06000698 RID: 1688 RVA: 0x00013124 File Offset: 0x00011324
		[Property("cell-area")]
		public CellArea CellArea
		{
			get
			{
				Value property = base.GetProperty("cell-area");
				CellArea result = (CellArea)((Object)property);
				property.Dispose();
				return result;
			}
		}

		// Token: 0x17000109 RID: 265
		// (get) Token: 0x06000699 RID: 1689 RVA: 0x00013150 File Offset: 0x00011350
		[Property("cell-area-context")]
		public CellAreaContext CellAreaContext
		{
			get
			{
				Value property = base.GetProperty("cell-area-context");
				CellAreaContext result = (CellAreaContext)((Object)property);
				property.Dispose();
				return result;
			}
		}

		// Token: 0x1700010A RID: 266
		// (get) Token: 0x0600069A RID: 1690 RVA: 0x0001317B File Offset: 0x0001137B
		// (set) Token: 0x0600069B RID: 1691 RVA: 0x0001318D File Offset: 0x0001138D
		[Property("draw-sensitive")]
		public bool DrawSensitive
		{
			get
			{
				return CellView.gtk_cell_view_get_draw_sensitive(base.Handle);
			}
			set
			{
				CellView.gtk_cell_view_set_draw_sensitive(base.Handle, value);
			}
		}

		// Token: 0x1700010B RID: 267
		// (get) Token: 0x0600069C RID: 1692 RVA: 0x000131A0 File Offset: 0x000113A0
		// (set) Token: 0x0600069D RID: 1693 RVA: 0x000131B2 File Offset: 0x000113B2
		[Property("fit-model")]
		public bool FitModel
		{
			get
			{
				return CellView.gtk_cell_view_get_fit_model(base.Handle);
			}
			set
			{
				CellView.gtk_cell_view_set_fit_model(base.Handle, value);
			}
		}

		// Token: 0x1700010C RID: 268
		// (get) Token: 0x0600069E RID: 1694 RVA: 0x000131C8 File Offset: 0x000113C8
		public new static AbiStruct class_abi
		{
			get
			{
				if (CellView._class_abi == null)
				{
					CellView._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("_gtk_reserved1", Widget.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellView._class_abi;
			}
		}

		// Token: 0x1700010D RID: 269
		// (get) Token: 0x0600069F RID: 1695 RVA: 0x000132E4 File Offset: 0x000114E4
		// (set) Token: 0x060006A0 RID: 1696 RVA: 0x00013327 File Offset: 0x00011527
		public TreePath DisplayedRow
		{
			get
			{
				IntPtr intPtr = CellView.gtk_cell_view_get_displayed_row(base.Handle);
				if (!(intPtr == IntPtr.Zero))
				{
					return (TreePath)Opaque.GetOpaque(intPtr, typeof(TreePath), false);
				}
				return null;
			}
			set
			{
				CellView.gtk_cell_view_set_displayed_row(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x060006A1 RID: 1697 RVA: 0x0001334C File Offset: 0x0001154C
		[Obsolete]
		public bool GetSizeOfRow(TreePath path, Requisition requisition)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(requisition);
			bool result = CellView.gtk_cell_view_get_size_of_row(base.Handle, (path == null) ? IntPtr.Zero : path.Handle, intPtr);
			Marshal.FreeHGlobal(intPtr);
			return result;
		}

		// Token: 0x1700010E RID: 270
		// (get) Token: 0x060006A2 RID: 1698 RVA: 0x0001338C File Offset: 0x0001158C
		public new static GType GType
		{
			get
			{
				IntPtr val = CellView.gtk_cell_view_get_type();
				return new GType(val);
			}
		}

		// Token: 0x1700010F RID: 271
		// (set) Token: 0x060006A3 RID: 1699 RVA: 0x000133AC File Offset: 0x000115AC
		[Obsolete]
		public Color BackgroundColor
		{
			set
			{
				IntPtr intPtr = Marshaller.StructureToPtrAlloc(value);
				CellView.gtk_cell_view_set_background_color(base.Handle, intPtr);
				Marshal.FreeHGlobal(intPtr);
			}
		}

		// Token: 0x060006A4 RID: 1700 RVA: 0x000133DC File Offset: 0x000115DC
		public void AddAttribute(CellRenderer cell, string attribute, int column)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(attribute);
			CellView.gtk_cell_layout_add_attribute(base.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, intPtr, column);
			Marshaller.Free(intPtr);
		}

		// Token: 0x060006A5 RID: 1701 RVA: 0x00013418 File Offset: 0x00011618
		public void Clear()
		{
			CellView.gtk_cell_layout_clear(base.Handle);
		}

		// Token: 0x060006A6 RID: 1702 RVA: 0x0001342A File Offset: 0x0001162A
		public void ClearAttributes(CellRenderer cell)
		{
			CellView.gtk_cell_layout_clear_attributes(base.Handle, (cell == null) ? IntPtr.Zero : cell.Handle);
		}

		// Token: 0x17000110 RID: 272
		// (get) Token: 0x060006A7 RID: 1703 RVA: 0x0001344C File Offset: 0x0001164C
		public CellArea Area
		{
			get
			{
				return Object.GetObject(CellView.gtk_cell_layout_get_area(base.Handle)) as CellArea;
			}
		}

		// Token: 0x17000111 RID: 273
		// (get) Token: 0x060006A8 RID: 1704 RVA: 0x00013468 File Offset: 0x00011668
		public CellRenderer[] Cells
		{
			get
			{
				return (CellRenderer[])Marshaller.ListPtrToArray(CellView.gtk_cell_layout_get_cells(base.Handle), typeof(List), true, false, typeof(CellRenderer));
			}
		}

		// Token: 0x060006A9 RID: 1705 RVA: 0x0001349A File Offset: 0x0001169A
		public void PackEnd(CellRenderer cell, bool expand)
		{
			CellView.gtk_cell_layout_pack_end(base.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, expand);
		}

		// Token: 0x060006AA RID: 1706 RVA: 0x000134BD File Offset: 0x000116BD
		public void PackStart(CellRenderer cell, bool expand)
		{
			CellView.gtk_cell_layout_pack_start(base.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, expand);
		}

		// Token: 0x060006AB RID: 1707 RVA: 0x000134E0 File Offset: 0x000116E0
		public void Reorder(CellRenderer cell, int position)
		{
			CellView.gtk_cell_layout_reorder(base.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, position);
		}

		// Token: 0x060006AC RID: 1708 RVA: 0x00013504 File Offset: 0x00011704
		public void SetCellDataFunc(CellRenderer cell, CellLayoutDataFunc func)
		{
			CellLayoutDataFuncWrapper cellLayoutDataFuncWrapper = new CellLayoutDataFuncWrapper(func);
			IntPtr func_data;
			DestroyNotify destroy;
			if (func == null)
			{
				func_data = IntPtr.Zero;
				destroy = null;
			}
			else
			{
				func_data = (IntPtr)GCHandle.Alloc(cellLayoutDataFuncWrapper);
				destroy = DestroyHelper.NotifyHandler;
			}
			CellView.gtk_cell_layout_set_cell_data_func(base.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, cellLayoutDataFuncWrapper.NativeDelegate, func_data, destroy);
		}

		// Token: 0x17000112 RID: 274
		// (get) Token: 0x060006AD RID: 1709 RVA: 0x0001355F File Offset: 0x0001175F
		// (set) Token: 0x060006AE RID: 1710 RVA: 0x00013571 File Offset: 0x00011771
		[Property("orientation")]
		public Orientation Orientation
		{
			get
			{
				return (Orientation)CellView.gtk_orientable_get_orientation(base.Handle);
			}
			set
			{
				CellView.gtk_orientable_set_orientation(base.Handle, (int)value);
			}
		}

		// Token: 0x17000113 RID: 275
		// (get) Token: 0x060006AF RID: 1711 RVA: 0x00013584 File Offset: 0x00011784
		public new static AbiStruct abi_info
		{
			get
			{
				if (CellView._abi_info == null)
				{
					CellView._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Widget.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellView._abi_info;
			}
		}

		// Token: 0x04000333 RID: 819
		private static CellView.d_gtk_cell_view_new gtk_cell_view_new = FuncLoader.LoadFunction<CellView.d_gtk_cell_view_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_view_new"));

		// Token: 0x04000334 RID: 820
		private static CellView.d_gtk_cell_view_new_with_context gtk_cell_view_new_with_context = FuncLoader.LoadFunction<CellView.d_gtk_cell_view_new_with_context>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_view_new_with_context"));

		// Token: 0x04000335 RID: 821
		private static CellView.d_gtk_cell_view_new_with_markup gtk_cell_view_new_with_markup = FuncLoader.LoadFunction<CellView.d_gtk_cell_view_new_with_markup>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_view_new_with_markup"));

		// Token: 0x04000336 RID: 822
		private static CellView.d_gtk_cell_view_new_with_pixbuf gtk_cell_view_new_with_pixbuf = FuncLoader.LoadFunction<CellView.d_gtk_cell_view_new_with_pixbuf>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_view_new_with_pixbuf"));

		// Token: 0x04000337 RID: 823
		private static CellView.d_gtk_cell_view_new_with_text gtk_cell_view_new_with_text = FuncLoader.LoadFunction<CellView.d_gtk_cell_view_new_with_text>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_view_new_with_text"));

		// Token: 0x04000338 RID: 824
		private static CellView.d_gtk_cell_view_set_background_rgba gtk_cell_view_set_background_rgba = FuncLoader.LoadFunction<CellView.d_gtk_cell_view_set_background_rgba>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_view_set_background_rgba"));

		// Token: 0x04000339 RID: 825
		private static CellView.d_gtk_cell_view_get_model gtk_cell_view_get_model = FuncLoader.LoadFunction<CellView.d_gtk_cell_view_get_model>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_view_get_model"));

		// Token: 0x0400033A RID: 826
		private static CellView.d_gtk_cell_view_set_model gtk_cell_view_set_model = FuncLoader.LoadFunction<CellView.d_gtk_cell_view_set_model>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_view_set_model"));

		// Token: 0x0400033B RID: 827
		private static CellView.d_gtk_cell_view_get_draw_sensitive gtk_cell_view_get_draw_sensitive = FuncLoader.LoadFunction<CellView.d_gtk_cell_view_get_draw_sensitive>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_view_get_draw_sensitive"));

		// Token: 0x0400033C RID: 828
		private static CellView.d_gtk_cell_view_set_draw_sensitive gtk_cell_view_set_draw_sensitive = FuncLoader.LoadFunction<CellView.d_gtk_cell_view_set_draw_sensitive>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_view_set_draw_sensitive"));

		// Token: 0x0400033D RID: 829
		private static CellView.d_gtk_cell_view_get_fit_model gtk_cell_view_get_fit_model = FuncLoader.LoadFunction<CellView.d_gtk_cell_view_get_fit_model>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_view_get_fit_model"));

		// Token: 0x0400033E RID: 830
		private static CellView.d_gtk_cell_view_set_fit_model gtk_cell_view_set_fit_model = FuncLoader.LoadFunction<CellView.d_gtk_cell_view_set_fit_model>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_view_set_fit_model"));

		// Token: 0x0400033F RID: 831
		private static AbiStruct _class_abi = null;

		// Token: 0x04000340 RID: 832
		private static CellView.d_gtk_cell_view_get_displayed_row gtk_cell_view_get_displayed_row = FuncLoader.LoadFunction<CellView.d_gtk_cell_view_get_displayed_row>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_view_get_displayed_row"));

		// Token: 0x04000341 RID: 833
		private static CellView.d_gtk_cell_view_set_displayed_row gtk_cell_view_set_displayed_row = FuncLoader.LoadFunction<CellView.d_gtk_cell_view_set_displayed_row>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_view_set_displayed_row"));

		// Token: 0x04000342 RID: 834
		private static CellView.d_gtk_cell_view_get_size_of_row gtk_cell_view_get_size_of_row = FuncLoader.LoadFunction<CellView.d_gtk_cell_view_get_size_of_row>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_view_get_size_of_row"));

		// Token: 0x04000343 RID: 835
		private static CellView.d_gtk_cell_view_get_type gtk_cell_view_get_type = FuncLoader.LoadFunction<CellView.d_gtk_cell_view_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_view_get_type"));

		// Token: 0x04000344 RID: 836
		private static CellView.d_gtk_cell_view_set_background_color gtk_cell_view_set_background_color = FuncLoader.LoadFunction<CellView.d_gtk_cell_view_set_background_color>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_view_set_background_color"));

		// Token: 0x04000345 RID: 837
		private static CellView.d_gtk_cell_layout_add_attribute gtk_cell_layout_add_attribute = FuncLoader.LoadFunction<CellView.d_gtk_cell_layout_add_attribute>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_add_attribute"));

		// Token: 0x04000346 RID: 838
		private static CellView.d_gtk_cell_layout_clear gtk_cell_layout_clear = FuncLoader.LoadFunction<CellView.d_gtk_cell_layout_clear>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_clear"));

		// Token: 0x04000347 RID: 839
		private static CellView.d_gtk_cell_layout_clear_attributes gtk_cell_layout_clear_attributes = FuncLoader.LoadFunction<CellView.d_gtk_cell_layout_clear_attributes>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_clear_attributes"));

		// Token: 0x04000348 RID: 840
		private static CellView.d_gtk_cell_layout_get_area gtk_cell_layout_get_area = FuncLoader.LoadFunction<CellView.d_gtk_cell_layout_get_area>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_get_area"));

		// Token: 0x04000349 RID: 841
		private static CellView.d_gtk_cell_layout_get_cells gtk_cell_layout_get_cells = FuncLoader.LoadFunction<CellView.d_gtk_cell_layout_get_cells>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_get_cells"));

		// Token: 0x0400034A RID: 842
		private static CellView.d_gtk_cell_layout_pack_end gtk_cell_layout_pack_end = FuncLoader.LoadFunction<CellView.d_gtk_cell_layout_pack_end>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_pack_end"));

		// Token: 0x0400034B RID: 843
		private static CellView.d_gtk_cell_layout_pack_start gtk_cell_layout_pack_start = FuncLoader.LoadFunction<CellView.d_gtk_cell_layout_pack_start>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_pack_start"));

		// Token: 0x0400034C RID: 844
		private static CellView.d_gtk_cell_layout_reorder gtk_cell_layout_reorder = FuncLoader.LoadFunction<CellView.d_gtk_cell_layout_reorder>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_reorder"));

		// Token: 0x0400034D RID: 845
		private static CellView.d_gtk_cell_layout_set_cell_data_func gtk_cell_layout_set_cell_data_func = FuncLoader.LoadFunction<CellView.d_gtk_cell_layout_set_cell_data_func>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_set_cell_data_func"));

		// Token: 0x0400034E RID: 846
		private static CellView.d_gtk_orientable_get_orientation gtk_orientable_get_orientation = FuncLoader.LoadFunction<CellView.d_gtk_orientable_get_orientation>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_orientable_get_orientation"));

		// Token: 0x0400034F RID: 847
		private static CellView.d_gtk_orientable_set_orientation gtk_orientable_set_orientation = FuncLoader.LoadFunction<CellView.d_gtk_orientable_set_orientation>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_orientable_set_orientation"));

		// Token: 0x04000350 RID: 848
		private static AbiStruct _abi_info = null;

		// Token: 0x0200076B RID: 1899
		// (Invoke) Token: 0x060044CC RID: 17612
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_view_new();

		// Token: 0x0200076C RID: 1900
		// (Invoke) Token: 0x060044D0 RID: 17616
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_view_new_with_context(IntPtr area, IntPtr context);

		// Token: 0x0200076D RID: 1901
		// (Invoke) Token: 0x060044D4 RID: 17620
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_view_new_with_markup(IntPtr markup);

		// Token: 0x0200076E RID: 1902
		// (Invoke) Token: 0x060044D8 RID: 17624
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_view_new_with_pixbuf(IntPtr pixbuf);

		// Token: 0x0200076F RID: 1903
		// (Invoke) Token: 0x060044DC RID: 17628
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_view_new_with_text(IntPtr text);

		// Token: 0x02000770 RID: 1904
		// (Invoke) Token: 0x060044E0 RID: 17632
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_view_set_background_rgba(IntPtr raw, IntPtr value);

		// Token: 0x02000771 RID: 1905
		// (Invoke) Token: 0x060044E4 RID: 17636
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_view_get_model(IntPtr raw);

		// Token: 0x02000772 RID: 1906
		// (Invoke) Token: 0x060044E8 RID: 17640
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_view_set_model(IntPtr raw, IntPtr model);

		// Token: 0x02000773 RID: 1907
		// (Invoke) Token: 0x060044EC RID: 17644
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_cell_view_get_draw_sensitive(IntPtr raw);

		// Token: 0x02000774 RID: 1908
		// (Invoke) Token: 0x060044F0 RID: 17648
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_view_set_draw_sensitive(IntPtr raw, bool draw_sensitive);

		// Token: 0x02000775 RID: 1909
		// (Invoke) Token: 0x060044F4 RID: 17652
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_cell_view_get_fit_model(IntPtr raw);

		// Token: 0x02000776 RID: 1910
		// (Invoke) Token: 0x060044F8 RID: 17656
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_view_set_fit_model(IntPtr raw, bool fit_model);

		// Token: 0x02000777 RID: 1911
		// (Invoke) Token: 0x060044FC RID: 17660
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_view_get_displayed_row(IntPtr raw);

		// Token: 0x02000778 RID: 1912
		// (Invoke) Token: 0x06004500 RID: 17664
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_view_set_displayed_row(IntPtr raw, IntPtr path);

		// Token: 0x02000779 RID: 1913
		// (Invoke) Token: 0x06004504 RID: 17668
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_cell_view_get_size_of_row(IntPtr raw, IntPtr path, IntPtr requisition);

		// Token: 0x0200077A RID: 1914
		// (Invoke) Token: 0x06004508 RID: 17672
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_view_get_type();

		// Token: 0x0200077B RID: 1915
		// (Invoke) Token: 0x0600450C RID: 17676
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_view_set_background_color(IntPtr raw, IntPtr value);

		// Token: 0x0200077C RID: 1916
		// (Invoke) Token: 0x06004510 RID: 17680
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_add_attribute(IntPtr raw, IntPtr cell, IntPtr attribute, int column);

		// Token: 0x0200077D RID: 1917
		// (Invoke) Token: 0x06004514 RID: 17684
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_clear(IntPtr raw);

		// Token: 0x0200077E RID: 1918
		// (Invoke) Token: 0x06004518 RID: 17688
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_clear_attributes(IntPtr raw, IntPtr cell);

		// Token: 0x0200077F RID: 1919
		// (Invoke) Token: 0x0600451C RID: 17692
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_layout_get_area(IntPtr raw);

		// Token: 0x02000780 RID: 1920
		// (Invoke) Token: 0x06004520 RID: 17696
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_layout_get_cells(IntPtr raw);

		// Token: 0x02000781 RID: 1921
		// (Invoke) Token: 0x06004524 RID: 17700
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_pack_end(IntPtr raw, IntPtr cell, bool expand);

		// Token: 0x02000782 RID: 1922
		// (Invoke) Token: 0x06004528 RID: 17704
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_pack_start(IntPtr raw, IntPtr cell, bool expand);

		// Token: 0x02000783 RID: 1923
		// (Invoke) Token: 0x0600452C RID: 17708
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_reorder(IntPtr raw, IntPtr cell, int position);

		// Token: 0x02000784 RID: 1924
		// (Invoke) Token: 0x06004530 RID: 17712
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_set_cell_data_func(IntPtr raw, IntPtr cell, CellLayoutDataFuncNative func, IntPtr func_data, DestroyNotify destroy);

		// Token: 0x02000785 RID: 1925
		// (Invoke) Token: 0x06004534 RID: 17716
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_orientable_get_orientation(IntPtr raw);

		// Token: 0x02000786 RID: 1926
		// (Invoke) Token: 0x06004538 RID: 17720
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_orientable_set_orientation(IntPtr raw, int orientation);
	}
}
