﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x02000144 RID: 324
	public class BorderImage : Opaque
	{
		// Token: 0x06000DFE RID: 3582 RVA: 0x0002A232 File Offset: 0x00028432
		public BorderImage(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000306 RID: 774
		// (get) Token: 0x06000DFF RID: 3583 RVA: 0x0002A23B File Offset: 0x0002843B
		public static AbiStruct abi_info
		{
			get
			{
				if (BorderImage._abi_info == null)
				{
					BorderImage._abi_info = new AbiStruct(new List<AbiField>());
				}
				return BorderImage._abi_info;
			}
		}

		// Token: 0x040006D3 RID: 1747
		private static AbiStruct _abi_info;
	}
}
