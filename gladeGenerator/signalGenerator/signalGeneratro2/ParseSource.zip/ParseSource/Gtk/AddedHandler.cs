﻿using System;

namespace Gtk
{
	// Token: 0x02000114 RID: 276
	// (Invoke) Token: 0x06000C6F RID: 3183
	public delegate void AddedHandler(object o, AddedArgs args);
}
