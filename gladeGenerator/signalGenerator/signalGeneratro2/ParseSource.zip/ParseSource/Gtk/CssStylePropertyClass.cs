﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x02000204 RID: 516
	public class CssStylePropertyClass : Opaque
	{
		// Token: 0x06001222 RID: 4642 RVA: 0x00034F59 File Offset: 0x00033159
		public CssStylePropertyClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700045F RID: 1119
		// (get) Token: 0x06001223 RID: 4643 RVA: 0x00034F62 File Offset: 0x00033162
		public static AbiStruct abi_info
		{
			get
			{
				if (CssStylePropertyClass._abi_info == null)
				{
					CssStylePropertyClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssStylePropertyClass._abi_info;
			}
		}

		// Token: 0x0400088A RID: 2186
		private static AbiStruct _abi_info;
	}
}
