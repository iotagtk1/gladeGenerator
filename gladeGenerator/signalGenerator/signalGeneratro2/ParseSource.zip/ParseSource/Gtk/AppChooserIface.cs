﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x02000122 RID: 290
	public class AppChooserIface : Opaque
	{
		// Token: 0x06000CD6 RID: 3286 RVA: 0x00026E30 File Offset: 0x00025030
		public AppChooserIface(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170002BE RID: 702
		// (get) Token: 0x06000CD7 RID: 3287 RVA: 0x00026E39 File Offset: 0x00025039
		public static AbiStruct abi_info
		{
			get
			{
				if (AppChooserIface._abi_info == null)
				{
					AppChooserIface._abi_info = new AbiStruct(new List<AbiField>());
				}
				return AppChooserIface._abi_info;
			}
		}

		// Token: 0x04000639 RID: 1593
		private static AbiStruct _abi_info;
	}
}
