﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;
using GtkSharp;

namespace Gtk
{
	// Token: 0x020000DA RID: 218
	public class Calendar : Widget
	{
		// Token: 0x06000567 RID: 1383 RVA: 0x0000EDE8 File Offset: 0x0000CFE8
		public DateTime GetDate()
		{
			uint year;
			uint num;
			uint day;
			this.GetDate(out year, out num, out day);
			DateTime result;
			try
			{
				result = new DateTime((int)year, (int)(num + 1U), (int)day);
			}
			catch (ArgumentOutOfRangeException)
			{
				result = new DateTime((int)year, (int)(num + 1U), DateTime.DaysInMonth((int)year, (int)(num + 1U)));
			}
			return result;
		}

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x06000568 RID: 1384 RVA: 0x0000EE38 File Offset: 0x0000D038
		// (set) Token: 0x06000569 RID: 1385 RVA: 0x0000EE40 File Offset: 0x0000D040
		public DateTime Date
		{
			get
			{
				return this.GetDate();
			}
			set
			{
				uint month = (uint)(value.Month - 1);
				uint year = (uint)value.Year;
				uint day = (uint)value.Day;
				this.SelectMonth(month, year);
				this.SelectDay(day);
			}
		}

		// Token: 0x0600056A RID: 1386 RVA: 0x0000EE76 File Offset: 0x0000D076
		public Calendar(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x0600056B RID: 1387 RVA: 0x0000EE80 File Offset: 0x0000D080
		public Calendar() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Calendar))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = Calendar.gtk_calendar_new();
		}

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x0600056C RID: 1388 RVA: 0x0000EED4 File Offset: 0x0000D0D4
		// (set) Token: 0x0600056D RID: 1389 RVA: 0x0000EEFC File Offset: 0x0000D0FC
		[Property("year")]
		public int Year
		{
			get
			{
				Value property = base.GetProperty("year");
				int result = (int)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("year", val);
				val.Dispose();
			}
		}

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x0600056E RID: 1390 RVA: 0x0000EF24 File Offset: 0x0000D124
		// (set) Token: 0x0600056F RID: 1391 RVA: 0x0000EF4C File Offset: 0x0000D14C
		[Property("month")]
		public int Month
		{
			get
			{
				Value property = base.GetProperty("month");
				int result = (int)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("month", val);
				val.Dispose();
			}
		}

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x06000570 RID: 1392 RVA: 0x0000EF74 File Offset: 0x0000D174
		// (set) Token: 0x06000571 RID: 1393 RVA: 0x0000EF9C File Offset: 0x0000D19C
		[Property("day")]
		public int Day
		{
			get
			{
				Value property = base.GetProperty("day");
				int result = (int)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("day", val);
				val.Dispose();
			}
		}

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x06000572 RID: 1394 RVA: 0x0000EFC4 File Offset: 0x0000D1C4
		// (set) Token: 0x06000573 RID: 1395 RVA: 0x0000EFEC File Offset: 0x0000D1EC
		[Property("show-heading")]
		public bool ShowHeading
		{
			get
			{
				Value property = base.GetProperty("show-heading");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("show-heading", val);
				val.Dispose();
			}
		}

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x06000574 RID: 1396 RVA: 0x0000F014 File Offset: 0x0000D214
		// (set) Token: 0x06000575 RID: 1397 RVA: 0x0000F03C File Offset: 0x0000D23C
		[Property("show-day-names")]
		public bool ShowDayNames
		{
			get
			{
				Value property = base.GetProperty("show-day-names");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("show-day-names", val);
				val.Dispose();
			}
		}

		// Token: 0x170000BE RID: 190
		// (get) Token: 0x06000576 RID: 1398 RVA: 0x0000F064 File Offset: 0x0000D264
		// (set) Token: 0x06000577 RID: 1399 RVA: 0x0000F08C File Offset: 0x0000D28C
		[Property("no-month-change")]
		public bool NoMonthChange
		{
			get
			{
				Value property = base.GetProperty("no-month-change");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("no-month-change", val);
				val.Dispose();
			}
		}

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x06000578 RID: 1400 RVA: 0x0000F0B4 File Offset: 0x0000D2B4
		// (set) Token: 0x06000579 RID: 1401 RVA: 0x0000F0DC File Offset: 0x0000D2DC
		[Property("show-week-numbers")]
		public bool ShowWeekNumbers
		{
			get
			{
				Value property = base.GetProperty("show-week-numbers");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("show-week-numbers", val);
				val.Dispose();
			}
		}

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x0600057A RID: 1402 RVA: 0x0000F104 File Offset: 0x0000D304
		// (set) Token: 0x0600057B RID: 1403 RVA: 0x0000F116 File Offset: 0x0000D316
		[Property("detail-width-chars")]
		public int DetailWidthChars
		{
			get
			{
				return Calendar.gtk_calendar_get_detail_width_chars(base.Handle);
			}
			set
			{
				Calendar.gtk_calendar_set_detail_width_chars(base.Handle, value);
			}
		}

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x0600057C RID: 1404 RVA: 0x0000F129 File Offset: 0x0000D329
		// (set) Token: 0x0600057D RID: 1405 RVA: 0x0000F13B File Offset: 0x0000D33B
		[Property("detail-height-rows")]
		public int DetailHeightRows
		{
			get
			{
				return Calendar.gtk_calendar_get_detail_height_rows(base.Handle);
			}
			set
			{
				Calendar.gtk_calendar_set_detail_height_rows(base.Handle, value);
			}
		}

		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x0600057E RID: 1406 RVA: 0x0000F150 File Offset: 0x0000D350
		// (set) Token: 0x0600057F RID: 1407 RVA: 0x0000F178 File Offset: 0x0000D378
		[Property("show-details")]
		public bool ShowDetails
		{
			get
			{
				Value property = base.GetProperty("show-details");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("show-details", val);
				val.Dispose();
			}
		}

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x06000580 RID: 1408 RVA: 0x0000F1A0 File Offset: 0x0000D3A0
		[Property("inner-border")]
		public int InnerBorder
		{
			get
			{
				Value property = base.GetProperty("inner-border");
				int result = (int)property;
				property.Dispose();
				return result;
			}
		}

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x06000581 RID: 1409 RVA: 0x0000F1C8 File Offset: 0x0000D3C8
		[Property("vertical-separation")]
		public int VerticalSeparation
		{
			get
			{
				Value property = base.GetProperty("vertical-separation");
				int result = (int)property;
				property.Dispose();
				return result;
			}
		}

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x06000582 RID: 1410 RVA: 0x0000F1F0 File Offset: 0x0000D3F0
		[Property("horizontal-separation")]
		public int HorizontalSeparation
		{
			get
			{
				Value property = base.GetProperty("horizontal-separation");
				int result = (int)property;
				property.Dispose();
				return result;
			}
		}

		// Token: 0x14000010 RID: 16
		// (add) Token: 0x06000583 RID: 1411 RVA: 0x0000F216 File Offset: 0x0000D416
		// (remove) Token: 0x06000584 RID: 1412 RVA: 0x0000F224 File Offset: 0x0000D424
		[Signal("month-changed")]
		public event EventHandler MonthChanged
		{
			add
			{
				base.AddSignalHandler("month-changed", value);
			}
			remove
			{
				base.RemoveSignalHandler("month-changed", value);
			}
		}

		// Token: 0x14000011 RID: 17
		// (add) Token: 0x06000585 RID: 1413 RVA: 0x0000F232 File Offset: 0x0000D432
		// (remove) Token: 0x06000586 RID: 1414 RVA: 0x0000F240 File Offset: 0x0000D440
		[Signal("next-month")]
		public event EventHandler NextMonth
		{
			add
			{
				base.AddSignalHandler("next-month", value);
			}
			remove
			{
				base.RemoveSignalHandler("next-month", value);
			}
		}

		// Token: 0x14000012 RID: 18
		// (add) Token: 0x06000587 RID: 1415 RVA: 0x0000F24E File Offset: 0x0000D44E
		// (remove) Token: 0x06000588 RID: 1416 RVA: 0x0000F25C File Offset: 0x0000D45C
		[Signal("next-year")]
		public event EventHandler NextYear
		{
			add
			{
				base.AddSignalHandler("next-year", value);
			}
			remove
			{
				base.RemoveSignalHandler("next-year", value);
			}
		}

		// Token: 0x14000013 RID: 19
		// (add) Token: 0x06000589 RID: 1417 RVA: 0x0000F26A File Offset: 0x0000D46A
		// (remove) Token: 0x0600058A RID: 1418 RVA: 0x0000F278 File Offset: 0x0000D478
		[Signal("day-selected")]
		public event EventHandler DaySelected
		{
			add
			{
				base.AddSignalHandler("day-selected", value);
			}
			remove
			{
				base.RemoveSignalHandler("day-selected", value);
			}
		}

		// Token: 0x14000014 RID: 20
		// (add) Token: 0x0600058B RID: 1419 RVA: 0x0000F286 File Offset: 0x0000D486
		// (remove) Token: 0x0600058C RID: 1420 RVA: 0x0000F294 File Offset: 0x0000D494
		[Signal("prev-month")]
		public event EventHandler PrevMonth
		{
			add
			{
				base.AddSignalHandler("prev-month", value);
			}
			remove
			{
				base.RemoveSignalHandler("prev-month", value);
			}
		}

		// Token: 0x14000015 RID: 21
		// (add) Token: 0x0600058D RID: 1421 RVA: 0x0000F2A2 File Offset: 0x0000D4A2
		// (remove) Token: 0x0600058E RID: 1422 RVA: 0x0000F2B0 File Offset: 0x0000D4B0
		[Signal("day-selected-double-click")]
		public event EventHandler DaySelectedDoubleClick
		{
			add
			{
				base.AddSignalHandler("day-selected-double-click", value);
			}
			remove
			{
				base.RemoveSignalHandler("day-selected-double-click", value);
			}
		}

		// Token: 0x14000016 RID: 22
		// (add) Token: 0x0600058F RID: 1423 RVA: 0x0000F2BE File Offset: 0x0000D4BE
		// (remove) Token: 0x06000590 RID: 1424 RVA: 0x0000F2CC File Offset: 0x0000D4CC
		[Signal("prev-year")]
		public event EventHandler PrevYear
		{
			add
			{
				base.AddSignalHandler("prev-year", value);
			}
			remove
			{
				base.RemoveSignalHandler("prev-year", value);
			}
		}

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x06000591 RID: 1425 RVA: 0x0000F2DA File Offset: 0x0000D4DA
		private static Calendar.MonthChangedNativeDelegate MonthChangedVMCallback
		{
			get
			{
				if (Calendar.MonthChanged_cb_delegate == null)
				{
					Calendar.MonthChanged_cb_delegate = new Calendar.MonthChangedNativeDelegate(Calendar.MonthChanged_cb);
				}
				return Calendar.MonthChanged_cb_delegate;
			}
		}

		// Token: 0x06000592 RID: 1426 RVA: 0x0000F2F9 File Offset: 0x0000D4F9
		private static void OverrideMonthChanged(GType gtype)
		{
			Calendar.OverrideMonthChanged(gtype, Calendar.MonthChangedVMCallback);
		}

		// Token: 0x06000593 RID: 1427 RVA: 0x0000F308 File Offset: 0x0000D508
		private unsafe static void OverrideMonthChanged(GType gtype, Calendar.MonthChangedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Calendar.class_abi.GetFieldOffset("month_changed");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000594 RID: 1428 RVA: 0x0000F33C File Offset: 0x0000D53C
		private static void MonthChanged_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Calendar).OnMonthChanged();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000595 RID: 1429 RVA: 0x0000F374 File Offset: 0x0000D574
		[DefaultSignalHandler(Type = typeof(Calendar), ConnectionMethod = "OverrideMonthChanged")]
		protected virtual void OnMonthChanged()
		{
			this.InternalMonthChanged();
		}

		// Token: 0x06000596 RID: 1430 RVA: 0x0000F37C File Offset: 0x0000D57C
		private void InternalMonthChanged()
		{
			Calendar.MonthChangedNativeDelegate monthChangedNativeDelegate = Calendar.class_abi.BaseOverride(base.LookupGType(), "month_changed");
			if (monthChangedNativeDelegate == null)
			{
				return;
			}
			monthChangedNativeDelegate(base.Handle);
		}

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x06000597 RID: 1431 RVA: 0x0000F3AF File Offset: 0x0000D5AF
		private static Calendar.DaySelectedNativeDelegate DaySelectedVMCallback
		{
			get
			{
				if (Calendar.DaySelected_cb_delegate == null)
				{
					Calendar.DaySelected_cb_delegate = new Calendar.DaySelectedNativeDelegate(Calendar.DaySelected_cb);
				}
				return Calendar.DaySelected_cb_delegate;
			}
		}

		// Token: 0x06000598 RID: 1432 RVA: 0x0000F3CE File Offset: 0x0000D5CE
		private static void OverrideDaySelected(GType gtype)
		{
			Calendar.OverrideDaySelected(gtype, Calendar.DaySelectedVMCallback);
		}

		// Token: 0x06000599 RID: 1433 RVA: 0x0000F3DC File Offset: 0x0000D5DC
		private unsafe static void OverrideDaySelected(GType gtype, Calendar.DaySelectedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Calendar.class_abi.GetFieldOffset("day_selected");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600059A RID: 1434 RVA: 0x0000F410 File Offset: 0x0000D610
		private static void DaySelected_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Calendar).OnDaySelected();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x0600059B RID: 1435 RVA: 0x0000F448 File Offset: 0x0000D648
		[DefaultSignalHandler(Type = typeof(Calendar), ConnectionMethod = "OverrideDaySelected")]
		protected virtual void OnDaySelected()
		{
			this.InternalDaySelected();
		}

		// Token: 0x0600059C RID: 1436 RVA: 0x0000F450 File Offset: 0x0000D650
		private void InternalDaySelected()
		{
			Calendar.DaySelectedNativeDelegate daySelectedNativeDelegate = Calendar.class_abi.BaseOverride(base.LookupGType(), "day_selected");
			if (daySelectedNativeDelegate == null)
			{
				return;
			}
			daySelectedNativeDelegate(base.Handle);
		}

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x0600059D RID: 1437 RVA: 0x0000F483 File Offset: 0x0000D683
		private static Calendar.DaySelectedDoubleClickNativeDelegate DaySelectedDoubleClickVMCallback
		{
			get
			{
				if (Calendar.DaySelectedDoubleClick_cb_delegate == null)
				{
					Calendar.DaySelectedDoubleClick_cb_delegate = new Calendar.DaySelectedDoubleClickNativeDelegate(Calendar.DaySelectedDoubleClick_cb);
				}
				return Calendar.DaySelectedDoubleClick_cb_delegate;
			}
		}

		// Token: 0x0600059E RID: 1438 RVA: 0x0000F4A2 File Offset: 0x0000D6A2
		private static void OverrideDaySelectedDoubleClick(GType gtype)
		{
			Calendar.OverrideDaySelectedDoubleClick(gtype, Calendar.DaySelectedDoubleClickVMCallback);
		}

		// Token: 0x0600059F RID: 1439 RVA: 0x0000F4B0 File Offset: 0x0000D6B0
		private unsafe static void OverrideDaySelectedDoubleClick(GType gtype, Calendar.DaySelectedDoubleClickNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Calendar.class_abi.GetFieldOffset("day_selected_double_click");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060005A0 RID: 1440 RVA: 0x0000F4E4 File Offset: 0x0000D6E4
		private static void DaySelectedDoubleClick_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Calendar).OnDaySelectedDoubleClick();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005A1 RID: 1441 RVA: 0x0000F51C File Offset: 0x0000D71C
		[DefaultSignalHandler(Type = typeof(Calendar), ConnectionMethod = "OverrideDaySelectedDoubleClick")]
		protected virtual void OnDaySelectedDoubleClick()
		{
			this.InternalDaySelectedDoubleClick();
		}

		// Token: 0x060005A2 RID: 1442 RVA: 0x0000F524 File Offset: 0x0000D724
		private void InternalDaySelectedDoubleClick()
		{
			Calendar.DaySelectedDoubleClickNativeDelegate daySelectedDoubleClickNativeDelegate = Calendar.class_abi.BaseOverride(base.LookupGType(), "day_selected_double_click");
			if (daySelectedDoubleClickNativeDelegate == null)
			{
				return;
			}
			daySelectedDoubleClickNativeDelegate(base.Handle);
		}

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x060005A3 RID: 1443 RVA: 0x0000F557 File Offset: 0x0000D757
		private static Calendar.PrevMonthNativeDelegate PrevMonthVMCallback
		{
			get
			{
				if (Calendar.PrevMonth_cb_delegate == null)
				{
					Calendar.PrevMonth_cb_delegate = new Calendar.PrevMonthNativeDelegate(Calendar.PrevMonth_cb);
				}
				return Calendar.PrevMonth_cb_delegate;
			}
		}

		// Token: 0x060005A4 RID: 1444 RVA: 0x0000F576 File Offset: 0x0000D776
		private static void OverridePrevMonth(GType gtype)
		{
			Calendar.OverridePrevMonth(gtype, Calendar.PrevMonthVMCallback);
		}

		// Token: 0x060005A5 RID: 1445 RVA: 0x0000F584 File Offset: 0x0000D784
		private unsafe static void OverridePrevMonth(GType gtype, Calendar.PrevMonthNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Calendar.class_abi.GetFieldOffset("prev_month");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060005A6 RID: 1446 RVA: 0x0000F5B8 File Offset: 0x0000D7B8
		private static void PrevMonth_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Calendar).OnPrevMonth();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005A7 RID: 1447 RVA: 0x0000F5F0 File Offset: 0x0000D7F0
		[DefaultSignalHandler(Type = typeof(Calendar), ConnectionMethod = "OverridePrevMonth")]
		protected virtual void OnPrevMonth()
		{
			this.InternalPrevMonth();
		}

		// Token: 0x060005A8 RID: 1448 RVA: 0x0000F5F8 File Offset: 0x0000D7F8
		private void InternalPrevMonth()
		{
			Calendar.PrevMonthNativeDelegate prevMonthNativeDelegate = Calendar.class_abi.BaseOverride(base.LookupGType(), "prev_month");
			if (prevMonthNativeDelegate == null)
			{
				return;
			}
			prevMonthNativeDelegate(base.Handle);
		}

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x060005A9 RID: 1449 RVA: 0x0000F62B File Offset: 0x0000D82B
		private static Calendar.NextMonthNativeDelegate NextMonthVMCallback
		{
			get
			{
				if (Calendar.NextMonth_cb_delegate == null)
				{
					Calendar.NextMonth_cb_delegate = new Calendar.NextMonthNativeDelegate(Calendar.NextMonth_cb);
				}
				return Calendar.NextMonth_cb_delegate;
			}
		}

		// Token: 0x060005AA RID: 1450 RVA: 0x0000F64A File Offset: 0x0000D84A
		private static void OverrideNextMonth(GType gtype)
		{
			Calendar.OverrideNextMonth(gtype, Calendar.NextMonthVMCallback);
		}

		// Token: 0x060005AB RID: 1451 RVA: 0x0000F658 File Offset: 0x0000D858
		private unsafe static void OverrideNextMonth(GType gtype, Calendar.NextMonthNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Calendar.class_abi.GetFieldOffset("next_month");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060005AC RID: 1452 RVA: 0x0000F68C File Offset: 0x0000D88C
		private static void NextMonth_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Calendar).OnNextMonth();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005AD RID: 1453 RVA: 0x0000F6C4 File Offset: 0x0000D8C4
		[DefaultSignalHandler(Type = typeof(Calendar), ConnectionMethod = "OverrideNextMonth")]
		protected virtual void OnNextMonth()
		{
			this.InternalNextMonth();
		}

		// Token: 0x060005AE RID: 1454 RVA: 0x0000F6CC File Offset: 0x0000D8CC
		private void InternalNextMonth()
		{
			Calendar.NextMonthNativeDelegate nextMonthNativeDelegate = Calendar.class_abi.BaseOverride(base.LookupGType(), "next_month");
			if (nextMonthNativeDelegate == null)
			{
				return;
			}
			nextMonthNativeDelegate(base.Handle);
		}

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x060005AF RID: 1455 RVA: 0x0000F6FF File Offset: 0x0000D8FF
		private static Calendar.PrevYearNativeDelegate PrevYearVMCallback
		{
			get
			{
				if (Calendar.PrevYear_cb_delegate == null)
				{
					Calendar.PrevYear_cb_delegate = new Calendar.PrevYearNativeDelegate(Calendar.PrevYear_cb);
				}
				return Calendar.PrevYear_cb_delegate;
			}
		}

		// Token: 0x060005B0 RID: 1456 RVA: 0x0000F71E File Offset: 0x0000D91E
		private static void OverridePrevYear(GType gtype)
		{
			Calendar.OverridePrevYear(gtype, Calendar.PrevYearVMCallback);
		}

		// Token: 0x060005B1 RID: 1457 RVA: 0x0000F72C File Offset: 0x0000D92C
		private unsafe static void OverridePrevYear(GType gtype, Calendar.PrevYearNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Calendar.class_abi.GetFieldOffset("prev_year");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060005B2 RID: 1458 RVA: 0x0000F760 File Offset: 0x0000D960
		private static void PrevYear_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Calendar).OnPrevYear();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005B3 RID: 1459 RVA: 0x0000F798 File Offset: 0x0000D998
		[DefaultSignalHandler(Type = typeof(Calendar), ConnectionMethod = "OverridePrevYear")]
		protected virtual void OnPrevYear()
		{
			this.InternalPrevYear();
		}

		// Token: 0x060005B4 RID: 1460 RVA: 0x0000F7A0 File Offset: 0x0000D9A0
		private void InternalPrevYear()
		{
			Calendar.PrevYearNativeDelegate prevYearNativeDelegate = Calendar.class_abi.BaseOverride(base.LookupGType(), "prev_year");
			if (prevYearNativeDelegate == null)
			{
				return;
			}
			prevYearNativeDelegate(base.Handle);
		}

		// Token: 0x170000CC RID: 204
		// (get) Token: 0x060005B5 RID: 1461 RVA: 0x0000F7D3 File Offset: 0x0000D9D3
		private static Calendar.NextYearNativeDelegate NextYearVMCallback
		{
			get
			{
				if (Calendar.NextYear_cb_delegate == null)
				{
					Calendar.NextYear_cb_delegate = new Calendar.NextYearNativeDelegate(Calendar.NextYear_cb);
				}
				return Calendar.NextYear_cb_delegate;
			}
		}

		// Token: 0x060005B6 RID: 1462 RVA: 0x0000F7F2 File Offset: 0x0000D9F2
		private static void OverrideNextYear(GType gtype)
		{
			Calendar.OverrideNextYear(gtype, Calendar.NextYearVMCallback);
		}

		// Token: 0x060005B7 RID: 1463 RVA: 0x0000F800 File Offset: 0x0000DA00
		private unsafe static void OverrideNextYear(GType gtype, Calendar.NextYearNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Calendar.class_abi.GetFieldOffset("next_year");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060005B8 RID: 1464 RVA: 0x0000F834 File Offset: 0x0000DA34
		private static void NextYear_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Calendar).OnNextYear();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005B9 RID: 1465 RVA: 0x0000F86C File Offset: 0x0000DA6C
		[DefaultSignalHandler(Type = typeof(Calendar), ConnectionMethod = "OverrideNextYear")]
		protected virtual void OnNextYear()
		{
			this.InternalNextYear();
		}

		// Token: 0x060005BA RID: 1466 RVA: 0x0000F874 File Offset: 0x0000DA74
		private void InternalNextYear()
		{
			Calendar.NextYearNativeDelegate nextYearNativeDelegate = Calendar.class_abi.BaseOverride(base.LookupGType(), "next_year");
			if (nextYearNativeDelegate == null)
			{
				return;
			}
			nextYearNativeDelegate(base.Handle);
		}

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x060005BB RID: 1467 RVA: 0x0000F8A8 File Offset: 0x0000DAA8
		public new static AbiStruct class_abi
		{
			get
			{
				if (Calendar._class_abi == null)
				{
					Calendar._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("month_changed", Widget.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "day_selected", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("day_selected", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "month_changed", "day_selected_double_click", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("day_selected_double_click", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "day_selected", "prev_month", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("prev_month", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "day_selected_double_click", "next_month", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("next_month", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "prev_month", "prev_year", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("prev_year", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "next_month", "next_year", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("next_year", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "prev_year", "_gtk_reserved1", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved1", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "next_year", "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Calendar._class_abi;
			}
		}

		// Token: 0x060005BC RID: 1468 RVA: 0x0000FB67 File Offset: 0x0000DD67
		public void ClearMarks()
		{
			Calendar.gtk_calendar_clear_marks(base.Handle);
		}

		// Token: 0x060005BD RID: 1469 RVA: 0x0000FB79 File Offset: 0x0000DD79
		public void GetDate(out uint year, out uint month, out uint day)
		{
			Calendar.gtk_calendar_get_date(base.Handle, out year, out month, out day);
		}

		// Token: 0x060005BE RID: 1470 RVA: 0x0000FB8E File Offset: 0x0000DD8E
		public bool GetDayIsMarked(uint day)
		{
			return Calendar.gtk_calendar_get_day_is_marked(base.Handle, day);
		}

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x060005BF RID: 1471 RVA: 0x0000FBA1 File Offset: 0x0000DDA1
		// (set) Token: 0x060005C0 RID: 1472 RVA: 0x0000FBB3 File Offset: 0x0000DDB3
		public CalendarDisplayOptions DisplayOptions
		{
			get
			{
				return (CalendarDisplayOptions)Calendar.gtk_calendar_get_display_options(base.Handle);
			}
			set
			{
				Calendar.gtk_calendar_set_display_options(base.Handle, (int)value);
			}
		}

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x060005C1 RID: 1473 RVA: 0x0000FBC8 File Offset: 0x0000DDC8
		public new static GType GType
		{
			get
			{
				IntPtr val = Calendar.gtk_calendar_get_type();
				return new GType(val);
			}
		}

		// Token: 0x060005C2 RID: 1474 RVA: 0x0000FBE6 File Offset: 0x0000DDE6
		public void MarkDay(uint day)
		{
			Calendar.gtk_calendar_mark_day(base.Handle, day);
		}

		// Token: 0x060005C3 RID: 1475 RVA: 0x0000FBF9 File Offset: 0x0000DDF9
		public void SelectDay(uint day)
		{
			Calendar.gtk_calendar_select_day(base.Handle, day);
		}

		// Token: 0x060005C4 RID: 1476 RVA: 0x0000FC0C File Offset: 0x0000DE0C
		public void SelectMonth(uint month, uint year)
		{
			Calendar.gtk_calendar_select_month(base.Handle, month, year);
		}

		// Token: 0x170000D0 RID: 208
		// (set) Token: 0x060005C5 RID: 1477 RVA: 0x0000FC20 File Offset: 0x0000DE20
		public CalendarDetailFunc DetailFunc
		{
			set
			{
				CalendarDetailFuncWrapper calendarDetailFuncWrapper = new CalendarDetailFuncWrapper(value);
				IntPtr data;
				DestroyNotify destroy;
				if (value == null)
				{
					data = IntPtr.Zero;
					destroy = null;
				}
				else
				{
					data = (IntPtr)GCHandle.Alloc(calendarDetailFuncWrapper);
					destroy = DestroyHelper.NotifyHandler;
				}
				Calendar.gtk_calendar_set_detail_func(base.Handle, calendarDetailFuncWrapper.NativeDelegate, data, destroy);
			}
		}

		// Token: 0x060005C6 RID: 1478 RVA: 0x0000FC6B File Offset: 0x0000DE6B
		public void UnmarkDay(uint day)
		{
			Calendar.gtk_calendar_unmark_day(base.Handle, day);
		}

		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x060005C7 RID: 1479 RVA: 0x0000FC80 File Offset: 0x0000DE80
		public new static AbiStruct abi_info
		{
			get
			{
				if (Calendar._abi_info == null)
				{
					Calendar._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Widget.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Calendar._abi_info;
			}
		}

		// Token: 0x040002D2 RID: 722
		private static Calendar.d_gtk_calendar_new gtk_calendar_new = FuncLoader.LoadFunction<Calendar.d_gtk_calendar_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_calendar_new"));

		// Token: 0x040002D3 RID: 723
		private static Calendar.d_gtk_calendar_get_detail_width_chars gtk_calendar_get_detail_width_chars = FuncLoader.LoadFunction<Calendar.d_gtk_calendar_get_detail_width_chars>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_calendar_get_detail_width_chars"));

		// Token: 0x040002D4 RID: 724
		private static Calendar.d_gtk_calendar_set_detail_width_chars gtk_calendar_set_detail_width_chars = FuncLoader.LoadFunction<Calendar.d_gtk_calendar_set_detail_width_chars>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_calendar_set_detail_width_chars"));

		// Token: 0x040002D5 RID: 725
		private static Calendar.d_gtk_calendar_get_detail_height_rows gtk_calendar_get_detail_height_rows = FuncLoader.LoadFunction<Calendar.d_gtk_calendar_get_detail_height_rows>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_calendar_get_detail_height_rows"));

		// Token: 0x040002D6 RID: 726
		private static Calendar.d_gtk_calendar_set_detail_height_rows gtk_calendar_set_detail_height_rows = FuncLoader.LoadFunction<Calendar.d_gtk_calendar_set_detail_height_rows>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_calendar_set_detail_height_rows"));

		// Token: 0x040002D7 RID: 727
		private static Calendar.MonthChangedNativeDelegate MonthChanged_cb_delegate;

		// Token: 0x040002D8 RID: 728
		private static Calendar.DaySelectedNativeDelegate DaySelected_cb_delegate;

		// Token: 0x040002D9 RID: 729
		private static Calendar.DaySelectedDoubleClickNativeDelegate DaySelectedDoubleClick_cb_delegate;

		// Token: 0x040002DA RID: 730
		private static Calendar.PrevMonthNativeDelegate PrevMonth_cb_delegate;

		// Token: 0x040002DB RID: 731
		private static Calendar.NextMonthNativeDelegate NextMonth_cb_delegate;

		// Token: 0x040002DC RID: 732
		private static Calendar.PrevYearNativeDelegate PrevYear_cb_delegate;

		// Token: 0x040002DD RID: 733
		private static Calendar.NextYearNativeDelegate NextYear_cb_delegate;

		// Token: 0x040002DE RID: 734
		private static AbiStruct _class_abi = null;

		// Token: 0x040002DF RID: 735
		private static Calendar.d_gtk_calendar_clear_marks gtk_calendar_clear_marks = FuncLoader.LoadFunction<Calendar.d_gtk_calendar_clear_marks>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_calendar_clear_marks"));

		// Token: 0x040002E0 RID: 736
		private static Calendar.d_gtk_calendar_get_date gtk_calendar_get_date = FuncLoader.LoadFunction<Calendar.d_gtk_calendar_get_date>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_calendar_get_date"));

		// Token: 0x040002E1 RID: 737
		private static Calendar.d_gtk_calendar_get_day_is_marked gtk_calendar_get_day_is_marked = FuncLoader.LoadFunction<Calendar.d_gtk_calendar_get_day_is_marked>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_calendar_get_day_is_marked"));

		// Token: 0x040002E2 RID: 738
		private static Calendar.d_gtk_calendar_get_display_options gtk_calendar_get_display_options = FuncLoader.LoadFunction<Calendar.d_gtk_calendar_get_display_options>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_calendar_get_display_options"));

		// Token: 0x040002E3 RID: 739
		private static Calendar.d_gtk_calendar_set_display_options gtk_calendar_set_display_options = FuncLoader.LoadFunction<Calendar.d_gtk_calendar_set_display_options>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_calendar_set_display_options"));

		// Token: 0x040002E4 RID: 740
		private static Calendar.d_gtk_calendar_get_type gtk_calendar_get_type = FuncLoader.LoadFunction<Calendar.d_gtk_calendar_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_calendar_get_type"));

		// Token: 0x040002E5 RID: 741
		private static Calendar.d_gtk_calendar_mark_day gtk_calendar_mark_day = FuncLoader.LoadFunction<Calendar.d_gtk_calendar_mark_day>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_calendar_mark_day"));

		// Token: 0x040002E6 RID: 742
		private static Calendar.d_gtk_calendar_select_day gtk_calendar_select_day = FuncLoader.LoadFunction<Calendar.d_gtk_calendar_select_day>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_calendar_select_day"));

		// Token: 0x040002E7 RID: 743
		private static Calendar.d_gtk_calendar_select_month gtk_calendar_select_month = FuncLoader.LoadFunction<Calendar.d_gtk_calendar_select_month>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_calendar_select_month"));

		// Token: 0x040002E8 RID: 744
		private static Calendar.d_gtk_calendar_set_detail_func gtk_calendar_set_detail_func = FuncLoader.LoadFunction<Calendar.d_gtk_calendar_set_detail_func>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_calendar_set_detail_func"));

		// Token: 0x040002E9 RID: 745
		private static Calendar.d_gtk_calendar_unmark_day gtk_calendar_unmark_day = FuncLoader.LoadFunction<Calendar.d_gtk_calendar_unmark_day>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_calendar_unmark_day"));

		// Token: 0x040002EA RID: 746
		private static AbiStruct _abi_info = null;

		// Token: 0x0200070A RID: 1802
		// (Invoke) Token: 0x0600434C RID: 17228
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_calendar_new();

		// Token: 0x0200070B RID: 1803
		// (Invoke) Token: 0x06004350 RID: 17232
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_calendar_get_detail_width_chars(IntPtr raw);

		// Token: 0x0200070C RID: 1804
		// (Invoke) Token: 0x06004354 RID: 17236
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_calendar_set_detail_width_chars(IntPtr raw, int chars);

		// Token: 0x0200070D RID: 1805
		// (Invoke) Token: 0x06004358 RID: 17240
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_calendar_get_detail_height_rows(IntPtr raw);

		// Token: 0x0200070E RID: 1806
		// (Invoke) Token: 0x0600435C RID: 17244
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_calendar_set_detail_height_rows(IntPtr raw, int rows);

		// Token: 0x0200070F RID: 1807
		// (Invoke) Token: 0x06004360 RID: 17248
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void MonthChangedNativeDelegate(IntPtr inst);

		// Token: 0x02000710 RID: 1808
		// (Invoke) Token: 0x06004364 RID: 17252
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DaySelectedNativeDelegate(IntPtr inst);

		// Token: 0x02000711 RID: 1809
		// (Invoke) Token: 0x06004368 RID: 17256
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DaySelectedDoubleClickNativeDelegate(IntPtr inst);

		// Token: 0x02000712 RID: 1810
		// (Invoke) Token: 0x0600436C RID: 17260
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void PrevMonthNativeDelegate(IntPtr inst);

		// Token: 0x02000713 RID: 1811
		// (Invoke) Token: 0x06004370 RID: 17264
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void NextMonthNativeDelegate(IntPtr inst);

		// Token: 0x02000714 RID: 1812
		// (Invoke) Token: 0x06004374 RID: 17268
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void PrevYearNativeDelegate(IntPtr inst);

		// Token: 0x02000715 RID: 1813
		// (Invoke) Token: 0x06004378 RID: 17272
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void NextYearNativeDelegate(IntPtr inst);

		// Token: 0x02000716 RID: 1814
		// (Invoke) Token: 0x0600437C RID: 17276
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_calendar_clear_marks(IntPtr raw);

		// Token: 0x02000717 RID: 1815
		// (Invoke) Token: 0x06004380 RID: 17280
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_calendar_get_date(IntPtr raw, out uint year, out uint month, out uint day);

		// Token: 0x02000718 RID: 1816
		// (Invoke) Token: 0x06004384 RID: 17284
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_calendar_get_day_is_marked(IntPtr raw, uint day);

		// Token: 0x02000719 RID: 1817
		// (Invoke) Token: 0x06004388 RID: 17288
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_calendar_get_display_options(IntPtr raw);

		// Token: 0x0200071A RID: 1818
		// (Invoke) Token: 0x0600438C RID: 17292
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_calendar_set_display_options(IntPtr raw, int flags);

		// Token: 0x0200071B RID: 1819
		// (Invoke) Token: 0x06004390 RID: 17296
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_calendar_get_type();

		// Token: 0x0200071C RID: 1820
		// (Invoke) Token: 0x06004394 RID: 17300
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_calendar_mark_day(IntPtr raw, uint day);

		// Token: 0x0200071D RID: 1821
		// (Invoke) Token: 0x06004398 RID: 17304
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_calendar_select_day(IntPtr raw, uint day);

		// Token: 0x0200071E RID: 1822
		// (Invoke) Token: 0x0600439C RID: 17308
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_calendar_select_month(IntPtr raw, uint month, uint year);

		// Token: 0x0200071F RID: 1823
		// (Invoke) Token: 0x060043A0 RID: 17312
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_calendar_set_detail_func(IntPtr raw, CalendarDetailFuncNative func, IntPtr data, DestroyNotify destroy);

		// Token: 0x02000720 RID: 1824
		// (Invoke) Token: 0x060043A4 RID: 17316
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_calendar_unmark_day(IntPtr raw, uint day);
	}
}
