﻿using System;

namespace Gtk
{
	// Token: 0x0200020D RID: 525
	// (Invoke) Token: 0x06001235 RID: 4661
	public delegate void CursorOnMatchHandler(object o, CursorOnMatchArgs args);
}
