﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000113 RID: 275
	public class ActivateLinkArgs : SignalArgs
	{
	}
}
