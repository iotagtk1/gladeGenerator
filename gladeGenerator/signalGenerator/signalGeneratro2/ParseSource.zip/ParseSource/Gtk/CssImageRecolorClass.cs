﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001DA RID: 474
	public class CssImageRecolorClass : Opaque
	{
		// Token: 0x060011AF RID: 4527 RVA: 0x00034081 File Offset: 0x00032281
		public CssImageRecolorClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700042B RID: 1067
		// (get) Token: 0x060011B0 RID: 4528 RVA: 0x0003408A File Offset: 0x0003228A
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImageRecolorClass._abi_info == null)
				{
					CssImageRecolorClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImageRecolorClass._abi_info;
			}
		}

		// Token: 0x0400083A RID: 2106
		private static AbiStruct _abi_info;
	}
}
