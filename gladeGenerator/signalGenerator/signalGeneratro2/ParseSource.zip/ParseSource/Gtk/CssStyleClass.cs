﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x02000202 RID: 514
	public class CssStyleClass : Opaque
	{
		// Token: 0x0600121E RID: 4638 RVA: 0x00034F0D File Offset: 0x0003310D
		public CssStyleClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700045D RID: 1117
		// (get) Token: 0x0600121F RID: 4639 RVA: 0x00034F16 File Offset: 0x00033116
		public static AbiStruct abi_info
		{
			get
			{
				if (CssStyleClass._abi_info == null)
				{
					CssStyleClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssStyleClass._abi_info;
			}
		}

		// Token: 0x04000888 RID: 2184
		private static AbiStruct _abi_info;
	}
}
