﻿using System;
using System.Runtime.InteropServices;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x0200019A RID: 410
	public class ColorChooserAdapter : GInterfaceAdapter, IColorChooser, IWrapper
	{
		// Token: 0x060010DD RID: 4317 RVA: 0x0003273C File Offset: 0x0003093C
		static ColorChooserAdapter()
		{
			GType.Register(ColorChooserAdapter._gtype, typeof(ColorChooserAdapter));
			ColorChooserAdapter.iface.AddPalette = new ColorChooserAdapter.AddPaletteNativeDelegate(ColorChooserAdapter.AddPalette_cb);
		}

		// Token: 0x060010DE RID: 4318 RVA: 0x00032838 File Offset: 0x00030A38
		private static void AddPalette_cb(IntPtr inst, int orientation, int colors_per_line, int n_colors, IntPtr colors)
		{
			try
			{
				(Object.GetObject(inst, false) as IColorChooserImplementor).AddPalette((Orientation)orientation, colors_per_line, n_colors, RGBA.New(colors));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060010DF RID: 4319 RVA: 0x0003287C File Offset: 0x00030A7C
		private static void Initialize(IntPtr ptr, IntPtr data)
		{
			IntPtr ptr2 = new IntPtr(ptr.ToInt64() + (long)ColorChooserAdapter.class_offset);
			ColorChooserAdapter.GtkColorChooserInterface structure = (ColorChooserAdapter.GtkColorChooserInterface)Marshal.PtrToStructure(ptr2, typeof(ColorChooserAdapter.GtkColorChooserInterface));
			structure.AddPalette = ColorChooserAdapter.iface.AddPalette;
			Marshal.StructureToPtr<ColorChooserAdapter.GtkColorChooserInterface>(structure, ptr2, false);
		}

		// Token: 0x060010E0 RID: 4320 RVA: 0x000328CD File Offset: 0x00030ACD
		public ColorChooserAdapter()
		{
			base.InitHandler = new GInterfaceInitHandler(ColorChooserAdapter.Initialize);
		}

		// Token: 0x060010E1 RID: 4321 RVA: 0x000328E7 File Offset: 0x00030AE7
		public ColorChooserAdapter(IColorChooserImplementor implementor)
		{
			if (implementor == null)
			{
				throw new ArgumentNullException("implementor");
			}
			if (!(implementor is Object))
			{
				throw new ArgumentException("implementor must be a subclass of GLib.Object");
			}
			this.implementor = (implementor as Object);
		}

		// Token: 0x060010E2 RID: 4322 RVA: 0x0003291C File Offset: 0x00030B1C
		public ColorChooserAdapter(IntPtr handle)
		{
			if (!ColorChooserAdapter._gtype.IsInstance(handle))
			{
				throw new ArgumentException("The gobject doesn't implement the GInterface of this adapter", "handle");
			}
			this.implementor = Object.GetObject(handle);
		}

		// Token: 0x170003DF RID: 991
		// (get) Token: 0x060010E3 RID: 4323 RVA: 0x0003294D File Offset: 0x00030B4D
		public static GType GType
		{
			get
			{
				return ColorChooserAdapter._gtype;
			}
		}

		// Token: 0x170003E0 RID: 992
		// (get) Token: 0x060010E4 RID: 4324 RVA: 0x00032954 File Offset: 0x00030B54
		public override GType GInterfaceGType
		{
			get
			{
				return ColorChooserAdapter._gtype;
			}
		}

		// Token: 0x170003E1 RID: 993
		// (get) Token: 0x060010E5 RID: 4325 RVA: 0x0003295B File Offset: 0x00030B5B
		public override IntPtr Handle
		{
			get
			{
				return this.implementor.Handle;
			}
		}

		// Token: 0x170003E2 RID: 994
		// (get) Token: 0x060010E6 RID: 4326 RVA: 0x00032968 File Offset: 0x00030B68
		public IntPtr OwnedHandle
		{
			get
			{
				return this.implementor.OwnedHandle;
			}
		}

		// Token: 0x060010E7 RID: 4327 RVA: 0x00032975 File Offset: 0x00030B75
		public static IColorChooser GetObject(IntPtr handle, bool owned)
		{
			return ColorChooserAdapter.GetObject(Object.GetObject(handle, owned));
		}

		// Token: 0x060010E8 RID: 4328 RVA: 0x00032983 File Offset: 0x00030B83
		public static IColorChooser GetObject(Object obj)
		{
			if (obj == null)
			{
				return null;
			}
			if (obj is IColorChooserImplementor)
			{
				return new ColorChooserAdapter(obj as IColorChooserImplementor);
			}
			if (!(obj is IColorChooser))
			{
				return new ColorChooserAdapter(obj.Handle);
			}
			return obj as IColorChooser;
		}

		// Token: 0x170003E3 RID: 995
		// (get) Token: 0x060010E9 RID: 4329 RVA: 0x000329B8 File Offset: 0x00030BB8
		public IColorChooserImplementor Implementor
		{
			get
			{
				return this.implementor as IColorChooserImplementor;
			}
		}

		// Token: 0x170003E4 RID: 996
		// (get) Token: 0x060010EA RID: 4330 RVA: 0x000329C8 File Offset: 0x00030BC8
		// (set) Token: 0x060010EB RID: 4331 RVA: 0x00032A08 File Offset: 0x00030C08
		[Property("rgba")]
		public RGBA Rgba
		{
			get
			{
				IntPtr intPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(RGBA)));
				ColorChooserAdapter.gtk_color_chooser_get_rgba(this.Handle, intPtr);
				RGBA result = RGBA.New(intPtr);
				Marshal.FreeHGlobal(intPtr);
				return result;
			}
			set
			{
				IntPtr intPtr = Marshaller.StructureToPtrAlloc(value);
				ColorChooserAdapter.gtk_color_chooser_set_rgba(this.Handle, intPtr);
				Marshal.FreeHGlobal(intPtr);
			}
		}

		// Token: 0x170003E5 RID: 997
		// (get) Token: 0x060010EC RID: 4332 RVA: 0x00032A38 File Offset: 0x00030C38
		// (set) Token: 0x060010ED RID: 4333 RVA: 0x00032A4A File Offset: 0x00030C4A
		[Property("use-alpha")]
		public bool UseAlpha
		{
			get
			{
				return ColorChooserAdapter.gtk_color_chooser_get_use_alpha(this.Handle);
			}
			set
			{
				ColorChooserAdapter.gtk_color_chooser_set_use_alpha(this.Handle, value);
			}
		}

		// Token: 0x14000069 RID: 105
		// (add) Token: 0x060010EE RID: 4334 RVA: 0x00032A5D File Offset: 0x00030C5D
		// (remove) Token: 0x060010EF RID: 4335 RVA: 0x00032A7F File Offset: 0x00030C7F
		[Signal("color-activated")]
		public event ColorActivatedHandler ColorActivated
		{
			add
			{
				Object.GetObject(this.Handle).AddSignalHandler("color-activated", value, typeof(ColorActivatedArgs));
			}
			remove
			{
				Object.GetObject(this.Handle).RemoveSignalHandler("color-activated", value);
			}
		}

		// Token: 0x060010F0 RID: 4336 RVA: 0x00032A98 File Offset: 0x00030C98
		public void AddPalette(Orientation orientation, int colors_per_line, int n_colors, RGBA colors)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(colors);
			ColorChooserAdapter.gtk_color_chooser_add_palette(this.Handle, (int)orientation, colors_per_line, n_colors, intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x040007E9 RID: 2025
		private static ColorChooserAdapter.GtkColorChooserInterface iface;

		// Token: 0x040007EA RID: 2026
		private static int class_offset = 2 * IntPtr.Size;

		// Token: 0x040007EB RID: 2027
		private Object implementor;

		// Token: 0x040007EC RID: 2028
		private static ColorChooserAdapter.d_gtk_color_chooser_get_type gtk_color_chooser_get_type = FuncLoader.LoadFunction<ColorChooserAdapter.d_gtk_color_chooser_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_get_type"));

		// Token: 0x040007ED RID: 2029
		private static GType _gtype = new GType(ColorChooserAdapter.gtk_color_chooser_get_type());

		// Token: 0x040007EE RID: 2030
		private static ColorChooserAdapter.d_gtk_color_chooser_get_rgba gtk_color_chooser_get_rgba = FuncLoader.LoadFunction<ColorChooserAdapter.d_gtk_color_chooser_get_rgba>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_get_rgba"));

		// Token: 0x040007EF RID: 2031
		private static ColorChooserAdapter.d_gtk_color_chooser_set_rgba gtk_color_chooser_set_rgba = FuncLoader.LoadFunction<ColorChooserAdapter.d_gtk_color_chooser_set_rgba>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_set_rgba"));

		// Token: 0x040007F0 RID: 2032
		private static ColorChooserAdapter.d_gtk_color_chooser_get_use_alpha gtk_color_chooser_get_use_alpha = FuncLoader.LoadFunction<ColorChooserAdapter.d_gtk_color_chooser_get_use_alpha>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_get_use_alpha"));

		// Token: 0x040007F1 RID: 2033
		private static ColorChooserAdapter.d_gtk_color_chooser_set_use_alpha gtk_color_chooser_set_use_alpha = FuncLoader.LoadFunction<ColorChooserAdapter.d_gtk_color_chooser_set_use_alpha>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_set_use_alpha"));

		// Token: 0x040007F2 RID: 2034
		private static ColorChooserAdapter.d_gtk_color_chooser_add_palette gtk_color_chooser_add_palette = FuncLoader.LoadFunction<ColorChooserAdapter.d_gtk_color_chooser_add_palette>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_add_palette"));

		// Token: 0x02000B4B RID: 2891
		private struct GtkColorChooserInterface
		{
			// Token: 0x04001E6A RID: 7786
			public ColorChooserAdapter.AddPaletteNativeDelegate AddPalette;

			// Token: 0x04001E6B RID: 7787
			private IntPtr ColorActivated;

			// Token: 0x04001E6C RID: 7788
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
			public IntPtr[] Padding;
		}

		// Token: 0x02000B4C RID: 2892
		// (Invoke) Token: 0x06005439 RID: 21561
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void AddPaletteNativeDelegate(IntPtr inst, int orientation, int colors_per_line, int n_colors, IntPtr colors);

		// Token: 0x02000B4D RID: 2893
		// (Invoke) Token: 0x0600543D RID: 21565
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_color_chooser_get_type();

		// Token: 0x02000B4E RID: 2894
		// (Invoke) Token: 0x06005441 RID: 21569
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_chooser_get_rgba(IntPtr raw, IntPtr color);

		// Token: 0x02000B4F RID: 2895
		// (Invoke) Token: 0x06005445 RID: 21573
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_chooser_set_rgba(IntPtr raw, IntPtr value);

		// Token: 0x02000B50 RID: 2896
		// (Invoke) Token: 0x06005449 RID: 21577
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_color_chooser_get_use_alpha(IntPtr raw);

		// Token: 0x02000B51 RID: 2897
		// (Invoke) Token: 0x0600544D RID: 21581
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_chooser_set_use_alpha(IntPtr raw, bool use_alpha);

		// Token: 0x02000B52 RID: 2898
		// (Invoke) Token: 0x06005451 RID: 21585
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_chooser_add_palette(IntPtr raw, int orientation, int colors_per_line, int n_colors, IntPtr colors);
	}
}
