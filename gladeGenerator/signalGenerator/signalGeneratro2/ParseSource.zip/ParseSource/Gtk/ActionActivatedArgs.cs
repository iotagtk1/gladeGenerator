﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000107 RID: 263
	public class ActionActivatedArgs : SignalArgs
	{
		// Token: 0x17000270 RID: 624
		// (get) Token: 0x06000BC3 RID: 3011 RVA: 0x00023897 File Offset: 0x00021A97
		public int Index
		{
			get
			{
				return (int)base.Args[0];
			}
		}
	}
}
