﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x0200018C RID: 396
	public class ChildDetachedArgs : SignalArgs
	{
		// Token: 0x170003CF RID: 975
		// (get) Token: 0x0600108A RID: 4234 RVA: 0x00031D4F File Offset: 0x0002FF4F
		public Widget Child
		{
			get
			{
				return (Widget)base.Args[0];
			}
		}
	}
}
