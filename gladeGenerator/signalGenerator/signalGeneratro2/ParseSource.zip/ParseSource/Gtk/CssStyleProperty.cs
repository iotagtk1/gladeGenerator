﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x02000203 RID: 515
	public class CssStyleProperty : Opaque
	{
		// Token: 0x06001220 RID: 4640 RVA: 0x00034F33 File Offset: 0x00033133
		public CssStyleProperty(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700045E RID: 1118
		// (get) Token: 0x06001221 RID: 4641 RVA: 0x00034F3C File Offset: 0x0003313C
		public static AbiStruct abi_info
		{
			get
			{
				if (CssStyleProperty._abi_info == null)
				{
					CssStyleProperty._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssStyleProperty._abi_info;
			}
		}

		// Token: 0x04000889 RID: 2185
		private static AbiStruct _abi_info;
	}
}
