﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000173 RID: 371
	[GType(typeof(CellRendererModeGType))]
	public enum CellRendererMode
	{
		// Token: 0x0400079D RID: 1949
		Inert,
		// Token: 0x0400079E RID: 1950
		Activatable,
		// Token: 0x0400079F RID: 1951
		Editable
	}
}
