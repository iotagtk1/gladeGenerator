﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001D7 RID: 471
	public class CssImageRadialClass : Opaque
	{
		// Token: 0x060011A9 RID: 4521 RVA: 0x0003400F File Offset: 0x0003220F
		public CssImageRadialClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000428 RID: 1064
		// (get) Token: 0x060011AA RID: 4522 RVA: 0x00034018 File Offset: 0x00032218
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImageRadialClass._abi_info == null)
				{
					CssImageRadialClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImageRadialClass._abi_info;
			}
		}

		// Token: 0x04000837 RID: 2103
		private static AbiStruct _abi_info;
	}
}
