﻿using System;

namespace Gtk
{
	// Token: 0x020001A9 RID: 425
	// (Invoke) Token: 0x06001140 RID: 4416
	public delegate void CommitHandler(object o, CommitArgs args);
}
