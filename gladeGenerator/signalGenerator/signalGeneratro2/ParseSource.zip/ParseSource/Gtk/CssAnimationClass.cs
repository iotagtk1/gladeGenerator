﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001C0 RID: 448
	public class CssAnimationClass : Opaque
	{
		// Token: 0x0600117B RID: 4475 RVA: 0x00033CA5 File Offset: 0x00031EA5
		public CssAnimationClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000411 RID: 1041
		// (get) Token: 0x0600117C RID: 4476 RVA: 0x00033CAE File Offset: 0x00031EAE
		public static AbiStruct abi_info
		{
			get
			{
				if (CssAnimationClass._abi_info == null)
				{
					CssAnimationClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssAnimationClass._abi_info;
			}
		}

		// Token: 0x04000820 RID: 2080
		private static AbiStruct _abi_info;
	}
}
