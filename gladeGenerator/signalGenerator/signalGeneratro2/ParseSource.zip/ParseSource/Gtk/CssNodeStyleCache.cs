﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001EC RID: 492
	public class CssNodeStyleCache : Opaque
	{
		// Token: 0x060011D3 RID: 4563 RVA: 0x0003432D File Offset: 0x0003252D
		public CssNodeStyleCache(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700043D RID: 1085
		// (get) Token: 0x060011D4 RID: 4564 RVA: 0x00034336 File Offset: 0x00032536
		public static AbiStruct abi_info
		{
			get
			{
				if (CssNodeStyleCache._abi_info == null)
				{
					CssNodeStyleCache._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssNodeStyleCache._abi_info;
			}
		}

		// Token: 0x0400084C RID: 2124
		private static AbiStruct _abi_info;
	}
}
