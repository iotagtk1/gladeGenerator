﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001AB RID: 427
	public class CompareInfo : Opaque
	{
		// Token: 0x06001145 RID: 4421 RVA: 0x00033B1F File Offset: 0x00031D1F
		public CompareInfo(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000405 RID: 1029
		// (get) Token: 0x06001146 RID: 4422 RVA: 0x00033B28 File Offset: 0x00031D28
		public static AbiStruct abi_info
		{
			get
			{
				if (CompareInfo._abi_info == null)
				{
					CompareInfo._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CompareInfo._abi_info;
			}
		}

		// Token: 0x04000815 RID: 2069
		private static AbiStruct _abi_info;
	}
}
