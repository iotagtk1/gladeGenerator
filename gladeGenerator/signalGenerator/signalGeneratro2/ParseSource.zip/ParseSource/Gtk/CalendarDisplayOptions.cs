﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x0200015F RID: 351
	[Flags]
	[GType(typeof(CalendarDisplayOptionsGType))]
	public enum CalendarDisplayOptions
	{
		// Token: 0x0400072C RID: 1836
		ShowHeading = 1,
		// Token: 0x0400072D RID: 1837
		ShowDayNames = 2,
		// Token: 0x0400072E RID: 1838
		NoMonthChange = 4,
		// Token: 0x0400072F RID: 1839
		ShowWeekNumbers = 8,
		// Token: 0x04000730 RID: 1840
		ShowDetails = 32
	}
}
