﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x0200017C RID: 380
	public class CellRendererToggle : CellRenderer
	{
		// Token: 0x06001037 RID: 4151 RVA: 0x000312B6 File Offset: 0x0002F4B6
		public CellRendererToggle(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06001038 RID: 4152 RVA: 0x000312C0 File Offset: 0x0002F4C0
		public CellRendererToggle() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(CellRendererToggle))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = CellRendererToggle.gtk_cell_renderer_toggle_new();
		}

		// Token: 0x170003B8 RID: 952
		// (get) Token: 0x06001039 RID: 4153 RVA: 0x00031312 File Offset: 0x0002F512
		// (set) Token: 0x0600103A RID: 4154 RVA: 0x00031324 File Offset: 0x0002F524
		[Property("active")]
		public bool Active
		{
			get
			{
				return CellRendererToggle.gtk_cell_renderer_toggle_get_active(base.Handle);
			}
			set
			{
				CellRendererToggle.gtk_cell_renderer_toggle_set_active(base.Handle, value);
			}
		}

		// Token: 0x170003B9 RID: 953
		// (get) Token: 0x0600103B RID: 4155 RVA: 0x00031338 File Offset: 0x0002F538
		// (set) Token: 0x0600103C RID: 4156 RVA: 0x00031360 File Offset: 0x0002F560
		[Property("inconsistent")]
		public bool Inconsistent
		{
			get
			{
				Value property = base.GetProperty("inconsistent");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("inconsistent", val);
				val.Dispose();
			}
		}

		// Token: 0x170003BA RID: 954
		// (get) Token: 0x0600103D RID: 4157 RVA: 0x00031388 File Offset: 0x0002F588
		// (set) Token: 0x0600103E RID: 4158 RVA: 0x0003139A File Offset: 0x0002F59A
		[Property("activatable")]
		public bool Activatable
		{
			get
			{
				return CellRendererToggle.gtk_cell_renderer_toggle_get_activatable(base.Handle);
			}
			set
			{
				CellRendererToggle.gtk_cell_renderer_toggle_set_activatable(base.Handle, value);
			}
		}

		// Token: 0x170003BB RID: 955
		// (get) Token: 0x0600103F RID: 4159 RVA: 0x000313AD File Offset: 0x0002F5AD
		// (set) Token: 0x06001040 RID: 4160 RVA: 0x000313BF File Offset: 0x0002F5BF
		[Property("radio")]
		public bool Radio
		{
			get
			{
				return CellRendererToggle.gtk_cell_renderer_toggle_get_radio(base.Handle);
			}
			set
			{
				CellRendererToggle.gtk_cell_renderer_toggle_set_radio(base.Handle, value);
			}
		}

		// Token: 0x170003BC RID: 956
		// (get) Token: 0x06001041 RID: 4161 RVA: 0x000313D4 File Offset: 0x0002F5D4
		// (set) Token: 0x06001042 RID: 4162 RVA: 0x000313FC File Offset: 0x0002F5FC
		[Property("indicator-size")]
		public int IndicatorSize
		{
			get
			{
				Value property = base.GetProperty("indicator-size");
				int result = (int)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("indicator-size", val);
				val.Dispose();
			}
		}

		// Token: 0x14000066 RID: 102
		// (add) Token: 0x06001043 RID: 4163 RVA: 0x00031424 File Offset: 0x0002F624
		// (remove) Token: 0x06001044 RID: 4164 RVA: 0x0003143C File Offset: 0x0002F63C
		[Signal("toggled")]
		public event ToggledHandler Toggled
		{
			add
			{
				base.AddSignalHandler("toggled", value, typeof(ToggledArgs));
			}
			remove
			{
				base.RemoveSignalHandler("toggled", value);
			}
		}

		// Token: 0x170003BD RID: 957
		// (get) Token: 0x06001045 RID: 4165 RVA: 0x0003144A File Offset: 0x0002F64A
		private static CellRendererToggle.ToggledNativeDelegate ToggledVMCallback
		{
			get
			{
				if (CellRendererToggle.Toggled_cb_delegate == null)
				{
					CellRendererToggle.Toggled_cb_delegate = new CellRendererToggle.ToggledNativeDelegate(CellRendererToggle.Toggled_cb);
				}
				return CellRendererToggle.Toggled_cb_delegate;
			}
		}

		// Token: 0x06001046 RID: 4166 RVA: 0x00031469 File Offset: 0x0002F669
		private static void OverrideToggled(GType gtype)
		{
			CellRendererToggle.OverrideToggled(gtype, CellRendererToggle.ToggledVMCallback);
		}

		// Token: 0x06001047 RID: 4167 RVA: 0x00031478 File Offset: 0x0002F678
		private unsafe static void OverrideToggled(GType gtype, CellRendererToggle.ToggledNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellRendererToggle.class_abi.GetFieldOffset("toggled");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06001048 RID: 4168 RVA: 0x000314AC File Offset: 0x0002F6AC
		private static void Toggled_cb(IntPtr inst, IntPtr path)
		{
			try
			{
				(Object.GetObject(inst, false) as CellRendererToggle).OnToggled(Marshaller.Utf8PtrToString(path));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06001049 RID: 4169 RVA: 0x000314EC File Offset: 0x0002F6EC
		[DefaultSignalHandler(Type = typeof(CellRendererToggle), ConnectionMethod = "OverrideToggled")]
		protected virtual void OnToggled(string path)
		{
			this.InternalToggled(path);
		}

		// Token: 0x0600104A RID: 4170 RVA: 0x000314F8 File Offset: 0x0002F6F8
		private void InternalToggled(string path)
		{
			CellRendererToggle.ToggledNativeDelegate toggledNativeDelegate = CellRendererToggle.class_abi.BaseOverride(base.LookupGType(), "toggled");
			if (toggledNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(path);
			toggledNativeDelegate(base.Handle, intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x170003BE RID: 958
		// (get) Token: 0x0600104B RID: 4171 RVA: 0x0003153C File Offset: 0x0002F73C
		public new static AbiStruct class_abi
		{
			get
			{
				if (CellRendererToggle._class_abi == null)
				{
					CellRendererToggle._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("toggled", CellRenderer.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved1", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved1", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "toggled", "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellRendererToggle._class_abi;
			}
		}

		// Token: 0x170003BF RID: 959
		// (get) Token: 0x0600104C RID: 4172 RVA: 0x00031694 File Offset: 0x0002F894
		public new static GType GType
		{
			get
			{
				IntPtr val = CellRendererToggle.gtk_cell_renderer_toggle_get_type();
				return new GType(val);
			}
		}

		// Token: 0x170003C0 RID: 960
		// (get) Token: 0x0600104D RID: 4173 RVA: 0x000316B4 File Offset: 0x0002F8B4
		public new static AbiStruct abi_info
		{
			get
			{
				if (CellRendererToggle._abi_info == null)
				{
					CellRendererToggle._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", CellRenderer.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellRendererToggle._abi_info;
			}
		}

		// Token: 0x040007C2 RID: 1986
		private static CellRendererToggle.d_gtk_cell_renderer_toggle_new gtk_cell_renderer_toggle_new = FuncLoader.LoadFunction<CellRendererToggle.d_gtk_cell_renderer_toggle_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_toggle_new"));

		// Token: 0x040007C3 RID: 1987
		private static CellRendererToggle.d_gtk_cell_renderer_toggle_get_active gtk_cell_renderer_toggle_get_active = FuncLoader.LoadFunction<CellRendererToggle.d_gtk_cell_renderer_toggle_get_active>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_toggle_get_active"));

		// Token: 0x040007C4 RID: 1988
		private static CellRendererToggle.d_gtk_cell_renderer_toggle_set_active gtk_cell_renderer_toggle_set_active = FuncLoader.LoadFunction<CellRendererToggle.d_gtk_cell_renderer_toggle_set_active>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_toggle_set_active"));

		// Token: 0x040007C5 RID: 1989
		private static CellRendererToggle.d_gtk_cell_renderer_toggle_get_activatable gtk_cell_renderer_toggle_get_activatable = FuncLoader.LoadFunction<CellRendererToggle.d_gtk_cell_renderer_toggle_get_activatable>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_toggle_get_activatable"));

		// Token: 0x040007C6 RID: 1990
		private static CellRendererToggle.d_gtk_cell_renderer_toggle_set_activatable gtk_cell_renderer_toggle_set_activatable = FuncLoader.LoadFunction<CellRendererToggle.d_gtk_cell_renderer_toggle_set_activatable>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_toggle_set_activatable"));

		// Token: 0x040007C7 RID: 1991
		private static CellRendererToggle.d_gtk_cell_renderer_toggle_get_radio gtk_cell_renderer_toggle_get_radio = FuncLoader.LoadFunction<CellRendererToggle.d_gtk_cell_renderer_toggle_get_radio>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_toggle_get_radio"));

		// Token: 0x040007C8 RID: 1992
		private static CellRendererToggle.d_gtk_cell_renderer_toggle_set_radio gtk_cell_renderer_toggle_set_radio = FuncLoader.LoadFunction<CellRendererToggle.d_gtk_cell_renderer_toggle_set_radio>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_toggle_set_radio"));

		// Token: 0x040007C9 RID: 1993
		private static CellRendererToggle.ToggledNativeDelegate Toggled_cb_delegate;

		// Token: 0x040007CA RID: 1994
		private static AbiStruct _class_abi = null;

		// Token: 0x040007CB RID: 1995
		private static CellRendererToggle.d_gtk_cell_renderer_toggle_get_type gtk_cell_renderer_toggle_get_type = FuncLoader.LoadFunction<CellRendererToggle.d_gtk_cell_renderer_toggle_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_toggle_get_type"));

		// Token: 0x040007CC RID: 1996
		private static AbiStruct _abi_info = null;

		// Token: 0x02000B2C RID: 2860
		// (Invoke) Token: 0x060053BD RID: 21437
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_renderer_toggle_new();

		// Token: 0x02000B2D RID: 2861
		// (Invoke) Token: 0x060053C1 RID: 21441
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_cell_renderer_toggle_get_active(IntPtr raw);

		// Token: 0x02000B2E RID: 2862
		// (Invoke) Token: 0x060053C5 RID: 21445
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_toggle_set_active(IntPtr raw, bool setting);

		// Token: 0x02000B2F RID: 2863
		// (Invoke) Token: 0x060053C9 RID: 21449
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_cell_renderer_toggle_get_activatable(IntPtr raw);

		// Token: 0x02000B30 RID: 2864
		// (Invoke) Token: 0x060053CD RID: 21453
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_toggle_set_activatable(IntPtr raw, bool setting);

		// Token: 0x02000B31 RID: 2865
		// (Invoke) Token: 0x060053D1 RID: 21457
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_cell_renderer_toggle_get_radio(IntPtr raw);

		// Token: 0x02000B32 RID: 2866
		// (Invoke) Token: 0x060053D5 RID: 21461
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_toggle_set_radio(IntPtr raw, bool radio);

		// Token: 0x02000B33 RID: 2867
		// (Invoke) Token: 0x060053D9 RID: 21465
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ToggledNativeDelegate(IntPtr inst, IntPtr path);

		// Token: 0x02000B34 RID: 2868
		// (Invoke) Token: 0x060053DD RID: 21469
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_renderer_toggle_get_type();
	}
}
