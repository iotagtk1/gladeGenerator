﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001D0 RID: 464
	public class CssImageGradientClass : Opaque
	{
		// Token: 0x0600119B RID: 4507 RVA: 0x00033F05 File Offset: 0x00032105
		public CssImageGradientClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000421 RID: 1057
		// (get) Token: 0x0600119C RID: 4508 RVA: 0x00033F0E File Offset: 0x0003210E
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImageGradientClass._abi_info == null)
				{
					CssImageGradientClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImageGradientClass._abi_info;
			}
		}

		// Token: 0x04000830 RID: 2096
		private static AbiStruct _abi_info;
	}
}
