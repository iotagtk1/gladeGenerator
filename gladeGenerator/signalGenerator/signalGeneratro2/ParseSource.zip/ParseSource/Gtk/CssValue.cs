﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x02000209 RID: 521
	public class CssValue : Opaque
	{
		// Token: 0x0600122C RID: 4652 RVA: 0x00035017 File Offset: 0x00033217
		public CssValue(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000464 RID: 1124
		// (get) Token: 0x0600122D RID: 4653 RVA: 0x00035020 File Offset: 0x00033220
		public static AbiStruct abi_info
		{
			get
			{
				if (CssValue._abi_info == null)
				{
					CssValue._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssValue._abi_info;
			}
		}

		// Token: 0x0400088F RID: 2191
		private static AbiStruct _abi_info;
	}
}
