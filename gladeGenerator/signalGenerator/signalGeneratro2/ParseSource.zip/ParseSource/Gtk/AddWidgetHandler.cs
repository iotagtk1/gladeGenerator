﻿using System;

namespace Gtk
{
	// Token: 0x02000116 RID: 278
	// (Invoke) Token: 0x06000C75 RID: 3189
	public delegate void AddWidgetHandler(object o, AddWidgetArgs args);
}
