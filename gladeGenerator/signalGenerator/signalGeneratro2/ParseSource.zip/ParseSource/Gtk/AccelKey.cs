﻿using System;
using System.Runtime.InteropServices;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x020000CF RID: 207
	public struct AccelKey : IEquatable<AccelKey>
	{
		// Token: 0x060003C3 RID: 963 RVA: 0x0000911D File Offset: 0x0000731D
		public AccelKey(Key key, ModifierType mods, AccelFlags flags)
		{
			this.Key = key;
			this.AccelMods = mods;
			this.AccelFlags = (ushort)flags;
		}

		// Token: 0x060003C4 RID: 964 RVA: 0x00009135 File Offset: 0x00007335
		public static AccelKey New(IntPtr raw)
		{
			if (raw == IntPtr.Zero)
			{
				return AccelKey.Zero;
			}
			return (AccelKey)Marshal.PtrToStructure(raw, typeof(AccelKey));
		}

		// Token: 0x060003C5 RID: 965 RVA: 0x00009160 File Offset: 0x00007360
		public bool Equals(AccelKey other)
		{
			return this.Key.Equals(other.Key) && this.AccelMods.Equals(other.AccelMods) && this.AccelFlags.Equals(other.AccelFlags);
		}

		// Token: 0x060003C6 RID: 966 RVA: 0x000091BC File Offset: 0x000073BC
		public override bool Equals(object other)
		{
			return other is AccelKey && this.Equals((AccelKey)other);
		}

		// Token: 0x060003C7 RID: 967 RVA: 0x000091D4 File Offset: 0x000073D4
		public override int GetHashCode()
		{
			return base.GetType().FullName.GetHashCode() ^ this.Key.GetHashCode() ^ this.AccelMods.GetHashCode() ^ this.AccelFlags.GetHashCode();
		}

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x060003C8 RID: 968 RVA: 0x0000922B File Offset: 0x0000742B
		private static GType GType
		{
			get
			{
				return GType.Pointer;
			}
		}

		// Token: 0x040001F5 RID: 501
		public Key Key;

		// Token: 0x040001F6 RID: 502
		public ModifierType AccelMods;

		// Token: 0x040001F7 RID: 503
		public ushort AccelFlags;

		// Token: 0x040001F8 RID: 504
		public static AccelKey Zero;
	}
}
