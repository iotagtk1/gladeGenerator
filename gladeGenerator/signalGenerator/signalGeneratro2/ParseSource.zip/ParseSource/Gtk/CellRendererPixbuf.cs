﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x02000175 RID: 373
	public class CellRendererPixbuf : CellRenderer
	{
		// Token: 0x06000FA4 RID: 4004 RVA: 0x0002F45D File Offset: 0x0002D65D
		public CellRendererPixbuf(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000FA5 RID: 4005 RVA: 0x0002F468 File Offset: 0x0002D668
		public CellRendererPixbuf() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(CellRendererPixbuf))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = CellRendererPixbuf.gtk_cell_renderer_pixbuf_new();
		}

		// Token: 0x17000370 RID: 880
		// (get) Token: 0x06000FA6 RID: 4006 RVA: 0x0002F4BC File Offset: 0x0002D6BC
		// (set) Token: 0x06000FA7 RID: 4007 RVA: 0x0002F4E8 File Offset: 0x0002D6E8
		[Property("pixbuf")]
		public Pixbuf Pixbuf
		{
			get
			{
				Value property = base.GetProperty("pixbuf");
				Pixbuf result = (Pixbuf)((Object)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("pixbuf", val);
				val.Dispose();
			}
		}

		// Token: 0x17000371 RID: 881
		// (get) Token: 0x06000FA8 RID: 4008 RVA: 0x0002F510 File Offset: 0x0002D710
		// (set) Token: 0x06000FA9 RID: 4009 RVA: 0x0002F53C File Offset: 0x0002D73C
		[Property("pixbuf-expander-open")]
		public Pixbuf PixbufExpanderOpen
		{
			get
			{
				Value property = base.GetProperty("pixbuf-expander-open");
				Pixbuf result = (Pixbuf)((Object)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("pixbuf-expander-open", val);
				val.Dispose();
			}
		}

		// Token: 0x17000372 RID: 882
		// (get) Token: 0x06000FAA RID: 4010 RVA: 0x0002F564 File Offset: 0x0002D764
		// (set) Token: 0x06000FAB RID: 4011 RVA: 0x0002F590 File Offset: 0x0002D790
		[Property("pixbuf-expander-closed")]
		public Pixbuf PixbufExpanderClosed
		{
			get
			{
				Value property = base.GetProperty("pixbuf-expander-closed");
				Pixbuf result = (Pixbuf)((Object)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("pixbuf-expander-closed", val);
				val.Dispose();
			}
		}

		// Token: 0x17000373 RID: 883
		// (get) Token: 0x06000FAC RID: 4012 RVA: 0x0002F5B8 File Offset: 0x0002D7B8
		// (set) Token: 0x06000FAD RID: 4013 RVA: 0x0002F5E0 File Offset: 0x0002D7E0
		[Property("stock-id")]
		public string StockId
		{
			get
			{
				Value property = base.GetProperty("stock-id");
				string result = (string)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("stock-id", val);
				val.Dispose();
			}
		}

		// Token: 0x17000374 RID: 884
		// (get) Token: 0x06000FAE RID: 4014 RVA: 0x0002F608 File Offset: 0x0002D808
		// (set) Token: 0x06000FAF RID: 4015 RVA: 0x0002F630 File Offset: 0x0002D830
		[Property("stock-size")]
		public uint StockSize
		{
			get
			{
				Value property = base.GetProperty("stock-size");
				uint result = (uint)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("stock-size", val);
				val.Dispose();
			}
		}

		// Token: 0x17000375 RID: 885
		// (get) Token: 0x06000FB0 RID: 4016 RVA: 0x0002F658 File Offset: 0x0002D858
		// (set) Token: 0x06000FB1 RID: 4017 RVA: 0x0002F680 File Offset: 0x0002D880
		[Property("stock-detail")]
		public string StockDetail
		{
			get
			{
				Value property = base.GetProperty("stock-detail");
				string result = (string)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("stock-detail", val);
				val.Dispose();
			}
		}

		// Token: 0x17000376 RID: 886
		// (get) Token: 0x06000FB2 RID: 4018 RVA: 0x0002F6A8 File Offset: 0x0002D8A8
		// (set) Token: 0x06000FB3 RID: 4019 RVA: 0x0002F6D0 File Offset: 0x0002D8D0
		[Property("icon-name")]
		public string IconName
		{
			get
			{
				Value property = base.GetProperty("icon-name");
				string result = (string)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("icon-name", val);
				val.Dispose();
			}
		}

		// Token: 0x17000377 RID: 887
		// (get) Token: 0x06000FB4 RID: 4020 RVA: 0x0002F6F8 File Offset: 0x0002D8F8
		// (set) Token: 0x06000FB5 RID: 4021 RVA: 0x0002F720 File Offset: 0x0002D920
		[Property("follow-state")]
		public bool FollowState
		{
			get
			{
				Value property = base.GetProperty("follow-state");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("follow-state", val);
				val.Dispose();
			}
		}

		// Token: 0x17000378 RID: 888
		// (get) Token: 0x06000FB6 RID: 4022 RVA: 0x0002F748 File Offset: 0x0002D948
		// (set) Token: 0x06000FB7 RID: 4023 RVA: 0x0002F774 File Offset: 0x0002D974
		[Property("gicon")]
		public IIcon Icon
		{
			get
			{
				Value property = base.GetProperty("gicon");
				IIcon @object = IconAdapter.GetObject((Object)property);
				property.Dispose();
				return @object;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("gicon", val);
				val.Dispose();
			}
		}

		// Token: 0x17000379 RID: 889
		// (get) Token: 0x06000FB8 RID: 4024 RVA: 0x0002F79C File Offset: 0x0002D99C
		public new static AbiStruct class_abi
		{
			get
			{
				if (CellRendererPixbuf._class_abi == null)
				{
					CellRendererPixbuf._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("_gtk_reserved1", CellRenderer.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellRendererPixbuf._class_abi;
			}
		}

		// Token: 0x1700037A RID: 890
		// (get) Token: 0x06000FB9 RID: 4025 RVA: 0x0002F8B8 File Offset: 0x0002DAB8
		public new static GType GType
		{
			get
			{
				IntPtr val = CellRendererPixbuf.gtk_cell_renderer_pixbuf_get_type();
				return new GType(val);
			}
		}

		// Token: 0x1700037B RID: 891
		// (get) Token: 0x06000FBA RID: 4026 RVA: 0x0002F8D8 File Offset: 0x0002DAD8
		public new static AbiStruct abi_info
		{
			get
			{
				if (CellRendererPixbuf._abi_info == null)
				{
					CellRendererPixbuf._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", CellRenderer.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellRendererPixbuf._abi_info;
			}
		}

		// Token: 0x040007A1 RID: 1953
		private static CellRendererPixbuf.d_gtk_cell_renderer_pixbuf_new gtk_cell_renderer_pixbuf_new = FuncLoader.LoadFunction<CellRendererPixbuf.d_gtk_cell_renderer_pixbuf_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_pixbuf_new"));

		// Token: 0x040007A2 RID: 1954
		private static AbiStruct _class_abi = null;

		// Token: 0x040007A3 RID: 1955
		private static CellRendererPixbuf.d_gtk_cell_renderer_pixbuf_get_type gtk_cell_renderer_pixbuf_get_type = FuncLoader.LoadFunction<CellRendererPixbuf.d_gtk_cell_renderer_pixbuf_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_pixbuf_get_type"));

		// Token: 0x040007A4 RID: 1956
		private static AbiStruct _abi_info = null;

		// Token: 0x02000B1D RID: 2845
		// (Invoke) Token: 0x06005381 RID: 21377
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_renderer_pixbuf_new();

		// Token: 0x02000B1E RID: 2846
		// (Invoke) Token: 0x06005385 RID: 21381
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_renderer_pixbuf_get_type();
	}
}
