﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Text;
using GLib;
using GtkSharp;

namespace Gtk
{
	// Token: 0x020000D8 RID: 216
	public class Builder : Object
	{
		// Token: 0x060004D8 RID: 1240 RVA: 0x0000CDF4 File Offset: 0x0000AFF4
		public IntPtr GetRawObject(string name)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(name);
			IntPtr result = Builder.gtk_builder_get_object(base.Handle, intPtr);
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x060004D9 RID: 1241 RVA: 0x0000CE20 File Offset: 0x0000B020
		public IntPtr GetRawOwnedObject(string name)
		{
			IntPtr rawObject = this.GetRawObject(name);
			Builder.g_object_ref(rawObject);
			return rawObject;
		}

		// Token: 0x060004DA RID: 1242 RVA: 0x0000CE42 File Offset: 0x0000B042
		public Builder(Stream s) : this(s, null)
		{
		}

		// Token: 0x060004DB RID: 1243 RVA: 0x0000CE4C File Offset: 0x0000B04C
		public Builder(Stream s, string translation_domain)
		{
			if (s == null)
			{
				throw new ArgumentNullException("s");
			}
			this.AddFromStream(s);
			this.TranslationDomain = translation_domain;
		}

		// Token: 0x060004DC RID: 1244 RVA: 0x0000CE70 File Offset: 0x0000B070
		public Builder(string resource_name) : this(Assembly.GetCallingAssembly(), resource_name, null)
		{
		}

		// Token: 0x060004DD RID: 1245 RVA: 0x0000CE7F File Offset: 0x0000B07F
		public Builder(string resource_name, string translation_domain) : this(Assembly.GetCallingAssembly(), resource_name, translation_domain)
		{
		}

		// Token: 0x060004DE RID: 1246 RVA: 0x0000CE90 File Offset: 0x0000B090
		public Builder(Assembly assembly, string resource_name, string translation_domain) : this()
		{
			if (base.GetType() != typeof(Builder))
			{
				throw new InvalidOperationException("Cannot chain to this constructor from subclasses.");
			}
			if (assembly == null)
			{
				assembly = Assembly.GetCallingAssembly();
			}
			Stream manifestResourceStream = assembly.GetManifestResourceStream(resource_name);
			if (manifestResourceStream == null)
			{
				throw new ArgumentException("Cannot get resource file '" + resource_name + "'", "resource_name");
			}
			this.AddFromStream(manifestResourceStream);
			this.TranslationDomain = translation_domain;
		}

		// Token: 0x060004DF RID: 1247 RVA: 0x0000CF09 File Offset: 0x0000B109
		public void Autoconnect(object handler)
		{
			this.BindFields(handler);
			new Builder.SignalConnector(this, handler).ConnectSignals();
		}

		// Token: 0x060004E0 RID: 1248 RVA: 0x0000CF1E File Offset: 0x0000B11E
		public void Autoconnect(Type handler_class)
		{
			this.BindFields(handler_class);
			new Builder.SignalConnector(this, handler_class).ConnectSignals();
		}

		// Token: 0x060004E1 RID: 1249 RVA: 0x0000CF34 File Offset: 0x0000B134
		private void AddFromStream(Stream stream)
		{
			int num = (int)stream.Length;
			byte[] array = new byte[num];
			stream.Read(array, 0, num);
			stream.Close();
			int num2 = 0;
			if (num >= 3 && array[0] == 239 && array[1] == 187 && array[2] == 191)
			{
				num2 = 3;
			}
			string @string = Encoding.UTF8.GetString(array, num2, num - num2);
			this.AddFromString(@string);
		}

		// Token: 0x060004E2 RID: 1250 RVA: 0x0000CF9E File Offset: 0x0000B19E
		private void BindFields(object target)
		{
			this.BindFields(target, target.GetType());
		}

		// Token: 0x060004E3 RID: 1251 RVA: 0x0000CFAD File Offset: 0x0000B1AD
		private void BindFields(Type type)
		{
			this.BindFields(null, type);
		}

		// Token: 0x060004E4 RID: 1252 RVA: 0x0000CFB8 File Offset: 0x0000B1B8
		private void BindFields(object target, Type type)
		{
			BindingFlags bindingFlags = BindingFlags.DeclaredOnly | BindingFlags.Public | BindingFlags.NonPublic;
			if (target != null)
			{
				bindingFlags |= BindingFlags.Instance;
			}
			else
			{
				bindingFlags |= BindingFlags.Static;
			}
			for (;;)
			{
				FieldInfo[] fields = type.GetFields(bindingFlags);
				if (fields == null)
				{
					break;
				}
				foreach (FieldInfo fieldInfo in fields)
				{
					object[] customAttributes = fieldInfo.GetCustomAttributes(typeof(Builder.ObjectAttribute), false);
					if (customAttributes != null && customAttributes.Length != 0)
					{
						Builder.ObjectAttribute objectAttribute = (Builder.ObjectAttribute)customAttributes[0];
						Object @object;
						if (objectAttribute.Specified)
						{
							@object = this.GetObject(objectAttribute.Name);
						}
						else
						{
							@object = this.GetObject(fieldInfo.Name);
						}
						if (@object != null)
						{
							try
							{
								fieldInfo.SetValue(target, @object, bindingFlags, null, null);
							}
							catch (Exception ex)
							{
								Console.WriteLine("Unable to set value for field " + fieldInfo.Name);
								throw ex;
							}
						}
					}
				}
				type = type.BaseType;
				if (!(type != typeof(object)) || !(type != null))
				{
					return;
				}
			}
		}

		// Token: 0x060004E5 RID: 1253 RVA: 0x0000D0B0 File Offset: 0x0000B2B0
		public Builder(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x060004E6 RID: 1254 RVA: 0x0000D0BC File Offset: 0x0000B2BC
		public Builder() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Builder))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = Builder.gtk_builder_new();
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x060004E7 RID: 1255 RVA: 0x0000D10E File Offset: 0x0000B30E
		// (set) Token: 0x060004E8 RID: 1256 RVA: 0x0000D128 File Offset: 0x0000B328
		[Property("translation-domain")]
		public string TranslationDomain
		{
			get
			{
				return Marshaller.Utf8PtrToString(Builder.gtk_builder_get_translation_domain(base.Handle));
			}
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				Builder.gtk_builder_set_translation_domain(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x060004E9 RID: 1257 RVA: 0x0000D153 File Offset: 0x0000B353
		private static Builder.GetTypeFromNameNativeDelegate GetTypeFromNameVMCallback
		{
			get
			{
				if (Builder.GetTypeFromName_cb_delegate == null)
				{
					Builder.GetTypeFromName_cb_delegate = new Builder.GetTypeFromNameNativeDelegate(Builder.GetTypeFromName_cb);
				}
				return Builder.GetTypeFromName_cb_delegate;
			}
		}

		// Token: 0x060004EA RID: 1258 RVA: 0x0000D172 File Offset: 0x0000B372
		private static void OverrideGetTypeFromName(GType gtype)
		{
			Builder.OverrideGetTypeFromName(gtype, Builder.GetTypeFromNameVMCallback);
		}

		// Token: 0x060004EB RID: 1259 RVA: 0x0000D180 File Offset: 0x0000B380
		private unsafe static void OverrideGetTypeFromName(GType gtype, Builder.GetTypeFromNameNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Builder.class_abi.GetFieldOffset("get_type_from_name");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060004EC RID: 1260 RVA: 0x0000D1B4 File Offset: 0x0000B3B4
		private static IntPtr GetTypeFromName_cb(IntPtr inst, IntPtr type_name)
		{
			IntPtr val;
			try
			{
				val = (Object.GetObject(inst, false) as Builder).OnGetTypeFromName(Marshaller.Utf8PtrToString(type_name)).Val;
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return val;
		}

		// Token: 0x060004ED RID: 1261 RVA: 0x0000D1FC File Offset: 0x0000B3FC
		[DefaultSignalHandler(Type = typeof(Builder), ConnectionMethod = "OverrideGetTypeFromName")]
		protected virtual GType OnGetTypeFromName(string type_name)
		{
			return this.InternalGetTypeFromName(type_name);
		}

		// Token: 0x060004EE RID: 1262 RVA: 0x0000D208 File Offset: 0x0000B408
		private GType InternalGetTypeFromName(string type_name)
		{
			Builder.GetTypeFromNameNativeDelegate getTypeFromNameNativeDelegate = Builder.class_abi.BaseOverride(base.LookupGType(), "get_type_from_name");
			if (getTypeFromNameNativeDelegate == null)
			{
				return GType.None;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(type_name);
			IntPtr val = getTypeFromNameNativeDelegate(base.Handle, intPtr);
			Marshaller.Free(intPtr);
			return new GType(val);
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x060004EF RID: 1263 RVA: 0x0000D254 File Offset: 0x0000B454
		public new static AbiStruct class_abi
		{
			get
			{
				if (Builder._class_abi == null)
				{
					Builder._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("get_type_from_name", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved1", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved1", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_type_from_name", "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", "_gtk_reserved5", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved5", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved4", "_gtk_reserved6", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved6", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved5", "_gtk_reserved7", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved7", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved6", "_gtk_reserved8", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved8", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved7", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Builder._class_abi;
			}
		}

		// Token: 0x060004F0 RID: 1264 RVA: 0x0000D49C File Offset: 0x0000B69C
		public uint AddFromFile(string filename)
		{
			IntPtr intPtr = Marshaller.StringToFilenamePtr(filename);
			IntPtr zero = IntPtr.Zero;
			uint result = Builder.gtk_builder_add_from_file(base.Handle, intPtr, out zero);
			Marshaller.Free(intPtr);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x060004F1 RID: 1265 RVA: 0x0000D4E4 File Offset: 0x0000B6E4
		public uint AddFromResource(string resource_path)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(resource_path);
			IntPtr zero = IntPtr.Zero;
			uint result = Builder.gtk_builder_add_from_resource(base.Handle, intPtr, out zero);
			Marshaller.Free(intPtr);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x060004F2 RID: 1266 RVA: 0x0000D52C File Offset: 0x0000B72C
		public uint AddFromString(string buffer)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(buffer);
			IntPtr zero = IntPtr.Zero;
			uint result = Builder.gtk_builder_add_from_string(base.Handle, intPtr, new UIntPtr((ulong)((long)Encoding.UTF8.GetByteCount(buffer))), out zero);
			Marshaller.Free(intPtr);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x060004F3 RID: 1267 RVA: 0x0000D584 File Offset: 0x0000B784
		public uint AddObjectsFromFile(string filename, string object_ids)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(filename);
			IntPtr zero = IntPtr.Zero;
			uint result = Builder.gtk_builder_add_objects_from_file(base.Handle, intPtr, Marshaller.StringToPtrGStrdup(object_ids), out zero);
			Marshaller.Free(intPtr);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x060004F4 RID: 1268 RVA: 0x0000D5D4 File Offset: 0x0000B7D4
		public uint AddObjectsFromResource(string resource_path, string object_ids)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(resource_path);
			IntPtr zero = IntPtr.Zero;
			uint result = Builder.gtk_builder_add_objects_from_resource(base.Handle, intPtr, Marshaller.StringToPtrGStrdup(object_ids), out zero);
			Marshaller.Free(intPtr);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x060004F5 RID: 1269 RVA: 0x0000D624 File Offset: 0x0000B824
		public uint AddObjectsFromString(string buffer, string object_ids)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(buffer);
			IntPtr zero = IntPtr.Zero;
			uint result = Builder.gtk_builder_add_objects_from_string(base.Handle, intPtr, new UIntPtr((ulong)((long)Encoding.UTF8.GetByteCount(buffer))), Marshaller.StringToPtrGStrdup(object_ids), out zero);
			Marshaller.Free(intPtr);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x060004F6 RID: 1270 RVA: 0x0000D682 File Offset: 0x0000B882
		public static int ErrorQuark
		{
			get
			{
				return Builder.gtk_builder_error_quark();
			}
		}

		// Token: 0x060004F7 RID: 1271 RVA: 0x0000D690 File Offset: 0x0000B890
		public void ExposeObject(string name, Object objekt)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(name);
			Builder.gtk_builder_expose_object(base.Handle, intPtr, (objekt == null) ? IntPtr.Zero : objekt.Handle);
			Marshaller.Free(intPtr);
		}

		// Token: 0x060004F8 RID: 1272 RVA: 0x0000D6CC File Offset: 0x0000B8CC
		public uint ExtendWithTemplate(Widget widget, GType template_type, string buffer)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(buffer);
			IntPtr zero = IntPtr.Zero;
			uint result = Builder.gtk_builder_extend_with_template(base.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, template_type.Val, intPtr, new UIntPtr((ulong)((long)Encoding.UTF8.GetByteCount(buffer))), out zero);
			Marshaller.Free(intPtr);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x060004F9 RID: 1273 RVA: 0x0000D73B File Offset: 0x0000B93B
		// (set) Token: 0x060004FA RID: 1274 RVA: 0x0000D757 File Offset: 0x0000B957
		public Application Application
		{
			get
			{
				return Object.GetObject(Builder.gtk_builder_get_application(base.Handle)) as Application;
			}
			set
			{
				Builder.gtk_builder_set_application(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x060004FB RID: 1275 RVA: 0x0000D77C File Offset: 0x0000B97C
		public Object GetObject(string name)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(name);
			Object @object = Object.GetObject(Builder.gtk_builder_get_object(base.Handle, intPtr));
			Marshaller.Free(intPtr);
			return @object;
		}

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x060004FC RID: 1276 RVA: 0x0000D7AC File Offset: 0x0000B9AC
		public Object[] Objects
		{
			get
			{
				return (Object[])Marshaller.ListPtrToArray(Builder.gtk_builder_get_objects(base.Handle), typeof(SList), true, false, typeof(Object));
			}
		}

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x060004FD RID: 1277 RVA: 0x0000D7E0 File Offset: 0x0000B9E0
		public new static GType GType
		{
			get
			{
				IntPtr val = Builder.gtk_builder_get_type();
				return new GType(val);
			}
		}

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x060004FE RID: 1278 RVA: 0x0000D800 File Offset: 0x0000BA00
		public new static AbiStruct abi_info
		{
			get
			{
				if (Builder._abi_info == null)
				{
					Builder._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Object.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Builder._abi_info;
			}
		}

		// Token: 0x0400028E RID: 654
		private static Builder.d_g_object_ref g_object_ref = FuncLoader.LoadFunction<Builder.d_g_object_ref>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GObject), "g_object_ref"));

		// Token: 0x0400028F RID: 655
		private static Builder.d_gtk_builder_new gtk_builder_new = FuncLoader.LoadFunction<Builder.d_gtk_builder_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_builder_new"));

		// Token: 0x04000290 RID: 656
		private static Builder.d_gtk_builder_get_translation_domain gtk_builder_get_translation_domain = FuncLoader.LoadFunction<Builder.d_gtk_builder_get_translation_domain>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_builder_get_translation_domain"));

		// Token: 0x04000291 RID: 657
		private static Builder.d_gtk_builder_set_translation_domain gtk_builder_set_translation_domain = FuncLoader.LoadFunction<Builder.d_gtk_builder_set_translation_domain>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_builder_set_translation_domain"));

		// Token: 0x04000292 RID: 658
		private static Builder.GetTypeFromNameNativeDelegate GetTypeFromName_cb_delegate;

		// Token: 0x04000293 RID: 659
		private static AbiStruct _class_abi = null;

		// Token: 0x04000294 RID: 660
		private static Builder.d_gtk_builder_add_from_file gtk_builder_add_from_file = FuncLoader.LoadFunction<Builder.d_gtk_builder_add_from_file>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_builder_add_from_file"));

		// Token: 0x04000295 RID: 661
		private static Builder.d_gtk_builder_add_from_resource gtk_builder_add_from_resource = FuncLoader.LoadFunction<Builder.d_gtk_builder_add_from_resource>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_builder_add_from_resource"));

		// Token: 0x04000296 RID: 662
		private static Builder.d_gtk_builder_add_from_string gtk_builder_add_from_string = FuncLoader.LoadFunction<Builder.d_gtk_builder_add_from_string>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_builder_add_from_string"));

		// Token: 0x04000297 RID: 663
		private static Builder.d_gtk_builder_add_objects_from_file gtk_builder_add_objects_from_file = FuncLoader.LoadFunction<Builder.d_gtk_builder_add_objects_from_file>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_builder_add_objects_from_file"));

		// Token: 0x04000298 RID: 664
		private static Builder.d_gtk_builder_add_objects_from_resource gtk_builder_add_objects_from_resource = FuncLoader.LoadFunction<Builder.d_gtk_builder_add_objects_from_resource>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_builder_add_objects_from_resource"));

		// Token: 0x04000299 RID: 665
		private static Builder.d_gtk_builder_add_objects_from_string gtk_builder_add_objects_from_string = FuncLoader.LoadFunction<Builder.d_gtk_builder_add_objects_from_string>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_builder_add_objects_from_string"));

		// Token: 0x0400029A RID: 666
		private static Builder.d_gtk_builder_error_quark gtk_builder_error_quark = FuncLoader.LoadFunction<Builder.d_gtk_builder_error_quark>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_builder_error_quark"));

		// Token: 0x0400029B RID: 667
		private static Builder.d_gtk_builder_expose_object gtk_builder_expose_object = FuncLoader.LoadFunction<Builder.d_gtk_builder_expose_object>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_builder_expose_object"));

		// Token: 0x0400029C RID: 668
		private static Builder.d_gtk_builder_extend_with_template gtk_builder_extend_with_template = FuncLoader.LoadFunction<Builder.d_gtk_builder_extend_with_template>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_builder_extend_with_template"));

		// Token: 0x0400029D RID: 669
		private static Builder.d_gtk_builder_get_application gtk_builder_get_application = FuncLoader.LoadFunction<Builder.d_gtk_builder_get_application>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_builder_get_application"));

		// Token: 0x0400029E RID: 670
		private static Builder.d_gtk_builder_set_application gtk_builder_set_application = FuncLoader.LoadFunction<Builder.d_gtk_builder_set_application>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_builder_set_application"));

		// Token: 0x0400029F RID: 671
		private static Builder.d_gtk_builder_get_object gtk_builder_get_object = FuncLoader.LoadFunction<Builder.d_gtk_builder_get_object>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_builder_get_object"));

		// Token: 0x040002A0 RID: 672
		private static Builder.d_gtk_builder_get_objects gtk_builder_get_objects = FuncLoader.LoadFunction<Builder.d_gtk_builder_get_objects>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_builder_get_objects"));

		// Token: 0x040002A1 RID: 673
		private static Builder.d_gtk_builder_get_type gtk_builder_get_type = FuncLoader.LoadFunction<Builder.d_gtk_builder_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_builder_get_type"));

		// Token: 0x040002A2 RID: 674
		private static AbiStruct _abi_info = null;

		// Token: 0x020006C7 RID: 1735
		[Serializable]
		public class HandlerNotFoundException : SystemException
		{
			// Token: 0x06004234 RID: 16948 RVA: 0x000B5E41 File Offset: 0x000B4041
			public HandlerNotFoundException(string handler_name, string signal_name, EventInfo evnt, Type delegate_type) : this(handler_name, signal_name, evnt, delegate_type, null)
			{
			}

			// Token: 0x06004235 RID: 16949 RVA: 0x000B5E4F File Offset: 0x000B404F
			public HandlerNotFoundException(string handler_name, string signal_name, EventInfo evnt, Type delegate_type, Exception inner) : base("No handler " + handler_name + " found for signal " + signal_name, inner)
			{
				this.handler_name = handler_name;
				this.signal_name = signal_name;
				this.evnt = evnt;
				this.delegate_type = delegate_type;
			}

			// Token: 0x06004236 RID: 16950 RVA: 0x000B5E87 File Offset: 0x000B4087
			public HandlerNotFoundException(string message, string handler_name, string signal_name, EventInfo evnt, Type delegate_type) : base((message != null) ? message : ("No handler " + handler_name + " found for signal " + signal_name), null)
			{
				this.handler_name = handler_name;
				this.signal_name = signal_name;
				this.evnt = evnt;
				this.delegate_type = delegate_type;
			}

			// Token: 0x06004237 RID: 16951 RVA: 0x000B5EC8 File Offset: 0x000B40C8
			protected HandlerNotFoundException(SerializationInfo info, StreamingContext context) : base(info, context)
			{
				this.handler_name = info.GetString("HandlerName");
				this.signal_name = info.GetString("SignalName");
				this.evnt = (info.GetValue("Event", typeof(EventInfo)) as EventInfo);
				this.delegate_type = (info.GetValue("DelegateType", typeof(Type)) as Type);
			}

			// Token: 0x17001197 RID: 4503
			// (get) Token: 0x06004238 RID: 16952 RVA: 0x000B5F3F File Offset: 0x000B413F
			public string HandlerName
			{
				get
				{
					return this.handler_name;
				}
			}

			// Token: 0x17001198 RID: 4504
			// (get) Token: 0x06004239 RID: 16953 RVA: 0x000B5F47 File Offset: 0x000B4147
			public string SignalName
			{
				get
				{
					return this.signal_name;
				}
			}

			// Token: 0x17001199 RID: 4505
			// (get) Token: 0x0600423A RID: 16954 RVA: 0x000B5F4F File Offset: 0x000B414F
			public EventInfo Event
			{
				get
				{
					return this.evnt;
				}
			}

			// Token: 0x1700119A RID: 4506
			// (get) Token: 0x0600423B RID: 16955 RVA: 0x000B5F57 File Offset: 0x000B4157
			public Type DelegateType
			{
				get
				{
					return this.delegate_type;
				}
			}

			// Token: 0x0600423C RID: 16956 RVA: 0x000B5F60 File Offset: 0x000B4160
			public override void GetObjectData(SerializationInfo info, StreamingContext context)
			{
				base.GetObjectData(info, context);
				info.AddValue("HandlerName", this.handler_name);
				info.AddValue("SignalName", this.signal_name);
				info.AddValue("Event", this.evnt);
				info.AddValue("DelegateType", this.delegate_type);
			}

			// Token: 0x04001E35 RID: 7733
			private string handler_name;

			// Token: 0x04001E36 RID: 7734
			private string signal_name;

			// Token: 0x04001E37 RID: 7735
			private EventInfo evnt;

			// Token: 0x04001E38 RID: 7736
			private Type delegate_type;
		}

		// Token: 0x020006C8 RID: 1736
		[AttributeUsage(AttributeTargets.Field)]
		public class ObjectAttribute : Attribute
		{
			// Token: 0x0600423D RID: 16957 RVA: 0x000B5FB9 File Offset: 0x000B41B9
			public ObjectAttribute(string name)
			{
				this.specified = true;
				this.name = name;
			}

			// Token: 0x0600423E RID: 16958 RVA: 0x000B5FCF File Offset: 0x000B41CF
			public ObjectAttribute()
			{
				this.specified = false;
			}

			// Token: 0x1700119B RID: 4507
			// (get) Token: 0x0600423F RID: 16959 RVA: 0x000B5FDE File Offset: 0x000B41DE
			public string Name
			{
				get
				{
					return this.name;
				}
			}

			// Token: 0x1700119C RID: 4508
			// (get) Token: 0x06004240 RID: 16960 RVA: 0x000B5FE6 File Offset: 0x000B41E6
			public bool Specified
			{
				get
				{
					return this.specified;
				}
			}

			// Token: 0x04001E39 RID: 7737
			private string name;

			// Token: 0x04001E3A RID: 7738
			private bool specified;
		}

		// Token: 0x020006C9 RID: 1737
		// (Invoke) Token: 0x06004242 RID: 16962
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_g_object_ref(IntPtr raw);

		// Token: 0x020006CA RID: 1738
		private class SignalConnector
		{
			// Token: 0x06004245 RID: 16965 RVA: 0x000B5FEE File Offset: 0x000B41EE
			public SignalConnector(Builder builder, object handler)
			{
				this.builder = builder;
				this.handler = handler;
				this.handler_type = handler.GetType();
			}

			// Token: 0x06004246 RID: 16966 RVA: 0x000B6010 File Offset: 0x000B4210
			public SignalConnector(Builder builder, Type handler_type)
			{
				this.builder = builder;
				this.handler = null;
				this.handler_type = handler_type;
			}

			// Token: 0x06004247 RID: 16967 RVA: 0x000B6030 File Offset: 0x000B4230
			public void ConnectSignals()
			{
				BuilderConnectFuncWrapper builderConnectFuncWrapper = new BuilderConnectFuncWrapper(new BuilderConnectFunc(this.ConnectFunc));
				Builder.SignalConnector.gtk_builder_connect_signals_full(this.builder.Handle, builderConnectFuncWrapper.NativeDelegate, IntPtr.Zero);
			}

			// Token: 0x06004248 RID: 16968 RVA: 0x000B6070 File Offset: 0x000B4270
			public void ConnectFunc(Builder builder, Object objekt, string signal_name, string handler_name, Object connect_object, ConnectFlags flags)
			{
				foreach (EventInfo eventInfo in objekt.GetType().FindMembers(MemberTypes.Event, BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic, new MemberFilter(Builder.SignalConnector.SignalFilter), signal_name))
				{
					bool flag = false;
					MethodInfo addMethod = eventInfo.GetAddMethod();
					ParameterInfo[] parameters = addMethod.GetParameters();
					if (parameters.Length == 1)
					{
						Type parameterType = parameters[0].ParameterType;
						if (connect_object != null || this.handler != null)
						{
							try
							{
								Delegate @delegate = Delegate.CreateDelegate(parameterType, (connect_object != null) ? connect_object : this.handler, handler_name);
								addMethod.Invoke(objekt, new object[]
								{
									@delegate
								});
								flag = true;
							}
							catch (ArgumentException)
							{
							}
						}
						if (!flag && this.handler_type != null)
						{
							try
							{
								Delegate delegate2 = Delegate.CreateDelegate(parameterType, this.handler_type, handler_name);
								addMethod.Invoke(objekt, new object[]
								{
									delegate2
								});
								flag = true;
							}
							catch (ArgumentException)
							{
							}
						}
						if (!flag)
						{
							throw new Builder.HandlerNotFoundException(Builder.SignalConnector.ExplainError(eventInfo.Name, parameterType, this.handler_type, handler_name), handler_name, signal_name, eventInfo, parameterType);
						}
					}
				}
			}

			// Token: 0x06004249 RID: 16969 RVA: 0x000B619C File Offset: 0x000B439C
			private static bool SignalFilter(MemberInfo m, object filterCriteria)
			{
				string text = filterCriteria as string;
				object[] customAttributes = m.GetCustomAttributes(typeof(SignalAttribute), false);
				if (customAttributes.Length != 0)
				{
					foreach (SignalAttribute signalAttribute in customAttributes)
					{
						if (text == signalAttribute.CName)
						{
							return true;
						}
					}
					return false;
				}
				text = text.ToLower().Replace("_", "");
				string b = m.Name.ToLower();
				return text == b;
			}

			// Token: 0x0600424A RID: 16970 RVA: 0x000B6220 File Offset: 0x000B4420
			private static string GetSignature(MethodInfo method)
			{
				if (method == null)
				{
					return null;
				}
				ParameterInfo[] parameters = method.GetParameters();
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append('(');
				foreach (ParameterInfo parameterInfo in parameters)
				{
					stringBuilder.Append(parameterInfo.ParameterType.ToString());
					stringBuilder.Append(',');
				}
				if (stringBuilder.Length != 0)
				{
					StringBuilder stringBuilder2 = stringBuilder;
					int i = stringBuilder2.Length;
					stringBuilder2.Length = i - 1;
				}
				stringBuilder.Append(')');
				return stringBuilder.ToString();
			}

			// Token: 0x0600424B RID: 16971 RVA: 0x000B62A2 File Offset: 0x000B44A2
			private static string GetSignature(Type delegate_type)
			{
				return Builder.SignalConnector.GetSignature(delegate_type.GetMethod("Invoke"));
			}

			// Token: 0x0600424C RID: 16972 RVA: 0x000B62B4 File Offset: 0x000B44B4
			private static string GetSignature(Type klass, string method_name)
			{
				string result;
				try
				{
					result = Builder.SignalConnector.GetSignature(klass.GetMethod(method_name, BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic));
				}
				catch
				{
					result = null;
				}
				return result;
			}

			// Token: 0x0600424D RID: 16973 RVA: 0x000B62E8 File Offset: 0x000B44E8
			private static string ExplainError(string event_name, Type deleg, Type klass, string method)
			{
				if (deleg == null || klass == null || method == null)
				{
					return null;
				}
				StringBuilder stringBuilder = new StringBuilder();
				string signature = Builder.SignalConnector.GetSignature(deleg);
				string signature2 = Builder.SignalConnector.GetSignature(klass, method);
				if (signature2 == null)
				{
					return null;
				}
				stringBuilder.AppendFormat("The handler for the event {0} should take '{1}', but the signature of the provided handler ('{2}') is '{3}'\n", new object[]
				{
					event_name,
					signature,
					method,
					signature2
				});
				return stringBuilder.ToString();
			}

			// Token: 0x04001E3B RID: 7739
			private Builder builder;

			// Token: 0x04001E3C RID: 7740
			private Type handler_type;

			// Token: 0x04001E3D RID: 7741
			private object handler;

			// Token: 0x04001E3E RID: 7742
			private static Builder.SignalConnector.d_gtk_builder_connect_signals_full gtk_builder_connect_signals_full = FuncLoader.LoadFunction<Builder.SignalConnector.d_gtk_builder_connect_signals_full>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_builder_connect_signals_full"));

			// Token: 0x04001E3F RID: 7743
			private const BindingFlags flags = BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;

			// Token: 0x02001CF2 RID: 7410
			// (Invoke) Token: 0x06009A3C RID: 39484
			[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
			private delegate void d_gtk_builder_connect_signals_full(IntPtr raw, BuilderConnectFuncNative func, IntPtr user_data);
		}

		// Token: 0x020006CB RID: 1739
		// (Invoke) Token: 0x06004250 RID: 16976
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_builder_new();

		// Token: 0x020006CC RID: 1740
		// (Invoke) Token: 0x06004254 RID: 16980
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_builder_get_translation_domain(IntPtr raw);

		// Token: 0x020006CD RID: 1741
		// (Invoke) Token: 0x06004258 RID: 16984
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_builder_set_translation_domain(IntPtr raw, IntPtr domain);

		// Token: 0x020006CE RID: 1742
		// (Invoke) Token: 0x0600425C RID: 16988
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetTypeFromNameNativeDelegate(IntPtr inst, IntPtr type_name);

		// Token: 0x020006CF RID: 1743
		// (Invoke) Token: 0x06004260 RID: 16992
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gtk_builder_add_from_file(IntPtr raw, IntPtr filename, out IntPtr error);

		// Token: 0x020006D0 RID: 1744
		// (Invoke) Token: 0x06004264 RID: 16996
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gtk_builder_add_from_resource(IntPtr raw, IntPtr resource_path, out IntPtr error);

		// Token: 0x020006D1 RID: 1745
		// (Invoke) Token: 0x06004268 RID: 17000
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gtk_builder_add_from_string(IntPtr raw, IntPtr buffer, UIntPtr length, out IntPtr error);

		// Token: 0x020006D2 RID: 1746
		// (Invoke) Token: 0x0600426C RID: 17004
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gtk_builder_add_objects_from_file(IntPtr raw, IntPtr filename, IntPtr object_ids, out IntPtr error);

		// Token: 0x020006D3 RID: 1747
		// (Invoke) Token: 0x06004270 RID: 17008
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gtk_builder_add_objects_from_resource(IntPtr raw, IntPtr resource_path, IntPtr object_ids, out IntPtr error);

		// Token: 0x020006D4 RID: 1748
		// (Invoke) Token: 0x06004274 RID: 17012
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gtk_builder_add_objects_from_string(IntPtr raw, IntPtr buffer, UIntPtr length, IntPtr object_ids, out IntPtr error);

		// Token: 0x020006D5 RID: 1749
		// (Invoke) Token: 0x06004278 RID: 17016
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_builder_error_quark();

		// Token: 0x020006D6 RID: 1750
		// (Invoke) Token: 0x0600427C RID: 17020
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_builder_expose_object(IntPtr raw, IntPtr name, IntPtr objekt);

		// Token: 0x020006D7 RID: 1751
		// (Invoke) Token: 0x06004280 RID: 17024
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gtk_builder_extend_with_template(IntPtr raw, IntPtr widget, IntPtr template_type, IntPtr buffer, UIntPtr length, out IntPtr error);

		// Token: 0x020006D8 RID: 1752
		// (Invoke) Token: 0x06004284 RID: 17028
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_builder_get_application(IntPtr raw);

		// Token: 0x020006D9 RID: 1753
		// (Invoke) Token: 0x06004288 RID: 17032
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_builder_set_application(IntPtr raw, IntPtr application);

		// Token: 0x020006DA RID: 1754
		// (Invoke) Token: 0x0600428C RID: 17036
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_builder_get_object(IntPtr raw, IntPtr name);

		// Token: 0x020006DB RID: 1755
		// (Invoke) Token: 0x06004290 RID: 17040
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_builder_get_objects(IntPtr raw);

		// Token: 0x020006DC RID: 1756
		// (Invoke) Token: 0x06004294 RID: 17044
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_builder_get_type();
	}
}
