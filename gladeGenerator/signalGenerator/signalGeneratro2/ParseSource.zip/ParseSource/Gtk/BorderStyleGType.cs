﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x02000147 RID: 327
	internal class BorderStyleGType
	{
		// Token: 0x17000308 RID: 776
		// (get) Token: 0x06000E02 RID: 3586 RVA: 0x0002A27E File Offset: 0x0002847E
		public static GType GType
		{
			get
			{
				return new GType(BorderStyleGType.gtk_border_style_get_type());
			}
		}

		// Token: 0x040006E0 RID: 1760
		private static BorderStyleGType.d_gtk_border_style_get_type gtk_border_style_get_type = FuncLoader.LoadFunction<BorderStyleGType.d_gtk_border_style_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_border_style_get_type"));

		// Token: 0x02000AA0 RID: 2720
		// (Invoke) Token: 0x06005190 RID: 20880
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_border_style_get_type();
	}
}
