﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x02000176 RID: 374
	public class CellRendererProgress : CellRenderer, IOrientable, IWrapper
	{
		// Token: 0x06000FBC RID: 4028 RVA: 0x0002F98B File Offset: 0x0002DB8B
		public CellRendererProgress(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000FBD RID: 4029 RVA: 0x0002F994 File Offset: 0x0002DB94
		public CellRendererProgress() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(CellRendererProgress))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = CellRendererProgress.gtk_cell_renderer_progress_new();
		}

		// Token: 0x1700037C RID: 892
		// (get) Token: 0x06000FBE RID: 4030 RVA: 0x0002F9E8 File Offset: 0x0002DBE8
		// (set) Token: 0x06000FBF RID: 4031 RVA: 0x0002FA10 File Offset: 0x0002DC10
		[Property("value")]
		public int Value
		{
			get
			{
				Value property = base.GetProperty("value");
				int result = (int)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("value", val);
				val.Dispose();
			}
		}

		// Token: 0x1700037D RID: 893
		// (get) Token: 0x06000FC0 RID: 4032 RVA: 0x0002FA38 File Offset: 0x0002DC38
		// (set) Token: 0x06000FC1 RID: 4033 RVA: 0x0002FA60 File Offset: 0x0002DC60
		[Property("text")]
		public string Text
		{
			get
			{
				Value property = base.GetProperty("text");
				string result = (string)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("text", val);
				val.Dispose();
			}
		}

		// Token: 0x1700037E RID: 894
		// (get) Token: 0x06000FC2 RID: 4034 RVA: 0x0002FA88 File Offset: 0x0002DC88
		// (set) Token: 0x06000FC3 RID: 4035 RVA: 0x0002FAB0 File Offset: 0x0002DCB0
		[Property("pulse")]
		public int Pulse
		{
			get
			{
				Value property = base.GetProperty("pulse");
				int result = (int)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("pulse", val);
				val.Dispose();
			}
		}

		// Token: 0x1700037F RID: 895
		// (get) Token: 0x06000FC4 RID: 4036 RVA: 0x0002FAD8 File Offset: 0x0002DCD8
		// (set) Token: 0x06000FC5 RID: 4037 RVA: 0x0002FB00 File Offset: 0x0002DD00
		[Property("text-xalign")]
		public float TextXAlign
		{
			get
			{
				Value property = base.GetProperty("text-xalign");
				float result = (float)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("text-xalign", val);
				val.Dispose();
			}
		}

		// Token: 0x17000380 RID: 896
		// (get) Token: 0x06000FC6 RID: 4038 RVA: 0x0002FB28 File Offset: 0x0002DD28
		// (set) Token: 0x06000FC7 RID: 4039 RVA: 0x0002FB50 File Offset: 0x0002DD50
		[Property("text-yalign")]
		public float TextYAlign
		{
			get
			{
				Value property = base.GetProperty("text-yalign");
				float result = (float)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("text-yalign", val);
				val.Dispose();
			}
		}

		// Token: 0x17000381 RID: 897
		// (get) Token: 0x06000FC8 RID: 4040 RVA: 0x0002FB78 File Offset: 0x0002DD78
		// (set) Token: 0x06000FC9 RID: 4041 RVA: 0x0002FBA0 File Offset: 0x0002DDA0
		[Property("inverted")]
		public bool Inverted
		{
			get
			{
				Value property = base.GetProperty("inverted");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("inverted", val);
				val.Dispose();
			}
		}

		// Token: 0x17000382 RID: 898
		// (get) Token: 0x06000FCA RID: 4042 RVA: 0x0002FBC8 File Offset: 0x0002DDC8
		public new static AbiStruct class_abi
		{
			get
			{
				if (CellRendererProgress._class_abi == null)
				{
					CellRendererProgress._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("_gtk_reserved1", CellRenderer.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellRendererProgress._class_abi;
			}
		}

		// Token: 0x17000383 RID: 899
		// (get) Token: 0x06000FCB RID: 4043 RVA: 0x0002FCE4 File Offset: 0x0002DEE4
		public new static GType GType
		{
			get
			{
				IntPtr val = CellRendererProgress.gtk_cell_renderer_progress_get_type();
				return new GType(val);
			}
		}

		// Token: 0x17000384 RID: 900
		// (get) Token: 0x06000FCC RID: 4044 RVA: 0x0002FD02 File Offset: 0x0002DF02
		// (set) Token: 0x06000FCD RID: 4045 RVA: 0x0002FD14 File Offset: 0x0002DF14
		[Property("orientation")]
		public Orientation Orientation
		{
			get
			{
				return (Orientation)CellRendererProgress.gtk_orientable_get_orientation(base.Handle);
			}
			set
			{
				CellRendererProgress.gtk_orientable_set_orientation(base.Handle, (int)value);
			}
		}

		// Token: 0x17000385 RID: 901
		// (get) Token: 0x06000FCE RID: 4046 RVA: 0x0002FD28 File Offset: 0x0002DF28
		public new static AbiStruct abi_info
		{
			get
			{
				if (CellRendererProgress._abi_info == null)
				{
					CellRendererProgress._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", CellRenderer.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellRendererProgress._abi_info;
			}
		}

		// Token: 0x040007A5 RID: 1957
		private static CellRendererProgress.d_gtk_cell_renderer_progress_new gtk_cell_renderer_progress_new = FuncLoader.LoadFunction<CellRendererProgress.d_gtk_cell_renderer_progress_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_progress_new"));

		// Token: 0x040007A6 RID: 1958
		private static AbiStruct _class_abi = null;

		// Token: 0x040007A7 RID: 1959
		private static CellRendererProgress.d_gtk_cell_renderer_progress_get_type gtk_cell_renderer_progress_get_type = FuncLoader.LoadFunction<CellRendererProgress.d_gtk_cell_renderer_progress_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_progress_get_type"));

		// Token: 0x040007A8 RID: 1960
		private static CellRendererProgress.d_gtk_orientable_get_orientation gtk_orientable_get_orientation = FuncLoader.LoadFunction<CellRendererProgress.d_gtk_orientable_get_orientation>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_orientable_get_orientation"));

		// Token: 0x040007A9 RID: 1961
		private static CellRendererProgress.d_gtk_orientable_set_orientation gtk_orientable_set_orientation = FuncLoader.LoadFunction<CellRendererProgress.d_gtk_orientable_set_orientation>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_orientable_set_orientation"));

		// Token: 0x040007AA RID: 1962
		private static AbiStruct _abi_info = null;

		// Token: 0x02000B1F RID: 2847
		// (Invoke) Token: 0x06005389 RID: 21385
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_renderer_progress_new();

		// Token: 0x02000B20 RID: 2848
		// (Invoke) Token: 0x0600538D RID: 21389
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_renderer_progress_get_type();

		// Token: 0x02000B21 RID: 2849
		// (Invoke) Token: 0x06005391 RID: 21393
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_orientable_get_orientation(IntPtr raw);

		// Token: 0x02000B22 RID: 2850
		// (Invoke) Token: 0x06005395 RID: 21397
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_orientable_set_orientation(IntPtr raw, int orientation);
	}
}
