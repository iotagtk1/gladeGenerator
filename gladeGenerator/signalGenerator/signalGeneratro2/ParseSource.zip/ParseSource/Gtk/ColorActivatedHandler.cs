﻿using System;

namespace Gtk
{
	// Token: 0x02000197 RID: 407
	// (Invoke) Token: 0x060010B1 RID: 4273
	public delegate void ColorActivatedHandler(object o, ColorActivatedArgs args);
}
