﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001BD RID: 445
	public class CssAnimatedStyle : Opaque
	{
		// Token: 0x06001175 RID: 4469 RVA: 0x00033C33 File Offset: 0x00031E33
		public CssAnimatedStyle(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700040E RID: 1038
		// (get) Token: 0x06001176 RID: 4470 RVA: 0x00033C3C File Offset: 0x00031E3C
		public static AbiStruct abi_info
		{
			get
			{
				if (CssAnimatedStyle._abi_info == null)
				{
					CssAnimatedStyle._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssAnimatedStyle._abi_info;
			}
		}

		// Token: 0x0400081D RID: 2077
		private static AbiStruct _abi_info;
	}
}
