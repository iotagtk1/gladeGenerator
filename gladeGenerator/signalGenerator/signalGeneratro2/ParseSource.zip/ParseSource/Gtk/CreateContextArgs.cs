﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x020001B6 RID: 438
	public class CreateContextArgs : SignalArgs
	{
	}
}
