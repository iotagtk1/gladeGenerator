﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x0200012D RID: 301
	internal class ArrowPlacementGType
	{
		// Token: 0x170002E0 RID: 736
		// (get) Token: 0x06000D5C RID: 3420 RVA: 0x0002888B File Offset: 0x00026A8B
		public static GType GType
		{
			get
			{
				return new GType(ArrowPlacementGType.gtk_arrow_placement_get_type());
			}
		}

		// Token: 0x0400067D RID: 1661
		private static ArrowPlacementGType.d_gtk_arrow_placement_get_type gtk_arrow_placement_get_type = FuncLoader.LoadFunction<ArrowPlacementGType.d_gtk_arrow_placement_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_arrow_placement_get_type"));

		// Token: 0x02000A72 RID: 2674
		// (Invoke) Token: 0x060050CF RID: 20687
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_arrow_placement_get_type();
	}
}
