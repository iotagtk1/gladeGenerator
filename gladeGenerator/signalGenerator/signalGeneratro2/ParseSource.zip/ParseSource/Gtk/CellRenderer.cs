﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Cairo;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x020000DD RID: 221
	public class CellRenderer : InitiallyUnowned
	{
		// Token: 0x06000606 RID: 1542 RVA: 0x00010EAC File Offset: 0x0000F0AC
		public ICellEditable StartEditing(Widget widget, Event evnt, string path, Gdk.Rectangle background_area, Gdk.Rectangle cell_area, CellRendererState flags)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(path);
			IntPtr o = CellRenderer.gtk_cell_renderer_start_editing(base.Handle, (evnt != null) ? evnt.Handle : IntPtr.Zero, widget.Handle, intPtr, ref background_area, ref cell_area, (int)flags);
			Marshaller.Free(intPtr);
			return (ICellEditable)Object.GetObject(o);
		}

		// Token: 0x06000607 RID: 1543 RVA: 0x00010EFD File Offset: 0x0000F0FD
		public void Render(Context context, Widget widget, Gdk.Rectangle background_area, Gdk.Rectangle cell_area, Gdk.Rectangle expose_area, CellRendererState flags)
		{
			CellRenderer.gtk_cell_renderer_render2(base.Handle, (context == null) ? IntPtr.Zero : context.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, ref background_area, ref cell_area, ref expose_area, (int)flags);
		}

		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x06000608 RID: 1544 RVA: 0x00010F37 File Offset: 0x0000F137
		private static CellRenderer.GetSizeNativeDelegate GetSizeVMCallback
		{
			get
			{
				if (CellRenderer.GetSize_cb_delegate == null)
				{
					CellRenderer.GetSize_cb_delegate = new CellRenderer.GetSizeNativeDelegate(CellRenderer.GetSize_cb);
				}
				return CellRenderer.GetSize_cb_delegate;
			}
		}

		// Token: 0x06000609 RID: 1545 RVA: 0x00010F56 File Offset: 0x0000F156
		private static void OverrideGetSize(GType gtype)
		{
			CellRenderer.OverrideGetSize(gtype, CellRenderer.GetSizeVMCallback);
		}

		// Token: 0x0600060A RID: 1546 RVA: 0x00010F64 File Offset: 0x0000F164
		private unsafe static void OverrideGetSize(GType gtype, CellRenderer.GetSizeNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellRenderer.class_abi.GetFieldOffset("get_size");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600060B RID: 1547 RVA: 0x00010F98 File Offset: 0x0000F198
		private static void GetSize_cb(IntPtr item, IntPtr widget, IntPtr cell_area_ptr, IntPtr x_offset, IntPtr y_offset, IntPtr width, IntPtr height)
		{
			try
			{
				CellRenderer cellRenderer = Object.GetObject(item, false) as CellRenderer;
				Widget widget2 = Object.GetObject(widget, false) as Widget;
				Gdk.Rectangle rectangle = Gdk.Rectangle.Zero;
				if (cell_area_ptr != IntPtr.Zero)
				{
					rectangle = Gdk.Rectangle.New(cell_area_ptr);
				}
				int val;
				int val2;
				int val3;
				int val4;
				cellRenderer.OnGetSize(widget2, ref rectangle, out val, out val2, out val3, out val4);
				if (x_offset != IntPtr.Zero)
				{
					Marshal.WriteInt32(x_offset, val);
				}
				if (y_offset != IntPtr.Zero)
				{
					Marshal.WriteInt32(y_offset, val2);
				}
				if (width != IntPtr.Zero)
				{
					Marshal.WriteInt32(width, val3);
				}
				if (height != IntPtr.Zero)
				{
					Marshal.WriteInt32(height, val4);
				}
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x0600060C RID: 1548 RVA: 0x0001105C File Offset: 0x0000F25C
		[DefaultSignalHandler(Type = typeof(CellRenderer), ConnectionMethod = "OverrideGetSize")]
		protected virtual void OnGetSize(Widget widget, ref Gdk.Rectangle cell_area, out int x_offset, out int y_offset, out int width, out int height)
		{
			this.InternalOnGetSize(widget, ref cell_area, out x_offset, out y_offset, out width, out height);
		}

		// Token: 0x0600060D RID: 1549 RVA: 0x00011070 File Offset: 0x0000F270
		private void InternalOnGetSize(Widget widget, ref Gdk.Rectangle cell_area, out int x_offset, out int y_offset, out int width, out int height)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(cell_area);
			CellRenderer.gtksharp_cellrenderer_base_get_size(base.Handle, (widget != null) ? widget.Handle : IntPtr.Zero, intPtr, out x_offset, out y_offset, out width, out height);
			cell_area = Gdk.Rectangle.New(intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x0600060E RID: 1550 RVA: 0x000110C4 File Offset: 0x0000F2C4
		private unsafe static CellRenderer.GetSizeNativeDelegate InternalGetSizeNativeDelegate(GType gtype)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellRenderer.class_abi.GetFieldOffset("get_size");
			if (*ptr == IntPtr.Zero)
			{
				return null;
			}
			return Marshal.GetDelegateForFunctionPointer<CellRenderer.GetSizeNativeDelegate>(*ptr);
		}

		// Token: 0x0600060F RID: 1551 RVA: 0x00011108 File Offset: 0x0000F308
		private static void gtksharp_cellrenderer_base_get_size(IntPtr cell, IntPtr widget, IntPtr cell_area, out int x_offset, out int y_offset, out int width, out int height)
		{
			x_offset = 0;
			y_offset = 0;
			width = 0;
			height = 0;
			if (cell == IntPtr.Zero)
			{
				return;
			}
			Object @object = Object.TryGetObject(cell);
			if (@object == null)
			{
				return;
			}
			GType gtype = @object.NativeType;
			while ((gtype = gtype.GetBaseType()) != GType.None)
			{
				if (!gtype.ToString().StartsWith("__gtksharp_"))
				{
					CellRenderer.GetSizeNativeDelegate getSizeNativeDelegate = CellRenderer.InternalGetSizeNativeDelegate(gtype);
					if (getSizeNativeDelegate != null)
					{
						IntPtr intPtr = Marshal.AllocHGlobal(4);
						IntPtr intPtr2 = Marshal.AllocHGlobal(4);
						IntPtr intPtr3 = Marshal.AllocHGlobal(4);
						IntPtr intPtr4 = Marshal.AllocHGlobal(4);
						try
						{
							getSizeNativeDelegate(cell, widget, cell_area, intPtr, intPtr2, intPtr3, intPtr4);
							if (intPtr != IntPtr.Zero)
							{
								Marshal.WriteInt32(intPtr, x_offset);
							}
							if (intPtr2 != IntPtr.Zero)
							{
								Marshal.WriteInt32(intPtr2, y_offset);
							}
							if (intPtr3 != IntPtr.Zero)
							{
								Marshal.WriteInt32(intPtr3, width);
							}
							if (intPtr4 != IntPtr.Zero)
							{
								Marshal.WriteInt32(intPtr4, height);
							}
						}
						finally
						{
							Marshal.FreeHGlobal(intPtr);
							Marshal.FreeHGlobal(intPtr2);
							Marshal.FreeHGlobal(intPtr3);
							Marshal.FreeHGlobal(intPtr4);
						}
					}
					return;
				}
			}
		}

		// Token: 0x06000610 RID: 1552 RVA: 0x00011248 File Offset: 0x0000F448
		public CellRenderer(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000611 RID: 1553 RVA: 0x00011251 File Offset: 0x0000F451
		protected CellRenderer() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x06000612 RID: 1554 RVA: 0x00011270 File Offset: 0x0000F470
		// (set) Token: 0x06000613 RID: 1555 RVA: 0x0001129C File Offset: 0x0000F49C
		[Property("mode")]
		public CellRendererMode Mode
		{
			get
			{
				Value property = base.GetProperty("mode");
				CellRendererMode result = (CellRendererMode)((Enum)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("mode", val);
				val.Dispose();
			}
		}

		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x06000614 RID: 1556 RVA: 0x000112C9 File Offset: 0x0000F4C9
		// (set) Token: 0x06000615 RID: 1557 RVA: 0x000112DB File Offset: 0x0000F4DB
		[Property("visible")]
		public bool Visible
		{
			get
			{
				return CellRenderer.gtk_cell_renderer_get_visible(base.Handle);
			}
			set
			{
				CellRenderer.gtk_cell_renderer_set_visible(base.Handle, value);
			}
		}

		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x06000616 RID: 1558 RVA: 0x000112EE File Offset: 0x0000F4EE
		// (set) Token: 0x06000617 RID: 1559 RVA: 0x00011300 File Offset: 0x0000F500
		[Property("sensitive")]
		public bool Sensitive
		{
			get
			{
				return CellRenderer.gtk_cell_renderer_get_sensitive(base.Handle);
			}
			set
			{
				CellRenderer.gtk_cell_renderer_set_sensitive(base.Handle, value);
			}
		}

		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x06000618 RID: 1560 RVA: 0x00011314 File Offset: 0x0000F514
		// (set) Token: 0x06000619 RID: 1561 RVA: 0x0001133C File Offset: 0x0000F53C
		[Property("xalign")]
		public float Xalign
		{
			get
			{
				Value property = base.GetProperty("xalign");
				float result = (float)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("xalign", val);
				val.Dispose();
			}
		}

		// Token: 0x170000E9 RID: 233
		// (get) Token: 0x0600061A RID: 1562 RVA: 0x00011364 File Offset: 0x0000F564
		// (set) Token: 0x0600061B RID: 1563 RVA: 0x0001138C File Offset: 0x0000F58C
		[Property("yalign")]
		public float Yalign
		{
			get
			{
				Value property = base.GetProperty("yalign");
				float result = (float)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("yalign", val);
				val.Dispose();
			}
		}

		// Token: 0x170000EA RID: 234
		// (get) Token: 0x0600061C RID: 1564 RVA: 0x000113B4 File Offset: 0x0000F5B4
		// (set) Token: 0x0600061D RID: 1565 RVA: 0x000113DC File Offset: 0x0000F5DC
		[Property("xpad")]
		public uint Xpad
		{
			get
			{
				Value property = base.GetProperty("xpad");
				uint result = (uint)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("xpad", val);
				val.Dispose();
			}
		}

		// Token: 0x170000EB RID: 235
		// (get) Token: 0x0600061E RID: 1566 RVA: 0x00011404 File Offset: 0x0000F604
		// (set) Token: 0x0600061F RID: 1567 RVA: 0x0001142C File Offset: 0x0000F62C
		[Property("ypad")]
		public uint Ypad
		{
			get
			{
				Value property = base.GetProperty("ypad");
				uint result = (uint)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("ypad", val);
				val.Dispose();
			}
		}

		// Token: 0x170000EC RID: 236
		// (get) Token: 0x06000620 RID: 1568 RVA: 0x00011454 File Offset: 0x0000F654
		// (set) Token: 0x06000621 RID: 1569 RVA: 0x0001147C File Offset: 0x0000F67C
		[Property("width")]
		public int Width
		{
			get
			{
				Value property = base.GetProperty("width");
				int result = (int)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("width", val);
				val.Dispose();
			}
		}

		// Token: 0x170000ED RID: 237
		// (get) Token: 0x06000622 RID: 1570 RVA: 0x000114A4 File Offset: 0x0000F6A4
		// (set) Token: 0x06000623 RID: 1571 RVA: 0x000114CC File Offset: 0x0000F6CC
		[Property("height")]
		public int Height
		{
			get
			{
				Value property = base.GetProperty("height");
				int result = (int)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("height", val);
				val.Dispose();
			}
		}

		// Token: 0x170000EE RID: 238
		// (get) Token: 0x06000624 RID: 1572 RVA: 0x000114F4 File Offset: 0x0000F6F4
		// (set) Token: 0x06000625 RID: 1573 RVA: 0x0001151C File Offset: 0x0000F71C
		[Property("is-expander")]
		public bool IsExpander
		{
			get
			{
				Value property = base.GetProperty("is-expander");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("is-expander", val);
				val.Dispose();
			}
		}

		// Token: 0x170000EF RID: 239
		// (get) Token: 0x06000626 RID: 1574 RVA: 0x00011544 File Offset: 0x0000F744
		// (set) Token: 0x06000627 RID: 1575 RVA: 0x0001156C File Offset: 0x0000F76C
		[Property("is-expanded")]
		public bool IsExpanded
		{
			get
			{
				Value property = base.GetProperty("is-expanded");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("is-expanded", val);
				val.Dispose();
			}
		}

		// Token: 0x170000F0 RID: 240
		// (set) Token: 0x06000628 RID: 1576 RVA: 0x00011594 File Offset: 0x0000F794
		[Property("cell-background")]
		public string CellBackground
		{
			set
			{
				Value val = new Value(value);
				base.SetProperty("cell-background", val);
				val.Dispose();
			}
		}

		// Token: 0x170000F1 RID: 241
		// (get) Token: 0x06000629 RID: 1577 RVA: 0x000115BC File Offset: 0x0000F7BC
		// (set) Token: 0x0600062A RID: 1578 RVA: 0x000115E4 File Offset: 0x0000F7E4
		[Property("cell-background-gdk")]
		public Gdk.Color CellBackgroundGdk
		{
			get
			{
				Value property = base.GetProperty("cell-background-gdk");
				Gdk.Color result = (Gdk.Color)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = (Value)value;
				base.SetProperty("cell-background-gdk", val);
				val.Dispose();
			}
		}

		// Token: 0x170000F2 RID: 242
		// (get) Token: 0x0600062B RID: 1579 RVA: 0x0001160C File Offset: 0x0000F80C
		// (set) Token: 0x0600062C RID: 1580 RVA: 0x00011634 File Offset: 0x0000F834
		[Property("cell-background-rgba")]
		public RGBA CellBackgroundRgba
		{
			get
			{
				Value property = base.GetProperty("cell-background-rgba");
				RGBA result = (RGBA)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("cell-background-rgba", val);
				val.Dispose();
			}
		}

		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x0600062D RID: 1581 RVA: 0x00011664 File Offset: 0x0000F864
		[Property("editing")]
		public bool Editing
		{
			get
			{
				Value property = base.GetProperty("editing");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
		}

		// Token: 0x14000017 RID: 23
		// (add) Token: 0x0600062E RID: 1582 RVA: 0x0001168A File Offset: 0x0000F88A
		// (remove) Token: 0x0600062F RID: 1583 RVA: 0x000116A2 File Offset: 0x0000F8A2
		[Signal("editing-started")]
		public event EditingStartedHandler EditingStarted
		{
			add
			{
				base.AddSignalHandler("editing-started", value, typeof(EditingStartedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("editing-started", value);
			}
		}

		// Token: 0x14000018 RID: 24
		// (add) Token: 0x06000630 RID: 1584 RVA: 0x000116B0 File Offset: 0x0000F8B0
		// (remove) Token: 0x06000631 RID: 1585 RVA: 0x000116BE File Offset: 0x0000F8BE
		[Signal("editing-canceled")]
		public event EventHandler EditingCanceled
		{
			add
			{
				base.AddSignalHandler("editing-canceled", value);
			}
			remove
			{
				base.RemoveSignalHandler("editing-canceled", value);
			}
		}

		// Token: 0x170000F4 RID: 244
		// (get) Token: 0x06000632 RID: 1586 RVA: 0x000116CC File Offset: 0x0000F8CC
		private static CellRenderer.GetRequestModeNativeDelegate GetRequestModeVMCallback
		{
			get
			{
				if (CellRenderer.GetRequestMode_cb_delegate == null)
				{
					CellRenderer.GetRequestMode_cb_delegate = new CellRenderer.GetRequestModeNativeDelegate(CellRenderer.GetRequestMode_cb);
				}
				return CellRenderer.GetRequestMode_cb_delegate;
			}
		}

		// Token: 0x06000633 RID: 1587 RVA: 0x000116EB File Offset: 0x0000F8EB
		private static void OverrideGetRequestMode(GType gtype)
		{
			CellRenderer.OverrideGetRequestMode(gtype, CellRenderer.GetRequestModeVMCallback);
		}

		// Token: 0x06000634 RID: 1588 RVA: 0x000116F8 File Offset: 0x0000F8F8
		private unsafe static void OverrideGetRequestMode(GType gtype, CellRenderer.GetRequestModeNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellRenderer.class_abi.GetFieldOffset("get_request_mode");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000635 RID: 1589 RVA: 0x0001172C File Offset: 0x0000F92C
		private static int GetRequestMode_cb(IntPtr inst)
		{
			int result;
			try
			{
				result = (int)(Object.GetObject(inst, false) as CellRenderer).OnGetRequestMode();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000636 RID: 1590 RVA: 0x00011768 File Offset: 0x0000F968
		[DefaultSignalHandler(Type = typeof(CellRenderer), ConnectionMethod = "OverrideGetRequestMode")]
		protected virtual SizeRequestMode OnGetRequestMode()
		{
			return this.InternalGetRequestMode();
		}

		// Token: 0x06000637 RID: 1591 RVA: 0x00011770 File Offset: 0x0000F970
		private SizeRequestMode InternalGetRequestMode()
		{
			CellRenderer.GetRequestModeNativeDelegate getRequestModeNativeDelegate = CellRenderer.class_abi.BaseOverride(base.LookupGType(), "get_request_mode");
			if (getRequestModeNativeDelegate == null)
			{
				return SizeRequestMode.HeightForWidth;
			}
			return (SizeRequestMode)getRequestModeNativeDelegate(base.Handle);
		}

		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x06000638 RID: 1592 RVA: 0x000117A4 File Offset: 0x0000F9A4
		private static CellRenderer.GetPreferredWidthNativeDelegate GetPreferredWidthVMCallback
		{
			get
			{
				if (CellRenderer.GetPreferredWidth_cb_delegate == null)
				{
					CellRenderer.GetPreferredWidth_cb_delegate = new CellRenderer.GetPreferredWidthNativeDelegate(CellRenderer.GetPreferredWidth_cb);
				}
				return CellRenderer.GetPreferredWidth_cb_delegate;
			}
		}

		// Token: 0x06000639 RID: 1593 RVA: 0x000117C3 File Offset: 0x0000F9C3
		private static void OverrideGetPreferredWidth(GType gtype)
		{
			CellRenderer.OverrideGetPreferredWidth(gtype, CellRenderer.GetPreferredWidthVMCallback);
		}

		// Token: 0x0600063A RID: 1594 RVA: 0x000117D0 File Offset: 0x0000F9D0
		private unsafe static void OverrideGetPreferredWidth(GType gtype, CellRenderer.GetPreferredWidthNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellRenderer.class_abi.GetFieldOffset("get_preferred_width");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600063B RID: 1595 RVA: 0x00011804 File Offset: 0x0000FA04
		private static void GetPreferredWidth_cb(IntPtr inst, IntPtr widget, out int minimum_size, out int natural_size)
		{
			try
			{
				(Object.GetObject(inst, false) as CellRenderer).OnGetPreferredWidth(Object.GetObject(widget) as Widget, out minimum_size, out natural_size);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
		}

		// Token: 0x0600063C RID: 1596 RVA: 0x0001184C File Offset: 0x0000FA4C
		[DefaultSignalHandler(Type = typeof(CellRenderer), ConnectionMethod = "OverrideGetPreferredWidth")]
		protected virtual void OnGetPreferredWidth(Widget widget, out int minimum_size, out int natural_size)
		{
			this.InternalGetPreferredWidth(widget, out minimum_size, out natural_size);
		}

		// Token: 0x0600063D RID: 1597 RVA: 0x00011858 File Offset: 0x0000FA58
		private void InternalGetPreferredWidth(Widget widget, out int minimum_size, out int natural_size)
		{
			CellRenderer.GetPreferredWidthNativeDelegate getPreferredWidthNativeDelegate = CellRenderer.class_abi.BaseOverride(base.LookupGType(), "get_preferred_width");
			if (getPreferredWidthNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			getPreferredWidthNativeDelegate(base.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, out minimum_size, out natural_size);
		}

		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x0600063E RID: 1598 RVA: 0x000118A5 File Offset: 0x0000FAA5
		private static CellRenderer.GetPreferredHeightForWidthNativeDelegate GetPreferredHeightForWidthVMCallback
		{
			get
			{
				if (CellRenderer.GetPreferredHeightForWidth_cb_delegate == null)
				{
					CellRenderer.GetPreferredHeightForWidth_cb_delegate = new CellRenderer.GetPreferredHeightForWidthNativeDelegate(CellRenderer.GetPreferredHeightForWidth_cb);
				}
				return CellRenderer.GetPreferredHeightForWidth_cb_delegate;
			}
		}

		// Token: 0x0600063F RID: 1599 RVA: 0x000118C4 File Offset: 0x0000FAC4
		private static void OverrideGetPreferredHeightForWidth(GType gtype)
		{
			CellRenderer.OverrideGetPreferredHeightForWidth(gtype, CellRenderer.GetPreferredHeightForWidthVMCallback);
		}

		// Token: 0x06000640 RID: 1600 RVA: 0x000118D4 File Offset: 0x0000FAD4
		private unsafe static void OverrideGetPreferredHeightForWidth(GType gtype, CellRenderer.GetPreferredHeightForWidthNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellRenderer.class_abi.GetFieldOffset("get_preferred_height_for_width");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000641 RID: 1601 RVA: 0x00011908 File Offset: 0x0000FB08
		private static void GetPreferredHeightForWidth_cb(IntPtr inst, IntPtr widget, int width, out int minimum_height, out int natural_height)
		{
			try
			{
				(Object.GetObject(inst, false) as CellRenderer).OnGetPreferredHeightForWidth(Object.GetObject(widget) as Widget, width, out minimum_height, out natural_height);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
		}

		// Token: 0x06000642 RID: 1602 RVA: 0x00011950 File Offset: 0x0000FB50
		[DefaultSignalHandler(Type = typeof(CellRenderer), ConnectionMethod = "OverrideGetPreferredHeightForWidth")]
		protected virtual void OnGetPreferredHeightForWidth(Widget widget, int width, out int minimum_height, out int natural_height)
		{
			this.InternalGetPreferredHeightForWidth(widget, width, out minimum_height, out natural_height);
		}

		// Token: 0x06000643 RID: 1603 RVA: 0x00011960 File Offset: 0x0000FB60
		private void InternalGetPreferredHeightForWidth(Widget widget, int width, out int minimum_height, out int natural_height)
		{
			CellRenderer.GetPreferredHeightForWidthNativeDelegate getPreferredHeightForWidthNativeDelegate = CellRenderer.class_abi.BaseOverride(base.LookupGType(), "get_preferred_height_for_width");
			if (getPreferredHeightForWidthNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			getPreferredHeightForWidthNativeDelegate(base.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, width, out minimum_height, out natural_height);
		}

		// Token: 0x170000F7 RID: 247
		// (get) Token: 0x06000644 RID: 1604 RVA: 0x000119AF File Offset: 0x0000FBAF
		private static CellRenderer.GetPreferredHeightNativeDelegate GetPreferredHeightVMCallback
		{
			get
			{
				if (CellRenderer.GetPreferredHeight_cb_delegate == null)
				{
					CellRenderer.GetPreferredHeight_cb_delegate = new CellRenderer.GetPreferredHeightNativeDelegate(CellRenderer.GetPreferredHeight_cb);
				}
				return CellRenderer.GetPreferredHeight_cb_delegate;
			}
		}

		// Token: 0x06000645 RID: 1605 RVA: 0x000119CE File Offset: 0x0000FBCE
		private static void OverrideGetPreferredHeight(GType gtype)
		{
			CellRenderer.OverrideGetPreferredHeight(gtype, CellRenderer.GetPreferredHeightVMCallback);
		}

		// Token: 0x06000646 RID: 1606 RVA: 0x000119DC File Offset: 0x0000FBDC
		private unsafe static void OverrideGetPreferredHeight(GType gtype, CellRenderer.GetPreferredHeightNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellRenderer.class_abi.GetFieldOffset("get_preferred_height");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000647 RID: 1607 RVA: 0x00011A10 File Offset: 0x0000FC10
		private static void GetPreferredHeight_cb(IntPtr inst, IntPtr widget, out int minimum_size, out int natural_size)
		{
			try
			{
				(Object.GetObject(inst, false) as CellRenderer).OnGetPreferredHeight(Object.GetObject(widget) as Widget, out minimum_size, out natural_size);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
		}

		// Token: 0x06000648 RID: 1608 RVA: 0x00011A58 File Offset: 0x0000FC58
		[DefaultSignalHandler(Type = typeof(CellRenderer), ConnectionMethod = "OverrideGetPreferredHeight")]
		protected virtual void OnGetPreferredHeight(Widget widget, out int minimum_size, out int natural_size)
		{
			this.InternalGetPreferredHeight(widget, out minimum_size, out natural_size);
		}

		// Token: 0x06000649 RID: 1609 RVA: 0x00011A64 File Offset: 0x0000FC64
		private void InternalGetPreferredHeight(Widget widget, out int minimum_size, out int natural_size)
		{
			CellRenderer.GetPreferredHeightNativeDelegate getPreferredHeightNativeDelegate = CellRenderer.class_abi.BaseOverride(base.LookupGType(), "get_preferred_height");
			if (getPreferredHeightNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			getPreferredHeightNativeDelegate(base.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, out minimum_size, out natural_size);
		}

		// Token: 0x170000F8 RID: 248
		// (get) Token: 0x0600064A RID: 1610 RVA: 0x00011AB1 File Offset: 0x0000FCB1
		private static CellRenderer.GetPreferredWidthForHeightNativeDelegate GetPreferredWidthForHeightVMCallback
		{
			get
			{
				if (CellRenderer.GetPreferredWidthForHeight_cb_delegate == null)
				{
					CellRenderer.GetPreferredWidthForHeight_cb_delegate = new CellRenderer.GetPreferredWidthForHeightNativeDelegate(CellRenderer.GetPreferredWidthForHeight_cb);
				}
				return CellRenderer.GetPreferredWidthForHeight_cb_delegate;
			}
		}

		// Token: 0x0600064B RID: 1611 RVA: 0x00011AD0 File Offset: 0x0000FCD0
		private static void OverrideGetPreferredWidthForHeight(GType gtype)
		{
			CellRenderer.OverrideGetPreferredWidthForHeight(gtype, CellRenderer.GetPreferredWidthForHeightVMCallback);
		}

		// Token: 0x0600064C RID: 1612 RVA: 0x00011AE0 File Offset: 0x0000FCE0
		private unsafe static void OverrideGetPreferredWidthForHeight(GType gtype, CellRenderer.GetPreferredWidthForHeightNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellRenderer.class_abi.GetFieldOffset("get_preferred_width_for_height");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600064D RID: 1613 RVA: 0x00011B14 File Offset: 0x0000FD14
		private static void GetPreferredWidthForHeight_cb(IntPtr inst, IntPtr widget, int height, out int minimum_width, out int natural_width)
		{
			try
			{
				(Object.GetObject(inst, false) as CellRenderer).OnGetPreferredWidthForHeight(Object.GetObject(widget) as Widget, height, out minimum_width, out natural_width);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
		}

		// Token: 0x0600064E RID: 1614 RVA: 0x00011B5C File Offset: 0x0000FD5C
		[DefaultSignalHandler(Type = typeof(CellRenderer), ConnectionMethod = "OverrideGetPreferredWidthForHeight")]
		protected virtual void OnGetPreferredWidthForHeight(Widget widget, int height, out int minimum_width, out int natural_width)
		{
			this.InternalGetPreferredWidthForHeight(widget, height, out minimum_width, out natural_width);
		}

		// Token: 0x0600064F RID: 1615 RVA: 0x00011B6C File Offset: 0x0000FD6C
		private void InternalGetPreferredWidthForHeight(Widget widget, int height, out int minimum_width, out int natural_width)
		{
			CellRenderer.GetPreferredWidthForHeightNativeDelegate getPreferredWidthForHeightNativeDelegate = CellRenderer.class_abi.BaseOverride(base.LookupGType(), "get_preferred_width_for_height");
			if (getPreferredWidthForHeightNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			getPreferredWidthForHeightNativeDelegate(base.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, height, out minimum_width, out natural_width);
		}

		// Token: 0x170000F9 RID: 249
		// (get) Token: 0x06000650 RID: 1616 RVA: 0x00011BBB File Offset: 0x0000FDBB
		private static CellRenderer.GetAlignedAreaNativeDelegate GetAlignedAreaVMCallback
		{
			get
			{
				if (CellRenderer.GetAlignedArea_cb_delegate == null)
				{
					CellRenderer.GetAlignedArea_cb_delegate = new CellRenderer.GetAlignedAreaNativeDelegate(CellRenderer.GetAlignedArea_cb);
				}
				return CellRenderer.GetAlignedArea_cb_delegate;
			}
		}

		// Token: 0x06000651 RID: 1617 RVA: 0x00011BDA File Offset: 0x0000FDDA
		private static void OverrideGetAlignedArea(GType gtype)
		{
			CellRenderer.OverrideGetAlignedArea(gtype, CellRenderer.GetAlignedAreaVMCallback);
		}

		// Token: 0x06000652 RID: 1618 RVA: 0x00011BE8 File Offset: 0x0000FDE8
		private unsafe static void OverrideGetAlignedArea(GType gtype, CellRenderer.GetAlignedAreaNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellRenderer.class_abi.GetFieldOffset("get_aligned_area");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000653 RID: 1619 RVA: 0x00011C1C File Offset: 0x0000FE1C
		private static void GetAlignedArea_cb(IntPtr inst, IntPtr widget, int flags, IntPtr cell_area, IntPtr aligned_area)
		{
			try
			{
				(Object.GetObject(inst, false) as CellRenderer).OnGetAlignedArea(Object.GetObject(widget) as Widget, (CellRendererState)flags, (Gdk.Rectangle)Marshal.PtrToStructure(cell_area, typeof(Gdk.Rectangle)), (Gdk.Rectangle)Marshal.PtrToStructure(aligned_area, typeof(Gdk.Rectangle)));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000654 RID: 1620 RVA: 0x00011C8C File Offset: 0x0000FE8C
		[DefaultSignalHandler(Type = typeof(CellRenderer), ConnectionMethod = "OverrideGetAlignedArea")]
		protected virtual void OnGetAlignedArea(Widget widget, CellRendererState flags, Gdk.Rectangle cell_area, Gdk.Rectangle aligned_area)
		{
			this.InternalGetAlignedArea(widget, flags, cell_area, aligned_area);
		}

		// Token: 0x06000655 RID: 1621 RVA: 0x00011C9C File Offset: 0x0000FE9C
		private void InternalGetAlignedArea(Widget widget, CellRendererState flags, Gdk.Rectangle cell_area, Gdk.Rectangle aligned_area)
		{
			CellRenderer.GetAlignedAreaNativeDelegate getAlignedAreaNativeDelegate = CellRenderer.class_abi.BaseOverride(base.LookupGType(), "get_aligned_area");
			if (getAlignedAreaNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(cell_area);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(aligned_area);
			getAlignedAreaNativeDelegate(base.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, (int)flags, intPtr, intPtr2);
			Marshal.FreeHGlobal(intPtr);
			Marshal.FreeHGlobal(intPtr2);
		}

		// Token: 0x170000FA RID: 250
		// (get) Token: 0x06000656 RID: 1622 RVA: 0x00011D07 File Offset: 0x0000FF07
		private static CellRenderer.RenderNativeDelegate RenderVMCallback
		{
			get
			{
				if (CellRenderer.Render_cb_delegate == null)
				{
					CellRenderer.Render_cb_delegate = new CellRenderer.RenderNativeDelegate(CellRenderer.Render_cb);
				}
				return CellRenderer.Render_cb_delegate;
			}
		}

		// Token: 0x06000657 RID: 1623 RVA: 0x00011D26 File Offset: 0x0000FF26
		private static void OverrideRender(GType gtype)
		{
			CellRenderer.OverrideRender(gtype, CellRenderer.RenderVMCallback);
		}

		// Token: 0x06000658 RID: 1624 RVA: 0x00011D34 File Offset: 0x0000FF34
		private unsafe static void OverrideRender(GType gtype, CellRenderer.RenderNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellRenderer.class_abi.GetFieldOffset("render");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000659 RID: 1625 RVA: 0x00011D68 File Offset: 0x0000FF68
		private static void Render_cb(IntPtr inst, IntPtr cr, IntPtr widget, IntPtr background_area, IntPtr cell_area, int flags)
		{
			Context context = null;
			try
			{
				CellRenderer cellRenderer = Object.GetObject(inst, false) as CellRenderer;
				context = new Context(cr, false);
				cellRenderer.OnRender(context, Object.GetObject(widget) as Widget, (Gdk.Rectangle)Marshal.PtrToStructure(background_area, typeof(Gdk.Rectangle)), (Gdk.Rectangle)Marshal.PtrToStructure(cell_area, typeof(Gdk.Rectangle)), (CellRendererState)flags);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
			finally
			{
				IDisposable disposable = context;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
		}

		// Token: 0x0600065A RID: 1626 RVA: 0x00011DFC File Offset: 0x0000FFFC
		[DefaultSignalHandler(Type = typeof(CellRenderer), ConnectionMethod = "OverrideRender")]
		protected virtual void OnRender(Context cr, Widget widget, Gdk.Rectangle background_area, Gdk.Rectangle cell_area, CellRendererState flags)
		{
			this.InternalRender(cr, widget, background_area, cell_area, flags);
		}

		// Token: 0x0600065B RID: 1627 RVA: 0x00011E0C File Offset: 0x0001000C
		private void InternalRender(Context cr, Widget widget, Gdk.Rectangle background_area, Gdk.Rectangle cell_area, CellRendererState flags)
		{
			CellRenderer.RenderNativeDelegate renderNativeDelegate = CellRenderer.class_abi.BaseOverride(base.LookupGType(), "render");
			if (renderNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(background_area);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(cell_area);
			renderNativeDelegate(base.Handle, (cr == null) ? IntPtr.Zero : cr.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, intPtr, intPtr2, (int)flags);
			Marshal.FreeHGlobal(intPtr);
			Marshal.FreeHGlobal(intPtr2);
		}

		// Token: 0x170000FB RID: 251
		// (get) Token: 0x0600065C RID: 1628 RVA: 0x00011E88 File Offset: 0x00010088
		private static CellRenderer.ActivateNativeDelegate ActivateVMCallback
		{
			get
			{
				if (CellRenderer.Activate_cb_delegate == null)
				{
					CellRenderer.Activate_cb_delegate = new CellRenderer.ActivateNativeDelegate(CellRenderer.Activate_cb);
				}
				return CellRenderer.Activate_cb_delegate;
			}
		}

		// Token: 0x0600065D RID: 1629 RVA: 0x00011EA7 File Offset: 0x000100A7
		private static void OverrideActivate(GType gtype)
		{
			CellRenderer.OverrideActivate(gtype, CellRenderer.ActivateVMCallback);
		}

		// Token: 0x0600065E RID: 1630 RVA: 0x00011EB4 File Offset: 0x000100B4
		private unsafe static void OverrideActivate(GType gtype, CellRenderer.ActivateNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellRenderer.class_abi.GetFieldOffset("activate");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600065F RID: 1631 RVA: 0x00011EE8 File Offset: 0x000100E8
		private static bool Activate_cb(IntPtr inst, IntPtr evnt, IntPtr widget, IntPtr path, IntPtr background_area, IntPtr cell_area, int flags)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as CellRenderer).OnActivate(Event.GetEvent(evnt), Object.GetObject(widget) as Widget, Marshaller.Utf8PtrToString(path), (Gdk.Rectangle)Marshal.PtrToStructure(background_area, typeof(Gdk.Rectangle)), (Gdk.Rectangle)Marshal.PtrToStructure(cell_area, typeof(Gdk.Rectangle)), (CellRendererState)flags);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000660 RID: 1632 RVA: 0x00011F68 File Offset: 0x00010168
		[DefaultSignalHandler(Type = typeof(CellRenderer), ConnectionMethod = "OverrideActivate")]
		protected virtual bool OnActivate(Event evnt, Widget widget, string path, Gdk.Rectangle background_area, Gdk.Rectangle cell_area, CellRendererState flags)
		{
			return this.InternalActivate(evnt, widget, path, background_area, cell_area, flags);
		}

		// Token: 0x06000661 RID: 1633 RVA: 0x00011F7C File Offset: 0x0001017C
		private bool InternalActivate(Event evnt, Widget widget, string path, Gdk.Rectangle background_area, Gdk.Rectangle cell_area, CellRendererState flags)
		{
			CellRenderer.ActivateNativeDelegate activateNativeDelegate = CellRenderer.class_abi.BaseOverride(base.LookupGType(), "activate");
			if (activateNativeDelegate == null)
			{
				return false;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(path);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(background_area);
			IntPtr intPtr3 = Marshaller.StructureToPtrAlloc(cell_area);
			bool result = activateNativeDelegate(base.Handle, (evnt == null) ? IntPtr.Zero : evnt.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, intPtr, intPtr2, intPtr3, (int)flags);
			Marshaller.Free(intPtr);
			Marshal.FreeHGlobal(intPtr2);
			Marshal.FreeHGlobal(intPtr3);
			return result;
		}

		// Token: 0x170000FC RID: 252
		// (get) Token: 0x06000662 RID: 1634 RVA: 0x00012008 File Offset: 0x00010208
		private static CellRenderer.StartEditingNativeDelegate StartEditingVMCallback
		{
			get
			{
				if (CellRenderer.StartEditing_cb_delegate == null)
				{
					CellRenderer.StartEditing_cb_delegate = new CellRenderer.StartEditingNativeDelegate(CellRenderer.StartEditing_cb);
				}
				return CellRenderer.StartEditing_cb_delegate;
			}
		}

		// Token: 0x06000663 RID: 1635 RVA: 0x00012027 File Offset: 0x00010227
		private static void OverrideStartEditing(GType gtype)
		{
			CellRenderer.OverrideStartEditing(gtype, CellRenderer.StartEditingVMCallback);
		}

		// Token: 0x06000664 RID: 1636 RVA: 0x00012034 File Offset: 0x00010234
		private unsafe static void OverrideStartEditing(GType gtype, CellRenderer.StartEditingNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellRenderer.class_abi.GetFieldOffset("start_editing");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000665 RID: 1637 RVA: 0x00012068 File Offset: 0x00010268
		private static IntPtr StartEditing_cb(IntPtr inst, IntPtr evnt, IntPtr widget, IntPtr path, IntPtr background_area, IntPtr cell_area, int flags)
		{
			IntPtr result;
			try
			{
				ICellEditable cellEditable = (Object.GetObject(inst, false) as CellRenderer).OnStartEditing(Event.GetEvent(evnt), Object.GetObject(widget) as Widget, Marshaller.Utf8PtrToString(path), (Gdk.Rectangle)Marshal.PtrToStructure(background_area, typeof(Gdk.Rectangle)), (Gdk.Rectangle)Marshal.PtrToStructure(cell_area, typeof(Gdk.Rectangle)), (CellRendererState)flags);
				result = ((cellEditable == null) ? IntPtr.Zero : ((cellEditable is Object) ? (cellEditable as Object).Handle : (cellEditable as CellEditableAdapter).Handle));
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000666 RID: 1638 RVA: 0x00012114 File Offset: 0x00010314
		[DefaultSignalHandler(Type = typeof(CellRenderer), ConnectionMethod = "OverrideStartEditing")]
		protected virtual ICellEditable OnStartEditing(Event evnt, Widget widget, string path, Gdk.Rectangle background_area, Gdk.Rectangle cell_area, CellRendererState flags)
		{
			return this.InternalStartEditing(evnt, widget, path, background_area, cell_area, flags);
		}

		// Token: 0x06000667 RID: 1639 RVA: 0x00012128 File Offset: 0x00010328
		private ICellEditable InternalStartEditing(Event evnt, Widget widget, string path, Gdk.Rectangle background_area, Gdk.Rectangle cell_area, CellRendererState flags)
		{
			CellRenderer.StartEditingNativeDelegate startEditingNativeDelegate = CellRenderer.class_abi.BaseOverride(base.LookupGType(), "start_editing");
			if (startEditingNativeDelegate == null)
			{
				return null;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(path);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(background_area);
			IntPtr intPtr3 = Marshaller.StructureToPtrAlloc(cell_area);
			IntPtr handle = startEditingNativeDelegate(base.Handle, (evnt == null) ? IntPtr.Zero : evnt.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, intPtr, intPtr2, intPtr3, (int)flags);
			Marshaller.Free(intPtr);
			Marshal.FreeHGlobal(intPtr2);
			Marshal.FreeHGlobal(intPtr3);
			return CellEditableAdapter.GetObject(handle, false);
		}

		// Token: 0x170000FD RID: 253
		// (get) Token: 0x06000668 RID: 1640 RVA: 0x000121BA File Offset: 0x000103BA
		private static CellRenderer.EditingCanceledNativeDelegate EditingCanceledVMCallback
		{
			get
			{
				if (CellRenderer.EditingCanceled_cb_delegate == null)
				{
					CellRenderer.EditingCanceled_cb_delegate = new CellRenderer.EditingCanceledNativeDelegate(CellRenderer.EditingCanceled_cb);
				}
				return CellRenderer.EditingCanceled_cb_delegate;
			}
		}

		// Token: 0x06000669 RID: 1641 RVA: 0x000121D9 File Offset: 0x000103D9
		private static void OverrideEditingCanceled(GType gtype)
		{
			CellRenderer.OverrideEditingCanceled(gtype, CellRenderer.EditingCanceledVMCallback);
		}

		// Token: 0x0600066A RID: 1642 RVA: 0x000121E8 File Offset: 0x000103E8
		private unsafe static void OverrideEditingCanceled(GType gtype, CellRenderer.EditingCanceledNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellRenderer.class_abi.GetFieldOffset("editing_canceled");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600066B RID: 1643 RVA: 0x0001221C File Offset: 0x0001041C
		private static void EditingCanceled_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as CellRenderer).OnEditingCanceled();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x0600066C RID: 1644 RVA: 0x00012254 File Offset: 0x00010454
		[DefaultSignalHandler(Type = typeof(CellRenderer), ConnectionMethod = "OverrideEditingCanceled")]
		protected virtual void OnEditingCanceled()
		{
			this.InternalEditingCanceled();
		}

		// Token: 0x0600066D RID: 1645 RVA: 0x0001225C File Offset: 0x0001045C
		private void InternalEditingCanceled()
		{
			CellRenderer.EditingCanceledNativeDelegate editingCanceledNativeDelegate = CellRenderer.class_abi.BaseOverride(base.LookupGType(), "editing_canceled");
			if (editingCanceledNativeDelegate == null)
			{
				return;
			}
			editingCanceledNativeDelegate(base.Handle);
		}

		// Token: 0x170000FE RID: 254
		// (get) Token: 0x0600066E RID: 1646 RVA: 0x0001228F File Offset: 0x0001048F
		private static CellRenderer.EditingStartedNativeDelegate EditingStartedVMCallback
		{
			get
			{
				if (CellRenderer.EditingStarted_cb_delegate == null)
				{
					CellRenderer.EditingStarted_cb_delegate = new CellRenderer.EditingStartedNativeDelegate(CellRenderer.EditingStarted_cb);
				}
				return CellRenderer.EditingStarted_cb_delegate;
			}
		}

		// Token: 0x0600066F RID: 1647 RVA: 0x000122AE File Offset: 0x000104AE
		private static void OverrideEditingStarted(GType gtype)
		{
			CellRenderer.OverrideEditingStarted(gtype, CellRenderer.EditingStartedVMCallback);
		}

		// Token: 0x06000670 RID: 1648 RVA: 0x000122BC File Offset: 0x000104BC
		private unsafe static void OverrideEditingStarted(GType gtype, CellRenderer.EditingStartedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellRenderer.class_abi.GetFieldOffset("editing_started");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000671 RID: 1649 RVA: 0x000122F0 File Offset: 0x000104F0
		private static void EditingStarted_cb(IntPtr inst, IntPtr editable, IntPtr path)
		{
			try
			{
				(Object.GetObject(inst, false) as CellRenderer).OnEditingStarted(CellEditableAdapter.GetObject(editable, false), Marshaller.Utf8PtrToString(path));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000672 RID: 1650 RVA: 0x00012338 File Offset: 0x00010538
		[DefaultSignalHandler(Type = typeof(CellRenderer), ConnectionMethod = "OverrideEditingStarted")]
		protected virtual void OnEditingStarted(ICellEditable editable, string path)
		{
			this.InternalEditingStarted(editable, path);
		}

		// Token: 0x06000673 RID: 1651 RVA: 0x00012344 File Offset: 0x00010544
		private void InternalEditingStarted(ICellEditable editable, string path)
		{
			CellRenderer.EditingStartedNativeDelegate editingStartedNativeDelegate = CellRenderer.class_abi.BaseOverride(base.LookupGType(), "editing_started");
			if (editingStartedNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(path);
			editingStartedNativeDelegate(base.Handle, (editable == null) ? IntPtr.Zero : ((editable is Object) ? (editable as Object).Handle : (editable as CellEditableAdapter).Handle), intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x170000FF RID: 255
		// (get) Token: 0x06000674 RID: 1652 RVA: 0x000123B0 File Offset: 0x000105B0
		public new static AbiStruct class_abi
		{
			get
			{
				if (CellRenderer._class_abi == null)
				{
					CellRenderer._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("get_request_mode", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "get_preferred_width", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_preferred_width", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_request_mode", "get_preferred_height_for_width", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_preferred_height_for_width", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_preferred_width", "get_preferred_height", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_preferred_height", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_preferred_height_for_width", "get_preferred_width_for_height", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_preferred_width_for_height", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_preferred_height", "get_aligned_area", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_aligned_area", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_preferred_width_for_height", "get_size", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_size", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_aligned_area", "render", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("render", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_size", "activate", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("activate", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "render", "start_editing", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("start_editing", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "activate", "editing_canceled", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("editing_canceled", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "start_editing", "editing_started", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("editing_started", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "editing_canceled", "priv", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("priv", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "editing_started", "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "priv", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellRenderer._class_abi;
			}
		}

		// Token: 0x06000675 RID: 1653 RVA: 0x0001279C File Offset: 0x0001099C
		public bool Activate(Event evnt, Widget widget, string path, Gdk.Rectangle background_area, Gdk.Rectangle cell_area, CellRendererState flags)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(path);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(background_area);
			IntPtr intPtr3 = Marshaller.StructureToPtrAlloc(cell_area);
			bool result = CellRenderer.gtk_cell_renderer_activate(base.Handle, (evnt == null) ? IntPtr.Zero : evnt.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, intPtr, intPtr2, intPtr3, (int)flags);
			Marshaller.Free(intPtr);
			Marshal.FreeHGlobal(intPtr2);
			Marshal.FreeHGlobal(intPtr3);
			return result;
		}

		// Token: 0x06000676 RID: 1654 RVA: 0x00012814 File Offset: 0x00010A14
		public void GetAlignedArea(Widget widget, CellRendererState flags, Gdk.Rectangle cell_area, Gdk.Rectangle aligned_area)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(cell_area);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(aligned_area);
			CellRenderer.gtk_cell_renderer_get_aligned_area(base.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, (int)flags, intPtr, intPtr2);
			Marshal.FreeHGlobal(intPtr);
			Marshal.FreeHGlobal(intPtr2);
		}

		// Token: 0x06000677 RID: 1655 RVA: 0x00012869 File Offset: 0x00010A69
		public void GetAlignment(out float xalign, out float yalign)
		{
			CellRenderer.gtk_cell_renderer_get_alignment(base.Handle, out xalign, out yalign);
		}

		// Token: 0x06000678 RID: 1656 RVA: 0x0001287D File Offset: 0x00010A7D
		public void GetFixedSize(out int width, out int height)
		{
			CellRenderer.gtk_cell_renderer_get_fixed_size(base.Handle, out width, out height);
		}

		// Token: 0x06000679 RID: 1657 RVA: 0x00012891 File Offset: 0x00010A91
		public void GetPadding(out int xpad, out int ypad)
		{
			CellRenderer.gtk_cell_renderer_get_padding(base.Handle, out xpad, out ypad);
		}

		// Token: 0x0600067A RID: 1658 RVA: 0x000128A5 File Offset: 0x00010AA5
		public void GetPreferredHeight(Widget widget, out int minimum_size, out int natural_size)
		{
			CellRenderer.gtk_cell_renderer_get_preferred_height(base.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, out minimum_size, out natural_size);
		}

		// Token: 0x0600067B RID: 1659 RVA: 0x000128C9 File Offset: 0x00010AC9
		public void GetPreferredHeightForWidth(Widget widget, int width, out int minimum_height, out int natural_height)
		{
			CellRenderer.gtk_cell_renderer_get_preferred_height_for_width(base.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, width, out minimum_height, out natural_height);
		}

		// Token: 0x0600067C RID: 1660 RVA: 0x000128F0 File Offset: 0x00010AF0
		public void GetPreferredSize(Widget widget, Requisition minimum_size, Requisition natural_size)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(minimum_size);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(natural_size);
			CellRenderer.gtk_cell_renderer_get_preferred_size(base.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, intPtr, intPtr2);
			Marshal.FreeHGlobal(intPtr);
			Marshal.FreeHGlobal(intPtr2);
		}

		// Token: 0x0600067D RID: 1661 RVA: 0x00012943 File Offset: 0x00010B43
		public void GetPreferredWidth(Widget widget, out int minimum_size, out int natural_size)
		{
			CellRenderer.gtk_cell_renderer_get_preferred_width(base.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, out minimum_size, out natural_size);
		}

		// Token: 0x0600067E RID: 1662 RVA: 0x00012967 File Offset: 0x00010B67
		public void GetPreferredWidthForHeight(Widget widget, int height, out int minimum_width, out int natural_width)
		{
			CellRenderer.gtk_cell_renderer_get_preferred_width_for_height(base.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, height, out minimum_width, out natural_width);
		}

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x0600067F RID: 1663 RVA: 0x0001298D File Offset: 0x00010B8D
		public SizeRequestMode RequestMode
		{
			get
			{
				return (SizeRequestMode)CellRenderer.gtk_cell_renderer_get_request_mode(base.Handle);
			}
		}

		// Token: 0x06000680 RID: 1664 RVA: 0x0001299F File Offset: 0x00010B9F
		public StateFlags GetState(Widget widget, CellRendererState cell_state)
		{
			return (StateFlags)CellRenderer.gtk_cell_renderer_get_state(base.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, (int)cell_state);
		}

		// Token: 0x17000101 RID: 257
		// (get) Token: 0x06000681 RID: 1665 RVA: 0x000129C4 File Offset: 0x00010BC4
		public new static GType GType
		{
			get
			{
				IntPtr val = CellRenderer.gtk_cell_renderer_get_type();
				return new GType(val);
			}
		}

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x06000682 RID: 1666 RVA: 0x000129E2 File Offset: 0x00010BE2
		public bool IsActivatable
		{
			get
			{
				return CellRenderer.gtk_cell_renderer_is_activatable(base.Handle);
			}
		}

		// Token: 0x06000683 RID: 1667 RVA: 0x000129F4 File Offset: 0x00010BF4
		public void Render(Context cr, Widget widget, Gdk.Rectangle background_area, Gdk.Rectangle cell_area, CellRendererState flags)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(background_area);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(cell_area);
			CellRenderer.gtk_cell_renderer_render(base.Handle, (cr == null) ? IntPtr.Zero : cr.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, intPtr, intPtr2, (int)flags);
			Marshal.FreeHGlobal(intPtr);
			Marshal.FreeHGlobal(intPtr2);
		}

		// Token: 0x06000684 RID: 1668 RVA: 0x00012A5A File Offset: 0x00010C5A
		public void SetAlignment(float xalign, float yalign)
		{
			CellRenderer.gtk_cell_renderer_set_alignment(base.Handle, xalign, yalign);
		}

		// Token: 0x06000685 RID: 1669 RVA: 0x00012A6E File Offset: 0x00010C6E
		public void SetFixedSize(int width, int height)
		{
			CellRenderer.gtk_cell_renderer_set_fixed_size(base.Handle, width, height);
		}

		// Token: 0x06000686 RID: 1670 RVA: 0x00012A82 File Offset: 0x00010C82
		public void SetPadding(int xpad, int ypad)
		{
			CellRenderer.gtk_cell_renderer_set_padding(base.Handle, xpad, ypad);
		}

		// Token: 0x06000687 RID: 1671 RVA: 0x00012A96 File Offset: 0x00010C96
		public void StopEditing(bool canceled)
		{
			CellRenderer.gtk_cell_renderer_stop_editing(base.Handle, canceled);
		}

		// Token: 0x17000103 RID: 259
		// (get) Token: 0x06000688 RID: 1672 RVA: 0x00012AAC File Offset: 0x00010CAC
		public new static AbiStruct abi_info
		{
			get
			{
				if (CellRenderer._abi_info == null)
				{
					CellRenderer._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Object.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellRenderer._abi_info;
			}
		}

		// Token: 0x0400030C RID: 780
		private static CellRenderer.d_gtk_cell_renderer_start_editing gtk_cell_renderer_start_editing = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_start_editing>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_start_editing"));

		// Token: 0x0400030D RID: 781
		private static CellRenderer.d_gtk_cell_renderer_render2 gtk_cell_renderer_render2 = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_render2>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_render"));

		// Token: 0x0400030E RID: 782
		private static CellRenderer.GetSizeNativeDelegate GetSize_cb_delegate;

		// Token: 0x0400030F RID: 783
		private static CellRenderer.d_gtk_cell_renderer_get_visible gtk_cell_renderer_get_visible = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_get_visible>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_get_visible"));

		// Token: 0x04000310 RID: 784
		private static CellRenderer.d_gtk_cell_renderer_set_visible gtk_cell_renderer_set_visible = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_set_visible>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_set_visible"));

		// Token: 0x04000311 RID: 785
		private static CellRenderer.d_gtk_cell_renderer_get_sensitive gtk_cell_renderer_get_sensitive = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_get_sensitive>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_get_sensitive"));

		// Token: 0x04000312 RID: 786
		private static CellRenderer.d_gtk_cell_renderer_set_sensitive gtk_cell_renderer_set_sensitive = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_set_sensitive>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_set_sensitive"));

		// Token: 0x04000313 RID: 787
		private static CellRenderer.GetRequestModeNativeDelegate GetRequestMode_cb_delegate;

		// Token: 0x04000314 RID: 788
		private static CellRenderer.GetPreferredWidthNativeDelegate GetPreferredWidth_cb_delegate;

		// Token: 0x04000315 RID: 789
		private static CellRenderer.GetPreferredHeightForWidthNativeDelegate GetPreferredHeightForWidth_cb_delegate;

		// Token: 0x04000316 RID: 790
		private static CellRenderer.GetPreferredHeightNativeDelegate GetPreferredHeight_cb_delegate;

		// Token: 0x04000317 RID: 791
		private static CellRenderer.GetPreferredWidthForHeightNativeDelegate GetPreferredWidthForHeight_cb_delegate;

		// Token: 0x04000318 RID: 792
		private static CellRenderer.GetAlignedAreaNativeDelegate GetAlignedArea_cb_delegate;

		// Token: 0x04000319 RID: 793
		private static CellRenderer.RenderNativeDelegate Render_cb_delegate;

		// Token: 0x0400031A RID: 794
		private static CellRenderer.ActivateNativeDelegate Activate_cb_delegate;

		// Token: 0x0400031B RID: 795
		private static CellRenderer.StartEditingNativeDelegate StartEditing_cb_delegate;

		// Token: 0x0400031C RID: 796
		private static CellRenderer.EditingCanceledNativeDelegate EditingCanceled_cb_delegate;

		// Token: 0x0400031D RID: 797
		private static CellRenderer.EditingStartedNativeDelegate EditingStarted_cb_delegate;

		// Token: 0x0400031E RID: 798
		private static AbiStruct _class_abi = null;

		// Token: 0x0400031F RID: 799
		private static CellRenderer.d_gtk_cell_renderer_activate gtk_cell_renderer_activate = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_activate>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_activate"));

		// Token: 0x04000320 RID: 800
		private static CellRenderer.d_gtk_cell_renderer_get_aligned_area gtk_cell_renderer_get_aligned_area = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_get_aligned_area>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_get_aligned_area"));

		// Token: 0x04000321 RID: 801
		private static CellRenderer.d_gtk_cell_renderer_get_alignment gtk_cell_renderer_get_alignment = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_get_alignment>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_get_alignment"));

		// Token: 0x04000322 RID: 802
		private static CellRenderer.d_gtk_cell_renderer_get_fixed_size gtk_cell_renderer_get_fixed_size = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_get_fixed_size>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_get_fixed_size"));

		// Token: 0x04000323 RID: 803
		private static CellRenderer.d_gtk_cell_renderer_get_padding gtk_cell_renderer_get_padding = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_get_padding>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_get_padding"));

		// Token: 0x04000324 RID: 804
		private static CellRenderer.d_gtk_cell_renderer_get_preferred_height gtk_cell_renderer_get_preferred_height = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_get_preferred_height>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_get_preferred_height"));

		// Token: 0x04000325 RID: 805
		private static CellRenderer.d_gtk_cell_renderer_get_preferred_height_for_width gtk_cell_renderer_get_preferred_height_for_width = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_get_preferred_height_for_width>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_get_preferred_height_for_width"));

		// Token: 0x04000326 RID: 806
		private static CellRenderer.d_gtk_cell_renderer_get_preferred_size gtk_cell_renderer_get_preferred_size = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_get_preferred_size>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_get_preferred_size"));

		// Token: 0x04000327 RID: 807
		private static CellRenderer.d_gtk_cell_renderer_get_preferred_width gtk_cell_renderer_get_preferred_width = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_get_preferred_width>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_get_preferred_width"));

		// Token: 0x04000328 RID: 808
		private static CellRenderer.d_gtk_cell_renderer_get_preferred_width_for_height gtk_cell_renderer_get_preferred_width_for_height = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_get_preferred_width_for_height>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_get_preferred_width_for_height"));

		// Token: 0x04000329 RID: 809
		private static CellRenderer.d_gtk_cell_renderer_get_request_mode gtk_cell_renderer_get_request_mode = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_get_request_mode>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_get_request_mode"));

		// Token: 0x0400032A RID: 810
		private static CellRenderer.d_gtk_cell_renderer_get_state gtk_cell_renderer_get_state = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_get_state>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_get_state"));

		// Token: 0x0400032B RID: 811
		private static CellRenderer.d_gtk_cell_renderer_get_type gtk_cell_renderer_get_type = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_get_type"));

		// Token: 0x0400032C RID: 812
		private static CellRenderer.d_gtk_cell_renderer_is_activatable gtk_cell_renderer_is_activatable = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_is_activatable>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_is_activatable"));

		// Token: 0x0400032D RID: 813
		private static CellRenderer.d_gtk_cell_renderer_render gtk_cell_renderer_render = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_render>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_render"));

		// Token: 0x0400032E RID: 814
		private static CellRenderer.d_gtk_cell_renderer_set_alignment gtk_cell_renderer_set_alignment = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_set_alignment>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_set_alignment"));

		// Token: 0x0400032F RID: 815
		private static CellRenderer.d_gtk_cell_renderer_set_fixed_size gtk_cell_renderer_set_fixed_size = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_set_fixed_size>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_set_fixed_size"));

		// Token: 0x04000330 RID: 816
		private static CellRenderer.d_gtk_cell_renderer_set_padding gtk_cell_renderer_set_padding = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_set_padding>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_set_padding"));

		// Token: 0x04000331 RID: 817
		private static CellRenderer.d_gtk_cell_renderer_stop_editing gtk_cell_renderer_stop_editing = FuncLoader.LoadFunction<CellRenderer.d_gtk_cell_renderer_stop_editing>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_stop_editing"));

		// Token: 0x04000332 RID: 818
		private static AbiStruct _abi_info = null;

		// Token: 0x02000746 RID: 1862
		// (Invoke) Token: 0x06004438 RID: 17464
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_renderer_start_editing(IntPtr handle, IntPtr evnt, IntPtr widget, IntPtr path, ref Gdk.Rectangle bg_area, ref Gdk.Rectangle cell_area, int flags);

		// Token: 0x02000747 RID: 1863
		// (Invoke) Token: 0x0600443C RID: 17468
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_render2(IntPtr handle, IntPtr drawable, IntPtr widget, ref Gdk.Rectangle bg_area, ref Gdk.Rectangle cell_area, ref Gdk.Rectangle expose_area, int flags);

		// Token: 0x02000748 RID: 1864
		// (Invoke) Token: 0x06004440 RID: 17472
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		internal delegate void GetSizeNativeDelegate(IntPtr item, IntPtr widget, IntPtr cell_area_ptr, IntPtr x_offset, IntPtr y_offset, IntPtr width, IntPtr height);

		// Token: 0x02000749 RID: 1865
		// (Invoke) Token: 0x06004444 RID: 17476
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_cell_renderer_get_visible(IntPtr raw);

		// Token: 0x0200074A RID: 1866
		// (Invoke) Token: 0x06004448 RID: 17480
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_set_visible(IntPtr raw, bool visible);

		// Token: 0x0200074B RID: 1867
		// (Invoke) Token: 0x0600444C RID: 17484
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_cell_renderer_get_sensitive(IntPtr raw);

		// Token: 0x0200074C RID: 1868
		// (Invoke) Token: 0x06004450 RID: 17488
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_set_sensitive(IntPtr raw, bool sensitive);

		// Token: 0x0200074D RID: 1869
		// (Invoke) Token: 0x06004454 RID: 17492
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetRequestModeNativeDelegate(IntPtr inst);

		// Token: 0x0200074E RID: 1870
		// (Invoke) Token: 0x06004458 RID: 17496
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void GetPreferredWidthNativeDelegate(IntPtr inst, IntPtr widget, out int minimum_size, out int natural_size);

		// Token: 0x0200074F RID: 1871
		// (Invoke) Token: 0x0600445C RID: 17500
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void GetPreferredHeightForWidthNativeDelegate(IntPtr inst, IntPtr widget, int width, out int minimum_height, out int natural_height);

		// Token: 0x02000750 RID: 1872
		// (Invoke) Token: 0x06004460 RID: 17504
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void GetPreferredHeightNativeDelegate(IntPtr inst, IntPtr widget, out int minimum_size, out int natural_size);

		// Token: 0x02000751 RID: 1873
		// (Invoke) Token: 0x06004464 RID: 17508
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void GetPreferredWidthForHeightNativeDelegate(IntPtr inst, IntPtr widget, int height, out int minimum_width, out int natural_width);

		// Token: 0x02000752 RID: 1874
		// (Invoke) Token: 0x06004468 RID: 17512
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void GetAlignedAreaNativeDelegate(IntPtr inst, IntPtr widget, int flags, IntPtr cell_area, IntPtr aligned_area);

		// Token: 0x02000753 RID: 1875
		// (Invoke) Token: 0x0600446C RID: 17516
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void RenderNativeDelegate(IntPtr inst, IntPtr cr, IntPtr widget, IntPtr background_area, IntPtr cell_area, int flags);

		// Token: 0x02000754 RID: 1876
		// (Invoke) Token: 0x06004470 RID: 17520
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool ActivateNativeDelegate(IntPtr inst, IntPtr evnt, IntPtr widget, IntPtr path, IntPtr background_area, IntPtr cell_area, int flags);

		// Token: 0x02000755 RID: 1877
		// (Invoke) Token: 0x06004474 RID: 17524
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr StartEditingNativeDelegate(IntPtr inst, IntPtr evnt, IntPtr widget, IntPtr path, IntPtr background_area, IntPtr cell_area, int flags);

		// Token: 0x02000756 RID: 1878
		// (Invoke) Token: 0x06004478 RID: 17528
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void EditingCanceledNativeDelegate(IntPtr inst);

		// Token: 0x02000757 RID: 1879
		// (Invoke) Token: 0x0600447C RID: 17532
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void EditingStartedNativeDelegate(IntPtr inst, IntPtr editable, IntPtr path);

		// Token: 0x02000758 RID: 1880
		// (Invoke) Token: 0x06004480 RID: 17536
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_cell_renderer_activate(IntPtr raw, IntPtr evnt, IntPtr widget, IntPtr path, IntPtr background_area, IntPtr cell_area, int flags);

		// Token: 0x02000759 RID: 1881
		// (Invoke) Token: 0x06004484 RID: 17540
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_get_aligned_area(IntPtr raw, IntPtr widget, int flags, IntPtr cell_area, IntPtr aligned_area);

		// Token: 0x0200075A RID: 1882
		// (Invoke) Token: 0x06004488 RID: 17544
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_get_alignment(IntPtr raw, out float xalign, out float yalign);

		// Token: 0x0200075B RID: 1883
		// (Invoke) Token: 0x0600448C RID: 17548
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_get_fixed_size(IntPtr raw, out int width, out int height);

		// Token: 0x0200075C RID: 1884
		// (Invoke) Token: 0x06004490 RID: 17552
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_get_padding(IntPtr raw, out int xpad, out int ypad);

		// Token: 0x0200075D RID: 1885
		// (Invoke) Token: 0x06004494 RID: 17556
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_get_preferred_height(IntPtr raw, IntPtr widget, out int minimum_size, out int natural_size);

		// Token: 0x0200075E RID: 1886
		// (Invoke) Token: 0x06004498 RID: 17560
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_get_preferred_height_for_width(IntPtr raw, IntPtr widget, int width, out int minimum_height, out int natural_height);

		// Token: 0x0200075F RID: 1887
		// (Invoke) Token: 0x0600449C RID: 17564
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_get_preferred_size(IntPtr raw, IntPtr widget, IntPtr minimum_size, IntPtr natural_size);

		// Token: 0x02000760 RID: 1888
		// (Invoke) Token: 0x060044A0 RID: 17568
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_get_preferred_width(IntPtr raw, IntPtr widget, out int minimum_size, out int natural_size);

		// Token: 0x02000761 RID: 1889
		// (Invoke) Token: 0x060044A4 RID: 17572
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_get_preferred_width_for_height(IntPtr raw, IntPtr widget, int height, out int minimum_width, out int natural_width);

		// Token: 0x02000762 RID: 1890
		// (Invoke) Token: 0x060044A8 RID: 17576
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_cell_renderer_get_request_mode(IntPtr raw);

		// Token: 0x02000763 RID: 1891
		// (Invoke) Token: 0x060044AC RID: 17580
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_cell_renderer_get_state(IntPtr raw, IntPtr widget, int cell_state);

		// Token: 0x02000764 RID: 1892
		// (Invoke) Token: 0x060044B0 RID: 17584
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_renderer_get_type();

		// Token: 0x02000765 RID: 1893
		// (Invoke) Token: 0x060044B4 RID: 17588
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_cell_renderer_is_activatable(IntPtr raw);

		// Token: 0x02000766 RID: 1894
		// (Invoke) Token: 0x060044B8 RID: 17592
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_render(IntPtr raw, IntPtr cr, IntPtr widget, IntPtr background_area, IntPtr cell_area, int flags);

		// Token: 0x02000767 RID: 1895
		// (Invoke) Token: 0x060044BC RID: 17596
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_set_alignment(IntPtr raw, float xalign, float yalign);

		// Token: 0x02000768 RID: 1896
		// (Invoke) Token: 0x060044C0 RID: 17600
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_set_fixed_size(IntPtr raw, int width, int height);

		// Token: 0x02000769 RID: 1897
		// (Invoke) Token: 0x060044C4 RID: 17604
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_set_padding(IntPtr raw, int xpad, int ypad);

		// Token: 0x0200076A RID: 1898
		// (Invoke) Token: 0x060044C8 RID: 17608
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_renderer_stop_editing(IntPtr raw, bool canceled);
	}
}
