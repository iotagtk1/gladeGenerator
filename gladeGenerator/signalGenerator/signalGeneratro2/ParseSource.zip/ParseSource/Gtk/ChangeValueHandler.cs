﻿using System;

namespace Gtk
{
	// Token: 0x02000181 RID: 385
	// (Invoke) Token: 0x0600105C RID: 4188
	public delegate void ChangeValueHandler(object o, ChangeValueArgs args);
}
