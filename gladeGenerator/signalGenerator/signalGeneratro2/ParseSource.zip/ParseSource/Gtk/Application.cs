﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x020000D4 RID: 212
	public class Application : Application
	{
		// Token: 0x06000490 RID: 1168 RVA: 0x0000BDF4 File Offset: 0x00009FF4
		static Application()
		{
			if (!Thread.Supported)
			{
				Thread.Init();
			}
		}

		// Token: 0x06000491 RID: 1169 RVA: 0x0000C144 File Offset: 0x0000A344
		private static void SetPrgname()
		{
			string[] commandLineArgs = Environment.GetCommandLineArgs();
			if (commandLineArgs != null && commandLineArgs.Length != 0)
			{
				GLib.Global.ProgramName = Path.GetFileNameWithoutExtension(commandLineArgs[0]);
			}
		}

		// Token: 0x06000492 RID: 1170 RVA: 0x0000C16C File Offset: 0x0000A36C
		public static void Init()
		{
			Application.SetPrgname();
			IntPtr intPtr = new IntPtr(0);
			int num = 0;
			Application.gtk_init(ref num, ref intPtr);
			SynchronizationContext.SetSynchronizationContext(new GLibSynchronizationContext());
		}

		// Token: 0x06000493 RID: 1171 RVA: 0x0000C1A0 File Offset: 0x0000A3A0
		private static bool do_init(string progname, ref string[] args, bool check)
		{
			Application.SetPrgname();
			bool result = false;
			string[] array = new string[args.Length + 1];
			array[0] = progname;
			args.CopyTo(array, 1);
			Argv argv = new Argv(array);
			IntPtr handle = argv.Handle;
			int num = array.Length;
			if (check)
			{
				result = Application.gtk_init_check(ref num, ref handle);
			}
			else
			{
				Application.gtk_init(ref num, ref handle);
			}
			if (handle != argv.Handle)
			{
				throw new Exception("init returned new argv handle");
			}
			if (num <= 1)
			{
				args = new string[0];
			}
			else
			{
				array = argv.GetArgs(num);
				args = new string[num - 1];
				Array.Copy(array, 1, args, 0, num - 1);
			}
			return result;
		}

		// Token: 0x06000494 RID: 1172 RVA: 0x0000C24D File Offset: 0x0000A44D
		public static void Init(string progname, ref string[] args)
		{
			Application.do_init(progname, ref args, false);
		}

		// Token: 0x06000495 RID: 1173 RVA: 0x0000C258 File Offset: 0x0000A458
		public static bool InitCheck(string progname, ref string[] args)
		{
			return Application.do_init(progname, ref args, true);
		}

		// Token: 0x06000496 RID: 1174 RVA: 0x0000C262 File Offset: 0x0000A462
		public static void Run()
		{
			Application.gtk_main();
		}

		// Token: 0x06000497 RID: 1175 RVA: 0x0000C26E File Offset: 0x0000A46E
		public static bool EventsPending()
		{
			return Application.gtk_events_pending();
		}

		// Token: 0x06000498 RID: 1176 RVA: 0x0000C27A File Offset: 0x0000A47A
		public static void RunIteration()
		{
			Application.gtk_main_iteration();
		}

		// Token: 0x06000499 RID: 1177 RVA: 0x0000C286 File Offset: 0x0000A486
		public static bool RunIteration(bool blocking)
		{
			return Application.gtk_main_iteration_do(blocking);
		}

		// Token: 0x0600049A RID: 1178 RVA: 0x0000C293 File Offset: 0x0000A493
		public static void Quit()
		{
			Application.gtk_main_quit();
		}

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x0600049B RID: 1179 RVA: 0x0000C29F File Offset: 0x0000A49F
		public static Event CurrentEvent
		{
			get
			{
				return Event.GetEvent(Application.gtk_get_current_event());
			}
		}

		// Token: 0x0600049C RID: 1180 RVA: 0x0000C2B0 File Offset: 0x0000A4B0
		public static void Invoke(EventHandler d)
		{
			Application.InvokeCB @object = new Application.InvokeCB(d);
			Timeout.Add(0U, new TimeoutHandler(@object.Invoke));
		}

		// Token: 0x0600049D RID: 1181 RVA: 0x0000C2D8 File Offset: 0x0000A4D8
		public static void Invoke(object sender, EventArgs args, EventHandler d)
		{
			Application.InvokeCB @object = new Application.InvokeCB(d, sender, args);
			Timeout.Add(0U, new TimeoutHandler(@object.Invoke));
		}

		// Token: 0x0600049E RID: 1182 RVA: 0x0000C301 File Offset: 0x0000A501
		public Application(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x0600049F RID: 1183 RVA: 0x0000C30C File Offset: 0x0000A50C
		public Application(string application_id, ApplicationFlags flags) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Application))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				list2.Add("application_id");
				list.Add(new Value(application_id));
				list2.Add("flags");
				list.Add(new Value(flags));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(application_id);
			this.Raw = Application.gtk_application_new(intPtr, (int)flags);
			Marshaller.Free(intPtr);
		}

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x060004A0 RID: 1184 RVA: 0x0000C3AC File Offset: 0x0000A5AC
		// (set) Token: 0x060004A1 RID: 1185 RVA: 0x0000C3D4 File Offset: 0x0000A5D4
		[Property("register-session")]
		public bool RegisterSession
		{
			get
			{
				Value property = base.GetProperty("register-session");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("register-session", val);
				val.Dispose();
			}
		}

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x060004A2 RID: 1186 RVA: 0x0000C3FC File Offset: 0x0000A5FC
		// (set) Token: 0x060004A3 RID: 1187 RVA: 0x0000C418 File Offset: 0x0000A618
		[Property("app-menu")]
		public MenuModel AppMenu
		{
			get
			{
				return Object.GetObject(Application.gtk_application_get_app_menu(base.Handle)) as MenuModel;
			}
			set
			{
				Application.gtk_application_set_app_menu(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x060004A4 RID: 1188 RVA: 0x0000C43A File Offset: 0x0000A63A
		// (set) Token: 0x060004A5 RID: 1189 RVA: 0x0000C456 File Offset: 0x0000A656
		[Property("menubar")]
		public MenuModel Menubar
		{
			get
			{
				return Object.GetObject(Application.gtk_application_get_menubar(base.Handle)) as MenuModel;
			}
			set
			{
				Application.gtk_application_set_menubar(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x060004A6 RID: 1190 RVA: 0x0000C478 File Offset: 0x0000A678
		[Property("active-window")]
		public Window ActiveWindow
		{
			get
			{
				return Object.GetObject(Application.gtk_application_get_active_window(base.Handle)) as Window;
			}
		}

		// Token: 0x14000008 RID: 8
		// (add) Token: 0x060004A7 RID: 1191 RVA: 0x0000C494 File Offset: 0x0000A694
		// (remove) Token: 0x060004A8 RID: 1192 RVA: 0x0000C4AC File Offset: 0x0000A6AC
		[Signal("window-added")]
		public event WindowAddedHandler WindowAdded
		{
			add
			{
				base.AddSignalHandler("window-added", value, typeof(WindowAddedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("window-added", value);
			}
		}

		// Token: 0x14000009 RID: 9
		// (add) Token: 0x060004A9 RID: 1193 RVA: 0x0000C4BA File Offset: 0x0000A6BA
		// (remove) Token: 0x060004AA RID: 1194 RVA: 0x0000C4D2 File Offset: 0x0000A6D2
		[Signal("window-removed")]
		public event WindowRemovedHandler WindowRemoved
		{
			add
			{
				base.AddSignalHandler("window-removed", value, typeof(WindowRemovedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("window-removed", value);
			}
		}

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x060004AB RID: 1195 RVA: 0x0000C4E0 File Offset: 0x0000A6E0
		private static Application.WindowAddedNativeDelegate WindowAddedVMCallback
		{
			get
			{
				if (Application.WindowAdded_cb_delegate == null)
				{
					Application.WindowAdded_cb_delegate = new Application.WindowAddedNativeDelegate(Application.WindowAdded_cb);
				}
				return Application.WindowAdded_cb_delegate;
			}
		}

		// Token: 0x060004AC RID: 1196 RVA: 0x0000C4FF File Offset: 0x0000A6FF
		private static void OverrideWindowAdded(GType gtype)
		{
			Application.OverrideWindowAdded(gtype, Application.WindowAddedVMCallback);
		}

		// Token: 0x060004AD RID: 1197 RVA: 0x0000C50C File Offset: 0x0000A70C
		private unsafe static void OverrideWindowAdded(GType gtype, Application.WindowAddedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Application.class_abi.GetFieldOffset("window_added");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060004AE RID: 1198 RVA: 0x0000C540 File Offset: 0x0000A740
		private static void WindowAdded_cb(IntPtr inst, IntPtr window)
		{
			try
			{
				(Object.GetObject(inst, false) as Application).OnWindowAdded(Object.GetObject(window) as Window);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060004AF RID: 1199 RVA: 0x0000C584 File Offset: 0x0000A784
		[DefaultSignalHandler(Type = typeof(Application), ConnectionMethod = "OverrideWindowAdded")]
		protected virtual void OnWindowAdded(Window window)
		{
			this.InternalWindowAdded(window);
		}

		// Token: 0x060004B0 RID: 1200 RVA: 0x0000C590 File Offset: 0x0000A790
		private void InternalWindowAdded(Window window)
		{
			Application.WindowAddedNativeDelegate windowAddedNativeDelegate = Application.class_abi.BaseOverride(base.LookupGType(), "window_added");
			if (windowAddedNativeDelegate == null)
			{
				return;
			}
			windowAddedNativeDelegate(base.Handle, (window == null) ? IntPtr.Zero : window.Handle);
		}

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x060004B1 RID: 1201 RVA: 0x0000C5D3 File Offset: 0x0000A7D3
		private static Application.WindowRemovedNativeDelegate WindowRemovedVMCallback
		{
			get
			{
				if (Application.WindowRemoved_cb_delegate == null)
				{
					Application.WindowRemoved_cb_delegate = new Application.WindowRemovedNativeDelegate(Application.WindowRemoved_cb);
				}
				return Application.WindowRemoved_cb_delegate;
			}
		}

		// Token: 0x060004B2 RID: 1202 RVA: 0x0000C5F2 File Offset: 0x0000A7F2
		private static void OverrideWindowRemoved(GType gtype)
		{
			Application.OverrideWindowRemoved(gtype, Application.WindowRemovedVMCallback);
		}

		// Token: 0x060004B3 RID: 1203 RVA: 0x0000C600 File Offset: 0x0000A800
		private unsafe static void OverrideWindowRemoved(GType gtype, Application.WindowRemovedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Application.class_abi.GetFieldOffset("window_removed");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060004B4 RID: 1204 RVA: 0x0000C634 File Offset: 0x0000A834
		private static void WindowRemoved_cb(IntPtr inst, IntPtr window)
		{
			try
			{
				(Object.GetObject(inst, false) as Application).OnWindowRemoved(Object.GetObject(window) as Window);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060004B5 RID: 1205 RVA: 0x0000C678 File Offset: 0x0000A878
		[DefaultSignalHandler(Type = typeof(Application), ConnectionMethod = "OverrideWindowRemoved")]
		protected virtual void OnWindowRemoved(Window window)
		{
			this.InternalWindowRemoved(window);
		}

		// Token: 0x060004B6 RID: 1206 RVA: 0x0000C684 File Offset: 0x0000A884
		private void InternalWindowRemoved(Window window)
		{
			Application.WindowRemovedNativeDelegate windowRemovedNativeDelegate = Application.class_abi.BaseOverride(base.LookupGType(), "window_removed");
			if (windowRemovedNativeDelegate == null)
			{
				return;
			}
			windowRemovedNativeDelegate(base.Handle, (window == null) ? IntPtr.Zero : window.Handle);
		}

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x060004B7 RID: 1207 RVA: 0x0000C6C8 File Offset: 0x0000A8C8
		public new static AbiStruct class_abi
		{
			get
			{
				if (Application._class_abi == null)
				{
					Application._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("window_added", Application.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "window_removed", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("window_removed", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "window_added", "padding", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("padding", -1L, (uint)(Marshal.SizeOf(typeof(IntPtr)) * 12), "window_removed", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Application._class_abi;
			}
		}

		// Token: 0x060004B8 RID: 1208 RVA: 0x0000C7AC File Offset: 0x0000A9AC
		[Obsolete]
		public void AddAccelerator(string accelerator, string action_name, Variant parameter)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(accelerator);
			IntPtr intPtr2 = Marshaller.StringToPtrGStrdup(action_name);
			Application.gtk_application_add_accelerator(base.Handle, intPtr, intPtr2, (parameter == null) ? IntPtr.Zero : parameter.Handle);
			Marshaller.Free(intPtr);
			Marshaller.Free(intPtr2);
		}

		// Token: 0x060004B9 RID: 1209 RVA: 0x0000C7F5 File Offset: 0x0000A9F5
		public void AddWindow(Window window)
		{
			Application.gtk_application_add_window(base.Handle, (window == null) ? IntPtr.Zero : window.Handle);
		}

		// Token: 0x060004BA RID: 1210 RVA: 0x0000C818 File Offset: 0x0000AA18
		public string[] GetAccelsForAction(string detailed_action_name)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(detailed_action_name);
			string[] result = Marshaller.NullTermPtrToStringArray(Application.gtk_application_get_accels_for_action(base.Handle, intPtr), false);
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x060004BB RID: 1211 RVA: 0x0000C84C File Offset: 0x0000AA4C
		public string[] GetActionsForAccel(string accel)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(accel);
			string[] result = Marshaller.NullTermPtrToStringArray(Application.gtk_application_get_actions_for_accel(base.Handle, intPtr), false);
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x060004BC RID: 1212 RVA: 0x0000C880 File Offset: 0x0000AA80
		public Menu GetMenuById(string id)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(id);
			Menu result = Object.GetObject(Application.gtk_application_get_menu_by_id(base.Handle, intPtr)) as Menu;
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x060004BD RID: 1213 RVA: 0x0000C8B8 File Offset: 0x0000AAB8
		public new static GType GType
		{
			get
			{
				IntPtr val = Application.gtk_application_get_type();
				return new GType(val);
			}
		}

		// Token: 0x060004BE RID: 1214 RVA: 0x0000C8D6 File Offset: 0x0000AAD6
		public Window GetWindowById(uint id)
		{
			return Object.GetObject(Application.gtk_application_get_window_by_id(base.Handle, id)) as Window;
		}

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x060004BF RID: 1215 RVA: 0x0000C8F3 File Offset: 0x0000AAF3
		public Window[] Windows
		{
			get
			{
				return (Window[])Marshaller.ListPtrToArray(Application.gtk_application_get_windows(base.Handle), typeof(List), false, false, typeof(Window));
			}
		}

		// Token: 0x060004C0 RID: 1216 RVA: 0x0000C928 File Offset: 0x0000AB28
		public uint Inhibit(Window window, ApplicationInhibitFlags flags, string reason)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(reason);
			uint result = Application.gtk_application_inhibit(base.Handle, (window == null) ? IntPtr.Zero : window.Handle, (int)flags, intPtr);
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x060004C1 RID: 1217 RVA: 0x0000C964 File Offset: 0x0000AB64
		public bool IsInhibited(ApplicationInhibitFlags flags)
		{
			return Application.gtk_application_is_inhibited(base.Handle, (int)flags);
		}

		// Token: 0x060004C2 RID: 1218 RVA: 0x0000C977 File Offset: 0x0000AB77
		public string ListActionDescriptions()
		{
			return Marshaller.PtrToStringGFree(Application.gtk_application_list_action_descriptions(base.Handle));
		}

		// Token: 0x060004C3 RID: 1219 RVA: 0x0000C98E File Offset: 0x0000AB8E
		public bool PrefersAppMenu()
		{
			return Application.gtk_application_prefers_app_menu(base.Handle);
		}

		// Token: 0x060004C4 RID: 1220 RVA: 0x0000C9A0 File Offset: 0x0000ABA0
		[Obsolete]
		public void RemoveAccelerator(string action_name, Variant parameter)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			Application.gtk_application_remove_accelerator(base.Handle, intPtr, (parameter == null) ? IntPtr.Zero : parameter.Handle);
			Marshaller.Free(intPtr);
		}

		// Token: 0x060004C5 RID: 1221 RVA: 0x0000C9DB File Offset: 0x0000ABDB
		public void RemoveWindow(Window window)
		{
			Application.gtk_application_remove_window(base.Handle, (window == null) ? IntPtr.Zero : window.Handle);
		}

		// Token: 0x060004C6 RID: 1222 RVA: 0x0000CA00 File Offset: 0x0000AC00
		public void SetAccelsForAction(string detailed_action_name, string[] accels)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(detailed_action_name);
			int num = (accels == null) ? 0 : accels.Length;
			IntPtr[] array = new IntPtr[num + 1];
			for (int i = 0; i < num; i++)
			{
				array[i] = Marshaller.StringToPtrGStrdup(accels[i]);
			}
			array[num] = IntPtr.Zero;
			Application.gtk_application_set_accels_for_action(base.Handle, intPtr, array);
			Marshaller.Free(intPtr);
			for (int j = 0; j < array.Length - 1; j++)
			{
				accels[j] = Marshaller.Utf8PtrToString(array[j]);
				Marshaller.Free(array[j]);
			}
		}

		// Token: 0x060004C7 RID: 1223 RVA: 0x0000CA88 File Offset: 0x0000AC88
		public void Uninhibit(uint cookie)
		{
			Application.gtk_application_uninhibit(base.Handle, cookie);
		}

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x060004C8 RID: 1224 RVA: 0x0000CA9C File Offset: 0x0000AC9C
		public new static AbiStruct abi_info
		{
			get
			{
				if (Application._abi_info == null)
				{
					Application._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Application.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Application._abi_info;
			}
		}

		// Token: 0x04000262 RID: 610
		private const int WS_EX_TOOLWINDOW = 128;

		// Token: 0x04000263 RID: 611
		private const int WS_OVERLAPPEDWINDOW = 13565952;

		// Token: 0x04000264 RID: 612
		private static Application.d_gtk_init gtk_init = FuncLoader.LoadFunction<Application.d_gtk_init>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_init"));

		// Token: 0x04000265 RID: 613
		private static Application.d_gtk_init_check gtk_init_check = FuncLoader.LoadFunction<Application.d_gtk_init_check>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_init_check"));

		// Token: 0x04000266 RID: 614
		private static Application.d_gtk_main gtk_main = FuncLoader.LoadFunction<Application.d_gtk_main>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_main"));

		// Token: 0x04000267 RID: 615
		private static Application.d_gtk_events_pending gtk_events_pending = FuncLoader.LoadFunction<Application.d_gtk_events_pending>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_events_pending"));

		// Token: 0x04000268 RID: 616
		private static Application.d_gtk_main_iteration gtk_main_iteration = FuncLoader.LoadFunction<Application.d_gtk_main_iteration>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_main_iteration"));

		// Token: 0x04000269 RID: 617
		private static Application.d_gtk_main_iteration_do gtk_main_iteration_do = FuncLoader.LoadFunction<Application.d_gtk_main_iteration_do>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_main_iteration_do"));

		// Token: 0x0400026A RID: 618
		private static Application.d_gtk_main_quit gtk_main_quit = FuncLoader.LoadFunction<Application.d_gtk_main_quit>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_main_quit"));

		// Token: 0x0400026B RID: 619
		private static Application.d_gtk_get_current_event gtk_get_current_event = FuncLoader.LoadFunction<Application.d_gtk_get_current_event>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_get_current_event"));

		// Token: 0x0400026C RID: 620
		private static Application.d_gtk_application_new gtk_application_new = FuncLoader.LoadFunction<Application.d_gtk_application_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_new"));

		// Token: 0x0400026D RID: 621
		private static Application.d_gtk_application_get_app_menu gtk_application_get_app_menu = FuncLoader.LoadFunction<Application.d_gtk_application_get_app_menu>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_get_app_menu"));

		// Token: 0x0400026E RID: 622
		private static Application.d_gtk_application_set_app_menu gtk_application_set_app_menu = FuncLoader.LoadFunction<Application.d_gtk_application_set_app_menu>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_set_app_menu"));

		// Token: 0x0400026F RID: 623
		private static Application.d_gtk_application_get_menubar gtk_application_get_menubar = FuncLoader.LoadFunction<Application.d_gtk_application_get_menubar>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_get_menubar"));

		// Token: 0x04000270 RID: 624
		private static Application.d_gtk_application_set_menubar gtk_application_set_menubar = FuncLoader.LoadFunction<Application.d_gtk_application_set_menubar>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_set_menubar"));

		// Token: 0x04000271 RID: 625
		private static Application.d_gtk_application_get_active_window gtk_application_get_active_window = FuncLoader.LoadFunction<Application.d_gtk_application_get_active_window>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_get_active_window"));

		// Token: 0x04000272 RID: 626
		private static Application.WindowAddedNativeDelegate WindowAdded_cb_delegate;

		// Token: 0x04000273 RID: 627
		private static Application.WindowRemovedNativeDelegate WindowRemoved_cb_delegate;

		// Token: 0x04000274 RID: 628
		private static AbiStruct _class_abi = null;

		// Token: 0x04000275 RID: 629
		private static Application.d_gtk_application_add_accelerator gtk_application_add_accelerator = FuncLoader.LoadFunction<Application.d_gtk_application_add_accelerator>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_add_accelerator"));

		// Token: 0x04000276 RID: 630
		private static Application.d_gtk_application_add_window gtk_application_add_window = FuncLoader.LoadFunction<Application.d_gtk_application_add_window>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_add_window"));

		// Token: 0x04000277 RID: 631
		private static Application.d_gtk_application_get_accels_for_action gtk_application_get_accels_for_action = FuncLoader.LoadFunction<Application.d_gtk_application_get_accels_for_action>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_get_accels_for_action"));

		// Token: 0x04000278 RID: 632
		private static Application.d_gtk_application_get_actions_for_accel gtk_application_get_actions_for_accel = FuncLoader.LoadFunction<Application.d_gtk_application_get_actions_for_accel>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_get_actions_for_accel"));

		// Token: 0x04000279 RID: 633
		private static Application.d_gtk_application_get_menu_by_id gtk_application_get_menu_by_id = FuncLoader.LoadFunction<Application.d_gtk_application_get_menu_by_id>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_get_menu_by_id"));

		// Token: 0x0400027A RID: 634
		private static Application.d_gtk_application_get_type gtk_application_get_type = FuncLoader.LoadFunction<Application.d_gtk_application_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_get_type"));

		// Token: 0x0400027B RID: 635
		private static Application.d_gtk_application_get_window_by_id gtk_application_get_window_by_id = FuncLoader.LoadFunction<Application.d_gtk_application_get_window_by_id>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_get_window_by_id"));

		// Token: 0x0400027C RID: 636
		private static Application.d_gtk_application_get_windows gtk_application_get_windows = FuncLoader.LoadFunction<Application.d_gtk_application_get_windows>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_get_windows"));

		// Token: 0x0400027D RID: 637
		private static Application.d_gtk_application_inhibit gtk_application_inhibit = FuncLoader.LoadFunction<Application.d_gtk_application_inhibit>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_inhibit"));

		// Token: 0x0400027E RID: 638
		private static Application.d_gtk_application_is_inhibited gtk_application_is_inhibited = FuncLoader.LoadFunction<Application.d_gtk_application_is_inhibited>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_is_inhibited"));

		// Token: 0x0400027F RID: 639
		private static Application.d_gtk_application_list_action_descriptions gtk_application_list_action_descriptions = FuncLoader.LoadFunction<Application.d_gtk_application_list_action_descriptions>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_list_action_descriptions"));

		// Token: 0x04000280 RID: 640
		private static Application.d_gtk_application_prefers_app_menu gtk_application_prefers_app_menu = FuncLoader.LoadFunction<Application.d_gtk_application_prefers_app_menu>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_prefers_app_menu"));

		// Token: 0x04000281 RID: 641
		private static Application.d_gtk_application_remove_accelerator gtk_application_remove_accelerator = FuncLoader.LoadFunction<Application.d_gtk_application_remove_accelerator>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_remove_accelerator"));

		// Token: 0x04000282 RID: 642
		private static Application.d_gtk_application_remove_window gtk_application_remove_window = FuncLoader.LoadFunction<Application.d_gtk_application_remove_window>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_remove_window"));

		// Token: 0x04000283 RID: 643
		private static Application.d_gtk_application_set_accels_for_action gtk_application_set_accels_for_action = FuncLoader.LoadFunction<Application.d_gtk_application_set_accels_for_action>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_set_accels_for_action"));

		// Token: 0x04000284 RID: 644
		private static Application.d_gtk_application_uninhibit gtk_application_uninhibit = FuncLoader.LoadFunction<Application.d_gtk_application_uninhibit>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_application_uninhibit"));

		// Token: 0x04000285 RID: 645
		private static AbiStruct _abi_info = null;

		// Token: 0x020006A4 RID: 1700
		// (Invoke) Token: 0x060041AA RID: 16810
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_init(ref int argc, ref IntPtr argv);

		// Token: 0x020006A5 RID: 1701
		// (Invoke) Token: 0x060041AE RID: 16814
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_init_check(ref int argc, ref IntPtr argv);

		// Token: 0x020006A6 RID: 1702
		// (Invoke) Token: 0x060041B2 RID: 16818
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_main();

		// Token: 0x020006A7 RID: 1703
		// (Invoke) Token: 0x060041B6 RID: 16822
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_events_pending();

		// Token: 0x020006A8 RID: 1704
		// (Invoke) Token: 0x060041BA RID: 16826
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_main_iteration();

		// Token: 0x020006A9 RID: 1705
		// (Invoke) Token: 0x060041BE RID: 16830
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_main_iteration_do(bool blocking);

		// Token: 0x020006AA RID: 1706
		// (Invoke) Token: 0x060041C2 RID: 16834
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_main_quit();

		// Token: 0x020006AB RID: 1707
		// (Invoke) Token: 0x060041C6 RID: 16838
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_get_current_event();

		// Token: 0x020006AC RID: 1708
		internal class InvokeCB
		{
			// Token: 0x060041C9 RID: 16841 RVA: 0x000B5DE9 File Offset: 0x000B3FE9
			internal InvokeCB(EventHandler d)
			{
				this.d = d;
				this.args = EventArgs.Empty;
				this.sender = this;
			}

			// Token: 0x060041CA RID: 16842 RVA: 0x000B5E0A File Offset: 0x000B400A
			internal InvokeCB(EventHandler d, object sender, EventArgs args)
			{
				this.d = d;
				this.args = args;
				this.sender = sender;
			}

			// Token: 0x060041CB RID: 16843 RVA: 0x000B5E27 File Offset: 0x000B4027
			internal bool Invoke()
			{
				this.d(this.sender, this.args);
				return false;
			}

			// Token: 0x04001E32 RID: 7730
			private EventHandler d;

			// Token: 0x04001E33 RID: 7731
			private object sender;

			// Token: 0x04001E34 RID: 7732
			private EventArgs args;
		}

		// Token: 0x020006AD RID: 1709
		// (Invoke) Token: 0x060041CD RID: 16845
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_application_new(IntPtr application_id, int flags);

		// Token: 0x020006AE RID: 1710
		// (Invoke) Token: 0x060041D1 RID: 16849
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_application_get_app_menu(IntPtr raw);

		// Token: 0x020006AF RID: 1711
		// (Invoke) Token: 0x060041D5 RID: 16853
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_application_set_app_menu(IntPtr raw, IntPtr app_menu);

		// Token: 0x020006B0 RID: 1712
		// (Invoke) Token: 0x060041D9 RID: 16857
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_application_get_menubar(IntPtr raw);

		// Token: 0x020006B1 RID: 1713
		// (Invoke) Token: 0x060041DD RID: 16861
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_application_set_menubar(IntPtr raw, IntPtr menubar);

		// Token: 0x020006B2 RID: 1714
		// (Invoke) Token: 0x060041E1 RID: 16865
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_application_get_active_window(IntPtr raw);

		// Token: 0x020006B3 RID: 1715
		// (Invoke) Token: 0x060041E5 RID: 16869
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void WindowAddedNativeDelegate(IntPtr inst, IntPtr window);

		// Token: 0x020006B4 RID: 1716
		// (Invoke) Token: 0x060041E9 RID: 16873
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void WindowRemovedNativeDelegate(IntPtr inst, IntPtr window);

		// Token: 0x020006B5 RID: 1717
		// (Invoke) Token: 0x060041ED RID: 16877
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_application_add_accelerator(IntPtr raw, IntPtr accelerator, IntPtr action_name, IntPtr parameter);

		// Token: 0x020006B6 RID: 1718
		// (Invoke) Token: 0x060041F1 RID: 16881
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_application_add_window(IntPtr raw, IntPtr window);

		// Token: 0x020006B7 RID: 1719
		// (Invoke) Token: 0x060041F5 RID: 16885
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_application_get_accels_for_action(IntPtr raw, IntPtr detailed_action_name);

		// Token: 0x020006B8 RID: 1720
		// (Invoke) Token: 0x060041F9 RID: 16889
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_application_get_actions_for_accel(IntPtr raw, IntPtr accel);

		// Token: 0x020006B9 RID: 1721
		// (Invoke) Token: 0x060041FD RID: 16893
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_application_get_menu_by_id(IntPtr raw, IntPtr id);

		// Token: 0x020006BA RID: 1722
		// (Invoke) Token: 0x06004201 RID: 16897
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_application_get_type();

		// Token: 0x020006BB RID: 1723
		// (Invoke) Token: 0x06004205 RID: 16901
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_application_get_window_by_id(IntPtr raw, uint id);

		// Token: 0x020006BC RID: 1724
		// (Invoke) Token: 0x06004209 RID: 16905
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_application_get_windows(IntPtr raw);

		// Token: 0x020006BD RID: 1725
		// (Invoke) Token: 0x0600420D RID: 16909
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gtk_application_inhibit(IntPtr raw, IntPtr window, int flags, IntPtr reason);

		// Token: 0x020006BE RID: 1726
		// (Invoke) Token: 0x06004211 RID: 16913
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_application_is_inhibited(IntPtr raw, int flags);

		// Token: 0x020006BF RID: 1727
		// (Invoke) Token: 0x06004215 RID: 16917
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_application_list_action_descriptions(IntPtr raw);

		// Token: 0x020006C0 RID: 1728
		// (Invoke) Token: 0x06004219 RID: 16921
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_application_prefers_app_menu(IntPtr raw);

		// Token: 0x020006C1 RID: 1729
		// (Invoke) Token: 0x0600421D RID: 16925
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_application_remove_accelerator(IntPtr raw, IntPtr action_name, IntPtr parameter);

		// Token: 0x020006C2 RID: 1730
		// (Invoke) Token: 0x06004221 RID: 16929
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_application_remove_window(IntPtr raw, IntPtr window);

		// Token: 0x020006C3 RID: 1731
		// (Invoke) Token: 0x06004225 RID: 16933
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_application_set_accels_for_action(IntPtr raw, IntPtr detailed_action_name, IntPtr[] accels);

		// Token: 0x020006C4 RID: 1732
		// (Invoke) Token: 0x06004229 RID: 16937
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_application_uninhibit(IntPtr raw, uint cookie);
	}
}
