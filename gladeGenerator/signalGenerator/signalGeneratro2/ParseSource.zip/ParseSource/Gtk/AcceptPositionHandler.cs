﻿using System;

namespace Gtk
{
	// Token: 0x02000102 RID: 258
	// (Invoke) Token: 0x06000B8B RID: 2955
	public delegate void AcceptPositionHandler(object o, AcceptPositionArgs args);
}
