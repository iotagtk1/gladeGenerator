﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x0200019D RID: 413
	public class ColorEditor : Opaque
	{
		// Token: 0x0600111B RID: 4379 RVA: 0x0003367A File Offset: 0x0003187A
		public ColorEditor(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170003F4 RID: 1012
		// (get) Token: 0x0600111C RID: 4380 RVA: 0x00033683 File Offset: 0x00031883
		public static AbiStruct abi_info
		{
			get
			{
				if (ColorEditor._abi_info == null)
				{
					ColorEditor._abi_info = new AbiStruct(new List<AbiField>());
				}
				return ColorEditor._abi_info;
			}
		}

		// Token: 0x04000807 RID: 2055
		private static AbiStruct _abi_info;
	}
}
