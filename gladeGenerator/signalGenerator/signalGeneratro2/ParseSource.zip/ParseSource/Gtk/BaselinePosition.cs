﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000138 RID: 312
	[GType(typeof(BaselinePositionGType))]
	public enum BaselinePosition
	{
		// Token: 0x040006BD RID: 1725
		Top,
		// Token: 0x040006BE RID: 1726
		Center,
		// Token: 0x040006BF RID: 1727
		Bottom
	}
}
