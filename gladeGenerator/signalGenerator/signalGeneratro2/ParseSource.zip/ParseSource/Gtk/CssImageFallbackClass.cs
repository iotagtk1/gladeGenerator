﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001CE RID: 462
	public class CssImageFallbackClass : Opaque
	{
		// Token: 0x06001197 RID: 4503 RVA: 0x00033EB9 File Offset: 0x000320B9
		public CssImageFallbackClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700041F RID: 1055
		// (get) Token: 0x06001198 RID: 4504 RVA: 0x00033EC2 File Offset: 0x000320C2
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImageFallbackClass._abi_info == null)
				{
					CssImageFallbackClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImageFallbackClass._abi_info;
			}
		}

		// Token: 0x0400082E RID: 2094
		private static AbiStruct _abi_info;
	}
}
