﻿using System;

namespace Gtk
{
	// Token: 0x02000218 RID: 536
	// (Invoke) Token: 0x06001258 RID: 4696
	public delegate void CycleHandleFocusHandler(object o, CycleHandleFocusArgs args);
}
