﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x0200010A RID: 266
	public class ActionMuxer : Object, IActionGroup, IWrapper, IActionObservable
	{
		// Token: 0x06000BE1 RID: 3041 RVA: 0x000240BB File Offset: 0x000222BB
		public ActionMuxer(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000BE2 RID: 3042 RVA: 0x000240C4 File Offset: 0x000222C4
		public ActionMuxer() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(ActionMuxer))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = ActionMuxer.gtk_action_muxer_new();
		}

		// Token: 0x1700027C RID: 636
		// (get) Token: 0x06000BE3 RID: 3043 RVA: 0x00024116 File Offset: 0x00022316
		// (set) Token: 0x06000BE4 RID: 3044 RVA: 0x00024132 File Offset: 0x00022332
		[Property("parent")]
		public ActionMuxer Parent
		{
			get
			{
				return Object.GetObject(ActionMuxer.gtk_action_muxer_get_parent(base.Handle)) as ActionMuxer;
			}
			set
			{
				ActionMuxer.gtk_action_muxer_set_parent(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x1400004E RID: 78
		// (add) Token: 0x06000BE5 RID: 3045 RVA: 0x00024154 File Offset: 0x00022354
		// (remove) Token: 0x06000BE6 RID: 3046 RVA: 0x0002416C File Offset: 0x0002236C
		[Signal("primary-accel-changed")]
		public event PrimaryAccelChangedHandler PrimaryAccelChanged
		{
			add
			{
				base.AddSignalHandler("primary-accel-changed", value, typeof(PrimaryAccelChangedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("primary-accel-changed", value);
			}
		}

		// Token: 0x1700027D RID: 637
		// (get) Token: 0x06000BE7 RID: 3047 RVA: 0x0002417A File Offset: 0x0002237A
		private static ActionMuxer.PrimaryAccelChangedNativeDelegate PrimaryAccelChangedVMCallback
		{
			get
			{
				if (ActionMuxer.PrimaryAccelChanged_cb_delegate == null)
				{
					ActionMuxer.PrimaryAccelChanged_cb_delegate = new ActionMuxer.PrimaryAccelChangedNativeDelegate(ActionMuxer.PrimaryAccelChanged_cb);
				}
				return ActionMuxer.PrimaryAccelChanged_cb_delegate;
			}
		}

		// Token: 0x06000BE8 RID: 3048 RVA: 0x00024199 File Offset: 0x00022399
		private static void OverridePrimaryAccelChanged(GType gtype)
		{
			ActionMuxer.OverridePrimaryAccelChanged(gtype, ActionMuxer.PrimaryAccelChangedVMCallback);
		}

		// Token: 0x06000BE9 RID: 3049 RVA: 0x000241A6 File Offset: 0x000223A6
		private static void OverridePrimaryAccelChanged(GType gtype, ActionMuxer.PrimaryAccelChangedNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "primary-accel-changed", callback);
		}

		// Token: 0x06000BEA RID: 3050 RVA: 0x000241B4 File Offset: 0x000223B4
		private static void PrimaryAccelChanged_cb(IntPtr inst, IntPtr p0, IntPtr p1)
		{
			try
			{
				(Object.GetObject(inst, false) as ActionMuxer).OnPrimaryAccelChanged(Marshaller.PtrToStringGFree(p0), Marshaller.PtrToStringGFree(p1));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000BEB RID: 3051 RVA: 0x000241F8 File Offset: 0x000223F8
		[DefaultSignalHandler(Type = typeof(ActionMuxer), ConnectionMethod = "OverridePrimaryAccelChanged")]
		protected virtual void OnPrimaryAccelChanged(string p0, string p1)
		{
			this.InternalPrimaryAccelChanged(p0, p1);
		}

		// Token: 0x06000BEC RID: 3052 RVA: 0x00024204 File Offset: 0x00022404
		private void InternalPrimaryAccelChanged(string p0, string p1)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(3U);
			Value[] array = new Value[3];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(p0);
			valueArray.Append(array[1]);
			array[2] = new Value(p1);
			valueArray.Append(array[2]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x06000BED RID: 3053 RVA: 0x000242AC File Offset: 0x000224AC
		public string GetPrimaryAccel(string action_and_target)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_and_target);
			string result = Marshaller.Utf8PtrToString(ActionMuxer.gtk_action_muxer_get_primary_accel(base.Handle, intPtr));
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x1700027E RID: 638
		// (get) Token: 0x06000BEE RID: 3054 RVA: 0x000242DC File Offset: 0x000224DC
		public new static GType GType
		{
			get
			{
				IntPtr val = ActionMuxer.gtk_action_muxer_get_type();
				return new GType(val);
			}
		}

		// Token: 0x06000BEF RID: 3055 RVA: 0x000242FC File Offset: 0x000224FC
		public void Insert(string prefix, IActionGroup action_group)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(prefix);
			ActionMuxer.gtk_action_muxer_insert(base.Handle, intPtr, (action_group == null) ? IntPtr.Zero : ((action_group is Object) ? (action_group as Object).Handle : (action_group as ActionGroupAdapter).Handle));
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000BF0 RID: 3056 RVA: 0x00024351 File Offset: 0x00022551
		public string ListPrefixes()
		{
			return Marshaller.Utf8PtrToString(ActionMuxer.gtk_action_muxer_list_prefixes(base.Handle));
		}

		// Token: 0x06000BF1 RID: 3057 RVA: 0x00024368 File Offset: 0x00022568
		public IActionGroup Lookup(string prefix)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(prefix);
			IActionGroup @object = ActionGroupAdapter.GetObject(ActionMuxer.gtk_action_muxer_lookup(base.Handle, intPtr), false);
			Marshaller.Free(intPtr);
			return @object;
		}

		// Token: 0x06000BF2 RID: 3058 RVA: 0x0002439C File Offset: 0x0002259C
		public void Remove(string prefix)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(prefix);
			ActionMuxer.gtk_action_muxer_remove(base.Handle, intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000BF3 RID: 3059 RVA: 0x000243C8 File Offset: 0x000225C8
		public void SetPrimaryAccel(string action_and_target, string primary_accel)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_and_target);
			IntPtr intPtr2 = Marshaller.StringToPtrGStrdup(primary_accel);
			ActionMuxer.gtk_action_muxer_set_primary_accel(base.Handle, intPtr, intPtr2);
			Marshaller.Free(intPtr);
			Marshaller.Free(intPtr2);
		}

		// Token: 0x06000BF4 RID: 3060 RVA: 0x00024404 File Offset: 0x00022604
		public void EmitActionAdded(string action_name)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			ActionMuxer.g_action_group_action_added(base.Handle, intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000BF5 RID: 3061 RVA: 0x00024430 File Offset: 0x00022630
		public void EmitActionEnabledChanged(string action_name, bool enabled)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			ActionMuxer.g_action_group_action_enabled_changed(base.Handle, intPtr, enabled);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000BF6 RID: 3062 RVA: 0x0002445C File Offset: 0x0002265C
		public void EmitActionRemoved(string action_name)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			ActionMuxer.g_action_group_action_removed(base.Handle, intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000BF7 RID: 3063 RVA: 0x00024488 File Offset: 0x00022688
		public void EmitActionStateChanged(string action_name, Variant state)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			ActionMuxer.g_action_group_action_state_changed(base.Handle, intPtr, (state == null) ? IntPtr.Zero : state.Handle);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000BF8 RID: 3064 RVA: 0x000244C4 File Offset: 0x000226C4
		public void ActivateAction(string action_name, Variant parameter)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			ActionMuxer.g_action_group_activate_action(base.Handle, intPtr, (parameter == null) ? IntPtr.Zero : parameter.Handle);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000BF9 RID: 3065 RVA: 0x00024500 File Offset: 0x00022700
		public void ChangeActionState(string action_name, Variant value)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			ActionMuxer.g_action_group_change_action_state(base.Handle, intPtr, (value == null) ? IntPtr.Zero : value.Handle);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000BFA RID: 3066 RVA: 0x0002453C File Offset: 0x0002273C
		public bool GetActionEnabled(string action_name)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			bool result = ActionMuxer.g_action_group_get_action_enabled(base.Handle, intPtr);
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x06000BFB RID: 3067 RVA: 0x00024568 File Offset: 0x00022768
		public VariantType GetActionParameterType(string action_name)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			VariantType result = new VariantType(ActionMuxer.g_action_group_get_action_parameter_type(base.Handle, intPtr));
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x06000BFC RID: 3068 RVA: 0x00024598 File Offset: 0x00022798
		public Variant GetActionState(string action_name)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			Variant result = new Variant(ActionMuxer.g_action_group_get_action_state(base.Handle, intPtr));
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x06000BFD RID: 3069 RVA: 0x000245C8 File Offset: 0x000227C8
		public Variant GetActionStateHint(string action_name)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			Variant result = new Variant(ActionMuxer.g_action_group_get_action_state_hint(base.Handle, intPtr));
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x06000BFE RID: 3070 RVA: 0x000245F8 File Offset: 0x000227F8
		public VariantType GetActionStateType(string action_name)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			VariantType result = new VariantType(ActionMuxer.g_action_group_get_action_state_type(base.Handle, intPtr));
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x06000BFF RID: 3071 RVA: 0x00024628 File Offset: 0x00022828
		public bool HasAction(string action_name)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			bool result = ActionMuxer.g_action_group_has_action(base.Handle, intPtr);
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x06000C00 RID: 3072 RVA: 0x00024653 File Offset: 0x00022853
		public string[] ListActions()
		{
			return Marshaller.NullTermPtrToStringArray(ActionMuxer.g_action_group_list_actions(base.Handle), true);
		}

		// Token: 0x06000C01 RID: 3073 RVA: 0x0002466C File Offset: 0x0002286C
		public bool QueryAction(string action_name, out bool enabled, VariantType parameter_type, VariantType state_type, Variant state_hint, Variant state)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			bool result = ActionMuxer.g_action_group_query_action(base.Handle, intPtr, out enabled, (parameter_type == null) ? IntPtr.Zero : parameter_type.Handle, (state_type == null) ? IntPtr.Zero : state_type.Handle, (state_hint == null) ? IntPtr.Zero : state_hint.Handle, (state == null) ? IntPtr.Zero : state.Handle);
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x1400004F RID: 79
		// (add) Token: 0x06000C02 RID: 3074 RVA: 0x000246DE File Offset: 0x000228DE
		// (remove) Token: 0x06000C03 RID: 3075 RVA: 0x000246F6 File Offset: 0x000228F6
		[Signal("action-removed")]
		public event ActionRemovedHandler ActionRemoved
		{
			add
			{
				base.AddSignalHandler("action-removed", value, typeof(ActionRemovedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("action-removed", value);
			}
		}

		// Token: 0x14000050 RID: 80
		// (add) Token: 0x06000C04 RID: 3076 RVA: 0x00024704 File Offset: 0x00022904
		// (remove) Token: 0x06000C05 RID: 3077 RVA: 0x0002471C File Offset: 0x0002291C
		[Signal("action-enabled-changed")]
		public event ActionEnabledChangedHandler ActionEnabledChanged
		{
			add
			{
				base.AddSignalHandler("action-enabled-changed", value, typeof(ActionEnabledChangedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("action-enabled-changed", value);
			}
		}

		// Token: 0x14000051 RID: 81
		// (add) Token: 0x06000C06 RID: 3078 RVA: 0x0002472A File Offset: 0x0002292A
		// (remove) Token: 0x06000C07 RID: 3079 RVA: 0x00024742 File Offset: 0x00022942
		[Signal("action-state-changed")]
		public event ActionStateChangedHandler ActionStateChanged
		{
			add
			{
				base.AddSignalHandler("action-state-changed", value, typeof(ActionStateChangedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("action-state-changed", value);
			}
		}

		// Token: 0x14000052 RID: 82
		// (add) Token: 0x06000C08 RID: 3080 RVA: 0x00024750 File Offset: 0x00022950
		// (remove) Token: 0x06000C09 RID: 3081 RVA: 0x00024768 File Offset: 0x00022968
		[Signal("action-added")]
		public event ActionAddedHandler ActionAdded
		{
			add
			{
				base.AddSignalHandler("action-added", value, typeof(ActionAddedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("action-added", value);
			}
		}

		// Token: 0x1700027F RID: 639
		// (get) Token: 0x06000C0A RID: 3082 RVA: 0x00024776 File Offset: 0x00022976
		private static ActionMuxer.ActionAddedNativeDelegate ActionAddedVMCallback
		{
			get
			{
				if (ActionMuxer.ActionAdded_cb_delegate == null)
				{
					ActionMuxer.ActionAdded_cb_delegate = new ActionMuxer.ActionAddedNativeDelegate(ActionMuxer.ActionAdded_cb);
				}
				return ActionMuxer.ActionAdded_cb_delegate;
			}
		}

		// Token: 0x06000C0B RID: 3083 RVA: 0x00024795 File Offset: 0x00022995
		private static void OverrideActionAdded(GType gtype)
		{
			ActionMuxer.OverrideActionAdded(gtype, ActionMuxer.ActionAddedVMCallback);
		}

		// Token: 0x06000C0C RID: 3084 RVA: 0x000247A2 File Offset: 0x000229A2
		private static void OverrideActionAdded(GType gtype, ActionMuxer.ActionAddedNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "action-added", callback);
		}

		// Token: 0x06000C0D RID: 3085 RVA: 0x000247B0 File Offset: 0x000229B0
		private static void ActionAdded_cb(IntPtr inst, IntPtr action_name)
		{
			try
			{
				(Object.GetObject(inst, false) as ActionMuxer).OnActionAdded(Marshaller.Utf8PtrToString(action_name));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000C0E RID: 3086 RVA: 0x000247F0 File Offset: 0x000229F0
		[DefaultSignalHandler(Type = typeof(ActionMuxer), ConnectionMethod = "OverrideActionAdded")]
		protected virtual void OnActionAdded(string action_name)
		{
			this.InternalActionAdded(action_name);
		}

		// Token: 0x06000C0F RID: 3087 RVA: 0x000247FC File Offset: 0x000229FC
		private void InternalActionAdded(string action_name)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(2U);
			Value[] array = new Value[2];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(action_name);
			valueArray.Append(array[1]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x17000280 RID: 640
		// (get) Token: 0x06000C10 RID: 3088 RVA: 0x00024888 File Offset: 0x00022A88
		private static ActionMuxer.ActionRemovedNativeDelegate ActionRemovedVMCallback
		{
			get
			{
				if (ActionMuxer.ActionRemoved_cb_delegate == null)
				{
					ActionMuxer.ActionRemoved_cb_delegate = new ActionMuxer.ActionRemovedNativeDelegate(ActionMuxer.ActionRemoved_cb);
				}
				return ActionMuxer.ActionRemoved_cb_delegate;
			}
		}

		// Token: 0x06000C11 RID: 3089 RVA: 0x000248A7 File Offset: 0x00022AA7
		private static void OverrideActionRemoved(GType gtype)
		{
			ActionMuxer.OverrideActionRemoved(gtype, ActionMuxer.ActionRemovedVMCallback);
		}

		// Token: 0x06000C12 RID: 3090 RVA: 0x000248B4 File Offset: 0x00022AB4
		private static void OverrideActionRemoved(GType gtype, ActionMuxer.ActionRemovedNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "action-removed", callback);
		}

		// Token: 0x06000C13 RID: 3091 RVA: 0x000248C4 File Offset: 0x00022AC4
		private static void ActionRemoved_cb(IntPtr inst, IntPtr action_name)
		{
			try
			{
				(Object.GetObject(inst, false) as ActionMuxer).OnActionRemoved(Marshaller.Utf8PtrToString(action_name));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000C14 RID: 3092 RVA: 0x00024904 File Offset: 0x00022B04
		[DefaultSignalHandler(Type = typeof(ActionMuxer), ConnectionMethod = "OverrideActionRemoved")]
		protected virtual void OnActionRemoved(string action_name)
		{
			this.InternalActionRemoved(action_name);
		}

		// Token: 0x06000C15 RID: 3093 RVA: 0x00024910 File Offset: 0x00022B10
		private void InternalActionRemoved(string action_name)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(2U);
			Value[] array = new Value[2];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(action_name);
			valueArray.Append(array[1]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x17000281 RID: 641
		// (get) Token: 0x06000C16 RID: 3094 RVA: 0x0002499C File Offset: 0x00022B9C
		private static ActionMuxer.ActionEnabledChangedNativeDelegate ActionEnabledChangedVMCallback
		{
			get
			{
				if (ActionMuxer.ActionEnabledChanged_cb_delegate == null)
				{
					ActionMuxer.ActionEnabledChanged_cb_delegate = new ActionMuxer.ActionEnabledChangedNativeDelegate(ActionMuxer.ActionEnabledChanged_cb);
				}
				return ActionMuxer.ActionEnabledChanged_cb_delegate;
			}
		}

		// Token: 0x06000C17 RID: 3095 RVA: 0x000249BB File Offset: 0x00022BBB
		private static void OverrideActionEnabledChanged(GType gtype)
		{
			ActionMuxer.OverrideActionEnabledChanged(gtype, ActionMuxer.ActionEnabledChangedVMCallback);
		}

		// Token: 0x06000C18 RID: 3096 RVA: 0x000249C8 File Offset: 0x00022BC8
		private static void OverrideActionEnabledChanged(GType gtype, ActionMuxer.ActionEnabledChangedNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "action-enabled-changed", callback);
		}

		// Token: 0x06000C19 RID: 3097 RVA: 0x000249D8 File Offset: 0x00022BD8
		private static void ActionEnabledChanged_cb(IntPtr inst, IntPtr action_name, bool enabled)
		{
			try
			{
				(Object.GetObject(inst, false) as ActionMuxer).OnActionEnabledChanged(Marshaller.Utf8PtrToString(action_name), enabled);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000C1A RID: 3098 RVA: 0x00024A18 File Offset: 0x00022C18
		[DefaultSignalHandler(Type = typeof(ActionMuxer), ConnectionMethod = "OverrideActionEnabledChanged")]
		protected virtual void OnActionEnabledChanged(string action_name, bool enabled)
		{
			this.InternalActionEnabledChanged(action_name, enabled);
		}

		// Token: 0x06000C1B RID: 3099 RVA: 0x00024A24 File Offset: 0x00022C24
		private void InternalActionEnabledChanged(string action_name, bool enabled)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(3U);
			Value[] array = new Value[3];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(action_name);
			valueArray.Append(array[1]);
			array[2] = new Value(enabled);
			valueArray.Append(array[2]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x17000282 RID: 642
		// (get) Token: 0x06000C1C RID: 3100 RVA: 0x00024ACA File Offset: 0x00022CCA
		private static ActionMuxer.ActionStateChangedNativeDelegate ActionStateChangedVMCallback
		{
			get
			{
				if (ActionMuxer.ActionStateChanged_cb_delegate == null)
				{
					ActionMuxer.ActionStateChanged_cb_delegate = new ActionMuxer.ActionStateChangedNativeDelegate(ActionMuxer.ActionStateChanged_cb);
				}
				return ActionMuxer.ActionStateChanged_cb_delegate;
			}
		}

		// Token: 0x06000C1D RID: 3101 RVA: 0x00024AE9 File Offset: 0x00022CE9
		private static void OverrideActionStateChanged(GType gtype)
		{
			ActionMuxer.OverrideActionStateChanged(gtype, ActionMuxer.ActionStateChangedVMCallback);
		}

		// Token: 0x06000C1E RID: 3102 RVA: 0x00024AF6 File Offset: 0x00022CF6
		private static void OverrideActionStateChanged(GType gtype, ActionMuxer.ActionStateChangedNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "action-state-changed", callback);
		}

		// Token: 0x06000C1F RID: 3103 RVA: 0x00024B04 File Offset: 0x00022D04
		private static void ActionStateChanged_cb(IntPtr inst, IntPtr action_name, IntPtr state)
		{
			try
			{
				(Object.GetObject(inst, false) as ActionMuxer).OnActionStateChanged(Marshaller.Utf8PtrToString(action_name), new Variant(state));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000C20 RID: 3104 RVA: 0x00024B48 File Offset: 0x00022D48
		[DefaultSignalHandler(Type = typeof(ActionMuxer), ConnectionMethod = "OverrideActionStateChanged")]
		protected virtual void OnActionStateChanged(string action_name, Variant state)
		{
			this.InternalActionStateChanged(action_name, state);
		}

		// Token: 0x06000C21 RID: 3105 RVA: 0x00024B54 File Offset: 0x00022D54
		private void InternalActionStateChanged(string action_name, Variant state)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(3U);
			Value[] array = new Value[3];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(action_name);
			valueArray.Append(array[1]);
			array[2] = new Value(state);
			valueArray.Append(array[2]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x06000C22 RID: 3106 RVA: 0x00024BFC File Offset: 0x00022DFC
		public void RegisterObserver(string action_name, IActionObserver observer)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			ActionMuxer.gtk_action_observable_register_observer(base.Handle, intPtr, (observer == null) ? IntPtr.Zero : ((observer is Object) ? (observer as Object).Handle : (observer as ActionObserverAdapter).Handle));
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000C23 RID: 3107 RVA: 0x00024C54 File Offset: 0x00022E54
		public void UnregisterObserver(string action_name, IActionObserver observer)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			ActionMuxer.gtk_action_observable_unregister_observer(base.Handle, intPtr, (observer == null) ? IntPtr.Zero : ((observer is Object) ? (observer as Object).Handle : (observer as ActionObserverAdapter).Handle));
			Marshaller.Free(intPtr);
		}

		// Token: 0x040005CE RID: 1486
		private static ActionMuxer.d_gtk_action_muxer_new gtk_action_muxer_new = FuncLoader.LoadFunction<ActionMuxer.d_gtk_action_muxer_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_muxer_new"));

		// Token: 0x040005CF RID: 1487
		private static ActionMuxer.d_gtk_action_muxer_get_parent gtk_action_muxer_get_parent = FuncLoader.LoadFunction<ActionMuxer.d_gtk_action_muxer_get_parent>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_muxer_get_parent"));

		// Token: 0x040005D0 RID: 1488
		private static ActionMuxer.d_gtk_action_muxer_set_parent gtk_action_muxer_set_parent = FuncLoader.LoadFunction<ActionMuxer.d_gtk_action_muxer_set_parent>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_muxer_set_parent"));

		// Token: 0x040005D1 RID: 1489
		private static ActionMuxer.PrimaryAccelChangedNativeDelegate PrimaryAccelChanged_cb_delegate;

		// Token: 0x040005D2 RID: 1490
		private static ActionMuxer.d_gtk_action_muxer_get_primary_accel gtk_action_muxer_get_primary_accel = FuncLoader.LoadFunction<ActionMuxer.d_gtk_action_muxer_get_primary_accel>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_muxer_get_primary_accel"));

		// Token: 0x040005D3 RID: 1491
		private static ActionMuxer.d_gtk_action_muxer_get_type gtk_action_muxer_get_type = FuncLoader.LoadFunction<ActionMuxer.d_gtk_action_muxer_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_muxer_get_type"));

		// Token: 0x040005D4 RID: 1492
		private static ActionMuxer.d_gtk_action_muxer_insert gtk_action_muxer_insert = FuncLoader.LoadFunction<ActionMuxer.d_gtk_action_muxer_insert>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_muxer_insert"));

		// Token: 0x040005D5 RID: 1493
		private static ActionMuxer.d_gtk_action_muxer_list_prefixes gtk_action_muxer_list_prefixes = FuncLoader.LoadFunction<ActionMuxer.d_gtk_action_muxer_list_prefixes>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_muxer_list_prefixes"));

		// Token: 0x040005D6 RID: 1494
		private static ActionMuxer.d_gtk_action_muxer_lookup gtk_action_muxer_lookup = FuncLoader.LoadFunction<ActionMuxer.d_gtk_action_muxer_lookup>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_muxer_lookup"));

		// Token: 0x040005D7 RID: 1495
		private static ActionMuxer.d_gtk_action_muxer_remove gtk_action_muxer_remove = FuncLoader.LoadFunction<ActionMuxer.d_gtk_action_muxer_remove>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_muxer_remove"));

		// Token: 0x040005D8 RID: 1496
		private static ActionMuxer.d_gtk_action_muxer_set_primary_accel gtk_action_muxer_set_primary_accel = FuncLoader.LoadFunction<ActionMuxer.d_gtk_action_muxer_set_primary_accel>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_muxer_set_primary_accel"));

		// Token: 0x040005D9 RID: 1497
		private static ActionMuxer.d_g_action_group_action_added g_action_group_action_added = FuncLoader.LoadFunction<ActionMuxer.d_g_action_group_action_added>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_action_group_action_added"));

		// Token: 0x040005DA RID: 1498
		private static ActionMuxer.d_g_action_group_action_enabled_changed g_action_group_action_enabled_changed = FuncLoader.LoadFunction<ActionMuxer.d_g_action_group_action_enabled_changed>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_action_group_action_enabled_changed"));

		// Token: 0x040005DB RID: 1499
		private static ActionMuxer.d_g_action_group_action_removed g_action_group_action_removed = FuncLoader.LoadFunction<ActionMuxer.d_g_action_group_action_removed>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_action_group_action_removed"));

		// Token: 0x040005DC RID: 1500
		private static ActionMuxer.d_g_action_group_action_state_changed g_action_group_action_state_changed = FuncLoader.LoadFunction<ActionMuxer.d_g_action_group_action_state_changed>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_action_group_action_state_changed"));

		// Token: 0x040005DD RID: 1501
		private static ActionMuxer.d_g_action_group_activate_action g_action_group_activate_action = FuncLoader.LoadFunction<ActionMuxer.d_g_action_group_activate_action>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_action_group_activate_action"));

		// Token: 0x040005DE RID: 1502
		private static ActionMuxer.d_g_action_group_change_action_state g_action_group_change_action_state = FuncLoader.LoadFunction<ActionMuxer.d_g_action_group_change_action_state>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_action_group_change_action_state"));

		// Token: 0x040005DF RID: 1503
		private static ActionMuxer.d_g_action_group_get_action_enabled g_action_group_get_action_enabled = FuncLoader.LoadFunction<ActionMuxer.d_g_action_group_get_action_enabled>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_action_group_get_action_enabled"));

		// Token: 0x040005E0 RID: 1504
		private static ActionMuxer.d_g_action_group_get_action_parameter_type g_action_group_get_action_parameter_type = FuncLoader.LoadFunction<ActionMuxer.d_g_action_group_get_action_parameter_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_action_group_get_action_parameter_type"));

		// Token: 0x040005E1 RID: 1505
		private static ActionMuxer.d_g_action_group_get_action_state g_action_group_get_action_state = FuncLoader.LoadFunction<ActionMuxer.d_g_action_group_get_action_state>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_action_group_get_action_state"));

		// Token: 0x040005E2 RID: 1506
		private static ActionMuxer.d_g_action_group_get_action_state_hint g_action_group_get_action_state_hint = FuncLoader.LoadFunction<ActionMuxer.d_g_action_group_get_action_state_hint>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_action_group_get_action_state_hint"));

		// Token: 0x040005E3 RID: 1507
		private static ActionMuxer.d_g_action_group_get_action_state_type g_action_group_get_action_state_type = FuncLoader.LoadFunction<ActionMuxer.d_g_action_group_get_action_state_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_action_group_get_action_state_type"));

		// Token: 0x040005E4 RID: 1508
		private static ActionMuxer.d_g_action_group_has_action g_action_group_has_action = FuncLoader.LoadFunction<ActionMuxer.d_g_action_group_has_action>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_action_group_has_action"));

		// Token: 0x040005E5 RID: 1509
		private static ActionMuxer.d_g_action_group_list_actions g_action_group_list_actions = FuncLoader.LoadFunction<ActionMuxer.d_g_action_group_list_actions>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_action_group_list_actions"));

		// Token: 0x040005E6 RID: 1510
		private static ActionMuxer.d_g_action_group_query_action g_action_group_query_action = FuncLoader.LoadFunction<ActionMuxer.d_g_action_group_query_action>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_action_group_query_action"));

		// Token: 0x040005E7 RID: 1511
		private static ActionMuxer.ActionAddedNativeDelegate ActionAdded_cb_delegate;

		// Token: 0x040005E8 RID: 1512
		private static ActionMuxer.ActionRemovedNativeDelegate ActionRemoved_cb_delegate;

		// Token: 0x040005E9 RID: 1513
		private static ActionMuxer.ActionEnabledChangedNativeDelegate ActionEnabledChanged_cb_delegate;

		// Token: 0x040005EA RID: 1514
		private static ActionMuxer.ActionStateChangedNativeDelegate ActionStateChanged_cb_delegate;

		// Token: 0x040005EB RID: 1515
		private static ActionMuxer.d_gtk_action_observable_register_observer gtk_action_observable_register_observer = FuncLoader.LoadFunction<ActionMuxer.d_gtk_action_observable_register_observer>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_observable_register_observer"));

		// Token: 0x040005EC RID: 1516
		private static ActionMuxer.d_gtk_action_observable_unregister_observer gtk_action_observable_unregister_observer = FuncLoader.LoadFunction<ActionMuxer.d_gtk_action_observable_unregister_observer>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_observable_unregister_observer"));

		// Token: 0x020009E2 RID: 2530
		// (Invoke) Token: 0x06004E9B RID: 20123
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_muxer_new();

		// Token: 0x020009E3 RID: 2531
		// (Invoke) Token: 0x06004E9F RID: 20127
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_muxer_get_parent(IntPtr raw);

		// Token: 0x020009E4 RID: 2532
		// (Invoke) Token: 0x06004EA3 RID: 20131
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_muxer_set_parent(IntPtr raw, IntPtr parent);

		// Token: 0x020009E5 RID: 2533
		// (Invoke) Token: 0x06004EA7 RID: 20135
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void PrimaryAccelChangedNativeDelegate(IntPtr inst, IntPtr p0, IntPtr p1);

		// Token: 0x020009E6 RID: 2534
		// (Invoke) Token: 0x06004EAB RID: 20139
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_muxer_get_primary_accel(IntPtr raw, IntPtr action_and_target);

		// Token: 0x020009E7 RID: 2535
		// (Invoke) Token: 0x06004EAF RID: 20143
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_muxer_get_type();

		// Token: 0x020009E8 RID: 2536
		// (Invoke) Token: 0x06004EB3 RID: 20147
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_muxer_insert(IntPtr raw, IntPtr prefix, IntPtr action_group);

		// Token: 0x020009E9 RID: 2537
		// (Invoke) Token: 0x06004EB7 RID: 20151
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_muxer_list_prefixes(IntPtr raw);

		// Token: 0x020009EA RID: 2538
		// (Invoke) Token: 0x06004EBB RID: 20155
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_muxer_lookup(IntPtr raw, IntPtr prefix);

		// Token: 0x020009EB RID: 2539
		// (Invoke) Token: 0x06004EBF RID: 20159
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_muxer_remove(IntPtr raw, IntPtr prefix);

		// Token: 0x020009EC RID: 2540
		// (Invoke) Token: 0x06004EC3 RID: 20163
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_muxer_set_primary_accel(IntPtr raw, IntPtr action_and_target, IntPtr primary_accel);

		// Token: 0x020009ED RID: 2541
		// (Invoke) Token: 0x06004EC7 RID: 20167
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_g_action_group_action_added(IntPtr raw, IntPtr action_name);

		// Token: 0x020009EE RID: 2542
		// (Invoke) Token: 0x06004ECB RID: 20171
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_g_action_group_action_enabled_changed(IntPtr raw, IntPtr action_name, bool enabled);

		// Token: 0x020009EF RID: 2543
		// (Invoke) Token: 0x06004ECF RID: 20175
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_g_action_group_action_removed(IntPtr raw, IntPtr action_name);

		// Token: 0x020009F0 RID: 2544
		// (Invoke) Token: 0x06004ED3 RID: 20179
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_g_action_group_action_state_changed(IntPtr raw, IntPtr action_name, IntPtr state);

		// Token: 0x020009F1 RID: 2545
		// (Invoke) Token: 0x06004ED7 RID: 20183
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_g_action_group_activate_action(IntPtr raw, IntPtr action_name, IntPtr parameter);

		// Token: 0x020009F2 RID: 2546
		// (Invoke) Token: 0x06004EDB RID: 20187
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_g_action_group_change_action_state(IntPtr raw, IntPtr action_name, IntPtr value);

		// Token: 0x020009F3 RID: 2547
		// (Invoke) Token: 0x06004EDF RID: 20191
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_g_action_group_get_action_enabled(IntPtr raw, IntPtr action_name);

		// Token: 0x020009F4 RID: 2548
		// (Invoke) Token: 0x06004EE3 RID: 20195
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_g_action_group_get_action_parameter_type(IntPtr raw, IntPtr action_name);

		// Token: 0x020009F5 RID: 2549
		// (Invoke) Token: 0x06004EE7 RID: 20199
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_g_action_group_get_action_state(IntPtr raw, IntPtr action_name);

		// Token: 0x020009F6 RID: 2550
		// (Invoke) Token: 0x06004EEB RID: 20203
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_g_action_group_get_action_state_hint(IntPtr raw, IntPtr action_name);

		// Token: 0x020009F7 RID: 2551
		// (Invoke) Token: 0x06004EEF RID: 20207
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_g_action_group_get_action_state_type(IntPtr raw, IntPtr action_name);

		// Token: 0x020009F8 RID: 2552
		// (Invoke) Token: 0x06004EF3 RID: 20211
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_g_action_group_has_action(IntPtr raw, IntPtr action_name);

		// Token: 0x020009F9 RID: 2553
		// (Invoke) Token: 0x06004EF7 RID: 20215
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_g_action_group_list_actions(IntPtr raw);

		// Token: 0x020009FA RID: 2554
		// (Invoke) Token: 0x06004EFB RID: 20219
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_g_action_group_query_action(IntPtr raw, IntPtr action_name, out bool enabled, IntPtr parameter_type, IntPtr state_type, IntPtr state_hint, IntPtr state);

		// Token: 0x020009FB RID: 2555
		// (Invoke) Token: 0x06004EFF RID: 20223
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ActionAddedNativeDelegate(IntPtr inst, IntPtr action_name);

		// Token: 0x020009FC RID: 2556
		// (Invoke) Token: 0x06004F03 RID: 20227
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ActionRemovedNativeDelegate(IntPtr inst, IntPtr action_name);

		// Token: 0x020009FD RID: 2557
		// (Invoke) Token: 0x06004F07 RID: 20231
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ActionEnabledChangedNativeDelegate(IntPtr inst, IntPtr action_name, bool enabled);

		// Token: 0x020009FE RID: 2558
		// (Invoke) Token: 0x06004F0B RID: 20235
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ActionStateChangedNativeDelegate(IntPtr inst, IntPtr action_name, IntPtr state);

		// Token: 0x020009FF RID: 2559
		// (Invoke) Token: 0x06004F0F RID: 20239
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_observable_register_observer(IntPtr raw, IntPtr action_name, IntPtr observer);

		// Token: 0x02000A00 RID: 2560
		// (Invoke) Token: 0x06004F13 RID: 20243
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_observable_unregister_observer(IntPtr raw, IntPtr action_name, IntPtr observer);
	}
}
