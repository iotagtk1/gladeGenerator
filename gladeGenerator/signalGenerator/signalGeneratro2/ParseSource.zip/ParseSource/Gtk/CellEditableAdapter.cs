﻿using System;
using System.Runtime.InteropServices;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x0200016C RID: 364
	public class CellEditableAdapter : GInterfaceAdapter, ICellEditable, IWrapper
	{
		// Token: 0x06000F52 RID: 3922 RVA: 0x0002E5A8 File Offset: 0x0002C7A8
		static CellEditableAdapter()
		{
			GType.Register(CellEditableAdapter._gtype, typeof(CellEditableAdapter));
			CellEditableAdapter.iface.StartEditing = new CellEditableAdapter.StartEditingNativeDelegate(CellEditableAdapter.StartEditing_cb);
		}

		// Token: 0x06000F53 RID: 3923 RVA: 0x0002E66C File Offset: 0x0002C86C
		private static void StartEditing_cb(IntPtr inst, IntPtr evnt)
		{
			try
			{
				(Object.GetObject(inst, false) as ICellEditableImplementor).StartEditing(Event.GetEvent(evnt));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000F54 RID: 3924 RVA: 0x0002E6AC File Offset: 0x0002C8AC
		private static void Initialize(IntPtr ptr, IntPtr data)
		{
			IntPtr ptr2 = new IntPtr(ptr.ToInt64() + (long)CellEditableAdapter.class_offset);
			CellEditableAdapter.GtkCellEditableIface structure = (CellEditableAdapter.GtkCellEditableIface)Marshal.PtrToStructure(ptr2, typeof(CellEditableAdapter.GtkCellEditableIface));
			structure.StartEditing = CellEditableAdapter.iface.StartEditing;
			Marshal.StructureToPtr<CellEditableAdapter.GtkCellEditableIface>(structure, ptr2, false);
		}

		// Token: 0x06000F55 RID: 3925 RVA: 0x0002E6FD File Offset: 0x0002C8FD
		public CellEditableAdapter()
		{
			base.InitHandler = new GInterfaceInitHandler(CellEditableAdapter.Initialize);
		}

		// Token: 0x06000F56 RID: 3926 RVA: 0x0002E717 File Offset: 0x0002C917
		public CellEditableAdapter(ICellEditableImplementor implementor)
		{
			if (implementor == null)
			{
				throw new ArgumentNullException("implementor");
			}
			if (!(implementor is Object))
			{
				throw new ArgumentException("implementor must be a subclass of GLib.Object");
			}
			this.implementor = (implementor as Object);
		}

		// Token: 0x06000F57 RID: 3927 RVA: 0x0002E74C File Offset: 0x0002C94C
		public CellEditableAdapter(IntPtr handle)
		{
			if (!CellEditableAdapter._gtype.IsInstance(handle))
			{
				throw new ArgumentException("The gobject doesn't implement the GInterface of this adapter", "handle");
			}
			this.implementor = Object.GetObject(handle);
		}

		// Token: 0x17000358 RID: 856
		// (get) Token: 0x06000F58 RID: 3928 RVA: 0x0002E77D File Offset: 0x0002C97D
		public static GType GType
		{
			get
			{
				return CellEditableAdapter._gtype;
			}
		}

		// Token: 0x17000359 RID: 857
		// (get) Token: 0x06000F59 RID: 3929 RVA: 0x0002E784 File Offset: 0x0002C984
		public override GType GInterfaceGType
		{
			get
			{
				return CellEditableAdapter._gtype;
			}
		}

		// Token: 0x1700035A RID: 858
		// (get) Token: 0x06000F5A RID: 3930 RVA: 0x0002E78B File Offset: 0x0002C98B
		public override IntPtr Handle
		{
			get
			{
				return this.implementor.Handle;
			}
		}

		// Token: 0x1700035B RID: 859
		// (get) Token: 0x06000F5B RID: 3931 RVA: 0x0002E798 File Offset: 0x0002C998
		public IntPtr OwnedHandle
		{
			get
			{
				return this.implementor.OwnedHandle;
			}
		}

		// Token: 0x06000F5C RID: 3932 RVA: 0x0002E7A5 File Offset: 0x0002C9A5
		public static ICellEditable GetObject(IntPtr handle, bool owned)
		{
			return CellEditableAdapter.GetObject(Object.GetObject(handle, owned));
		}

		// Token: 0x06000F5D RID: 3933 RVA: 0x0002E7B3 File Offset: 0x0002C9B3
		public static ICellEditable GetObject(Object obj)
		{
			if (obj == null)
			{
				return null;
			}
			if (obj is ICellEditableImplementor)
			{
				return new CellEditableAdapter(obj as ICellEditableImplementor);
			}
			if (!(obj is ICellEditable))
			{
				return new CellEditableAdapter(obj.Handle);
			}
			return obj as ICellEditable;
		}

		// Token: 0x1700035C RID: 860
		// (get) Token: 0x06000F5E RID: 3934 RVA: 0x0002E7E8 File Offset: 0x0002C9E8
		public ICellEditableImplementor Implementor
		{
			get
			{
				return this.implementor as ICellEditableImplementor;
			}
		}

		// Token: 0x14000060 RID: 96
		// (add) Token: 0x06000F5F RID: 3935 RVA: 0x0002E7F5 File Offset: 0x0002C9F5
		// (remove) Token: 0x06000F60 RID: 3936 RVA: 0x0002E80D File Offset: 0x0002CA0D
		[Signal("editing-done")]
		public event EventHandler EditingDone
		{
			add
			{
				Object.GetObject(this.Handle).AddSignalHandler("editing-done", value);
			}
			remove
			{
				Object.GetObject(this.Handle).RemoveSignalHandler("editing-done", value);
			}
		}

		// Token: 0x14000061 RID: 97
		// (add) Token: 0x06000F61 RID: 3937 RVA: 0x0002E825 File Offset: 0x0002CA25
		// (remove) Token: 0x06000F62 RID: 3938 RVA: 0x0002E83D File Offset: 0x0002CA3D
		[Signal("remove-widget")]
		public event EventHandler WidgetRemoved
		{
			add
			{
				Object.GetObject(this.Handle).AddSignalHandler("remove-widget", value);
			}
			remove
			{
				Object.GetObject(this.Handle).RemoveSignalHandler("remove-widget", value);
			}
		}

		// Token: 0x06000F63 RID: 3939 RVA: 0x0002E855 File Offset: 0x0002CA55
		public void FinishEditing()
		{
			CellEditableAdapter.gtk_cell_editable_editing_done(this.Handle);
		}

		// Token: 0x06000F64 RID: 3940 RVA: 0x0002E867 File Offset: 0x0002CA67
		public void RemoveWidget()
		{
			CellEditableAdapter.gtk_cell_editable_remove_widget(this.Handle);
		}

		// Token: 0x06000F65 RID: 3941 RVA: 0x0002E879 File Offset: 0x0002CA79
		public void StartEditing(Event evnt)
		{
			CellEditableAdapter.gtk_cell_editable_start_editing(this.Handle, (evnt == null) ? IntPtr.Zero : evnt.Handle);
		}

		// Token: 0x04000784 RID: 1924
		private static CellEditableAdapter.GtkCellEditableIface iface;

		// Token: 0x04000785 RID: 1925
		private static int class_offset = 2 * IntPtr.Size;

		// Token: 0x04000786 RID: 1926
		private Object implementor;

		// Token: 0x04000787 RID: 1927
		private static CellEditableAdapter.d_gtk_cell_editable_get_type gtk_cell_editable_get_type = FuncLoader.LoadFunction<CellEditableAdapter.d_gtk_cell_editable_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_editable_get_type"));

		// Token: 0x04000788 RID: 1928
		private static GType _gtype = new GType(CellEditableAdapter.gtk_cell_editable_get_type());

		// Token: 0x04000789 RID: 1929
		private static CellEditableAdapter.d_gtk_cell_editable_editing_done gtk_cell_editable_editing_done = FuncLoader.LoadFunction<CellEditableAdapter.d_gtk_cell_editable_editing_done>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_editable_editing_done"));

		// Token: 0x0400078A RID: 1930
		private static CellEditableAdapter.d_gtk_cell_editable_remove_widget gtk_cell_editable_remove_widget = FuncLoader.LoadFunction<CellEditableAdapter.d_gtk_cell_editable_remove_widget>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_editable_remove_widget"));

		// Token: 0x0400078B RID: 1931
		private static CellEditableAdapter.d_gtk_cell_editable_start_editing gtk_cell_editable_start_editing = FuncLoader.LoadFunction<CellEditableAdapter.d_gtk_cell_editable_start_editing>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_editable_start_editing"));

		// Token: 0x02000B0E RID: 2830
		private struct GtkCellEditableIface
		{
			// Token: 0x04001E67 RID: 7783
			private IntPtr EditingDone;

			// Token: 0x04001E68 RID: 7784
			private IntPtr WidgetRemoved;

			// Token: 0x04001E69 RID: 7785
			public CellEditableAdapter.StartEditingNativeDelegate StartEditing;
		}

		// Token: 0x02000B0F RID: 2831
		// (Invoke) Token: 0x06005349 RID: 21321
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void StartEditingNativeDelegate(IntPtr inst, IntPtr evnt);

		// Token: 0x02000B10 RID: 2832
		// (Invoke) Token: 0x0600534D RID: 21325
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_editable_get_type();

		// Token: 0x02000B11 RID: 2833
		// (Invoke) Token: 0x06005351 RID: 21329
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_editable_editing_done(IntPtr raw);

		// Token: 0x02000B12 RID: 2834
		// (Invoke) Token: 0x06005355 RID: 21333
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_editable_remove_widget(IntPtr raw);

		// Token: 0x02000B13 RID: 2835
		// (Invoke) Token: 0x06005359 RID: 21337
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_editable_start_editing(IntPtr raw, IntPtr evnt);
	}
}
