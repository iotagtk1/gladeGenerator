﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x0200011C RID: 284
	public class Alignment : Bin
	{
		// Token: 0x06000C83 RID: 3203 RVA: 0x00025D0A File Offset: 0x00023F0A
		public Alignment(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000C84 RID: 3204 RVA: 0x00025D14 File Offset: 0x00023F14
		public Alignment(float xalign, float yalign, float xscale, float yscale) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Alignment))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				list2.Add("xalign");
				list.Add(new Value(xalign));
				list2.Add("yalign");
				list.Add(new Value(yalign));
				list2.Add("xscale");
				list.Add(new Value(xscale));
				list2.Add("yscale");
				list.Add(new Value(yscale));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			this.Raw = Alignment.gtk_alignment_new(xalign, yalign, xscale, yscale);
		}

		// Token: 0x17000299 RID: 665
		// (get) Token: 0x06000C85 RID: 3205 RVA: 0x00025DD4 File Offset: 0x00023FD4
		// (set) Token: 0x06000C86 RID: 3206 RVA: 0x00025DFC File Offset: 0x00023FFC
		[Property("xalign")]
		public float Xalign
		{
			get
			{
				Value property = base.GetProperty("xalign");
				float result = (float)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("xalign", val);
				val.Dispose();
			}
		}

		// Token: 0x1700029A RID: 666
		// (get) Token: 0x06000C87 RID: 3207 RVA: 0x00025E24 File Offset: 0x00024024
		// (set) Token: 0x06000C88 RID: 3208 RVA: 0x00025E4C File Offset: 0x0002404C
		[Property("yalign")]
		public float Yalign
		{
			get
			{
				Value property = base.GetProperty("yalign");
				float result = (float)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("yalign", val);
				val.Dispose();
			}
		}

		// Token: 0x1700029B RID: 667
		// (get) Token: 0x06000C89 RID: 3209 RVA: 0x00025E74 File Offset: 0x00024074
		// (set) Token: 0x06000C8A RID: 3210 RVA: 0x00025E9C File Offset: 0x0002409C
		[Property("xscale")]
		public float Xscale
		{
			get
			{
				Value property = base.GetProperty("xscale");
				float result = (float)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("xscale", val);
				val.Dispose();
			}
		}

		// Token: 0x1700029C RID: 668
		// (get) Token: 0x06000C8B RID: 3211 RVA: 0x00025EC4 File Offset: 0x000240C4
		// (set) Token: 0x06000C8C RID: 3212 RVA: 0x00025EEC File Offset: 0x000240EC
		[Property("yscale")]
		public float Yscale
		{
			get
			{
				Value property = base.GetProperty("yscale");
				float result = (float)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("yscale", val);
				val.Dispose();
			}
		}

		// Token: 0x1700029D RID: 669
		// (get) Token: 0x06000C8D RID: 3213 RVA: 0x00025F14 File Offset: 0x00024114
		// (set) Token: 0x06000C8E RID: 3214 RVA: 0x00025F3C File Offset: 0x0002413C
		[Property("top-padding")]
		public uint TopPadding
		{
			get
			{
				Value property = base.GetProperty("top-padding");
				uint result = (uint)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("top-padding", val);
				val.Dispose();
			}
		}

		// Token: 0x1700029E RID: 670
		// (get) Token: 0x06000C8F RID: 3215 RVA: 0x00025F64 File Offset: 0x00024164
		// (set) Token: 0x06000C90 RID: 3216 RVA: 0x00025F8C File Offset: 0x0002418C
		[Property("bottom-padding")]
		public uint BottomPadding
		{
			get
			{
				Value property = base.GetProperty("bottom-padding");
				uint result = (uint)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("bottom-padding", val);
				val.Dispose();
			}
		}

		// Token: 0x1700029F RID: 671
		// (get) Token: 0x06000C91 RID: 3217 RVA: 0x00025FB4 File Offset: 0x000241B4
		// (set) Token: 0x06000C92 RID: 3218 RVA: 0x00025FDC File Offset: 0x000241DC
		[Property("left-padding")]
		public uint LeftPadding
		{
			get
			{
				Value property = base.GetProperty("left-padding");
				uint result = (uint)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("left-padding", val);
				val.Dispose();
			}
		}

		// Token: 0x170002A0 RID: 672
		// (get) Token: 0x06000C93 RID: 3219 RVA: 0x00026004 File Offset: 0x00024204
		// (set) Token: 0x06000C94 RID: 3220 RVA: 0x0002602C File Offset: 0x0002422C
		[Property("right-padding")]
		public uint RightPadding
		{
			get
			{
				Value property = base.GetProperty("right-padding");
				uint result = (uint)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("right-padding", val);
				val.Dispose();
			}
		}

		// Token: 0x170002A1 RID: 673
		// (get) Token: 0x06000C95 RID: 3221 RVA: 0x00026054 File Offset: 0x00024254
		public new static AbiStruct class_abi
		{
			get
			{
				if (Alignment._class_abi == null)
				{
					Alignment._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("_gtk_reserved1", Bin.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Alignment._class_abi;
			}
		}

		// Token: 0x06000C96 RID: 3222 RVA: 0x0002616F File Offset: 0x0002436F
		[Obsolete]
		public void GetPadding(out uint padding_top, out uint padding_bottom, out uint padding_left, out uint padding_right)
		{
			Alignment.gtk_alignment_get_padding(base.Handle, out padding_top, out padding_bottom, out padding_left, out padding_right);
		}

		// Token: 0x170002A2 RID: 674
		// (get) Token: 0x06000C97 RID: 3223 RVA: 0x00026188 File Offset: 0x00024388
		[Obsolete]
		public new static GType GType
		{
			get
			{
				IntPtr val = Alignment.gtk_alignment_get_type();
				return new GType(val);
			}
		}

		// Token: 0x06000C98 RID: 3224 RVA: 0x000261A6 File Offset: 0x000243A6
		[Obsolete]
		public void Set(float xalign, float yalign, float xscale, float yscale)
		{
			Alignment.gtk_alignment_set(base.Handle, xalign, yalign, xscale, yscale);
		}

		// Token: 0x06000C99 RID: 3225 RVA: 0x000261BD File Offset: 0x000243BD
		[Obsolete]
		public void SetPadding(uint padding_top, uint padding_bottom, uint padding_left, uint padding_right)
		{
			Alignment.gtk_alignment_set_padding(base.Handle, padding_top, padding_bottom, padding_left, padding_right);
		}

		// Token: 0x170002A3 RID: 675
		// (get) Token: 0x06000C9A RID: 3226 RVA: 0x000261D4 File Offset: 0x000243D4
		public new static AbiStruct abi_info
		{
			get
			{
				if (Alignment._abi_info == null)
				{
					Alignment._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Bin.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Alignment._abi_info;
			}
		}

		// Token: 0x04000610 RID: 1552
		private static Alignment.d_gtk_alignment_new gtk_alignment_new = FuncLoader.LoadFunction<Alignment.d_gtk_alignment_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_alignment_new"));

		// Token: 0x04000611 RID: 1553
		private static AbiStruct _class_abi = null;

		// Token: 0x04000612 RID: 1554
		private static Alignment.d_gtk_alignment_get_padding gtk_alignment_get_padding = FuncLoader.LoadFunction<Alignment.d_gtk_alignment_get_padding>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_alignment_get_padding"));

		// Token: 0x04000613 RID: 1555
		private static Alignment.d_gtk_alignment_get_type gtk_alignment_get_type = FuncLoader.LoadFunction<Alignment.d_gtk_alignment_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_alignment_get_type"));

		// Token: 0x04000614 RID: 1556
		private static Alignment.d_gtk_alignment_set gtk_alignment_set = FuncLoader.LoadFunction<Alignment.d_gtk_alignment_set>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_alignment_set"));

		// Token: 0x04000615 RID: 1557
		private static Alignment.d_gtk_alignment_set_padding gtk_alignment_set_padding = FuncLoader.LoadFunction<Alignment.d_gtk_alignment_set_padding>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_alignment_set_padding"));

		// Token: 0x04000616 RID: 1558
		private static AbiStruct _abi_info = null;

		// Token: 0x02000A1D RID: 2589
		// (Invoke) Token: 0x06004F7B RID: 20347
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_alignment_new(float xalign, float yalign, float xscale, float yscale);

		// Token: 0x02000A1E RID: 2590
		// (Invoke) Token: 0x06004F7F RID: 20351
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_alignment_get_padding(IntPtr raw, out uint padding_top, out uint padding_bottom, out uint padding_left, out uint padding_right);

		// Token: 0x02000A1F RID: 2591
		// (Invoke) Token: 0x06004F83 RID: 20355
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_alignment_get_type();

		// Token: 0x02000A20 RID: 2592
		// (Invoke) Token: 0x06004F87 RID: 20359
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_alignment_set(IntPtr raw, float xalign, float yalign, float xscale, float yscale);

		// Token: 0x02000A21 RID: 2593
		// (Invoke) Token: 0x06004F8B RID: 20363
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_alignment_set_padding(IntPtr raw, uint padding_top, uint padding_bottom, uint padding_left, uint padding_right);
	}
}
