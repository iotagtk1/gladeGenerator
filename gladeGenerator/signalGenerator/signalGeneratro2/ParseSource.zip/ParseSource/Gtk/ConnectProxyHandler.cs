﻿using System;

namespace Gtk
{
	// Token: 0x020001B0 RID: 432
	// (Invoke) Token: 0x06001153 RID: 4435
	public delegate void ConnectProxyHandler(object o, ConnectProxyArgs args);
}
