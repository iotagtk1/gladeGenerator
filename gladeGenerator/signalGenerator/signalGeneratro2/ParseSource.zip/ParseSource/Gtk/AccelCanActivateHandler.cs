﻿using System;

namespace Gtk
{
	// Token: 0x020000F0 RID: 240
	// (Invoke) Token: 0x06000B03 RID: 2819
	public delegate void AccelCanActivateHandler(object o, AccelCanActivateArgs args);
}
