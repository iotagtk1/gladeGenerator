﻿using System;

namespace Gtk
{
	// Token: 0x02000128 RID: 296
	// (Invoke) Token: 0x06000D0F RID: 3343
	public delegate void ApplicationSelectedHandler(object o, ApplicationSelectedArgs args);
}
