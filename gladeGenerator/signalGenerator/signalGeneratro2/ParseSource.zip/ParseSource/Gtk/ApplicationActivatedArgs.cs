﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000125 RID: 293
	public class ApplicationActivatedArgs : SignalArgs
	{
		// Token: 0x170002CD RID: 717
		// (get) Token: 0x06000D09 RID: 3337 RVA: 0x00027744 File Offset: 0x00025944
		public IAppInfo AppInfo
		{
			get
			{
				return AppInfoAdapter.GetObject(base.Args[0] as Object);
			}
		}
	}
}
