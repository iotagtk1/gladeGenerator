﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000217 RID: 535
	public class CycleFocusArgs : SignalArgs
	{
		// Token: 0x1700046E RID: 1134
		// (get) Token: 0x06001255 RID: 4693 RVA: 0x00035185 File Offset: 0x00033385
		public DirectionType P0
		{
			get
			{
				return (DirectionType)base.Args[0];
			}
		}
	}
}
