﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001CC RID: 460
	public class CssImageCrossFadeClass : Opaque
	{
		// Token: 0x06001193 RID: 4499 RVA: 0x00033E6D File Offset: 0x0003206D
		public CssImageCrossFadeClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700041D RID: 1053
		// (get) Token: 0x06001194 RID: 4500 RVA: 0x00033E76 File Offset: 0x00032076
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImageCrossFadeClass._abi_info == null)
				{
					CssImageCrossFadeClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImageCrossFadeClass._abi_info;
			}
		}

		// Token: 0x0400082C RID: 2092
		private static AbiStruct _abi_info;
	}
}
