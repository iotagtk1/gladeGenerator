﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x0200011E RID: 286
	public class AngleChangedArgs : SignalArgs
	{
		// Token: 0x170002A4 RID: 676
		// (get) Token: 0x06000CA0 RID: 3232 RVA: 0x000262D8 File Offset: 0x000244D8
		public double Angle
		{
			get
			{
				return (double)base.Args[0];
			}
		}

		// Token: 0x170002A5 RID: 677
		// (get) Token: 0x06000CA1 RID: 3233 RVA: 0x000262E7 File Offset: 0x000244E7
		public double Delta
		{
			get
			{
				return (double)base.Args[1];
			}
		}
	}
}
