﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x0200020E RID: 526
	public class CursorOnMatchArgs : SignalArgs
	{
		// Token: 0x17000468 RID: 1128
		// (get) Token: 0x06001238 RID: 4664 RVA: 0x000350AF File Offset: 0x000332AF
		public ITreeModel Model
		{
			get
			{
				return TreeModelAdapter.GetObject(base.Args[0] as Object);
			}
		}

		// Token: 0x17000469 RID: 1129
		// (get) Token: 0x06001239 RID: 4665 RVA: 0x000350C3 File Offset: 0x000332C3
		public TreeIter Iter
		{
			get
			{
				return (TreeIter)base.Args[1];
			}
		}
	}
}
