﻿using System;

namespace Gtk
{
	// Token: 0x0200015E RID: 350
	// (Invoke) Token: 0x06000E64 RID: 3684
	public delegate string CalendarDetailFunc(Calendar calendar, uint year, uint month, uint day);
}
