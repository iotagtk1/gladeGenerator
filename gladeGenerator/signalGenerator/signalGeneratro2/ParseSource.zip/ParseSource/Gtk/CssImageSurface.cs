﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001DD RID: 477
	public class CssImageSurface : Opaque
	{
		// Token: 0x060011B5 RID: 4533 RVA: 0x000340F3 File Offset: 0x000322F3
		public CssImageSurface(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700042E RID: 1070
		// (get) Token: 0x060011B6 RID: 4534 RVA: 0x000340FC File Offset: 0x000322FC
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImageSurface._abi_info == null)
				{
					CssImageSurface._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImageSurface._abi_info;
			}
		}

		// Token: 0x0400083D RID: 2109
		private static AbiStruct _abi_info;
	}
}
