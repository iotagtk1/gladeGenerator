﻿using System;

namespace Gtk
{
	// Token: 0x02000133 RID: 307
	// (Invoke) Token: 0x06000DC1 RID: 3521
	public delegate int AssistantPageFunc(int current_page);
}
