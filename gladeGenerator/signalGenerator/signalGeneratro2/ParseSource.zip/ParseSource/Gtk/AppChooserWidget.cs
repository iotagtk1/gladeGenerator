﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x02000123 RID: 291
	public class AppChooserWidget : Box, IAppChooser, IWrapper
	{
		// Token: 0x06000CD8 RID: 3288 RVA: 0x00026E56 File Offset: 0x00025056
		public AppChooserWidget(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000CD9 RID: 3289 RVA: 0x00026E60 File Offset: 0x00025060
		public AppChooserWidget(string content_type) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(AppChooserWidget))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(content_type);
			this.Raw = AppChooserWidget.gtk_app_chooser_widget_new(intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x170002BF RID: 703
		// (get) Token: 0x06000CDA RID: 3290 RVA: 0x00026ECC File Offset: 0x000250CC
		// (set) Token: 0x06000CDB RID: 3291 RVA: 0x00026EDE File Offset: 0x000250DE
		[Property("show-default")]
		public bool ShowDefault
		{
			get
			{
				return AppChooserWidget.gtk_app_chooser_widget_get_show_default(base.Handle);
			}
			set
			{
				AppChooserWidget.gtk_app_chooser_widget_set_show_default(base.Handle, value);
			}
		}

		// Token: 0x170002C0 RID: 704
		// (get) Token: 0x06000CDC RID: 3292 RVA: 0x00026EF1 File Offset: 0x000250F1
		// (set) Token: 0x06000CDD RID: 3293 RVA: 0x00026F03 File Offset: 0x00025103
		[Property("show-recommended")]
		public bool ShowRecommended
		{
			get
			{
				return AppChooserWidget.gtk_app_chooser_widget_get_show_recommended(base.Handle);
			}
			set
			{
				AppChooserWidget.gtk_app_chooser_widget_set_show_recommended(base.Handle, value);
			}
		}

		// Token: 0x170002C1 RID: 705
		// (get) Token: 0x06000CDE RID: 3294 RVA: 0x00026F16 File Offset: 0x00025116
		// (set) Token: 0x06000CDF RID: 3295 RVA: 0x00026F28 File Offset: 0x00025128
		[Property("show-fallback")]
		public bool ShowFallback
		{
			get
			{
				return AppChooserWidget.gtk_app_chooser_widget_get_show_fallback(base.Handle);
			}
			set
			{
				AppChooserWidget.gtk_app_chooser_widget_set_show_fallback(base.Handle, value);
			}
		}

		// Token: 0x170002C2 RID: 706
		// (get) Token: 0x06000CE0 RID: 3296 RVA: 0x00026F3B File Offset: 0x0002513B
		// (set) Token: 0x06000CE1 RID: 3297 RVA: 0x00026F4D File Offset: 0x0002514D
		[Property("show-other")]
		public bool ShowOther
		{
			get
			{
				return AppChooserWidget.gtk_app_chooser_widget_get_show_other(base.Handle);
			}
			set
			{
				AppChooserWidget.gtk_app_chooser_widget_set_show_other(base.Handle, value);
			}
		}

		// Token: 0x170002C3 RID: 707
		// (get) Token: 0x06000CE2 RID: 3298 RVA: 0x00026F60 File Offset: 0x00025160
		// (set) Token: 0x06000CE3 RID: 3299 RVA: 0x00026F72 File Offset: 0x00025172
		[Property("show-all")]
		public new bool ShowAll
		{
			get
			{
				return AppChooserWidget.gtk_app_chooser_widget_get_show_all(base.Handle);
			}
			set
			{
				AppChooserWidget.gtk_app_chooser_widget_set_show_all(base.Handle, value);
			}
		}

		// Token: 0x170002C4 RID: 708
		// (get) Token: 0x06000CE4 RID: 3300 RVA: 0x00026F85 File Offset: 0x00025185
		// (set) Token: 0x06000CE5 RID: 3301 RVA: 0x00026F9C File Offset: 0x0002519C
		[Property("default-text")]
		public string DefaultText
		{
			get
			{
				return Marshaller.Utf8PtrToString(AppChooserWidget.gtk_app_chooser_widget_get_default_text(base.Handle));
			}
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				AppChooserWidget.gtk_app_chooser_widget_set_default_text(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x14000054 RID: 84
		// (add) Token: 0x06000CE6 RID: 3302 RVA: 0x00026FC7 File Offset: 0x000251C7
		// (remove) Token: 0x06000CE7 RID: 3303 RVA: 0x00026FDF File Offset: 0x000251DF
		[Signal("application-selected")]
		public event ApplicationSelectedHandler ApplicationSelected
		{
			add
			{
				base.AddSignalHandler("application-selected", value, typeof(ApplicationSelectedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("application-selected", value);
			}
		}

		// Token: 0x14000055 RID: 85
		// (add) Token: 0x06000CE8 RID: 3304 RVA: 0x00026FED File Offset: 0x000251ED
		// (remove) Token: 0x06000CE9 RID: 3305 RVA: 0x00027005 File Offset: 0x00025205
		[Signal("populate-popup")]
		public event PopulatePopupHandler PopulatePopup
		{
			add
			{
				base.AddSignalHandler("populate-popup", value, typeof(PopulatePopupArgs));
			}
			remove
			{
				base.RemoveSignalHandler("populate-popup", value);
			}
		}

		// Token: 0x14000056 RID: 86
		// (add) Token: 0x06000CEA RID: 3306 RVA: 0x00027013 File Offset: 0x00025213
		// (remove) Token: 0x06000CEB RID: 3307 RVA: 0x0002702B File Offset: 0x0002522B
		[Signal("application-activated")]
		public event ApplicationActivatedHandler ApplicationActivated
		{
			add
			{
				base.AddSignalHandler("application-activated", value, typeof(ApplicationActivatedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("application-activated", value);
			}
		}

		// Token: 0x170002C5 RID: 709
		// (get) Token: 0x06000CEC RID: 3308 RVA: 0x00027039 File Offset: 0x00025239
		private static AppChooserWidget.ApplicationSelectedNativeDelegate ApplicationSelectedVMCallback
		{
			get
			{
				if (AppChooserWidget.ApplicationSelected_cb_delegate == null)
				{
					AppChooserWidget.ApplicationSelected_cb_delegate = new AppChooserWidget.ApplicationSelectedNativeDelegate(AppChooserWidget.ApplicationSelected_cb);
				}
				return AppChooserWidget.ApplicationSelected_cb_delegate;
			}
		}

		// Token: 0x06000CED RID: 3309 RVA: 0x00027058 File Offset: 0x00025258
		private static void OverrideApplicationSelected(GType gtype)
		{
			AppChooserWidget.OverrideApplicationSelected(gtype, AppChooserWidget.ApplicationSelectedVMCallback);
		}

		// Token: 0x06000CEE RID: 3310 RVA: 0x00027068 File Offset: 0x00025268
		private unsafe static void OverrideApplicationSelected(GType gtype, AppChooserWidget.ApplicationSelectedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + AppChooserWidget.class_abi.GetFieldOffset("application_selected");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000CEF RID: 3311 RVA: 0x0002709C File Offset: 0x0002529C
		private static void ApplicationSelected_cb(IntPtr inst, IntPtr app_info)
		{
			try
			{
				(Object.GetObject(inst, false) as AppChooserWidget).OnApplicationSelected(AppInfoAdapter.GetObject(app_info, false));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000CF0 RID: 3312 RVA: 0x000270DC File Offset: 0x000252DC
		[DefaultSignalHandler(Type = typeof(AppChooserWidget), ConnectionMethod = "OverrideApplicationSelected")]
		protected virtual void OnApplicationSelected(IAppInfo app_info)
		{
			this.InternalApplicationSelected(app_info);
		}

		// Token: 0x06000CF1 RID: 3313 RVA: 0x000270E8 File Offset: 0x000252E8
		private void InternalApplicationSelected(IAppInfo app_info)
		{
			AppChooserWidget.ApplicationSelectedNativeDelegate applicationSelectedNativeDelegate = AppChooserWidget.class_abi.BaseOverride(base.LookupGType(), "application_selected");
			if (applicationSelectedNativeDelegate == null)
			{
				return;
			}
			applicationSelectedNativeDelegate(base.Handle, (app_info == null) ? IntPtr.Zero : ((app_info is Object) ? (app_info as Object).Handle : (app_info as AppInfoAdapter).Handle));
		}

		// Token: 0x170002C6 RID: 710
		// (get) Token: 0x06000CF2 RID: 3314 RVA: 0x00027145 File Offset: 0x00025345
		private static AppChooserWidget.ApplicationActivatedNativeDelegate ApplicationActivatedVMCallback
		{
			get
			{
				if (AppChooserWidget.ApplicationActivated_cb_delegate == null)
				{
					AppChooserWidget.ApplicationActivated_cb_delegate = new AppChooserWidget.ApplicationActivatedNativeDelegate(AppChooserWidget.ApplicationActivated_cb);
				}
				return AppChooserWidget.ApplicationActivated_cb_delegate;
			}
		}

		// Token: 0x06000CF3 RID: 3315 RVA: 0x00027164 File Offset: 0x00025364
		private static void OverrideApplicationActivated(GType gtype)
		{
			AppChooserWidget.OverrideApplicationActivated(gtype, AppChooserWidget.ApplicationActivatedVMCallback);
		}

		// Token: 0x06000CF4 RID: 3316 RVA: 0x00027174 File Offset: 0x00025374
		private unsafe static void OverrideApplicationActivated(GType gtype, AppChooserWidget.ApplicationActivatedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + AppChooserWidget.class_abi.GetFieldOffset("application_activated");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000CF5 RID: 3317 RVA: 0x000271A8 File Offset: 0x000253A8
		private static void ApplicationActivated_cb(IntPtr inst, IntPtr app_info)
		{
			try
			{
				(Object.GetObject(inst, false) as AppChooserWidget).OnApplicationActivated(AppInfoAdapter.GetObject(app_info, false));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000CF6 RID: 3318 RVA: 0x000271E8 File Offset: 0x000253E8
		[DefaultSignalHandler(Type = typeof(AppChooserWidget), ConnectionMethod = "OverrideApplicationActivated")]
		protected virtual void OnApplicationActivated(IAppInfo app_info)
		{
			this.InternalApplicationActivated(app_info);
		}

		// Token: 0x06000CF7 RID: 3319 RVA: 0x000271F4 File Offset: 0x000253F4
		private void InternalApplicationActivated(IAppInfo app_info)
		{
			AppChooserWidget.ApplicationActivatedNativeDelegate applicationActivatedNativeDelegate = AppChooserWidget.class_abi.BaseOverride(base.LookupGType(), "application_activated");
			if (applicationActivatedNativeDelegate == null)
			{
				return;
			}
			applicationActivatedNativeDelegate(base.Handle, (app_info == null) ? IntPtr.Zero : ((app_info is Object) ? (app_info as Object).Handle : (app_info as AppInfoAdapter).Handle));
		}

		// Token: 0x170002C7 RID: 711
		// (get) Token: 0x06000CF8 RID: 3320 RVA: 0x00027251 File Offset: 0x00025451
		private static AppChooserWidget.PopulatePopupNativeDelegate PopulatePopupVMCallback
		{
			get
			{
				if (AppChooserWidget.PopulatePopup_cb_delegate == null)
				{
					AppChooserWidget.PopulatePopup_cb_delegate = new AppChooserWidget.PopulatePopupNativeDelegate(AppChooserWidget.PopulatePopup_cb);
				}
				return AppChooserWidget.PopulatePopup_cb_delegate;
			}
		}

		// Token: 0x06000CF9 RID: 3321 RVA: 0x00027270 File Offset: 0x00025470
		private static void OverridePopulatePopup(GType gtype)
		{
			AppChooserWidget.OverridePopulatePopup(gtype, AppChooserWidget.PopulatePopupVMCallback);
		}

		// Token: 0x06000CFA RID: 3322 RVA: 0x00027280 File Offset: 0x00025480
		private unsafe static void OverridePopulatePopup(GType gtype, AppChooserWidget.PopulatePopupNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + AppChooserWidget.class_abi.GetFieldOffset("populate_popup");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000CFB RID: 3323 RVA: 0x000272B4 File Offset: 0x000254B4
		private static void PopulatePopup_cb(IntPtr inst, IntPtr menu, IntPtr app_info)
		{
			try
			{
				(Object.GetObject(inst, false) as AppChooserWidget).OnPopulatePopup(Object.GetObject(menu) as Menu, AppInfoAdapter.GetObject(app_info, false));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000CFC RID: 3324 RVA: 0x00027300 File Offset: 0x00025500
		[DefaultSignalHandler(Type = typeof(AppChooserWidget), ConnectionMethod = "OverridePopulatePopup")]
		protected virtual void OnPopulatePopup(Menu menu, IAppInfo app_info)
		{
			this.InternalPopulatePopup(menu, app_info);
		}

		// Token: 0x06000CFD RID: 3325 RVA: 0x0002730C File Offset: 0x0002550C
		private void InternalPopulatePopup(Menu menu, IAppInfo app_info)
		{
			AppChooserWidget.PopulatePopupNativeDelegate populatePopupNativeDelegate = AppChooserWidget.class_abi.BaseOverride(base.LookupGType(), "populate_popup");
			if (populatePopupNativeDelegate == null)
			{
				return;
			}
			populatePopupNativeDelegate(base.Handle, (menu == null) ? IntPtr.Zero : menu.Handle, (app_info == null) ? IntPtr.Zero : ((app_info is Object) ? (app_info as Object).Handle : (app_info as AppInfoAdapter).Handle));
		}

		// Token: 0x170002C8 RID: 712
		// (get) Token: 0x06000CFE RID: 3326 RVA: 0x0002737C File Offset: 0x0002557C
		public new static AbiStruct class_abi
		{
			get
			{
				if (AppChooserWidget._class_abi == null)
				{
					AppChooserWidget._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("application_selected", Box.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "application_activated", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("application_activated", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "application_selected", "populate_popup", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("populate_popup", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "application_activated", "padding", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("padding", -1L, (uint)(Marshal.SizeOf(typeof(IntPtr)) * 16), "populate_popup", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return AppChooserWidget._class_abi;
			}
		}

		// Token: 0x170002C9 RID: 713
		// (get) Token: 0x06000CFF RID: 3327 RVA: 0x0002749C File Offset: 0x0002569C
		public new static GType GType
		{
			get
			{
				IntPtr val = AppChooserWidget.gtk_app_chooser_widget_get_type();
				return new GType(val);
			}
		}

		// Token: 0x170002CA RID: 714
		// (get) Token: 0x06000D00 RID: 3328 RVA: 0x000274BA File Offset: 0x000256BA
		public IAppInfo AppInfo
		{
			get
			{
				return AppInfoAdapter.GetObject(AppChooserWidget.gtk_app_chooser_get_app_info(base.Handle), false);
			}
		}

		// Token: 0x170002CB RID: 715
		// (get) Token: 0x06000D01 RID: 3329 RVA: 0x000274D2 File Offset: 0x000256D2
		public string ContentType
		{
			get
			{
				return Marshaller.PtrToStringGFree(AppChooserWidget.gtk_app_chooser_get_content_type(base.Handle));
			}
		}

		// Token: 0x06000D02 RID: 3330 RVA: 0x000274E9 File Offset: 0x000256E9
		public void Refresh()
		{
			AppChooserWidget.gtk_app_chooser_refresh(base.Handle);
		}

		// Token: 0x170002CC RID: 716
		// (get) Token: 0x06000D03 RID: 3331 RVA: 0x000274FC File Offset: 0x000256FC
		public new static AbiStruct abi_info
		{
			get
			{
				if (AppChooserWidget._abi_info == null)
				{
					AppChooserWidget._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Box.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return AppChooserWidget._abi_info;
			}
		}

		// Token: 0x0400063A RID: 1594
		private static AppChooserWidget.d_gtk_app_chooser_widget_new gtk_app_chooser_widget_new = FuncLoader.LoadFunction<AppChooserWidget.d_gtk_app_chooser_widget_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_widget_new"));

		// Token: 0x0400063B RID: 1595
		private static AppChooserWidget.d_gtk_app_chooser_widget_get_show_default gtk_app_chooser_widget_get_show_default = FuncLoader.LoadFunction<AppChooserWidget.d_gtk_app_chooser_widget_get_show_default>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_widget_get_show_default"));

		// Token: 0x0400063C RID: 1596
		private static AppChooserWidget.d_gtk_app_chooser_widget_set_show_default gtk_app_chooser_widget_set_show_default = FuncLoader.LoadFunction<AppChooserWidget.d_gtk_app_chooser_widget_set_show_default>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_widget_set_show_default"));

		// Token: 0x0400063D RID: 1597
		private static AppChooserWidget.d_gtk_app_chooser_widget_get_show_recommended gtk_app_chooser_widget_get_show_recommended = FuncLoader.LoadFunction<AppChooserWidget.d_gtk_app_chooser_widget_get_show_recommended>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_widget_get_show_recommended"));

		// Token: 0x0400063E RID: 1598
		private static AppChooserWidget.d_gtk_app_chooser_widget_set_show_recommended gtk_app_chooser_widget_set_show_recommended = FuncLoader.LoadFunction<AppChooserWidget.d_gtk_app_chooser_widget_set_show_recommended>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_widget_set_show_recommended"));

		// Token: 0x0400063F RID: 1599
		private static AppChooserWidget.d_gtk_app_chooser_widget_get_show_fallback gtk_app_chooser_widget_get_show_fallback = FuncLoader.LoadFunction<AppChooserWidget.d_gtk_app_chooser_widget_get_show_fallback>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_widget_get_show_fallback"));

		// Token: 0x04000640 RID: 1600
		private static AppChooserWidget.d_gtk_app_chooser_widget_set_show_fallback gtk_app_chooser_widget_set_show_fallback = FuncLoader.LoadFunction<AppChooserWidget.d_gtk_app_chooser_widget_set_show_fallback>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_widget_set_show_fallback"));

		// Token: 0x04000641 RID: 1601
		private static AppChooserWidget.d_gtk_app_chooser_widget_get_show_other gtk_app_chooser_widget_get_show_other = FuncLoader.LoadFunction<AppChooserWidget.d_gtk_app_chooser_widget_get_show_other>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_widget_get_show_other"));

		// Token: 0x04000642 RID: 1602
		private static AppChooserWidget.d_gtk_app_chooser_widget_set_show_other gtk_app_chooser_widget_set_show_other = FuncLoader.LoadFunction<AppChooserWidget.d_gtk_app_chooser_widget_set_show_other>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_widget_set_show_other"));

		// Token: 0x04000643 RID: 1603
		private static AppChooserWidget.d_gtk_app_chooser_widget_get_show_all gtk_app_chooser_widget_get_show_all = FuncLoader.LoadFunction<AppChooserWidget.d_gtk_app_chooser_widget_get_show_all>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_widget_get_show_all"));

		// Token: 0x04000644 RID: 1604
		private static AppChooserWidget.d_gtk_app_chooser_widget_set_show_all gtk_app_chooser_widget_set_show_all = FuncLoader.LoadFunction<AppChooserWidget.d_gtk_app_chooser_widget_set_show_all>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_widget_set_show_all"));

		// Token: 0x04000645 RID: 1605
		private static AppChooserWidget.d_gtk_app_chooser_widget_get_default_text gtk_app_chooser_widget_get_default_text = FuncLoader.LoadFunction<AppChooserWidget.d_gtk_app_chooser_widget_get_default_text>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_widget_get_default_text"));

		// Token: 0x04000646 RID: 1606
		private static AppChooserWidget.d_gtk_app_chooser_widget_set_default_text gtk_app_chooser_widget_set_default_text = FuncLoader.LoadFunction<AppChooserWidget.d_gtk_app_chooser_widget_set_default_text>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_widget_set_default_text"));

		// Token: 0x04000647 RID: 1607
		private static AppChooserWidget.ApplicationSelectedNativeDelegate ApplicationSelected_cb_delegate;

		// Token: 0x04000648 RID: 1608
		private static AppChooserWidget.ApplicationActivatedNativeDelegate ApplicationActivated_cb_delegate;

		// Token: 0x04000649 RID: 1609
		private static AppChooserWidget.PopulatePopupNativeDelegate PopulatePopup_cb_delegate;

		// Token: 0x0400064A RID: 1610
		private static AbiStruct _class_abi = null;

		// Token: 0x0400064B RID: 1611
		private static AppChooserWidget.d_gtk_app_chooser_widget_get_type gtk_app_chooser_widget_get_type = FuncLoader.LoadFunction<AppChooserWidget.d_gtk_app_chooser_widget_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_widget_get_type"));

		// Token: 0x0400064C RID: 1612
		private static AppChooserWidget.d_gtk_app_chooser_get_app_info gtk_app_chooser_get_app_info = FuncLoader.LoadFunction<AppChooserWidget.d_gtk_app_chooser_get_app_info>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_get_app_info"));

		// Token: 0x0400064D RID: 1613
		private static AppChooserWidget.d_gtk_app_chooser_get_content_type gtk_app_chooser_get_content_type = FuncLoader.LoadFunction<AppChooserWidget.d_gtk_app_chooser_get_content_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_get_content_type"));

		// Token: 0x0400064E RID: 1614
		private static AppChooserWidget.d_gtk_app_chooser_refresh gtk_app_chooser_refresh = FuncLoader.LoadFunction<AppChooserWidget.d_gtk_app_chooser_refresh>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_refresh"));

		// Token: 0x0400064F RID: 1615
		private static AbiStruct _abi_info = null;

		// Token: 0x02000A3E RID: 2622
		// (Invoke) Token: 0x06004FFF RID: 20479
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_app_chooser_widget_new(IntPtr content_type);

		// Token: 0x02000A3F RID: 2623
		// (Invoke) Token: 0x06005003 RID: 20483
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_app_chooser_widget_get_show_default(IntPtr raw);

		// Token: 0x02000A40 RID: 2624
		// (Invoke) Token: 0x06005007 RID: 20487
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_app_chooser_widget_set_show_default(IntPtr raw, bool setting);

		// Token: 0x02000A41 RID: 2625
		// (Invoke) Token: 0x0600500B RID: 20491
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_app_chooser_widget_get_show_recommended(IntPtr raw);

		// Token: 0x02000A42 RID: 2626
		// (Invoke) Token: 0x0600500F RID: 20495
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_app_chooser_widget_set_show_recommended(IntPtr raw, bool setting);

		// Token: 0x02000A43 RID: 2627
		// (Invoke) Token: 0x06005013 RID: 20499
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_app_chooser_widget_get_show_fallback(IntPtr raw);

		// Token: 0x02000A44 RID: 2628
		// (Invoke) Token: 0x06005017 RID: 20503
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_app_chooser_widget_set_show_fallback(IntPtr raw, bool setting);

		// Token: 0x02000A45 RID: 2629
		// (Invoke) Token: 0x0600501B RID: 20507
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_app_chooser_widget_get_show_other(IntPtr raw);

		// Token: 0x02000A46 RID: 2630
		// (Invoke) Token: 0x0600501F RID: 20511
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_app_chooser_widget_set_show_other(IntPtr raw, bool setting);

		// Token: 0x02000A47 RID: 2631
		// (Invoke) Token: 0x06005023 RID: 20515
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_app_chooser_widget_get_show_all(IntPtr raw);

		// Token: 0x02000A48 RID: 2632
		// (Invoke) Token: 0x06005027 RID: 20519
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_app_chooser_widget_set_show_all(IntPtr raw, bool setting);

		// Token: 0x02000A49 RID: 2633
		// (Invoke) Token: 0x0600502B RID: 20523
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_app_chooser_widget_get_default_text(IntPtr raw);

		// Token: 0x02000A4A RID: 2634
		// (Invoke) Token: 0x0600502F RID: 20527
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_app_chooser_widget_set_default_text(IntPtr raw, IntPtr text);

		// Token: 0x02000A4B RID: 2635
		// (Invoke) Token: 0x06005033 RID: 20531
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ApplicationSelectedNativeDelegate(IntPtr inst, IntPtr app_info);

		// Token: 0x02000A4C RID: 2636
		// (Invoke) Token: 0x06005037 RID: 20535
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ApplicationActivatedNativeDelegate(IntPtr inst, IntPtr app_info);

		// Token: 0x02000A4D RID: 2637
		// (Invoke) Token: 0x0600503B RID: 20539
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void PopulatePopupNativeDelegate(IntPtr inst, IntPtr menu, IntPtr app_info);

		// Token: 0x02000A4E RID: 2638
		// (Invoke) Token: 0x0600503F RID: 20543
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_app_chooser_widget_get_type();

		// Token: 0x02000A4F RID: 2639
		// (Invoke) Token: 0x06005043 RID: 20547
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_app_chooser_get_app_info(IntPtr raw);

		// Token: 0x02000A50 RID: 2640
		// (Invoke) Token: 0x06005047 RID: 20551
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_app_chooser_get_content_type(IntPtr raw);

		// Token: 0x02000A51 RID: 2641
		// (Invoke) Token: 0x0600504B RID: 20555
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_app_chooser_refresh(IntPtr raw);
	}
}
