﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x020001B3 RID: 435
	internal class CornerTypeGType
	{
		// Token: 0x17000409 RID: 1033
		// (get) Token: 0x06001159 RID: 4441 RVA: 0x00033B8A File Offset: 0x00031D8A
		public static GType GType
		{
			get
			{
				return new GType(CornerTypeGType.gtk_corner_type_get_type());
			}
		}

		// Token: 0x0400081B RID: 2075
		private static CornerTypeGType.d_gtk_corner_type_get_type gtk_corner_type_get_type = FuncLoader.LoadFunction<CornerTypeGType.d_gtk_corner_type_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_corner_type_get_type"));

		// Token: 0x02000B66 RID: 2918
		// (Invoke) Token: 0x060054A1 RID: 21665
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_corner_type_get_type();
	}
}
