﻿using System;

namespace Gtk
{
	// Token: 0x02000162 RID: 354
	// (Invoke) Token: 0x06000E6F RID: 3695
	public delegate void CancelHandler(object o, CancelArgs args);
}
