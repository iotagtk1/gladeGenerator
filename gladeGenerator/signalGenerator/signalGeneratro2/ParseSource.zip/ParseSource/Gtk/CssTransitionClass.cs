﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x02000208 RID: 520
	public class CssTransitionClass : Opaque
	{
		// Token: 0x0600122A RID: 4650 RVA: 0x00034FF1 File Offset: 0x000331F1
		public CssTransitionClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000463 RID: 1123
		// (get) Token: 0x0600122B RID: 4651 RVA: 0x00034FFA File Offset: 0x000331FA
		public static AbiStruct abi_info
		{
			get
			{
				if (CssTransitionClass._abi_info == null)
				{
					CssTransitionClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssTransitionClass._abi_info;
			}
		}

		// Token: 0x0400088E RID: 2190
		private static AbiStruct _abi_info;
	}
}
