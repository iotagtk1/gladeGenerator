﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x0200014B RID: 331
	public class BoxGadgetClass : Opaque
	{
		// Token: 0x06000E28 RID: 3624 RVA: 0x0002AA64 File Offset: 0x00028C64
		public BoxGadgetClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000318 RID: 792
		// (get) Token: 0x06000E29 RID: 3625 RVA: 0x0002AA6D File Offset: 0x00028C6D
		public static AbiStruct abi_info
		{
			get
			{
				if (BoxGadgetClass._abi_info == null)
				{
					BoxGadgetClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return BoxGadgetClass._abi_info;
			}
		}

		// Token: 0x040006F6 RID: 1782
		private static AbiStruct _abi_info;
	}
}
