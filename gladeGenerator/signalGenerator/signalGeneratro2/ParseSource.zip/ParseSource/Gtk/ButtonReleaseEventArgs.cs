﻿using System;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x02000157 RID: 343
	public class ButtonReleaseEventArgs : SignalArgs
	{
		// Token: 0x17000328 RID: 808
		// (get) Token: 0x06000E55 RID: 3669 RVA: 0x0002B006 File Offset: 0x00029206
		public EventButton Event
		{
			get
			{
				return (EventButton)base.Args[0];
			}
		}
	}
}
