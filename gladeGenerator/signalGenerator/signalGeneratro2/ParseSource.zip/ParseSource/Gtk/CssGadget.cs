﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001C5 RID: 453
	public class CssGadget : Opaque
	{
		// Token: 0x06001185 RID: 4485 RVA: 0x00033D63 File Offset: 0x00031F63
		public CssGadget(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000416 RID: 1046
		// (get) Token: 0x06001186 RID: 4486 RVA: 0x00033D6C File Offset: 0x00031F6C
		public static AbiStruct abi_info
		{
			get
			{
				if (CssGadget._abi_info == null)
				{
					CssGadget._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssGadget._abi_info;
			}
		}

		// Token: 0x04000825 RID: 2085
		private static AbiStruct _abi_info;
	}
}
