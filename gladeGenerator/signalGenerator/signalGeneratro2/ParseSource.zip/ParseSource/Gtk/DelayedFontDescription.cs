﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x0200021D RID: 541
	public class DelayedFontDescription : Opaque
	{
		// Token: 0x06001265 RID: 4709 RVA: 0x000351F0 File Offset: 0x000333F0
		public DelayedFontDescription(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000472 RID: 1138
		// (get) Token: 0x06001266 RID: 4710 RVA: 0x000351F9 File Offset: 0x000333F9
		public static AbiStruct abi_info
		{
			get
			{
				if (DelayedFontDescription._abi_info == null)
				{
					DelayedFontDescription._abi_info = new AbiStruct(new List<AbiField>());
				}
				return DelayedFontDescription._abi_info;
			}
		}

		// Token: 0x04000895 RID: 2197
		private static AbiStruct _abi_info;
	}
}
