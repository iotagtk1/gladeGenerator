﻿using System;

namespace Gtk
{
	// Token: 0x02000106 RID: 262
	// (Invoke) Token: 0x06000BC0 RID: 3008
	public delegate void ActionActivatedHandler(object o, ActionActivatedArgs args);
}
