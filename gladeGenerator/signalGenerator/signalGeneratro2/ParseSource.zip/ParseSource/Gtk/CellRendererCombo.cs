﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x02000172 RID: 370
	public class CellRendererCombo : CellRendererText
	{
		// Token: 0x06000F8D RID: 3981 RVA: 0x0002EF89 File Offset: 0x0002D189
		public CellRendererCombo(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000F8E RID: 3982 RVA: 0x0002EF94 File Offset: 0x0002D194
		public CellRendererCombo() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(CellRendererCombo))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = CellRendererCombo.gtk_cell_renderer_combo_new();
		}

		// Token: 0x17000368 RID: 872
		// (get) Token: 0x06000F8F RID: 3983 RVA: 0x0002EFE8 File Offset: 0x0002D1E8
		// (set) Token: 0x06000F90 RID: 3984 RVA: 0x0002F014 File Offset: 0x0002D214
		[Property("model")]
		public ITreeModel Model
		{
			get
			{
				Value property = base.GetProperty("model");
				ITreeModel @object = TreeModelAdapter.GetObject((Object)property);
				property.Dispose();
				return @object;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("model", val);
				val.Dispose();
			}
		}

		// Token: 0x17000369 RID: 873
		// (get) Token: 0x06000F91 RID: 3985 RVA: 0x0002F03C File Offset: 0x0002D23C
		// (set) Token: 0x06000F92 RID: 3986 RVA: 0x0002F064 File Offset: 0x0002D264
		[Property("text-column")]
		public int TextColumn
		{
			get
			{
				Value property = base.GetProperty("text-column");
				int result = (int)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("text-column", val);
				val.Dispose();
			}
		}

		// Token: 0x1700036A RID: 874
		// (get) Token: 0x06000F93 RID: 3987 RVA: 0x0002F08C File Offset: 0x0002D28C
		// (set) Token: 0x06000F94 RID: 3988 RVA: 0x0002F0B4 File Offset: 0x0002D2B4
		[Property("has-entry")]
		public bool HasEntry
		{
			get
			{
				Value property = base.GetProperty("has-entry");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("has-entry", val);
				val.Dispose();
			}
		}

		// Token: 0x14000064 RID: 100
		// (add) Token: 0x06000F95 RID: 3989 RVA: 0x0002F0DC File Offset: 0x0002D2DC
		// (remove) Token: 0x06000F96 RID: 3990 RVA: 0x0002F0F4 File Offset: 0x0002D2F4
		[Signal("changed")]
		public event ChangedHandler Changed
		{
			add
			{
				base.AddSignalHandler("changed", value, typeof(ChangedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("changed", value);
			}
		}

		// Token: 0x1700036B RID: 875
		// (get) Token: 0x06000F97 RID: 3991 RVA: 0x0002F102 File Offset: 0x0002D302
		private static CellRendererCombo.ChangedNativeDelegate ChangedVMCallback
		{
			get
			{
				if (CellRendererCombo.Changed_cb_delegate == null)
				{
					CellRendererCombo.Changed_cb_delegate = new CellRendererCombo.ChangedNativeDelegate(CellRendererCombo.Changed_cb);
				}
				return CellRendererCombo.Changed_cb_delegate;
			}
		}

		// Token: 0x06000F98 RID: 3992 RVA: 0x0002F121 File Offset: 0x0002D321
		private static void OverrideChanged(GType gtype)
		{
			CellRendererCombo.OverrideChanged(gtype, CellRendererCombo.ChangedVMCallback);
		}

		// Token: 0x06000F99 RID: 3993 RVA: 0x0002F12E File Offset: 0x0002D32E
		private static void OverrideChanged(GType gtype, CellRendererCombo.ChangedNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "changed", callback);
		}

		// Token: 0x06000F9A RID: 3994 RVA: 0x0002F13C File Offset: 0x0002D33C
		private static void Changed_cb(IntPtr inst, IntPtr p0, IntPtr p1)
		{
			try
			{
				(Object.GetObject(inst, false) as CellRendererCombo).OnChanged(Marshaller.PtrToStringGFree(p0), TreeIter.New(p1));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000F9B RID: 3995 RVA: 0x0002F180 File Offset: 0x0002D380
		[DefaultSignalHandler(Type = typeof(CellRendererCombo), ConnectionMethod = "OverrideChanged")]
		protected virtual void OnChanged(string p0, TreeIter p1)
		{
			this.InternalChanged(p0, p1);
		}

		// Token: 0x06000F9C RID: 3996 RVA: 0x0002F18C File Offset: 0x0002D38C
		private void InternalChanged(string p0, TreeIter p1)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(3U);
			Value[] array = new Value[3];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(p0);
			valueArray.Append(array[1]);
			array[2] = new Value(p1);
			valueArray.Append(array[2]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x1700036C RID: 876
		// (get) Token: 0x06000F9D RID: 3997 RVA: 0x0002F238 File Offset: 0x0002D438
		public new static AbiStruct class_abi
		{
			get
			{
				if (CellRendererCombo._class_abi == null)
				{
					CellRendererCombo._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("_gtk_reserved1", CellRendererText.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellRendererCombo._class_abi;
			}
		}

		// Token: 0x1700036D RID: 877
		// (get) Token: 0x06000F9E RID: 3998 RVA: 0x0002F354 File Offset: 0x0002D554
		public new static GType GType
		{
			get
			{
				IntPtr val = CellRendererCombo.gtk_cell_renderer_combo_get_type();
				return new GType(val);
			}
		}

		// Token: 0x1700036E RID: 878
		// (get) Token: 0x06000F9F RID: 3999 RVA: 0x0002F374 File Offset: 0x0002D574
		public new static AbiStruct abi_info
		{
			get
			{
				if (CellRendererCombo._abi_info == null)
				{
					CellRendererCombo._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", CellRendererText.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellRendererCombo._abi_info;
			}
		}

		// Token: 0x04000797 RID: 1943
		private static CellRendererCombo.d_gtk_cell_renderer_combo_new gtk_cell_renderer_combo_new = FuncLoader.LoadFunction<CellRendererCombo.d_gtk_cell_renderer_combo_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_combo_new"));

		// Token: 0x04000798 RID: 1944
		private static CellRendererCombo.ChangedNativeDelegate Changed_cb_delegate;

		// Token: 0x04000799 RID: 1945
		private static AbiStruct _class_abi = null;

		// Token: 0x0400079A RID: 1946
		private static CellRendererCombo.d_gtk_cell_renderer_combo_get_type gtk_cell_renderer_combo_get_type = FuncLoader.LoadFunction<CellRendererCombo.d_gtk_cell_renderer_combo_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_combo_get_type"));

		// Token: 0x0400079B RID: 1947
		private static AbiStruct _abi_info = null;

		// Token: 0x02000B19 RID: 2841
		// (Invoke) Token: 0x06005371 RID: 21361
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_renderer_combo_new();

		// Token: 0x02000B1A RID: 2842
		// (Invoke) Token: 0x06005375 RID: 21365
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ChangedNativeDelegate(IntPtr inst, IntPtr p0, IntPtr p1);

		// Token: 0x02000B1B RID: 2843
		// (Invoke) Token: 0x06005379 RID: 21369
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_renderer_combo_get_type();
	}
}
