﻿using System;

namespace Gtk
{
	// Token: 0x0200017F RID: 383
	// (Invoke) Token: 0x06001056 RID: 4182
	public delegate void ChangedHandler(object o, ChangedArgs args);
}
