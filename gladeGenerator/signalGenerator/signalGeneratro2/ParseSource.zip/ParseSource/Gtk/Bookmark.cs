﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x02000140 RID: 320
	public struct Bookmark : IEquatable<Bookmark>
	{
		// Token: 0x170002FF RID: 767
		// (get) Token: 0x06000DDE RID: 3550 RVA: 0x00029E15 File Offset: 0x00028015
		// (set) Token: 0x06000DDF RID: 3551 RVA: 0x00029E23 File Offset: 0x00028023
		public IFile File
		{
			get
			{
				return FileAdapter.GetObject(this._file, false);
			}
			set
			{
				this._file = ((value == null) ? IntPtr.Zero : ((value is Object) ? (value as Object).Handle : (value as FileAdapter).Handle));
			}
		}

		// Token: 0x06000DE0 RID: 3552 RVA: 0x00029E55 File Offset: 0x00028055
		public static Bookmark New(IntPtr raw)
		{
			if (raw == IntPtr.Zero)
			{
				return Bookmark.Zero;
			}
			return (Bookmark)Marshal.PtrToStructure(raw, typeof(Bookmark));
		}

		// Token: 0x06000DE1 RID: 3553 RVA: 0x00029E7F File Offset: 0x0002807F
		public bool Equals(Bookmark other)
		{
			return this.File.Equals(other.File) && this.Label.Equals(other.Label);
		}

		// Token: 0x06000DE2 RID: 3554 RVA: 0x00029EA8 File Offset: 0x000280A8
		public override bool Equals(object other)
		{
			return other is Bookmark && this.Equals((Bookmark)other);
		}

		// Token: 0x06000DE3 RID: 3555 RVA: 0x00029EC0 File Offset: 0x000280C0
		public override int GetHashCode()
		{
			return base.GetType().FullName.GetHashCode() ^ this.File.GetHashCode() ^ this.Label.GetHashCode();
		}

		// Token: 0x17000300 RID: 768
		// (get) Token: 0x06000DE4 RID: 3556 RVA: 0x00029EF4 File Offset: 0x000280F4
		private static GType GType
		{
			get
			{
				return GType.Pointer;
			}
		}

		// Token: 0x040006C3 RID: 1731
		private IntPtr _file;

		// Token: 0x040006C4 RID: 1732
		public string Label;

		// Token: 0x040006C5 RID: 1733
		public static Bookmark Zero;
	}
}
