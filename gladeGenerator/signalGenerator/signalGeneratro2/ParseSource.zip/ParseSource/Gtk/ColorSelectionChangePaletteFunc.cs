﻿using System;
using Gdk;

namespace Gtk
{
	// Token: 0x020001A3 RID: 419
	// (Invoke) Token: 0x06001128 RID: 4392
	public delegate void ColorSelectionChangePaletteFunc(Color colors, int n_colors);
}
