﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x02000211 RID: 529
	public class CustomPaperUnixDialog : Dialog
	{
		// Token: 0x06001241 RID: 4673 RVA: 0x000350F1 File Offset: 0x000332F1
		public CustomPaperUnixDialog(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06001242 RID: 4674 RVA: 0x000350FA File Offset: 0x000332FA
		protected CustomPaperUnixDialog() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x1700046B RID: 1131
		// (get) Token: 0x06001243 RID: 4675 RVA: 0x0003511C File Offset: 0x0003331C
		public new static GType GType
		{
			get
			{
				IntPtr val = CustomPaperUnixDialog.gtk_custom_paper_unix_dialog_get_type();
				return new GType(val);
			}
		}

		// Token: 0x04000893 RID: 2195
		private static CustomPaperUnixDialog.d_gtk_custom_paper_unix_dialog_get_type gtk_custom_paper_unix_dialog_get_type = FuncLoader.LoadFunction<CustomPaperUnixDialog.d_gtk_custom_paper_unix_dialog_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_custom_paper_unix_dialog_get_type"));

		// Token: 0x02000B80 RID: 2944
		// (Invoke) Token: 0x06005507 RID: 21767
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_custom_paper_unix_dialog_get_type();
	}
}
