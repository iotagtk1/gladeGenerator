﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000180 RID: 384
	public class ChangedArgs : SignalArgs
	{
		// Token: 0x170003C2 RID: 962
		// (get) Token: 0x06001059 RID: 4185 RVA: 0x00031820 File Offset: 0x0002FA20
		public RadioAction Current
		{
			get
			{
				return (RadioAction)base.Args[0];
			}
		}
	}
}
