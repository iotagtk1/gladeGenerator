﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x0200015C RID: 348
	public class CacheEntry : Opaque
	{
		// Token: 0x06000E5D RID: 3677 RVA: 0x0002B089 File Offset: 0x00029289
		public CacheEntry(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700032B RID: 811
		// (get) Token: 0x06000E5E RID: 3678 RVA: 0x0002B092 File Offset: 0x00029292
		public static AbiStruct abi_info
		{
			get
			{
				if (CacheEntry._abi_info == null)
				{
					CacheEntry._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CacheEntry._abi_info;
			}
		}

		// Token: 0x04000728 RID: 1832
		private static AbiStruct _abi_info;
	}
}
