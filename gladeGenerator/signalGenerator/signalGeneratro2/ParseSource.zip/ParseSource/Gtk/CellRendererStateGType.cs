﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x0200017A RID: 378
	internal class CellRendererStateGType
	{
		// Token: 0x17000392 RID: 914
		// (get) Token: 0x06000FE8 RID: 4072 RVA: 0x0003049B File Offset: 0x0002E69B
		public static GType GType
		{
			get
			{
				return new GType(CellRendererStateGType.gtk_cell_renderer_state_get_type());
			}
		}

		// Token: 0x040007BB RID: 1979
		private static CellRendererStateGType.d_gtk_cell_renderer_state_get_type gtk_cell_renderer_state_get_type = FuncLoader.LoadFunction<CellRendererStateGType.d_gtk_cell_renderer_state_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_renderer_state_get_type"));

		// Token: 0x02000B27 RID: 2855
		// (Invoke) Token: 0x060053A9 RID: 21417
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_renderer_state_get_type();
	}
}
