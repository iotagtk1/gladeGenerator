﻿using System;

namespace Gtk
{
	// Token: 0x02000161 RID: 353
	// (Invoke) Token: 0x06000E6B RID: 3691
	public delegate void Callback(Widget widget);
}
