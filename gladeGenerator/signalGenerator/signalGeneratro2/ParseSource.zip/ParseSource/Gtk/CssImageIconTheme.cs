﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001D1 RID: 465
	public class CssImageIconTheme : Opaque
	{
		// Token: 0x0600119D RID: 4509 RVA: 0x00033F2B File Offset: 0x0003212B
		public CssImageIconTheme(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000422 RID: 1058
		// (get) Token: 0x0600119E RID: 4510 RVA: 0x00033F34 File Offset: 0x00032134
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImageIconTheme._abi_info == null)
				{
					CssImageIconTheme._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImageIconTheme._abi_info;
			}
		}

		// Token: 0x04000831 RID: 2097
		private static AbiStruct _abi_info;
	}
}
