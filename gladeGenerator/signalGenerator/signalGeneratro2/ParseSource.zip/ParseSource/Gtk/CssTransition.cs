﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x02000207 RID: 519
	public class CssTransition : Opaque
	{
		// Token: 0x06001228 RID: 4648 RVA: 0x00034FCB File Offset: 0x000331CB
		public CssTransition(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000462 RID: 1122
		// (get) Token: 0x06001229 RID: 4649 RVA: 0x00034FD4 File Offset: 0x000331D4
		public static AbiStruct abi_info
		{
			get
			{
				if (CssTransition._abi_info == null)
				{
					CssTransition._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssTransition._abi_info;
			}
		}

		// Token: 0x0400088D RID: 2189
		private static AbiStruct _abi_info;
	}
}
