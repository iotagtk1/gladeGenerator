﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000215 RID: 533
	public class CycleChildFocusArgs : SignalArgs
	{
		// Token: 0x1700046D RID: 1133
		// (get) Token: 0x0600124F RID: 4687 RVA: 0x0003516E File Offset: 0x0003336E
		public bool Reverse
		{
			get
			{
				return (bool)base.Args[0];
			}
		}
	}
}
