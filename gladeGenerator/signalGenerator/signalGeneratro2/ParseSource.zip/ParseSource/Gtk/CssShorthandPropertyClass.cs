﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001FD RID: 509
	public class CssShorthandPropertyClass : Opaque
	{
		// Token: 0x06001214 RID: 4628 RVA: 0x00034E4F File Offset: 0x0003304F
		public CssShorthandPropertyClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000458 RID: 1112
		// (get) Token: 0x06001215 RID: 4629 RVA: 0x00034E58 File Offset: 0x00033058
		public static AbiStruct abi_info
		{
			get
			{
				if (CssShorthandPropertyClass._abi_info == null)
				{
					CssShorthandPropertyClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssShorthandPropertyClass._abi_info;
			}
		}

		// Token: 0x04000883 RID: 2179
		private static AbiStruct _abi_info;
	}
}
