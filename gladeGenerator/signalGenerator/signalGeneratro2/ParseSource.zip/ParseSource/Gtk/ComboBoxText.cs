﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x020000E4 RID: 228
	public class ComboBoxText : ComboBox
	{
		// Token: 0x06000799 RID: 1945 RVA: 0x00016BA0 File Offset: 0x00014DA0
		protected ComboBoxText(bool has_entry) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(ComboBoxText))
			{
				this.CreateNativeObject(new string[]
				{
					"has-entry",
					"entry-text-column",
					"id-column"
				}, new Value[]
				{
					new Value(has_entry),
					new Value(0),
					new Value(1)
				});
				return;
			}
			if (has_entry)
			{
				this.Raw = ComboBoxText.gtk_combo_box_text_new_with_entry();
				return;
			}
			this.Raw = ComboBoxText.gtk_combo_box_text_new();
		}

		// Token: 0x0600079A RID: 1946 RVA: 0x00016C45 File Offset: 0x00014E45
		public ComboBoxText(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x0600079B RID: 1947 RVA: 0x00016C50 File Offset: 0x00014E50
		public ComboBoxText() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(ComboBoxText))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = ComboBoxText.gtk_combo_box_text_new();
		}

		// Token: 0x0600079C RID: 1948 RVA: 0x00016CA2 File Offset: 0x00014EA2
		public new static ComboBoxText NewWithEntry()
		{
			return new ComboBoxText(ComboBoxText.gtk_combo_box_text_new_with_entry());
		}

		// Token: 0x17000154 RID: 340
		// (get) Token: 0x0600079D RID: 1949 RVA: 0x00016CB4 File Offset: 0x00014EB4
		public new static AbiStruct class_abi
		{
			get
			{
				if (ComboBoxText._class_abi == null)
				{
					ComboBoxText._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("_gtk_reserved1", ComboBox.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return ComboBoxText._class_abi;
			}
		}

		// Token: 0x0600079E RID: 1950 RVA: 0x00016DD0 File Offset: 0x00014FD0
		public void Append(string id, string text)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(id);
			IntPtr intPtr2 = Marshaller.StringToPtrGStrdup(text);
			ComboBoxText.gtk_combo_box_text_append(base.Handle, intPtr, intPtr2);
			Marshaller.Free(intPtr);
			Marshaller.Free(intPtr2);
		}

		// Token: 0x0600079F RID: 1951 RVA: 0x00016E0C File Offset: 0x0001500C
		public void AppendText(string text)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(text);
			ComboBoxText.gtk_combo_box_text_append_text(base.Handle, intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x17000155 RID: 341
		// (get) Token: 0x060007A0 RID: 1952 RVA: 0x00016E37 File Offset: 0x00015037
		public string ActiveText
		{
			get
			{
				return Marshaller.PtrToStringGFree(ComboBoxText.gtk_combo_box_text_get_active_text(base.Handle));
			}
		}

		// Token: 0x17000156 RID: 342
		// (get) Token: 0x060007A1 RID: 1953 RVA: 0x00016E50 File Offset: 0x00015050
		public new static GType GType
		{
			get
			{
				IntPtr val = ComboBoxText.gtk_combo_box_text_get_type();
				return new GType(val);
			}
		}

		// Token: 0x060007A2 RID: 1954 RVA: 0x00016E70 File Offset: 0x00015070
		public void Insert(int position, string id, string text)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(id);
			IntPtr intPtr2 = Marshaller.StringToPtrGStrdup(text);
			ComboBoxText.gtk_combo_box_text_insert(base.Handle, position, intPtr, intPtr2);
			Marshaller.Free(intPtr);
			Marshaller.Free(intPtr2);
		}

		// Token: 0x060007A3 RID: 1955 RVA: 0x00016EAC File Offset: 0x000150AC
		public void InsertText(int position, string text)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(text);
			ComboBoxText.gtk_combo_box_text_insert_text(base.Handle, position, intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x060007A4 RID: 1956 RVA: 0x00016ED8 File Offset: 0x000150D8
		public void Prepend(string id, string text)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(id);
			IntPtr intPtr2 = Marshaller.StringToPtrGStrdup(text);
			ComboBoxText.gtk_combo_box_text_prepend(base.Handle, intPtr, intPtr2);
			Marshaller.Free(intPtr);
			Marshaller.Free(intPtr2);
		}

		// Token: 0x060007A5 RID: 1957 RVA: 0x00016F14 File Offset: 0x00015114
		public void PrependText(string text)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(text);
			ComboBoxText.gtk_combo_box_text_prepend_text(base.Handle, intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x060007A6 RID: 1958 RVA: 0x00016F3F File Offset: 0x0001513F
		public void Remove(int position)
		{
			ComboBoxText.gtk_combo_box_text_remove(base.Handle, position);
		}

		// Token: 0x060007A7 RID: 1959 RVA: 0x00016F52 File Offset: 0x00015152
		public void RemoveAll()
		{
			ComboBoxText.gtk_combo_box_text_remove_all(base.Handle);
		}

		// Token: 0x17000157 RID: 343
		// (get) Token: 0x060007A8 RID: 1960 RVA: 0x00016F64 File Offset: 0x00015164
		public new static AbiStruct abi_info
		{
			get
			{
				if (ComboBoxText._abi_info == null)
				{
					ComboBoxText._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", ComboBox.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return ComboBoxText._abi_info;
			}
		}

		// Token: 0x040003D5 RID: 981
		private static ComboBoxText.d_gtk_combo_box_text_new gtk_combo_box_text_new = FuncLoader.LoadFunction<ComboBoxText.d_gtk_combo_box_text_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_text_new"));

		// Token: 0x040003D6 RID: 982
		private static ComboBoxText.d_gtk_combo_box_text_new_with_entry gtk_combo_box_text_new_with_entry = FuncLoader.LoadFunction<ComboBoxText.d_gtk_combo_box_text_new_with_entry>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_text_new_with_entry"));

		// Token: 0x040003D7 RID: 983
		private static AbiStruct _class_abi = null;

		// Token: 0x040003D8 RID: 984
		private static ComboBoxText.d_gtk_combo_box_text_append gtk_combo_box_text_append = FuncLoader.LoadFunction<ComboBoxText.d_gtk_combo_box_text_append>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_text_append"));

		// Token: 0x040003D9 RID: 985
		private static ComboBoxText.d_gtk_combo_box_text_append_text gtk_combo_box_text_append_text = FuncLoader.LoadFunction<ComboBoxText.d_gtk_combo_box_text_append_text>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_text_append_text"));

		// Token: 0x040003DA RID: 986
		private static ComboBoxText.d_gtk_combo_box_text_get_active_text gtk_combo_box_text_get_active_text = FuncLoader.LoadFunction<ComboBoxText.d_gtk_combo_box_text_get_active_text>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_text_get_active_text"));

		// Token: 0x040003DB RID: 987
		private static ComboBoxText.d_gtk_combo_box_text_get_type gtk_combo_box_text_get_type = FuncLoader.LoadFunction<ComboBoxText.d_gtk_combo_box_text_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_text_get_type"));

		// Token: 0x040003DC RID: 988
		private static ComboBoxText.d_gtk_combo_box_text_insert gtk_combo_box_text_insert = FuncLoader.LoadFunction<ComboBoxText.d_gtk_combo_box_text_insert>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_text_insert"));

		// Token: 0x040003DD RID: 989
		private static ComboBoxText.d_gtk_combo_box_text_insert_text gtk_combo_box_text_insert_text = FuncLoader.LoadFunction<ComboBoxText.d_gtk_combo_box_text_insert_text>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_text_insert_text"));

		// Token: 0x040003DE RID: 990
		private static ComboBoxText.d_gtk_combo_box_text_prepend gtk_combo_box_text_prepend = FuncLoader.LoadFunction<ComboBoxText.d_gtk_combo_box_text_prepend>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_text_prepend"));

		// Token: 0x040003DF RID: 991
		private static ComboBoxText.d_gtk_combo_box_text_prepend_text gtk_combo_box_text_prepend_text = FuncLoader.LoadFunction<ComboBoxText.d_gtk_combo_box_text_prepend_text>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_text_prepend_text"));

		// Token: 0x040003E0 RID: 992
		private static ComboBoxText.d_gtk_combo_box_text_remove gtk_combo_box_text_remove = FuncLoader.LoadFunction<ComboBoxText.d_gtk_combo_box_text_remove>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_text_remove"));

		// Token: 0x040003E1 RID: 993
		private static ComboBoxText.d_gtk_combo_box_text_remove_all gtk_combo_box_text_remove_all = FuncLoader.LoadFunction<ComboBoxText.d_gtk_combo_box_text_remove_all>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_combo_box_text_remove_all"));

		// Token: 0x040003E2 RID: 994
		private static AbiStruct _abi_info = null;

		// Token: 0x02000805 RID: 2053
		// (Invoke) Token: 0x06004734 RID: 18228
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_combo_box_text_new();

		// Token: 0x02000806 RID: 2054
		// (Invoke) Token: 0x06004738 RID: 18232
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_combo_box_text_new_with_entry();

		// Token: 0x02000807 RID: 2055
		// (Invoke) Token: 0x0600473C RID: 18236
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_text_append(IntPtr raw, IntPtr id, IntPtr text);

		// Token: 0x02000808 RID: 2056
		// (Invoke) Token: 0x06004740 RID: 18240
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_text_append_text(IntPtr raw, IntPtr text);

		// Token: 0x02000809 RID: 2057
		// (Invoke) Token: 0x06004744 RID: 18244
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_combo_box_text_get_active_text(IntPtr raw);

		// Token: 0x0200080A RID: 2058
		// (Invoke) Token: 0x06004748 RID: 18248
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_combo_box_text_get_type();

		// Token: 0x0200080B RID: 2059
		// (Invoke) Token: 0x0600474C RID: 18252
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_text_insert(IntPtr raw, int position, IntPtr id, IntPtr text);

		// Token: 0x0200080C RID: 2060
		// (Invoke) Token: 0x06004750 RID: 18256
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_text_insert_text(IntPtr raw, int position, IntPtr text);

		// Token: 0x0200080D RID: 2061
		// (Invoke) Token: 0x06004754 RID: 18260
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_text_prepend(IntPtr raw, IntPtr id, IntPtr text);

		// Token: 0x0200080E RID: 2062
		// (Invoke) Token: 0x06004758 RID: 18264
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_text_prepend_text(IntPtr raw, IntPtr text);

		// Token: 0x0200080F RID: 2063
		// (Invoke) Token: 0x0600475C RID: 18268
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_text_remove(IntPtr raw, int position);

		// Token: 0x02000810 RID: 2064
		// (Invoke) Token: 0x06004760 RID: 18272
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_combo_box_text_remove_all(IntPtr raw);
	}
}
