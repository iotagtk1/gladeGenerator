﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001D5 RID: 469
	public class CssImageLinearColorStop : Opaque
	{
		// Token: 0x060011A5 RID: 4517 RVA: 0x00033FC3 File Offset: 0x000321C3
		public CssImageLinearColorStop(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000426 RID: 1062
		// (get) Token: 0x060011A6 RID: 4518 RVA: 0x00033FCC File Offset: 0x000321CC
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImageLinearColorStop._abi_info == null)
				{
					CssImageLinearColorStop._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImageLinearColorStop._abi_info;
			}
		}

		// Token: 0x04000835 RID: 2101
		private static AbiStruct _abi_info;
	}
}
