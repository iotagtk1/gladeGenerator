﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000134 RID: 308
	[GType(typeof(AssistantPageTypeGType))]
	public enum AssistantPageType
	{
		// Token: 0x040006B0 RID: 1712
		Content,
		// Token: 0x040006B1 RID: 1713
		Intro,
		// Token: 0x040006B2 RID: 1714
		Confirm,
		// Token: 0x040006B3 RID: 1715
		Summary,
		// Token: 0x040006B4 RID: 1716
		Progress,
		// Token: 0x040006B5 RID: 1717
		Custom
	}
}
