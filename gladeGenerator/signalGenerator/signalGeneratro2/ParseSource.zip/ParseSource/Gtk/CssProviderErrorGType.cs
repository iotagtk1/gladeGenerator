﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x020001F3 RID: 499
	internal class CssProviderErrorGType
	{
		// Token: 0x17000447 RID: 1095
		// (get) Token: 0x060011F4 RID: 4596 RVA: 0x00034A4E File Offset: 0x00032C4E
		public static GType GType
		{
			get
			{
				return new GType(CssProviderErrorGType.gtk_css_provider_error_get_type());
			}
		}

		// Token: 0x04000866 RID: 2150
		private static CssProviderErrorGType.d_gtk_css_provider_error_get_type gtk_css_provider_error_get_type = FuncLoader.LoadFunction<CssProviderErrorGType.d_gtk_css_provider_error_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_css_provider_error_get_type"));

		// Token: 0x02000B73 RID: 2931
		// (Invoke) Token: 0x060054D5 RID: 21717
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_css_provider_error_get_type();
	}
}
