﻿using System;
using Gdk;

namespace Gtk
{
	// Token: 0x02000166 RID: 358
	// (Invoke) Token: 0x06000E7A RID: 3706
	public delegate bool CellAllocCallback(CellRenderer renderer, Rectangle cell_area, Rectangle cell_background);
}
