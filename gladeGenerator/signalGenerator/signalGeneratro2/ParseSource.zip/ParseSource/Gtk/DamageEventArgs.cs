﻿using System;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x0200021B RID: 539
	public class DamageEventArgs : SignalArgs
	{
		// Token: 0x17000470 RID: 1136
		// (get) Token: 0x06001261 RID: 4705 RVA: 0x000351B3 File Offset: 0x000333B3
		public EventExpose Event
		{
			get
			{
				return (EventExpose)base.Args[0];
			}
		}
	}
}
