﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x0200010C RID: 268
	public class ActionObserverAdapter : GInterfaceAdapter, IActionObserver, IWrapper
	{
		// Token: 0x06000C35 RID: 3125 RVA: 0x000252C8 File Offset: 0x000234C8
		static ActionObserverAdapter()
		{
			GType.Register(ActionObserverAdapter._gtype, typeof(ActionObserverAdapter));
			ActionObserverAdapter.iface.ActionAdded = new ActionObserverAdapter.ActionAddedNativeDelegate(ActionObserverAdapter.ActionAdded_cb);
			ActionObserverAdapter.iface.ActionEnabledChanged = new ActionObserverAdapter.ActionEnabledChangedNativeDelegate(ActionObserverAdapter.ActionEnabledChanged_cb);
			ActionObserverAdapter.iface.ActionStateChanged = new ActionObserverAdapter.ActionStateChangedNativeDelegate(ActionObserverAdapter.ActionStateChanged_cb);
			ActionObserverAdapter.iface.ActionRemoved = new ActionObserverAdapter.ActionRemovedNativeDelegate(ActionObserverAdapter.ActionRemoved_cb);
			ActionObserverAdapter.iface.PrimaryAccelChanged = new ActionObserverAdapter.PrimaryAccelChangedNativeDelegate(ActionObserverAdapter.PrimaryAccelChanged_cb);
		}

		// Token: 0x06000C36 RID: 3126 RVA: 0x0002541C File Offset: 0x0002361C
		private static void ActionAdded_cb(IntPtr inst, IntPtr observable, IntPtr action_name, IntPtr parameter_type, bool enabled, IntPtr state)
		{
			try
			{
				(Object.GetObject(inst, false) as IActionObserverImplementor).ActionAdded(ActionObservableAdapter.GetObject(observable, false), Marshaller.Utf8PtrToString(action_name), new VariantType(parameter_type), enabled, new Variant(state));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000C37 RID: 3127 RVA: 0x00025470 File Offset: 0x00023670
		private static void ActionEnabledChanged_cb(IntPtr inst, IntPtr observable, IntPtr action_name, bool enabled)
		{
			try
			{
				(Object.GetObject(inst, false) as IActionObserverImplementor).ActionEnabledChanged(ActionObservableAdapter.GetObject(observable, false), Marshaller.Utf8PtrToString(action_name), enabled);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000C38 RID: 3128 RVA: 0x000254B8 File Offset: 0x000236B8
		private static void ActionStateChanged_cb(IntPtr inst, IntPtr observable, IntPtr action_name, IntPtr state)
		{
			try
			{
				(Object.GetObject(inst, false) as IActionObserverImplementor).ActionStateChanged(ActionObservableAdapter.GetObject(observable, false), Marshaller.Utf8PtrToString(action_name), new Variant(state));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000C39 RID: 3129 RVA: 0x00025504 File Offset: 0x00023704
		private static void ActionRemoved_cb(IntPtr inst, IntPtr observable, IntPtr action_name)
		{
			try
			{
				(Object.GetObject(inst, false) as IActionObserverImplementor).ActionRemoved(ActionObservableAdapter.GetObject(observable, false), Marshaller.Utf8PtrToString(action_name));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000C3A RID: 3130 RVA: 0x0002554C File Offset: 0x0002374C
		private static void PrimaryAccelChanged_cb(IntPtr inst, IntPtr observable, IntPtr action_name, IntPtr action_and_target)
		{
			try
			{
				(Object.GetObject(inst, false) as IActionObserverImplementor).PrimaryAccelChanged(ActionObservableAdapter.GetObject(observable, false), Marshaller.Utf8PtrToString(action_name), Marshaller.Utf8PtrToString(action_and_target));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000C3B RID: 3131 RVA: 0x00025598 File Offset: 0x00023798
		private static void Initialize(IntPtr ptr, IntPtr data)
		{
			IntPtr ptr2 = new IntPtr(ptr.ToInt64() + (long)ActionObserverAdapter.class_offset);
			ActionObserverAdapter.GtkActionObserverInterface structure = (ActionObserverAdapter.GtkActionObserverInterface)Marshal.PtrToStructure(ptr2, typeof(ActionObserverAdapter.GtkActionObserverInterface));
			structure.ActionAdded = ActionObserverAdapter.iface.ActionAdded;
			structure.ActionEnabledChanged = ActionObserverAdapter.iface.ActionEnabledChanged;
			structure.ActionStateChanged = ActionObserverAdapter.iface.ActionStateChanged;
			structure.ActionRemoved = ActionObserverAdapter.iface.ActionRemoved;
			structure.PrimaryAccelChanged = ActionObserverAdapter.iface.PrimaryAccelChanged;
			Marshal.StructureToPtr<ActionObserverAdapter.GtkActionObserverInterface>(structure, ptr2, false);
		}

		// Token: 0x06000C3C RID: 3132 RVA: 0x0002562D File Offset: 0x0002382D
		public ActionObserverAdapter()
		{
			base.InitHandler = new GInterfaceInitHandler(ActionObserverAdapter.Initialize);
		}

		// Token: 0x06000C3D RID: 3133 RVA: 0x00025647 File Offset: 0x00023847
		public ActionObserverAdapter(IActionObserverImplementor implementor)
		{
			if (implementor == null)
			{
				throw new ArgumentNullException("implementor");
			}
			if (!(implementor is Object))
			{
				throw new ArgumentException("implementor must be a subclass of GLib.Object");
			}
			this.implementor = (implementor as Object);
		}

		// Token: 0x06000C3E RID: 3134 RVA: 0x0002567C File Offset: 0x0002387C
		public ActionObserverAdapter(IntPtr handle)
		{
			if (!ActionObserverAdapter._gtype.IsInstance(handle))
			{
				throw new ArgumentException("The gobject doesn't implement the GInterface of this adapter", "handle");
			}
			this.implementor = Object.GetObject(handle);
		}

		// Token: 0x17000288 RID: 648
		// (get) Token: 0x06000C3F RID: 3135 RVA: 0x000256AD File Offset: 0x000238AD
		public static GType GType
		{
			get
			{
				return ActionObserverAdapter._gtype;
			}
		}

		// Token: 0x17000289 RID: 649
		// (get) Token: 0x06000C40 RID: 3136 RVA: 0x000256B4 File Offset: 0x000238B4
		public override GType GInterfaceGType
		{
			get
			{
				return ActionObserverAdapter._gtype;
			}
		}

		// Token: 0x1700028A RID: 650
		// (get) Token: 0x06000C41 RID: 3137 RVA: 0x000256BB File Offset: 0x000238BB
		public override IntPtr Handle
		{
			get
			{
				return this.implementor.Handle;
			}
		}

		// Token: 0x1700028B RID: 651
		// (get) Token: 0x06000C42 RID: 3138 RVA: 0x000256C8 File Offset: 0x000238C8
		public IntPtr OwnedHandle
		{
			get
			{
				return this.implementor.OwnedHandle;
			}
		}

		// Token: 0x06000C43 RID: 3139 RVA: 0x000256D5 File Offset: 0x000238D5
		public static IActionObserver GetObject(IntPtr handle, bool owned)
		{
			return ActionObserverAdapter.GetObject(Object.GetObject(handle, owned));
		}

		// Token: 0x06000C44 RID: 3140 RVA: 0x000256E3 File Offset: 0x000238E3
		public static IActionObserver GetObject(Object obj)
		{
			if (obj == null)
			{
				return null;
			}
			if (obj is IActionObserverImplementor)
			{
				return new ActionObserverAdapter(obj as IActionObserverImplementor);
			}
			if (!(obj is IActionObserver))
			{
				return new ActionObserverAdapter(obj.Handle);
			}
			return obj as IActionObserver;
		}

		// Token: 0x1700028C RID: 652
		// (get) Token: 0x06000C45 RID: 3141 RVA: 0x00025718 File Offset: 0x00023918
		public IActionObserverImplementor Implementor
		{
			get
			{
				return this.implementor as IActionObserverImplementor;
			}
		}

		// Token: 0x06000C46 RID: 3142 RVA: 0x00025728 File Offset: 0x00023928
		public void ActionAdded(IActionObservable observable, string action_name, VariantType parameter_type, bool enabled, Variant state)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			ActionObserverAdapter.gtk_action_observer_action_added(this.Handle, (observable == null) ? IntPtr.Zero : ((observable is Object) ? (observable as Object).Handle : (observable as ActionObservableAdapter).Handle), intPtr, (parameter_type == null) ? IntPtr.Zero : parameter_type.Handle, enabled, (state == null) ? IntPtr.Zero : state.Handle);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000C47 RID: 3143 RVA: 0x000257A4 File Offset: 0x000239A4
		public void ActionEnabledChanged(IActionObservable observable, string action_name, bool enabled)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			ActionObserverAdapter.gtk_action_observer_action_enabled_changed(this.Handle, (observable == null) ? IntPtr.Zero : ((observable is Object) ? (observable as Object).Handle : (observable as ActionObservableAdapter).Handle), intPtr, enabled);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000C48 RID: 3144 RVA: 0x000257FC File Offset: 0x000239FC
		public void ActionRemoved(IActionObservable observable, string action_name)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			ActionObserverAdapter.gtk_action_observer_action_removed(this.Handle, (observable == null) ? IntPtr.Zero : ((observable is Object) ? (observable as Object).Handle : (observable as ActionObservableAdapter).Handle), intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000C49 RID: 3145 RVA: 0x00025854 File Offset: 0x00023A54
		public void ActionStateChanged(IActionObservable observable, string action_name, Variant state)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			ActionObserverAdapter.gtk_action_observer_action_state_changed(this.Handle, (observable == null) ? IntPtr.Zero : ((observable is Object) ? (observable as Object).Handle : (observable as ActionObservableAdapter).Handle), intPtr, (state == null) ? IntPtr.Zero : state.Handle);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000C4A RID: 3146 RVA: 0x000258BC File Offset: 0x00023ABC
		public void PrimaryAccelChanged(IActionObservable observable, string action_name, string action_and_target)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(action_name);
			IntPtr intPtr2 = Marshaller.StringToPtrGStrdup(action_and_target);
			ActionObserverAdapter.gtk_action_observer_primary_accel_changed(this.Handle, (observable == null) ? IntPtr.Zero : ((observable is Object) ? (observable as Object).Handle : (observable as ActionObservableAdapter).Handle), intPtr, intPtr2);
			Marshaller.Free(intPtr);
			Marshaller.Free(intPtr2);
		}

		// Token: 0x040005F4 RID: 1524
		private static ActionObserverAdapter.GtkActionObserverInterface iface;

		// Token: 0x040005F5 RID: 1525
		private static int class_offset = 2 * IntPtr.Size;

		// Token: 0x040005F6 RID: 1526
		private Object implementor;

		// Token: 0x040005F7 RID: 1527
		private static ActionObserverAdapter.d_gtk_action_observer_get_type gtk_action_observer_get_type = FuncLoader.LoadFunction<ActionObserverAdapter.d_gtk_action_observer_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_observer_get_type"));

		// Token: 0x040005F8 RID: 1528
		private static GType _gtype = new GType(ActionObserverAdapter.gtk_action_observer_get_type());

		// Token: 0x040005F9 RID: 1529
		private static ActionObserverAdapter.d_gtk_action_observer_action_added gtk_action_observer_action_added = FuncLoader.LoadFunction<ActionObserverAdapter.d_gtk_action_observer_action_added>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_observer_action_added"));

		// Token: 0x040005FA RID: 1530
		private static ActionObserverAdapter.d_gtk_action_observer_action_enabled_changed gtk_action_observer_action_enabled_changed = FuncLoader.LoadFunction<ActionObserverAdapter.d_gtk_action_observer_action_enabled_changed>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_observer_action_enabled_changed"));

		// Token: 0x040005FB RID: 1531
		private static ActionObserverAdapter.d_gtk_action_observer_action_removed gtk_action_observer_action_removed = FuncLoader.LoadFunction<ActionObserverAdapter.d_gtk_action_observer_action_removed>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_observer_action_removed"));

		// Token: 0x040005FC RID: 1532
		private static ActionObserverAdapter.d_gtk_action_observer_action_state_changed gtk_action_observer_action_state_changed = FuncLoader.LoadFunction<ActionObserverAdapter.d_gtk_action_observer_action_state_changed>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_observer_action_state_changed"));

		// Token: 0x040005FD RID: 1533
		private static ActionObserverAdapter.d_gtk_action_observer_primary_accel_changed gtk_action_observer_primary_accel_changed = FuncLoader.LoadFunction<ActionObserverAdapter.d_gtk_action_observer_primary_accel_changed>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_observer_primary_accel_changed"));

		// Token: 0x02000A07 RID: 2567
		private struct GtkActionObserverInterface
		{
			// Token: 0x04001E60 RID: 7776
			public ActionObserverAdapter.ActionAddedNativeDelegate ActionAdded;

			// Token: 0x04001E61 RID: 7777
			public ActionObserverAdapter.ActionEnabledChangedNativeDelegate ActionEnabledChanged;

			// Token: 0x04001E62 RID: 7778
			public ActionObserverAdapter.ActionStateChangedNativeDelegate ActionStateChanged;

			// Token: 0x04001E63 RID: 7779
			public ActionObserverAdapter.ActionRemovedNativeDelegate ActionRemoved;

			// Token: 0x04001E64 RID: 7780
			public ActionObserverAdapter.PrimaryAccelChangedNativeDelegate PrimaryAccelChanged;
		}

		// Token: 0x02000A08 RID: 2568
		// (Invoke) Token: 0x06004F2B RID: 20267
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ActionAddedNativeDelegate(IntPtr inst, IntPtr observable, IntPtr action_name, IntPtr parameter_type, bool enabled, IntPtr state);

		// Token: 0x02000A09 RID: 2569
		// (Invoke) Token: 0x06004F2F RID: 20271
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ActionEnabledChangedNativeDelegate(IntPtr inst, IntPtr observable, IntPtr action_name, bool enabled);

		// Token: 0x02000A0A RID: 2570
		// (Invoke) Token: 0x06004F33 RID: 20275
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ActionStateChangedNativeDelegate(IntPtr inst, IntPtr observable, IntPtr action_name, IntPtr state);

		// Token: 0x02000A0B RID: 2571
		// (Invoke) Token: 0x06004F37 RID: 20279
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ActionRemovedNativeDelegate(IntPtr inst, IntPtr observable, IntPtr action_name);

		// Token: 0x02000A0C RID: 2572
		// (Invoke) Token: 0x06004F3B RID: 20283
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void PrimaryAccelChangedNativeDelegate(IntPtr inst, IntPtr observable, IntPtr action_name, IntPtr action_and_target);

		// Token: 0x02000A0D RID: 2573
		// (Invoke) Token: 0x06004F3F RID: 20287
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_observer_get_type();

		// Token: 0x02000A0E RID: 2574
		// (Invoke) Token: 0x06004F43 RID: 20291
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_observer_action_added(IntPtr raw, IntPtr observable, IntPtr action_name, IntPtr parameter_type, bool enabled, IntPtr state);

		// Token: 0x02000A0F RID: 2575
		// (Invoke) Token: 0x06004F47 RID: 20295
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_observer_action_enabled_changed(IntPtr raw, IntPtr observable, IntPtr action_name, bool enabled);

		// Token: 0x02000A10 RID: 2576
		// (Invoke) Token: 0x06004F4B RID: 20299
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_observer_action_removed(IntPtr raw, IntPtr observable, IntPtr action_name);

		// Token: 0x02000A11 RID: 2577
		// (Invoke) Token: 0x06004F4F RID: 20303
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_observer_action_state_changed(IntPtr raw, IntPtr observable, IntPtr action_name, IntPtr state);

		// Token: 0x02000A12 RID: 2578
		// (Invoke) Token: 0x06004F53 RID: 20307
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_observer_primary_accel_changed(IntPtr raw, IntPtr observable, IntPtr action_name, IntPtr action_and_target);
	}
}
