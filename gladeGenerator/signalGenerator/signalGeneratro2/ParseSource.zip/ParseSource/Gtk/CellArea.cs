﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Cairo;
using Gdk;
using GLib;
using GtkSharp;

namespace Gtk
{
	// Token: 0x02000167 RID: 359
	public class CellArea : InitiallyUnowned
	{
		// Token: 0x06000E7D RID: 3709 RVA: 0x0002B1AC File Offset: 0x000293AC
		public CellArea(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000E7E RID: 3710 RVA: 0x0002B1B5 File Offset: 0x000293B5
		protected CellArea() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x1700032E RID: 814
		// (get) Token: 0x06000E7F RID: 3711 RVA: 0x0002B1D4 File Offset: 0x000293D4
		private static CellArea.AddNativeDelegate AddVMCallback
		{
			get
			{
				if (CellArea.Add_cb_delegate == null)
				{
					CellArea.Add_cb_delegate = new CellArea.AddNativeDelegate(CellArea.Add_cb);
				}
				return CellArea.Add_cb_delegate;
			}
		}

		// Token: 0x06000E80 RID: 3712 RVA: 0x0002B1F3 File Offset: 0x000293F3
		private static void OverrideAdd(GType gtype)
		{
			CellArea.OverrideAdd(gtype, CellArea.AddVMCallback);
		}

		// Token: 0x06000E81 RID: 3713 RVA: 0x0002B200 File Offset: 0x00029400
		private unsafe static void OverrideAdd(GType gtype, CellArea.AddNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellArea.class_abi.GetFieldOffset("add");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000E82 RID: 3714 RVA: 0x0002B234 File Offset: 0x00029434
		private static void Add_cb(IntPtr inst, IntPtr renderer)
		{
			try
			{
				(Object.GetObject(inst, false) as CellArea).OnAdd(Object.GetObject(renderer) as CellRenderer);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000E83 RID: 3715 RVA: 0x0002B278 File Offset: 0x00029478
		[DefaultSignalHandler(Type = typeof(CellArea), ConnectionMethod = "OverrideAdd")]
		protected virtual void OnAdd(CellRenderer renderer)
		{
			this.InternalAdd(renderer);
		}

		// Token: 0x06000E84 RID: 3716 RVA: 0x0002B284 File Offset: 0x00029484
		private void InternalAdd(CellRenderer renderer)
		{
			CellArea.AddNativeDelegate addNativeDelegate = CellArea.class_abi.BaseOverride(base.LookupGType(), "add");
			if (addNativeDelegate == null)
			{
				return;
			}
			addNativeDelegate(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle);
		}

		// Token: 0x1700032F RID: 815
		// (get) Token: 0x06000E85 RID: 3717 RVA: 0x0002B2C7 File Offset: 0x000294C7
		private static CellArea.RemoveNativeDelegate RemoveVMCallback
		{
			get
			{
				if (CellArea.Remove_cb_delegate == null)
				{
					CellArea.Remove_cb_delegate = new CellArea.RemoveNativeDelegate(CellArea.Remove_cb);
				}
				return CellArea.Remove_cb_delegate;
			}
		}

		// Token: 0x06000E86 RID: 3718 RVA: 0x0002B2E6 File Offset: 0x000294E6
		private static void OverrideRemove(GType gtype)
		{
			CellArea.OverrideRemove(gtype, CellArea.RemoveVMCallback);
		}

		// Token: 0x06000E87 RID: 3719 RVA: 0x0002B2F4 File Offset: 0x000294F4
		private unsafe static void OverrideRemove(GType gtype, CellArea.RemoveNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellArea.class_abi.GetFieldOffset("_remove");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000E88 RID: 3720 RVA: 0x0002B328 File Offset: 0x00029528
		private static void Remove_cb(IntPtr inst, IntPtr renderer)
		{
			try
			{
				(Object.GetObject(inst, false) as CellArea).OnRemove(Object.GetObject(renderer) as CellRenderer);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000E89 RID: 3721 RVA: 0x0002B36C File Offset: 0x0002956C
		[DefaultSignalHandler(Type = typeof(CellArea), ConnectionMethod = "OverrideRemove")]
		protected virtual void OnRemove(CellRenderer renderer)
		{
			this.InternalRemove(renderer);
		}

		// Token: 0x06000E8A RID: 3722 RVA: 0x0002B378 File Offset: 0x00029578
		private void InternalRemove(CellRenderer renderer)
		{
			CellArea.RemoveNativeDelegate removeNativeDelegate = CellArea.class_abi.BaseOverride(base.LookupGType(), "_remove");
			if (removeNativeDelegate == null)
			{
				return;
			}
			removeNativeDelegate(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle);
		}

		// Token: 0x17000330 RID: 816
		// (get) Token: 0x06000E8B RID: 3723 RVA: 0x0002B3BB File Offset: 0x000295BB
		private static CellArea.ForeachNativeDelegate ForeachVMCallback
		{
			get
			{
				if (CellArea.Foreach_cb_delegate == null)
				{
					CellArea.Foreach_cb_delegate = new CellArea.ForeachNativeDelegate(CellArea.Foreach_cb);
				}
				return CellArea.Foreach_cb_delegate;
			}
		}

		// Token: 0x06000E8C RID: 3724 RVA: 0x0002B3DA File Offset: 0x000295DA
		private static void OverrideForeach(GType gtype)
		{
			CellArea.OverrideForeach(gtype, CellArea.ForeachVMCallback);
		}

		// Token: 0x06000E8D RID: 3725 RVA: 0x0002B3E8 File Offset: 0x000295E8
		private unsafe static void OverrideForeach(GType gtype, CellArea.ForeachNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellArea.class_abi.GetFieldOffset("for_each");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000E8E RID: 3726 RVA: 0x0002B41C File Offset: 0x0002961C
		private static void Foreach_cb(IntPtr inst, CellCallbackNative cb, IntPtr callback_data)
		{
			try
			{
				CellArea cellArea = Object.GetObject(inst, false) as CellArea;
				CellCallbackInvoker cellCallbackInvoker = new CellCallbackInvoker(cb, callback_data);
				cellArea.OnForeach(cellCallbackInvoker.Handler);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000E8F RID: 3727 RVA: 0x0002B464 File Offset: 0x00029664
		[DefaultSignalHandler(Type = typeof(CellArea), ConnectionMethod = "OverrideForeach")]
		protected virtual void OnForeach(CellCallback cb)
		{
			this.InternalForeach(cb);
		}

		// Token: 0x06000E90 RID: 3728 RVA: 0x0002B470 File Offset: 0x00029670
		private void InternalForeach(CellCallback cb)
		{
			CellArea.ForeachNativeDelegate foreachNativeDelegate = CellArea.class_abi.BaseOverride(base.LookupGType(), "for_each");
			if (foreachNativeDelegate == null)
			{
				return;
			}
			CellCallbackWrapper cellCallbackWrapper = new CellCallbackWrapper(cb);
			foreachNativeDelegate(base.Handle, cellCallbackWrapper.NativeDelegate, IntPtr.Zero);
		}

		// Token: 0x17000331 RID: 817
		// (get) Token: 0x06000E91 RID: 3729 RVA: 0x0002B4B5 File Offset: 0x000296B5
		private static CellArea.ForeachAllocNativeDelegate ForeachAllocVMCallback
		{
			get
			{
				if (CellArea.ForeachAlloc_cb_delegate == null)
				{
					CellArea.ForeachAlloc_cb_delegate = new CellArea.ForeachAllocNativeDelegate(CellArea.ForeachAlloc_cb);
				}
				return CellArea.ForeachAlloc_cb_delegate;
			}
		}

		// Token: 0x06000E92 RID: 3730 RVA: 0x0002B4D4 File Offset: 0x000296D4
		private static void OverrideForeachAlloc(GType gtype)
		{
			CellArea.OverrideForeachAlloc(gtype, CellArea.ForeachAllocVMCallback);
		}

		// Token: 0x06000E93 RID: 3731 RVA: 0x0002B4E4 File Offset: 0x000296E4
		private unsafe static void OverrideForeachAlloc(GType gtype, CellArea.ForeachAllocNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellArea.class_abi.GetFieldOffset("foreach_alloc");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000E94 RID: 3732 RVA: 0x0002B518 File Offset: 0x00029718
		private static void ForeachAlloc_cb(IntPtr inst, IntPtr context, IntPtr widget, IntPtr cell_area, IntPtr background_area, CellAllocCallbackNative cb, IntPtr callback_data)
		{
			try
			{
				CellArea cellArea = Object.GetObject(inst, false) as CellArea;
				CellAllocCallbackInvoker cellAllocCallbackInvoker = new CellAllocCallbackInvoker(cb, callback_data);
				cellArea.OnForeachAlloc(Object.GetObject(context) as CellAreaContext, Object.GetObject(widget) as Widget, (Gdk.Rectangle)Marshal.PtrToStructure(cell_area, typeof(Gdk.Rectangle)), (Gdk.Rectangle)Marshal.PtrToStructure(background_area, typeof(Gdk.Rectangle)), cellAllocCallbackInvoker.Handler);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000E95 RID: 3733 RVA: 0x0002B5A4 File Offset: 0x000297A4
		[DefaultSignalHandler(Type = typeof(CellArea), ConnectionMethod = "OverrideForeachAlloc")]
		protected virtual void OnForeachAlloc(CellAreaContext context, Widget widget, Gdk.Rectangle cell_area, Gdk.Rectangle background_area, CellAllocCallback cb)
		{
			this.InternalForeachAlloc(context, widget, cell_area, background_area, cb);
		}

		// Token: 0x06000E96 RID: 3734 RVA: 0x0002B5B4 File Offset: 0x000297B4
		private void InternalForeachAlloc(CellAreaContext context, Widget widget, Gdk.Rectangle cell_area, Gdk.Rectangle background_area, CellAllocCallback cb)
		{
			CellArea.ForeachAllocNativeDelegate foreachAllocNativeDelegate = CellArea.class_abi.BaseOverride(base.LookupGType(), "foreach_alloc");
			if (foreachAllocNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(cell_area);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(background_area);
			CellAllocCallbackWrapper cellAllocCallbackWrapper = new CellAllocCallbackWrapper(cb);
			foreachAllocNativeDelegate(base.Handle, (context == null) ? IntPtr.Zero : context.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, intPtr, intPtr2, cellAllocCallbackWrapper.NativeDelegate, IntPtr.Zero);
			Marshal.FreeHGlobal(intPtr);
			Marshal.FreeHGlobal(intPtr2);
		}

		// Token: 0x17000332 RID: 818
		// (get) Token: 0x06000E97 RID: 3735 RVA: 0x0002B641 File Offset: 0x00029841
		private static CellArea.EventNativeDelegate EventVMCallback
		{
			get
			{
				if (CellArea.Event_cb_delegate == null)
				{
					CellArea.Event_cb_delegate = new CellArea.EventNativeDelegate(CellArea.Event_cb);
				}
				return CellArea.Event_cb_delegate;
			}
		}

		// Token: 0x06000E98 RID: 3736 RVA: 0x0002B660 File Offset: 0x00029860
		private static void OverrideEvent(GType gtype)
		{
			CellArea.OverrideEvent(gtype, CellArea.EventVMCallback);
		}

		// Token: 0x06000E99 RID: 3737 RVA: 0x0002B670 File Offset: 0x00029870
		private unsafe static void OverrideEvent(GType gtype, CellArea.EventNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellArea.class_abi.GetFieldOffset("evnt");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000E9A RID: 3738 RVA: 0x0002B6A4 File Offset: 0x000298A4
		private static int Event_cb(IntPtr inst, IntPtr context, IntPtr widget, IntPtr evnt, IntPtr cell_area, int flags)
		{
			int result;
			try
			{
				result = (Object.GetObject(inst, false) as CellArea).OnEvent(Object.GetObject(context) as CellAreaContext, Object.GetObject(widget) as Widget, Gdk.Event.GetEvent(evnt), (Gdk.Rectangle)Marshal.PtrToStructure(cell_area, typeof(Gdk.Rectangle)), (CellRendererState)flags);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000E9B RID: 3739 RVA: 0x0002B714 File Offset: 0x00029914
		[DefaultSignalHandler(Type = typeof(CellArea), ConnectionMethod = "OverrideEvent")]
		protected virtual int OnEvent(CellAreaContext context, Widget widget, Event evnt, Gdk.Rectangle cell_area, CellRendererState flags)
		{
			return this.InternalEvent(context, widget, evnt, cell_area, flags);
		}

		// Token: 0x06000E9C RID: 3740 RVA: 0x0002B724 File Offset: 0x00029924
		private int InternalEvent(CellAreaContext context, Widget widget, Event evnt, Gdk.Rectangle cell_area, CellRendererState flags)
		{
			CellArea.EventNativeDelegate eventNativeDelegate = CellArea.class_abi.BaseOverride(base.LookupGType(), "evnt");
			if (eventNativeDelegate == null)
			{
				return 0;
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(cell_area);
			int result = eventNativeDelegate(base.Handle, (context == null) ? IntPtr.Zero : context.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, (evnt == null) ? IntPtr.Zero : evnt.Handle, intPtr, (int)flags);
			Marshal.FreeHGlobal(intPtr);
			return result;
		}

		// Token: 0x17000333 RID: 819
		// (get) Token: 0x06000E9D RID: 3741 RVA: 0x0002B79E File Offset: 0x0002999E
		private static CellArea.RenderNativeDelegate RenderVMCallback
		{
			get
			{
				if (CellArea.Render_cb_delegate == null)
				{
					CellArea.Render_cb_delegate = new CellArea.RenderNativeDelegate(CellArea.Render_cb);
				}
				return CellArea.Render_cb_delegate;
			}
		}

		// Token: 0x06000E9E RID: 3742 RVA: 0x0002B7BD File Offset: 0x000299BD
		private static void OverrideRender(GType gtype)
		{
			CellArea.OverrideRender(gtype, CellArea.RenderVMCallback);
		}

		// Token: 0x06000E9F RID: 3743 RVA: 0x0002B7CC File Offset: 0x000299CC
		private unsafe static void OverrideRender(GType gtype, CellArea.RenderNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellArea.class_abi.GetFieldOffset("render");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000EA0 RID: 3744 RVA: 0x0002B800 File Offset: 0x00029A00
		private static void Render_cb(IntPtr inst, IntPtr context, IntPtr widget, IntPtr cr, IntPtr background_area, IntPtr cell_area, int flags, bool paint_focus)
		{
			Context context2 = null;
			try
			{
				CellArea cellArea = Object.GetObject(inst, false) as CellArea;
				context2 = new Context(cr, false);
				cellArea.OnRender(Object.GetObject(context) as CellAreaContext, Object.GetObject(widget) as Widget, context2, (Gdk.Rectangle)Marshal.PtrToStructure(background_area, typeof(Gdk.Rectangle)), (Gdk.Rectangle)Marshal.PtrToStructure(cell_area, typeof(Gdk.Rectangle)), (CellRendererState)flags, paint_focus);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
			finally
			{
				IDisposable disposable = context2;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
		}

		// Token: 0x06000EA1 RID: 3745 RVA: 0x0002B8A4 File Offset: 0x00029AA4
		[DefaultSignalHandler(Type = typeof(CellArea), ConnectionMethod = "OverrideRender")]
		protected virtual void OnRender(CellAreaContext context, Widget widget, Context cr, Gdk.Rectangle background_area, Gdk.Rectangle cell_area, CellRendererState flags, bool paint_focus)
		{
			this.InternalRender(context, widget, cr, background_area, cell_area, flags, paint_focus);
		}

		// Token: 0x06000EA2 RID: 3746 RVA: 0x0002B8B8 File Offset: 0x00029AB8
		private void InternalRender(CellAreaContext context, Widget widget, Context cr, Gdk.Rectangle background_area, Gdk.Rectangle cell_area, CellRendererState flags, bool paint_focus)
		{
			CellArea.RenderNativeDelegate renderNativeDelegate = CellArea.class_abi.BaseOverride(base.LookupGType(), "render");
			if (renderNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(background_area);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(cell_area);
			renderNativeDelegate(base.Handle, (context == null) ? IntPtr.Zero : context.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, (cr == null) ? IntPtr.Zero : cr.Handle, intPtr, intPtr2, (int)flags, paint_focus);
			Marshal.FreeHGlobal(intPtr);
			Marshal.FreeHGlobal(intPtr2);
		}

		// Token: 0x17000334 RID: 820
		// (get) Token: 0x06000EA3 RID: 3747 RVA: 0x0002B947 File Offset: 0x00029B47
		private static CellArea.ApplyAttributesNativeDelegate ApplyAttributesVMCallback
		{
			get
			{
				if (CellArea.ApplyAttributes_cb_delegate == null)
				{
					CellArea.ApplyAttributes_cb_delegate = new CellArea.ApplyAttributesNativeDelegate(CellArea.ApplyAttributes_cb);
				}
				return CellArea.ApplyAttributes_cb_delegate;
			}
		}

		// Token: 0x06000EA4 RID: 3748 RVA: 0x0002B966 File Offset: 0x00029B66
		private static void OverrideApplyAttributes(GType gtype)
		{
			CellArea.OverrideApplyAttributes(gtype, CellArea.ApplyAttributesVMCallback);
		}

		// Token: 0x06000EA5 RID: 3749 RVA: 0x0002B974 File Offset: 0x00029B74
		private unsafe static void OverrideApplyAttributes(GType gtype, CellArea.ApplyAttributesNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellArea.class_abi.GetFieldOffset("apply_attributes");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000EA6 RID: 3750 RVA: 0x0002B9A8 File Offset: 0x00029BA8
		private static void ApplyAttributes_cb(IntPtr inst, IntPtr tree_model, IntPtr iter, bool is_expander, bool is_expanded)
		{
			try
			{
				(Object.GetObject(inst, false) as CellArea).OnApplyAttributes(TreeModelAdapter.GetObject(tree_model, false), TreeIter.New(iter), is_expander, is_expanded);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000EA7 RID: 3751 RVA: 0x0002B9F0 File Offset: 0x00029BF0
		[DefaultSignalHandler(Type = typeof(CellArea), ConnectionMethod = "OverrideApplyAttributes")]
		protected virtual void OnApplyAttributes(ITreeModel tree_model, TreeIter iter, bool is_expander, bool is_expanded)
		{
			this.InternalApplyAttributes(tree_model, iter, is_expander, is_expanded);
		}

		// Token: 0x06000EA8 RID: 3752 RVA: 0x0002BA00 File Offset: 0x00029C00
		private void InternalApplyAttributes(ITreeModel tree_model, TreeIter iter, bool is_expander, bool is_expanded)
		{
			CellArea.ApplyAttributesNativeDelegate applyAttributesNativeDelegate = CellArea.class_abi.BaseOverride(base.LookupGType(), "apply_attributes");
			if (applyAttributesNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(iter);
			applyAttributesNativeDelegate(base.Handle, (tree_model == null) ? IntPtr.Zero : ((tree_model is Object) ? (tree_model as Object).Handle : (tree_model as TreeModelAdapter).Handle), intPtr, is_expander, is_expanded);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x17000335 RID: 821
		// (get) Token: 0x06000EA9 RID: 3753 RVA: 0x0002BA73 File Offset: 0x00029C73
		private static CellArea.CreateContextNativeDelegate CreateContextVMCallback
		{
			get
			{
				if (CellArea.CreateContext_cb_delegate == null)
				{
					CellArea.CreateContext_cb_delegate = new CellArea.CreateContextNativeDelegate(CellArea.CreateContext_cb);
				}
				return CellArea.CreateContext_cb_delegate;
			}
		}

		// Token: 0x06000EAA RID: 3754 RVA: 0x0002BA92 File Offset: 0x00029C92
		private static void OverrideCreateContext(GType gtype)
		{
			CellArea.OverrideCreateContext(gtype, CellArea.CreateContextVMCallback);
		}

		// Token: 0x06000EAB RID: 3755 RVA: 0x0002BAA0 File Offset: 0x00029CA0
		private unsafe static void OverrideCreateContext(GType gtype, CellArea.CreateContextNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellArea.class_abi.GetFieldOffset("create_context");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000EAC RID: 3756 RVA: 0x0002BAD4 File Offset: 0x00029CD4
		private static IntPtr CreateContext_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				CellAreaContext cellAreaContext = (Object.GetObject(inst, false) as CellArea).OnCreateContext();
				result = ((cellAreaContext == null) ? IntPtr.Zero : cellAreaContext.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000EAD RID: 3757 RVA: 0x0002BB20 File Offset: 0x00029D20
		[DefaultSignalHandler(Type = typeof(CellArea), ConnectionMethod = "OverrideCreateContext")]
		protected virtual CellAreaContext OnCreateContext()
		{
			return this.InternalCreateContext();
		}

		// Token: 0x06000EAE RID: 3758 RVA: 0x0002BB28 File Offset: 0x00029D28
		private CellAreaContext InternalCreateContext()
		{
			CellArea.CreateContextNativeDelegate createContextNativeDelegate = CellArea.class_abi.BaseOverride(base.LookupGType(), "create_context");
			if (createContextNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(createContextNativeDelegate(base.Handle)) as CellAreaContext;
		}

		// Token: 0x17000336 RID: 822
		// (get) Token: 0x06000EAF RID: 3759 RVA: 0x0002BB66 File Offset: 0x00029D66
		private static CellArea.CopyContextNativeDelegate CopyContextVMCallback
		{
			get
			{
				if (CellArea.CopyContext_cb_delegate == null)
				{
					CellArea.CopyContext_cb_delegate = new CellArea.CopyContextNativeDelegate(CellArea.CopyContext_cb);
				}
				return CellArea.CopyContext_cb_delegate;
			}
		}

		// Token: 0x06000EB0 RID: 3760 RVA: 0x0002BB85 File Offset: 0x00029D85
		private static void OverrideCopyContext(GType gtype)
		{
			CellArea.OverrideCopyContext(gtype, CellArea.CopyContextVMCallback);
		}

		// Token: 0x06000EB1 RID: 3761 RVA: 0x0002BB94 File Offset: 0x00029D94
		private unsafe static void OverrideCopyContext(GType gtype, CellArea.CopyContextNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellArea.class_abi.GetFieldOffset("copy_context");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000EB2 RID: 3762 RVA: 0x0002BBC8 File Offset: 0x00029DC8
		private static IntPtr CopyContext_cb(IntPtr inst, IntPtr context)
		{
			IntPtr result;
			try
			{
				CellAreaContext cellAreaContext = (Object.GetObject(inst, false) as CellArea).OnCopyContext(Object.GetObject(context) as CellAreaContext);
				result = ((cellAreaContext == null) ? IntPtr.Zero : cellAreaContext.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000EB3 RID: 3763 RVA: 0x0002BC20 File Offset: 0x00029E20
		[DefaultSignalHandler(Type = typeof(CellArea), ConnectionMethod = "OverrideCopyContext")]
		protected virtual CellAreaContext OnCopyContext(CellAreaContext context)
		{
			return this.InternalCopyContext(context);
		}

		// Token: 0x06000EB4 RID: 3764 RVA: 0x0002BC2C File Offset: 0x00029E2C
		private CellAreaContext InternalCopyContext(CellAreaContext context)
		{
			CellArea.CopyContextNativeDelegate copyContextNativeDelegate = CellArea.class_abi.BaseOverride(base.LookupGType(), "copy_context");
			if (copyContextNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(copyContextNativeDelegate(base.Handle, (context == null) ? IntPtr.Zero : context.Handle)) as CellAreaContext;
		}

		// Token: 0x17000337 RID: 823
		// (get) Token: 0x06000EB5 RID: 3765 RVA: 0x0002BC7A File Offset: 0x00029E7A
		private static CellArea.GetRequestModeNativeDelegate GetRequestModeVMCallback
		{
			get
			{
				if (CellArea.GetRequestMode_cb_delegate == null)
				{
					CellArea.GetRequestMode_cb_delegate = new CellArea.GetRequestModeNativeDelegate(CellArea.GetRequestMode_cb);
				}
				return CellArea.GetRequestMode_cb_delegate;
			}
		}

		// Token: 0x06000EB6 RID: 3766 RVA: 0x0002BC99 File Offset: 0x00029E99
		private static void OverrideGetRequestMode(GType gtype)
		{
			CellArea.OverrideGetRequestMode(gtype, CellArea.GetRequestModeVMCallback);
		}

		// Token: 0x06000EB7 RID: 3767 RVA: 0x0002BCA8 File Offset: 0x00029EA8
		private unsafe static void OverrideGetRequestMode(GType gtype, CellArea.GetRequestModeNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellArea.class_abi.GetFieldOffset("get_request_mode");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000EB8 RID: 3768 RVA: 0x0002BCDC File Offset: 0x00029EDC
		private static int GetRequestMode_cb(IntPtr inst)
		{
			int result;
			try
			{
				result = (int)(Object.GetObject(inst, false) as CellArea).OnGetRequestMode();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000EB9 RID: 3769 RVA: 0x0002BD18 File Offset: 0x00029F18
		[DefaultSignalHandler(Type = typeof(CellArea), ConnectionMethod = "OverrideGetRequestMode")]
		protected virtual SizeRequestMode OnGetRequestMode()
		{
			return this.InternalGetRequestMode();
		}

		// Token: 0x06000EBA RID: 3770 RVA: 0x0002BD20 File Offset: 0x00029F20
		private SizeRequestMode InternalGetRequestMode()
		{
			CellArea.GetRequestModeNativeDelegate getRequestModeNativeDelegate = CellArea.class_abi.BaseOverride(base.LookupGType(), "get_request_mode");
			if (getRequestModeNativeDelegate == null)
			{
				return SizeRequestMode.HeightForWidth;
			}
			return (SizeRequestMode)getRequestModeNativeDelegate(base.Handle);
		}

		// Token: 0x17000338 RID: 824
		// (get) Token: 0x06000EBB RID: 3771 RVA: 0x0002BD54 File Offset: 0x00029F54
		private static CellArea.GetPreferredWidthNativeDelegate GetPreferredWidthVMCallback
		{
			get
			{
				if (CellArea.GetPreferredWidth_cb_delegate == null)
				{
					CellArea.GetPreferredWidth_cb_delegate = new CellArea.GetPreferredWidthNativeDelegate(CellArea.GetPreferredWidth_cb);
				}
				return CellArea.GetPreferredWidth_cb_delegate;
			}
		}

		// Token: 0x06000EBC RID: 3772 RVA: 0x0002BD73 File Offset: 0x00029F73
		private static void OverrideGetPreferredWidth(GType gtype)
		{
			CellArea.OverrideGetPreferredWidth(gtype, CellArea.GetPreferredWidthVMCallback);
		}

		// Token: 0x06000EBD RID: 3773 RVA: 0x0002BD80 File Offset: 0x00029F80
		private unsafe static void OverrideGetPreferredWidth(GType gtype, CellArea.GetPreferredWidthNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellArea.class_abi.GetFieldOffset("get_preferred_width");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000EBE RID: 3774 RVA: 0x0002BDB4 File Offset: 0x00029FB4
		private static void GetPreferredWidth_cb(IntPtr inst, IntPtr context, IntPtr widget, out int minimum_width, out int natural_width)
		{
			try
			{
				(Object.GetObject(inst, false) as CellArea).OnGetPreferredWidth(Object.GetObject(context) as CellAreaContext, Object.GetObject(widget) as Widget, out minimum_width, out natural_width);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
		}

		// Token: 0x06000EBF RID: 3775 RVA: 0x0002BE08 File Offset: 0x0002A008
		[DefaultSignalHandler(Type = typeof(CellArea), ConnectionMethod = "OverrideGetPreferredWidth")]
		protected virtual void OnGetPreferredWidth(CellAreaContext context, Widget widget, out int minimum_width, out int natural_width)
		{
			this.InternalGetPreferredWidth(context, widget, out minimum_width, out natural_width);
		}

		// Token: 0x06000EC0 RID: 3776 RVA: 0x0002BE18 File Offset: 0x0002A018
		private void InternalGetPreferredWidth(CellAreaContext context, Widget widget, out int minimum_width, out int natural_width)
		{
			CellArea.GetPreferredWidthNativeDelegate getPreferredWidthNativeDelegate = CellArea.class_abi.BaseOverride(base.LookupGType(), "get_preferred_width");
			if (getPreferredWidthNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			getPreferredWidthNativeDelegate(base.Handle, (context == null) ? IntPtr.Zero : context.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, out minimum_width, out natural_width);
		}

		// Token: 0x17000339 RID: 825
		// (get) Token: 0x06000EC1 RID: 3777 RVA: 0x0002BE76 File Offset: 0x0002A076
		private static CellArea.GetPreferredHeightForWidthNativeDelegate GetPreferredHeightForWidthVMCallback
		{
			get
			{
				if (CellArea.GetPreferredHeightForWidth_cb_delegate == null)
				{
					CellArea.GetPreferredHeightForWidth_cb_delegate = new CellArea.GetPreferredHeightForWidthNativeDelegate(CellArea.GetPreferredHeightForWidth_cb);
				}
				return CellArea.GetPreferredHeightForWidth_cb_delegate;
			}
		}

		// Token: 0x06000EC2 RID: 3778 RVA: 0x0002BE95 File Offset: 0x0002A095
		private static void OverrideGetPreferredHeightForWidth(GType gtype)
		{
			CellArea.OverrideGetPreferredHeightForWidth(gtype, CellArea.GetPreferredHeightForWidthVMCallback);
		}

		// Token: 0x06000EC3 RID: 3779 RVA: 0x0002BEA4 File Offset: 0x0002A0A4
		private unsafe static void OverrideGetPreferredHeightForWidth(GType gtype, CellArea.GetPreferredHeightForWidthNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellArea.class_abi.GetFieldOffset("get_preferred_height_for_width");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000EC4 RID: 3780 RVA: 0x0002BED8 File Offset: 0x0002A0D8
		private static void GetPreferredHeightForWidth_cb(IntPtr inst, IntPtr context, IntPtr widget, int width, out int minimum_height, out int natural_height)
		{
			try
			{
				(Object.GetObject(inst, false) as CellArea).OnGetPreferredHeightForWidth(Object.GetObject(context) as CellAreaContext, Object.GetObject(widget) as Widget, width, out minimum_height, out natural_height);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
		}

		// Token: 0x06000EC5 RID: 3781 RVA: 0x0002BF2C File Offset: 0x0002A12C
		[DefaultSignalHandler(Type = typeof(CellArea), ConnectionMethod = "OverrideGetPreferredHeightForWidth")]
		protected virtual void OnGetPreferredHeightForWidth(CellAreaContext context, Widget widget, int width, out int minimum_height, out int natural_height)
		{
			this.InternalGetPreferredHeightForWidth(context, widget, width, out minimum_height, out natural_height);
		}

		// Token: 0x06000EC6 RID: 3782 RVA: 0x0002BF3C File Offset: 0x0002A13C
		private void InternalGetPreferredHeightForWidth(CellAreaContext context, Widget widget, int width, out int minimum_height, out int natural_height)
		{
			CellArea.GetPreferredHeightForWidthNativeDelegate getPreferredHeightForWidthNativeDelegate = CellArea.class_abi.BaseOverride(base.LookupGType(), "get_preferred_height_for_width");
			if (getPreferredHeightForWidthNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			getPreferredHeightForWidthNativeDelegate(base.Handle, (context == null) ? IntPtr.Zero : context.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, width, out minimum_height, out natural_height);
		}

		// Token: 0x1700033A RID: 826
		// (get) Token: 0x06000EC7 RID: 3783 RVA: 0x0002BF9C File Offset: 0x0002A19C
		private static CellArea.GetPreferredHeightNativeDelegate GetPreferredHeightVMCallback
		{
			get
			{
				if (CellArea.GetPreferredHeight_cb_delegate == null)
				{
					CellArea.GetPreferredHeight_cb_delegate = new CellArea.GetPreferredHeightNativeDelegate(CellArea.GetPreferredHeight_cb);
				}
				return CellArea.GetPreferredHeight_cb_delegate;
			}
		}

		// Token: 0x06000EC8 RID: 3784 RVA: 0x0002BFBB File Offset: 0x0002A1BB
		private static void OverrideGetPreferredHeight(GType gtype)
		{
			CellArea.OverrideGetPreferredHeight(gtype, CellArea.GetPreferredHeightVMCallback);
		}

		// Token: 0x06000EC9 RID: 3785 RVA: 0x0002BFC8 File Offset: 0x0002A1C8
		private unsafe static void OverrideGetPreferredHeight(GType gtype, CellArea.GetPreferredHeightNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellArea.class_abi.GetFieldOffset("get_preferred_height");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000ECA RID: 3786 RVA: 0x0002BFFC File Offset: 0x0002A1FC
		private static void GetPreferredHeight_cb(IntPtr inst, IntPtr context, IntPtr widget, out int minimum_height, out int natural_height)
		{
			try
			{
				(Object.GetObject(inst, false) as CellArea).OnGetPreferredHeight(Object.GetObject(context) as CellAreaContext, Object.GetObject(widget) as Widget, out minimum_height, out natural_height);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
		}

		// Token: 0x06000ECB RID: 3787 RVA: 0x0002C050 File Offset: 0x0002A250
		[DefaultSignalHandler(Type = typeof(CellArea), ConnectionMethod = "OverrideGetPreferredHeight")]
		protected virtual void OnGetPreferredHeight(CellAreaContext context, Widget widget, out int minimum_height, out int natural_height)
		{
			this.InternalGetPreferredHeight(context, widget, out minimum_height, out natural_height);
		}

		// Token: 0x06000ECC RID: 3788 RVA: 0x0002C060 File Offset: 0x0002A260
		private void InternalGetPreferredHeight(CellAreaContext context, Widget widget, out int minimum_height, out int natural_height)
		{
			CellArea.GetPreferredHeightNativeDelegate getPreferredHeightNativeDelegate = CellArea.class_abi.BaseOverride(base.LookupGType(), "get_preferred_height");
			if (getPreferredHeightNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			getPreferredHeightNativeDelegate(base.Handle, (context == null) ? IntPtr.Zero : context.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, out minimum_height, out natural_height);
		}

		// Token: 0x1700033B RID: 827
		// (get) Token: 0x06000ECD RID: 3789 RVA: 0x0002C0BE File Offset: 0x0002A2BE
		private static CellArea.GetPreferredWidthForHeightNativeDelegate GetPreferredWidthForHeightVMCallback
		{
			get
			{
				if (CellArea.GetPreferredWidthForHeight_cb_delegate == null)
				{
					CellArea.GetPreferredWidthForHeight_cb_delegate = new CellArea.GetPreferredWidthForHeightNativeDelegate(CellArea.GetPreferredWidthForHeight_cb);
				}
				return CellArea.GetPreferredWidthForHeight_cb_delegate;
			}
		}

		// Token: 0x06000ECE RID: 3790 RVA: 0x0002C0DD File Offset: 0x0002A2DD
		private static void OverrideGetPreferredWidthForHeight(GType gtype)
		{
			CellArea.OverrideGetPreferredWidthForHeight(gtype, CellArea.GetPreferredWidthForHeightVMCallback);
		}

		// Token: 0x06000ECF RID: 3791 RVA: 0x0002C0EC File Offset: 0x0002A2EC
		private unsafe static void OverrideGetPreferredWidthForHeight(GType gtype, CellArea.GetPreferredWidthForHeightNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellArea.class_abi.GetFieldOffset("get_preferred_width_for_height");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000ED0 RID: 3792 RVA: 0x0002C120 File Offset: 0x0002A320
		private static void GetPreferredWidthForHeight_cb(IntPtr inst, IntPtr context, IntPtr widget, int height, out int minimum_width, out int natural_width)
		{
			try
			{
				(Object.GetObject(inst, false) as CellArea).OnGetPreferredWidthForHeight(Object.GetObject(context) as CellAreaContext, Object.GetObject(widget) as Widget, height, out minimum_width, out natural_width);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
		}

		// Token: 0x06000ED1 RID: 3793 RVA: 0x0002C174 File Offset: 0x0002A374
		[DefaultSignalHandler(Type = typeof(CellArea), ConnectionMethod = "OverrideGetPreferredWidthForHeight")]
		protected virtual void OnGetPreferredWidthForHeight(CellAreaContext context, Widget widget, int height, out int minimum_width, out int natural_width)
		{
			this.InternalGetPreferredWidthForHeight(context, widget, height, out minimum_width, out natural_width);
		}

		// Token: 0x06000ED2 RID: 3794 RVA: 0x0002C184 File Offset: 0x0002A384
		private void InternalGetPreferredWidthForHeight(CellAreaContext context, Widget widget, int height, out int minimum_width, out int natural_width)
		{
			CellArea.GetPreferredWidthForHeightNativeDelegate getPreferredWidthForHeightNativeDelegate = CellArea.class_abi.BaseOverride(base.LookupGType(), "get_preferred_width_for_height");
			if (getPreferredWidthForHeightNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			getPreferredWidthForHeightNativeDelegate(base.Handle, (context == null) ? IntPtr.Zero : context.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, height, out minimum_width, out natural_width);
		}

		// Token: 0x1700033C RID: 828
		// (get) Token: 0x06000ED3 RID: 3795 RVA: 0x0002C1E4 File Offset: 0x0002A3E4
		private static CellArea.SetCellPropertyNativeDelegate SetCellPropertyVMCallback
		{
			get
			{
				if (CellArea.SetCellProperty_cb_delegate == null)
				{
					CellArea.SetCellProperty_cb_delegate = new CellArea.SetCellPropertyNativeDelegate(CellArea.SetCellProperty_cb);
				}
				return CellArea.SetCellProperty_cb_delegate;
			}
		}

		// Token: 0x06000ED4 RID: 3796 RVA: 0x0002C203 File Offset: 0x0002A403
		private static void OverrideSetCellProperty(GType gtype)
		{
			CellArea.OverrideSetCellProperty(gtype, CellArea.SetCellPropertyVMCallback);
		}

		// Token: 0x06000ED5 RID: 3797 RVA: 0x0002C210 File Offset: 0x0002A410
		private unsafe static void OverrideSetCellProperty(GType gtype, CellArea.SetCellPropertyNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellArea.class_abi.GetFieldOffset("set_cell_property");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000ED6 RID: 3798 RVA: 0x0002C244 File Offset: 0x0002A444
		private static void SetCellProperty_cb(IntPtr inst, IntPtr renderer, uint property_id, IntPtr value, IntPtr pspec)
		{
			try
			{
				(Object.GetObject(inst, false) as CellArea).OnSetCellProperty(Object.GetObject(renderer) as CellRenderer, property_id, (Value)Marshal.PtrToStructure(value, typeof(Value)), pspec);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000ED7 RID: 3799 RVA: 0x0002C2A0 File Offset: 0x0002A4A0
		[DefaultSignalHandler(Type = typeof(CellArea), ConnectionMethod = "OverrideSetCellProperty")]
		protected virtual void OnSetCellProperty(CellRenderer renderer, uint property_id, Value value, IntPtr pspec)
		{
			this.InternalSetCellProperty(renderer, property_id, value, pspec);
		}

		// Token: 0x06000ED8 RID: 3800 RVA: 0x0002C2B0 File Offset: 0x0002A4B0
		private void InternalSetCellProperty(CellRenderer renderer, uint property_id, Value value, IntPtr pspec)
		{
			CellArea.SetCellPropertyNativeDelegate setCellPropertyNativeDelegate = CellArea.class_abi.BaseOverride(base.LookupGType(), "set_cell_property");
			if (setCellPropertyNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(value);
			setCellPropertyNativeDelegate(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle, property_id, intPtr, pspec);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x1700033D RID: 829
		// (get) Token: 0x06000ED9 RID: 3801 RVA: 0x0002C309 File Offset: 0x0002A509
		private static CellArea.GetCellPropertyNativeDelegate GetCellPropertyVMCallback
		{
			get
			{
				if (CellArea.GetCellProperty_cb_delegate == null)
				{
					CellArea.GetCellProperty_cb_delegate = new CellArea.GetCellPropertyNativeDelegate(CellArea.GetCellProperty_cb);
				}
				return CellArea.GetCellProperty_cb_delegate;
			}
		}

		// Token: 0x06000EDA RID: 3802 RVA: 0x0002C328 File Offset: 0x0002A528
		private static void OverrideGetCellProperty(GType gtype)
		{
			CellArea.OverrideGetCellProperty(gtype, CellArea.GetCellPropertyVMCallback);
		}

		// Token: 0x06000EDB RID: 3803 RVA: 0x0002C338 File Offset: 0x0002A538
		private unsafe static void OverrideGetCellProperty(GType gtype, CellArea.GetCellPropertyNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellArea.class_abi.GetFieldOffset("get_cell_property");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000EDC RID: 3804 RVA: 0x0002C36C File Offset: 0x0002A56C
		private static void GetCellProperty_cb(IntPtr inst, IntPtr renderer, uint property_id, IntPtr value, IntPtr pspec)
		{
			try
			{
				(Object.GetObject(inst, false) as CellArea).OnGetCellProperty(Object.GetObject(renderer) as CellRenderer, property_id, (Value)Marshal.PtrToStructure(value, typeof(Value)), pspec);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000EDD RID: 3805 RVA: 0x0002C3C8 File Offset: 0x0002A5C8
		[DefaultSignalHandler(Type = typeof(CellArea), ConnectionMethod = "OverrideGetCellProperty")]
		protected virtual void OnGetCellProperty(CellRenderer renderer, uint property_id, Value value, IntPtr pspec)
		{
			this.InternalGetCellProperty(renderer, property_id, value, pspec);
		}

		// Token: 0x06000EDE RID: 3806 RVA: 0x0002C3D8 File Offset: 0x0002A5D8
		private void InternalGetCellProperty(CellRenderer renderer, uint property_id, Value value, IntPtr pspec)
		{
			CellArea.GetCellPropertyNativeDelegate getCellPropertyNativeDelegate = CellArea.class_abi.BaseOverride(base.LookupGType(), "get_cell_property");
			if (getCellPropertyNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(value);
			getCellPropertyNativeDelegate(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle, property_id, intPtr, pspec);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x1700033E RID: 830
		// (get) Token: 0x06000EDF RID: 3807 RVA: 0x0002C431 File Offset: 0x0002A631
		private static CellArea.FocusNativeDelegate FocusVMCallback
		{
			get
			{
				if (CellArea.Focus_cb_delegate == null)
				{
					CellArea.Focus_cb_delegate = new CellArea.FocusNativeDelegate(CellArea.Focus_cb);
				}
				return CellArea.Focus_cb_delegate;
			}
		}

		// Token: 0x06000EE0 RID: 3808 RVA: 0x0002C450 File Offset: 0x0002A650
		private static void OverrideFocus(GType gtype)
		{
			CellArea.OverrideFocus(gtype, CellArea.FocusVMCallback);
		}

		// Token: 0x06000EE1 RID: 3809 RVA: 0x0002C460 File Offset: 0x0002A660
		private unsafe static void OverrideFocus(GType gtype, CellArea.FocusNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellArea.class_abi.GetFieldOffset("focus");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000EE2 RID: 3810 RVA: 0x0002C494 File Offset: 0x0002A694
		private static bool Focus_cb(IntPtr inst, int direction)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as CellArea).OnFocus((DirectionType)direction);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000EE3 RID: 3811 RVA: 0x0002C4D0 File Offset: 0x0002A6D0
		[DefaultSignalHandler(Type = typeof(CellArea), ConnectionMethod = "OverrideFocus")]
		protected virtual bool OnFocus(DirectionType direction)
		{
			return this.InternalFocus(direction);
		}

		// Token: 0x06000EE4 RID: 3812 RVA: 0x0002C4DC File Offset: 0x0002A6DC
		private bool InternalFocus(DirectionType direction)
		{
			CellArea.FocusNativeDelegate focusNativeDelegate = CellArea.class_abi.BaseOverride(base.LookupGType(), "focus");
			return focusNativeDelegate != null && focusNativeDelegate(base.Handle, (int)direction);
		}

		// Token: 0x1700033F RID: 831
		// (get) Token: 0x06000EE5 RID: 3813 RVA: 0x0002C511 File Offset: 0x0002A711
		private static CellArea.IsActivatableNativeDelegate IsActivatableVMCallback
		{
			get
			{
				if (CellArea.IsActivatable_cb_delegate == null)
				{
					CellArea.IsActivatable_cb_delegate = new CellArea.IsActivatableNativeDelegate(CellArea.IsActivatable_cb);
				}
				return CellArea.IsActivatable_cb_delegate;
			}
		}

		// Token: 0x06000EE6 RID: 3814 RVA: 0x0002C530 File Offset: 0x0002A730
		private static void OverrideIsActivatable(GType gtype)
		{
			CellArea.OverrideIsActivatable(gtype, CellArea.IsActivatableVMCallback);
		}

		// Token: 0x06000EE7 RID: 3815 RVA: 0x0002C540 File Offset: 0x0002A740
		private unsafe static void OverrideIsActivatable(GType gtype, CellArea.IsActivatableNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellArea.class_abi.GetFieldOffset("is_activatable");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000EE8 RID: 3816 RVA: 0x0002C574 File Offset: 0x0002A774
		private static bool IsActivatable_cb(IntPtr inst)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as CellArea).OnIsActivatable();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000EE9 RID: 3817 RVA: 0x0002C5B0 File Offset: 0x0002A7B0
		[DefaultSignalHandler(Type = typeof(CellArea), ConnectionMethod = "OverrideIsActivatable")]
		protected virtual bool OnIsActivatable()
		{
			return this.InternalIsActivatable();
		}

		// Token: 0x06000EEA RID: 3818 RVA: 0x0002C5B8 File Offset: 0x0002A7B8
		private bool InternalIsActivatable()
		{
			CellArea.IsActivatableNativeDelegate isActivatableNativeDelegate = CellArea.class_abi.BaseOverride(base.LookupGType(), "is_activatable");
			return isActivatableNativeDelegate != null && isActivatableNativeDelegate(base.Handle);
		}

		// Token: 0x17000340 RID: 832
		// (get) Token: 0x06000EEB RID: 3819 RVA: 0x0002C5EC File Offset: 0x0002A7EC
		private static CellArea.ActivateNativeDelegate ActivateVMCallback
		{
			get
			{
				if (CellArea.Activate_cb_delegate == null)
				{
					CellArea.Activate_cb_delegate = new CellArea.ActivateNativeDelegate(CellArea.Activate_cb);
				}
				return CellArea.Activate_cb_delegate;
			}
		}

		// Token: 0x06000EEC RID: 3820 RVA: 0x0002C60B File Offset: 0x0002A80B
		private static void OverrideActivate(GType gtype)
		{
			CellArea.OverrideActivate(gtype, CellArea.ActivateVMCallback);
		}

		// Token: 0x06000EED RID: 3821 RVA: 0x0002C618 File Offset: 0x0002A818
		private unsafe static void OverrideActivate(GType gtype, CellArea.ActivateNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CellArea.class_abi.GetFieldOffset("activate");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000EEE RID: 3822 RVA: 0x0002C64C File Offset: 0x0002A84C
		private static bool Activate_cb(IntPtr inst, IntPtr context, IntPtr widget, IntPtr cell_area, int flags, bool edit_only)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as CellArea).OnActivate(Object.GetObject(context) as CellAreaContext, Object.GetObject(widget) as Widget, (Gdk.Rectangle)Marshal.PtrToStructure(cell_area, typeof(Gdk.Rectangle)), (CellRendererState)flags, edit_only);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000EEF RID: 3823 RVA: 0x0002C6B8 File Offset: 0x0002A8B8
		[DefaultSignalHandler(Type = typeof(CellArea), ConnectionMethod = "OverrideActivate")]
		protected virtual bool OnActivate(CellAreaContext context, Widget widget, Gdk.Rectangle cell_area, CellRendererState flags, bool edit_only)
		{
			return this.InternalActivate(context, widget, cell_area, flags, edit_only);
		}

		// Token: 0x06000EF0 RID: 3824 RVA: 0x0002C6C8 File Offset: 0x0002A8C8
		private bool InternalActivate(CellAreaContext context, Widget widget, Gdk.Rectangle cell_area, CellRendererState flags, bool edit_only)
		{
			CellArea.ActivateNativeDelegate activateNativeDelegate = CellArea.class_abi.BaseOverride(base.LookupGType(), "activate");
			if (activateNativeDelegate == null)
			{
				return false;
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(cell_area);
			bool result = activateNativeDelegate(base.Handle, (context == null) ? IntPtr.Zero : context.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, intPtr, (int)flags, edit_only);
			Marshal.FreeHGlobal(intPtr);
			return result;
		}

		// Token: 0x17000341 RID: 833
		// (get) Token: 0x06000EF1 RID: 3825 RVA: 0x0002C734 File Offset: 0x0002A934
		public new static AbiStruct class_abi
		{
			get
			{
				if (CellArea._class_abi == null)
				{
					CellArea._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("add", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "remove", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("remove", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "add", "foreach", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("foreach", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "remove", "foreach_alloc", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("foreach_alloc", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "foreach", "event", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("event", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "foreach_alloc", "render", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("render", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "event", "apply_attributes", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("apply_attributes", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "render", "create_context", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("create_context", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "apply_attributes", "copy_context", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("copy_context", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "create_context", "get_request_mode", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_request_mode", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "copy_context", "get_preferred_width", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_preferred_width", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_request_mode", "get_preferred_height_for_width", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_preferred_height_for_width", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_preferred_width", "get_preferred_height", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_preferred_height", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_preferred_height_for_width", "get_preferred_width_for_height", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_preferred_width_for_height", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_preferred_height", "set_cell_property", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("set_cell_property", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_preferred_width_for_height", "get_cell_property", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_cell_property", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "set_cell_property", "focus", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("focus", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_cell_property", "is_activatable", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("is_activatable", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "focus", "activate", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("activate", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "is_activatable", "_gtk_reserved1", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved1", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "activate", "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", "_gtk_reserved5", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved5", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved4", "_gtk_reserved6", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved6", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved5", "_gtk_reserved7", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved7", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved6", "_gtk_reserved8", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved8", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved7", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellArea._class_abi;
			}
		}

		// Token: 0x06000EF2 RID: 3826 RVA: 0x0002CDB4 File Offset: 0x0002AFB4
		public bool Activate(CellAreaContext context, Widget widget, Gdk.Rectangle cell_area, CellRendererState flags, bool edit_only)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(cell_area);
			bool result = CellArea.gtk_cell_area_activate(base.Handle, (context == null) ? IntPtr.Zero : context.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, intPtr, (int)flags, edit_only);
			Marshal.FreeHGlobal(intPtr);
			return result;
		}

		// Token: 0x06000EF3 RID: 3827 RVA: 0x0002CE08 File Offset: 0x0002B008
		public bool ActivateCell(Widget widget, CellRenderer renderer, Event evnt, Gdk.Rectangle cell_area, CellRendererState flags)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(cell_area);
			bool result = CellArea.gtk_cell_area_activate_cell(base.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle, (evnt == null) ? IntPtr.Zero : evnt.Handle, intPtr, (int)flags);
			Marshal.FreeHGlobal(intPtr);
			return result;
		}

		// Token: 0x06000EF4 RID: 3828 RVA: 0x0002CE6B File Offset: 0x0002B06B
		public void Add(CellRenderer renderer)
		{
			CellArea.gtk_cell_area_add(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle);
		}

		// Token: 0x06000EF5 RID: 3829 RVA: 0x0002CE8D File Offset: 0x0002B08D
		public void AddFocusSibling(CellRenderer renderer, CellRenderer sibling)
		{
			CellArea.gtk_cell_area_add_focus_sibling(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle, (sibling == null) ? IntPtr.Zero : sibling.Handle);
		}

		// Token: 0x06000EF6 RID: 3830 RVA: 0x0002CEC0 File Offset: 0x0002B0C0
		public void ApplyAttributes(ITreeModel tree_model, TreeIter iter, bool is_expander, bool is_expanded)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(iter);
			CellArea.gtk_cell_area_apply_attributes(base.Handle, (tree_model == null) ? IntPtr.Zero : ((tree_model is Object) ? (tree_model as Object).Handle : (tree_model as TreeModelAdapter).Handle), intPtr, is_expander, is_expanded);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x06000EF7 RID: 3831 RVA: 0x0002CF20 File Offset: 0x0002B120
		public void AttributeConnect(CellRenderer renderer, string attribute, int column)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(attribute);
			CellArea.gtk_cell_area_attribute_connect(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle, intPtr, column);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000EF8 RID: 3832 RVA: 0x0002CF5C File Offset: 0x0002B15C
		public void AttributeDisconnect(CellRenderer renderer, string attribute)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(attribute);
			CellArea.gtk_cell_area_attribute_disconnect(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle, intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000EF9 RID: 3833 RVA: 0x0002CF98 File Offset: 0x0002B198
		public int AttributeGetColumn(CellRenderer renderer, string attribute)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(attribute);
			int result = CellArea.gtk_cell_area_attribute_get_column(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle, intPtr);
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x06000EFA RID: 3834 RVA: 0x0002CFD4 File Offset: 0x0002B1D4
		public void CellGetProperty(CellRenderer renderer, string property_name, Value value)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(property_name);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(value);
			CellArea.gtk_cell_area_cell_get_property(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle, intPtr, intPtr2);
			Marshaller.Free(intPtr);
			Marshal.FreeHGlobal(intPtr2);
		}

		// Token: 0x06000EFB RID: 3835 RVA: 0x0002D024 File Offset: 0x0002B224
		public void CellGetValist(CellRenderer renderer, string first_property_name, IntPtr var_args)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(first_property_name);
			CellArea.gtk_cell_area_cell_get_valist(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle, intPtr, var_args);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000EFC RID: 3836 RVA: 0x0002D060 File Offset: 0x0002B260
		public void CellSetProperty(CellRenderer renderer, string property_name, Value value)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(property_name);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(value);
			CellArea.gtk_cell_area_cell_set_property(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle, intPtr, intPtr2);
			Marshaller.Free(intPtr);
			Marshal.FreeHGlobal(intPtr2);
		}

		// Token: 0x06000EFD RID: 3837 RVA: 0x0002D0B0 File Offset: 0x0002B2B0
		public void CellSetValist(CellRenderer renderer, string first_property_name, IntPtr var_args)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(first_property_name);
			CellArea.gtk_cell_area_cell_set_valist(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle, intPtr, var_args);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000EFE RID: 3838 RVA: 0x0002D0EC File Offset: 0x0002B2EC
		public CellAreaContext CopyContext(CellAreaContext context)
		{
			return Object.GetObject(CellArea.gtk_cell_area_copy_context(base.Handle, (context == null) ? IntPtr.Zero : context.Handle)) as CellAreaContext;
		}

		// Token: 0x06000EFF RID: 3839 RVA: 0x0002D118 File Offset: 0x0002B318
		public CellAreaContext CreateContext()
		{
			return Object.GetObject(CellArea.gtk_cell_area_create_context(base.Handle)) as CellAreaContext;
		}

		// Token: 0x06000F00 RID: 3840 RVA: 0x0002D134 File Offset: 0x0002B334
		public int Event(CellAreaContext context, Widget widget, Event evnt, Gdk.Rectangle cell_area, CellRendererState flags)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(cell_area);
			int result = CellArea.gtk_cell_area_event(base.Handle, (context == null) ? IntPtr.Zero : context.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, (evnt == null) ? IntPtr.Zero : evnt.Handle, intPtr, (int)flags);
			Marshal.FreeHGlobal(intPtr);
			return result;
		}

		// Token: 0x06000F01 RID: 3841 RVA: 0x0002D197 File Offset: 0x0002B397
		public bool Focus(DirectionType direction)
		{
			return CellArea.gtk_cell_area_focus(base.Handle, (int)direction);
		}

		// Token: 0x06000F02 RID: 3842 RVA: 0x0002D1AC File Offset: 0x0002B3AC
		public void Foreach(CellCallback cb)
		{
			CellCallbackWrapper cellCallbackWrapper = new CellCallbackWrapper(cb);
			CellArea.gtk_cell_area_foreach(base.Handle, cellCallbackWrapper.NativeDelegate, IntPtr.Zero);
		}

		// Token: 0x06000F03 RID: 3843 RVA: 0x0002D1DC File Offset: 0x0002B3DC
		public void ForeachAlloc(CellAreaContext context, Widget widget, Gdk.Rectangle cell_area, Gdk.Rectangle background_area, CellAllocCallback cb)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(cell_area);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(background_area);
			CellAllocCallbackWrapper cellAllocCallbackWrapper = new CellAllocCallbackWrapper(cb);
			CellArea.gtk_cell_area_foreach_alloc(base.Handle, (context == null) ? IntPtr.Zero : context.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, intPtr, intPtr2, cellAllocCallbackWrapper.NativeDelegate, IntPtr.Zero);
			Marshal.FreeHGlobal(intPtr);
			Marshal.FreeHGlobal(intPtr2);
		}

		// Token: 0x06000F04 RID: 3844 RVA: 0x0002D254 File Offset: 0x0002B454
		public void GetCellAllocation(CellAreaContext context, Widget widget, CellRenderer renderer, Gdk.Rectangle cell_area, Gdk.Rectangle allocation)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(cell_area);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(allocation);
			CellArea.gtk_cell_area_get_cell_allocation(base.Handle, (context == null) ? IntPtr.Zero : context.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle, intPtr, intPtr2);
			Marshal.FreeHGlobal(intPtr);
			Marshal.FreeHGlobal(intPtr2);
		}

		// Token: 0x06000F05 RID: 3845 RVA: 0x0002D2CC File Offset: 0x0002B4CC
		public CellRenderer GetCellAtPosition(CellAreaContext context, Widget widget, Gdk.Rectangle cell_area, int x, int y, Gdk.Rectangle alloc_area)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(cell_area);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(alloc_area);
			CellRenderer result = Object.GetObject(CellArea.gtk_cell_area_get_cell_at_position(base.Handle, (context == null) ? IntPtr.Zero : context.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, intPtr, x, y, intPtr2)) as CellRenderer;
			Marshal.FreeHGlobal(intPtr);
			Marshal.FreeHGlobal(intPtr2);
			return result;
		}

		// Token: 0x17000342 RID: 834
		// (get) Token: 0x06000F06 RID: 3846 RVA: 0x0002D33E File Offset: 0x0002B53E
		public string CurrentPathString
		{
			get
			{
				return Marshaller.Utf8PtrToString(CellArea.gtk_cell_area_get_current_path_string(base.Handle));
			}
		}

		// Token: 0x17000343 RID: 835
		// (get) Token: 0x06000F07 RID: 3847 RVA: 0x0002D355 File Offset: 0x0002B555
		public ICellEditable EditWidget
		{
			get
			{
				return CellEditableAdapter.GetObject(CellArea.gtk_cell_area_get_edit_widget(base.Handle), false);
			}
		}

		// Token: 0x17000344 RID: 836
		// (get) Token: 0x06000F08 RID: 3848 RVA: 0x0002D36D File Offset: 0x0002B56D
		public CellRenderer EditedCell
		{
			get
			{
				return Object.GetObject(CellArea.gtk_cell_area_get_edited_cell(base.Handle)) as CellRenderer;
			}
		}

		// Token: 0x17000345 RID: 837
		// (get) Token: 0x06000F09 RID: 3849 RVA: 0x0002D389 File Offset: 0x0002B589
		// (set) Token: 0x06000F0A RID: 3850 RVA: 0x0002D3A5 File Offset: 0x0002B5A5
		public CellRenderer FocusCell
		{
			get
			{
				return Object.GetObject(CellArea.gtk_cell_area_get_focus_cell(base.Handle)) as CellRenderer;
			}
			set
			{
				CellArea.gtk_cell_area_set_focus_cell(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x06000F0B RID: 3851 RVA: 0x0002D3C7 File Offset: 0x0002B5C7
		public CellRenderer GetFocusFromSibling(CellRenderer renderer)
		{
			return Object.GetObject(CellArea.gtk_cell_area_get_focus_from_sibling(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle)) as CellRenderer;
		}

		// Token: 0x06000F0C RID: 3852 RVA: 0x0002D3F4 File Offset: 0x0002B5F4
		public CellRenderer[] GetFocusSiblings(CellRenderer renderer)
		{
			return (CellRenderer[])Marshaller.ListPtrToArray(CellArea.gtk_cell_area_get_focus_siblings(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle), typeof(List), false, false, typeof(CellRenderer));
		}

		// Token: 0x06000F0D RID: 3853 RVA: 0x0002D441 File Offset: 0x0002B641
		public void GetPreferredHeight(CellAreaContext context, Widget widget, out int minimum_height, out int natural_height)
		{
			CellArea.gtk_cell_area_get_preferred_height(base.Handle, (context == null) ? IntPtr.Zero : context.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, out minimum_height, out natural_height);
		}

		// Token: 0x06000F0E RID: 3854 RVA: 0x0002D476 File Offset: 0x0002B676
		public void GetPreferredHeightForWidth(CellAreaContext context, Widget widget, int width, out int minimum_height, out int natural_height)
		{
			CellArea.gtk_cell_area_get_preferred_height_for_width(base.Handle, (context == null) ? IntPtr.Zero : context.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, width, out minimum_height, out natural_height);
		}

		// Token: 0x06000F0F RID: 3855 RVA: 0x0002D4AD File Offset: 0x0002B6AD
		public void GetPreferredWidth(CellAreaContext context, Widget widget, out int minimum_width, out int natural_width)
		{
			CellArea.gtk_cell_area_get_preferred_width(base.Handle, (context == null) ? IntPtr.Zero : context.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, out minimum_width, out natural_width);
		}

		// Token: 0x06000F10 RID: 3856 RVA: 0x0002D4E2 File Offset: 0x0002B6E2
		public void GetPreferredWidthForHeight(CellAreaContext context, Widget widget, int height, out int minimum_width, out int natural_width)
		{
			CellArea.gtk_cell_area_get_preferred_width_for_height(base.Handle, (context == null) ? IntPtr.Zero : context.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, height, out minimum_width, out natural_width);
		}

		// Token: 0x17000346 RID: 838
		// (get) Token: 0x06000F11 RID: 3857 RVA: 0x0002D519 File Offset: 0x0002B719
		public SizeRequestMode RequestMode
		{
			get
			{
				return (SizeRequestMode)CellArea.gtk_cell_area_get_request_mode(base.Handle);
			}
		}

		// Token: 0x17000347 RID: 839
		// (get) Token: 0x06000F12 RID: 3858 RVA: 0x0002D52C File Offset: 0x0002B72C
		public new static GType GType
		{
			get
			{
				IntPtr val = CellArea.gtk_cell_area_get_type();
				return new GType(val);
			}
		}

		// Token: 0x06000F13 RID: 3859 RVA: 0x0002D54A File Offset: 0x0002B74A
		public bool HasRenderer(CellRenderer renderer)
		{
			return CellArea.gtk_cell_area_has_renderer(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle);
		}

		// Token: 0x06000F14 RID: 3860 RVA: 0x0002D56C File Offset: 0x0002B76C
		public void InnerCellArea(Widget widget, Gdk.Rectangle cell_area, Gdk.Rectangle inner_area)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(cell_area);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(inner_area);
			CellArea.gtk_cell_area_inner_cell_area(base.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, intPtr, intPtr2);
			Marshal.FreeHGlobal(intPtr);
			Marshal.FreeHGlobal(intPtr2);
		}

		// Token: 0x17000348 RID: 840
		// (get) Token: 0x06000F15 RID: 3861 RVA: 0x0002D5BF File Offset: 0x0002B7BF
		public bool IsActivatable
		{
			get
			{
				return CellArea.gtk_cell_area_is_activatable(base.Handle);
			}
		}

		// Token: 0x06000F16 RID: 3862 RVA: 0x0002D5D1 File Offset: 0x0002B7D1
		public bool IsFocusSibling(CellRenderer renderer, CellRenderer sibling)
		{
			return CellArea.gtk_cell_area_is_focus_sibling(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle, (sibling == null) ? IntPtr.Zero : sibling.Handle);
		}

		// Token: 0x06000F17 RID: 3863 RVA: 0x0002D603 File Offset: 0x0002B803
		public void Remove(CellRenderer renderer)
		{
			CellArea.gtk_cell_area_remove(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle);
		}

		// Token: 0x06000F18 RID: 3864 RVA: 0x0002D625 File Offset: 0x0002B825
		public void RemoveFocusSibling(CellRenderer renderer, CellRenderer sibling)
		{
			CellArea.gtk_cell_area_remove_focus_sibling(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle, (sibling == null) ? IntPtr.Zero : sibling.Handle);
		}

		// Token: 0x06000F19 RID: 3865 RVA: 0x0002D658 File Offset: 0x0002B858
		public void Render(CellAreaContext context, Widget widget, Context cr, Gdk.Rectangle background_area, Gdk.Rectangle cell_area, CellRendererState flags, bool paint_focus)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(background_area);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(cell_area);
			CellArea.gtk_cell_area_render(base.Handle, (context == null) ? IntPtr.Zero : context.Handle, (widget == null) ? IntPtr.Zero : widget.Handle, (cr == null) ? IntPtr.Zero : cr.Handle, intPtr, intPtr2, (int)flags, paint_focus);
			Marshal.FreeHGlobal(intPtr);
			Marshal.FreeHGlobal(intPtr2);
		}

		// Token: 0x06000F1A RID: 3866 RVA: 0x0002D6D1 File Offset: 0x0002B8D1
		public void RequestRenderer(CellRenderer renderer, Orientation orientation, Widget widget, int for_size, out int minimum_size, out int natural_size)
		{
			CellArea.gtk_cell_area_request_renderer(base.Handle, (renderer == null) ? IntPtr.Zero : renderer.Handle, (int)orientation, (widget == null) ? IntPtr.Zero : widget.Handle, for_size, out minimum_size, out natural_size);
		}

		// Token: 0x06000F1B RID: 3867 RVA: 0x0002D70A File Offset: 0x0002B90A
		public void StopEditing(bool canceled)
		{
			CellArea.gtk_cell_area_stop_editing(base.Handle, canceled);
		}

		// Token: 0x17000349 RID: 841
		// (get) Token: 0x06000F1C RID: 3868 RVA: 0x0002D720 File Offset: 0x0002B920
		public new static AbiStruct abi_info
		{
			get
			{
				if (CellArea._abi_info == null)
				{
					CellArea._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Object.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CellArea._abi_info;
			}
		}

		// Token: 0x04000732 RID: 1842
		private static CellArea.AddNativeDelegate Add_cb_delegate;

		// Token: 0x04000733 RID: 1843
		private static CellArea.RemoveNativeDelegate Remove_cb_delegate;

		// Token: 0x04000734 RID: 1844
		private static CellArea.ForeachNativeDelegate Foreach_cb_delegate;

		// Token: 0x04000735 RID: 1845
		private static CellArea.ForeachAllocNativeDelegate ForeachAlloc_cb_delegate;

		// Token: 0x04000736 RID: 1846
		private static CellArea.EventNativeDelegate Event_cb_delegate;

		// Token: 0x04000737 RID: 1847
		private static CellArea.RenderNativeDelegate Render_cb_delegate;

		// Token: 0x04000738 RID: 1848
		private static CellArea.ApplyAttributesNativeDelegate ApplyAttributes_cb_delegate;

		// Token: 0x04000739 RID: 1849
		private static CellArea.CreateContextNativeDelegate CreateContext_cb_delegate;

		// Token: 0x0400073A RID: 1850
		private static CellArea.CopyContextNativeDelegate CopyContext_cb_delegate;

		// Token: 0x0400073B RID: 1851
		private static CellArea.GetRequestModeNativeDelegate GetRequestMode_cb_delegate;

		// Token: 0x0400073C RID: 1852
		private static CellArea.GetPreferredWidthNativeDelegate GetPreferredWidth_cb_delegate;

		// Token: 0x0400073D RID: 1853
		private static CellArea.GetPreferredHeightForWidthNativeDelegate GetPreferredHeightForWidth_cb_delegate;

		// Token: 0x0400073E RID: 1854
		private static CellArea.GetPreferredHeightNativeDelegate GetPreferredHeight_cb_delegate;

		// Token: 0x0400073F RID: 1855
		private static CellArea.GetPreferredWidthForHeightNativeDelegate GetPreferredWidthForHeight_cb_delegate;

		// Token: 0x04000740 RID: 1856
		private static CellArea.SetCellPropertyNativeDelegate SetCellProperty_cb_delegate;

		// Token: 0x04000741 RID: 1857
		private static CellArea.GetCellPropertyNativeDelegate GetCellProperty_cb_delegate;

		// Token: 0x04000742 RID: 1858
		private static CellArea.FocusNativeDelegate Focus_cb_delegate;

		// Token: 0x04000743 RID: 1859
		private static CellArea.IsActivatableNativeDelegate IsActivatable_cb_delegate;

		// Token: 0x04000744 RID: 1860
		private static CellArea.ActivateNativeDelegate Activate_cb_delegate;

		// Token: 0x04000745 RID: 1861
		private static AbiStruct _class_abi = null;

		// Token: 0x04000746 RID: 1862
		private static CellArea.d_gtk_cell_area_activate gtk_cell_area_activate = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_activate>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_activate"));

		// Token: 0x04000747 RID: 1863
		private static CellArea.d_gtk_cell_area_activate_cell gtk_cell_area_activate_cell = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_activate_cell>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_activate_cell"));

		// Token: 0x04000748 RID: 1864
		private static CellArea.d_gtk_cell_area_add gtk_cell_area_add = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_add>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_add"));

		// Token: 0x04000749 RID: 1865
		private static CellArea.d_gtk_cell_area_add_focus_sibling gtk_cell_area_add_focus_sibling = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_add_focus_sibling>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_add_focus_sibling"));

		// Token: 0x0400074A RID: 1866
		private static CellArea.d_gtk_cell_area_apply_attributes gtk_cell_area_apply_attributes = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_apply_attributes>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_apply_attributes"));

		// Token: 0x0400074B RID: 1867
		private static CellArea.d_gtk_cell_area_attribute_connect gtk_cell_area_attribute_connect = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_attribute_connect>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_attribute_connect"));

		// Token: 0x0400074C RID: 1868
		private static CellArea.d_gtk_cell_area_attribute_disconnect gtk_cell_area_attribute_disconnect = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_attribute_disconnect>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_attribute_disconnect"));

		// Token: 0x0400074D RID: 1869
		private static CellArea.d_gtk_cell_area_attribute_get_column gtk_cell_area_attribute_get_column = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_attribute_get_column>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_attribute_get_column"));

		// Token: 0x0400074E RID: 1870
		private static CellArea.d_gtk_cell_area_cell_get_property gtk_cell_area_cell_get_property = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_cell_get_property>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_cell_get_property"));

		// Token: 0x0400074F RID: 1871
		private static CellArea.d_gtk_cell_area_cell_get_valist gtk_cell_area_cell_get_valist = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_cell_get_valist>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_cell_get_valist"));

		// Token: 0x04000750 RID: 1872
		private static CellArea.d_gtk_cell_area_cell_set_property gtk_cell_area_cell_set_property = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_cell_set_property>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_cell_set_property"));

		// Token: 0x04000751 RID: 1873
		private static CellArea.d_gtk_cell_area_cell_set_valist gtk_cell_area_cell_set_valist = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_cell_set_valist>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_cell_set_valist"));

		// Token: 0x04000752 RID: 1874
		private static CellArea.d_gtk_cell_area_copy_context gtk_cell_area_copy_context = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_copy_context>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_copy_context"));

		// Token: 0x04000753 RID: 1875
		private static CellArea.d_gtk_cell_area_create_context gtk_cell_area_create_context = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_create_context>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_create_context"));

		// Token: 0x04000754 RID: 1876
		private static CellArea.d_gtk_cell_area_event gtk_cell_area_event = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_event>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_event"));

		// Token: 0x04000755 RID: 1877
		private static CellArea.d_gtk_cell_area_focus gtk_cell_area_focus = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_focus>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_focus"));

		// Token: 0x04000756 RID: 1878
		private static CellArea.d_gtk_cell_area_foreach gtk_cell_area_foreach = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_foreach>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_foreach"));

		// Token: 0x04000757 RID: 1879
		private static CellArea.d_gtk_cell_area_foreach_alloc gtk_cell_area_foreach_alloc = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_foreach_alloc>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_foreach_alloc"));

		// Token: 0x04000758 RID: 1880
		private static CellArea.d_gtk_cell_area_get_cell_allocation gtk_cell_area_get_cell_allocation = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_get_cell_allocation>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_get_cell_allocation"));

		// Token: 0x04000759 RID: 1881
		private static CellArea.d_gtk_cell_area_get_cell_at_position gtk_cell_area_get_cell_at_position = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_get_cell_at_position>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_get_cell_at_position"));

		// Token: 0x0400075A RID: 1882
		private static CellArea.d_gtk_cell_area_get_current_path_string gtk_cell_area_get_current_path_string = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_get_current_path_string>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_get_current_path_string"));

		// Token: 0x0400075B RID: 1883
		private static CellArea.d_gtk_cell_area_get_edit_widget gtk_cell_area_get_edit_widget = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_get_edit_widget>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_get_edit_widget"));

		// Token: 0x0400075C RID: 1884
		private static CellArea.d_gtk_cell_area_get_edited_cell gtk_cell_area_get_edited_cell = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_get_edited_cell>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_get_edited_cell"));

		// Token: 0x0400075D RID: 1885
		private static CellArea.d_gtk_cell_area_get_focus_cell gtk_cell_area_get_focus_cell = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_get_focus_cell>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_get_focus_cell"));

		// Token: 0x0400075E RID: 1886
		private static CellArea.d_gtk_cell_area_set_focus_cell gtk_cell_area_set_focus_cell = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_set_focus_cell>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_set_focus_cell"));

		// Token: 0x0400075F RID: 1887
		private static CellArea.d_gtk_cell_area_get_focus_from_sibling gtk_cell_area_get_focus_from_sibling = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_get_focus_from_sibling>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_get_focus_from_sibling"));

		// Token: 0x04000760 RID: 1888
		private static CellArea.d_gtk_cell_area_get_focus_siblings gtk_cell_area_get_focus_siblings = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_get_focus_siblings>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_get_focus_siblings"));

		// Token: 0x04000761 RID: 1889
		private static CellArea.d_gtk_cell_area_get_preferred_height gtk_cell_area_get_preferred_height = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_get_preferred_height>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_get_preferred_height"));

		// Token: 0x04000762 RID: 1890
		private static CellArea.d_gtk_cell_area_get_preferred_height_for_width gtk_cell_area_get_preferred_height_for_width = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_get_preferred_height_for_width>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_get_preferred_height_for_width"));

		// Token: 0x04000763 RID: 1891
		private static CellArea.d_gtk_cell_area_get_preferred_width gtk_cell_area_get_preferred_width = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_get_preferred_width>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_get_preferred_width"));

		// Token: 0x04000764 RID: 1892
		private static CellArea.d_gtk_cell_area_get_preferred_width_for_height gtk_cell_area_get_preferred_width_for_height = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_get_preferred_width_for_height>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_get_preferred_width_for_height"));

		// Token: 0x04000765 RID: 1893
		private static CellArea.d_gtk_cell_area_get_request_mode gtk_cell_area_get_request_mode = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_get_request_mode>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_get_request_mode"));

		// Token: 0x04000766 RID: 1894
		private static CellArea.d_gtk_cell_area_get_type gtk_cell_area_get_type = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_get_type"));

		// Token: 0x04000767 RID: 1895
		private static CellArea.d_gtk_cell_area_has_renderer gtk_cell_area_has_renderer = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_has_renderer>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_has_renderer"));

		// Token: 0x04000768 RID: 1896
		private static CellArea.d_gtk_cell_area_inner_cell_area gtk_cell_area_inner_cell_area = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_inner_cell_area>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_inner_cell_area"));

		// Token: 0x04000769 RID: 1897
		private static CellArea.d_gtk_cell_area_is_activatable gtk_cell_area_is_activatable = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_is_activatable>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_is_activatable"));

		// Token: 0x0400076A RID: 1898
		private static CellArea.d_gtk_cell_area_is_focus_sibling gtk_cell_area_is_focus_sibling = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_is_focus_sibling>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_is_focus_sibling"));

		// Token: 0x0400076B RID: 1899
		private static CellArea.d_gtk_cell_area_remove gtk_cell_area_remove = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_remove>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_remove"));

		// Token: 0x0400076C RID: 1900
		private static CellArea.d_gtk_cell_area_remove_focus_sibling gtk_cell_area_remove_focus_sibling = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_remove_focus_sibling>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_remove_focus_sibling"));

		// Token: 0x0400076D RID: 1901
		private static CellArea.d_gtk_cell_area_render gtk_cell_area_render = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_render>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_render"));

		// Token: 0x0400076E RID: 1902
		private static CellArea.d_gtk_cell_area_request_renderer gtk_cell_area_request_renderer = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_request_renderer>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_request_renderer"));

		// Token: 0x0400076F RID: 1903
		private static CellArea.d_gtk_cell_area_stop_editing gtk_cell_area_stop_editing = FuncLoader.LoadFunction<CellArea.d_gtk_cell_area_stop_editing>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_area_stop_editing"));

		// Token: 0x04000770 RID: 1904
		private static AbiStruct _abi_info = null;

		// Token: 0x02000AC2 RID: 2754
		// (Invoke) Token: 0x06005219 RID: 21017
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void AddNativeDelegate(IntPtr inst, IntPtr renderer);

		// Token: 0x02000AC3 RID: 2755
		// (Invoke) Token: 0x0600521D RID: 21021
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void RemoveNativeDelegate(IntPtr inst, IntPtr renderer);

		// Token: 0x02000AC4 RID: 2756
		// (Invoke) Token: 0x06005221 RID: 21025
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ForeachNativeDelegate(IntPtr inst, CellCallbackNative cb, IntPtr callback_data);

		// Token: 0x02000AC5 RID: 2757
		// (Invoke) Token: 0x06005225 RID: 21029
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ForeachAllocNativeDelegate(IntPtr inst, IntPtr context, IntPtr widget, IntPtr cell_area, IntPtr background_area, CellAllocCallbackNative cb, IntPtr callback_data);

		// Token: 0x02000AC6 RID: 2758
		// (Invoke) Token: 0x06005229 RID: 21033
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int EventNativeDelegate(IntPtr inst, IntPtr context, IntPtr widget, IntPtr evnt, IntPtr cell_area, int flags);

		// Token: 0x02000AC7 RID: 2759
		// (Invoke) Token: 0x0600522D RID: 21037
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void RenderNativeDelegate(IntPtr inst, IntPtr context, IntPtr widget, IntPtr cr, IntPtr background_area, IntPtr cell_area, int flags, bool paint_focus);

		// Token: 0x02000AC8 RID: 2760
		// (Invoke) Token: 0x06005231 RID: 21041
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ApplyAttributesNativeDelegate(IntPtr inst, IntPtr tree_model, IntPtr iter, bool is_expander, bool is_expanded);

		// Token: 0x02000AC9 RID: 2761
		// (Invoke) Token: 0x06005235 RID: 21045
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr CreateContextNativeDelegate(IntPtr inst);

		// Token: 0x02000ACA RID: 2762
		// (Invoke) Token: 0x06005239 RID: 21049
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr CopyContextNativeDelegate(IntPtr inst, IntPtr context);

		// Token: 0x02000ACB RID: 2763
		// (Invoke) Token: 0x0600523D RID: 21053
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetRequestModeNativeDelegate(IntPtr inst);

		// Token: 0x02000ACC RID: 2764
		// (Invoke) Token: 0x06005241 RID: 21057
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void GetPreferredWidthNativeDelegate(IntPtr inst, IntPtr context, IntPtr widget, out int minimum_width, out int natural_width);

		// Token: 0x02000ACD RID: 2765
		// (Invoke) Token: 0x06005245 RID: 21061
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void GetPreferredHeightForWidthNativeDelegate(IntPtr inst, IntPtr context, IntPtr widget, int width, out int minimum_height, out int natural_height);

		// Token: 0x02000ACE RID: 2766
		// (Invoke) Token: 0x06005249 RID: 21065
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void GetPreferredHeightNativeDelegate(IntPtr inst, IntPtr context, IntPtr widget, out int minimum_height, out int natural_height);

		// Token: 0x02000ACF RID: 2767
		// (Invoke) Token: 0x0600524D RID: 21069
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void GetPreferredWidthForHeightNativeDelegate(IntPtr inst, IntPtr context, IntPtr widget, int height, out int minimum_width, out int natural_width);

		// Token: 0x02000AD0 RID: 2768
		// (Invoke) Token: 0x06005251 RID: 21073
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void SetCellPropertyNativeDelegate(IntPtr inst, IntPtr renderer, uint property_id, IntPtr value, IntPtr pspec);

		// Token: 0x02000AD1 RID: 2769
		// (Invoke) Token: 0x06005255 RID: 21077
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void GetCellPropertyNativeDelegate(IntPtr inst, IntPtr renderer, uint property_id, IntPtr value, IntPtr pspec);

		// Token: 0x02000AD2 RID: 2770
		// (Invoke) Token: 0x06005259 RID: 21081
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool FocusNativeDelegate(IntPtr inst, int direction);

		// Token: 0x02000AD3 RID: 2771
		// (Invoke) Token: 0x0600525D RID: 21085
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool IsActivatableNativeDelegate(IntPtr inst);

		// Token: 0x02000AD4 RID: 2772
		// (Invoke) Token: 0x06005261 RID: 21089
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool ActivateNativeDelegate(IntPtr inst, IntPtr context, IntPtr widget, IntPtr cell_area, int flags, bool edit_only);

		// Token: 0x02000AD5 RID: 2773
		// (Invoke) Token: 0x06005265 RID: 21093
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_cell_area_activate(IntPtr raw, IntPtr context, IntPtr widget, IntPtr cell_area, int flags, bool edit_only);

		// Token: 0x02000AD6 RID: 2774
		// (Invoke) Token: 0x06005269 RID: 21097
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_cell_area_activate_cell(IntPtr raw, IntPtr widget, IntPtr renderer, IntPtr evnt, IntPtr cell_area, int flags);

		// Token: 0x02000AD7 RID: 2775
		// (Invoke) Token: 0x0600526D RID: 21101
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_add(IntPtr raw, IntPtr renderer);

		// Token: 0x02000AD8 RID: 2776
		// (Invoke) Token: 0x06005271 RID: 21105
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_add_focus_sibling(IntPtr raw, IntPtr renderer, IntPtr sibling);

		// Token: 0x02000AD9 RID: 2777
		// (Invoke) Token: 0x06005275 RID: 21109
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_apply_attributes(IntPtr raw, IntPtr tree_model, IntPtr iter, bool is_expander, bool is_expanded);

		// Token: 0x02000ADA RID: 2778
		// (Invoke) Token: 0x06005279 RID: 21113
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_attribute_connect(IntPtr raw, IntPtr renderer, IntPtr attribute, int column);

		// Token: 0x02000ADB RID: 2779
		// (Invoke) Token: 0x0600527D RID: 21117
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_attribute_disconnect(IntPtr raw, IntPtr renderer, IntPtr attribute);

		// Token: 0x02000ADC RID: 2780
		// (Invoke) Token: 0x06005281 RID: 21121
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_cell_area_attribute_get_column(IntPtr raw, IntPtr renderer, IntPtr attribute);

		// Token: 0x02000ADD RID: 2781
		// (Invoke) Token: 0x06005285 RID: 21125
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_cell_get_property(IntPtr raw, IntPtr renderer, IntPtr property_name, IntPtr value);

		// Token: 0x02000ADE RID: 2782
		// (Invoke) Token: 0x06005289 RID: 21129
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_cell_get_valist(IntPtr raw, IntPtr renderer, IntPtr first_property_name, IntPtr var_args);

		// Token: 0x02000ADF RID: 2783
		// (Invoke) Token: 0x0600528D RID: 21133
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_cell_set_property(IntPtr raw, IntPtr renderer, IntPtr property_name, IntPtr value);

		// Token: 0x02000AE0 RID: 2784
		// (Invoke) Token: 0x06005291 RID: 21137
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_cell_set_valist(IntPtr raw, IntPtr renderer, IntPtr first_property_name, IntPtr var_args);

		// Token: 0x02000AE1 RID: 2785
		// (Invoke) Token: 0x06005295 RID: 21141
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_area_copy_context(IntPtr raw, IntPtr context);

		// Token: 0x02000AE2 RID: 2786
		// (Invoke) Token: 0x06005299 RID: 21145
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_area_create_context(IntPtr raw);

		// Token: 0x02000AE3 RID: 2787
		// (Invoke) Token: 0x0600529D RID: 21149
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_cell_area_event(IntPtr raw, IntPtr context, IntPtr widget, IntPtr evnt, IntPtr cell_area, int flags);

		// Token: 0x02000AE4 RID: 2788
		// (Invoke) Token: 0x060052A1 RID: 21153
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_cell_area_focus(IntPtr raw, int direction);

		// Token: 0x02000AE5 RID: 2789
		// (Invoke) Token: 0x060052A5 RID: 21157
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_foreach(IntPtr raw, CellCallbackNative cb, IntPtr callback_data);

		// Token: 0x02000AE6 RID: 2790
		// (Invoke) Token: 0x060052A9 RID: 21161
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_foreach_alloc(IntPtr raw, IntPtr context, IntPtr widget, IntPtr cell_area, IntPtr background_area, CellAllocCallbackNative cb, IntPtr callback_data);

		// Token: 0x02000AE7 RID: 2791
		// (Invoke) Token: 0x060052AD RID: 21165
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_get_cell_allocation(IntPtr raw, IntPtr context, IntPtr widget, IntPtr renderer, IntPtr cell_area, IntPtr allocation);

		// Token: 0x02000AE8 RID: 2792
		// (Invoke) Token: 0x060052B1 RID: 21169
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_area_get_cell_at_position(IntPtr raw, IntPtr context, IntPtr widget, IntPtr cell_area, int x, int y, IntPtr alloc_area);

		// Token: 0x02000AE9 RID: 2793
		// (Invoke) Token: 0x060052B5 RID: 21173
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_area_get_current_path_string(IntPtr raw);

		// Token: 0x02000AEA RID: 2794
		// (Invoke) Token: 0x060052B9 RID: 21177
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_area_get_edit_widget(IntPtr raw);

		// Token: 0x02000AEB RID: 2795
		// (Invoke) Token: 0x060052BD RID: 21181
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_area_get_edited_cell(IntPtr raw);

		// Token: 0x02000AEC RID: 2796
		// (Invoke) Token: 0x060052C1 RID: 21185
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_area_get_focus_cell(IntPtr raw);

		// Token: 0x02000AED RID: 2797
		// (Invoke) Token: 0x060052C5 RID: 21189
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_set_focus_cell(IntPtr raw, IntPtr renderer);

		// Token: 0x02000AEE RID: 2798
		// (Invoke) Token: 0x060052C9 RID: 21193
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_area_get_focus_from_sibling(IntPtr raw, IntPtr renderer);

		// Token: 0x02000AEF RID: 2799
		// (Invoke) Token: 0x060052CD RID: 21197
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_area_get_focus_siblings(IntPtr raw, IntPtr renderer);

		// Token: 0x02000AF0 RID: 2800
		// (Invoke) Token: 0x060052D1 RID: 21201
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_get_preferred_height(IntPtr raw, IntPtr context, IntPtr widget, out int minimum_height, out int natural_height);

		// Token: 0x02000AF1 RID: 2801
		// (Invoke) Token: 0x060052D5 RID: 21205
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_get_preferred_height_for_width(IntPtr raw, IntPtr context, IntPtr widget, int width, out int minimum_height, out int natural_height);

		// Token: 0x02000AF2 RID: 2802
		// (Invoke) Token: 0x060052D9 RID: 21209
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_get_preferred_width(IntPtr raw, IntPtr context, IntPtr widget, out int minimum_width, out int natural_width);

		// Token: 0x02000AF3 RID: 2803
		// (Invoke) Token: 0x060052DD RID: 21213
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_get_preferred_width_for_height(IntPtr raw, IntPtr context, IntPtr widget, int height, out int minimum_width, out int natural_width);

		// Token: 0x02000AF4 RID: 2804
		// (Invoke) Token: 0x060052E1 RID: 21217
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_cell_area_get_request_mode(IntPtr raw);

		// Token: 0x02000AF5 RID: 2805
		// (Invoke) Token: 0x060052E5 RID: 21221
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_area_get_type();

		// Token: 0x02000AF6 RID: 2806
		// (Invoke) Token: 0x060052E9 RID: 21225
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_cell_area_has_renderer(IntPtr raw, IntPtr renderer);

		// Token: 0x02000AF7 RID: 2807
		// (Invoke) Token: 0x060052ED RID: 21229
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_inner_cell_area(IntPtr raw, IntPtr widget, IntPtr cell_area, IntPtr inner_area);

		// Token: 0x02000AF8 RID: 2808
		// (Invoke) Token: 0x060052F1 RID: 21233
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_cell_area_is_activatable(IntPtr raw);

		// Token: 0x02000AF9 RID: 2809
		// (Invoke) Token: 0x060052F5 RID: 21237
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_cell_area_is_focus_sibling(IntPtr raw, IntPtr renderer, IntPtr sibling);

		// Token: 0x02000AFA RID: 2810
		// (Invoke) Token: 0x060052F9 RID: 21241
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_remove(IntPtr raw, IntPtr renderer);

		// Token: 0x02000AFB RID: 2811
		// (Invoke) Token: 0x060052FD RID: 21245
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_remove_focus_sibling(IntPtr raw, IntPtr renderer, IntPtr sibling);

		// Token: 0x02000AFC RID: 2812
		// (Invoke) Token: 0x06005301 RID: 21249
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_render(IntPtr raw, IntPtr context, IntPtr widget, IntPtr cr, IntPtr background_area, IntPtr cell_area, int flags, bool paint_focus);

		// Token: 0x02000AFD RID: 2813
		// (Invoke) Token: 0x06005305 RID: 21253
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_request_renderer(IntPtr raw, IntPtr renderer, int orientation, IntPtr widget, int for_size, out int minimum_size, out int natural_size);

		// Token: 0x02000AFE RID: 2814
		// (Invoke) Token: 0x06005309 RID: 21257
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_area_stop_editing(IntPtr raw, bool canceled);
	}
}
