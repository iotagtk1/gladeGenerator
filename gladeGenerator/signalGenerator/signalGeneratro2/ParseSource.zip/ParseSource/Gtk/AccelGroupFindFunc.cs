﻿using System;

namespace Gtk
{
	// Token: 0x020000FE RID: 254
	// (Invoke) Token: 0x06000B5A RID: 2906
	public delegate bool AccelGroupFindFunc(AccelKey key, IntPtr closure);
}
