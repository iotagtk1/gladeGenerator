﻿using System;
using Gdk;

namespace Gtk
{
	// Token: 0x02000101 RID: 257
	// (Invoke) Token: 0x06000B87 RID: 2951
	public delegate void AccelMapForeach(IntPtr data, string accel_path, uint accel_key, ModifierType accel_mods, bool changed);
}
