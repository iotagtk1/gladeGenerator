﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x0200012F RID: 303
	internal class ArrowTypeGType
	{
		// Token: 0x170002E1 RID: 737
		// (get) Token: 0x06000D5F RID: 3423 RVA: 0x000288C1 File Offset: 0x00026AC1
		public static GType GType
		{
			get
			{
				return new GType(ArrowTypeGType.gtk_arrow_type_get_type());
			}
		}

		// Token: 0x04000684 RID: 1668
		private static ArrowTypeGType.d_gtk_arrow_type_get_type gtk_arrow_type_get_type = FuncLoader.LoadFunction<ArrowTypeGType.d_gtk_arrow_type_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_arrow_type_get_type"));

		// Token: 0x02000A73 RID: 2675
		// (Invoke) Token: 0x060050D3 RID: 20691
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_arrow_type_get_type();
	}
}
