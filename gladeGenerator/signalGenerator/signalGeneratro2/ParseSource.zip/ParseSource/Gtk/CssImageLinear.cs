﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001D3 RID: 467
	public class CssImageLinear : Opaque
	{
		// Token: 0x060011A1 RID: 4513 RVA: 0x00033F77 File Offset: 0x00032177
		public CssImageLinear(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000424 RID: 1060
		// (get) Token: 0x060011A2 RID: 4514 RVA: 0x00033F80 File Offset: 0x00032180
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImageLinear._abi_info == null)
				{
					CssImageLinear._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImageLinear._abi_info;
			}
		}

		// Token: 0x04000833 RID: 2099
		private static AbiStruct _abi_info;
	}
}
