﻿using System;

namespace Gtk
{
	// Token: 0x02000214 RID: 532
	// (Invoke) Token: 0x0600124C RID: 4684
	public delegate void CycleChildFocusHandler(object o, CycleChildFocusArgs args);
}
