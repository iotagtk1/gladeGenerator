﻿using System;

namespace Gtk
{
	// Token: 0x0200021E RID: 542
	// (Invoke) Token: 0x06001268 RID: 4712
	public delegate void DeletedTextHandler(object o, DeletedTextArgs args);
}
