﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001C6 RID: 454
	public class CssGadgetClass : Opaque
	{
		// Token: 0x06001187 RID: 4487 RVA: 0x00033D89 File Offset: 0x00031F89
		public CssGadgetClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000417 RID: 1047
		// (get) Token: 0x06001188 RID: 4488 RVA: 0x00033D92 File Offset: 0x00031F92
		public static AbiStruct abi_info
		{
			get
			{
				if (CssGadgetClass._abi_info == null)
				{
					CssGadgetClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssGadgetClass._abi_info;
			}
		}

		// Token: 0x04000826 RID: 2086
		private static AbiStruct _abi_info;
	}
}
