﻿using System;
using System.Runtime.InteropServices;
using GLib;
using GtkSharp;

namespace Gtk
{
	// Token: 0x020000DC RID: 220
	public class CellLayoutAdapter : GInterfaceAdapter, ICellLayout, IWrapper
	{
		// Token: 0x060005E7 RID: 1511 RVA: 0x00010644 File Offset: 0x0000E844
		public void SetAttributes(CellRenderer cell, params object[] attrs)
		{
			if (attrs.Length % 2 != 0)
			{
				throw new ArgumentException("attrs should contain pairs of attribute/col");
			}
			this.ClearAttributes(cell);
			for (int i = 0; i < attrs.Length - 1; i += 2)
			{
				this.AddAttribute(cell, (string)attrs[i], (int)attrs[i + 1]);
			}
		}

		// Token: 0x060005E8 RID: 1512 RVA: 0x00010694 File Offset: 0x0000E894
		static CellLayoutAdapter()
		{
			GType.Register(CellLayoutAdapter._gtype, typeof(CellLayoutAdapter));
			CellLayoutAdapter.iface.PackStart = new CellLayoutAdapter.PackStartNativeDelegate(CellLayoutAdapter.PackStart_cb);
			CellLayoutAdapter.iface.PackEnd = new CellLayoutAdapter.PackEndNativeDelegate(CellLayoutAdapter.PackEnd_cb);
			CellLayoutAdapter.iface.Clear = new CellLayoutAdapter.ClearNativeDelegate(CellLayoutAdapter.Clear_cb);
			CellLayoutAdapter.iface.AddAttribute = new CellLayoutAdapter.AddAttributeNativeDelegate(CellLayoutAdapter.AddAttribute_cb);
			CellLayoutAdapter.iface.SetCellDataFunc = new CellLayoutAdapter.SetCellDataFuncNativeDelegate(CellLayoutAdapter.SetCellDataFunc_cb);
			CellLayoutAdapter.iface.ClearAttributes = new CellLayoutAdapter.ClearAttributesNativeDelegate(CellLayoutAdapter.ClearAttributes_cb);
			CellLayoutAdapter.iface.Reorder = new CellLayoutAdapter.ReorderNativeDelegate(CellLayoutAdapter.Reorder_cb);
			CellLayoutAdapter.iface.GetCells = new CellLayoutAdapter.GetCellsNativeDelegate(CellLayoutAdapter.GetCells_cb);
			CellLayoutAdapter.iface.GetArea = new CellLayoutAdapter.GetAreaNativeDelegate(CellLayoutAdapter.GetArea_cb);
		}

		// Token: 0x060005E9 RID: 1513 RVA: 0x000108AC File Offset: 0x0000EAAC
		private static void PackStart_cb(IntPtr inst, IntPtr cell, bool expand)
		{
			try
			{
				(Object.GetObject(inst, false) as ICellLayoutImplementor).PackStart(Object.GetObject(cell) as CellRenderer, expand);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005EA RID: 1514 RVA: 0x000108F0 File Offset: 0x0000EAF0
		private static void PackEnd_cb(IntPtr inst, IntPtr cell, bool expand)
		{
			try
			{
				(Object.GetObject(inst, false) as ICellLayoutImplementor).PackEnd(Object.GetObject(cell) as CellRenderer, expand);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005EB RID: 1515 RVA: 0x00010934 File Offset: 0x0000EB34
		private static void Clear_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as ICellLayoutImplementor).Clear();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005EC RID: 1516 RVA: 0x0001096C File Offset: 0x0000EB6C
		private static void AddAttribute_cb(IntPtr inst, IntPtr cell, IntPtr attribute, int column)
		{
			try
			{
				(Object.GetObject(inst, false) as ICellLayoutImplementor).AddAttribute(Object.GetObject(cell) as CellRenderer, Marshaller.Utf8PtrToString(attribute), column);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005ED RID: 1517 RVA: 0x000109B8 File Offset: 0x0000EBB8
		private static void SetCellDataFunc_cb(IntPtr inst, IntPtr cell, CellLayoutDataFuncNative func, IntPtr func_data, DestroyNotify destroy)
		{
			try
			{
				ICellLayoutImplementor cellLayoutImplementor = Object.GetObject(inst, false) as ICellLayoutImplementor;
				CellLayoutDataFuncInvoker cellLayoutDataFuncInvoker = new CellLayoutDataFuncInvoker(func, func_data, destroy);
				cellLayoutImplementor.SetCellDataFunc(Object.GetObject(cell) as CellRenderer, cellLayoutDataFuncInvoker.Handler);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005EE RID: 1518 RVA: 0x00010A0C File Offset: 0x0000EC0C
		private static void ClearAttributes_cb(IntPtr inst, IntPtr cell)
		{
			try
			{
				(Object.GetObject(inst, false) as ICellLayoutImplementor).ClearAttributes(Object.GetObject(cell) as CellRenderer);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005EF RID: 1519 RVA: 0x00010A50 File Offset: 0x0000EC50
		private static void Reorder_cb(IntPtr inst, IntPtr cell, int position)
		{
			try
			{
				(Object.GetObject(inst, false) as ICellLayoutImplementor).Reorder(Object.GetObject(cell) as CellRenderer, position);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005F0 RID: 1520 RVA: 0x00010A94 File Offset: 0x0000EC94
		private static IntPtr GetCells_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				CellRenderer[] cells = (Object.GetObject(inst, false) as ICellLayoutImplementor).Cells;
				object[] elements = cells;
				IntPtr intPtr;
				if (new List(elements, typeof(CellRenderer), true, false) != null)
				{
					elements = cells;
					intPtr = new List(elements, typeof(CellRenderer), true, false).Handle;
				}
				else
				{
					intPtr = IntPtr.Zero;
				}
				result = intPtr;
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060005F1 RID: 1521 RVA: 0x00010B08 File Offset: 0x0000ED08
		private static IntPtr GetArea_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				CellArea area = (Object.GetObject(inst, false) as ICellLayoutImplementor).Area;
				result = ((area == null) ? IntPtr.Zero : area.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060005F2 RID: 1522 RVA: 0x00010B54 File Offset: 0x0000ED54
		private static void Initialize(IntPtr ptr, IntPtr data)
		{
			IntPtr ptr2 = new IntPtr(ptr.ToInt64() + (long)CellLayoutAdapter.class_offset);
			CellLayoutAdapter.GtkCellLayoutIface structure = (CellLayoutAdapter.GtkCellLayoutIface)Marshal.PtrToStructure(ptr2, typeof(CellLayoutAdapter.GtkCellLayoutIface));
			structure.PackStart = CellLayoutAdapter.iface.PackStart;
			structure.PackEnd = CellLayoutAdapter.iface.PackEnd;
			structure.Clear = CellLayoutAdapter.iface.Clear;
			structure.AddAttribute = CellLayoutAdapter.iface.AddAttribute;
			structure.SetCellDataFunc = CellLayoutAdapter.iface.SetCellDataFunc;
			structure.ClearAttributes = CellLayoutAdapter.iface.ClearAttributes;
			structure.Reorder = CellLayoutAdapter.iface.Reorder;
			structure.GetCells = CellLayoutAdapter.iface.GetCells;
			structure.GetArea = CellLayoutAdapter.iface.GetArea;
			Marshal.StructureToPtr<CellLayoutAdapter.GtkCellLayoutIface>(structure, ptr2, false);
		}

		// Token: 0x060005F3 RID: 1523 RVA: 0x00010C2D File Offset: 0x0000EE2D
		public CellLayoutAdapter()
		{
			base.InitHandler = new GInterfaceInitHandler(CellLayoutAdapter.Initialize);
		}

		// Token: 0x060005F4 RID: 1524 RVA: 0x00010C47 File Offset: 0x0000EE47
		public CellLayoutAdapter(ICellLayoutImplementor implementor)
		{
			if (implementor == null)
			{
				throw new ArgumentNullException("implementor");
			}
			if (!(implementor is Object))
			{
				throw new ArgumentException("implementor must be a subclass of GLib.Object");
			}
			this.implementor = (implementor as Object);
		}

		// Token: 0x060005F5 RID: 1525 RVA: 0x00010C7C File Offset: 0x0000EE7C
		public CellLayoutAdapter(IntPtr handle)
		{
			if (!CellLayoutAdapter._gtype.IsInstance(handle))
			{
				throw new ArgumentException("The gobject doesn't implement the GInterface of this adapter", "handle");
			}
			this.implementor = Object.GetObject(handle);
		}

		// Token: 0x170000DD RID: 221
		// (get) Token: 0x060005F6 RID: 1526 RVA: 0x00010CAD File Offset: 0x0000EEAD
		public static GType GType
		{
			get
			{
				return CellLayoutAdapter._gtype;
			}
		}

		// Token: 0x170000DE RID: 222
		// (get) Token: 0x060005F7 RID: 1527 RVA: 0x00010CB4 File Offset: 0x0000EEB4
		public override GType GInterfaceGType
		{
			get
			{
				return CellLayoutAdapter._gtype;
			}
		}

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x060005F8 RID: 1528 RVA: 0x00010CBB File Offset: 0x0000EEBB
		public override IntPtr Handle
		{
			get
			{
				return this.implementor.Handle;
			}
		}

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x060005F9 RID: 1529 RVA: 0x00010CC8 File Offset: 0x0000EEC8
		public IntPtr OwnedHandle
		{
			get
			{
				return this.implementor.OwnedHandle;
			}
		}

		// Token: 0x060005FA RID: 1530 RVA: 0x00010CD5 File Offset: 0x0000EED5
		public static ICellLayout GetObject(IntPtr handle, bool owned)
		{
			return CellLayoutAdapter.GetObject(Object.GetObject(handle, owned));
		}

		// Token: 0x060005FB RID: 1531 RVA: 0x00010CE3 File Offset: 0x0000EEE3
		public static ICellLayout GetObject(Object obj)
		{
			if (obj == null)
			{
				return null;
			}
			if (obj is ICellLayoutImplementor)
			{
				return new CellLayoutAdapter(obj as ICellLayoutImplementor);
			}
			if (!(obj is ICellLayout))
			{
				return new CellLayoutAdapter(obj.Handle);
			}
			return obj as ICellLayout;
		}

		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x060005FC RID: 1532 RVA: 0x00010D18 File Offset: 0x0000EF18
		public ICellLayoutImplementor Implementor
		{
			get
			{
				return this.implementor as ICellLayoutImplementor;
			}
		}

		// Token: 0x060005FD RID: 1533 RVA: 0x00010D28 File Offset: 0x0000EF28
		public void AddAttribute(CellRenderer cell, string attribute, int column)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(attribute);
			CellLayoutAdapter.gtk_cell_layout_add_attribute(this.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, intPtr, column);
			Marshaller.Free(intPtr);
		}

		// Token: 0x060005FE RID: 1534 RVA: 0x00010D64 File Offset: 0x0000EF64
		public void Clear()
		{
			CellLayoutAdapter.gtk_cell_layout_clear(this.Handle);
		}

		// Token: 0x060005FF RID: 1535 RVA: 0x00010D76 File Offset: 0x0000EF76
		public void ClearAttributes(CellRenderer cell)
		{
			CellLayoutAdapter.gtk_cell_layout_clear_attributes(this.Handle, (cell == null) ? IntPtr.Zero : cell.Handle);
		}

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x06000600 RID: 1536 RVA: 0x00010D98 File Offset: 0x0000EF98
		public CellArea Area
		{
			get
			{
				return Object.GetObject(CellLayoutAdapter.gtk_cell_layout_get_area(this.Handle)) as CellArea;
			}
		}

		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x06000601 RID: 1537 RVA: 0x00010DB4 File Offset: 0x0000EFB4
		public CellRenderer[] Cells
		{
			get
			{
				return (CellRenderer[])Marshaller.ListPtrToArray(CellLayoutAdapter.gtk_cell_layout_get_cells(this.Handle), typeof(List), true, false, typeof(CellRenderer));
			}
		}

		// Token: 0x06000602 RID: 1538 RVA: 0x00010DE6 File Offset: 0x0000EFE6
		public void PackEnd(CellRenderer cell, bool expand)
		{
			CellLayoutAdapter.gtk_cell_layout_pack_end(this.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, expand);
		}

		// Token: 0x06000603 RID: 1539 RVA: 0x00010E09 File Offset: 0x0000F009
		public void PackStart(CellRenderer cell, bool expand)
		{
			CellLayoutAdapter.gtk_cell_layout_pack_start(this.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, expand);
		}

		// Token: 0x06000604 RID: 1540 RVA: 0x00010E2C File Offset: 0x0000F02C
		public void Reorder(CellRenderer cell, int position)
		{
			CellLayoutAdapter.gtk_cell_layout_reorder(this.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, position);
		}

		// Token: 0x06000605 RID: 1541 RVA: 0x00010E50 File Offset: 0x0000F050
		public void SetCellDataFunc(CellRenderer cell, CellLayoutDataFunc func)
		{
			CellLayoutDataFuncWrapper cellLayoutDataFuncWrapper = new CellLayoutDataFuncWrapper(func);
			IntPtr func_data;
			DestroyNotify destroy;
			if (func == null)
			{
				func_data = IntPtr.Zero;
				destroy = null;
			}
			else
			{
				func_data = (IntPtr)GCHandle.Alloc(cellLayoutDataFuncWrapper);
				destroy = DestroyHelper.NotifyHandler;
			}
			CellLayoutAdapter.gtk_cell_layout_set_cell_data_func(this.Handle, (cell == null) ? IntPtr.Zero : cell.Handle, cellLayoutDataFuncWrapper.NativeDelegate, func_data, destroy);
		}

		// Token: 0x040002FE RID: 766
		private static CellLayoutAdapter.GtkCellLayoutIface iface;

		// Token: 0x040002FF RID: 767
		private static int class_offset = 2 * IntPtr.Size;

		// Token: 0x04000300 RID: 768
		private Object implementor;

		// Token: 0x04000301 RID: 769
		private static CellLayoutAdapter.d_gtk_cell_layout_get_type gtk_cell_layout_get_type = FuncLoader.LoadFunction<CellLayoutAdapter.d_gtk_cell_layout_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_get_type"));

		// Token: 0x04000302 RID: 770
		private static GType _gtype = new GType(CellLayoutAdapter.gtk_cell_layout_get_type());

		// Token: 0x04000303 RID: 771
		private static CellLayoutAdapter.d_gtk_cell_layout_add_attribute gtk_cell_layout_add_attribute = FuncLoader.LoadFunction<CellLayoutAdapter.d_gtk_cell_layout_add_attribute>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_add_attribute"));

		// Token: 0x04000304 RID: 772
		private static CellLayoutAdapter.d_gtk_cell_layout_clear gtk_cell_layout_clear = FuncLoader.LoadFunction<CellLayoutAdapter.d_gtk_cell_layout_clear>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_clear"));

		// Token: 0x04000305 RID: 773
		private static CellLayoutAdapter.d_gtk_cell_layout_clear_attributes gtk_cell_layout_clear_attributes = FuncLoader.LoadFunction<CellLayoutAdapter.d_gtk_cell_layout_clear_attributes>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_clear_attributes"));

		// Token: 0x04000306 RID: 774
		private static CellLayoutAdapter.d_gtk_cell_layout_get_area gtk_cell_layout_get_area = FuncLoader.LoadFunction<CellLayoutAdapter.d_gtk_cell_layout_get_area>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_get_area"));

		// Token: 0x04000307 RID: 775
		private static CellLayoutAdapter.d_gtk_cell_layout_get_cells gtk_cell_layout_get_cells = FuncLoader.LoadFunction<CellLayoutAdapter.d_gtk_cell_layout_get_cells>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_get_cells"));

		// Token: 0x04000308 RID: 776
		private static CellLayoutAdapter.d_gtk_cell_layout_pack_end gtk_cell_layout_pack_end = FuncLoader.LoadFunction<CellLayoutAdapter.d_gtk_cell_layout_pack_end>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_pack_end"));

		// Token: 0x04000309 RID: 777
		private static CellLayoutAdapter.d_gtk_cell_layout_pack_start gtk_cell_layout_pack_start = FuncLoader.LoadFunction<CellLayoutAdapter.d_gtk_cell_layout_pack_start>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_pack_start"));

		// Token: 0x0400030A RID: 778
		private static CellLayoutAdapter.d_gtk_cell_layout_reorder gtk_cell_layout_reorder = FuncLoader.LoadFunction<CellLayoutAdapter.d_gtk_cell_layout_reorder>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_reorder"));

		// Token: 0x0400030B RID: 779
		private static CellLayoutAdapter.d_gtk_cell_layout_set_cell_data_func gtk_cell_layout_set_cell_data_func = FuncLoader.LoadFunction<CellLayoutAdapter.d_gtk_cell_layout_set_cell_data_func>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_cell_layout_set_cell_data_func"));

		// Token: 0x02000732 RID: 1842
		private struct GtkCellLayoutIface
		{
			// Token: 0x04001E40 RID: 7744
			public CellLayoutAdapter.PackStartNativeDelegate PackStart;

			// Token: 0x04001E41 RID: 7745
			public CellLayoutAdapter.PackEndNativeDelegate PackEnd;

			// Token: 0x04001E42 RID: 7746
			public CellLayoutAdapter.ClearNativeDelegate Clear;

			// Token: 0x04001E43 RID: 7747
			public CellLayoutAdapter.AddAttributeNativeDelegate AddAttribute;

			// Token: 0x04001E44 RID: 7748
			public CellLayoutAdapter.SetCellDataFuncNativeDelegate SetCellDataFunc;

			// Token: 0x04001E45 RID: 7749
			public CellLayoutAdapter.ClearAttributesNativeDelegate ClearAttributes;

			// Token: 0x04001E46 RID: 7750
			public CellLayoutAdapter.ReorderNativeDelegate Reorder;

			// Token: 0x04001E47 RID: 7751
			public CellLayoutAdapter.GetCellsNativeDelegate GetCells;

			// Token: 0x04001E48 RID: 7752
			public CellLayoutAdapter.GetAreaNativeDelegate GetArea;
		}

		// Token: 0x02000733 RID: 1843
		// (Invoke) Token: 0x060043EC RID: 17388
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void PackStartNativeDelegate(IntPtr inst, IntPtr cell, bool expand);

		// Token: 0x02000734 RID: 1844
		// (Invoke) Token: 0x060043F0 RID: 17392
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void PackEndNativeDelegate(IntPtr inst, IntPtr cell, bool expand);

		// Token: 0x02000735 RID: 1845
		// (Invoke) Token: 0x060043F4 RID: 17396
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ClearNativeDelegate(IntPtr inst);

		// Token: 0x02000736 RID: 1846
		// (Invoke) Token: 0x060043F8 RID: 17400
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void AddAttributeNativeDelegate(IntPtr inst, IntPtr cell, IntPtr attribute, int column);

		// Token: 0x02000737 RID: 1847
		// (Invoke) Token: 0x060043FC RID: 17404
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void SetCellDataFuncNativeDelegate(IntPtr inst, IntPtr cell, CellLayoutDataFuncNative func, IntPtr func_data, DestroyNotify destroy);

		// Token: 0x02000738 RID: 1848
		// (Invoke) Token: 0x06004400 RID: 17408
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ClearAttributesNativeDelegate(IntPtr inst, IntPtr cell);

		// Token: 0x02000739 RID: 1849
		// (Invoke) Token: 0x06004404 RID: 17412
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ReorderNativeDelegate(IntPtr inst, IntPtr cell, int position);

		// Token: 0x0200073A RID: 1850
		// (Invoke) Token: 0x06004408 RID: 17416
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetCellsNativeDelegate(IntPtr inst);

		// Token: 0x0200073B RID: 1851
		// (Invoke) Token: 0x0600440C RID: 17420
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetAreaNativeDelegate(IntPtr inst);

		// Token: 0x0200073C RID: 1852
		// (Invoke) Token: 0x06004410 RID: 17424
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_layout_get_type();

		// Token: 0x0200073D RID: 1853
		// (Invoke) Token: 0x06004414 RID: 17428
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_add_attribute(IntPtr raw, IntPtr cell, IntPtr attribute, int column);

		// Token: 0x0200073E RID: 1854
		// (Invoke) Token: 0x06004418 RID: 17432
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_clear(IntPtr raw);

		// Token: 0x0200073F RID: 1855
		// (Invoke) Token: 0x0600441C RID: 17436
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_clear_attributes(IntPtr raw, IntPtr cell);

		// Token: 0x02000740 RID: 1856
		// (Invoke) Token: 0x06004420 RID: 17440
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_layout_get_area(IntPtr raw);

		// Token: 0x02000741 RID: 1857
		// (Invoke) Token: 0x06004424 RID: 17444
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_cell_layout_get_cells(IntPtr raw);

		// Token: 0x02000742 RID: 1858
		// (Invoke) Token: 0x06004428 RID: 17448
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_pack_end(IntPtr raw, IntPtr cell, bool expand);

		// Token: 0x02000743 RID: 1859
		// (Invoke) Token: 0x0600442C RID: 17452
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_pack_start(IntPtr raw, IntPtr cell, bool expand);

		// Token: 0x02000744 RID: 1860
		// (Invoke) Token: 0x06004430 RID: 17456
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_reorder(IntPtr raw, IntPtr cell, int position);

		// Token: 0x02000745 RID: 1861
		// (Invoke) Token: 0x06004434 RID: 17460
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_cell_layout_set_cell_data_func(IntPtr raw, IntPtr cell, CellLayoutDataFuncNative func, IntPtr func_data, DestroyNotify destroy);
	}
}
