﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x020000F5 RID: 245
	public class AccelClearedArgs : SignalArgs
	{
		// Token: 0x17000248 RID: 584
		// (get) Token: 0x06000B14 RID: 2836 RVA: 0x000218E1 File Offset: 0x0001FAE1
		public string PathString
		{
			get
			{
				return (string)base.Args[0];
			}
		}
	}
}
