﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x0200013F RID: 319
	public class Bitmask : Opaque
	{
		// Token: 0x06000DDC RID: 3548 RVA: 0x00029DEF File Offset: 0x00027FEF
		public Bitmask(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170002FE RID: 766
		// (get) Token: 0x06000DDD RID: 3549 RVA: 0x00029DF8 File Offset: 0x00027FF8
		public static AbiStruct abi_info
		{
			get
			{
				if (Bitmask._abi_info == null)
				{
					Bitmask._abi_info = new AbiStruct(new List<AbiField>());
				}
				return Bitmask._abi_info;
			}
		}

		// Token: 0x040006C2 RID: 1730
		private static AbiStruct _abi_info;
	}
}
