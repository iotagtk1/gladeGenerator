﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x0200020A RID: 522
	public class CssValueClass : Opaque
	{
		// Token: 0x0600122E RID: 4654 RVA: 0x0003503D File Offset: 0x0003323D
		public CssValueClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000465 RID: 1125
		// (get) Token: 0x0600122F RID: 4655 RVA: 0x00035046 File Offset: 0x00033246
		public static AbiStruct abi_info
		{
			get
			{
				if (CssValueClass._abi_info == null)
				{
					CssValueClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssValueClass._abi_info;
			}
		}

		// Token: 0x04000890 RID: 2192
		private static AbiStruct _abi_info;
	}
}
