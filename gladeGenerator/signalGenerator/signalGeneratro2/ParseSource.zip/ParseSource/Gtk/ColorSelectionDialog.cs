﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x020001A5 RID: 421
	public class ColorSelectionDialog : Dialog
	{
		// Token: 0x0600112F RID: 4399 RVA: 0x0003375E File Offset: 0x0003195E
		public ColorSelectionDialog(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06001130 RID: 4400 RVA: 0x00033768 File Offset: 0x00031968
		public ColorSelectionDialog(string title) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(ColorSelectionDialog))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				list2.Add("title");
				list.Add(new Value(title));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(title);
			this.Raw = ColorSelectionDialog.gtk_color_selection_dialog_new(intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x170003FA RID: 1018
		// (get) Token: 0x06001131 RID: 4401 RVA: 0x000337EB File Offset: 0x000319EB
		[Obsolete]
		[Property("color-selection")]
		public ColorSelection ColorSelection
		{
			get
			{
				return Object.GetObject(ColorSelectionDialog.gtk_color_selection_dialog_get_color_selection(base.Handle)) as ColorSelection;
			}
		}

		// Token: 0x170003FB RID: 1019
		// (get) Token: 0x06001132 RID: 4402 RVA: 0x00033808 File Offset: 0x00031A08
		[Property("ok-button")]
		public Button OkButton
		{
			get
			{
				Value property = base.GetProperty("ok-button");
				Button result = (Button)((Object)property);
				property.Dispose();
				return result;
			}
		}

		// Token: 0x170003FC RID: 1020
		// (get) Token: 0x06001133 RID: 4403 RVA: 0x00033834 File Offset: 0x00031A34
		[Property("cancel-button")]
		public Button CancelButton
		{
			get
			{
				Value property = base.GetProperty("cancel-button");
				Button result = (Button)((Object)property);
				property.Dispose();
				return result;
			}
		}

		// Token: 0x170003FD RID: 1021
		// (get) Token: 0x06001134 RID: 4404 RVA: 0x00033860 File Offset: 0x00031A60
		[Property("help-button")]
		public Button HelpButton
		{
			get
			{
				Value property = base.GetProperty("help-button");
				Button result = (Button)((Object)property);
				property.Dispose();
				return result;
			}
		}

		// Token: 0x170003FE RID: 1022
		// (get) Token: 0x06001135 RID: 4405 RVA: 0x0003388C File Offset: 0x00031A8C
		public new static AbiStruct class_abi
		{
			get
			{
				if (ColorSelectionDialog._class_abi == null)
				{
					ColorSelectionDialog._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("_gtk_reserved1", Dialog.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return ColorSelectionDialog._class_abi;
			}
		}

		// Token: 0x170003FF RID: 1023
		// (get) Token: 0x06001136 RID: 4406 RVA: 0x000339A8 File Offset: 0x00031BA8
		[Obsolete]
		public new static GType GType
		{
			get
			{
				IntPtr val = ColorSelectionDialog.gtk_color_selection_dialog_get_type();
				return new GType(val);
			}
		}

		// Token: 0x17000400 RID: 1024
		// (get) Token: 0x06001137 RID: 4407 RVA: 0x000339C8 File Offset: 0x00031BC8
		public new static AbiStruct abi_info
		{
			get
			{
				if (ColorSelectionDialog._abi_info == null)
				{
					ColorSelectionDialog._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Dialog.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return ColorSelectionDialog._abi_info;
			}
		}

		// Token: 0x0400080D RID: 2061
		private static ColorSelectionDialog.d_gtk_color_selection_dialog_new gtk_color_selection_dialog_new = FuncLoader.LoadFunction<ColorSelectionDialog.d_gtk_color_selection_dialog_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_selection_dialog_new"));

		// Token: 0x0400080E RID: 2062
		private static ColorSelectionDialog.d_gtk_color_selection_dialog_get_color_selection gtk_color_selection_dialog_get_color_selection = FuncLoader.LoadFunction<ColorSelectionDialog.d_gtk_color_selection_dialog_get_color_selection>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_selection_dialog_get_color_selection"));

		// Token: 0x0400080F RID: 2063
		private static AbiStruct _class_abi = null;

		// Token: 0x04000810 RID: 2064
		private static ColorSelectionDialog.d_gtk_color_selection_dialog_get_type gtk_color_selection_dialog_get_type = FuncLoader.LoadFunction<ColorSelectionDialog.d_gtk_color_selection_dialog_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_selection_dialog_get_type"));

		// Token: 0x04000811 RID: 2065
		private static AbiStruct _abi_info = null;

		// Token: 0x02000B63 RID: 2915
		// (Invoke) Token: 0x06005495 RID: 21653
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_color_selection_dialog_new(IntPtr title);

		// Token: 0x02000B64 RID: 2916
		// (Invoke) Token: 0x06005499 RID: 21657
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_color_selection_dialog_get_color_selection(IntPtr raw);

		// Token: 0x02000B65 RID: 2917
		// (Invoke) Token: 0x0600549D RID: 21661
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_color_selection_dialog_get_type();
	}
}
