﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x02000200 RID: 512
	public class CssStyle : Opaque
	{
		// Token: 0x0600121A RID: 4634 RVA: 0x00034EC1 File Offset: 0x000330C1
		public CssStyle(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700045B RID: 1115
		// (get) Token: 0x0600121B RID: 4635 RVA: 0x00034ECA File Offset: 0x000330CA
		public static AbiStruct abi_info
		{
			get
			{
				if (CssStyle._abi_info == null)
				{
					CssStyle._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssStyle._abi_info;
			}
		}

		// Token: 0x04000886 RID: 2182
		private static AbiStruct _abi_info;
	}
}
