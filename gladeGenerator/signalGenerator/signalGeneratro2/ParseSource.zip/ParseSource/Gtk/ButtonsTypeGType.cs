﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x0200015B RID: 347
	internal class ButtonsTypeGType
	{
		// Token: 0x1700032A RID: 810
		// (get) Token: 0x06000E5A RID: 3674 RVA: 0x0002B053 File Offset: 0x00029253
		public static GType GType
		{
			get
			{
				return new GType(ButtonsTypeGType.gtk_buttons_type_get_type());
			}
		}

		// Token: 0x04000727 RID: 1831
		private static ButtonsTypeGType.d_gtk_buttons_type_get_type gtk_buttons_type_get_type = FuncLoader.LoadFunction<ButtonsTypeGType.d_gtk_buttons_type_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_buttons_type_get_type"));

		// Token: 0x02000ABE RID: 2750
		// (Invoke) Token: 0x06005209 RID: 21001
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_buttons_type_get_type();
	}
}
