﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001C8 RID: 456
	public class CssImageBuiltin : Opaque
	{
		// Token: 0x0600118B RID: 4491 RVA: 0x00033DD5 File Offset: 0x00031FD5
		public CssImageBuiltin(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000419 RID: 1049
		// (get) Token: 0x0600118C RID: 4492 RVA: 0x00033DDE File Offset: 0x00031FDE
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImageBuiltin._abi_info == null)
				{
					CssImageBuiltin._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImageBuiltin._abi_info;
			}
		}

		// Token: 0x04000828 RID: 2088
		private static AbiStruct _abi_info;
	}
}
