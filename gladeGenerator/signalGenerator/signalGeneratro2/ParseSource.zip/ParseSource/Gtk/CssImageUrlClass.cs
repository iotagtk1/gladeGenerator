﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001E0 RID: 480
	public class CssImageUrlClass : Opaque
	{
		// Token: 0x060011BB RID: 4539 RVA: 0x00034165 File Offset: 0x00032365
		public CssImageUrlClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000431 RID: 1073
		// (get) Token: 0x060011BC RID: 4540 RVA: 0x0003416E File Offset: 0x0003236E
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImageUrlClass._abi_info == null)
				{
					CssImageUrlClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImageUrlClass._abi_info;
			}
		}

		// Token: 0x04000840 RID: 2112
		private static AbiStruct _abi_info;
	}
}
