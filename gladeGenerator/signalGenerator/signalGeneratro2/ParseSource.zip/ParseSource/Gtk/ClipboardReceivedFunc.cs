﻿using System;

namespace Gtk
{
	// Token: 0x02000192 RID: 402
	// (Invoke) Token: 0x0600109F RID: 4255
	public delegate void ClipboardReceivedFunc(Clipboard clipboard, SelectionData selection_data);
}
