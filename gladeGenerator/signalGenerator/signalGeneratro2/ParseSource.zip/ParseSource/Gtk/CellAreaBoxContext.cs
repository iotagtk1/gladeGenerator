﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x02000168 RID: 360
	public class CellAreaBoxContext : Opaque
	{
		// Token: 0x06000F1E RID: 3870 RVA: 0x0002DC0B File Offset: 0x0002BE0B
		public CellAreaBoxContext(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700034A RID: 842
		// (get) Token: 0x06000F1F RID: 3871 RVA: 0x0002DC14 File Offset: 0x0002BE14
		public static AbiStruct abi_info
		{
			get
			{
				if (CellAreaBoxContext._abi_info == null)
				{
					CellAreaBoxContext._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CellAreaBoxContext._abi_info;
			}
		}

		// Token: 0x04000771 RID: 1905
		private static AbiStruct _abi_info;
	}
}
