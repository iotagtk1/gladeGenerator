﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001C1 RID: 449
	public class CssCustomGadget : Opaque
	{
		// Token: 0x0600117D RID: 4477 RVA: 0x00033CCB File Offset: 0x00031ECB
		public CssCustomGadget(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000412 RID: 1042
		// (get) Token: 0x0600117E RID: 4478 RVA: 0x00033CD4 File Offset: 0x00031ED4
		public static AbiStruct abi_info
		{
			get
			{
				if (CssCustomGadget._abi_info == null)
				{
					CssCustomGadget._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssCustomGadget._abi_info;
			}
		}

		// Token: 0x04000821 RID: 2081
		private static AbiStruct _abi_info;
	}
}
