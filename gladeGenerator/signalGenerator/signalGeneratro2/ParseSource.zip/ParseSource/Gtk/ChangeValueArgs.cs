﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000182 RID: 386
	public class ChangeValueArgs : SignalArgs
	{
		// Token: 0x170003C3 RID: 963
		// (get) Token: 0x0600105F RID: 4191 RVA: 0x00031837 File Offset: 0x0002FA37
		public ScrollType Scroll
		{
			get
			{
				return (ScrollType)base.Args[0];
			}
		}
	}
}
