﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Cairo;
using GLib;
using GtkSharp;

namespace Gtk
{
	// Token: 0x020000E5 RID: 229
	public class Container : Widget, IEnumerable
	{
		// Token: 0x060007AA RID: 1962 RVA: 0x00017128 File Offset: 0x00015328
		public Value ChildGetProperty(Widget child, string property_name)
		{
			Value result = default(Value);
			IntPtr gtypeClass = ((Container.GTypeInstance)Marshal.PtrToStructure(base.Handle, typeof(Container.GTypeInstance))).GTypeClass;
			Container.GParamSpec gparamSpec = (Container.GParamSpec)Marshal.PtrToStructure(Container.gtk_container_class_find_child_property(gtypeClass, property_name), typeof(Container.GParamSpec));
			result.Init(gparamSpec.value_type);
			Container.gtk_container_child_get_property(base.Handle, child.Handle, property_name, ref result);
			return result;
		}

		// Token: 0x060007AB RID: 1963 RVA: 0x000171A5 File Offset: 0x000153A5
		public IEnumerator GetEnumerator()
		{
			return this.Children.GetEnumerator();
		}

		// Token: 0x17000158 RID: 344
		// (get) Token: 0x060007AC RID: 1964 RVA: 0x000171B4 File Offset: 0x000153B4
		public IEnumerable AllChildren
		{
			get
			{
				Container.ChildAccumulator childAccumulator = new Container.ChildAccumulator();
				this.Forall(new Callback(childAccumulator.Add));
				return childAccumulator.Children;
			}
		}

		// Token: 0x17000159 RID: 345
		// (get) Token: 0x060007AD RID: 1965 RVA: 0x000171E0 File Offset: 0x000153E0
		// (set) Token: 0x060007AE RID: 1966 RVA: 0x0001723C File Offset: 0x0001543C
		public Widget[] FocusChain
		{
			get
			{
				IntPtr raw;
				if (!Container.gtk_container_get_focus_chain(base.Handle, out raw))
				{
					return new Widget[0];
				}
				List list = new List(raw);
				Widget[] array = new Widget[list.Count];
				for (int i = 0; i < list.Count; i++)
				{
					array[i] = (list[i] as Widget);
				}
				return array;
			}
			set
			{
				List list = new List(IntPtr.Zero);
				for (int i = 0; i < value.Length; i++)
				{
					Widget widget = value[i];
					list.Append(widget.Handle);
				}
				Container.gtk_container_set_focus_chain(base.Handle, list.Handle);
			}
		}

		// Token: 0x060007AF RID: 1967 RVA: 0x0001728C File Offset: 0x0001548C
		private static IntPtr ObsoleteChildType_cb(IntPtr raw)
		{
			try
			{
				return (Object.GetObject(raw, false) as Container).ChildType().Val;
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
			return GType.Invalid.Val;
		}

		// Token: 0x060007B0 RID: 1968 RVA: 0x000172DC File Offset: 0x000154DC
		private static void OverrideObsoleteChildType(GType gtype)
		{
			if (Container.ObsoleteChildTypeVMCallback == null)
			{
				Container.ObsoleteChildTypeVMCallback = new Container.ChildTypeNativeDelegate(Container.ObsoleteChildType_cb);
			}
			Container.OverrideChildType(gtype, Container.ObsoleteChildTypeVMCallback);
		}

		// Token: 0x060007B1 RID: 1969 RVA: 0x00017301 File Offset: 0x00015501
		[Obsolete("Replaced by OnChildType for implementations and SupportedChildType for callers.")]
		[DefaultSignalHandler(Type = typeof(Container), ConnectionMethod = "OverrideObsoleteChildType")]
		public virtual GType ChildType()
		{
			return this.InternalChildType();
		}

		// Token: 0x1700015A RID: 346
		public virtual Container.ContainerChild this[Widget w]
		{
			get
			{
				return new Container.ContainerChild(this, w);
			}
		}

		// Token: 0x060007B3 RID: 1971 RVA: 0x00017314 File Offset: 0x00015514
		internal static D TryGetDelegate<D>(IntPtr _cb)
		{
			D result;
			try
			{
				result = Marshal.GetDelegateForFunctionPointer<D>(_cb);
			}
			catch
			{
				result = default(D);
			}
			return result;
		}

		// Token: 0x1700015B RID: 347
		// (get) Token: 0x060007B4 RID: 1972 RVA: 0x00017348 File Offset: 0x00015548
		private static Container.ForAllNativeDelegate ForAllVMCallback
		{
			get
			{
				if (Container.ForAll_cb_delegate == null)
				{
					Container.ForAll_cb_delegate = new Container.ForAllNativeDelegate(Container.ForAll_cb);
				}
				return Container.ForAll_cb_delegate;
			}
		}

		// Token: 0x060007B5 RID: 1973 RVA: 0x00017367 File Offset: 0x00015567
		private static void OverrideForAll(GType gtype)
		{
			Container.OverrideForAll(gtype, Container.ForAllVMCallback);
		}

		// Token: 0x060007B6 RID: 1974 RVA: 0x00017374 File Offset: 0x00015574
		private unsafe static void OverrideForAll(GType gtype, Container.ForAllNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Container.class_abi.GetFieldOffset("forall");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060007B7 RID: 1975 RVA: 0x000173A8 File Offset: 0x000155A8
		private static void ForAll_cb(IntPtr inst, bool include_internals, IntPtr cb, IntPtr data)
		{
			try
			{
				Container.ForAllCallbackHandler @object = new Container.ForAllCallbackHandler(cb, data, include_internals);
				Container container = Object.TryGetObject(inst) as Container;
				if (container != null)
				{
					container.ForAll(include_internals, new Callback(@object.Invoke));
				}
				else
				{
					Container.gtksharp_container_base_forall(inst, include_internals, new Callback(@object.Invoke), data);
				}
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060007B8 RID: 1976 RVA: 0x00017410 File Offset: 0x00015610
		[DefaultSignalHandler(Type = typeof(Container), ConnectionMethod = "OverrideForAll")]
		protected virtual void ForAll(bool include_internals, Callback callback)
		{
			this.InternalForAll(include_internals, callback);
		}

		// Token: 0x060007B9 RID: 1977 RVA: 0x0001741A File Offset: 0x0001561A
		private void InternalForAll(bool include_internals, Callback callback)
		{
			if (!(callback.Target is Container.ForAllCallbackHandler))
			{
				throw new ApplicationException("ForAll can only be called as \"base.ForAll()\". Use Forall() or Foreach().");
			}
			Container.gtksharp_container_base_forall(base.Handle, include_internals, callback, ((Container.ForAllCallbackHandler)callback.Target).data);
		}

		// Token: 0x060007BA RID: 1978 RVA: 0x00017454 File Offset: 0x00015654
		private unsafe static Container.ForAllNativeDelegate InternalForAllNativeDelegate(GType gtype)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Container.class_abi.GetFieldOffset("forall");
			if (*ptr == IntPtr.Zero)
			{
				return null;
			}
			return Marshal.GetDelegateForFunctionPointer<Container.ForAllNativeDelegate>(*ptr);
		}

		// Token: 0x060007BB RID: 1979 RVA: 0x00017498 File Offset: 0x00015698
		private static void gtksharp_container_base_forall(IntPtr container, bool include_internals, Callback cb, IntPtr data)
		{
			if (container == IntPtr.Zero)
			{
				return;
			}
			Object @object = Object.TryGetObject(container);
			if (@object == null)
			{
				return;
			}
			GType gtype = @object.NativeType;
			while ((gtype = gtype.GetBaseType()) != GType.None)
			{
				if (!gtype.ToString().StartsWith("__gtksharp_"))
				{
					Container.ForAllNativeDelegate forAllNativeDelegate = Container.InternalForAllNativeDelegate(gtype);
					if (forAllNativeDelegate != null)
					{
						Container.ForAllCallbackHandler forAllCallbackHandler = cb.Target as Container.ForAllCallbackHandler;
						if (forAllCallbackHandler != null)
						{
							new CallbackWrapper(cb);
							forAllNativeDelegate(container, include_internals, forAllCallbackHandler.cb, data);
						}
					}
					return;
				}
			}
		}

		// Token: 0x060007BC RID: 1980 RVA: 0x00017525 File Offset: 0x00015725
		public Container(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x060007BD RID: 1981 RVA: 0x0001752E File Offset: 0x0001572E
		protected Container() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x1700015C RID: 348
		// (get) Token: 0x060007BE RID: 1982 RVA: 0x0001754D File Offset: 0x0001574D
		// (set) Token: 0x060007BF RID: 1983 RVA: 0x0001755F File Offset: 0x0001575F
		[Obsolete]
		[Property("resize-mode")]
		public ResizeMode ResizeMode
		{
			get
			{
				return (ResizeMode)Container.gtk_container_get_resize_mode(base.Handle);
			}
			set
			{
				Container.gtk_container_set_resize_mode(base.Handle, (int)value);
			}
		}

		// Token: 0x1700015D RID: 349
		// (get) Token: 0x060007C0 RID: 1984 RVA: 0x00017572 File Offset: 0x00015772
		// (set) Token: 0x060007C1 RID: 1985 RVA: 0x00017584 File Offset: 0x00015784
		[Property("border-width")]
		public uint BorderWidth
		{
			get
			{
				return Container.gtk_container_get_border_width(base.Handle);
			}
			set
			{
				Container.gtk_container_set_border_width(base.Handle, value);
			}
		}

		// Token: 0x1700015E RID: 350
		// (set) Token: 0x060007C2 RID: 1986 RVA: 0x00017598 File Offset: 0x00015798
		[Property("child")]
		public Widget Child
		{
			set
			{
				Value val = new Value(value);
				base.SetProperty("child", val);
				val.Dispose();
			}
		}

		// Token: 0x14000023 RID: 35
		// (add) Token: 0x060007C3 RID: 1987 RVA: 0x000175C0 File Offset: 0x000157C0
		// (remove) Token: 0x060007C4 RID: 1988 RVA: 0x000175D8 File Offset: 0x000157D8
		[Signal("set-focus-child")]
		public event FocusChildSetHandler FocusChildSet
		{
			add
			{
				base.AddSignalHandler("set-focus-child", value, typeof(FocusChildSetArgs));
			}
			remove
			{
				base.RemoveSignalHandler("set-focus-child", value);
			}
		}

		// Token: 0x14000024 RID: 36
		// (add) Token: 0x060007C5 RID: 1989 RVA: 0x000175E6 File Offset: 0x000157E6
		// (remove) Token: 0x060007C6 RID: 1990 RVA: 0x000175F4 File Offset: 0x000157F4
		[Signal("check-resize")]
		public event EventHandler ResizeChecked
		{
			add
			{
				base.AddSignalHandler("check-resize", value);
			}
			remove
			{
				base.RemoveSignalHandler("check-resize", value);
			}
		}

		// Token: 0x14000025 RID: 37
		// (add) Token: 0x060007C7 RID: 1991 RVA: 0x00017602 File Offset: 0x00015802
		// (remove) Token: 0x060007C8 RID: 1992 RVA: 0x0001761A File Offset: 0x0001581A
		[Signal("remove")]
		public event RemovedHandler Removed
		{
			add
			{
				base.AddSignalHandler("remove", value, typeof(RemovedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("remove", value);
			}
		}

		// Token: 0x14000026 RID: 38
		// (add) Token: 0x060007C9 RID: 1993 RVA: 0x00017628 File Offset: 0x00015828
		// (remove) Token: 0x060007CA RID: 1994 RVA: 0x00017640 File Offset: 0x00015840
		[Signal("add")]
		public event AddedHandler Added
		{
			add
			{
				base.AddSignalHandler("add", value, typeof(AddedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("add", value);
			}
		}

		// Token: 0x1700015F RID: 351
		// (get) Token: 0x060007CB RID: 1995 RVA: 0x0001764E File Offset: 0x0001584E
		private static Container.AddedNativeDelegate AddedVMCallback
		{
			get
			{
				if (Container.Added_cb_delegate == null)
				{
					Container.Added_cb_delegate = new Container.AddedNativeDelegate(Container.Added_cb);
				}
				return Container.Added_cb_delegate;
			}
		}

		// Token: 0x060007CC RID: 1996 RVA: 0x0001766D File Offset: 0x0001586D
		private static void OverrideAdded(GType gtype)
		{
			Container.OverrideAdded(gtype, Container.AddedVMCallback);
		}

		// Token: 0x060007CD RID: 1997 RVA: 0x0001767C File Offset: 0x0001587C
		private unsafe static void OverrideAdded(GType gtype, Container.AddedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Container.class_abi.GetFieldOffset("add");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060007CE RID: 1998 RVA: 0x000176B0 File Offset: 0x000158B0
		private static void Added_cb(IntPtr inst, IntPtr widget)
		{
			try
			{
				(Object.GetObject(inst, false) as Container).OnAdded(Object.GetObject(widget) as Widget);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060007CF RID: 1999 RVA: 0x000176F4 File Offset: 0x000158F4
		[DefaultSignalHandler(Type = typeof(Container), ConnectionMethod = "OverrideAdded")]
		protected virtual void OnAdded(Widget widget)
		{
			this.InternalAdded(widget);
		}

		// Token: 0x060007D0 RID: 2000 RVA: 0x00017700 File Offset: 0x00015900
		private void InternalAdded(Widget widget)
		{
			Container.AddedNativeDelegate addedNativeDelegate = Container.class_abi.BaseOverride(base.LookupGType(), "add");
			if (addedNativeDelegate == null)
			{
				return;
			}
			addedNativeDelegate(base.Handle, (widget == null) ? IntPtr.Zero : widget.Handle);
		}

		// Token: 0x17000160 RID: 352
		// (get) Token: 0x060007D1 RID: 2001 RVA: 0x00017743 File Offset: 0x00015943
		private static Container.RemovedNativeDelegate RemovedVMCallback
		{
			get
			{
				if (Container.Removed_cb_delegate == null)
				{
					Container.Removed_cb_delegate = new Container.RemovedNativeDelegate(Container.Removed_cb);
				}
				return Container.Removed_cb_delegate;
			}
		}

		// Token: 0x060007D2 RID: 2002 RVA: 0x00017762 File Offset: 0x00015962
		private static void OverrideRemoved(GType gtype)
		{
			Container.OverrideRemoved(gtype, Container.RemovedVMCallback);
		}

		// Token: 0x060007D3 RID: 2003 RVA: 0x00017770 File Offset: 0x00015970
		private unsafe static void OverrideRemoved(GType gtype, Container.RemovedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Container.class_abi.GetFieldOffset("remove");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060007D4 RID: 2004 RVA: 0x000177A4 File Offset: 0x000159A4
		private static void Removed_cb(IntPtr inst, IntPtr widget)
		{
			try
			{
				(Object.GetObject(inst, false) as Container).OnRemoved(Object.GetObject(widget) as Widget);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060007D5 RID: 2005 RVA: 0x000177E8 File Offset: 0x000159E8
		[DefaultSignalHandler(Type = typeof(Container), ConnectionMethod = "OverrideRemoved")]
		protected virtual void OnRemoved(Widget widget)
		{
			this.InternalRemoved(widget);
		}

		// Token: 0x060007D6 RID: 2006 RVA: 0x000177F4 File Offset: 0x000159F4
		private void InternalRemoved(Widget widget)
		{
			Container.RemovedNativeDelegate removedNativeDelegate = Container.class_abi.BaseOverride(base.LookupGType(), "remove");
			if (removedNativeDelegate == null)
			{
				return;
			}
			removedNativeDelegate(base.Handle, (widget == null) ? IntPtr.Zero : widget.Handle);
		}

		// Token: 0x17000161 RID: 353
		// (get) Token: 0x060007D7 RID: 2007 RVA: 0x00017837 File Offset: 0x00015A37
		private static Container.ResizeCheckedNativeDelegate ResizeCheckedVMCallback
		{
			get
			{
				if (Container.ResizeChecked_cb_delegate == null)
				{
					Container.ResizeChecked_cb_delegate = new Container.ResizeCheckedNativeDelegate(Container.ResizeChecked_cb);
				}
				return Container.ResizeChecked_cb_delegate;
			}
		}

		// Token: 0x060007D8 RID: 2008 RVA: 0x00017856 File Offset: 0x00015A56
		private static void OverrideResizeChecked(GType gtype)
		{
			Container.OverrideResizeChecked(gtype, Container.ResizeCheckedVMCallback);
		}

		// Token: 0x060007D9 RID: 2009 RVA: 0x00017864 File Offset: 0x00015A64
		private unsafe static void OverrideResizeChecked(GType gtype, Container.ResizeCheckedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Container.class_abi.GetFieldOffset("check_resize");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060007DA RID: 2010 RVA: 0x00017898 File Offset: 0x00015A98
		private static void ResizeChecked_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Container).OnResizeChecked();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060007DB RID: 2011 RVA: 0x000178D0 File Offset: 0x00015AD0
		[DefaultSignalHandler(Type = typeof(Container), ConnectionMethod = "OverrideResizeChecked")]
		protected virtual void OnResizeChecked()
		{
			this.InternalResizeChecked();
		}

		// Token: 0x060007DC RID: 2012 RVA: 0x000178D8 File Offset: 0x00015AD8
		private void InternalResizeChecked()
		{
			Container.ResizeCheckedNativeDelegate resizeCheckedNativeDelegate = Container.class_abi.BaseOverride(base.LookupGType(), "check_resize");
			if (resizeCheckedNativeDelegate == null)
			{
				return;
			}
			resizeCheckedNativeDelegate(base.Handle);
		}

		// Token: 0x17000162 RID: 354
		// (get) Token: 0x060007DD RID: 2013 RVA: 0x0001790B File Offset: 0x00015B0B
		private static Container.FocusChildSetNativeDelegate FocusChildSetVMCallback
		{
			get
			{
				if (Container.FocusChildSet_cb_delegate == null)
				{
					Container.FocusChildSet_cb_delegate = new Container.FocusChildSetNativeDelegate(Container.FocusChildSet_cb);
				}
				return Container.FocusChildSet_cb_delegate;
			}
		}

		// Token: 0x060007DE RID: 2014 RVA: 0x0001792A File Offset: 0x00015B2A
		private static void OverrideFocusChildSet(GType gtype)
		{
			Container.OverrideFocusChildSet(gtype, Container.FocusChildSetVMCallback);
		}

		// Token: 0x060007DF RID: 2015 RVA: 0x00017938 File Offset: 0x00015B38
		private unsafe static void OverrideFocusChildSet(GType gtype, Container.FocusChildSetNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Container.class_abi.GetFieldOffset("set_focus_child");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060007E0 RID: 2016 RVA: 0x0001796C File Offset: 0x00015B6C
		private static void FocusChildSet_cb(IntPtr inst, IntPtr child)
		{
			try
			{
				(Object.GetObject(inst, false) as Container).OnFocusChildSet(Object.GetObject(child) as Widget);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060007E1 RID: 2017 RVA: 0x000179B0 File Offset: 0x00015BB0
		[DefaultSignalHandler(Type = typeof(Container), ConnectionMethod = "OverrideFocusChildSet")]
		protected virtual void OnFocusChildSet(Widget child)
		{
			this.InternalFocusChildSet(child);
		}

		// Token: 0x060007E2 RID: 2018 RVA: 0x000179BC File Offset: 0x00015BBC
		private void InternalFocusChildSet(Widget child)
		{
			Container.FocusChildSetNativeDelegate focusChildSetNativeDelegate = Container.class_abi.BaseOverride(base.LookupGType(), "set_focus_child");
			if (focusChildSetNativeDelegate == null)
			{
				return;
			}
			focusChildSetNativeDelegate(base.Handle, (child == null) ? IntPtr.Zero : child.Handle);
		}

		// Token: 0x17000163 RID: 355
		// (get) Token: 0x060007E3 RID: 2019 RVA: 0x000179FF File Offset: 0x00015BFF
		private static Container.ChildTypeNativeDelegate ChildTypeVMCallback
		{
			get
			{
				if (Container.ChildType_cb_delegate == null)
				{
					Container.ChildType_cb_delegate = new Container.ChildTypeNativeDelegate(Container.ChildType_cb);
				}
				return Container.ChildType_cb_delegate;
			}
		}

		// Token: 0x060007E4 RID: 2020 RVA: 0x00017A1E File Offset: 0x00015C1E
		private static void OverrideChildType(GType gtype)
		{
			Container.OverrideChildType(gtype, Container.ChildTypeVMCallback);
		}

		// Token: 0x060007E5 RID: 2021 RVA: 0x00017A2C File Offset: 0x00015C2C
		private unsafe static void OverrideChildType(GType gtype, Container.ChildTypeNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Container.class_abi.GetFieldOffset("child_type");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060007E6 RID: 2022 RVA: 0x00017A60 File Offset: 0x00015C60
		private static IntPtr ChildType_cb(IntPtr inst)
		{
			IntPtr val;
			try
			{
				val = (Object.GetObject(inst, false) as Container).OnChildType().Val;
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return val;
		}

		// Token: 0x060007E7 RID: 2023 RVA: 0x00017AA4 File Offset: 0x00015CA4
		[DefaultSignalHandler(Type = typeof(Container), ConnectionMethod = "OverrideChildType")]
		protected virtual GType OnChildType()
		{
			return this.InternalChildType();
		}

		// Token: 0x060007E8 RID: 2024 RVA: 0x00017AAC File Offset: 0x00015CAC
		private GType InternalChildType()
		{
			Container.ChildTypeNativeDelegate childTypeNativeDelegate = Container.class_abi.BaseOverride(base.LookupGType(), "child_type");
			if (childTypeNativeDelegate == null)
			{
				return GType.None;
			}
			return new GType(childTypeNativeDelegate(base.Handle));
		}

		// Token: 0x17000164 RID: 356
		// (get) Token: 0x060007E9 RID: 2025 RVA: 0x00017AE9 File Offset: 0x00015CE9
		private static Container.CompositeNameNativeDelegate CompositeNameVMCallback
		{
			get
			{
				if (Container.CompositeName_cb_delegate == null)
				{
					Container.CompositeName_cb_delegate = new Container.CompositeNameNativeDelegate(Container.CompositeName_cb);
				}
				return Container.CompositeName_cb_delegate;
			}
		}

		// Token: 0x060007EA RID: 2026 RVA: 0x00017B08 File Offset: 0x00015D08
		private static void OverrideCompositeName(GType gtype)
		{
			Container.OverrideCompositeName(gtype, Container.CompositeNameVMCallback);
		}

		// Token: 0x060007EB RID: 2027 RVA: 0x00017B18 File Offset: 0x00015D18
		private unsafe static void OverrideCompositeName(GType gtype, Container.CompositeNameNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Container.class_abi.GetFieldOffset("composite_name");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060007EC RID: 2028 RVA: 0x00017B4C File Offset: 0x00015D4C
		private static IntPtr CompositeName_cb(IntPtr inst, IntPtr child)
		{
			IntPtr result;
			try
			{
				result = Marshaller.StringToPtrGStrdup((Object.GetObject(inst, false) as Container).OnCompositeName(Object.GetObject(child) as Widget));
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060007ED RID: 2029 RVA: 0x00017B98 File Offset: 0x00015D98
		[DefaultSignalHandler(Type = typeof(Container), ConnectionMethod = "OverrideCompositeName")]
		protected virtual string OnCompositeName(Widget child)
		{
			return this.InternalCompositeName(child);
		}

		// Token: 0x060007EE RID: 2030 RVA: 0x00017BA4 File Offset: 0x00015DA4
		private string InternalCompositeName(Widget child)
		{
			Container.CompositeNameNativeDelegate compositeNameNativeDelegate = Container.class_abi.BaseOverride(base.LookupGType(), "composite_name");
			if (compositeNameNativeDelegate == null)
			{
				return null;
			}
			return Marshaller.PtrToStringGFree(compositeNameNativeDelegate(base.Handle, (child == null) ? IntPtr.Zero : child.Handle));
		}

		// Token: 0x17000165 RID: 357
		// (get) Token: 0x060007EF RID: 2031 RVA: 0x00017BED File Offset: 0x00015DED
		private static Container.SetChildPropertyNativeDelegate SetChildPropertyVMCallback
		{
			get
			{
				if (Container.SetChildProperty_cb_delegate == null)
				{
					Container.SetChildProperty_cb_delegate = new Container.SetChildPropertyNativeDelegate(Container.SetChildProperty_cb);
				}
				return Container.SetChildProperty_cb_delegate;
			}
		}

		// Token: 0x060007F0 RID: 2032 RVA: 0x00017C0C File Offset: 0x00015E0C
		private static void OverrideSetChildProperty(GType gtype)
		{
			Container.OverrideSetChildProperty(gtype, Container.SetChildPropertyVMCallback);
		}

		// Token: 0x060007F1 RID: 2033 RVA: 0x00017C1C File Offset: 0x00015E1C
		private unsafe static void OverrideSetChildProperty(GType gtype, Container.SetChildPropertyNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Container.class_abi.GetFieldOffset("set_child_property");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060007F2 RID: 2034 RVA: 0x00017C50 File Offset: 0x00015E50
		private static void SetChildProperty_cb(IntPtr inst, IntPtr child, uint property_id, IntPtr value, IntPtr pspec)
		{
			try
			{
				(Object.GetObject(inst, false) as Container).OnSetChildProperty(Object.GetObject(child) as Widget, property_id, (Value)Marshal.PtrToStructure(value, typeof(Value)), pspec);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060007F3 RID: 2035 RVA: 0x00017CAC File Offset: 0x00015EAC
		[DefaultSignalHandler(Type = typeof(Container), ConnectionMethod = "OverrideSetChildProperty")]
		protected virtual void OnSetChildProperty(Widget child, uint property_id, Value value, IntPtr pspec)
		{
			this.InternalSetChildProperty(child, property_id, value, pspec);
		}

		// Token: 0x060007F4 RID: 2036 RVA: 0x00017CBC File Offset: 0x00015EBC
		private void InternalSetChildProperty(Widget child, uint property_id, Value value, IntPtr pspec)
		{
			Container.SetChildPropertyNativeDelegate setChildPropertyNativeDelegate = Container.class_abi.BaseOverride(base.LookupGType(), "set_child_property");
			if (setChildPropertyNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(value);
			setChildPropertyNativeDelegate(base.Handle, (child == null) ? IntPtr.Zero : child.Handle, property_id, intPtr, pspec);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x17000166 RID: 358
		// (get) Token: 0x060007F5 RID: 2037 RVA: 0x00017D15 File Offset: 0x00015F15
		private static Container.GetChildPropertyNativeDelegate GetChildPropertyVMCallback
		{
			get
			{
				if (Container.GetChildProperty_cb_delegate == null)
				{
					Container.GetChildProperty_cb_delegate = new Container.GetChildPropertyNativeDelegate(Container.GetChildProperty_cb);
				}
				return Container.GetChildProperty_cb_delegate;
			}
		}

		// Token: 0x060007F6 RID: 2038 RVA: 0x00017D34 File Offset: 0x00015F34
		private static void OverrideGetChildProperty(GType gtype)
		{
			Container.OverrideGetChildProperty(gtype, Container.GetChildPropertyVMCallback);
		}

		// Token: 0x060007F7 RID: 2039 RVA: 0x00017D44 File Offset: 0x00015F44
		private unsafe static void OverrideGetChildProperty(GType gtype, Container.GetChildPropertyNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Container.class_abi.GetFieldOffset("get_child_property");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060007F8 RID: 2040 RVA: 0x00017D78 File Offset: 0x00015F78
		private static void GetChildProperty_cb(IntPtr inst, IntPtr child, uint property_id, IntPtr value, IntPtr pspec)
		{
			try
			{
				(Object.GetObject(inst, false) as Container).OnGetChildProperty(Object.GetObject(child) as Widget, property_id, (Value)Marshal.PtrToStructure(value, typeof(Value)), pspec);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060007F9 RID: 2041 RVA: 0x00017DD4 File Offset: 0x00015FD4
		[DefaultSignalHandler(Type = typeof(Container), ConnectionMethod = "OverrideGetChildProperty")]
		protected virtual void OnGetChildProperty(Widget child, uint property_id, Value value, IntPtr pspec)
		{
			this.InternalGetChildProperty(child, property_id, value, pspec);
		}

		// Token: 0x060007FA RID: 2042 RVA: 0x00017DE4 File Offset: 0x00015FE4
		private void InternalGetChildProperty(Widget child, uint property_id, Value value, IntPtr pspec)
		{
			Container.GetChildPropertyNativeDelegate getChildPropertyNativeDelegate = Container.class_abi.BaseOverride(base.LookupGType(), "get_child_property");
			if (getChildPropertyNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(value);
			getChildPropertyNativeDelegate(base.Handle, (child == null) ? IntPtr.Zero : child.Handle, property_id, intPtr, pspec);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x17000167 RID: 359
		// (get) Token: 0x060007FB RID: 2043 RVA: 0x00017E3D File Offset: 0x0001603D
		private static Container.GetPathForChildNativeDelegate GetPathForChildVMCallback
		{
			get
			{
				if (Container.GetPathForChild_cb_delegate == null)
				{
					Container.GetPathForChild_cb_delegate = new Container.GetPathForChildNativeDelegate(Container.GetPathForChild_cb);
				}
				return Container.GetPathForChild_cb_delegate;
			}
		}

		// Token: 0x060007FC RID: 2044 RVA: 0x00017E5C File Offset: 0x0001605C
		private static void OverrideGetPathForChild(GType gtype)
		{
			Container.OverrideGetPathForChild(gtype, Container.GetPathForChildVMCallback);
		}

		// Token: 0x060007FD RID: 2045 RVA: 0x00017E6C File Offset: 0x0001606C
		private unsafe static void OverrideGetPathForChild(GType gtype, Container.GetPathForChildNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Container.class_abi.GetFieldOffset("get_path_for_child");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060007FE RID: 2046 RVA: 0x00017EA0 File Offset: 0x000160A0
		private static IntPtr GetPathForChild_cb(IntPtr inst, IntPtr child)
		{
			IntPtr result;
			try
			{
				WidgetPath widgetPath = (Object.GetObject(inst, false) as Container).OnGetPathForChild(Object.GetObject(child) as Widget);
				result = ((widgetPath == null) ? IntPtr.Zero : widgetPath.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060007FF RID: 2047 RVA: 0x00017EF8 File Offset: 0x000160F8
		[DefaultSignalHandler(Type = typeof(Container), ConnectionMethod = "OverrideGetPathForChild")]
		protected virtual WidgetPath OnGetPathForChild(Widget child)
		{
			return this.InternalGetPathForChild(child);
		}

		// Token: 0x06000800 RID: 2048 RVA: 0x00017F04 File Offset: 0x00016104
		private WidgetPath InternalGetPathForChild(Widget child)
		{
			Container.GetPathForChildNativeDelegate getPathForChildNativeDelegate = Container.class_abi.BaseOverride(base.LookupGType(), "get_path_for_child");
			if (getPathForChildNativeDelegate == null)
			{
				return null;
			}
			IntPtr intPtr = getPathForChildNativeDelegate(base.Handle, (child == null) ? IntPtr.Zero : child.Handle);
			if (!(intPtr == IntPtr.Zero))
			{
				return (WidgetPath)Opaque.GetOpaque(intPtr, typeof(WidgetPath), false);
			}
			return null;
		}

		// Token: 0x17000168 RID: 360
		// (get) Token: 0x06000801 RID: 2049 RVA: 0x00017F70 File Offset: 0x00016170
		public new static AbiStruct class_abi
		{
			get
			{
				if (Container._class_abi == null)
				{
					Container._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("add", Widget.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "remove", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("remove", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "add", "check_resize", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("check_resize", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "remove", "forall", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("forall", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "check_resize", "set_focus_child", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("set_focus_child", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "forall", "child_type", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("child_type", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "set_focus_child", "composite_name", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("composite_name", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "child_type", "set_child_property", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("set_child_property", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "composite_name", "get_child_property", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_child_property", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "set_child_property", "get_path_for_child", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_path_for_child", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_child_property", "_handle_border_width", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_handle_border_width", -1L, (uint)Marshal.SizeOf(typeof(bool)), "get_path_for_child", "_gtk_reserved1", 1L, 1U),
						new AbiField("_gtk_reserved1", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_handle_border_width", "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", "_gtk_reserved5", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved5", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved4", "_gtk_reserved6", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved6", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved5", "_gtk_reserved7", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved7", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved6", "_gtk_reserved8", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved8", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved7", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Container._class_abi;
			}
		}

		// Token: 0x06000802 RID: 2050 RVA: 0x00018401 File Offset: 0x00016601
		public void Add(Widget widget)
		{
			Container.gtk_container_add(base.Handle, (widget == null) ? IntPtr.Zero : widget.Handle);
		}

		// Token: 0x06000803 RID: 2051 RVA: 0x00018423 File Offset: 0x00016623
		public void CheckResize()
		{
			Container.gtk_container_check_resize(base.Handle);
		}

		// Token: 0x06000804 RID: 2052 RVA: 0x00018438 File Offset: 0x00016638
		public void ChildGetValist(Widget child, string first_property_name, IntPtr var_args)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(first_property_name);
			Container.gtk_container_child_get_valist(base.Handle, (child == null) ? IntPtr.Zero : child.Handle, intPtr, var_args);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000805 RID: 2053 RVA: 0x00018474 File Offset: 0x00016674
		public void ChildNotify(Widget child, string child_property)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(child_property);
			Container.gtk_container_child_notify(base.Handle, (child == null) ? IntPtr.Zero : child.Handle, intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000806 RID: 2054 RVA: 0x000184AF File Offset: 0x000166AF
		public void ChildNotifyByPspec(Widget child, IntPtr pspec)
		{
			Container.gtk_container_child_notify_by_pspec(base.Handle, (child == null) ? IntPtr.Zero : child.Handle, pspec);
		}

		// Token: 0x06000807 RID: 2055 RVA: 0x000184D4 File Offset: 0x000166D4
		public void ChildSetProperty(Widget child, string property_name, Value value)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(property_name);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(value);
			Container.gtk_container_child_set_property(base.Handle, (child == null) ? IntPtr.Zero : child.Handle, intPtr, intPtr2);
			Marshaller.Free(intPtr);
			Marshal.FreeHGlobal(intPtr2);
		}

		// Token: 0x06000808 RID: 2056 RVA: 0x00018524 File Offset: 0x00016724
		public void ChildSetValist(Widget child, string first_property_name, IntPtr var_args)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(first_property_name);
			Container.gtk_container_child_set_valist(base.Handle, (child == null) ? IntPtr.Zero : child.Handle, intPtr, var_args);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000809 RID: 2057 RVA: 0x00018560 File Offset: 0x00016760
		public GType SupportedChildType()
		{
			IntPtr val = Container.gtk_container_child_type(base.Handle);
			return new GType(val);
		}

		// Token: 0x0600080A RID: 2058 RVA: 0x00018584 File Offset: 0x00016784
		public void Forall(Callback cb)
		{
			CallbackWrapper callbackWrapper = new CallbackWrapper(cb);
			Container.gtk_container_forall(base.Handle, callbackWrapper.NativeDelegate, IntPtr.Zero);
		}

		// Token: 0x0600080B RID: 2059 RVA: 0x000185B4 File Offset: 0x000167B4
		public void Foreach(Callback cb)
		{
			CallbackWrapper callbackWrapper = new CallbackWrapper(cb);
			Container.gtk_container_foreach(base.Handle, callbackWrapper.NativeDelegate, IntPtr.Zero);
		}

		// Token: 0x17000169 RID: 361
		// (get) Token: 0x0600080C RID: 2060 RVA: 0x000185E3 File Offset: 0x000167E3
		public Widget[] Children
		{
			get
			{
				return (Widget[])Marshaller.ListPtrToArray(Container.gtk_container_get_children(base.Handle), typeof(List), true, false, typeof(Widget));
			}
		}

		// Token: 0x1700016A RID: 362
		// (get) Token: 0x0600080D RID: 2061 RVA: 0x00018615 File Offset: 0x00016815
		// (set) Token: 0x0600080E RID: 2062 RVA: 0x00018631 File Offset: 0x00016831
		public Widget FocusChild
		{
			get
			{
				return Object.GetObject(Container.gtk_container_get_focus_child(base.Handle)) as Widget;
			}
			set
			{
				Container.gtk_container_set_focus_child(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x1700016B RID: 363
		// (get) Token: 0x0600080F RID: 2063 RVA: 0x00018653 File Offset: 0x00016853
		// (set) Token: 0x06000810 RID: 2064 RVA: 0x0001866F File Offset: 0x0001686F
		public Adjustment FocusHadjustment
		{
			get
			{
				return Object.GetObject(Container.gtk_container_get_focus_hadjustment(base.Handle)) as Adjustment;
			}
			set
			{
				Container.gtk_container_set_focus_hadjustment(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x1700016C RID: 364
		// (get) Token: 0x06000811 RID: 2065 RVA: 0x00018691 File Offset: 0x00016891
		// (set) Token: 0x06000812 RID: 2066 RVA: 0x000186AD File Offset: 0x000168AD
		public Adjustment FocusVadjustment
		{
			get
			{
				return Object.GetObject(Container.gtk_container_get_focus_vadjustment(base.Handle)) as Adjustment;
			}
			set
			{
				Container.gtk_container_set_focus_vadjustment(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x06000813 RID: 2067 RVA: 0x000186D0 File Offset: 0x000168D0
		public WidgetPath GetPathForChild(Widget child)
		{
			IntPtr intPtr = Container.gtk_container_get_path_for_child(base.Handle, (child == null) ? IntPtr.Zero : child.Handle);
			if (!(intPtr == IntPtr.Zero))
			{
				return (WidgetPath)Opaque.GetOpaque(intPtr, typeof(WidgetPath), false);
			}
			return null;
		}

		// Token: 0x1700016D RID: 365
		// (get) Token: 0x06000814 RID: 2068 RVA: 0x00018724 File Offset: 0x00016924
		public new static GType GType
		{
			get
			{
				IntPtr val = Container.gtk_container_get_type();
				return new GType(val);
			}
		}

		// Token: 0x06000815 RID: 2069 RVA: 0x00018742 File Offset: 0x00016942
		public void PropagateDraw(Widget child, Context cr)
		{
			Container.gtk_container_propagate_draw(base.Handle, (child == null) ? IntPtr.Zero : child.Handle, (cr == null) ? IntPtr.Zero : cr.Handle);
		}

		// Token: 0x06000816 RID: 2070 RVA: 0x00018774 File Offset: 0x00016974
		public void Remove(Widget widget)
		{
			Container.gtk_container_remove(base.Handle, (widget == null) ? IntPtr.Zero : widget.Handle);
		}

		// Token: 0x06000817 RID: 2071 RVA: 0x00018796 File Offset: 0x00016996
		[Obsolete]
		public void ResizeChildren()
		{
			Container.gtk_container_resize_children(base.Handle);
		}

		// Token: 0x1700016E RID: 366
		// (set) Token: 0x06000818 RID: 2072 RVA: 0x000187A8 File Offset: 0x000169A8
		[Obsolete]
		public bool ReallocateRedraws
		{
			set
			{
				Container.gtk_container_set_reallocate_redraws(base.Handle, value);
			}
		}

		// Token: 0x06000819 RID: 2073 RVA: 0x000187BB File Offset: 0x000169BB
		public void UnsetFocusChain()
		{
			Container.gtk_container_unset_focus_chain(base.Handle);
		}

		// Token: 0x1700016F RID: 367
		// (get) Token: 0x0600081A RID: 2074 RVA: 0x000187D0 File Offset: 0x000169D0
		public new static AbiStruct abi_info
		{
			get
			{
				if (Container._abi_info == null)
				{
					Container._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Widget.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Container._abi_info;
			}
		}

		// Token: 0x040003E3 RID: 995
		private static Container.d_gtk_container_class_find_child_property gtk_container_class_find_child_property = FuncLoader.LoadFunction<Container.d_gtk_container_class_find_child_property>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_class_find_child_property"));

		// Token: 0x040003E4 RID: 996
		private static Container.d_gtk_container_child_get_property gtk_container_child_get_property = FuncLoader.LoadFunction<Container.d_gtk_container_child_get_property>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_child_get_property"));

		// Token: 0x040003E5 RID: 997
		private static Container.d_gtk_container_get_focus_chain gtk_container_get_focus_chain = FuncLoader.LoadFunction<Container.d_gtk_container_get_focus_chain>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_get_focus_chain"));

		// Token: 0x040003E6 RID: 998
		private static Container.d_gtk_container_set_focus_chain gtk_container_set_focus_chain = FuncLoader.LoadFunction<Container.d_gtk_container_set_focus_chain>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_set_focus_chain"));

		// Token: 0x040003E7 RID: 999
		private static Container.ChildTypeNativeDelegate ObsoleteChildTypeVMCallback;

		// Token: 0x040003E8 RID: 1000
		private static Container.ForAllNativeDelegate ForAll_cb_delegate;

		// Token: 0x040003E9 RID: 1001
		private static Container.d_gtk_container_get_resize_mode gtk_container_get_resize_mode = FuncLoader.LoadFunction<Container.d_gtk_container_get_resize_mode>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_get_resize_mode"));

		// Token: 0x040003EA RID: 1002
		private static Container.d_gtk_container_set_resize_mode gtk_container_set_resize_mode = FuncLoader.LoadFunction<Container.d_gtk_container_set_resize_mode>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_set_resize_mode"));

		// Token: 0x040003EB RID: 1003
		private static Container.d_gtk_container_get_border_width gtk_container_get_border_width = FuncLoader.LoadFunction<Container.d_gtk_container_get_border_width>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_get_border_width"));

		// Token: 0x040003EC RID: 1004
		private static Container.d_gtk_container_set_border_width gtk_container_set_border_width = FuncLoader.LoadFunction<Container.d_gtk_container_set_border_width>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_set_border_width"));

		// Token: 0x040003ED RID: 1005
		private static Container.AddedNativeDelegate Added_cb_delegate;

		// Token: 0x040003EE RID: 1006
		private static Container.RemovedNativeDelegate Removed_cb_delegate;

		// Token: 0x040003EF RID: 1007
		private static Container.ResizeCheckedNativeDelegate ResizeChecked_cb_delegate;

		// Token: 0x040003F0 RID: 1008
		private static Container.FocusChildSetNativeDelegate FocusChildSet_cb_delegate;

		// Token: 0x040003F1 RID: 1009
		private static Container.ChildTypeNativeDelegate ChildType_cb_delegate;

		// Token: 0x040003F2 RID: 1010
		private static Container.CompositeNameNativeDelegate CompositeName_cb_delegate;

		// Token: 0x040003F3 RID: 1011
		private static Container.SetChildPropertyNativeDelegate SetChildProperty_cb_delegate;

		// Token: 0x040003F4 RID: 1012
		private static Container.GetChildPropertyNativeDelegate GetChildProperty_cb_delegate;

		// Token: 0x040003F5 RID: 1013
		private static Container.GetPathForChildNativeDelegate GetPathForChild_cb_delegate;

		// Token: 0x040003F6 RID: 1014
		private static AbiStruct _class_abi = null;

		// Token: 0x040003F7 RID: 1015
		private static Container.d_gtk_container_add gtk_container_add = FuncLoader.LoadFunction<Container.d_gtk_container_add>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_add"));

		// Token: 0x040003F8 RID: 1016
		private static Container.d_gtk_container_check_resize gtk_container_check_resize = FuncLoader.LoadFunction<Container.d_gtk_container_check_resize>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_check_resize"));

		// Token: 0x040003F9 RID: 1017
		private static Container.d_gtk_container_child_get_valist gtk_container_child_get_valist = FuncLoader.LoadFunction<Container.d_gtk_container_child_get_valist>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_child_get_valist"));

		// Token: 0x040003FA RID: 1018
		private static Container.d_gtk_container_child_notify gtk_container_child_notify = FuncLoader.LoadFunction<Container.d_gtk_container_child_notify>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_child_notify"));

		// Token: 0x040003FB RID: 1019
		private static Container.d_gtk_container_child_notify_by_pspec gtk_container_child_notify_by_pspec = FuncLoader.LoadFunction<Container.d_gtk_container_child_notify_by_pspec>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_child_notify_by_pspec"));

		// Token: 0x040003FC RID: 1020
		private static Container.d_gtk_container_child_set_property gtk_container_child_set_property = FuncLoader.LoadFunction<Container.d_gtk_container_child_set_property>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_child_set_property"));

		// Token: 0x040003FD RID: 1021
		private static Container.d_gtk_container_child_set_valist gtk_container_child_set_valist = FuncLoader.LoadFunction<Container.d_gtk_container_child_set_valist>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_child_set_valist"));

		// Token: 0x040003FE RID: 1022
		private static Container.d_gtk_container_child_type gtk_container_child_type = FuncLoader.LoadFunction<Container.d_gtk_container_child_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_child_type"));

		// Token: 0x040003FF RID: 1023
		private static Container.d_gtk_container_forall gtk_container_forall = FuncLoader.LoadFunction<Container.d_gtk_container_forall>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_forall"));

		// Token: 0x04000400 RID: 1024
		private static Container.d_gtk_container_foreach gtk_container_foreach = FuncLoader.LoadFunction<Container.d_gtk_container_foreach>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_foreach"));

		// Token: 0x04000401 RID: 1025
		private static Container.d_gtk_container_get_children gtk_container_get_children = FuncLoader.LoadFunction<Container.d_gtk_container_get_children>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_get_children"));

		// Token: 0x04000402 RID: 1026
		private static Container.d_gtk_container_get_focus_child gtk_container_get_focus_child = FuncLoader.LoadFunction<Container.d_gtk_container_get_focus_child>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_get_focus_child"));

		// Token: 0x04000403 RID: 1027
		private static Container.d_gtk_container_set_focus_child gtk_container_set_focus_child = FuncLoader.LoadFunction<Container.d_gtk_container_set_focus_child>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_set_focus_child"));

		// Token: 0x04000404 RID: 1028
		private static Container.d_gtk_container_get_focus_hadjustment gtk_container_get_focus_hadjustment = FuncLoader.LoadFunction<Container.d_gtk_container_get_focus_hadjustment>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_get_focus_hadjustment"));

		// Token: 0x04000405 RID: 1029
		private static Container.d_gtk_container_set_focus_hadjustment gtk_container_set_focus_hadjustment = FuncLoader.LoadFunction<Container.d_gtk_container_set_focus_hadjustment>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_set_focus_hadjustment"));

		// Token: 0x04000406 RID: 1030
		private static Container.d_gtk_container_get_focus_vadjustment gtk_container_get_focus_vadjustment = FuncLoader.LoadFunction<Container.d_gtk_container_get_focus_vadjustment>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_get_focus_vadjustment"));

		// Token: 0x04000407 RID: 1031
		private static Container.d_gtk_container_set_focus_vadjustment gtk_container_set_focus_vadjustment = FuncLoader.LoadFunction<Container.d_gtk_container_set_focus_vadjustment>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_set_focus_vadjustment"));

		// Token: 0x04000408 RID: 1032
		private static Container.d_gtk_container_get_path_for_child gtk_container_get_path_for_child = FuncLoader.LoadFunction<Container.d_gtk_container_get_path_for_child>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_get_path_for_child"));

		// Token: 0x04000409 RID: 1033
		private static Container.d_gtk_container_get_type gtk_container_get_type = FuncLoader.LoadFunction<Container.d_gtk_container_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_get_type"));

		// Token: 0x0400040A RID: 1034
		private static Container.d_gtk_container_propagate_draw gtk_container_propagate_draw = FuncLoader.LoadFunction<Container.d_gtk_container_propagate_draw>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_propagate_draw"));

		// Token: 0x0400040B RID: 1035
		private static Container.d_gtk_container_remove gtk_container_remove = FuncLoader.LoadFunction<Container.d_gtk_container_remove>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_remove"));

		// Token: 0x0400040C RID: 1036
		private static Container.d_gtk_container_resize_children gtk_container_resize_children = FuncLoader.LoadFunction<Container.d_gtk_container_resize_children>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_resize_children"));

		// Token: 0x0400040D RID: 1037
		private static Container.d_gtk_container_set_reallocate_redraws gtk_container_set_reallocate_redraws = FuncLoader.LoadFunction<Container.d_gtk_container_set_reallocate_redraws>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_set_reallocate_redraws"));

		// Token: 0x0400040E RID: 1038
		private static Container.d_gtk_container_unset_focus_chain gtk_container_unset_focus_chain = FuncLoader.LoadFunction<Container.d_gtk_container_unset_focus_chain>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_container_unset_focus_chain"));

		// Token: 0x0400040F RID: 1039
		private static AbiStruct _abi_info = null;

		// Token: 0x02000811 RID: 2065
		// (Invoke) Token: 0x06004764 RID: 18276
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_container_class_find_child_property(IntPtr cclass, string property_name);

		// Token: 0x02000812 RID: 2066
		// (Invoke) Token: 0x06004768 RID: 18280
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_child_get_property(IntPtr container, IntPtr child, string property_name, ref Value value);

		// Token: 0x02000813 RID: 2067
		private new struct GTypeInstance
		{
			// Token: 0x04001E49 RID: 7753
			public IntPtr GTypeClass;
		}

		// Token: 0x02000814 RID: 2068
		private struct GParamSpec
		{
			// Token: 0x04001E4A RID: 7754
			public Container.GTypeInstance g_type_instance;

			// Token: 0x04001E4B RID: 7755
			public IntPtr name;

			// Token: 0x04001E4C RID: 7756
			public int flags;

			// Token: 0x04001E4D RID: 7757
			public GType value_type;

			// Token: 0x04001E4E RID: 7758
			public GType owner_type;

			// Token: 0x04001E4F RID: 7759
			private IntPtr _nick;

			// Token: 0x04001E50 RID: 7760
			private IntPtr _blurb;

			// Token: 0x04001E51 RID: 7761
			private IntPtr qdata;

			// Token: 0x04001E52 RID: 7762
			private uint ref_count;

			// Token: 0x04001E53 RID: 7763
			private uint param_id;
		}

		// Token: 0x02000815 RID: 2069
		private class ChildAccumulator
		{
			// Token: 0x0600476B RID: 18283 RVA: 0x000B636B File Offset: 0x000B456B
			public void Add(Widget widget)
			{
				this.Children.Add(widget);
			}

			// Token: 0x04001E54 RID: 7764
			public ArrayList Children = new ArrayList();
		}

		// Token: 0x02000816 RID: 2070
		// (Invoke) Token: 0x0600476E RID: 18286
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_container_get_focus_chain(IntPtr raw, out IntPtr list_ptr);

		// Token: 0x02000817 RID: 2071
		// (Invoke) Token: 0x06004772 RID: 18290
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_set_focus_chain(IntPtr raw, IntPtr list_ptr);

		// Token: 0x02000818 RID: 2072
		public class ContainerChild
		{
			// Token: 0x06004775 RID: 18293 RVA: 0x000B638D File Offset: 0x000B458D
			public ContainerChild(Container parent, Widget child)
			{
				this.parent = parent;
				this.child = child;
			}

			// Token: 0x1700119D RID: 4509
			// (get) Token: 0x06004776 RID: 18294 RVA: 0x000B63A3 File Offset: 0x000B45A3
			public Container Parent
			{
				get
				{
					return this.parent;
				}
			}

			// Token: 0x1700119E RID: 4510
			// (get) Token: 0x06004777 RID: 18295 RVA: 0x000B63AB File Offset: 0x000B45AB
			public Widget Child
			{
				get
				{
					return this.child;
				}
			}

			// Token: 0x04001E55 RID: 7765
			protected Container parent;

			// Token: 0x04001E56 RID: 7766
			protected Widget child;
		}

		// Token: 0x02000819 RID: 2073
		// (Invoke) Token: 0x06004779 RID: 18297
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		internal delegate void ForAllNativeDelegate(IntPtr inst, bool include_internals, IntPtr cb, IntPtr data);

		// Token: 0x0200081A RID: 2074
		internal class ForAllCallbackHandler
		{
			// Token: 0x1700119F RID: 4511
			// (get) Token: 0x0600477C RID: 18300 RVA: 0x000B63B3 File Offset: 0x000B45B3
			internal IntPtr cb { get; }

			// Token: 0x170011A0 RID: 4512
			// (get) Token: 0x0600477D RID: 18301 RVA: 0x000B63BB File Offset: 0x000B45BB
			internal IntPtr data { get; }

			// Token: 0x170011A1 RID: 4513
			// (get) Token: 0x0600477E RID: 18302 RVA: 0x000B63C3 File Offset: 0x000B45C3
			internal bool include_internals { get; }

			// Token: 0x0600477F RID: 18303 RVA: 0x000B63CB File Offset: 0x000B45CB
			internal ForAllCallbackHandler(IntPtr cb, IntPtr data, bool include_internals)
			{
				this.cb = cb;
				this.data = data;
				this.include_internals = include_internals;
			}

			// Token: 0x06004780 RID: 18304 RVA: 0x000B63E8 File Offset: 0x000B45E8
			internal void Invoke(Widget w)
			{
				Callback handler = new CallbackInvoker(Container.TryGetDelegate<CallbackNative>(this.cb), this.data).Handler;
				if (handler == null)
				{
					return;
				}
				handler(w);
			}
		}

		// Token: 0x0200081B RID: 2075
		// (Invoke) Token: 0x06004782 RID: 18306
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_container_get_resize_mode(IntPtr raw);

		// Token: 0x0200081C RID: 2076
		// (Invoke) Token: 0x06004786 RID: 18310
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_set_resize_mode(IntPtr raw, int resize_mode);

		// Token: 0x0200081D RID: 2077
		// (Invoke) Token: 0x0600478A RID: 18314
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gtk_container_get_border_width(IntPtr raw);

		// Token: 0x0200081E RID: 2078
		// (Invoke) Token: 0x0600478E RID: 18318
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_set_border_width(IntPtr raw, uint border_width);

		// Token: 0x0200081F RID: 2079
		// (Invoke) Token: 0x06004792 RID: 18322
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void AddedNativeDelegate(IntPtr inst, IntPtr widget);

		// Token: 0x02000820 RID: 2080
		// (Invoke) Token: 0x06004796 RID: 18326
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void RemovedNativeDelegate(IntPtr inst, IntPtr widget);

		// Token: 0x02000821 RID: 2081
		// (Invoke) Token: 0x0600479A RID: 18330
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ResizeCheckedNativeDelegate(IntPtr inst);

		// Token: 0x02000822 RID: 2082
		// (Invoke) Token: 0x0600479E RID: 18334
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void FocusChildSetNativeDelegate(IntPtr inst, IntPtr child);

		// Token: 0x02000823 RID: 2083
		// (Invoke) Token: 0x060047A2 RID: 18338
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr ChildTypeNativeDelegate(IntPtr inst);

		// Token: 0x02000824 RID: 2084
		// (Invoke) Token: 0x060047A6 RID: 18342
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr CompositeNameNativeDelegate(IntPtr inst, IntPtr child);

		// Token: 0x02000825 RID: 2085
		// (Invoke) Token: 0x060047AA RID: 18346
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void SetChildPropertyNativeDelegate(IntPtr inst, IntPtr child, uint property_id, IntPtr value, IntPtr pspec);

		// Token: 0x02000826 RID: 2086
		// (Invoke) Token: 0x060047AE RID: 18350
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void GetChildPropertyNativeDelegate(IntPtr inst, IntPtr child, uint property_id, IntPtr value, IntPtr pspec);

		// Token: 0x02000827 RID: 2087
		// (Invoke) Token: 0x060047B2 RID: 18354
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetPathForChildNativeDelegate(IntPtr inst, IntPtr child);

		// Token: 0x02000828 RID: 2088
		// (Invoke) Token: 0x060047B6 RID: 18358
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_add(IntPtr raw, IntPtr widget);

		// Token: 0x02000829 RID: 2089
		// (Invoke) Token: 0x060047BA RID: 18362
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_check_resize(IntPtr raw);

		// Token: 0x0200082A RID: 2090
		// (Invoke) Token: 0x060047BE RID: 18366
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_child_get_valist(IntPtr raw, IntPtr child, IntPtr first_property_name, IntPtr var_args);

		// Token: 0x0200082B RID: 2091
		// (Invoke) Token: 0x060047C2 RID: 18370
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_child_notify(IntPtr raw, IntPtr child, IntPtr child_property);

		// Token: 0x0200082C RID: 2092
		// (Invoke) Token: 0x060047C6 RID: 18374
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_child_notify_by_pspec(IntPtr raw, IntPtr child, IntPtr pspec);

		// Token: 0x0200082D RID: 2093
		// (Invoke) Token: 0x060047CA RID: 18378
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_child_set_property(IntPtr raw, IntPtr child, IntPtr property_name, IntPtr value);

		// Token: 0x0200082E RID: 2094
		// (Invoke) Token: 0x060047CE RID: 18382
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_child_set_valist(IntPtr raw, IntPtr child, IntPtr first_property_name, IntPtr var_args);

		// Token: 0x0200082F RID: 2095
		// (Invoke) Token: 0x060047D2 RID: 18386
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_container_child_type(IntPtr raw);

		// Token: 0x02000830 RID: 2096
		// (Invoke) Token: 0x060047D6 RID: 18390
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_forall(IntPtr raw, CallbackNative cb, IntPtr callback_data);

		// Token: 0x02000831 RID: 2097
		// (Invoke) Token: 0x060047DA RID: 18394
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_foreach(IntPtr raw, CallbackNative cb, IntPtr callback_data);

		// Token: 0x02000832 RID: 2098
		// (Invoke) Token: 0x060047DE RID: 18398
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_container_get_children(IntPtr raw);

		// Token: 0x02000833 RID: 2099
		// (Invoke) Token: 0x060047E2 RID: 18402
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_container_get_focus_child(IntPtr raw);

		// Token: 0x02000834 RID: 2100
		// (Invoke) Token: 0x060047E6 RID: 18406
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_set_focus_child(IntPtr raw, IntPtr child);

		// Token: 0x02000835 RID: 2101
		// (Invoke) Token: 0x060047EA RID: 18410
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_container_get_focus_hadjustment(IntPtr raw);

		// Token: 0x02000836 RID: 2102
		// (Invoke) Token: 0x060047EE RID: 18414
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_set_focus_hadjustment(IntPtr raw, IntPtr adjustment);

		// Token: 0x02000837 RID: 2103
		// (Invoke) Token: 0x060047F2 RID: 18418
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_container_get_focus_vadjustment(IntPtr raw);

		// Token: 0x02000838 RID: 2104
		// (Invoke) Token: 0x060047F6 RID: 18422
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_set_focus_vadjustment(IntPtr raw, IntPtr adjustment);

		// Token: 0x02000839 RID: 2105
		// (Invoke) Token: 0x060047FA RID: 18426
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_container_get_path_for_child(IntPtr raw, IntPtr child);

		// Token: 0x0200083A RID: 2106
		// (Invoke) Token: 0x060047FE RID: 18430
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_container_get_type();

		// Token: 0x0200083B RID: 2107
		// (Invoke) Token: 0x06004802 RID: 18434
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_propagate_draw(IntPtr raw, IntPtr child, IntPtr cr);

		// Token: 0x0200083C RID: 2108
		// (Invoke) Token: 0x06004806 RID: 18438
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_remove(IntPtr raw, IntPtr widget);

		// Token: 0x0200083D RID: 2109
		// (Invoke) Token: 0x0600480A RID: 18442
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_resize_children(IntPtr raw);

		// Token: 0x0200083E RID: 2110
		// (Invoke) Token: 0x0600480E RID: 18446
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_set_reallocate_redraws(IntPtr raw, bool needs_redraws);

		// Token: 0x0200083F RID: 2111
		// (Invoke) Token: 0x06004812 RID: 18450
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_container_unset_focus_chain(IntPtr raw);
	}
}
