﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using GLib;

namespace Gtk
{
	// Token: 0x020001F1 RID: 497
	public class CssProvider : Object, IStyleProvider, IWrapper
	{
		// Token: 0x060011DD RID: 4573 RVA: 0x000343EB File Offset: 0x000325EB
		public CssProvider(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x060011DE RID: 4574 RVA: 0x000343F4 File Offset: 0x000325F4
		public CssProvider() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(CssProvider))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = CssProvider.gtk_css_provider_new();
		}

		// Token: 0x1400006C RID: 108
		// (add) Token: 0x060011DF RID: 4575 RVA: 0x00034446 File Offset: 0x00032646
		// (remove) Token: 0x060011E0 RID: 4576 RVA: 0x0003445E File Offset: 0x0003265E
		[Signal("parsing-error")]
		public event ParsingErrorHandler ParsingError
		{
			add
			{
				base.AddSignalHandler("parsing-error", value, typeof(ParsingErrorArgs));
			}
			remove
			{
				base.RemoveSignalHandler("parsing-error", value);
			}
		}

		// Token: 0x17000442 RID: 1090
		// (get) Token: 0x060011E1 RID: 4577 RVA: 0x0003446C File Offset: 0x0003266C
		private static CssProvider.ParsingErrorNativeDelegate ParsingErrorVMCallback
		{
			get
			{
				if (CssProvider.ParsingError_cb_delegate == null)
				{
					CssProvider.ParsingError_cb_delegate = new CssProvider.ParsingErrorNativeDelegate(CssProvider.ParsingError_cb);
				}
				return CssProvider.ParsingError_cb_delegate;
			}
		}

		// Token: 0x060011E2 RID: 4578 RVA: 0x0003448B File Offset: 0x0003268B
		private static void OverrideParsingError(GType gtype)
		{
			CssProvider.OverrideParsingError(gtype, CssProvider.ParsingErrorVMCallback);
		}

		// Token: 0x060011E3 RID: 4579 RVA: 0x00034498 File Offset: 0x00032698
		private unsafe static void OverrideParsingError(GType gtype, CssProvider.ParsingErrorNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + CssProvider.class_abi.GetFieldOffset("parsing_error");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060011E4 RID: 4580 RVA: 0x000344CC File Offset: 0x000326CC
		private static void ParsingError_cb(IntPtr inst, IntPtr section, IntPtr error)
		{
			try
			{
				(Object.GetObject(inst, false) as CssProvider).OnParsingError((section == IntPtr.Zero) ? null : ((CssSection)Opaque.GetOpaque(section, typeof(CssSection), false)), error);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060011E5 RID: 4581 RVA: 0x0003452C File Offset: 0x0003272C
		[DefaultSignalHandler(Type = typeof(CssProvider), ConnectionMethod = "OverrideParsingError")]
		protected virtual void OnParsingError(CssSection section, IntPtr error)
		{
			this.InternalParsingError(section, error);
		}

		// Token: 0x060011E6 RID: 4582 RVA: 0x00034538 File Offset: 0x00032738
		private void InternalParsingError(CssSection section, IntPtr error)
		{
			CssProvider.ParsingErrorNativeDelegate parsingErrorNativeDelegate = CssProvider.class_abi.BaseOverride(base.LookupGType(), "parsing_error");
			if (parsingErrorNativeDelegate == null)
			{
				return;
			}
			parsingErrorNativeDelegate(base.Handle, (section == null) ? IntPtr.Zero : section.Handle, error);
		}

		// Token: 0x17000443 RID: 1091
		// (get) Token: 0x060011E7 RID: 4583 RVA: 0x0003457C File Offset: 0x0003277C
		public new static AbiStruct class_abi
		{
			get
			{
				if (CssProvider._class_abi == null)
				{
					CssProvider._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("parsing_error", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "parsing_error", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CssProvider._class_abi;
			}
		}

		// Token: 0x060011E8 RID: 4584 RVA: 0x00034697 File Offset: 0x00032897
		public static int ErrorQuark()
		{
			return CssProvider.gtk_css_provider_error_quark();
		}

		// Token: 0x17000444 RID: 1092
		// (get) Token: 0x060011E9 RID: 4585 RVA: 0x000346A3 File Offset: 0x000328A3
		public static CssProvider Default
		{
			get
			{
				return Object.GetObject(CssProvider.gtk_css_provider_get_default()) as CssProvider;
			}
		}

		// Token: 0x060011EA RID: 4586 RVA: 0x000346BC File Offset: 0x000328BC
		public static CssProvider GetNamed(string name, string variant)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(name);
			IntPtr intPtr2 = Marshaller.StringToPtrGStrdup(variant);
			CssProvider result = Object.GetObject(CssProvider.gtk_css_provider_get_named(intPtr, intPtr2)) as CssProvider;
			Marshaller.Free(intPtr);
			Marshaller.Free(intPtr2);
			return result;
		}

		// Token: 0x17000445 RID: 1093
		// (get) Token: 0x060011EB RID: 4587 RVA: 0x000346FC File Offset: 0x000328FC
		public new static GType GType
		{
			get
			{
				IntPtr val = CssProvider.gtk_css_provider_get_type();
				return new GType(val);
			}
		}

		// Token: 0x060011EC RID: 4588 RVA: 0x0003471C File Offset: 0x0003291C
		public bool LoadFromData(string data)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(data);
			IntPtr zero = IntPtr.Zero;
			bool result = CssProvider.gtk_css_provider_load_from_data(base.Handle, intPtr, new IntPtr((long)Encoding.UTF8.GetByteCount(data)), out zero);
			Marshaller.Free(intPtr);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x060011ED RID: 4589 RVA: 0x00034774 File Offset: 0x00032974
		public bool LoadFromFile(IFile file)
		{
			IntPtr zero = IntPtr.Zero;
			bool result = CssProvider.gtk_css_provider_load_from_file(base.Handle, (file == null) ? IntPtr.Zero : ((file is Object) ? (file as Object).Handle : (file as FileAdapter).Handle), out zero);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x060011EE RID: 4590 RVA: 0x000347D8 File Offset: 0x000329D8
		public bool LoadFromPath(string path)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(path);
			IntPtr zero = IntPtr.Zero;
			bool result = CssProvider.gtk_css_provider_load_from_path(base.Handle, intPtr, out zero);
			Marshaller.Free(intPtr);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x060011EF RID: 4591 RVA: 0x00034820 File Offset: 0x00032A20
		public void LoadFromResource(string resource_path)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(resource_path);
			CssProvider.gtk_css_provider_load_from_resource(base.Handle, intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x060011F0 RID: 4592 RVA: 0x0003484B File Offset: 0x00032A4B
		public override string ToString()
		{
			return Marshaller.PtrToStringGFree(CssProvider.gtk_css_provider_to_string(base.Handle));
		}

		// Token: 0x060011F1 RID: 4593 RVA: 0x00034864 File Offset: 0x00032A64
		public bool GetStyleProperty(WidgetPath path, StateFlags state, IntPtr pspec, Value value)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(value);
			bool result = CssProvider.gtk_style_provider_get_style_property(base.Handle, (path == null) ? IntPtr.Zero : path.Handle, (int)state, pspec, intPtr);
			Marshal.FreeHGlobal(intPtr);
			return result;
		}

		// Token: 0x17000446 RID: 1094
		// (get) Token: 0x060011F2 RID: 4594 RVA: 0x000348A8 File Offset: 0x00032AA8
		public new static AbiStruct abi_info
		{
			get
			{
				if (CssProvider._abi_info == null)
				{
					CssProvider._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Object.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return CssProvider._abi_info;
			}
		}

		// Token: 0x04000851 RID: 2129
		private static CssProvider.d_gtk_css_provider_new gtk_css_provider_new = FuncLoader.LoadFunction<CssProvider.d_gtk_css_provider_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_css_provider_new"));

		// Token: 0x04000852 RID: 2130
		private static CssProvider.ParsingErrorNativeDelegate ParsingError_cb_delegate;

		// Token: 0x04000853 RID: 2131
		private static AbiStruct _class_abi = null;

		// Token: 0x04000854 RID: 2132
		private static CssProvider.d_gtk_css_provider_error_quark gtk_css_provider_error_quark = FuncLoader.LoadFunction<CssProvider.d_gtk_css_provider_error_quark>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_css_provider_error_quark"));

		// Token: 0x04000855 RID: 2133
		private static CssProvider.d_gtk_css_provider_get_default gtk_css_provider_get_default = FuncLoader.LoadFunction<CssProvider.d_gtk_css_provider_get_default>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_css_provider_get_default"));

		// Token: 0x04000856 RID: 2134
		private static CssProvider.d_gtk_css_provider_get_named gtk_css_provider_get_named = FuncLoader.LoadFunction<CssProvider.d_gtk_css_provider_get_named>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_css_provider_get_named"));

		// Token: 0x04000857 RID: 2135
		private static CssProvider.d_gtk_css_provider_get_type gtk_css_provider_get_type = FuncLoader.LoadFunction<CssProvider.d_gtk_css_provider_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_css_provider_get_type"));

		// Token: 0x04000858 RID: 2136
		private static CssProvider.d_gtk_css_provider_load_from_data gtk_css_provider_load_from_data = FuncLoader.LoadFunction<CssProvider.d_gtk_css_provider_load_from_data>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_css_provider_load_from_data"));

		// Token: 0x04000859 RID: 2137
		private static CssProvider.d_gtk_css_provider_load_from_file gtk_css_provider_load_from_file = FuncLoader.LoadFunction<CssProvider.d_gtk_css_provider_load_from_file>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_css_provider_load_from_file"));

		// Token: 0x0400085A RID: 2138
		private static CssProvider.d_gtk_css_provider_load_from_path gtk_css_provider_load_from_path = FuncLoader.LoadFunction<CssProvider.d_gtk_css_provider_load_from_path>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_css_provider_load_from_path"));

		// Token: 0x0400085B RID: 2139
		private static CssProvider.d_gtk_css_provider_load_from_resource gtk_css_provider_load_from_resource = FuncLoader.LoadFunction<CssProvider.d_gtk_css_provider_load_from_resource>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_css_provider_load_from_resource"));

		// Token: 0x0400085C RID: 2140
		private static CssProvider.d_gtk_css_provider_to_string gtk_css_provider_to_string = FuncLoader.LoadFunction<CssProvider.d_gtk_css_provider_to_string>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_css_provider_to_string"));

		// Token: 0x0400085D RID: 2141
		private static CssProvider.d_gtk_style_provider_get_style_property gtk_style_provider_get_style_property = FuncLoader.LoadFunction<CssProvider.d_gtk_style_provider_get_style_property>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_style_provider_get_style_property"));

		// Token: 0x0400085E RID: 2142
		private static AbiStruct _abi_info = null;

		// Token: 0x02000B67 RID: 2919
		// (Invoke) Token: 0x060054A5 RID: 21669
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_css_provider_new();

		// Token: 0x02000B68 RID: 2920
		// (Invoke) Token: 0x060054A9 RID: 21673
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ParsingErrorNativeDelegate(IntPtr inst, IntPtr section, IntPtr error);

		// Token: 0x02000B69 RID: 2921
		// (Invoke) Token: 0x060054AD RID: 21677
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gtk_css_provider_error_quark();

		// Token: 0x02000B6A RID: 2922
		// (Invoke) Token: 0x060054B1 RID: 21681
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_css_provider_get_default();

		// Token: 0x02000B6B RID: 2923
		// (Invoke) Token: 0x060054B5 RID: 21685
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_css_provider_get_named(IntPtr name, IntPtr variant);

		// Token: 0x02000B6C RID: 2924
		// (Invoke) Token: 0x060054B9 RID: 21689
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_css_provider_get_type();

		// Token: 0x02000B6D RID: 2925
		// (Invoke) Token: 0x060054BD RID: 21693
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_css_provider_load_from_data(IntPtr raw, IntPtr data, IntPtr length, out IntPtr error);

		// Token: 0x02000B6E RID: 2926
		// (Invoke) Token: 0x060054C1 RID: 21697
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_css_provider_load_from_file(IntPtr raw, IntPtr file, out IntPtr error);

		// Token: 0x02000B6F RID: 2927
		// (Invoke) Token: 0x060054C5 RID: 21701
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_css_provider_load_from_path(IntPtr raw, IntPtr path, out IntPtr error);

		// Token: 0x02000B70 RID: 2928
		// (Invoke) Token: 0x060054C9 RID: 21705
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_css_provider_load_from_resource(IntPtr raw, IntPtr resource_path);

		// Token: 0x02000B71 RID: 2929
		// (Invoke) Token: 0x060054CD RID: 21709
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_css_provider_to_string(IntPtr raw);

		// Token: 0x02000B72 RID: 2930
		// (Invoke) Token: 0x060054D1 RID: 21713
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_style_provider_get_style_property(IntPtr raw, IntPtr path, int state, IntPtr pspec, IntPtr value);
	}
}
