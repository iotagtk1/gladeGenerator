﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001EA RID: 490
	public class CssNodeClass : Opaque
	{
		// Token: 0x060011CF RID: 4559 RVA: 0x000342E1 File Offset: 0x000324E1
		public CssNodeClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700043B RID: 1083
		// (get) Token: 0x060011D0 RID: 4560 RVA: 0x000342EA File Offset: 0x000324EA
		public static AbiStruct abi_info
		{
			get
			{
				if (CssNodeClass._abi_info == null)
				{
					CssNodeClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssNodeClass._abi_info;
			}
		}

		// Token: 0x0400084A RID: 2122
		private static AbiStruct _abi_info;
	}
}
