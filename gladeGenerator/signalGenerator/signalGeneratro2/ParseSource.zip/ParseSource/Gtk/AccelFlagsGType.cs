﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x020000FA RID: 250
	internal class AccelFlagsGType
	{
		// Token: 0x1700024E RID: 590
		// (get) Token: 0x06000B2A RID: 2858 RVA: 0x00021B34 File Offset: 0x0001FD34
		public static GType GType
		{
			get
			{
				return new GType(AccelFlagsGType.gtk_accel_flags_get_type());
			}
		}

		// Token: 0x04000572 RID: 1394
		private static AccelFlagsGType.d_gtk_accel_flags_get_type gtk_accel_flags_get_type = FuncLoader.LoadFunction<AccelFlagsGType.d_gtk_accel_flags_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_accel_flags_get_type"));

		// Token: 0x02000992 RID: 2450
		// (Invoke) Token: 0x06004D5E RID: 19806
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_accel_flags_get_type();
	}
}
