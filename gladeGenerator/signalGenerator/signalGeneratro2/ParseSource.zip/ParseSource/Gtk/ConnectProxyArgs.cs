﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x020001B1 RID: 433
	public class ConnectProxyArgs : SignalArgs
	{
		// Token: 0x17000407 RID: 1031
		// (get) Token: 0x06001156 RID: 4438 RVA: 0x00033B64 File Offset: 0x00031D64
		public Action Action
		{
			get
			{
				return (Action)base.Args[0];
			}
		}

		// Token: 0x17000408 RID: 1032
		// (get) Token: 0x06001157 RID: 4439 RVA: 0x00033B73 File Offset: 0x00031D73
		public Widget Proxy
		{
			get
			{
				return (Widget)base.Args[1];
			}
		}
	}
}
