﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x0200018E RID: 398
	public class ChildNotifiedArgs : SignalArgs
	{
		// Token: 0x170003D0 RID: 976
		// (get) Token: 0x06001090 RID: 4240 RVA: 0x00031D66 File Offset: 0x0002FF66
		public IntPtr ChildProperty
		{
			get
			{
				return (IntPtr)base.Args[0];
			}
		}
	}
}
