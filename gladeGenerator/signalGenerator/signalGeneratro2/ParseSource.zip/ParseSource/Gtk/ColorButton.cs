﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x02000199 RID: 409
	public class ColorButton : Button, IColorChooser, IWrapper
	{
		// Token: 0x060010B6 RID: 4278 RVA: 0x00031DBA File Offset: 0x0002FFBA
		public ColorButton(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x060010B7 RID: 4279 RVA: 0x00031DC4 File Offset: 0x0002FFC4
		public ColorButton() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(ColorButton))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = ColorButton.gtk_color_button_new();
		}

		// Token: 0x060010B8 RID: 4280 RVA: 0x00031E18 File Offset: 0x00030018
		public ColorButton(Color color) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(ColorButton))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				list2.Add("color");
				list.Add(new Value(color));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(color);
			this.Raw = ColorButton.gtk_color_button_new_with_color(intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x060010B9 RID: 4281 RVA: 0x00031EA8 File Offset: 0x000300A8
		public ColorButton(RGBA rgba) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(ColorButton))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				list2.Add("rgba");
				list.Add(new Value(rgba));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(rgba);
			this.Raw = ColorButton.gtk_color_button_new_with_rgba(intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x170003D3 RID: 979
		// (get) Token: 0x060010BA RID: 4282 RVA: 0x00031F38 File Offset: 0x00030138
		// (set) Token: 0x060010BB RID: 4283 RVA: 0x00031F60 File Offset: 0x00030160
		[Property("use-alpha")]
		public bool HasAlpha
		{
			get
			{
				Value property = base.GetProperty("use-alpha");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("use-alpha", val);
				val.Dispose();
			}
		}

		// Token: 0x170003D4 RID: 980
		// (get) Token: 0x060010BC RID: 4284 RVA: 0x00031F88 File Offset: 0x00030188
		// (set) Token: 0x060010BD RID: 4285 RVA: 0x00031FA0 File Offset: 0x000301A0
		[Property("title")]
		public string Title
		{
			get
			{
				return Marshaller.Utf8PtrToString(ColorButton.gtk_color_button_get_title(base.Handle));
			}
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				ColorButton.gtk_color_button_set_title(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x170003D5 RID: 981
		// (get) Token: 0x060010BE RID: 4286 RVA: 0x00031FCC File Offset: 0x000301CC
		// (set) Token: 0x060010BF RID: 4287 RVA: 0x0003200C File Offset: 0x0003020C
		[Obsolete]
		[Property("color")]
		public Color Color
		{
			get
			{
				IntPtr intPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(Color)));
				ColorButton.gtk_color_button_get_color(base.Handle, intPtr);
				Color result = Color.New(intPtr);
				Marshal.FreeHGlobal(intPtr);
				return result;
			}
			set
			{
				IntPtr intPtr = Marshaller.StructureToPtrAlloc(value);
				ColorButton.gtk_color_button_set_color(base.Handle, intPtr);
				Marshal.FreeHGlobal(intPtr);
			}
		}

		// Token: 0x170003D6 RID: 982
		// (get) Token: 0x060010C0 RID: 4288 RVA: 0x0003203C File Offset: 0x0003023C
		// (set) Token: 0x060010C1 RID: 4289 RVA: 0x0003204E File Offset: 0x0003024E
		[Obsolete]
		[Property("alpha")]
		public ushort Alpha
		{
			get
			{
				return ColorButton.gtk_color_button_get_alpha(base.Handle);
			}
			set
			{
				ColorButton.gtk_color_button_set_alpha(base.Handle, value);
			}
		}

		// Token: 0x170003D7 RID: 983
		// (get) Token: 0x060010C2 RID: 4290 RVA: 0x00032064 File Offset: 0x00030264
		// (set) Token: 0x060010C3 RID: 4291 RVA: 0x0003208C File Offset: 0x0003028C
		[Property("show-editor")]
		public bool ShowEditor
		{
			get
			{
				Value property = base.GetProperty("show-editor");
				bool result = (bool)property;
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("show-editor", val);
				val.Dispose();
			}
		}

		// Token: 0x14000067 RID: 103
		// (add) Token: 0x060010C4 RID: 4292 RVA: 0x000320B4 File Offset: 0x000302B4
		// (remove) Token: 0x060010C5 RID: 4293 RVA: 0x000320C2 File Offset: 0x000302C2
		[Signal("color-set")]
		public event EventHandler ColorSet
		{
			add
			{
				base.AddSignalHandler("color-set", value);
			}
			remove
			{
				base.RemoveSignalHandler("color-set", value);
			}
		}

		// Token: 0x170003D8 RID: 984
		// (get) Token: 0x060010C6 RID: 4294 RVA: 0x000320D0 File Offset: 0x000302D0
		private static ColorButton.ColorSetNativeDelegate ColorSetVMCallback
		{
			get
			{
				if (ColorButton.ColorSet_cb_delegate == null)
				{
					ColorButton.ColorSet_cb_delegate = new ColorButton.ColorSetNativeDelegate(ColorButton.ColorSet_cb);
				}
				return ColorButton.ColorSet_cb_delegate;
			}
		}

		// Token: 0x060010C7 RID: 4295 RVA: 0x000320EF File Offset: 0x000302EF
		private static void OverrideColorSet(GType gtype)
		{
			ColorButton.OverrideColorSet(gtype, ColorButton.ColorSetVMCallback);
		}

		// Token: 0x060010C8 RID: 4296 RVA: 0x000320FC File Offset: 0x000302FC
		private unsafe static void OverrideColorSet(GType gtype, ColorButton.ColorSetNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + ColorButton.class_abi.GetFieldOffset("color_set");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060010C9 RID: 4297 RVA: 0x00032130 File Offset: 0x00030330
		private static void ColorSet_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as ColorButton).OnColorSet();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060010CA RID: 4298 RVA: 0x00032168 File Offset: 0x00030368
		[DefaultSignalHandler(Type = typeof(ColorButton), ConnectionMethod = "OverrideColorSet")]
		protected virtual void OnColorSet()
		{
			this.InternalColorSet();
		}

		// Token: 0x060010CB RID: 4299 RVA: 0x00032170 File Offset: 0x00030370
		private void InternalColorSet()
		{
			ColorButton.ColorSetNativeDelegate colorSetNativeDelegate = ColorButton.class_abi.BaseOverride(base.LookupGType(), "color_set");
			if (colorSetNativeDelegate == null)
			{
				return;
			}
			colorSetNativeDelegate(base.Handle);
		}

		// Token: 0x170003D9 RID: 985
		// (get) Token: 0x060010CC RID: 4300 RVA: 0x000321A4 File Offset: 0x000303A4
		public new static AbiStruct class_abi
		{
			get
			{
				if (ColorButton._class_abi == null)
				{
					ColorButton._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("color_set", Button.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved1", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved1", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "color_set", "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return ColorButton._class_abi;
			}
		}

		// Token: 0x170003DA RID: 986
		// (get) Token: 0x060010CD RID: 4301 RVA: 0x000322FC File Offset: 0x000304FC
		public new static GType GType
		{
			get
			{
				IntPtr val = ColorButton.gtk_color_button_get_type();
				return new GType(val);
			}
		}

		// Token: 0x060010CE RID: 4302 RVA: 0x0003231C File Offset: 0x0003051C
		public void AddPalette(Orientation orientation, int colors_per_line, int n_colors, RGBA colors)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(colors);
			ColorButton.gtk_color_chooser_add_palette(base.Handle, (int)orientation, colors_per_line, n_colors, intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x170003DB RID: 987
		// (get) Token: 0x060010CF RID: 4303 RVA: 0x00032350 File Offset: 0x00030550
		// (set) Token: 0x060010D0 RID: 4304 RVA: 0x00032390 File Offset: 0x00030590
		[Property("rgba")]
		public RGBA Rgba
		{
			get
			{
				IntPtr intPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(RGBA)));
				ColorButton.gtk_color_chooser_get_rgba(base.Handle, intPtr);
				RGBA result = RGBA.New(intPtr);
				Marshal.FreeHGlobal(intPtr);
				return result;
			}
			set
			{
				IntPtr intPtr = Marshaller.StructureToPtrAlloc(value);
				ColorButton.gtk_color_chooser_set_rgba(base.Handle, intPtr);
				Marshal.FreeHGlobal(intPtr);
			}
		}

		// Token: 0x170003DC RID: 988
		// (get) Token: 0x060010D1 RID: 4305 RVA: 0x000323C0 File Offset: 0x000305C0
		// (set) Token: 0x060010D2 RID: 4306 RVA: 0x000323D2 File Offset: 0x000305D2
		[Property("use-alpha")]
		public bool UseAlpha
		{
			get
			{
				return ColorButton.gtk_color_chooser_get_use_alpha(base.Handle);
			}
			set
			{
				ColorButton.gtk_color_chooser_set_use_alpha(base.Handle, value);
			}
		}

		// Token: 0x14000068 RID: 104
		// (add) Token: 0x060010D3 RID: 4307 RVA: 0x000323E5 File Offset: 0x000305E5
		// (remove) Token: 0x060010D4 RID: 4308 RVA: 0x000323FD File Offset: 0x000305FD
		[Signal("color-activated")]
		public event ColorActivatedHandler ColorActivated
		{
			add
			{
				base.AddSignalHandler("color-activated", value, typeof(ColorActivatedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("color-activated", value);
			}
		}

		// Token: 0x170003DD RID: 989
		// (get) Token: 0x060010D5 RID: 4309 RVA: 0x0003240B File Offset: 0x0003060B
		private static ColorButton.ColorActivatedNativeDelegate ColorActivatedVMCallback
		{
			get
			{
				if (ColorButton.ColorActivated_cb_delegate == null)
				{
					ColorButton.ColorActivated_cb_delegate = new ColorButton.ColorActivatedNativeDelegate(ColorButton.ColorActivated_cb);
				}
				return ColorButton.ColorActivated_cb_delegate;
			}
		}

		// Token: 0x060010D6 RID: 4310 RVA: 0x0003242A File Offset: 0x0003062A
		private static void OverrideColorActivated(GType gtype)
		{
			ColorButton.OverrideColorActivated(gtype, ColorButton.ColorActivatedVMCallback);
		}

		// Token: 0x060010D7 RID: 4311 RVA: 0x00032437 File Offset: 0x00030637
		private static void OverrideColorActivated(GType gtype, ColorButton.ColorActivatedNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "color-activated", callback);
		}

		// Token: 0x060010D8 RID: 4312 RVA: 0x00032448 File Offset: 0x00030648
		private static void ColorActivated_cb(IntPtr inst, IntPtr color)
		{
			try
			{
				(Object.GetObject(inst, false) as ColorButton).OnColorActivated(RGBA.New(color));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060010D9 RID: 4313 RVA: 0x00032488 File Offset: 0x00030688
		[DefaultSignalHandler(Type = typeof(ColorButton), ConnectionMethod = "OverrideColorActivated")]
		protected virtual void OnColorActivated(RGBA color)
		{
			this.InternalColorActivated(color);
		}

		// Token: 0x060010DA RID: 4314 RVA: 0x00032494 File Offset: 0x00030694
		private void InternalColorActivated(RGBA color)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(2U);
			Value[] array = new Value[2];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(color);
			valueArray.Append(array[1]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x170003DE RID: 990
		// (get) Token: 0x060010DB RID: 4315 RVA: 0x00032528 File Offset: 0x00030728
		public new static AbiStruct abi_info
		{
			get
			{
				if (ColorButton._abi_info == null)
				{
					ColorButton._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Button.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return ColorButton._abi_info;
			}
		}

		// Token: 0x040007D6 RID: 2006
		private static ColorButton.d_gtk_color_button_new gtk_color_button_new = FuncLoader.LoadFunction<ColorButton.d_gtk_color_button_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_button_new"));

		// Token: 0x040007D7 RID: 2007
		private static ColorButton.d_gtk_color_button_new_with_color gtk_color_button_new_with_color = FuncLoader.LoadFunction<ColorButton.d_gtk_color_button_new_with_color>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_button_new_with_color"));

		// Token: 0x040007D8 RID: 2008
		private static ColorButton.d_gtk_color_button_new_with_rgba gtk_color_button_new_with_rgba = FuncLoader.LoadFunction<ColorButton.d_gtk_color_button_new_with_rgba>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_button_new_with_rgba"));

		// Token: 0x040007D9 RID: 2009
		private static ColorButton.d_gtk_color_button_get_title gtk_color_button_get_title = FuncLoader.LoadFunction<ColorButton.d_gtk_color_button_get_title>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_button_get_title"));

		// Token: 0x040007DA RID: 2010
		private static ColorButton.d_gtk_color_button_set_title gtk_color_button_set_title = FuncLoader.LoadFunction<ColorButton.d_gtk_color_button_set_title>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_button_set_title"));

		// Token: 0x040007DB RID: 2011
		private static ColorButton.d_gtk_color_button_get_color gtk_color_button_get_color = FuncLoader.LoadFunction<ColorButton.d_gtk_color_button_get_color>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_button_get_color"));

		// Token: 0x040007DC RID: 2012
		private static ColorButton.d_gtk_color_button_set_color gtk_color_button_set_color = FuncLoader.LoadFunction<ColorButton.d_gtk_color_button_set_color>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_button_set_color"));

		// Token: 0x040007DD RID: 2013
		private static ColorButton.d_gtk_color_button_get_alpha gtk_color_button_get_alpha = FuncLoader.LoadFunction<ColorButton.d_gtk_color_button_get_alpha>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_button_get_alpha"));

		// Token: 0x040007DE RID: 2014
		private static ColorButton.d_gtk_color_button_set_alpha gtk_color_button_set_alpha = FuncLoader.LoadFunction<ColorButton.d_gtk_color_button_set_alpha>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_button_set_alpha"));

		// Token: 0x040007DF RID: 2015
		private static ColorButton.ColorSetNativeDelegate ColorSet_cb_delegate;

		// Token: 0x040007E0 RID: 2016
		private static AbiStruct _class_abi = null;

		// Token: 0x040007E1 RID: 2017
		private static ColorButton.d_gtk_color_button_get_type gtk_color_button_get_type = FuncLoader.LoadFunction<ColorButton.d_gtk_color_button_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_button_get_type"));

		// Token: 0x040007E2 RID: 2018
		private static ColorButton.d_gtk_color_chooser_add_palette gtk_color_chooser_add_palette = FuncLoader.LoadFunction<ColorButton.d_gtk_color_chooser_add_palette>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_add_palette"));

		// Token: 0x040007E3 RID: 2019
		private static ColorButton.d_gtk_color_chooser_get_rgba gtk_color_chooser_get_rgba = FuncLoader.LoadFunction<ColorButton.d_gtk_color_chooser_get_rgba>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_get_rgba"));

		// Token: 0x040007E4 RID: 2020
		private static ColorButton.d_gtk_color_chooser_set_rgba gtk_color_chooser_set_rgba = FuncLoader.LoadFunction<ColorButton.d_gtk_color_chooser_set_rgba>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_set_rgba"));

		// Token: 0x040007E5 RID: 2021
		private static ColorButton.d_gtk_color_chooser_get_use_alpha gtk_color_chooser_get_use_alpha = FuncLoader.LoadFunction<ColorButton.d_gtk_color_chooser_get_use_alpha>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_get_use_alpha"));

		// Token: 0x040007E6 RID: 2022
		private static ColorButton.d_gtk_color_chooser_set_use_alpha gtk_color_chooser_set_use_alpha = FuncLoader.LoadFunction<ColorButton.d_gtk_color_chooser_set_use_alpha>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_color_chooser_set_use_alpha"));

		// Token: 0x040007E7 RID: 2023
		private static ColorButton.ColorActivatedNativeDelegate ColorActivated_cb_delegate;

		// Token: 0x040007E8 RID: 2024
		private static AbiStruct _abi_info = null;

		// Token: 0x02000B3A RID: 2874
		// (Invoke) Token: 0x060053F5 RID: 21493
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_color_button_new();

		// Token: 0x02000B3B RID: 2875
		// (Invoke) Token: 0x060053F9 RID: 21497
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_color_button_new_with_color(IntPtr color);

		// Token: 0x02000B3C RID: 2876
		// (Invoke) Token: 0x060053FD RID: 21501
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_color_button_new_with_rgba(IntPtr rgba);

		// Token: 0x02000B3D RID: 2877
		// (Invoke) Token: 0x06005401 RID: 21505
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_color_button_get_title(IntPtr raw);

		// Token: 0x02000B3E RID: 2878
		// (Invoke) Token: 0x06005405 RID: 21509
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_button_set_title(IntPtr raw, IntPtr title);

		// Token: 0x02000B3F RID: 2879
		// (Invoke) Token: 0x06005409 RID: 21513
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_button_get_color(IntPtr raw, IntPtr color);

		// Token: 0x02000B40 RID: 2880
		// (Invoke) Token: 0x0600540D RID: 21517
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_button_set_color(IntPtr raw, IntPtr value);

		// Token: 0x02000B41 RID: 2881
		// (Invoke) Token: 0x06005411 RID: 21521
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate ushort d_gtk_color_button_get_alpha(IntPtr raw);

		// Token: 0x02000B42 RID: 2882
		// (Invoke) Token: 0x06005415 RID: 21525
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_button_set_alpha(IntPtr raw, ushort alpha);

		// Token: 0x02000B43 RID: 2883
		// (Invoke) Token: 0x06005419 RID: 21529
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ColorSetNativeDelegate(IntPtr inst);

		// Token: 0x02000B44 RID: 2884
		// (Invoke) Token: 0x0600541D RID: 21533
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_color_button_get_type();

		// Token: 0x02000B45 RID: 2885
		// (Invoke) Token: 0x06005421 RID: 21537
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_chooser_add_palette(IntPtr raw, int orientation, int colors_per_line, int n_colors, IntPtr colors);

		// Token: 0x02000B46 RID: 2886
		// (Invoke) Token: 0x06005425 RID: 21541
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_chooser_get_rgba(IntPtr raw, IntPtr color);

		// Token: 0x02000B47 RID: 2887
		// (Invoke) Token: 0x06005429 RID: 21545
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_chooser_set_rgba(IntPtr raw, IntPtr value);

		// Token: 0x02000B48 RID: 2888
		// (Invoke) Token: 0x0600542D RID: 21549
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_color_chooser_get_use_alpha(IntPtr raw);

		// Token: 0x02000B49 RID: 2889
		// (Invoke) Token: 0x06005431 RID: 21553
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_color_chooser_set_use_alpha(IntPtr raw, bool use_alpha);

		// Token: 0x02000B4A RID: 2890
		// (Invoke) Token: 0x06005435 RID: 21557
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ColorActivatedNativeDelegate(IntPtr inst, IntPtr color);
	}
}
