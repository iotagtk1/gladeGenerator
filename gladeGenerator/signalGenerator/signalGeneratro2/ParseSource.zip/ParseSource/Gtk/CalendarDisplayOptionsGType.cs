﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x02000160 RID: 352
	internal class CalendarDisplayOptionsGType
	{
		// Token: 0x1700032C RID: 812
		// (get) Token: 0x06000E67 RID: 3687 RVA: 0x0002B157 File Offset: 0x00029357
		public static GType GType
		{
			get
			{
				return new GType(CalendarDisplayOptionsGType.gtk_calendar_display_options_get_type());
			}
		}

		// Token: 0x04000731 RID: 1841
		private static CalendarDisplayOptionsGType.d_gtk_calendar_display_options_get_type gtk_calendar_display_options_get_type = FuncLoader.LoadFunction<CalendarDisplayOptionsGType.d_gtk_calendar_display_options_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_calendar_display_options_get_type"));

		// Token: 0x02000AC1 RID: 2753
		// (Invoke) Token: 0x06005215 RID: 21013
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_calendar_display_options_get_type();
	}
}
