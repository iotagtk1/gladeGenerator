﻿using System;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x02000221 RID: 545
	public class DeleteEventArgs : SignalArgs
	{
		// Token: 0x17000475 RID: 1141
		// (get) Token: 0x06001272 RID: 4722 RVA: 0x0003523C File Offset: 0x0003343C
		public Event Event
		{
			get
			{
				return (Event)base.Args[0];
			}
		}
	}
}
