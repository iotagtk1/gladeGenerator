﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000146 RID: 326
	[GType(typeof(BorderStyleGType))]
	public enum BorderStyle
	{
		// Token: 0x040006D6 RID: 1750
		None,
		// Token: 0x040006D7 RID: 1751
		Solid,
		// Token: 0x040006D8 RID: 1752
		Inset,
		// Token: 0x040006D9 RID: 1753
		Outset,
		// Token: 0x040006DA RID: 1754
		Hidden,
		// Token: 0x040006DB RID: 1755
		Dotted,
		// Token: 0x040006DC RID: 1756
		Dashed,
		// Token: 0x040006DD RID: 1757
		Double,
		// Token: 0x040006DE RID: 1758
		Groove,
		// Token: 0x040006DF RID: 1759
		Ridge
	}
}
