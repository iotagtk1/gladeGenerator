﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001CD RID: 461
	public class CssImageFallback : Opaque
	{
		// Token: 0x06001195 RID: 4501 RVA: 0x00033E93 File Offset: 0x00032093
		public CssImageFallback(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700041E RID: 1054
		// (get) Token: 0x06001196 RID: 4502 RVA: 0x00033E9C File Offset: 0x0003209C
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImageFallback._abi_info == null)
				{
					CssImageFallback._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImageFallback._abi_info;
			}
		}

		// Token: 0x0400082D RID: 2093
		private static AbiStruct _abi_info;
	}
}
