﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x02000145 RID: 325
	public class BorderImageSliceSize : Opaque
	{
		// Token: 0x06000E00 RID: 3584 RVA: 0x0002A258 File Offset: 0x00028458
		public BorderImageSliceSize(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000307 RID: 775
		// (get) Token: 0x06000E01 RID: 3585 RVA: 0x0002A261 File Offset: 0x00028461
		public static AbiStruct abi_info
		{
			get
			{
				if (BorderImageSliceSize._abi_info == null)
				{
					BorderImageSliceSize._abi_info = new AbiStruct(new List<AbiField>());
				}
				return BorderImageSliceSize._abi_info;
			}
		}

		// Token: 0x040006D4 RID: 1748
		private static AbiStruct _abi_info;
	}
}
