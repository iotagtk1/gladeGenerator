﻿using System;

namespace Gtk
{
	// Token: 0x02000141 RID: 321
	// (Invoke) Token: 0x06000DE7 RID: 3559
	public delegate void BookmarksChangedFunc();
}
