﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000111 RID: 273
	public class ActivateCursorItemArgs : SignalArgs
	{
	}
}
