﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x02000108 RID: 264
	public class ActionBar : Bin
	{
		// Token: 0x06000BC5 RID: 3013 RVA: 0x000238AE File Offset: 0x00021AAE
		public ActionBar(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000BC6 RID: 3014 RVA: 0x000238B8 File Offset: 0x00021AB8
		public ActionBar() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(ActionBar))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = ActionBar.gtk_action_bar_new();
		}

		// Token: 0x17000271 RID: 625
		public override Container.ContainerChild this[Widget child]
		{
			get
			{
				return new ActionBar.ActionBarChild(this, child);
			}
		}

		// Token: 0x17000272 RID: 626
		// (get) Token: 0x06000BC8 RID: 3016 RVA: 0x00023914 File Offset: 0x00021B14
		public new static AbiStruct class_abi
		{
			get
			{
				if (ActionBar._class_abi == null)
				{
					ActionBar._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("_gtk_reserved1", Bin.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "_gtk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved1", "_gtk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved2", "_gtk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gtk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gtk_reserved3", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return ActionBar._class_abi;
			}
		}

		// Token: 0x17000273 RID: 627
		// (get) Token: 0x06000BC9 RID: 3017 RVA: 0x00023A2F File Offset: 0x00021C2F
		// (set) Token: 0x06000BCA RID: 3018 RVA: 0x00023A4B File Offset: 0x00021C4B
		public Widget CenterWidget
		{
			get
			{
				return Object.GetObject(ActionBar.gtk_action_bar_get_center_widget(base.Handle)) as Widget;
			}
			set
			{
				ActionBar.gtk_action_bar_set_center_widget(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x17000274 RID: 628
		// (get) Token: 0x06000BCB RID: 3019 RVA: 0x00023A70 File Offset: 0x00021C70
		public new static GType GType
		{
			get
			{
				IntPtr val = ActionBar.gtk_action_bar_get_type();
				return new GType(val);
			}
		}

		// Token: 0x06000BCC RID: 3020 RVA: 0x00023A8E File Offset: 0x00021C8E
		public void PackEnd(Widget child)
		{
			ActionBar.gtk_action_bar_pack_end(base.Handle, (child == null) ? IntPtr.Zero : child.Handle);
		}

		// Token: 0x06000BCD RID: 3021 RVA: 0x00023AB0 File Offset: 0x00021CB0
		public void PackStart(Widget child)
		{
			ActionBar.gtk_action_bar_pack_start(base.Handle, (child == null) ? IntPtr.Zero : child.Handle);
		}

		// Token: 0x17000275 RID: 629
		// (get) Token: 0x06000BCE RID: 3022 RVA: 0x00023AD2 File Offset: 0x00021CD2
		public new static AbiStruct abi_info
		{
			get
			{
				if (ActionBar._abi_info == null)
				{
					ActionBar._abi_info = new AbiStruct(Bin.abi_info.Fields);
				}
				return ActionBar._abi_info;
			}
		}

		// Token: 0x040005B8 RID: 1464
		private static ActionBar.d_gtk_action_bar_new gtk_action_bar_new = FuncLoader.LoadFunction<ActionBar.d_gtk_action_bar_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_bar_new"));

		// Token: 0x040005B9 RID: 1465
		private static AbiStruct _class_abi = null;

		// Token: 0x040005BA RID: 1466
		private static ActionBar.d_gtk_action_bar_get_center_widget gtk_action_bar_get_center_widget = FuncLoader.LoadFunction<ActionBar.d_gtk_action_bar_get_center_widget>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_bar_get_center_widget"));

		// Token: 0x040005BB RID: 1467
		private static ActionBar.d_gtk_action_bar_set_center_widget gtk_action_bar_set_center_widget = FuncLoader.LoadFunction<ActionBar.d_gtk_action_bar_set_center_widget>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_bar_set_center_widget"));

		// Token: 0x040005BC RID: 1468
		private static ActionBar.d_gtk_action_bar_get_type gtk_action_bar_get_type = FuncLoader.LoadFunction<ActionBar.d_gtk_action_bar_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_bar_get_type"));

		// Token: 0x040005BD RID: 1469
		private static ActionBar.d_gtk_action_bar_pack_end gtk_action_bar_pack_end = FuncLoader.LoadFunction<ActionBar.d_gtk_action_bar_pack_end>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_bar_pack_end"));

		// Token: 0x040005BE RID: 1470
		private static ActionBar.d_gtk_action_bar_pack_start gtk_action_bar_pack_start = FuncLoader.LoadFunction<ActionBar.d_gtk_action_bar_pack_start>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_action_bar_pack_start"));

		// Token: 0x040005BF RID: 1471
		private static AbiStruct _abi_info = null;

		// Token: 0x020009CD RID: 2509
		// (Invoke) Token: 0x06004E46 RID: 20038
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_bar_new();

		// Token: 0x020009CE RID: 2510
		public class ActionBarChild : Container.ContainerChild
		{
			// Token: 0x06004E49 RID: 20041 RVA: 0x000B6410 File Offset: 0x000B4610
			protected internal ActionBarChild(Container parent, Widget child) : base(parent, child)
			{
			}

			// Token: 0x170011A2 RID: 4514
			// (get) Token: 0x06004E4A RID: 20042 RVA: 0x000B641C File Offset: 0x000B461C
			// (set) Token: 0x06004E4B RID: 20043 RVA: 0x000B6454 File Offset: 0x000B4654
			[ChildProperty("pack-type")]
			public PackType PackType
			{
				get
				{
					Value val = this.parent.ChildGetProperty(this.child, "pack-type");
					PackType result = (PackType)((Enum)val);
					val.Dispose();
					return result;
				}
				set
				{
					Value value2 = new Value(value);
					this.parent.ChildSetProperty(this.child, "pack-type", value2);
					value2.Dispose();
				}
			}

			// Token: 0x170011A3 RID: 4515
			// (get) Token: 0x06004E4C RID: 20044 RVA: 0x000B648C File Offset: 0x000B468C
			// (set) Token: 0x06004E4D RID: 20045 RVA: 0x000B64C0 File Offset: 0x000B46C0
			[ChildProperty("position")]
			public int Position
			{
				get
				{
					Value val = this.parent.ChildGetProperty(this.child, "position");
					int result = (int)val;
					val.Dispose();
					return result;
				}
				set
				{
					Value value2 = new Value(value);
					this.parent.ChildSetProperty(this.child, "position", value2);
					value2.Dispose();
				}
			}
		}

		// Token: 0x020009CF RID: 2511
		// (Invoke) Token: 0x06004E4F RID: 20047
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_bar_get_center_widget(IntPtr raw);

		// Token: 0x020009D0 RID: 2512
		// (Invoke) Token: 0x06004E53 RID: 20051
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_bar_set_center_widget(IntPtr raw, IntPtr center_widget);

		// Token: 0x020009D1 RID: 2513
		// (Invoke) Token: 0x06004E57 RID: 20055
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_action_bar_get_type();

		// Token: 0x020009D2 RID: 2514
		// (Invoke) Token: 0x06004E5B RID: 20059
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_bar_pack_end(IntPtr raw, IntPtr child);

		// Token: 0x020009D3 RID: 2515
		// (Invoke) Token: 0x06004E5F RID: 20063
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_action_bar_pack_start(IntPtr raw, IntPtr child);
	}
}
