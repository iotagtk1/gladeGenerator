﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gtk
{
	// Token: 0x02000120 RID: 288
	public class AppChooserButton : ComboBox, IAppChooser, IWrapper
	{
		// Token: 0x06000CAE RID: 3246 RVA: 0x00026455 File Offset: 0x00024655
		public AppChooserButton(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000CAF RID: 3247 RVA: 0x00026460 File Offset: 0x00024660
		public AppChooserButton(string content_type) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(AppChooserButton))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(content_type);
			this.Raw = AppChooserButton.gtk_app_chooser_button_new(intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x170002AC RID: 684
		// (get) Token: 0x06000CB0 RID: 3248 RVA: 0x000264CC File Offset: 0x000246CC
		// (set) Token: 0x06000CB1 RID: 3249 RVA: 0x000264DE File Offset: 0x000246DE
		[Property("show-dialog-item")]
		public bool ShowDialogItem
		{
			get
			{
				return AppChooserButton.gtk_app_chooser_button_get_show_dialog_item(base.Handle);
			}
			set
			{
				AppChooserButton.gtk_app_chooser_button_set_show_dialog_item(base.Handle, value);
			}
		}

		// Token: 0x170002AD RID: 685
		// (get) Token: 0x06000CB2 RID: 3250 RVA: 0x000264F1 File Offset: 0x000246F1
		// (set) Token: 0x06000CB3 RID: 3251 RVA: 0x00026503 File Offset: 0x00024703
		[Property("show-default-item")]
		public bool ShowDefaultItem
		{
			get
			{
				return AppChooserButton.gtk_app_chooser_button_get_show_default_item(base.Handle);
			}
			set
			{
				AppChooserButton.gtk_app_chooser_button_set_show_default_item(base.Handle, value);
			}
		}

		// Token: 0x170002AE RID: 686
		// (get) Token: 0x06000CB4 RID: 3252 RVA: 0x00026516 File Offset: 0x00024716
		// (set) Token: 0x06000CB5 RID: 3253 RVA: 0x00026530 File Offset: 0x00024730
		[Property("heading")]
		public string Heading
		{
			get
			{
				return Marshaller.Utf8PtrToString(AppChooserButton.gtk_app_chooser_button_get_heading(base.Handle));
			}
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				AppChooserButton.gtk_app_chooser_button_set_heading(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x14000053 RID: 83
		// (add) Token: 0x06000CB6 RID: 3254 RVA: 0x0002655B File Offset: 0x0002475B
		// (remove) Token: 0x06000CB7 RID: 3255 RVA: 0x00026573 File Offset: 0x00024773
		[Signal("custom-item-activated")]
		public event CustomItemActivatedHandler CustomItemActivated
		{
			add
			{
				base.AddSignalHandler("custom-item-activated", value, typeof(CustomItemActivatedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("custom-item-activated", value);
			}
		}

		// Token: 0x170002AF RID: 687
		// (get) Token: 0x06000CB8 RID: 3256 RVA: 0x00026581 File Offset: 0x00024781
		private static AppChooserButton.CustomItemActivatedNativeDelegate CustomItemActivatedVMCallback
		{
			get
			{
				if (AppChooserButton.CustomItemActivated_cb_delegate == null)
				{
					AppChooserButton.CustomItemActivated_cb_delegate = new AppChooserButton.CustomItemActivatedNativeDelegate(AppChooserButton.CustomItemActivated_cb);
				}
				return AppChooserButton.CustomItemActivated_cb_delegate;
			}
		}

		// Token: 0x06000CB9 RID: 3257 RVA: 0x000265A0 File Offset: 0x000247A0
		private static void OverrideCustomItemActivated(GType gtype)
		{
			AppChooserButton.OverrideCustomItemActivated(gtype, AppChooserButton.CustomItemActivatedVMCallback);
		}

		// Token: 0x06000CBA RID: 3258 RVA: 0x000265B0 File Offset: 0x000247B0
		private unsafe static void OverrideCustomItemActivated(GType gtype, AppChooserButton.CustomItemActivatedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + AppChooserButton.class_abi.GetFieldOffset("custom_item_activated");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000CBB RID: 3259 RVA: 0x000265E4 File Offset: 0x000247E4
		private static void CustomItemActivated_cb(IntPtr inst, IntPtr item_name)
		{
			try
			{
				(Object.GetObject(inst, false) as AppChooserButton).OnCustomItemActivated(Marshaller.Utf8PtrToString(item_name));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000CBC RID: 3260 RVA: 0x00026624 File Offset: 0x00024824
		[DefaultSignalHandler(Type = typeof(AppChooserButton), ConnectionMethod = "OverrideCustomItemActivated")]
		protected virtual void OnCustomItemActivated(string item_name)
		{
			this.InternalCustomItemActivated(item_name);
		}

		// Token: 0x06000CBD RID: 3261 RVA: 0x00026630 File Offset: 0x00024830
		private void InternalCustomItemActivated(string item_name)
		{
			AppChooserButton.CustomItemActivatedNativeDelegate customItemActivatedNativeDelegate = AppChooserButton.class_abi.BaseOverride(base.LookupGType(), "custom_item_activated");
			if (customItemActivatedNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(item_name);
			customItemActivatedNativeDelegate(base.Handle, intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x170002B0 RID: 688
		// (get) Token: 0x06000CBE RID: 3262 RVA: 0x00026674 File Offset: 0x00024874
		public new static AbiStruct class_abi
		{
			get
			{
				if (AppChooserButton._class_abi == null)
				{
					AppChooserButton._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("custom_item_activated", ComboBox.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "padding", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("padding", -1L, (uint)(Marshal.SizeOf(typeof(IntPtr)) * 16), "custom_item_activated", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return AppChooserButton._class_abi;
			}
		}

		// Token: 0x06000CBF RID: 3263 RVA: 0x0002671C File Offset: 0x0002491C
		public void AppendCustomItem(string name, string label, IIcon icon)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(name);
			IntPtr intPtr2 = Marshaller.StringToPtrGStrdup(label);
			AppChooserButton.gtk_app_chooser_button_append_custom_item(base.Handle, intPtr, intPtr2, (icon == null) ? IntPtr.Zero : ((icon is Object) ? (icon as Object).Handle : (icon as IconAdapter).Handle));
			Marshaller.Free(intPtr);
			Marshaller.Free(intPtr2);
		}

		// Token: 0x06000CC0 RID: 3264 RVA: 0x0002677F File Offset: 0x0002497F
		public void AppendSeparator()
		{
			AppChooserButton.gtk_app_chooser_button_append_separator(base.Handle);
		}

		// Token: 0x170002B1 RID: 689
		// (get) Token: 0x06000CC1 RID: 3265 RVA: 0x00026794 File Offset: 0x00024994
		public new static GType GType
		{
			get
			{
				IntPtr val = AppChooserButton.gtk_app_chooser_button_get_type();
				return new GType(val);
			}
		}

		// Token: 0x170002B2 RID: 690
		// (set) Token: 0x06000CC2 RID: 3266 RVA: 0x000267B4 File Offset: 0x000249B4
		public string ActiveCustomItem
		{
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				AppChooserButton.gtk_app_chooser_button_set_active_custom_item(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x170002B3 RID: 691
		// (get) Token: 0x06000CC3 RID: 3267 RVA: 0x000267DF File Offset: 0x000249DF
		public IAppInfo AppInfo
		{
			get
			{
				return AppInfoAdapter.GetObject(AppChooserButton.gtk_app_chooser_get_app_info(base.Handle), false);
			}
		}

		// Token: 0x170002B4 RID: 692
		// (get) Token: 0x06000CC4 RID: 3268 RVA: 0x000267F7 File Offset: 0x000249F7
		public string ContentType
		{
			get
			{
				return Marshaller.PtrToStringGFree(AppChooserButton.gtk_app_chooser_get_content_type(base.Handle));
			}
		}

		// Token: 0x06000CC5 RID: 3269 RVA: 0x0002680E File Offset: 0x00024A0E
		public void Refresh()
		{
			AppChooserButton.gtk_app_chooser_refresh(base.Handle);
		}

		// Token: 0x170002B5 RID: 693
		// (get) Token: 0x06000CC6 RID: 3270 RVA: 0x00026820 File Offset: 0x00024A20
		public new static AbiStruct abi_info
		{
			get
			{
				if (AppChooserButton._abi_info == null)
				{
					AppChooserButton._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", ComboBox.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return AppChooserButton._abi_info;
			}
		}

		// Token: 0x0400061D RID: 1565
		private static AppChooserButton.d_gtk_app_chooser_button_new gtk_app_chooser_button_new = FuncLoader.LoadFunction<AppChooserButton.d_gtk_app_chooser_button_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_button_new"));

		// Token: 0x0400061E RID: 1566
		private static AppChooserButton.d_gtk_app_chooser_button_get_show_dialog_item gtk_app_chooser_button_get_show_dialog_item = FuncLoader.LoadFunction<AppChooserButton.d_gtk_app_chooser_button_get_show_dialog_item>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_button_get_show_dialog_item"));

		// Token: 0x0400061F RID: 1567
		private static AppChooserButton.d_gtk_app_chooser_button_set_show_dialog_item gtk_app_chooser_button_set_show_dialog_item = FuncLoader.LoadFunction<AppChooserButton.d_gtk_app_chooser_button_set_show_dialog_item>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_button_set_show_dialog_item"));

		// Token: 0x04000620 RID: 1568
		private static AppChooserButton.d_gtk_app_chooser_button_get_show_default_item gtk_app_chooser_button_get_show_default_item = FuncLoader.LoadFunction<AppChooserButton.d_gtk_app_chooser_button_get_show_default_item>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_button_get_show_default_item"));

		// Token: 0x04000621 RID: 1569
		private static AppChooserButton.d_gtk_app_chooser_button_set_show_default_item gtk_app_chooser_button_set_show_default_item = FuncLoader.LoadFunction<AppChooserButton.d_gtk_app_chooser_button_set_show_default_item>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_button_set_show_default_item"));

		// Token: 0x04000622 RID: 1570
		private static AppChooserButton.d_gtk_app_chooser_button_get_heading gtk_app_chooser_button_get_heading = FuncLoader.LoadFunction<AppChooserButton.d_gtk_app_chooser_button_get_heading>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_button_get_heading"));

		// Token: 0x04000623 RID: 1571
		private static AppChooserButton.d_gtk_app_chooser_button_set_heading gtk_app_chooser_button_set_heading = FuncLoader.LoadFunction<AppChooserButton.d_gtk_app_chooser_button_set_heading>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_button_set_heading"));

		// Token: 0x04000624 RID: 1572
		private static AppChooserButton.CustomItemActivatedNativeDelegate CustomItemActivated_cb_delegate;

		// Token: 0x04000625 RID: 1573
		private static AbiStruct _class_abi = null;

		// Token: 0x04000626 RID: 1574
		private static AppChooserButton.d_gtk_app_chooser_button_append_custom_item gtk_app_chooser_button_append_custom_item = FuncLoader.LoadFunction<AppChooserButton.d_gtk_app_chooser_button_append_custom_item>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_button_append_custom_item"));

		// Token: 0x04000627 RID: 1575
		private static AppChooserButton.d_gtk_app_chooser_button_append_separator gtk_app_chooser_button_append_separator = FuncLoader.LoadFunction<AppChooserButton.d_gtk_app_chooser_button_append_separator>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_button_append_separator"));

		// Token: 0x04000628 RID: 1576
		private static AppChooserButton.d_gtk_app_chooser_button_get_type gtk_app_chooser_button_get_type = FuncLoader.LoadFunction<AppChooserButton.d_gtk_app_chooser_button_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_button_get_type"));

		// Token: 0x04000629 RID: 1577
		private static AppChooserButton.d_gtk_app_chooser_button_set_active_custom_item gtk_app_chooser_button_set_active_custom_item = FuncLoader.LoadFunction<AppChooserButton.d_gtk_app_chooser_button_set_active_custom_item>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_button_set_active_custom_item"));

		// Token: 0x0400062A RID: 1578
		private static AppChooserButton.d_gtk_app_chooser_get_app_info gtk_app_chooser_get_app_info = FuncLoader.LoadFunction<AppChooserButton.d_gtk_app_chooser_get_app_info>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_get_app_info"));

		// Token: 0x0400062B RID: 1579
		private static AppChooserButton.d_gtk_app_chooser_get_content_type gtk_app_chooser_get_content_type = FuncLoader.LoadFunction<AppChooserButton.d_gtk_app_chooser_get_content_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_get_content_type"));

		// Token: 0x0400062C RID: 1580
		private static AppChooserButton.d_gtk_app_chooser_refresh gtk_app_chooser_refresh = FuncLoader.LoadFunction<AppChooserButton.d_gtk_app_chooser_refresh>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gtk), "gtk_app_chooser_refresh"));

		// Token: 0x0400062D RID: 1581
		private static AbiStruct _abi_info = null;

		// Token: 0x02000A26 RID: 2598
		// (Invoke) Token: 0x06004F9F RID: 20383
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_app_chooser_button_new(IntPtr content_type);

		// Token: 0x02000A27 RID: 2599
		// (Invoke) Token: 0x06004FA3 RID: 20387
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_app_chooser_button_get_show_dialog_item(IntPtr raw);

		// Token: 0x02000A28 RID: 2600
		// (Invoke) Token: 0x06004FA7 RID: 20391
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_app_chooser_button_set_show_dialog_item(IntPtr raw, bool setting);

		// Token: 0x02000A29 RID: 2601
		// (Invoke) Token: 0x06004FAB RID: 20395
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gtk_app_chooser_button_get_show_default_item(IntPtr raw);

		// Token: 0x02000A2A RID: 2602
		// (Invoke) Token: 0x06004FAF RID: 20399
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_app_chooser_button_set_show_default_item(IntPtr raw, bool setting);

		// Token: 0x02000A2B RID: 2603
		// (Invoke) Token: 0x06004FB3 RID: 20403
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_app_chooser_button_get_heading(IntPtr raw);

		// Token: 0x02000A2C RID: 2604
		// (Invoke) Token: 0x06004FB7 RID: 20407
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_app_chooser_button_set_heading(IntPtr raw, IntPtr heading);

		// Token: 0x02000A2D RID: 2605
		// (Invoke) Token: 0x06004FBB RID: 20411
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void CustomItemActivatedNativeDelegate(IntPtr inst, IntPtr item_name);

		// Token: 0x02000A2E RID: 2606
		// (Invoke) Token: 0x06004FBF RID: 20415
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_app_chooser_button_append_custom_item(IntPtr raw, IntPtr name, IntPtr label, IntPtr icon);

		// Token: 0x02000A2F RID: 2607
		// (Invoke) Token: 0x06004FC3 RID: 20419
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_app_chooser_button_append_separator(IntPtr raw);

		// Token: 0x02000A30 RID: 2608
		// (Invoke) Token: 0x06004FC7 RID: 20423
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_app_chooser_button_get_type();

		// Token: 0x02000A31 RID: 2609
		// (Invoke) Token: 0x06004FCB RID: 20427
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_app_chooser_button_set_active_custom_item(IntPtr raw, IntPtr name);

		// Token: 0x02000A32 RID: 2610
		// (Invoke) Token: 0x06004FCF RID: 20431
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_app_chooser_get_app_info(IntPtr raw);

		// Token: 0x02000A33 RID: 2611
		// (Invoke) Token: 0x06004FD3 RID: 20435
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gtk_app_chooser_get_content_type(IntPtr raw);

		// Token: 0x02000A34 RID: 2612
		// (Invoke) Token: 0x06004FD7 RID: 20439
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gtk_app_chooser_refresh(IntPtr raw);
	}
}
