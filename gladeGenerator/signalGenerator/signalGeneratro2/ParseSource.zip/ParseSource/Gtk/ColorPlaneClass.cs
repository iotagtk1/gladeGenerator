﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001A0 RID: 416
	public class ColorPlaneClass : Opaque
	{
		// Token: 0x06001121 RID: 4385 RVA: 0x000336EC File Offset: 0x000318EC
		public ColorPlaneClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170003F7 RID: 1015
		// (get) Token: 0x06001122 RID: 4386 RVA: 0x000336F5 File Offset: 0x000318F5
		public static AbiStruct abi_info
		{
			get
			{
				if (ColorPlaneClass._abi_info == null)
				{
					ColorPlaneClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return ColorPlaneClass._abi_info;
			}
		}

		// Token: 0x0400080A RID: 2058
		private static AbiStruct _abi_info;
	}
}
