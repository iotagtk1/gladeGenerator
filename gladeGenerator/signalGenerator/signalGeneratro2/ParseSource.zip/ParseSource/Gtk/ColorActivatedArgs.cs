﻿using System;
using Gdk;
using GLib;

namespace Gtk
{
	// Token: 0x02000198 RID: 408
	public class ColorActivatedArgs : SignalArgs
	{
		// Token: 0x170003D2 RID: 978
		// (get) Token: 0x060010B4 RID: 4276 RVA: 0x00031DA3 File Offset: 0x0002FFA3
		public RGBA Color
		{
			get
			{
				return (RGBA)base.Args[0];
			}
		}
	}
}
