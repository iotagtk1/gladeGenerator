﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x02000188 RID: 392
	public class ChildAnchorInsertedArgs : SignalArgs
	{
		// Token: 0x170003CC RID: 972
		// (get) Token: 0x0600107D RID: 4221 RVA: 0x00031D12 File Offset: 0x0002FF12
		public TextIter Iter
		{
			get
			{
				return (TextIter)base.Args[0];
			}
		}

		// Token: 0x170003CD RID: 973
		// (get) Token: 0x0600107E RID: 4222 RVA: 0x00031D21 File Offset: 0x0002FF21
		public TextChildAnchor Anchor
		{
			get
			{
				return (TextChildAnchor)base.Args[1];
			}
		}
	}
}
