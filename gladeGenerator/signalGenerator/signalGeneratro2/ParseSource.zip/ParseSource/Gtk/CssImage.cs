﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gtk
{
	// Token: 0x020001C7 RID: 455
	public class CssImage : Opaque
	{
		// Token: 0x06001189 RID: 4489 RVA: 0x00033DAF File Offset: 0x00031FAF
		public CssImage(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000418 RID: 1048
		// (get) Token: 0x0600118A RID: 4490 RVA: 0x00033DB8 File Offset: 0x00031FB8
		public static AbiStruct abi_info
		{
			get
			{
				if (CssImage._abi_info == null)
				{
					CssImage._abi_info = new AbiStruct(new List<AbiField>());
				}
				return CssImage._abi_info;
			}
		}

		// Token: 0x04000827 RID: 2087
		private static AbiStruct _abi_info;
	}
}
