﻿using System;
using GLib;

namespace Gtk
{
	// Token: 0x0200012E RID: 302
	[GType(typeof(ArrowTypeGType))]
	public enum ArrowType
	{
		// Token: 0x0400067F RID: 1663
		Up,
		// Token: 0x04000680 RID: 1664
		Down,
		// Token: 0x04000681 RID: 1665
		Left,
		// Token: 0x04000682 RID: 1666
		Right,
		// Token: 0x04000683 RID: 1667
		None
	}
}
