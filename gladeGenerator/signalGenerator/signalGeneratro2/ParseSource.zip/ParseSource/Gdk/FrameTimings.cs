﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200008B RID: 139
	public class FrameTimings : Opaque
	{
		// Token: 0x1700017D RID: 381
		// (get) Token: 0x060005F6 RID: 1526 RVA: 0x00011CB9 File Offset: 0x0000FEB9
		public bool Complete
		{
			get
			{
				return FrameTimings.gdk_frame_timings_get_complete(base.Handle);
			}
		}

		// Token: 0x1700017E RID: 382
		// (get) Token: 0x060005F7 RID: 1527 RVA: 0x00011CCB File Offset: 0x0000FECB
		public long FrameCounter
		{
			get
			{
				return FrameTimings.gdk_frame_timings_get_frame_counter(base.Handle);
			}
		}

		// Token: 0x1700017F RID: 383
		// (get) Token: 0x060005F8 RID: 1528 RVA: 0x00011CDD File Offset: 0x0000FEDD
		public long FrameTime
		{
			get
			{
				return FrameTimings.gdk_frame_timings_get_frame_time(base.Handle);
			}
		}

		// Token: 0x17000180 RID: 384
		// (get) Token: 0x060005F9 RID: 1529 RVA: 0x00011CEF File Offset: 0x0000FEEF
		public long PredictedPresentationTime
		{
			get
			{
				return FrameTimings.gdk_frame_timings_get_predicted_presentation_time(base.Handle);
			}
		}

		// Token: 0x17000181 RID: 385
		// (get) Token: 0x060005FA RID: 1530 RVA: 0x00011D01 File Offset: 0x0000FF01
		public long PresentationTime
		{
			get
			{
				return FrameTimings.gdk_frame_timings_get_presentation_time(base.Handle);
			}
		}

		// Token: 0x17000182 RID: 386
		// (get) Token: 0x060005FB RID: 1531 RVA: 0x00011D13 File Offset: 0x0000FF13
		public long RefreshInterval
		{
			get
			{
				return FrameTimings.gdk_frame_timings_get_refresh_interval(base.Handle);
			}
		}

		// Token: 0x17000183 RID: 387
		// (get) Token: 0x060005FC RID: 1532 RVA: 0x00011D28 File Offset: 0x0000FF28
		public static GType GType
		{
			get
			{
				IntPtr val = FrameTimings.gdk_frame_timings_get_type();
				return new GType(val);
			}
		}

		// Token: 0x060005FD RID: 1533 RVA: 0x00011D46 File Offset: 0x0000FF46
		public FrameTimings(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x060005FE RID: 1534 RVA: 0x00011D4F File Offset: 0x0000FF4F
		protected override void Ref(IntPtr raw)
		{
			if (!base.Owned)
			{
				FrameTimings.gdk_frame_timings_ref(raw);
				base.Owned = true;
			}
		}

		// Token: 0x060005FF RID: 1535 RVA: 0x00011D6C File Offset: 0x0000FF6C
		protected override void Unref(IntPtr raw)
		{
			if (base.Owned)
			{
				FrameTimings.gdk_frame_timings_unref(raw);
				base.Owned = false;
			}
		}

		// Token: 0x06000600 RID: 1536 RVA: 0x00011D88 File Offset: 0x0000FF88
		protected override void Finalize()
		{
			try
			{
				if (base.Owned)
				{
					FrameTimings.FinalizerInfo finalizerInfo = new FrameTimings.FinalizerInfo(base.Handle);
					finalizerInfo.timeoutHandlerId = Timeout.Add(50U, new TimeoutHandler(finalizerInfo.Handler));
				}
			}
			finally
			{
				base.Finalize();
			}
		}

		// Token: 0x17000184 RID: 388
		// (get) Token: 0x06000601 RID: 1537 RVA: 0x00011DE0 File Offset: 0x0000FFE0
		public static AbiStruct abi_info
		{
			get
			{
				if (FrameTimings._abi_info == null)
				{
					FrameTimings._abi_info = new AbiStruct(new List<AbiField>());
				}
				return FrameTimings._abi_info;
			}
		}

		// Token: 0x04000317 RID: 791
		private static FrameTimings.d_gdk_frame_timings_get_complete gdk_frame_timings_get_complete = FuncLoader.LoadFunction<FrameTimings.d_gdk_frame_timings_get_complete>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_timings_get_complete"));

		// Token: 0x04000318 RID: 792
		private static FrameTimings.d_gdk_frame_timings_get_frame_counter gdk_frame_timings_get_frame_counter = FuncLoader.LoadFunction<FrameTimings.d_gdk_frame_timings_get_frame_counter>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_timings_get_frame_counter"));

		// Token: 0x04000319 RID: 793
		private static FrameTimings.d_gdk_frame_timings_get_frame_time gdk_frame_timings_get_frame_time = FuncLoader.LoadFunction<FrameTimings.d_gdk_frame_timings_get_frame_time>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_timings_get_frame_time"));

		// Token: 0x0400031A RID: 794
		private static FrameTimings.d_gdk_frame_timings_get_predicted_presentation_time gdk_frame_timings_get_predicted_presentation_time = FuncLoader.LoadFunction<FrameTimings.d_gdk_frame_timings_get_predicted_presentation_time>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_timings_get_predicted_presentation_time"));

		// Token: 0x0400031B RID: 795
		private static FrameTimings.d_gdk_frame_timings_get_presentation_time gdk_frame_timings_get_presentation_time = FuncLoader.LoadFunction<FrameTimings.d_gdk_frame_timings_get_presentation_time>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_timings_get_presentation_time"));

		// Token: 0x0400031C RID: 796
		private static FrameTimings.d_gdk_frame_timings_get_refresh_interval gdk_frame_timings_get_refresh_interval = FuncLoader.LoadFunction<FrameTimings.d_gdk_frame_timings_get_refresh_interval>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_timings_get_refresh_interval"));

		// Token: 0x0400031D RID: 797
		private static FrameTimings.d_gdk_frame_timings_get_type gdk_frame_timings_get_type = FuncLoader.LoadFunction<FrameTimings.d_gdk_frame_timings_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_timings_get_type"));

		// Token: 0x0400031E RID: 798
		private static FrameTimings.d_gdk_frame_timings_ref gdk_frame_timings_ref = FuncLoader.LoadFunction<FrameTimings.d_gdk_frame_timings_ref>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_timings_ref"));

		// Token: 0x0400031F RID: 799
		private static FrameTimings.d_gdk_frame_timings_unref gdk_frame_timings_unref = FuncLoader.LoadFunction<FrameTimings.d_gdk_frame_timings_unref>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_timings_unref"));

		// Token: 0x04000320 RID: 800
		private static AbiStruct _abi_info = null;

		// Token: 0x020002A5 RID: 677
		// (Invoke) Token: 0x0600111B RID: 4379
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_frame_timings_get_complete(IntPtr raw);

		// Token: 0x020002A6 RID: 678
		// (Invoke) Token: 0x0600111F RID: 4383
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate long d_gdk_frame_timings_get_frame_counter(IntPtr raw);

		// Token: 0x020002A7 RID: 679
		// (Invoke) Token: 0x06001123 RID: 4387
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate long d_gdk_frame_timings_get_frame_time(IntPtr raw);

		// Token: 0x020002A8 RID: 680
		// (Invoke) Token: 0x06001127 RID: 4391
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate long d_gdk_frame_timings_get_predicted_presentation_time(IntPtr raw);

		// Token: 0x020002A9 RID: 681
		// (Invoke) Token: 0x0600112B RID: 4395
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate long d_gdk_frame_timings_get_presentation_time(IntPtr raw);

		// Token: 0x020002AA RID: 682
		// (Invoke) Token: 0x0600112F RID: 4399
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate long d_gdk_frame_timings_get_refresh_interval(IntPtr raw);

		// Token: 0x020002AB RID: 683
		// (Invoke) Token: 0x06001133 RID: 4403
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_frame_timings_get_type();

		// Token: 0x020002AC RID: 684
		// (Invoke) Token: 0x06001137 RID: 4407
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_frame_timings_ref(IntPtr raw);

		// Token: 0x020002AD RID: 685
		// (Invoke) Token: 0x0600113B RID: 4411
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_frame_timings_unref(IntPtr raw);

		// Token: 0x020002AE RID: 686
		private class FinalizerInfo
		{
			// Token: 0x0600113E RID: 4414 RVA: 0x00021DB3 File Offset: 0x0001FFB3
			public FinalizerInfo(IntPtr handle)
			{
				this.handle = handle;
			}

			// Token: 0x0600113F RID: 4415 RVA: 0x00021DC2 File Offset: 0x0001FFC2
			public bool Handler()
			{
				FrameTimings.gdk_frame_timings_unref(this.handle);
				Timeout.Remove(this.timeoutHandlerId);
				return false;
			}

			// Token: 0x04000C96 RID: 3222
			private IntPtr handle;

			// Token: 0x04000C97 RID: 3223
			public uint timeoutHandlerId;
		}
	}
}
