﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x02000075 RID: 117
	public class EventFilter : Opaque
	{
		// Token: 0x0600050C RID: 1292 RVA: 0x0000F3F6 File Offset: 0x0000D5F6
		public EventFilter(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000150 RID: 336
		// (get) Token: 0x0600050D RID: 1293 RVA: 0x0000F3FF File Offset: 0x0000D5FF
		public static AbiStruct abi_info
		{
			get
			{
				if (EventFilter._abi_info == null)
				{
					EventFilter._abi_info = new AbiStruct(new List<AbiField>());
				}
				return EventFilter._abi_info;
			}
		}

		// Token: 0x0400022D RID: 557
		private static AbiStruct _abi_info;
	}
}
