﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x020000DE RID: 222
	public class PixbufSimpleAnimIterClass : Opaque
	{
		// Token: 0x06000871 RID: 2161 RVA: 0x00018EE2 File Offset: 0x000170E2
		public PixbufSimpleAnimIterClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000231 RID: 561
		// (get) Token: 0x06000872 RID: 2162 RVA: 0x00018EEB File Offset: 0x000170EB
		public static AbiStruct abi_info
		{
			get
			{
				if (PixbufSimpleAnimIterClass._abi_info == null)
				{
					PixbufSimpleAnimIterClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return PixbufSimpleAnimIterClass._abi_info;
			}
		}

		// Token: 0x040004C0 RID: 1216
		private static AbiStruct _abi_info;
	}
}
