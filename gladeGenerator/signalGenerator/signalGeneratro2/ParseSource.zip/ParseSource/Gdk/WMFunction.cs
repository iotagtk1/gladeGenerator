﻿using System;

namespace Gdk
{
	// Token: 0x0200012A RID: 298
	[Flags]
	public enum WMFunction
	{
		// Token: 0x040006BE RID: 1726
		All = 1,
		// Token: 0x040006BF RID: 1727
		Resize = 2,
		// Token: 0x040006C0 RID: 1728
		Move = 4,
		// Token: 0x040006C1 RID: 1729
		Minimize = 8,
		// Token: 0x040006C2 RID: 1730
		Maximize = 16,
		// Token: 0x040006C3 RID: 1731
		Close = 32
	}
}
