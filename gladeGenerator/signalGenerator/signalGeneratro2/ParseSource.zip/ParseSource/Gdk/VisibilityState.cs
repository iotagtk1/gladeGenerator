﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000110 RID: 272
	[GType(typeof(VisibilityStateGType))]
	public enum VisibilityState
	{
		// Token: 0x04000598 RID: 1432
		Unobscured,
		// Token: 0x04000599 RID: 1433
		Partial,
		// Token: 0x0400059A RID: 1434
		FullyObscured
	}
}
