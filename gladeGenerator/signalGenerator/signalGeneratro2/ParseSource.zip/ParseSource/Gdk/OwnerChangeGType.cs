﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000BE RID: 190
	internal class OwnerChangeGType
	{
		// Token: 0x170001E8 RID: 488
		// (get) Token: 0x06000757 RID: 1879 RVA: 0x00015283 File Offset: 0x00013483
		public static GType GType
		{
			get
			{
				return new GType(OwnerChangeGType.gdk_owner_change_get_type());
			}
		}

		// Token: 0x04000413 RID: 1043
		private static OwnerChangeGType.d_gdk_owner_change_get_type gdk_owner_change_get_type = FuncLoader.LoadFunction<OwnerChangeGType.d_gdk_owner_change_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_owner_change_get_type"));

		// Token: 0x0200031C RID: 796
		// (Invoke) Token: 0x060012F5 RID: 4853
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_owner_change_get_type();
	}
}
