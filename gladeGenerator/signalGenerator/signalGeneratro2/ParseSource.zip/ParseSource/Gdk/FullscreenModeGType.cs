﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200008F RID: 143
	internal class FullscreenModeGType
	{
		// Token: 0x17000189 RID: 393
		// (get) Token: 0x0600060C RID: 1548 RVA: 0x00011F45 File Offset: 0x00010145
		public static GType GType
		{
			get
			{
				return new GType(FullscreenModeGType.gdk_fullscreen_mode_get_type());
			}
		}

		// Token: 0x04000324 RID: 804
		private static FullscreenModeGType.d_gdk_fullscreen_mode_get_type gdk_fullscreen_mode_get_type = FuncLoader.LoadFunction<FullscreenModeGType.d_gdk_fullscreen_mode_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_fullscreen_mode_get_type"));

		// Token: 0x020002AF RID: 687
		// (Invoke) Token: 0x06001141 RID: 4417
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_fullscreen_mode_get_type();
	}
}
