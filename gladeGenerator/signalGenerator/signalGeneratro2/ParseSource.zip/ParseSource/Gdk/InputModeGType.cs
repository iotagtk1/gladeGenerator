﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000A3 RID: 163
	internal class InputModeGType
	{
		// Token: 0x170001AE RID: 430
		// (get) Token: 0x06000674 RID: 1652 RVA: 0x00013000 File Offset: 0x00011200
		public static GType GType
		{
			get
			{
				return new GType(InputModeGType.gdk_input_mode_get_type());
			}
		}

		// Token: 0x04000382 RID: 898
		private static InputModeGType.d_gdk_input_mode_get_type gdk_input_mode_get_type = FuncLoader.LoadFunction<InputModeGType.d_gdk_input_mode_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_input_mode_get_type"));

		// Token: 0x020002DB RID: 731
		// (Invoke) Token: 0x060011F1 RID: 4593
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_input_mode_get_type();
	}
}
