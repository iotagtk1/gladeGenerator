﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x020000DB RID: 219
	public class PixbufScaledAnimIterClass : Opaque
	{
		// Token: 0x06000864 RID: 2148 RVA: 0x00018CF4 File Offset: 0x00016EF4
		public PixbufScaledAnimIterClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700022C RID: 556
		// (get) Token: 0x06000865 RID: 2149 RVA: 0x00018CFD File Offset: 0x00016EFD
		public static AbiStruct abi_info
		{
			get
			{
				if (PixbufScaledAnimIterClass._abi_info == null)
				{
					PixbufScaledAnimIterClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return PixbufScaledAnimIterClass._abi_info;
			}
		}

		// Token: 0x040004B8 RID: 1208
		private static AbiStruct _abi_info;
	}
}
