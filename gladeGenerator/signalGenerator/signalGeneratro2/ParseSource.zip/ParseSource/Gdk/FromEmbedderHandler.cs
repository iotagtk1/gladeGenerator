﻿using System;

namespace Gdk
{
	// Token: 0x0200008C RID: 140
	// (Invoke) Token: 0x06000604 RID: 1540
	public delegate void FromEmbedderHandler(object o, FromEmbedderArgs args);
}
