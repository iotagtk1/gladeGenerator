﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x0200012C RID: 300
	public class XPMContext : Opaque
	{
		// Token: 0x06000B62 RID: 2914 RVA: 0x000216B6 File Offset: 0x0001F8B6
		public XPMContext(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170002F9 RID: 761
		// (get) Token: 0x06000B63 RID: 2915 RVA: 0x000216BF File Offset: 0x0001F8BF
		public static AbiStruct abi_info
		{
			get
			{
				if (XPMContext._abi_info == null)
				{
					XPMContext._abi_info = new AbiStruct(new List<AbiField>());
				}
				return XPMContext._abi_info;
			}
		}

		// Token: 0x040006C5 RID: 1733
		private static AbiStruct _abi_info;
	}
}
