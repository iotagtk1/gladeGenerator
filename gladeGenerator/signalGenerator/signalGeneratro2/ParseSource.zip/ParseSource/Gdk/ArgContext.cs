﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x0200003E RID: 62
	public class ArgContext : Opaque
	{
		// Token: 0x06000390 RID: 912 RVA: 0x0000B835 File Offset: 0x00009A35
		public ArgContext(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170000F2 RID: 242
		// (get) Token: 0x06000391 RID: 913 RVA: 0x0000B83E File Offset: 0x00009A3E
		public static AbiStruct abi_info
		{
			get
			{
				if (ArgContext._abi_info == null)
				{
					ArgContext._abi_info = new AbiStruct(new List<AbiField>());
				}
				return ArgContext._abi_info;
			}
		}

		// Token: 0x04000116 RID: 278
		private static AbiStruct _abi_info;
	}
}
