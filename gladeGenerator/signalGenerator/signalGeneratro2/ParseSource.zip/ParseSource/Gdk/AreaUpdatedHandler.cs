﻿using System;

namespace Gdk
{
	// Token: 0x0200003C RID: 60
	// (Invoke) Token: 0x06000388 RID: 904
	public delegate void AreaUpdatedHandler(object o, AreaUpdatedArgs args);
}
