﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000F2 RID: 242
	internal class SeatCapabilitiesGType
	{
		// Token: 0x17000281 RID: 641
		// (get) Token: 0x060009EA RID: 2538 RVA: 0x0001D734 File Offset: 0x0001B934
		public static GType GType
		{
			get
			{
				return new GType(SeatCapabilitiesGType.gdk_seat_capabilities_get_type());
			}
		}

		// Token: 0x04000560 RID: 1376
		private static SeatCapabilitiesGType.d_gdk_seat_capabilities_get_type gdk_seat_capabilities_get_type = FuncLoader.LoadFunction<SeatCapabilitiesGType.d_gdk_seat_capabilities_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_seat_capabilities_get_type"));

		// Token: 0x02000402 RID: 1026
		// (Invoke) Token: 0x0600168A RID: 5770
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_seat_capabilities_get_type();
	}
}
