﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000112 RID: 274
	public class Visual : Object
	{
		// Token: 0x06000A45 RID: 2629 RVA: 0x0001DF89 File Offset: 0x0001C189
		public Visual(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000A46 RID: 2630 RVA: 0x0001DF92 File Offset: 0x0001C192
		protected Visual() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x17000299 RID: 665
		// (get) Token: 0x06000A47 RID: 2631 RVA: 0x0001DFB1 File Offset: 0x0001C1B1
		public new static AbiStruct class_abi
		{
			get
			{
				if (Visual._class_abi == null)
				{
					Visual._class_abi = new AbiStruct(Object.class_abi.Fields);
				}
				return Visual._class_abi;
			}
		}

		// Token: 0x1700029A RID: 666
		// (get) Token: 0x06000A48 RID: 2632 RVA: 0x0001DFD3 File Offset: 0x0001C1D3
		[Obsolete]
		public static Visual Best
		{
			get
			{
				return Object.GetObject(Visual.gdk_visual_get_best()) as Visual;
			}
		}

		// Token: 0x1700029B RID: 667
		// (get) Token: 0x06000A49 RID: 2633 RVA: 0x0001DFE9 File Offset: 0x0001C1E9
		[Obsolete]
		public static int BestDepth
		{
			get
			{
				return Visual.gdk_visual_get_best_depth();
			}
		}

		// Token: 0x1700029C RID: 668
		// (get) Token: 0x06000A4A RID: 2634 RVA: 0x0001DFF5 File Offset: 0x0001C1F5
		[Obsolete]
		public static VisualType BestType
		{
			get
			{
				return (VisualType)Visual.gdk_visual_get_best_type();
			}
		}

		// Token: 0x06000A4B RID: 2635 RVA: 0x0001E001 File Offset: 0x0001C201
		[Obsolete]
		public static Visual GetBestWithBoth(int depth, VisualType visual_type)
		{
			return Object.GetObject(Visual.gdk_visual_get_best_with_both(depth, (int)visual_type)) as Visual;
		}

		// Token: 0x06000A4C RID: 2636 RVA: 0x0001E019 File Offset: 0x0001C219
		[Obsolete]
		public static Visual GetBestWithDepth(int depth)
		{
			return Object.GetObject(Visual.gdk_visual_get_best_with_depth(depth)) as Visual;
		}

		// Token: 0x06000A4D RID: 2637 RVA: 0x0001E030 File Offset: 0x0001C230
		[Obsolete]
		public static Visual GetBestWithType(VisualType visual_type)
		{
			return Object.GetObject(Visual.gdk_visual_get_best_with_type((int)visual_type)) as Visual;
		}

		// Token: 0x1700029D RID: 669
		// (get) Token: 0x06000A4E RID: 2638 RVA: 0x0001E047 File Offset: 0x0001C247
		[Obsolete]
		public int BitsPerRgb
		{
			get
			{
				return Visual.gdk_visual_get_bits_per_rgb(base.Handle);
			}
		}

		// Token: 0x06000A4F RID: 2639 RVA: 0x0001E059 File Offset: 0x0001C259
		public void GetBluePixelDetails(out uint mask, out int shift, out int precision)
		{
			Visual.gdk_visual_get_blue_pixel_details(base.Handle, out mask, out shift, out precision);
		}

		// Token: 0x1700029E RID: 670
		// (get) Token: 0x06000A50 RID: 2640 RVA: 0x0001E06E File Offset: 0x0001C26E
		[Obsolete]
		public ByteOrder ByteOrder
		{
			get
			{
				return (ByteOrder)Visual.gdk_visual_get_byte_order(base.Handle);
			}
		}

		// Token: 0x1700029F RID: 671
		// (get) Token: 0x06000A51 RID: 2641 RVA: 0x0001E080 File Offset: 0x0001C280
		[Obsolete]
		public int ColormapSize
		{
			get
			{
				return Visual.gdk_visual_get_colormap_size(base.Handle);
			}
		}

		// Token: 0x170002A0 RID: 672
		// (get) Token: 0x06000A52 RID: 2642 RVA: 0x0001E092 File Offset: 0x0001C292
		public int Depth
		{
			get
			{
				return Visual.gdk_visual_get_depth(base.Handle);
			}
		}

		// Token: 0x06000A53 RID: 2643 RVA: 0x0001E0A4 File Offset: 0x0001C2A4
		public void GetGreenPixelDetails(out uint mask, out int shift, out int precision)
		{
			Visual.gdk_visual_get_green_pixel_details(base.Handle, out mask, out shift, out precision);
		}

		// Token: 0x06000A54 RID: 2644 RVA: 0x0001E0B9 File Offset: 0x0001C2B9
		public void GetRedPixelDetails(out uint mask, out int shift, out int precision)
		{
			Visual.gdk_visual_get_red_pixel_details(base.Handle, out mask, out shift, out precision);
		}

		// Token: 0x170002A1 RID: 673
		// (get) Token: 0x06000A55 RID: 2645 RVA: 0x0001E0CE File Offset: 0x0001C2CE
		public Screen Screen
		{
			get
			{
				return Object.GetObject(Visual.gdk_visual_get_screen(base.Handle)) as Screen;
			}
		}

		// Token: 0x170002A2 RID: 674
		// (get) Token: 0x06000A56 RID: 2646 RVA: 0x0001E0EA File Offset: 0x0001C2EA
		[Obsolete]
		public static Visual System
		{
			get
			{
				return Object.GetObject(Visual.gdk_visual_get_system()) as Visual;
			}
		}

		// Token: 0x170002A3 RID: 675
		// (get) Token: 0x06000A57 RID: 2647 RVA: 0x0001E100 File Offset: 0x0001C300
		public new static GType GType
		{
			get
			{
				IntPtr val = Visual.gdk_visual_get_type();
				return new GType(val);
			}
		}

		// Token: 0x170002A4 RID: 676
		// (get) Token: 0x06000A58 RID: 2648 RVA: 0x0001E11E File Offset: 0x0001C31E
		public VisualType VisualType
		{
			get
			{
				return (VisualType)Visual.gdk_visual_get_visual_type(base.Handle);
			}
		}

		// Token: 0x170002A5 RID: 677
		// (get) Token: 0x06000A59 RID: 2649 RVA: 0x0001E130 File Offset: 0x0001C330
		public new static AbiStruct abi_info
		{
			get
			{
				if (Visual._abi_info == null)
				{
					Visual._abi_info = new AbiStruct(Object.abi_info.Fields);
				}
				return Visual._abi_info;
			}
		}

		// Token: 0x0400059C RID: 1436
		private static AbiStruct _class_abi = null;

		// Token: 0x0400059D RID: 1437
		private static Visual.d_gdk_visual_get_best gdk_visual_get_best = FuncLoader.LoadFunction<Visual.d_gdk_visual_get_best>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_visual_get_best"));

		// Token: 0x0400059E RID: 1438
		private static Visual.d_gdk_visual_get_best_depth gdk_visual_get_best_depth = FuncLoader.LoadFunction<Visual.d_gdk_visual_get_best_depth>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_visual_get_best_depth"));

		// Token: 0x0400059F RID: 1439
		private static Visual.d_gdk_visual_get_best_type gdk_visual_get_best_type = FuncLoader.LoadFunction<Visual.d_gdk_visual_get_best_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_visual_get_best_type"));

		// Token: 0x040005A0 RID: 1440
		private static Visual.d_gdk_visual_get_best_with_both gdk_visual_get_best_with_both = FuncLoader.LoadFunction<Visual.d_gdk_visual_get_best_with_both>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_visual_get_best_with_both"));

		// Token: 0x040005A1 RID: 1441
		private static Visual.d_gdk_visual_get_best_with_depth gdk_visual_get_best_with_depth = FuncLoader.LoadFunction<Visual.d_gdk_visual_get_best_with_depth>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_visual_get_best_with_depth"));

		// Token: 0x040005A2 RID: 1442
		private static Visual.d_gdk_visual_get_best_with_type gdk_visual_get_best_with_type = FuncLoader.LoadFunction<Visual.d_gdk_visual_get_best_with_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_visual_get_best_with_type"));

		// Token: 0x040005A3 RID: 1443
		private static Visual.d_gdk_visual_get_bits_per_rgb gdk_visual_get_bits_per_rgb = FuncLoader.LoadFunction<Visual.d_gdk_visual_get_bits_per_rgb>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_visual_get_bits_per_rgb"));

		// Token: 0x040005A4 RID: 1444
		private static Visual.d_gdk_visual_get_blue_pixel_details gdk_visual_get_blue_pixel_details = FuncLoader.LoadFunction<Visual.d_gdk_visual_get_blue_pixel_details>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_visual_get_blue_pixel_details"));

		// Token: 0x040005A5 RID: 1445
		private static Visual.d_gdk_visual_get_byte_order gdk_visual_get_byte_order = FuncLoader.LoadFunction<Visual.d_gdk_visual_get_byte_order>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_visual_get_byte_order"));

		// Token: 0x040005A6 RID: 1446
		private static Visual.d_gdk_visual_get_colormap_size gdk_visual_get_colormap_size = FuncLoader.LoadFunction<Visual.d_gdk_visual_get_colormap_size>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_visual_get_colormap_size"));

		// Token: 0x040005A7 RID: 1447
		private static Visual.d_gdk_visual_get_depth gdk_visual_get_depth = FuncLoader.LoadFunction<Visual.d_gdk_visual_get_depth>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_visual_get_depth"));

		// Token: 0x040005A8 RID: 1448
		private static Visual.d_gdk_visual_get_green_pixel_details gdk_visual_get_green_pixel_details = FuncLoader.LoadFunction<Visual.d_gdk_visual_get_green_pixel_details>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_visual_get_green_pixel_details"));

		// Token: 0x040005A9 RID: 1449
		private static Visual.d_gdk_visual_get_red_pixel_details gdk_visual_get_red_pixel_details = FuncLoader.LoadFunction<Visual.d_gdk_visual_get_red_pixel_details>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_visual_get_red_pixel_details"));

		// Token: 0x040005AA RID: 1450
		private static Visual.d_gdk_visual_get_screen gdk_visual_get_screen = FuncLoader.LoadFunction<Visual.d_gdk_visual_get_screen>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_visual_get_screen"));

		// Token: 0x040005AB RID: 1451
		private static Visual.d_gdk_visual_get_system gdk_visual_get_system = FuncLoader.LoadFunction<Visual.d_gdk_visual_get_system>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_visual_get_system"));

		// Token: 0x040005AC RID: 1452
		private static Visual.d_gdk_visual_get_type gdk_visual_get_type = FuncLoader.LoadFunction<Visual.d_gdk_visual_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_visual_get_type"));

		// Token: 0x040005AD RID: 1453
		private static Visual.d_gdk_visual_get_visual_type gdk_visual_get_visual_type = FuncLoader.LoadFunction<Visual.d_gdk_visual_get_visual_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_visual_get_visual_type"));

		// Token: 0x040005AE RID: 1454
		private static AbiStruct _abi_info = null;

		// Token: 0x02000415 RID: 1045
		// (Invoke) Token: 0x060016D6 RID: 5846
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_visual_get_best();

		// Token: 0x02000416 RID: 1046
		// (Invoke) Token: 0x060016DA RID: 5850
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_visual_get_best_depth();

		// Token: 0x02000417 RID: 1047
		// (Invoke) Token: 0x060016DE RID: 5854
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_visual_get_best_type();

		// Token: 0x02000418 RID: 1048
		// (Invoke) Token: 0x060016E2 RID: 5858
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_visual_get_best_with_both(int depth, int visual_type);

		// Token: 0x02000419 RID: 1049
		// (Invoke) Token: 0x060016E6 RID: 5862
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_visual_get_best_with_depth(int depth);

		// Token: 0x0200041A RID: 1050
		// (Invoke) Token: 0x060016EA RID: 5866
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_visual_get_best_with_type(int visual_type);

		// Token: 0x0200041B RID: 1051
		// (Invoke) Token: 0x060016EE RID: 5870
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_visual_get_bits_per_rgb(IntPtr raw);

		// Token: 0x0200041C RID: 1052
		// (Invoke) Token: 0x060016F2 RID: 5874
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_visual_get_blue_pixel_details(IntPtr raw, out uint mask, out int shift, out int precision);

		// Token: 0x0200041D RID: 1053
		// (Invoke) Token: 0x060016F6 RID: 5878
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_visual_get_byte_order(IntPtr raw);

		// Token: 0x0200041E RID: 1054
		// (Invoke) Token: 0x060016FA RID: 5882
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_visual_get_colormap_size(IntPtr raw);

		// Token: 0x0200041F RID: 1055
		// (Invoke) Token: 0x060016FE RID: 5886
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_visual_get_depth(IntPtr raw);

		// Token: 0x02000420 RID: 1056
		// (Invoke) Token: 0x06001702 RID: 5890
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_visual_get_green_pixel_details(IntPtr raw, out uint mask, out int shift, out int precision);

		// Token: 0x02000421 RID: 1057
		// (Invoke) Token: 0x06001706 RID: 5894
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_visual_get_red_pixel_details(IntPtr raw, out uint mask, out int shift, out int precision);

		// Token: 0x02000422 RID: 1058
		// (Invoke) Token: 0x0600170A RID: 5898
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_visual_get_screen(IntPtr raw);

		// Token: 0x02000423 RID: 1059
		// (Invoke) Token: 0x0600170E RID: 5902
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_visual_get_system();

		// Token: 0x02000424 RID: 1060
		// (Invoke) Token: 0x06001712 RID: 5906
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_visual_get_type();

		// Token: 0x02000425 RID: 1061
		// (Invoke) Token: 0x06001716 RID: 5910
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_visual_get_visual_type(IntPtr raw);
	}
}
