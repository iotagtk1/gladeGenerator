﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200002C RID: 44
	public class EventGrabBroken : Event
	{
		// Token: 0x060002FE RID: 766 RVA: 0x0000A7A4 File Offset: 0x000089A4
		public EventGrabBroken(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x060002FF RID: 767 RVA: 0x0000A7AD File Offset: 0x000089AD
		private EventGrabBroken.NativeStruct Native
		{
			get
			{
				return (EventGrabBroken.NativeStruct)Marshal.PtrToStructure(base.Handle, typeof(EventGrabBroken.NativeStruct));
			}
		}

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x06000300 RID: 768 RVA: 0x0000A7C9 File Offset: 0x000089C9
		// (set) Token: 0x06000301 RID: 769 RVA: 0x0000A7D8 File Offset: 0x000089D8
		public bool Keyboard
		{
			get
			{
				return this.Native.keyboard;
			}
			set
			{
				EventGrabBroken.NativeStruct native = this.Native;
				native.keyboard = value;
				Marshal.StructureToPtr<EventGrabBroken.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x06000302 RID: 770 RVA: 0x0000A801 File Offset: 0x00008A01
		// (set) Token: 0x06000303 RID: 771 RVA: 0x0000A810 File Offset: 0x00008A10
		public bool Implicit
		{
			get
			{
				return this.Native._implicit;
			}
			set
			{
				EventGrabBroken.NativeStruct native = this.Native;
				native._implicit = value;
				Marshal.StructureToPtr<EventGrabBroken.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x06000304 RID: 772 RVA: 0x0000A839 File Offset: 0x00008A39
		// (set) Token: 0x06000305 RID: 773 RVA: 0x0000A854 File Offset: 0x00008A54
		public Window GrabWindow
		{
			get
			{
				return Object.GetObject(this.Native.grab_window, false) as Window;
			}
			set
			{
				EventGrabBroken.NativeStruct native = this.Native;
				native.grab_window = ((value == null) ? IntPtr.Zero : value.Handle);
				Marshal.StructureToPtr<EventGrabBroken.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x020001DF RID: 479
		private struct NativeStruct
		{
			// Token: 0x04000C40 RID: 3136
			private EventType type;

			// Token: 0x04000C41 RID: 3137
			private IntPtr window;

			// Token: 0x04000C42 RID: 3138
			private sbyte send_event;

			// Token: 0x04000C43 RID: 3139
			public bool keyboard;

			// Token: 0x04000C44 RID: 3140
			public bool _implicit;

			// Token: 0x04000C45 RID: 3141
			public IntPtr grab_window;
		}
	}
}
