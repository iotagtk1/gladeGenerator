﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000124 RID: 292
	internal class WindowTypeGType
	{
		// Token: 0x170002F5 RID: 757
		// (get) Token: 0x06000B57 RID: 2903 RVA: 0x000215F1 File Offset: 0x0001F7F1
		public static GType GType
		{
			get
			{
				return new GType(WindowTypeGType.gdk_window_type_get_type());
			}
		}

		// Token: 0x040006A0 RID: 1696
		private static WindowTypeGType.d_gdk_window_type_get_type gdk_window_type_get_type = FuncLoader.LoadFunction<WindowTypeGType.d_gdk_window_type_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_type_get_type"));

		// Token: 0x020004D1 RID: 1233
		// (Invoke) Token: 0x060019C6 RID: 6598
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_type_get_type();
	}
}
