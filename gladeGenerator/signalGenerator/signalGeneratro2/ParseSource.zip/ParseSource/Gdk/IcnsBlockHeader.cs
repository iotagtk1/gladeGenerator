﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x0200009E RID: 158
	public class IcnsBlockHeader : Opaque
	{
		// Token: 0x06000668 RID: 1640 RVA: 0x00012FB4 File Offset: 0x000111B4
		public IcnsBlockHeader(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170001AA RID: 426
		// (get) Token: 0x06000669 RID: 1641 RVA: 0x00012FBD File Offset: 0x000111BD
		public static AbiStruct abi_info
		{
			get
			{
				if (IcnsBlockHeader._abi_info == null)
				{
					IcnsBlockHeader._abi_info = new AbiStruct(new List<AbiField>());
				}
				return IcnsBlockHeader._abi_info;
			}
		}

		// Token: 0x0400037C RID: 892
		private static AbiStruct _abi_info;
	}
}
