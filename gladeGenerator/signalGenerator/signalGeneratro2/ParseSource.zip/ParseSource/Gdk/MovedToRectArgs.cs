﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000B8 RID: 184
	public class MovedToRectArgs : SignalArgs
	{
		// Token: 0x170001E1 RID: 481
		// (get) Token: 0x06000747 RID: 1863 RVA: 0x000150E7 File Offset: 0x000132E7
		public IntPtr P0
		{
			get
			{
				return (IntPtr)base.Args[0];
			}
		}

		// Token: 0x170001E2 RID: 482
		// (get) Token: 0x06000748 RID: 1864 RVA: 0x000150F6 File Offset: 0x000132F6
		public IntPtr P1
		{
			get
			{
				return (IntPtr)base.Args[1];
			}
		}

		// Token: 0x170001E3 RID: 483
		// (get) Token: 0x06000749 RID: 1865 RVA: 0x00015105 File Offset: 0x00013305
		public bool P2
		{
			get
			{
				return (bool)base.Args[2];
			}
		}

		// Token: 0x170001E4 RID: 484
		// (get) Token: 0x0600074A RID: 1866 RVA: 0x00015114 File Offset: 0x00013314
		public bool P3
		{
			get
			{
				return (bool)base.Args[3];
			}
		}
	}
}
