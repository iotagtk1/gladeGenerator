﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000030 RID: 48
	public class EventProperty : Event
	{
		// Token: 0x06000333 RID: 819 RVA: 0x0000ADED File Offset: 0x00008FED
		public EventProperty(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x06000334 RID: 820 RVA: 0x0000ADF6 File Offset: 0x00008FF6
		private EventProperty.NativeStruct Native
		{
			get
			{
				return (EventProperty.NativeStruct)Marshal.PtrToStructure(base.Handle, typeof(EventProperty.NativeStruct));
			}
		}

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x06000335 RID: 821 RVA: 0x0000AE12 File Offset: 0x00009012
		// (set) Token: 0x06000336 RID: 822 RVA: 0x0000AE34 File Offset: 0x00009034
		public Atom Atom
		{
			get
			{
				return Opaque.GetOpaque(this.Native.atom, typeof(Atom), false) as Atom;
			}
			set
			{
				EventProperty.NativeStruct native = this.Native;
				native.atom = ((value == null) ? IntPtr.Zero : value.Handle);
				Marshal.StructureToPtr<EventProperty.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x06000337 RID: 823 RVA: 0x0000AE6C File Offset: 0x0000906C
		// (set) Token: 0x06000338 RID: 824 RVA: 0x0000AE7C File Offset: 0x0000907C
		public PropertyState State
		{
			get
			{
				return (PropertyState)this.Native.state;
			}
			set
			{
				EventProperty.NativeStruct native = this.Native;
				native.state = (uint)value;
				Marshal.StructureToPtr<EventProperty.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x06000339 RID: 825 RVA: 0x0000AEA5 File Offset: 0x000090A5
		// (set) Token: 0x0600033A RID: 826 RVA: 0x0000AEB4 File Offset: 0x000090B4
		public uint Time
		{
			get
			{
				return this.Native.time;
			}
			set
			{
				EventProperty.NativeStruct native = this.Native;
				native.time = value;
				Marshal.StructureToPtr<EventProperty.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x020001E3 RID: 483
		private struct NativeStruct
		{
			// Token: 0x04000C64 RID: 3172
			private EventType type;

			// Token: 0x04000C65 RID: 3173
			private IntPtr window;

			// Token: 0x04000C66 RID: 3174
			private sbyte send_event;

			// Token: 0x04000C67 RID: 3175
			public IntPtr atom;

			// Token: 0x04000C68 RID: 3176
			public uint time;

			// Token: 0x04000C69 RID: 3177
			public uint state;
		}
	}
}
