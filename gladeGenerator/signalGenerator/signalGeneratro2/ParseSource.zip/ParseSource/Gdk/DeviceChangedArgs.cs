﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x0200005A RID: 90
	public class DeviceChangedArgs : SignalArgs
	{
		// Token: 0x17000109 RID: 265
		// (get) Token: 0x060003EB RID: 1003 RVA: 0x0000C45D File Offset: 0x0000A65D
		public Device Device
		{
			get
			{
				return (Device)base.Args[0];
			}
		}
	}
}
