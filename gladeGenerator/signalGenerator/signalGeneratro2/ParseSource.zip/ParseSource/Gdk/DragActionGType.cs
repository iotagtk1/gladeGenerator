﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200006A RID: 106
	internal class DragActionGType
	{
		// Token: 0x17000126 RID: 294
		// (get) Token: 0x06000459 RID: 1113 RVA: 0x0000D5F5 File Offset: 0x0000B7F5
		public static GType GType
		{
			get
			{
				return new GType(DragActionGType.gdk_drag_action_get_type());
			}
		}

		// Token: 0x040001EF RID: 495
		private static DragActionGType.d_gdk_drag_action_get_type gdk_drag_action_get_type = FuncLoader.LoadFunction<DragActionGType.d_gdk_drag_action_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_action_get_type"));

		// Token: 0x02000234 RID: 564
		// (Invoke) Token: 0x06000F57 RID: 3927
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_drag_action_get_type();
	}
}
