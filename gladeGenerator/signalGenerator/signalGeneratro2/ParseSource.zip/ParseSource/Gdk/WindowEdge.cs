﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x0200011A RID: 282
	[GType(typeof(WindowEdgeGType))]
	public enum WindowEdge
	{
		// Token: 0x04000677 RID: 1655
		NorthWest,
		// Token: 0x04000678 RID: 1656
		North,
		// Token: 0x04000679 RID: 1657
		NorthEast,
		// Token: 0x0400067A RID: 1658
		West,
		// Token: 0x0400067B RID: 1659
		East,
		// Token: 0x0400067C RID: 1660
		SouthWest,
		// Token: 0x0400067D RID: 1661
		South,
		// Token: 0x0400067E RID: 1662
		SouthEast
	}
}
