﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200006C RID: 108
	internal class DragCancelReasonGType
	{
		// Token: 0x17000127 RID: 295
		// (get) Token: 0x0600045C RID: 1116 RVA: 0x0000D62A File Offset: 0x0000B82A
		public static GType GType
		{
			get
			{
				return new GType(DragCancelReasonGType.gdk_drag_cancel_reason_get_type());
			}
		}

		// Token: 0x040001F4 RID: 500
		private static DragCancelReasonGType.d_gdk_drag_cancel_reason_get_type gdk_drag_cancel_reason_get_type = FuncLoader.LoadFunction<DragCancelReasonGType.d_gdk_drag_cancel_reason_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_cancel_reason_get_type"));

		// Token: 0x02000235 RID: 565
		// (Invoke) Token: 0x06000F5B RID: 3931
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_drag_cancel_reason_get_type();
	}
}
