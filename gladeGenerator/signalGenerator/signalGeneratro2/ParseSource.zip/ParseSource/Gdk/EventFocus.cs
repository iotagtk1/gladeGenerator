﻿using System;
using System.Runtime.InteropServices;

namespace Gdk
{
	// Token: 0x0200002B RID: 43
	public class EventFocus : Event
	{
		// Token: 0x060002FA RID: 762 RVA: 0x0000A73D File Offset: 0x0000893D
		public EventFocus(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x060002FB RID: 763 RVA: 0x0000A746 File Offset: 0x00008946
		private EventFocus.NativeStruct Native
		{
			get
			{
				return (EventFocus.NativeStruct)Marshal.PtrToStructure(base.Handle, typeof(EventFocus.NativeStruct));
			}
		}

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x060002FC RID: 764 RVA: 0x0000A762 File Offset: 0x00008962
		// (set) Token: 0x060002FD RID: 765 RVA: 0x0000A774 File Offset: 0x00008974
		public bool In
		{
			get
			{
				return this.Native._in != 0;
			}
			set
			{
				EventFocus.NativeStruct native = this.Native;
				native._in = (value ? 1 : 0);
				Marshal.StructureToPtr<EventFocus.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x020001DE RID: 478
		private struct NativeStruct
		{
			// Token: 0x04000C3C RID: 3132
			private EventType type;

			// Token: 0x04000C3D RID: 3133
			private IntPtr window;

			// Token: 0x04000C3E RID: 3134
			private sbyte send_event;

			// Token: 0x04000C3F RID: 3135
			public short _in;
		}
	}
}
