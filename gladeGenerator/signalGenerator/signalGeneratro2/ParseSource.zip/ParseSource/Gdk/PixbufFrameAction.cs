﻿using System;

namespace Gdk
{
	// Token: 0x020000CF RID: 207
	public enum PixbufFrameAction
	{
		// Token: 0x04000495 RID: 1173
		Retain,
		// Token: 0x04000496 RID: 1174
		Dispose,
		// Token: 0x04000497 RID: 1175
		Revert
	}
}
