﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000C8 RID: 200
	public class PixbufAnimationIter : Object
	{
		// Token: 0x060007D7 RID: 2007 RVA: 0x0001779B File Offset: 0x0001599B
		public PixbufAnimationIter(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x060007D8 RID: 2008 RVA: 0x000177A4 File Offset: 0x000159A4
		protected PixbufAnimationIter() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x060007D9 RID: 2009 RVA: 0x000177C3 File Offset: 0x000159C3
		public bool Advance(IntPtr current_time)
		{
			return PixbufAnimationIter.gdk_pixbuf_animation_iter_advance(base.Handle, current_time);
		}

		// Token: 0x17000202 RID: 514
		// (get) Token: 0x060007DA RID: 2010 RVA: 0x000177D6 File Offset: 0x000159D6
		public int DelayTime
		{
			get
			{
				return PixbufAnimationIter.gdk_pixbuf_animation_iter_get_delay_time(base.Handle);
			}
		}

		// Token: 0x17000203 RID: 515
		// (get) Token: 0x060007DB RID: 2011 RVA: 0x000177E8 File Offset: 0x000159E8
		public Pixbuf Pixbuf
		{
			get
			{
				return Object.GetObject(PixbufAnimationIter.gdk_pixbuf_animation_iter_get_pixbuf(base.Handle)) as Pixbuf;
			}
		}

		// Token: 0x17000204 RID: 516
		// (get) Token: 0x060007DC RID: 2012 RVA: 0x00017804 File Offset: 0x00015A04
		public new static GType GType
		{
			get
			{
				IntPtr val = PixbufAnimationIter.gdk_pixbuf_animation_iter_get_type();
				return new GType(val);
			}
		}

		// Token: 0x060007DD RID: 2013 RVA: 0x00017822 File Offset: 0x00015A22
		public bool OnCurrentlyLoadingFrame()
		{
			return PixbufAnimationIter.gdk_pixbuf_animation_iter_on_currently_loading_frame(base.Handle);
		}

		// Token: 0x0400046C RID: 1132
		private static PixbufAnimationIter.d_gdk_pixbuf_animation_iter_advance gdk_pixbuf_animation_iter_advance = FuncLoader.LoadFunction<PixbufAnimationIter.d_gdk_pixbuf_animation_iter_advance>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_animation_iter_advance"));

		// Token: 0x0400046D RID: 1133
		private static PixbufAnimationIter.d_gdk_pixbuf_animation_iter_get_delay_time gdk_pixbuf_animation_iter_get_delay_time = FuncLoader.LoadFunction<PixbufAnimationIter.d_gdk_pixbuf_animation_iter_get_delay_time>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_animation_iter_get_delay_time"));

		// Token: 0x0400046E RID: 1134
		private static PixbufAnimationIter.d_gdk_pixbuf_animation_iter_get_pixbuf gdk_pixbuf_animation_iter_get_pixbuf = FuncLoader.LoadFunction<PixbufAnimationIter.d_gdk_pixbuf_animation_iter_get_pixbuf>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_animation_iter_get_pixbuf"));

		// Token: 0x0400046F RID: 1135
		private static PixbufAnimationIter.d_gdk_pixbuf_animation_iter_get_type gdk_pixbuf_animation_iter_get_type = FuncLoader.LoadFunction<PixbufAnimationIter.d_gdk_pixbuf_animation_iter_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_animation_iter_get_type"));

		// Token: 0x04000470 RID: 1136
		private static PixbufAnimationIter.d_gdk_pixbuf_animation_iter_on_currently_loading_frame gdk_pixbuf_animation_iter_on_currently_loading_frame = FuncLoader.LoadFunction<PixbufAnimationIter.d_gdk_pixbuf_animation_iter_on_currently_loading_frame>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_animation_iter_on_currently_loading_frame"));

		// Token: 0x02000371 RID: 881
		// (Invoke) Token: 0x06001448 RID: 5192
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_animation_iter_advance(IntPtr raw, IntPtr current_time);

		// Token: 0x02000372 RID: 882
		// (Invoke) Token: 0x0600144C RID: 5196
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_pixbuf_animation_iter_get_delay_time(IntPtr raw);

		// Token: 0x02000373 RID: 883
		// (Invoke) Token: 0x06001450 RID: 5200
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_animation_iter_get_pixbuf(IntPtr raw);

		// Token: 0x02000374 RID: 884
		// (Invoke) Token: 0x06001454 RID: 5204
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_animation_iter_get_type();

		// Token: 0x02000375 RID: 885
		// (Invoke) Token: 0x06001458 RID: 5208
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_animation_iter_on_currently_loading_frame(IntPtr raw);
	}
}
