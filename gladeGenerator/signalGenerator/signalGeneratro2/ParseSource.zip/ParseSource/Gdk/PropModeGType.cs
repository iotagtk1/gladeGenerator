﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000E9 RID: 233
	internal class PropModeGType
	{
		// Token: 0x17000238 RID: 568
		// (get) Token: 0x060008A1 RID: 2209 RVA: 0x00019802 File Offset: 0x00017A02
		public static GType GType
		{
			get
			{
				return new GType(PropModeGType.gdk_prop_mode_get_type());
			}
		}

		// Token: 0x040004EF RID: 1263
		private static PropModeGType.d_gdk_prop_mode_get_type gdk_prop_mode_get_type = FuncLoader.LoadFunction<PropModeGType.d_gdk_prop_mode_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_prop_mode_get_type"));

		// Token: 0x020003A8 RID: 936
		// (Invoke) Token: 0x06001522 RID: 5410
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_prop_mode_get_type();
	}
}
