﻿using System;
using System.Runtime.InteropServices;

namespace Gdk
{
	// Token: 0x02000074 RID: 116
	public class Error
	{
		// Token: 0x06000508 RID: 1288 RVA: 0x0000F3A0 File Offset: 0x0000D5A0
		public static void TrapPopIgnored()
		{
			Error.gdk_error_trap_pop_ignored();
		}

		// Token: 0x06000509 RID: 1289 RVA: 0x0000F3AC File Offset: 0x0000D5AC
		public static void TrapPush()
		{
			Error.gdk_error_trap_push();
		}

		// Token: 0x0400022B RID: 555
		private static Error.d_gdk_error_trap_pop_ignored gdk_error_trap_pop_ignored = FuncLoader.LoadFunction<Error.d_gdk_error_trap_pop_ignored>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_error_trap_pop_ignored"));

		// Token: 0x0400022C RID: 556
		private static Error.d_gdk_error_trap_push gdk_error_trap_push = FuncLoader.LoadFunction<Error.d_gdk_error_trap_push>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_error_trap_push"));

		// Token: 0x0200025F RID: 607
		// (Invoke) Token: 0x06001003 RID: 4099
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_error_trap_pop_ignored();

		// Token: 0x02000260 RID: 608
		// (Invoke) Token: 0x06001007 RID: 4103
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_error_trap_push();
	}
}
