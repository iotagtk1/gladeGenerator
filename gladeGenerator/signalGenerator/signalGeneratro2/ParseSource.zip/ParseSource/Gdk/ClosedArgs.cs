﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x0200004D RID: 77
	public class ClosedArgs : SignalArgs
	{
		// Token: 0x170000FB RID: 251
		// (get) Token: 0x060003BB RID: 955 RVA: 0x0000BD66 File Offset: 0x00009F66
		public bool IsError
		{
			get
			{
				return (bool)base.Args[0];
			}
		}
	}
}
