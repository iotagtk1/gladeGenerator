﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000047 RID: 71
	internal class ByteOrderGType
	{
		// Token: 0x170000F8 RID: 248
		// (get) Token: 0x0600039E RID: 926 RVA: 0x0000B937 File Offset: 0x00009B37
		public static GType GType
		{
			get
			{
				return new GType(ByteOrderGType.gdk_byte_order_get_type());
			}
		}

		// Token: 0x04000135 RID: 309
		private static ByteOrderGType.d_gdk_byte_order_get_type gdk_byte_order_get_type = FuncLoader.LoadFunction<ByteOrderGType.d_gdk_byte_order_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_byte_order_get_type"));

		// Token: 0x020001F5 RID: 501
		// (Invoke) Token: 0x06000E5F RID: 3679
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_byte_order_get_type();
	}
}
