﻿using System;

namespace Gdk
{
	// Token: 0x020000FB RID: 251
	// (Invoke) Token: 0x06000A08 RID: 2568
	public delegate void SizePreparedHandler(object o, SizePreparedArgs args);
}
