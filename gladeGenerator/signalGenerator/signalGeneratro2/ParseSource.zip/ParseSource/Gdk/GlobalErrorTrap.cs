﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x02000097 RID: 151
	public class GlobalErrorTrap : Opaque
	{
		// Token: 0x0600065D RID: 1629 RVA: 0x00012EEF File Offset: 0x000110EF
		public GlobalErrorTrap(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170001A6 RID: 422
		// (get) Token: 0x0600065E RID: 1630 RVA: 0x00012EF8 File Offset: 0x000110F8
		public static AbiStruct abi_info
		{
			get
			{
				if (GlobalErrorTrap._abi_info == null)
				{
					GlobalErrorTrap._abi_info = new AbiStruct(new List<AbiField>());
				}
				return GlobalErrorTrap._abi_info;
			}
		}

		// Token: 0x04000362 RID: 866
		private static AbiStruct _abi_info;
	}
}
