﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000085 RID: 133
	[GType(typeof(FilterReturnGType))]
	public enum FilterReturn
	{
		// Token: 0x040002ED RID: 749
		Continue,
		// Token: 0x040002EE RID: 750
		Translate,
		// Token: 0x040002EF RID: 751
		Remove
	}
}
