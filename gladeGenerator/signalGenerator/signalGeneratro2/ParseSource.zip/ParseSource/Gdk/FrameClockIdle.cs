﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000088 RID: 136
	public class FrameClockIdle : FrameClock
	{
		// Token: 0x060005ED RID: 1517 RVA: 0x00011B8D File Offset: 0x0000FD8D
		public FrameClockIdle(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x060005EE RID: 1518 RVA: 0x00011B96 File Offset: 0x0000FD96
		protected FrameClockIdle() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x17000179 RID: 377
		// (get) Token: 0x060005EF RID: 1519 RVA: 0x00011BB5 File Offset: 0x0000FDB5
		public new static AbiStruct class_abi
		{
			get
			{
				if (FrameClockIdle._class_abi == null)
				{
					FrameClockIdle._class_abi = new AbiStruct(FrameClock.class_abi.Fields);
				}
				return FrameClockIdle._class_abi;
			}
		}

		// Token: 0x1700017A RID: 378
		// (get) Token: 0x060005F0 RID: 1520 RVA: 0x00011BD8 File Offset: 0x0000FDD8
		public new static GType GType
		{
			get
			{
				IntPtr val = FrameClockIdle.gdk_frame_clock_idle_get_type();
				return new GType(val);
			}
		}

		// Token: 0x1700017B RID: 379
		// (get) Token: 0x060005F1 RID: 1521 RVA: 0x00011BF8 File Offset: 0x0000FDF8
		public new static AbiStruct abi_info
		{
			get
			{
				if (FrameClockIdle._abi_info == null)
				{
					FrameClockIdle._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", FrameClock.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return FrameClockIdle._abi_info;
			}
		}

		// Token: 0x0400030A RID: 778
		private static AbiStruct _class_abi = null;

		// Token: 0x0400030B RID: 779
		private static FrameClockIdle.d_gdk_frame_clock_idle_get_type gdk_frame_clock_idle_get_type = FuncLoader.LoadFunction<FrameClockIdle.d_gdk_frame_clock_idle_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_clock_idle_get_type"));

		// Token: 0x0400030C RID: 780
		private static AbiStruct _abi_info = null;

		// Token: 0x020002A3 RID: 675
		// (Invoke) Token: 0x06001113 RID: 4371
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_frame_clock_idle_get_type();
	}
}
