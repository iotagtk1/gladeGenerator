﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000C4 RID: 196
	internal class PixbufAlphaModeGType
	{
		// Token: 0x170001FA RID: 506
		// (get) Token: 0x060007BD RID: 1981 RVA: 0x00017271 File Offset: 0x00015471
		public static GType GType
		{
			get
			{
				return new GType(PixbufAlphaModeGType.gdk_pixbuf_alpha_mode_get_type());
			}
		}

		// Token: 0x0400045F RID: 1119
		private static PixbufAlphaModeGType.d_gdk_pixbuf_alpha_mode_get_type gdk_pixbuf_alpha_mode_get_type = FuncLoader.LoadFunction<PixbufAlphaModeGType.d_gdk_pixbuf_alpha_mode_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_alpha_mode_get_type"));

		// Token: 0x02000364 RID: 868
		// (Invoke) Token: 0x06001414 RID: 5140
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_alpha_mode_get_type();
	}
}
