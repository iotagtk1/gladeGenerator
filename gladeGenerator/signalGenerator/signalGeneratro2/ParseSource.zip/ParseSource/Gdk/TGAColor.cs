﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x02000101 RID: 257
	public class TGAColor : Opaque
	{
		// Token: 0x06000A14 RID: 2580 RVA: 0x0001DB61 File Offset: 0x0001BD61
		public TGAColor(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700028A RID: 650
		// (get) Token: 0x06000A15 RID: 2581 RVA: 0x0001DB6A File Offset: 0x0001BD6A
		public static AbiStruct abi_info
		{
			get
			{
				if (TGAColor._abi_info == null)
				{
					TGAColor._abi_info = new AbiStruct(new List<AbiField>());
				}
				return TGAColor._abi_info;
			}
		}

		// Token: 0x04000581 RID: 1409
		private static AbiStruct _abi_info;
	}
}
