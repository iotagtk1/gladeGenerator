﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x0200004A RID: 74
	public class CancelArgs : SignalArgs
	{
		// Token: 0x170000F9 RID: 249
		// (get) Token: 0x060003B3 RID: 947 RVA: 0x0000BD29 File Offset: 0x00009F29
		public DragCancelReason Reason
		{
			get
			{
				return (DragCancelReason)base.Args[0];
			}
		}
	}
}
