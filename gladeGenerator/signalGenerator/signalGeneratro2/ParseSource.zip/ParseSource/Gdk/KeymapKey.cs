﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000AB RID: 171
	public struct KeymapKey : IEquatable<KeymapKey>
	{
		// Token: 0x060006FE RID: 1790 RVA: 0x00014861 File Offset: 0x00012A61
		public static KeymapKey New(IntPtr raw)
		{
			if (raw == IntPtr.Zero)
			{
				return KeymapKey.Zero;
			}
			return (KeymapKey)Marshal.PtrToStructure(raw, typeof(KeymapKey));
		}

		// Token: 0x060006FF RID: 1791 RVA: 0x0001488B File Offset: 0x00012A8B
		public bool Equals(KeymapKey other)
		{
			return this.Keycode.Equals(other.Keycode) && this.Group.Equals(other.Group) && this.Level.Equals(other.Level);
		}

		// Token: 0x06000700 RID: 1792 RVA: 0x000148C6 File Offset: 0x00012AC6
		public override bool Equals(object other)
		{
			return other is KeymapKey && this.Equals((KeymapKey)other);
		}

		// Token: 0x06000701 RID: 1793 RVA: 0x000148DE File Offset: 0x00012ADE
		public override int GetHashCode()
		{
			return base.GetType().FullName.GetHashCode() ^ this.Keycode.GetHashCode() ^ this.Group.GetHashCode() ^ this.Level.GetHashCode();
		}

		// Token: 0x170001CB RID: 459
		// (get) Token: 0x06000702 RID: 1794 RVA: 0x0001491E File Offset: 0x00012B1E
		private static GType GType
		{
			get
			{
				return GType.Pointer;
			}
		}

		// Token: 0x040003B9 RID: 953
		public uint Keycode;

		// Token: 0x040003BA RID: 954
		public int Group;

		// Token: 0x040003BB RID: 955
		public int Level;

		// Token: 0x040003BC RID: 956
		public static KeymapKey Zero;
	}
}
