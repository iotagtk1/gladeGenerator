﻿using System;
using System.Runtime.InteropServices;

namespace Gdk
{
	// Token: 0x020000A9 RID: 169
	public class Keyboard
	{
		// Token: 0x0600067F RID: 1663 RVA: 0x000130C5 File Offset: 0x000112C5
		[Obsolete]
		public static GrabStatus Grab(Window window, bool owner_events, uint time_)
		{
			return (GrabStatus)Keyboard.gdk_keyboard_grab((window == null) ? IntPtr.Zero : window.Handle, owner_events, time_);
		}

		// Token: 0x06000680 RID: 1664 RVA: 0x000130E3 File Offset: 0x000112E3
		[Obsolete]
		public static void Ungrab(uint time_)
		{
			Keyboard.gdk_keyboard_ungrab(time_);
		}

		// Token: 0x04000395 RID: 917
		private static Keyboard.d_gdk_keyboard_grab gdk_keyboard_grab = FuncLoader.LoadFunction<Keyboard.d_gdk_keyboard_grab>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keyboard_grab"));

		// Token: 0x04000396 RID: 918
		private static Keyboard.d_gdk_keyboard_ungrab gdk_keyboard_ungrab = FuncLoader.LoadFunction<Keyboard.d_gdk_keyboard_ungrab>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keyboard_ungrab"));

		// Token: 0x020002DE RID: 734
		// (Invoke) Token: 0x060011FD RID: 4605
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_keyboard_grab(IntPtr window, bool owner_events, uint time_);

		// Token: 0x020002DF RID: 735
		// (Invoke) Token: 0x06001201 RID: 4609
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_keyboard_ungrab(uint time_);
	}
}
