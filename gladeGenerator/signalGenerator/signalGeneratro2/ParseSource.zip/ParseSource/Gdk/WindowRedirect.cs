﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x02000120 RID: 288
	public class WindowRedirect : Opaque
	{
		// Token: 0x06000B52 RID: 2898 RVA: 0x00021596 File Offset: 0x0001F796
		public WindowRedirect(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170002F3 RID: 755
		// (get) Token: 0x06000B53 RID: 2899 RVA: 0x0002159F File Offset: 0x0001F79F
		public static AbiStruct abi_info
		{
			get
			{
				if (WindowRedirect._abi_info == null)
				{
					WindowRedirect._abi_info = new AbiStruct(new List<AbiField>());
				}
				return WindowRedirect._abi_info;
			}
		}

		// Token: 0x0400068C RID: 1676
		private static AbiStruct _abi_info;
	}
}
