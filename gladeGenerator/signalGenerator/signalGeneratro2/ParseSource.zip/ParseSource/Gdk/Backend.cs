﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x02000045 RID: 69
	public class Backend : Opaque
	{
		// Token: 0x0600039C RID: 924 RVA: 0x0000B911 File Offset: 0x00009B11
		public Backend(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170000F7 RID: 247
		// (get) Token: 0x0600039D RID: 925 RVA: 0x0000B91A File Offset: 0x00009B1A
		public static AbiStruct abi_info
		{
			get
			{
				if (Backend._abi_info == null)
				{
					Backend._abi_info = new AbiStruct(new List<AbiField>());
				}
				return Backend._abi_info;
			}
		}

		// Token: 0x04000131 RID: 305
		private static AbiStruct _abi_info;
	}
}
