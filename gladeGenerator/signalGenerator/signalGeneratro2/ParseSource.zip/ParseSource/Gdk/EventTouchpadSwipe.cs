﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000081 RID: 129
	public struct EventTouchpadSwipe : IEquatable<EventTouchpadSwipe>
	{
		// Token: 0x17000161 RID: 353
		// (get) Token: 0x06000570 RID: 1392 RVA: 0x00010856 File Offset: 0x0000EA56
		// (set) Token: 0x06000571 RID: 1393 RVA: 0x00010868 File Offset: 0x0000EA68
		public Window Window
		{
			get
			{
				return Object.GetObject(this._window) as Window;
			}
			set
			{
				this._window = ((value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x06000572 RID: 1394 RVA: 0x00010880 File Offset: 0x0000EA80
		public static EventTouchpadSwipe New(IntPtr raw)
		{
			if (raw == IntPtr.Zero)
			{
				return EventTouchpadSwipe.Zero;
			}
			return (EventTouchpadSwipe)Marshal.PtrToStructure(raw, typeof(EventTouchpadSwipe));
		}

		// Token: 0x06000573 RID: 1395 RVA: 0x000108AC File Offset: 0x0000EAAC
		public bool Equals(EventTouchpadSwipe other)
		{
			return this.Type.Equals(other.Type) && this.Window.Equals(other.Window) && this.SendEvent.Equals(other.SendEvent) && this.Phase.Equals(other.Phase) && this.NFingers.Equals(other.NFingers) && this.Time.Equals(other.Time) && this.X.Equals(other.X) && this.Y.Equals(other.Y) && this.Dx.Equals(other.Dx) && this.Dy.Equals(other.Dy) && this.XRoot.Equals(other.XRoot) && this.YRoot.Equals(other.YRoot) && this.State.Equals(other.State);
		}

		// Token: 0x06000574 RID: 1396 RVA: 0x000109CE File Offset: 0x0000EBCE
		public override bool Equals(object other)
		{
			return other is EventTouchpadSwipe && this.Equals((EventTouchpadSwipe)other);
		}

		// Token: 0x06000575 RID: 1397 RVA: 0x000109E8 File Offset: 0x0000EBE8
		public override int GetHashCode()
		{
			return base.GetType().FullName.GetHashCode() ^ this.Type.GetHashCode() ^ this.Window.GetHashCode() ^ this.SendEvent.GetHashCode() ^ this.Phase.GetHashCode() ^ this.NFingers.GetHashCode() ^ this.Time.GetHashCode() ^ this.X.GetHashCode() ^ this.Y.GetHashCode() ^ this.Dx.GetHashCode() ^ this.Dy.GetHashCode() ^ this.XRoot.GetHashCode() ^ this.YRoot.GetHashCode() ^ this.State.GetHashCode();
		}

		// Token: 0x17000162 RID: 354
		// (get) Token: 0x06000576 RID: 1398 RVA: 0x00010AB1 File Offset: 0x0000ECB1
		private static GType GType
		{
			get
			{
				return GType.Pointer;
			}
		}

		// Token: 0x040002A9 RID: 681
		public EventType Type;

		// Token: 0x040002AA RID: 682
		private IntPtr _window;

		// Token: 0x040002AB RID: 683
		public sbyte SendEvent;

		// Token: 0x040002AC RID: 684
		public sbyte Phase;

		// Token: 0x040002AD RID: 685
		public sbyte NFingers;

		// Token: 0x040002AE RID: 686
		public uint Time;

		// Token: 0x040002AF RID: 687
		public double X;

		// Token: 0x040002B0 RID: 688
		public double Y;

		// Token: 0x040002B1 RID: 689
		public double Dx;

		// Token: 0x040002B2 RID: 690
		public double Dy;

		// Token: 0x040002B3 RID: 691
		public double XRoot;

		// Token: 0x040002B4 RID: 692
		public double YRoot;

		// Token: 0x040002B5 RID: 693
		public uint State;

		// Token: 0x040002B6 RID: 694
		public static EventTouchpadSwipe Zero;
	}
}
