﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using Cairo;
using GdkSharp;
using GLib;
using GLibSharp;

namespace Gdk
{
	// Token: 0x020000C2 RID: 194
	public class Pixbuf : Object, IIcon, IWrapper, ILoadableIcon
	{
		// Token: 0x06000768 RID: 1896 RVA: 0x00015425 File Offset: 0x00013625
		public Pixbuf(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000769 RID: 1897 RVA: 0x00015430 File Offset: 0x00013630
		public Pixbuf(Colorspace colorspace, bool has_alpha, int bits_per_sample, int width, int height) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Pixbuf))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				list2.Add("colorspace");
				list.Add(new Value(colorspace));
				list2.Add("has_alpha");
				list.Add(new Value(has_alpha));
				list2.Add("bits_per_sample");
				list.Add(new Value(bits_per_sample));
				list2.Add("width");
				list.Add(new Value(width));
				list2.Add("height");
				list.Add(new Value(height));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			this.Raw = Pixbuf.gdk_pixbuf_new((int)colorspace, has_alpha, bits_per_sample, width, height);
		}

		// Token: 0x0600076A RID: 1898 RVA: 0x00015514 File Offset: 0x00013714
		public Pixbuf(Bytes data, Colorspace colorspace, bool has_alpha, int bits_per_sample, int width, int height, int rowstride) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Pixbuf))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				list2.Add("colorspace");
				list.Add(new Value(colorspace));
				list2.Add("has_alpha");
				list.Add(new Value(has_alpha));
				list2.Add("bits_per_sample");
				list.Add(new Value(bits_per_sample));
				list2.Add("width");
				list.Add(new Value(width));
				list2.Add("height");
				list.Add(new Value(height));
				list2.Add("rowstride");
				list.Add(new Value(rowstride));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			this.Raw = Pixbuf.gdk_pixbuf_new_from_bytes((data == null) ? IntPtr.Zero : data.Handle, (int)colorspace, has_alpha, bits_per_sample, width, height, rowstride);
		}

		// Token: 0x0600076B RID: 1899 RVA: 0x00015624 File Offset: 0x00013824
		public Pixbuf(InputStream stream, Cancellable cancellable) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Pixbuf))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr zero = IntPtr.Zero;
			this.Raw = Pixbuf.gdk_pixbuf_new_from_stream((stream == null) ? IntPtr.Zero : stream.Handle, (cancellable == null) ? IntPtr.Zero : cancellable.Handle, out zero);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
		}

		// Token: 0x0600076C RID: 1900 RVA: 0x000156C0 File Offset: 0x000138C0
		public Pixbuf(InputStream stream, Cancellable cancellable, AsyncReadyCallback cb) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Pixbuf))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			AsyncReadyCallbackWrapper asyncReadyCallbackWrapper = new AsyncReadyCallbackWrapper(cb);
			this.Raw = Pixbuf.gdk_pixbuf_new_from_stream_async((stream == null) ? IntPtr.Zero : stream.Handle, (cancellable == null) ? IntPtr.Zero : cancellable.Handle, asyncReadyCallbackWrapper.NativeDelegate, IntPtr.Zero);
		}

		// Token: 0x0600076D RID: 1901 RVA: 0x00015750 File Offset: 0x00013950
		public Pixbuf(InputStream stream, int width, int height, bool preserve_aspect_ratio, Cancellable cancellable) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Pixbuf))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				if (stream != null)
				{
					list2.Add("width");
					list.Add(new Value(width));
				}
				list2.Add("height");
				list.Add(new Value(height));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr zero = IntPtr.Zero;
			this.Raw = Pixbuf.gdk_pixbuf_new_from_stream_at_scale((stream == null) ? IntPtr.Zero : stream.Handle, width, height, preserve_aspect_ratio, (cancellable == null) ? IntPtr.Zero : cancellable.Handle, out zero);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
		}

		// Token: 0x0600076E RID: 1902 RVA: 0x00015824 File Offset: 0x00013A24
		public Pixbuf(InputStream stream, int width, int height, bool preserve_aspect_ratio, Cancellable cancellable, AsyncReadyCallback cb) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Pixbuf))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				if (stream != null)
				{
					list2.Add("width");
					list.Add(new Value(width));
				}
				list2.Add("height");
				list.Add(new Value(height));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			AsyncReadyCallbackWrapper asyncReadyCallbackWrapper = new AsyncReadyCallbackWrapper(cb);
			this.Raw = Pixbuf.gdk_pixbuf_new_from_stream_at_scale_async((stream == null) ? IntPtr.Zero : stream.Handle, width, height, preserve_aspect_ratio, (cancellable == null) ? IntPtr.Zero : cancellable.Handle, asyncReadyCallbackWrapper.NativeDelegate, IntPtr.Zero);
		}

		// Token: 0x0600076F RID: 1903 RVA: 0x000158EC File Offset: 0x00013AEC
		public Pixbuf(IAsyncResult async_result) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Pixbuf))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr zero = IntPtr.Zero;
			this.Raw = Pixbuf.gdk_pixbuf_new_from_stream_finish((async_result == null) ? IntPtr.Zero : ((async_result is Object) ? (async_result as Object).Handle : (async_result as AsyncResultAdapter).Handle), out zero);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
		}

		// Token: 0x06000770 RID: 1904 RVA: 0x00015990 File Offset: 0x00013B90
		public Pixbuf(string[] data) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Pixbuf))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			int num = (data == null) ? 0 : data.Length;
			IntPtr[] array = new IntPtr[num];
			for (int i = 0; i < num; i++)
			{
				array[i] = Marshaller.StringToPtrGStrdup(data[i]);
			}
			this.Raw = Pixbuf.gdk_pixbuf_new_from_xpm_data(array);
			for (int j = 0; j < array.Length; j++)
			{
				data[j] = Marshaller.Utf8PtrToString(array[j]);
				Marshaller.Free(array[j]);
			}
		}

		// Token: 0x06000771 RID: 1905 RVA: 0x00015A48 File Offset: 0x00013C48
		public Pixbuf(Pixbuf src_pixbuf, int src_x, int src_y, int width, int height) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Pixbuf))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				if (src_pixbuf != null)
				{
					list2.Add("width");
					list.Add(new Value(width));
				}
				list2.Add("height");
				list.Add(new Value(height));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			this.Raw = Pixbuf.gdk_pixbuf_new_subpixbuf((src_pixbuf == null) ? IntPtr.Zero : src_pixbuf.Handle, src_x, src_y, width, height);
		}

		// Token: 0x06000772 RID: 1906 RVA: 0x00015AF0 File Offset: 0x00013CF0
		public Pixbuf(Surface surface, int src_x, int src_y, int width, int height) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Pixbuf))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				list2.Add("width");
				list.Add(new Value(width));
				list2.Add("height");
				list.Add(new Value(height));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			this.Raw = Pixbuf.gdk_pixbuf_get_from_surface(surface.Handle, src_x, src_y, width, height);
		}

		// Token: 0x06000773 RID: 1907 RVA: 0x00015B8C File Offset: 0x00013D8C
		public Pixbuf(Window window, int src_x, int src_y, int width, int height) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Pixbuf))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				if (window != null)
				{
					list2.Add("width");
					list.Add(new Value(width));
				}
				list2.Add("height");
				list.Add(new Value(height));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			this.Raw = Pixbuf.gdk_pixbuf_get_from_window((window == null) ? IntPtr.Zero : window.Handle, src_x, src_y, width, height);
		}

		// Token: 0x170001EB RID: 491
		// (get) Token: 0x06000774 RID: 1908 RVA: 0x00015C33 File Offset: 0x00013E33
		[Property("n-channels")]
		public int NChannels
		{
			get
			{
				return Pixbuf.gdk_pixbuf_get_n_channels(base.Handle);
			}
		}

		// Token: 0x170001EC RID: 492
		// (get) Token: 0x06000775 RID: 1909 RVA: 0x00015C45 File Offset: 0x00013E45
		[Property("colorspace")]
		public Colorspace Colorspace
		{
			get
			{
				return (Colorspace)Pixbuf.gdk_pixbuf_get_colorspace(base.Handle);
			}
		}

		// Token: 0x170001ED RID: 493
		// (get) Token: 0x06000776 RID: 1910 RVA: 0x00015C57 File Offset: 0x00013E57
		[Property("has-alpha")]
		public bool HasAlpha
		{
			get
			{
				return Pixbuf.gdk_pixbuf_get_has_alpha(base.Handle);
			}
		}

		// Token: 0x170001EE RID: 494
		// (get) Token: 0x06000777 RID: 1911 RVA: 0x00015C69 File Offset: 0x00013E69
		[Property("bits-per-sample")]
		public int BitsPerSample
		{
			get
			{
				return Pixbuf.gdk_pixbuf_get_bits_per_sample(base.Handle);
			}
		}

		// Token: 0x170001EF RID: 495
		// (get) Token: 0x06000778 RID: 1912 RVA: 0x00015C7B File Offset: 0x00013E7B
		[Property("width")]
		public int Width
		{
			get
			{
				return Pixbuf.gdk_pixbuf_get_width(base.Handle);
			}
		}

		// Token: 0x170001F0 RID: 496
		// (get) Token: 0x06000779 RID: 1913 RVA: 0x00015C8D File Offset: 0x00013E8D
		[Property("height")]
		public int Height
		{
			get
			{
				return Pixbuf.gdk_pixbuf_get_height(base.Handle);
			}
		}

		// Token: 0x170001F1 RID: 497
		// (get) Token: 0x0600077A RID: 1914 RVA: 0x00015C9F File Offset: 0x00013E9F
		[Property("rowstride")]
		public int Rowstride
		{
			get
			{
				return Pixbuf.gdk_pixbuf_get_rowstride(base.Handle);
			}
		}

		// Token: 0x170001F2 RID: 498
		// (get) Token: 0x0600077B RID: 1915 RVA: 0x00015CB4 File Offset: 0x00013EB4
		[Property("pixel-bytes")]
		public Bytes PixelBytes
		{
			get
			{
				Value property = base.GetProperty("pixel-bytes");
				Bytes result = (Bytes)((Opaque)property);
				property.Dispose();
				return result;
			}
		}

		// Token: 0x170001F3 RID: 499
		// (get) Token: 0x0600077C RID: 1916 RVA: 0x00015CDF File Offset: 0x00013EDF
		public new static AbiStruct class_abi
		{
			get
			{
				if (Pixbuf._class_abi == null)
				{
					Pixbuf._class_abi = new AbiStruct(Object.class_abi.Fields);
				}
				return Pixbuf._class_abi;
			}
		}

		// Token: 0x0600077D RID: 1917 RVA: 0x00015D01 File Offset: 0x00013F01
		public Pixbuf ApplyEmbeddedOrientation()
		{
			return Object.GetObject(Pixbuf.gdk_pixbuf_apply_embedded_orientation(base.Handle), true) as Pixbuf;
		}

		// Token: 0x0600077E RID: 1918 RVA: 0x00015D20 File Offset: 0x00013F20
		public void Composite(Pixbuf dest, int dest_x, int dest_y, int dest_width, int dest_height, double offset_x, double offset_y, double scale_x, double scale_y, InterpType interp_type, int overall_alpha)
		{
			Pixbuf.gdk_pixbuf_composite(base.Handle, (dest == null) ? IntPtr.Zero : dest.Handle, dest_x, dest_y, dest_width, dest_height, offset_x, offset_y, scale_x, scale_y, (int)interp_type, overall_alpha);
		}

		// Token: 0x0600077F RID: 1919 RVA: 0x00015D60 File Offset: 0x00013F60
		public void CompositeColor(Pixbuf dest, int dest_x, int dest_y, int dest_width, int dest_height, double offset_x, double offset_y, double scale_x, double scale_y, InterpType interp_type, int overall_alpha, int check_x, int check_y, int check_size, uint color1, uint color2)
		{
			Pixbuf.gdk_pixbuf_composite_color(base.Handle, (dest == null) ? IntPtr.Zero : dest.Handle, dest_x, dest_y, dest_width, dest_height, offset_x, offset_y, scale_x, scale_y, (int)interp_type, overall_alpha, check_x, check_y, check_size, color1, color2);
		}

		// Token: 0x06000780 RID: 1920 RVA: 0x00015DA9 File Offset: 0x00013FA9
		public Pixbuf Copy()
		{
			return Object.GetObject(Pixbuf.gdk_pixbuf_copy(base.Handle), true) as Pixbuf;
		}

		// Token: 0x06000781 RID: 1921 RVA: 0x00015DC8 File Offset: 0x00013FC8
		public void CopyArea(int src_x, int src_y, int width, int height, Pixbuf dest_pixbuf, int dest_x, int dest_y)
		{
			Pixbuf.gdk_pixbuf_copy_area(base.Handle, src_x, src_y, width, height, (dest_pixbuf == null) ? IntPtr.Zero : dest_pixbuf.Handle, dest_x, dest_y);
		}

		// Token: 0x06000782 RID: 1922 RVA: 0x00015E00 File Offset: 0x00014000
		public bool CopyOptions(Pixbuf dest_pixbuf)
		{
			return Pixbuf.gdk_pixbuf_copy_options(base.Handle, (dest_pixbuf == null) ? IntPtr.Zero : dest_pixbuf.Handle);
		}

		// Token: 0x06000783 RID: 1923 RVA: 0x00015E22 File Offset: 0x00014022
		public static int ErrorQuark()
		{
			return Pixbuf.gdk_pixbuf_error_quark();
		}

		// Token: 0x06000784 RID: 1924 RVA: 0x00015E2E File Offset: 0x0001402E
		public void Fill(uint pixel)
		{
			Pixbuf.gdk_pixbuf_fill(base.Handle, pixel);
		}

		// Token: 0x06000785 RID: 1925 RVA: 0x00015E41 File Offset: 0x00014041
		public Pixbuf Flip(bool horizontal)
		{
			return Object.GetObject(Pixbuf.gdk_pixbuf_flip(base.Handle, horizontal)) as Pixbuf;
		}

		// Token: 0x170001F4 RID: 500
		// (get) Token: 0x06000786 RID: 1926 RVA: 0x00015E5E File Offset: 0x0001405E
		public ulong ByteLength
		{
			get
			{
				return (ulong)Pixbuf.gdk_pixbuf_get_byte_length(base.Handle);
			}
		}

		// Token: 0x06000787 RID: 1927 RVA: 0x00015E78 File Offset: 0x00014078
		public static PixbufFormat GetFileInfo(string filename, out int width, out int height)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(filename);
			IntPtr intPtr2 = Pixbuf.gdk_pixbuf_get_file_info(intPtr, out width, out height);
			PixbufFormat result = (intPtr2 == IntPtr.Zero) ? null : ((PixbufFormat)Opaque.GetOpaque(intPtr2, typeof(PixbufFormat), false));
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x06000788 RID: 1928 RVA: 0x00015EC8 File Offset: 0x000140C8
		public static void GetFileInfoAsync(string filename, Cancellable cancellable, AsyncReadyCallback cb)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(filename);
			AsyncReadyCallbackWrapper asyncReadyCallbackWrapper = new AsyncReadyCallbackWrapper(cb);
			Pixbuf.gdk_pixbuf_get_file_info_async(intPtr, (cancellable == null) ? IntPtr.Zero : cancellable.Handle, asyncReadyCallbackWrapper.NativeDelegate, IntPtr.Zero);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000789 RID: 1929 RVA: 0x00015F10 File Offset: 0x00014110
		public static PixbufFormat GetFileInfoFinish(IAsyncResult async_result, out int width, out int height)
		{
			IntPtr zero = IntPtr.Zero;
			IntPtr intPtr = Pixbuf.gdk_pixbuf_get_file_info_finish((async_result == null) ? IntPtr.Zero : ((async_result is Object) ? (async_result as Object).Handle : (async_result as AsyncResultAdapter).Handle), out width, out height, out zero);
			PixbufFormat result = (intPtr == IntPtr.Zero) ? null : ((PixbufFormat)Opaque.GetOpaque(intPtr, typeof(PixbufFormat), false));
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x0600078A RID: 1930 RVA: 0x00015F98 File Offset: 0x00014198
		public string GetOption(string key)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(key);
			string result = Marshaller.Utf8PtrToString(Pixbuf.gdk_pixbuf_get_option(base.Handle, intPtr));
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x170001F5 RID: 501
		// (get) Token: 0x0600078B RID: 1931 RVA: 0x00015FC8 File Offset: 0x000141C8
		public IntPtr Options
		{
			get
			{
				return Pixbuf.gdk_pixbuf_get_options(base.Handle);
			}
		}

		// Token: 0x0600078C RID: 1932 RVA: 0x00015FDA File Offset: 0x000141DA
		public byte GetPixelsWithLength(out uint length)
		{
			return Pixbuf.gdk_pixbuf_get_pixels_with_length(base.Handle, out length);
		}

		// Token: 0x170001F6 RID: 502
		// (get) Token: 0x0600078D RID: 1933 RVA: 0x00015FF0 File Offset: 0x000141F0
		public new static GType GType
		{
			get
			{
				IntPtr val = Pixbuf.gdk_pixbuf_get_type();
				return new GType(val);
			}
		}

		// Token: 0x0600078E RID: 1934 RVA: 0x0001600E File Offset: 0x0001420E
		public Bytes ReadPixelBytes()
		{
			return new Bytes(Pixbuf.gdk_pixbuf_read_pixel_bytes(base.Handle));
		}

		// Token: 0x0600078F RID: 1935 RVA: 0x00016025 File Offset: 0x00014225
		public byte ReadPixels()
		{
			return Pixbuf.gdk_pixbuf_read_pixels(base.Handle);
		}

		// Token: 0x06000790 RID: 1936 RVA: 0x00016038 File Offset: 0x00014238
		public bool RemoveOption(string key)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(key);
			bool result = Pixbuf.gdk_pixbuf_remove_option(base.Handle, intPtr);
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x06000791 RID: 1937 RVA: 0x00016063 File Offset: 0x00014263
		public Pixbuf RotateSimple(PixbufRotation angle)
		{
			return Object.GetObject(Pixbuf.gdk_pixbuf_rotate_simple(base.Handle, (int)angle), true) as Pixbuf;
		}

		// Token: 0x06000792 RID: 1938 RVA: 0x00016081 File Offset: 0x00014281
		public void SaturateAndPixelate(Pixbuf dest, float saturation, bool pixelate)
		{
			Pixbuf.gdk_pixbuf_saturate_and_pixelate(base.Handle, (dest == null) ? IntPtr.Zero : dest.Handle, saturation, pixelate);
		}

		// Token: 0x06000793 RID: 1939 RVA: 0x000160A8 File Offset: 0x000142A8
		public static bool SaveToStreamFinish(IAsyncResult async_result)
		{
			IntPtr zero = IntPtr.Zero;
			bool result = Pixbuf.gdk_pixbuf_save_to_stream_finish((async_result == null) ? IntPtr.Zero : ((async_result is Object) ? (async_result as Object).Handle : (async_result as AsyncResultAdapter).Handle), out zero);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x06000794 RID: 1940 RVA: 0x00016108 File Offset: 0x00014308
		public bool SaveToStreamv(OutputStream stream, string type, string option_keys, string option_values, Cancellable cancellable)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(type);
			IntPtr zero = IntPtr.Zero;
			bool result = Pixbuf.gdk_pixbuf_save_to_streamv(base.Handle, (stream == null) ? IntPtr.Zero : stream.Handle, intPtr, Marshaller.StringToPtrGStrdup(option_keys), Marshaller.StringToPtrGStrdup(option_values), (cancellable == null) ? IntPtr.Zero : cancellable.Handle, out zero);
			Marshaller.Free(intPtr);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x06000795 RID: 1941 RVA: 0x00016180 File Offset: 0x00014380
		public void SaveToStreamvAsync(OutputStream stream, string type, string option_keys, string option_values, Cancellable cancellable, AsyncReadyCallback cb)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(type);
			AsyncReadyCallbackWrapper asyncReadyCallbackWrapper = new AsyncReadyCallbackWrapper(cb);
			Pixbuf.gdk_pixbuf_save_to_streamv_async(base.Handle, (stream == null) ? IntPtr.Zero : stream.Handle, intPtr, Marshaller.StringToPtrGStrdup(option_keys), Marshaller.StringToPtrGStrdup(option_values), (cancellable == null) ? IntPtr.Zero : cancellable.Handle, asyncReadyCallbackWrapper.NativeDelegate, IntPtr.Zero);
			Marshaller.Free(intPtr);
		}

		// Token: 0x06000796 RID: 1942 RVA: 0x000161F0 File Offset: 0x000143F0
		public void Scale(Pixbuf dest, int dest_x, int dest_y, int dest_width, int dest_height, double offset_x, double offset_y, double scale_x, double scale_y, InterpType interp_type)
		{
			Pixbuf.gdk_pixbuf_scale(base.Handle, (dest == null) ? IntPtr.Zero : dest.Handle, dest_x, dest_y, dest_width, dest_height, offset_x, offset_y, scale_x, scale_y, (int)interp_type);
		}

		// Token: 0x06000797 RID: 1943 RVA: 0x00016230 File Offset: 0x00014430
		public bool SetOption(string key, string value)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(key);
			IntPtr intPtr2 = Marshaller.StringToPtrGStrdup(value);
			bool result = Pixbuf.gdk_pixbuf_set_option(base.Handle, intPtr, intPtr2);
			Marshaller.Free(intPtr);
			Marshaller.Free(intPtr2);
			return result;
		}

		// Token: 0x06000798 RID: 1944 RVA: 0x00016269 File Offset: 0x00014469
		public bool Equal(IIcon icon2)
		{
			return Pixbuf.g_icon_equal(base.Handle, (icon2 == null) ? IntPtr.Zero : ((icon2 is Object) ? (icon2 as Object).Handle : (icon2 as IconAdapter).Handle));
		}

		// Token: 0x06000799 RID: 1945 RVA: 0x000162A5 File Offset: 0x000144A5
		public Variant Serialize()
		{
			return new Variant(Pixbuf.g_icon_serialize(base.Handle));
		}

		// Token: 0x0600079A RID: 1946 RVA: 0x000162BC File Offset: 0x000144BC
		public override string ToString()
		{
			return Marshaller.PtrToStringGFree(Pixbuf.g_icon_to_string(base.Handle));
		}

		// Token: 0x0600079B RID: 1947 RVA: 0x000162D4 File Offset: 0x000144D4
		public InputStream Load(int size, string type, Cancellable cancellable)
		{
			IntPtr zero = IntPtr.Zero;
			InputStream result = Object.GetObject(Pixbuf.g_loadable_icon_load(base.Handle, size, Marshaller.StringToPtrGStrdup(type), (cancellable == null) ? IntPtr.Zero : cancellable.Handle, out zero)) as InputStream;
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x0600079C RID: 1948 RVA: 0x00016330 File Offset: 0x00014530
		public void LoadAsync(int size, Cancellable cancellable, AsyncReadyCallback cb)
		{
			AsyncReadyCallbackWrapper asyncReadyCallbackWrapper = new AsyncReadyCallbackWrapper(cb);
			asyncReadyCallbackWrapper.PersistUntilCalled();
			Pixbuf.g_loadable_icon_load_async(base.Handle, size, (cancellable == null) ? IntPtr.Zero : cancellable.Handle, asyncReadyCallbackWrapper.NativeDelegate, IntPtr.Zero);
		}

		// Token: 0x0600079D RID: 1949 RVA: 0x00016378 File Offset: 0x00014578
		public InputStream LoadFinish(IAsyncResult res, string type)
		{
			IntPtr zero = IntPtr.Zero;
			InputStream result = Object.GetObject(Pixbuf.g_loadable_icon_load_finish(base.Handle, (res == null) ? IntPtr.Zero : ((res is Object) ? (res as Object).Handle : (res as AsyncResultAdapter).Handle), Marshaller.StringToPtrGStrdup(type), out zero)) as InputStream;
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x170001F7 RID: 503
		// (get) Token: 0x0600079E RID: 1950 RVA: 0x000163EB File Offset: 0x000145EB
		public new static AbiStruct abi_info
		{
			get
			{
				if (Pixbuf._abi_info == null)
				{
					Pixbuf._abi_info = new AbiStruct(Object.abi_info.Fields);
				}
				return Pixbuf._abi_info;
			}
		}

		// Token: 0x0600079F RID: 1951 RVA: 0x00016410 File Offset: 0x00014610
		public Pixbuf(string filename) : base(IntPtr.Zero)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(filename);
			IntPtr zero = IntPtr.Zero;
			this.Raw = Pixbuf.gdk_pixbuf_new_from_file(intPtr, out zero);
			Marshaller.Free(intPtr);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
		}

		// Token: 0x060007A0 RID: 1952 RVA: 0x00016464 File Offset: 0x00014664
		public Pixbuf(string filename, int width, int height, bool preserve_aspect_ratio) : base(IntPtr.Zero)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(filename);
			IntPtr zero = IntPtr.Zero;
			this.Raw = Pixbuf.gdk_pixbuf_new_from_file_at_scale(intPtr, width, height, preserve_aspect_ratio, out zero);
			Marshaller.Free(intPtr);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
		}

		// Token: 0x060007A1 RID: 1953 RVA: 0x000164BC File Offset: 0x000146BC
		public Pixbuf(string filename, int width, int height) : base(IntPtr.Zero)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(filename);
			IntPtr zero = IntPtr.Zero;
			this.Raw = Pixbuf.gdk_pixbuf_new_from_file_at_size(intPtr, width, height, out zero);
			Marshaller.Free(intPtr);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
		}

		// Token: 0x060007A2 RID: 1954 RVA: 0x00016510 File Offset: 0x00014710
		public Pixbuf(Stream stream) : base(IntPtr.Zero)
		{
			using (PixbufLoader pixbufLoader = new PixbufLoader(stream))
			{
				this.Raw = pixbufLoader.PixbufHandle;
			}
		}

		// Token: 0x060007A3 RID: 1955 RVA: 0x00016558 File Offset: 0x00014758
		public Pixbuf(Stream stream, int width, int height) : base(IntPtr.Zero)
		{
			using (PixbufLoader pixbufLoader = new PixbufLoader(stream, width, height))
			{
				this.Raw = pixbufLoader.PixbufHandle;
			}
		}

		// Token: 0x060007A4 RID: 1956 RVA: 0x000165A4 File Offset: 0x000147A4
		public Pixbuf(Assembly assembly, string resource) : base(IntPtr.Zero)
		{
			using (PixbufLoader pixbufLoader = new PixbufLoader((assembly == null) ? Assembly.GetCallingAssembly() : assembly, resource))
			{
				this.Raw = pixbufLoader.PixbufHandle;
			}
		}

		// Token: 0x060007A5 RID: 1957 RVA: 0x000165FC File Offset: 0x000147FC
		public Pixbuf(Assembly assembly, string resource, int width, int height) : base(IntPtr.Zero)
		{
			using (PixbufLoader pixbufLoader = new PixbufLoader((assembly == null) ? Assembly.GetCallingAssembly() : assembly, resource, width, height))
			{
				this.Raw = pixbufLoader.PixbufHandle;
			}
		}

		// Token: 0x060007A6 RID: 1958 RVA: 0x00016658 File Offset: 0x00014858
		public Pixbuf(byte[] buffer) : base(IntPtr.Zero)
		{
			using (PixbufLoader pixbufLoader = new PixbufLoader(buffer))
			{
				this.Raw = pixbufLoader.PixbufHandle;
			}
		}

		// Token: 0x060007A7 RID: 1959 RVA: 0x000166A0 File Offset: 0x000148A0
		public Pixbuf(byte[] buffer, int width, int height) : base(IntPtr.Zero)
		{
			using (PixbufLoader pixbufLoader = new PixbufLoader(buffer, width, height))
			{
				this.Raw = pixbufLoader.PixbufHandle;
			}
		}

		// Token: 0x060007A8 RID: 1960 RVA: 0x000166EC File Offset: 0x000148EC
		public static Pixbuf LoadFromResource(string resource)
		{
			return new Pixbuf(Assembly.GetCallingAssembly(), resource);
		}

		// Token: 0x060007A9 RID: 1961 RVA: 0x000166F9 File Offset: 0x000148F9
		public Pixbuf ScaleSimple(int dest_width, int dest_height, InterpType interp_type)
		{
			return (Pixbuf)Object.GetObject(Pixbuf.gdk_pixbuf_scale_simple(base.Handle, dest_width, dest_height, (int)interp_type), true);
		}

		// Token: 0x060007AA RID: 1962 RVA: 0x0001671C File Offset: 0x0001491C
		public Pixbuf CompositeColorSimple(int dest_width, int dest_height, InterpType interp_type, int overall_alpha, int check_size, uint color1, uint color2)
		{
			return (Pixbuf)Object.GetObject(Pixbuf.gdk_pixbuf_composite_color_simple(base.Handle, dest_width, dest_height, (int)interp_type, overall_alpha, check_size, color1, color2), true);
		}

		// Token: 0x060007AB RID: 1963 RVA: 0x0001674F File Offset: 0x0001494F
		public Pixbuf AddAlpha(bool substitute_color, byte r, byte g, byte b)
		{
			return (Pixbuf)Object.GetObject(Pixbuf.gdk_pixbuf_add_alpha(base.Handle, substitute_color, r, g, b), true);
		}

		// Token: 0x060007AC RID: 1964 RVA: 0x00016774 File Offset: 0x00014974
		public Pixbuf(byte[] data, Colorspace colorspace, bool has_alpha, int bits_per_sample, int width, int height, int rowstride, PixbufDestroyNotify destroy_fn) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Pixbuf))
			{
				throw new InvalidOperationException("Can't override this constructor.");
			}
			Pixbuf.DestroyHelper destroyHelper = new Pixbuf.DestroyHelper(data, destroy_fn);
			this.Raw = Pixbuf.gdk_pixbuf_new_from_data(data, (int)colorspace, has_alpha, bits_per_sample, width, height, rowstride, destroyHelper.Handler, IntPtr.Zero);
		}

		// Token: 0x060007AD RID: 1965 RVA: 0x000167E0 File Offset: 0x000149E0
		public Pixbuf(byte[] data, bool has_alpha, int bits_per_sample, int width, int height, int rowstride, PixbufDestroyNotify destroy_fn) : this(data, Colorspace.Rgb, has_alpha, bits_per_sample, width, height, rowstride, destroy_fn)
		{
		}

		// Token: 0x060007AE RID: 1966 RVA: 0x00016800 File Offset: 0x00014A00
		public Pixbuf(byte[] data, bool has_alpha, int bits_per_sample, int width, int height, int rowstride) : this(data, Colorspace.Rgb, has_alpha, bits_per_sample, width, height, rowstride, null)
		{
		}

		// Token: 0x060007AF RID: 1967 RVA: 0x00016820 File Offset: 0x00014A20
		public Pixbuf(byte[] data, Colorspace colorspace, bool has_alpha, int bits_per_sample, int width, int height, int rowstride) : this(data, colorspace, has_alpha, bits_per_sample, width, height, rowstride, null)
		{
		}

		// Token: 0x060007B0 RID: 1968 RVA: 0x00016840 File Offset: 0x00014A40
		public unsafe Pixbuf(int data_length, void* data, bool copy_pixels) : base(IntPtr.Zero)
		{
			IntPtr zero = IntPtr.Zero;
			this.Raw = Pixbuf.gdk_pixbuf_new_from_inline(data_length, (IntPtr)data, copy_pixels, out zero);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
		}

		// Token: 0x060007B1 RID: 1969 RVA: 0x0001688C File Offset: 0x00014A8C
		public object Clone()
		{
			return this.Copy();
		}

		// Token: 0x170001F8 RID: 504
		// (get) Token: 0x060007B2 RID: 1970 RVA: 0x00016894 File Offset: 0x00014A94
		public IntPtr Pixels
		{
			get
			{
				return Pixbuf.gdk_pixbuf_get_pixels(base.Handle);
			}
		}

		// Token: 0x170001F9 RID: 505
		// (get) Token: 0x060007B3 RID: 1971 RVA: 0x000168A8 File Offset: 0x00014AA8
		public static PixbufFormat[] Formats
		{
			get
			{
				IntPtr intPtr = Pixbuf.gdk_pixbuf_get_formats();
				if (intPtr == IntPtr.Zero)
				{
					return new PixbufFormat[0];
				}
				SList slist = new SList(intPtr, typeof(PixbufFormat));
				PixbufFormat[] array = new PixbufFormat[slist.Count];
				for (int i = 0; i < slist.Count; i++)
				{
					array[i] = (PixbufFormat)slist[i];
				}
				return array;
			}
		}

		// Token: 0x060007B4 RID: 1972 RVA: 0x00016914 File Offset: 0x00014B14
		public bool Save(string filename, string type)
		{
			IntPtr zero = IntPtr.Zero;
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(filename);
			IntPtr intPtr2 = Marshaller.StringToPtrGStrdup(type);
			bool result = Pixbuf.gdk_pixbuf_save(base.Handle, intPtr, intPtr2, out zero, IntPtr.Zero);
			Marshaller.Free(intPtr);
			Marshaller.Free(intPtr2);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x060007B5 RID: 1973 RVA: 0x00016970 File Offset: 0x00014B70
		private IntPtr[] NullTerm(string[] src)
		{
			if (src.Length == 0)
			{
				return null;
			}
			IntPtr[] array = new IntPtr[src.Length + 1];
			for (int i = 0; i < src.Length; i++)
			{
				array[i] = Marshaller.StringToPtrGStrdup(src[i]);
			}
			array[src.Length] = IntPtr.Zero;
			return array;
		}

		// Token: 0x060007B6 RID: 1974 RVA: 0x000169B4 File Offset: 0x00014BB4
		private void ReleaseArray(IntPtr[] ptrs)
		{
			if (ptrs == null)
			{
				return;
			}
			for (int i = 0; i < ptrs.Length; i++)
			{
				Marshaller.Free(ptrs[i]);
			}
		}

		// Token: 0x060007B7 RID: 1975 RVA: 0x000169DD File Offset: 0x00014BDD
		public byte[] SaveToBuffer(string type)
		{
			return this.SaveToBuffer(type, new string[0], new string[0]);
		}

		// Token: 0x060007B8 RID: 1976 RVA: 0x000169F4 File Offset: 0x00014BF4
		public byte[] SaveToBuffer(string type, string[] option_keys, string[] option_values)
		{
			IntPtr zero = IntPtr.Zero;
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(type);
			IntPtr[] array = this.NullTerm(option_keys);
			IntPtr[] array2 = this.NullTerm(option_values);
			IntPtr intPtr2;
			IntPtr value;
			bool flag = Pixbuf.gdk_pixbuf_save_to_bufferv(base.Handle, out intPtr2, out value, intPtr, array, array2, out zero);
			Marshaller.Free(intPtr);
			this.ReleaseArray(array);
			this.ReleaseArray(array2);
			if (!flag)
			{
				throw new GException(zero);
			}
			byte[] array3 = new byte[(int)value];
			Marshal.Copy(intPtr2, array3, 0, (int)value);
			Marshaller.Free(intPtr2);
			return array3;
		}

		// Token: 0x060007B9 RID: 1977 RVA: 0x00016A7E File Offset: 0x00014C7E
		public void SaveToCallback(PixbufSaveFunc save_func, string type)
		{
			this.SaveToCallback(save_func, type, new string[0], new string[0]);
		}

		// Token: 0x060007BA RID: 1978 RVA: 0x00016A94 File Offset: 0x00014C94
		public void SaveToCallback(PixbufSaveFunc save_func, string type, string[] option_keys, string[] option_values)
		{
			PixbufSaveFuncWrapper pixbufSaveFuncWrapper = new PixbufSaveFuncWrapper(save_func);
			IntPtr zero = IntPtr.Zero;
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(type);
			IntPtr[] array = this.NullTerm(option_keys);
			IntPtr[] array2 = this.NullTerm(option_values);
			bool flag = Pixbuf.gdk_pixbuf_save_to_callbackv(base.Handle, pixbufSaveFuncWrapper.NativeDelegate, IntPtr.Zero, intPtr, array, array2, out zero);
			Marshaller.Free(intPtr);
			this.ReleaseArray(array);
			this.ReleaseArray(array2);
			if (!flag)
			{
				throw new GException(zero);
			}
		}

		// Token: 0x060007BB RID: 1979 RVA: 0x00016B08 File Offset: 0x00014D08
		public bool Savev(string filename, string type, string[] option_keys, string[] option_values)
		{
			IntPtr zero = IntPtr.Zero;
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(filename);
			IntPtr intPtr2 = Marshaller.StringToPtrGStrdup(type);
			IntPtr[] array = this.NullTerm(option_keys);
			IntPtr[] array2 = this.NullTerm(option_values);
			bool flag = Pixbuf.gdk_pixbuf_savev(base.Handle, intPtr, intPtr2, array, array2, out zero);
			Marshaller.Free(intPtr);
			Marshaller.Free(intPtr2);
			this.ReleaseArray(array);
			this.ReleaseArray(array2);
			if (!flag)
			{
				throw new GException(zero);
			}
			return flag;
		}

		// Token: 0x04000419 RID: 1049
		private static Pixbuf.d_gdk_pixbuf_new gdk_pixbuf_new = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_new"));

		// Token: 0x0400041A RID: 1050
		private static Pixbuf.d_gdk_pixbuf_new_from_bytes gdk_pixbuf_new_from_bytes = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_new_from_bytes>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_new_from_bytes"));

		// Token: 0x0400041B RID: 1051
		private static Pixbuf.d_gdk_pixbuf_new_from_stream gdk_pixbuf_new_from_stream = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_new_from_stream>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_new_from_stream"));

		// Token: 0x0400041C RID: 1052
		private static Pixbuf.d_gdk_pixbuf_new_from_stream_async gdk_pixbuf_new_from_stream_async = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_new_from_stream_async>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_new_from_stream_async"));

		// Token: 0x0400041D RID: 1053
		private static Pixbuf.d_gdk_pixbuf_new_from_stream_at_scale gdk_pixbuf_new_from_stream_at_scale = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_new_from_stream_at_scale>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_new_from_stream_at_scale"));

		// Token: 0x0400041E RID: 1054
		private static Pixbuf.d_gdk_pixbuf_new_from_stream_at_scale_async gdk_pixbuf_new_from_stream_at_scale_async = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_new_from_stream_at_scale_async>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_new_from_stream_at_scale_async"));

		// Token: 0x0400041F RID: 1055
		private static Pixbuf.d_gdk_pixbuf_new_from_stream_finish gdk_pixbuf_new_from_stream_finish = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_new_from_stream_finish>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_new_from_stream_finish"));

		// Token: 0x04000420 RID: 1056
		private static Pixbuf.d_gdk_pixbuf_new_from_xpm_data gdk_pixbuf_new_from_xpm_data = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_new_from_xpm_data>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_new_from_xpm_data"));

		// Token: 0x04000421 RID: 1057
		private static Pixbuf.d_gdk_pixbuf_new_subpixbuf gdk_pixbuf_new_subpixbuf = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_new_subpixbuf>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_new_subpixbuf"));

		// Token: 0x04000422 RID: 1058
		private static Pixbuf.d_gdk_pixbuf_get_from_surface gdk_pixbuf_get_from_surface = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_get_from_surface>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_pixbuf_get_from_surface"));

		// Token: 0x04000423 RID: 1059
		private static Pixbuf.d_gdk_pixbuf_get_from_window gdk_pixbuf_get_from_window = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_get_from_window>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_pixbuf_get_from_window"));

		// Token: 0x04000424 RID: 1060
		private static Pixbuf.d_gdk_pixbuf_get_n_channels gdk_pixbuf_get_n_channels = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_get_n_channels>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_get_n_channels"));

		// Token: 0x04000425 RID: 1061
		private static Pixbuf.d_gdk_pixbuf_get_colorspace gdk_pixbuf_get_colorspace = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_get_colorspace>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_get_colorspace"));

		// Token: 0x04000426 RID: 1062
		private static Pixbuf.d_gdk_pixbuf_get_has_alpha gdk_pixbuf_get_has_alpha = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_get_has_alpha>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_get_has_alpha"));

		// Token: 0x04000427 RID: 1063
		private static Pixbuf.d_gdk_pixbuf_get_bits_per_sample gdk_pixbuf_get_bits_per_sample = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_get_bits_per_sample>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_get_bits_per_sample"));

		// Token: 0x04000428 RID: 1064
		private static Pixbuf.d_gdk_pixbuf_get_width gdk_pixbuf_get_width = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_get_width>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_get_width"));

		// Token: 0x04000429 RID: 1065
		private static Pixbuf.d_gdk_pixbuf_get_height gdk_pixbuf_get_height = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_get_height>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_get_height"));

		// Token: 0x0400042A RID: 1066
		private static Pixbuf.d_gdk_pixbuf_get_rowstride gdk_pixbuf_get_rowstride = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_get_rowstride>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_get_rowstride"));

		// Token: 0x0400042B RID: 1067
		private static AbiStruct _class_abi = null;

		// Token: 0x0400042C RID: 1068
		private static Pixbuf.d_gdk_pixbuf_apply_embedded_orientation gdk_pixbuf_apply_embedded_orientation = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_apply_embedded_orientation>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_apply_embedded_orientation"));

		// Token: 0x0400042D RID: 1069
		private static Pixbuf.d_gdk_pixbuf_composite gdk_pixbuf_composite = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_composite>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_composite"));

		// Token: 0x0400042E RID: 1070
		private static Pixbuf.d_gdk_pixbuf_composite_color gdk_pixbuf_composite_color = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_composite_color>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_composite_color"));

		// Token: 0x0400042F RID: 1071
		private static Pixbuf.d_gdk_pixbuf_copy gdk_pixbuf_copy = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_copy>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_copy"));

		// Token: 0x04000430 RID: 1072
		private static Pixbuf.d_gdk_pixbuf_copy_area gdk_pixbuf_copy_area = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_copy_area>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_copy_area"));

		// Token: 0x04000431 RID: 1073
		private static Pixbuf.d_gdk_pixbuf_copy_options gdk_pixbuf_copy_options = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_copy_options>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_copy_options"));

		// Token: 0x04000432 RID: 1074
		private static Pixbuf.d_gdk_pixbuf_error_quark gdk_pixbuf_error_quark = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_error_quark>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_error_quark"));

		// Token: 0x04000433 RID: 1075
		private static Pixbuf.d_gdk_pixbuf_fill gdk_pixbuf_fill = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_fill>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_fill"));

		// Token: 0x04000434 RID: 1076
		private static Pixbuf.d_gdk_pixbuf_flip gdk_pixbuf_flip = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_flip>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_flip"));

		// Token: 0x04000435 RID: 1077
		private static Pixbuf.d_gdk_pixbuf_get_byte_length gdk_pixbuf_get_byte_length = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_get_byte_length>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_get_byte_length"));

		// Token: 0x04000436 RID: 1078
		private static Pixbuf.d_gdk_pixbuf_get_file_info gdk_pixbuf_get_file_info = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_get_file_info>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_get_file_info"));

		// Token: 0x04000437 RID: 1079
		private static Pixbuf.d_gdk_pixbuf_get_file_info_async gdk_pixbuf_get_file_info_async = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_get_file_info_async>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_get_file_info_async"));

		// Token: 0x04000438 RID: 1080
		private static Pixbuf.d_gdk_pixbuf_get_file_info_finish gdk_pixbuf_get_file_info_finish = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_get_file_info_finish>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_get_file_info_finish"));

		// Token: 0x04000439 RID: 1081
		private static Pixbuf.d_gdk_pixbuf_get_option gdk_pixbuf_get_option = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_get_option>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_get_option"));

		// Token: 0x0400043A RID: 1082
		private static Pixbuf.d_gdk_pixbuf_get_options gdk_pixbuf_get_options = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_get_options>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_get_options"));

		// Token: 0x0400043B RID: 1083
		private static Pixbuf.d_gdk_pixbuf_get_pixels_with_length gdk_pixbuf_get_pixels_with_length = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_get_pixels_with_length>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_get_pixels_with_length"));

		// Token: 0x0400043C RID: 1084
		private static Pixbuf.d_gdk_pixbuf_get_type gdk_pixbuf_get_type = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_get_type"));

		// Token: 0x0400043D RID: 1085
		private static Pixbuf.d_gdk_pixbuf_read_pixel_bytes gdk_pixbuf_read_pixel_bytes = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_read_pixel_bytes>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_read_pixel_bytes"));

		// Token: 0x0400043E RID: 1086
		private static Pixbuf.d_gdk_pixbuf_read_pixels gdk_pixbuf_read_pixels = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_read_pixels>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_read_pixels"));

		// Token: 0x0400043F RID: 1087
		private static Pixbuf.d_gdk_pixbuf_remove_option gdk_pixbuf_remove_option = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_remove_option>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_remove_option"));

		// Token: 0x04000440 RID: 1088
		private static Pixbuf.d_gdk_pixbuf_rotate_simple gdk_pixbuf_rotate_simple = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_rotate_simple>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_rotate_simple"));

		// Token: 0x04000441 RID: 1089
		private static Pixbuf.d_gdk_pixbuf_saturate_and_pixelate gdk_pixbuf_saturate_and_pixelate = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_saturate_and_pixelate>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_saturate_and_pixelate"));

		// Token: 0x04000442 RID: 1090
		private static Pixbuf.d_gdk_pixbuf_save_to_stream_finish gdk_pixbuf_save_to_stream_finish = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_save_to_stream_finish>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_save_to_stream_finish"));

		// Token: 0x04000443 RID: 1091
		private static Pixbuf.d_gdk_pixbuf_save_to_streamv gdk_pixbuf_save_to_streamv = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_save_to_streamv>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_save_to_streamv"));

		// Token: 0x04000444 RID: 1092
		private static Pixbuf.d_gdk_pixbuf_save_to_streamv_async gdk_pixbuf_save_to_streamv_async = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_save_to_streamv_async>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_save_to_streamv_async"));

		// Token: 0x04000445 RID: 1093
		private static Pixbuf.d_gdk_pixbuf_scale gdk_pixbuf_scale = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_scale>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_scale"));

		// Token: 0x04000446 RID: 1094
		private static Pixbuf.d_gdk_pixbuf_set_option gdk_pixbuf_set_option = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_set_option>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_set_option"));

		// Token: 0x04000447 RID: 1095
		private static Pixbuf.d_g_icon_equal g_icon_equal = FuncLoader.LoadFunction<Pixbuf.d_g_icon_equal>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_icon_equal"));

		// Token: 0x04000448 RID: 1096
		private static Pixbuf.d_g_icon_serialize g_icon_serialize = FuncLoader.LoadFunction<Pixbuf.d_g_icon_serialize>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_icon_serialize"));

		// Token: 0x04000449 RID: 1097
		private static Pixbuf.d_g_icon_to_string g_icon_to_string = FuncLoader.LoadFunction<Pixbuf.d_g_icon_to_string>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_icon_to_string"));

		// Token: 0x0400044A RID: 1098
		private static Pixbuf.d_g_loadable_icon_load g_loadable_icon_load = FuncLoader.LoadFunction<Pixbuf.d_g_loadable_icon_load>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_loadable_icon_load"));

		// Token: 0x0400044B RID: 1099
		private static Pixbuf.d_g_loadable_icon_load_async g_loadable_icon_load_async = FuncLoader.LoadFunction<Pixbuf.d_g_loadable_icon_load_async>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_loadable_icon_load_async"));

		// Token: 0x0400044C RID: 1100
		private static Pixbuf.d_g_loadable_icon_load_finish g_loadable_icon_load_finish = FuncLoader.LoadFunction<Pixbuf.d_g_loadable_icon_load_finish>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gio), "g_loadable_icon_load_finish"));

		// Token: 0x0400044D RID: 1101
		private static AbiStruct _abi_info = null;

		// Token: 0x0400044E RID: 1102
		private static Pixbuf.d_gdk_pixbuf_new_from_file gdk_pixbuf_new_from_file = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_new_from_file>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), FuncLoader.IsWindows ? "gdk_pixbuf_new_from_file_utf8" : "gdk_pixbuf_new_from_file"));

		// Token: 0x0400044F RID: 1103
		private static Pixbuf.d_gdk_pixbuf_new_from_file_at_scale gdk_pixbuf_new_from_file_at_scale = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_new_from_file_at_scale>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), FuncLoader.IsWindows ? "gdk_pixbuf_new_from_file_at_scale_utf8" : "gdk_pixbuf_new_from_file_at_scale"));

		// Token: 0x04000450 RID: 1104
		private static Pixbuf.d_gdk_pixbuf_new_from_file_at_size gdk_pixbuf_new_from_file_at_size = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_new_from_file_at_size>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), FuncLoader.IsWindows ? "gdk_pixbuf_new_from_file_at_size_utf8" : "gdk_pixbuf_new_from_file_at_size"));

		// Token: 0x04000451 RID: 1105
		private static Pixbuf.d_gdk_pixbuf_scale_simple gdk_pixbuf_scale_simple = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_scale_simple>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_scale_simple"));

		// Token: 0x04000452 RID: 1106
		private static Pixbuf.d_gdk_pixbuf_composite_color_simple gdk_pixbuf_composite_color_simple = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_composite_color_simple>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_composite_color_simple"));

		// Token: 0x04000453 RID: 1107
		private static Pixbuf.d_gdk_pixbuf_add_alpha gdk_pixbuf_add_alpha = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_add_alpha>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_add_alpha"));

		// Token: 0x04000454 RID: 1108
		private static Pixbuf.d_gdk_pixbuf_new_from_data gdk_pixbuf_new_from_data = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_new_from_data>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_new_from_data"));

		// Token: 0x04000455 RID: 1109
		private static Pixbuf.d_gdk_pixbuf_new_from_inline gdk_pixbuf_new_from_inline = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_new_from_inline>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_new_from_inline"));

		// Token: 0x04000456 RID: 1110
		private static Pixbuf.d_gdk_pixbuf_get_pixels gdk_pixbuf_get_pixels = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_get_pixels>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_get_pixels"));

		// Token: 0x04000457 RID: 1111
		private static Pixbuf.d_gdk_pixbuf_get_formats gdk_pixbuf_get_formats = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_get_formats>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_get_formats"));

		// Token: 0x04000458 RID: 1112
		private static Pixbuf.d_gdk_pixbuf_save gdk_pixbuf_save = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_save>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), FuncLoader.IsWindows ? "gdk_pixbuf_save_utf8" : "gdk_pixbuf_save"));

		// Token: 0x04000459 RID: 1113
		private static Pixbuf.d_gdk_pixbuf_save_to_bufferv gdk_pixbuf_save_to_bufferv = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_save_to_bufferv>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_save_to_bufferv"));

		// Token: 0x0400045A RID: 1114
		private static Pixbuf.d_gdk_pixbuf_save_to_callbackv gdk_pixbuf_save_to_callbackv = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_save_to_callbackv>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_save_to_callbackv"));

		// Token: 0x0400045B RID: 1115
		private static Pixbuf.d_gdk_pixbuf_savev gdk_pixbuf_savev = FuncLoader.LoadFunction<Pixbuf.d_gdk_pixbuf_savev>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), FuncLoader.IsWindows ? "gdk_pixbuf_savev_utf8" : "gdk_pixbuf_savev"));

		// Token: 0x02000322 RID: 802
		// (Invoke) Token: 0x0600130D RID: 4877
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_new(int colorspace, bool has_alpha, int bits_per_sample, int width, int height);

		// Token: 0x02000323 RID: 803
		// (Invoke) Token: 0x06001311 RID: 4881
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_new_from_bytes(IntPtr data, int colorspace, bool has_alpha, int bits_per_sample, int width, int height, int rowstride);

		// Token: 0x02000324 RID: 804
		// (Invoke) Token: 0x06001315 RID: 4885
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_new_from_stream(IntPtr stream, IntPtr cancellable, out IntPtr error);

		// Token: 0x02000325 RID: 805
		// (Invoke) Token: 0x06001319 RID: 4889
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_new_from_stream_async(IntPtr stream, IntPtr cancellable, AsyncReadyCallbackNative cb, IntPtr user_data);

		// Token: 0x02000326 RID: 806
		// (Invoke) Token: 0x0600131D RID: 4893
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_new_from_stream_at_scale(IntPtr stream, int width, int height, bool preserve_aspect_ratio, IntPtr cancellable, out IntPtr error);

		// Token: 0x02000327 RID: 807
		// (Invoke) Token: 0x06001321 RID: 4897
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_new_from_stream_at_scale_async(IntPtr stream, int width, int height, bool preserve_aspect_ratio, IntPtr cancellable, AsyncReadyCallbackNative cb, IntPtr user_data);

		// Token: 0x02000328 RID: 808
		// (Invoke) Token: 0x06001325 RID: 4901
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_new_from_stream_finish(IntPtr async_result, out IntPtr error);

		// Token: 0x02000329 RID: 809
		// (Invoke) Token: 0x06001329 RID: 4905
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_new_from_xpm_data(IntPtr[] data);

		// Token: 0x0200032A RID: 810
		// (Invoke) Token: 0x0600132D RID: 4909
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_new_subpixbuf(IntPtr src_pixbuf, int src_x, int src_y, int width, int height);

		// Token: 0x0200032B RID: 811
		// (Invoke) Token: 0x06001331 RID: 4913
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_get_from_surface(IntPtr surface, int src_x, int src_y, int width, int height);

		// Token: 0x0200032C RID: 812
		// (Invoke) Token: 0x06001335 RID: 4917
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_get_from_window(IntPtr window, int src_x, int src_y, int width, int height);

		// Token: 0x0200032D RID: 813
		// (Invoke) Token: 0x06001339 RID: 4921
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_pixbuf_get_n_channels(IntPtr raw);

		// Token: 0x0200032E RID: 814
		// (Invoke) Token: 0x0600133D RID: 4925
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_pixbuf_get_colorspace(IntPtr raw);

		// Token: 0x0200032F RID: 815
		// (Invoke) Token: 0x06001341 RID: 4929
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_get_has_alpha(IntPtr raw);

		// Token: 0x02000330 RID: 816
		// (Invoke) Token: 0x06001345 RID: 4933
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_pixbuf_get_bits_per_sample(IntPtr raw);

		// Token: 0x02000331 RID: 817
		// (Invoke) Token: 0x06001349 RID: 4937
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_pixbuf_get_width(IntPtr raw);

		// Token: 0x02000332 RID: 818
		// (Invoke) Token: 0x0600134D RID: 4941
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_pixbuf_get_height(IntPtr raw);

		// Token: 0x02000333 RID: 819
		// (Invoke) Token: 0x06001351 RID: 4945
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_pixbuf_get_rowstride(IntPtr raw);

		// Token: 0x02000334 RID: 820
		// (Invoke) Token: 0x06001355 RID: 4949
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_apply_embedded_orientation(IntPtr raw);

		// Token: 0x02000335 RID: 821
		// (Invoke) Token: 0x06001359 RID: 4953
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_pixbuf_composite(IntPtr raw, IntPtr dest, int dest_x, int dest_y, int dest_width, int dest_height, double offset_x, double offset_y, double scale_x, double scale_y, int interp_type, int overall_alpha);

		// Token: 0x02000336 RID: 822
		// (Invoke) Token: 0x0600135D RID: 4957
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_pixbuf_composite_color(IntPtr raw, IntPtr dest, int dest_x, int dest_y, int dest_width, int dest_height, double offset_x, double offset_y, double scale_x, double scale_y, int interp_type, int overall_alpha, int check_x, int check_y, int check_size, uint color1, uint color2);

		// Token: 0x02000337 RID: 823
		// (Invoke) Token: 0x06001361 RID: 4961
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_copy(IntPtr raw);

		// Token: 0x02000338 RID: 824
		// (Invoke) Token: 0x06001365 RID: 4965
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_pixbuf_copy_area(IntPtr raw, int src_x, int src_y, int width, int height, IntPtr dest_pixbuf, int dest_x, int dest_y);

		// Token: 0x02000339 RID: 825
		// (Invoke) Token: 0x06001369 RID: 4969
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_copy_options(IntPtr raw, IntPtr dest_pixbuf);

		// Token: 0x0200033A RID: 826
		// (Invoke) Token: 0x0600136D RID: 4973
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_pixbuf_error_quark();

		// Token: 0x0200033B RID: 827
		// (Invoke) Token: 0x06001371 RID: 4977
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_pixbuf_fill(IntPtr raw, uint pixel);

		// Token: 0x0200033C RID: 828
		// (Invoke) Token: 0x06001375 RID: 4981
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_flip(IntPtr raw, bool horizontal);

		// Token: 0x0200033D RID: 829
		// (Invoke) Token: 0x06001379 RID: 4985
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate UIntPtr d_gdk_pixbuf_get_byte_length(IntPtr raw);

		// Token: 0x0200033E RID: 830
		// (Invoke) Token: 0x0600137D RID: 4989
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_get_file_info(IntPtr filename, out int width, out int height);

		// Token: 0x0200033F RID: 831
		// (Invoke) Token: 0x06001381 RID: 4993
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_pixbuf_get_file_info_async(IntPtr filename, IntPtr cancellable, AsyncReadyCallbackNative cb, IntPtr user_data);

		// Token: 0x02000340 RID: 832
		// (Invoke) Token: 0x06001385 RID: 4997
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_get_file_info_finish(IntPtr async_result, out int width, out int height, out IntPtr error);

		// Token: 0x02000341 RID: 833
		// (Invoke) Token: 0x06001389 RID: 5001
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_get_option(IntPtr raw, IntPtr key);

		// Token: 0x02000342 RID: 834
		// (Invoke) Token: 0x0600138D RID: 5005
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_get_options(IntPtr raw);

		// Token: 0x02000343 RID: 835
		// (Invoke) Token: 0x06001391 RID: 5009
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate byte d_gdk_pixbuf_get_pixels_with_length(IntPtr raw, out uint length);

		// Token: 0x02000344 RID: 836
		// (Invoke) Token: 0x06001395 RID: 5013
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_get_type();

		// Token: 0x02000345 RID: 837
		// (Invoke) Token: 0x06001399 RID: 5017
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_read_pixel_bytes(IntPtr raw);

		// Token: 0x02000346 RID: 838
		// (Invoke) Token: 0x0600139D RID: 5021
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate byte d_gdk_pixbuf_read_pixels(IntPtr raw);

		// Token: 0x02000347 RID: 839
		// (Invoke) Token: 0x060013A1 RID: 5025
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_remove_option(IntPtr raw, IntPtr key);

		// Token: 0x02000348 RID: 840
		// (Invoke) Token: 0x060013A5 RID: 5029
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_rotate_simple(IntPtr raw, int angle);

		// Token: 0x02000349 RID: 841
		// (Invoke) Token: 0x060013A9 RID: 5033
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_pixbuf_saturate_and_pixelate(IntPtr raw, IntPtr dest, float saturation, bool pixelate);

		// Token: 0x0200034A RID: 842
		// (Invoke) Token: 0x060013AD RID: 5037
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_save_to_stream_finish(IntPtr async_result, out IntPtr error);

		// Token: 0x0200034B RID: 843
		// (Invoke) Token: 0x060013B1 RID: 5041
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_save_to_streamv(IntPtr raw, IntPtr stream, IntPtr type, IntPtr option_keys, IntPtr option_values, IntPtr cancellable, out IntPtr error);

		// Token: 0x0200034C RID: 844
		// (Invoke) Token: 0x060013B5 RID: 5045
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_pixbuf_save_to_streamv_async(IntPtr raw, IntPtr stream, IntPtr type, IntPtr option_keys, IntPtr option_values, IntPtr cancellable, AsyncReadyCallbackNative cb, IntPtr user_data);

		// Token: 0x0200034D RID: 845
		// (Invoke) Token: 0x060013B9 RID: 5049
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_pixbuf_scale(IntPtr raw, IntPtr dest, int dest_x, int dest_y, int dest_width, int dest_height, double offset_x, double offset_y, double scale_x, double scale_y, int interp_type);

		// Token: 0x0200034E RID: 846
		// (Invoke) Token: 0x060013BD RID: 5053
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_set_option(IntPtr raw, IntPtr key, IntPtr value);

		// Token: 0x0200034F RID: 847
		// (Invoke) Token: 0x060013C1 RID: 5057
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_g_icon_equal(IntPtr raw, IntPtr icon2);

		// Token: 0x02000350 RID: 848
		// (Invoke) Token: 0x060013C5 RID: 5061
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_g_icon_serialize(IntPtr raw);

		// Token: 0x02000351 RID: 849
		// (Invoke) Token: 0x060013C9 RID: 5065
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_g_icon_to_string(IntPtr raw);

		// Token: 0x02000352 RID: 850
		// (Invoke) Token: 0x060013CD RID: 5069
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_g_loadable_icon_load(IntPtr raw, int size, IntPtr type, IntPtr cancellable, out IntPtr error);

		// Token: 0x02000353 RID: 851
		// (Invoke) Token: 0x060013D1 RID: 5073
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_g_loadable_icon_load_async(IntPtr raw, int size, IntPtr cancellable, AsyncReadyCallbackNative cb, IntPtr user_data);

		// Token: 0x02000354 RID: 852
		// (Invoke) Token: 0x060013D5 RID: 5077
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_g_loadable_icon_load_finish(IntPtr raw, IntPtr res, IntPtr type, out IntPtr error);

		// Token: 0x02000355 RID: 853
		// (Invoke) Token: 0x060013D9 RID: 5081
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_new_from_file(IntPtr filename, out IntPtr error);

		// Token: 0x02000356 RID: 854
		// (Invoke) Token: 0x060013DD RID: 5085
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_new_from_file_at_scale(IntPtr filename, int width, int height, bool preserve_aspect_ratio, out IntPtr error);

		// Token: 0x02000357 RID: 855
		// (Invoke) Token: 0x060013E1 RID: 5089
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_new_from_file_at_size(IntPtr filename, int width, int height, out IntPtr error);

		// Token: 0x02000358 RID: 856
		// (Invoke) Token: 0x060013E5 RID: 5093
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_scale_simple(IntPtr raw, int dest_width, int dest_height, int interp_type);

		// Token: 0x02000359 RID: 857
		// (Invoke) Token: 0x060013E9 RID: 5097
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_composite_color_simple(IntPtr raw, int dest_width, int dest_height, int interp_type, int overall_alpha, int check_size, uint color1, uint color2);

		// Token: 0x0200035A RID: 858
		// (Invoke) Token: 0x060013ED RID: 5101
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_add_alpha(IntPtr raw, bool substitute_color, byte r, byte g, byte b);

		// Token: 0x0200035B RID: 859
		private class DestroyHelper
		{
			// Token: 0x060013F0 RID: 5104 RVA: 0x00021DE0 File Offset: 0x0001FFE0
			public DestroyHelper(byte[] data, PixbufDestroyNotify notify)
			{
				this.gch = GCHandle.Alloc(this);
				this.data_handle = GCHandle.Alloc(data, GCHandleType.Pinned);
				this.notify = notify;
			}

			// Token: 0x060013F1 RID: 5105 RVA: 0x00021E08 File Offset: 0x00020008
			private void ReleaseHandles(IntPtr buf, IntPtr data)
			{
				if (this.notify != null)
				{
					this.notify((byte[])this.data_handle.Target);
				}
				this.data_handle.Free();
				this.gch.Free();
			}

			// Token: 0x17000305 RID: 773
			// (get) Token: 0x060013F2 RID: 5106 RVA: 0x00021E43 File Offset: 0x00020043
			public Pixbuf.DestroyHelper.NativeDelegate Handler
			{
				get
				{
					this.handler = new Pixbuf.DestroyHelper.NativeDelegate(this.ReleaseHandles);
					return this.handler;
				}
			}

			// Token: 0x04000C98 RID: 3224
			private GCHandle gch;

			// Token: 0x04000C99 RID: 3225
			private GCHandle data_handle;

			// Token: 0x04000C9A RID: 3226
			private PixbufDestroyNotify notify;

			// Token: 0x04000C9B RID: 3227
			private Pixbuf.DestroyHelper.NativeDelegate handler;

			// Token: 0x020004D8 RID: 1240
			// (Invoke) Token: 0x060019E2 RID: 6626
			[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
			public delegate void NativeDelegate(IntPtr buf, IntPtr data);
		}

		// Token: 0x0200035C RID: 860
		// (Invoke) Token: 0x060013F4 RID: 5108
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_new_from_data(byte[] data, int colorspace, bool has_alpha, int bits_per_sample, int width, int height, int rowstride, Pixbuf.DestroyHelper.NativeDelegate destroy_fn, IntPtr destroy_fn_data);

		// Token: 0x0200035D RID: 861
		// (Invoke) Token: 0x060013F8 RID: 5112
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_new_from_inline(int len, IntPtr data, bool copy_pixels, out IntPtr error);

		// Token: 0x0200035E RID: 862
		// (Invoke) Token: 0x060013FC RID: 5116
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_get_pixels(IntPtr raw);

		// Token: 0x0200035F RID: 863
		// (Invoke) Token: 0x06001400 RID: 5120
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_get_formats();

		// Token: 0x02000360 RID: 864
		// (Invoke) Token: 0x06001404 RID: 5124
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_save(IntPtr raw, IntPtr filename, IntPtr type, out IntPtr error, IntPtr dummy);

		// Token: 0x02000361 RID: 865
		// (Invoke) Token: 0x06001408 RID: 5128
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_save_to_bufferv(IntPtr raw, out IntPtr buffer, out IntPtr buffer_size, IntPtr type, IntPtr[] option_keys, IntPtr[] option_values, out IntPtr error);

		// Token: 0x02000362 RID: 866
		// (Invoke) Token: 0x0600140C RID: 5132
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_save_to_callbackv(IntPtr raw, PixbufSaveFuncNative save_func, IntPtr user_data, IntPtr type, IntPtr[] option_keys, IntPtr[] option_values, out IntPtr error);

		// Token: 0x02000363 RID: 867
		// (Invoke) Token: 0x06001410 RID: 5136
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_savev(IntPtr raw, IntPtr filename, IntPtr type, IntPtr[] option_keys, IntPtr[] option_values, out IntPtr error);
	}
}
