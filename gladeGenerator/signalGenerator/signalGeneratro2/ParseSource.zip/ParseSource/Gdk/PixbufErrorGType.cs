﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000CC RID: 204
	internal class PixbufErrorGType
	{
		// Token: 0x17000206 RID: 518
		// (get) Token: 0x060007E5 RID: 2021 RVA: 0x000178E9 File Offset: 0x00015AE9
		public static GType GType
		{
			get
			{
				return new GType(PixbufErrorGType.gdk_pixbuf_error_get_type());
			}
		}

		// Token: 0x0400047A RID: 1146
		private static PixbufErrorGType.d_gdk_pixbuf_error_get_type gdk_pixbuf_error_get_type = FuncLoader.LoadFunction<PixbufErrorGType.d_gdk_pixbuf_error_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_error_get_type"));

		// Token: 0x02000376 RID: 886
		// (Invoke) Token: 0x0600145C RID: 5212
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_error_get_type();
	}
}
