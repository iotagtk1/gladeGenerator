﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x020000D3 RID: 211
	public class PixbufNonAnim : Opaque
	{
		// Token: 0x06000853 RID: 2131 RVA: 0x00018C01 File Offset: 0x00016E01
		public PixbufNonAnim(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000226 RID: 550
		// (get) Token: 0x06000854 RID: 2132 RVA: 0x00018C0A File Offset: 0x00016E0A
		public static AbiStruct abi_info
		{
			get
			{
				if (PixbufNonAnim._abi_info == null)
				{
					PixbufNonAnim._abi_info = new AbiStruct(new List<AbiField>());
				}
				return PixbufNonAnim._abi_info;
			}
		}

		// Token: 0x040004AD RID: 1197
		private static AbiStruct _abi_info;
	}
}
