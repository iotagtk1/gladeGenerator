﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000AE RID: 174
	[GType(typeof(ModifierIntentGType))]
	public enum ModifierIntent
	{
		// Token: 0x040003C7 RID: 967
		PrimaryAccelerator,
		// Token: 0x040003C8 RID: 968
		ContextMenu,
		// Token: 0x040003C9 RID: 969
		ExtendSelection,
		// Token: 0x040003CA RID: 970
		ModifySelection,
		// Token: 0x040003CB RID: 971
		NoTextInput,
		// Token: 0x040003CC RID: 972
		ShiftGroup,
		// Token: 0x040003CD RID: 973
		DefaultModMask
	}
}
