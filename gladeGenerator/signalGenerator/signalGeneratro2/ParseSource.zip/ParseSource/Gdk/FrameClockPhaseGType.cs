﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200008A RID: 138
	internal class FrameClockPhaseGType
	{
		// Token: 0x1700017C RID: 380
		// (get) Token: 0x060005F3 RID: 1523 RVA: 0x00011C84 File Offset: 0x0000FE84
		public static GType GType
		{
			get
			{
				return new GType(FrameClockPhaseGType.gdk_frame_clock_phase_get_type());
			}
		}

		// Token: 0x04000316 RID: 790
		private static FrameClockPhaseGType.d_gdk_frame_clock_phase_get_type gdk_frame_clock_phase_get_type = FuncLoader.LoadFunction<FrameClockPhaseGType.d_gdk_frame_clock_phase_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_clock_phase_get_type"));

		// Token: 0x020002A4 RID: 676
		// (Invoke) Token: 0x06001117 RID: 4375
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_frame_clock_phase_get_type();
	}
}
