﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x0200012B RID: 299
	public class XBMData : Opaque
	{
		// Token: 0x06000B60 RID: 2912 RVA: 0x00021690 File Offset: 0x0001F890
		public XBMData(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170002F8 RID: 760
		// (get) Token: 0x06000B61 RID: 2913 RVA: 0x00021699 File Offset: 0x0001F899
		public static AbiStruct abi_info
		{
			get
			{
				if (XBMData._abi_info == null)
				{
					XBMData._abi_info = new AbiStruct(new List<AbiField>());
				}
				return XBMData._abi_info;
			}
		}

		// Token: 0x040006C4 RID: 1732
		private static AbiStruct _abi_info;
	}
}
