﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000BD RID: 189
	[GType(typeof(OwnerChangeGType))]
	public enum OwnerChange
	{
		// Token: 0x04000410 RID: 1040
		NewOwner,
		// Token: 0x04000411 RID: 1041
		Destroy,
		// Token: 0x04000412 RID: 1042
		Close
	}
}
