﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000C6 RID: 198
	public class PixbufAniAnimIter : PixbufAnimationIter
	{
		// Token: 0x060007C4 RID: 1988 RVA: 0x0001730A File Offset: 0x0001550A
		public PixbufAniAnimIter(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x060007C5 RID: 1989 RVA: 0x00017313 File Offset: 0x00015513
		protected PixbufAniAnimIter() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x170001FC RID: 508
		// (get) Token: 0x060007C6 RID: 1990 RVA: 0x00017334 File Offset: 0x00015534
		public new static GType GType
		{
			get
			{
				IntPtr val = PixbufAniAnimIter.gdk_pixbuf_ani_anim_iter_get_type();
				return new GType(val);
			}
		}

		// Token: 0x04000461 RID: 1121
		private static PixbufAniAnimIter.d_gdk_pixbuf_ani_anim_iter_get_type gdk_pixbuf_ani_anim_iter_get_type = FuncLoader.LoadFunction<PixbufAniAnimIter.d_gdk_pixbuf_ani_anim_iter_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_ani_anim_iter_get_type"));

		// Token: 0x02000366 RID: 870
		// (Invoke) Token: 0x0600141C RID: 5148
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_ani_anim_iter_get_type();
	}
}
