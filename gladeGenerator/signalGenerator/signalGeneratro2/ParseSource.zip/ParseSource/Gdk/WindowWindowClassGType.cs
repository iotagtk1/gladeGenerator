﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000128 RID: 296
	internal class WindowWindowClassGType
	{
		// Token: 0x170002F7 RID: 759
		// (get) Token: 0x06000B5D RID: 2909 RVA: 0x0002165B File Offset: 0x0001F85B
		public static GType GType
		{
			get
			{
				return new GType(WindowWindowClassGType.gdk_window_window_class_get_type());
			}
		}

		// Token: 0x040006B4 RID: 1716
		private static WindowWindowClassGType.d_gdk_window_window_class_get_type gdk_window_window_class_get_type = FuncLoader.LoadFunction<WindowWindowClassGType.d_gdk_window_window_class_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_window_class_get_type"));

		// Token: 0x020004D3 RID: 1235
		// (Invoke) Token: 0x060019CE RID: 6606
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_window_class_get_type();
	}
}
