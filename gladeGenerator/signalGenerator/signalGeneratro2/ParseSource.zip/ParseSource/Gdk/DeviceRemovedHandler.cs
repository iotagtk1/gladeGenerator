﻿using System;

namespace Gdk
{
	// Token: 0x0200005F RID: 95
	// (Invoke) Token: 0x06000432 RID: 1074
	public delegate void DeviceRemovedHandler(object o, DeviceRemovedArgs args);
}
