﻿using System;
using System.Runtime.InteropServices;
using Cairo;
using GLib;

namespace Gdk
{
	// Token: 0x02000070 RID: 112
	public class DrawingContext : Object
	{
		// Token: 0x060004F4 RID: 1268 RVA: 0x0000F188 File Offset: 0x0000D388
		public DrawingContext(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x060004F5 RID: 1269 RVA: 0x0000F191 File Offset: 0x0000D391
		protected DrawingContext() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x17000148 RID: 328
		// (get) Token: 0x060004F6 RID: 1270 RVA: 0x0000F1B0 File Offset: 0x0000D3B0
		[Property("window")]
		public Window Window
		{
			get
			{
				return Object.GetObject(DrawingContext.gdk_drawing_context_get_window(base.Handle)) as Window;
			}
		}

		// Token: 0x17000149 RID: 329
		// (get) Token: 0x060004F7 RID: 1271 RVA: 0x0000F1CC File Offset: 0x0000D3CC
		public new static AbiStruct class_abi
		{
			get
			{
				if (DrawingContext._class_abi == null)
				{
					DrawingContext._class_abi = new AbiStruct(Object.class_abi.Fields);
				}
				return DrawingContext._class_abi;
			}
		}

		// Token: 0x1700014A RID: 330
		// (get) Token: 0x060004F8 RID: 1272 RVA: 0x0000F1EE File Offset: 0x0000D3EE
		public Context CairoContext
		{
			get
			{
				return new Context(DrawingContext.gdk_drawing_context_get_cairo_context(base.Handle), false);
			}
		}

		// Token: 0x1700014B RID: 331
		// (get) Token: 0x060004F9 RID: 1273 RVA: 0x0000F206 File Offset: 0x0000D406
		public Region Clip
		{
			get
			{
				return new Region(DrawingContext.gdk_drawing_context_get_clip(base.Handle));
			}
		}

		// Token: 0x1700014C RID: 332
		// (get) Token: 0x060004FA RID: 1274 RVA: 0x0000F220 File Offset: 0x0000D420
		public new static GType GType
		{
			get
			{
				IntPtr val = DrawingContext.gdk_drawing_context_get_type();
				return new GType(val);
			}
		}

		// Token: 0x1700014D RID: 333
		// (get) Token: 0x060004FB RID: 1275 RVA: 0x0000F23E File Offset: 0x0000D43E
		public bool IsValid
		{
			get
			{
				return DrawingContext.gdk_drawing_context_is_valid(base.Handle);
			}
		}

		// Token: 0x1700014E RID: 334
		// (get) Token: 0x060004FC RID: 1276 RVA: 0x0000F250 File Offset: 0x0000D450
		public new static AbiStruct abi_info
		{
			get
			{
				if (DrawingContext._abi_info == null)
				{
					DrawingContext._abi_info = new AbiStruct(Object.abi_info.Fields);
				}
				return DrawingContext._abi_info;
			}
		}

		// Token: 0x04000222 RID: 546
		private static DrawingContext.d_gdk_drawing_context_get_window gdk_drawing_context_get_window = FuncLoader.LoadFunction<DrawingContext.d_gdk_drawing_context_get_window>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drawing_context_get_window"));

		// Token: 0x04000223 RID: 547
		private static AbiStruct _class_abi = null;

		// Token: 0x04000224 RID: 548
		private static DrawingContext.d_gdk_drawing_context_get_cairo_context gdk_drawing_context_get_cairo_context = FuncLoader.LoadFunction<DrawingContext.d_gdk_drawing_context_get_cairo_context>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drawing_context_get_cairo_context"));

		// Token: 0x04000225 RID: 549
		private static DrawingContext.d_gdk_drawing_context_get_clip gdk_drawing_context_get_clip = FuncLoader.LoadFunction<DrawingContext.d_gdk_drawing_context_get_clip>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drawing_context_get_clip"));

		// Token: 0x04000226 RID: 550
		private static DrawingContext.d_gdk_drawing_context_get_type gdk_drawing_context_get_type = FuncLoader.LoadFunction<DrawingContext.d_gdk_drawing_context_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drawing_context_get_type"));

		// Token: 0x04000227 RID: 551
		private static DrawingContext.d_gdk_drawing_context_is_valid gdk_drawing_context_is_valid = FuncLoader.LoadFunction<DrawingContext.d_gdk_drawing_context_is_valid>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drawing_context_is_valid"));

		// Token: 0x04000228 RID: 552
		private static AbiStruct _abi_info = null;

		// Token: 0x02000258 RID: 600
		// (Invoke) Token: 0x06000FE7 RID: 4071
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_drawing_context_get_window(IntPtr raw);

		// Token: 0x02000259 RID: 601
		// (Invoke) Token: 0x06000FEB RID: 4075
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_drawing_context_get_cairo_context(IntPtr raw);

		// Token: 0x0200025A RID: 602
		// (Invoke) Token: 0x06000FEF RID: 4079
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_drawing_context_get_clip(IntPtr raw);

		// Token: 0x0200025B RID: 603
		// (Invoke) Token: 0x06000FF3 RID: 4083
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_drawing_context_get_type();

		// Token: 0x0200025C RID: 604
		// (Invoke) Token: 0x06000FF7 RID: 4087
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_drawing_context_is_valid(IntPtr raw);
	}
}
