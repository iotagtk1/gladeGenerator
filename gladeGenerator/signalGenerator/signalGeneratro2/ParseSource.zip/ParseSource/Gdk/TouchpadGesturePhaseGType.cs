﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200010F RID: 271
	internal class TouchpadGesturePhaseGType
	{
		// Token: 0x17000297 RID: 663
		// (get) Token: 0x06000A3F RID: 2623 RVA: 0x0001DF1F File Offset: 0x0001C11F
		public static GType GType
		{
			get
			{
				return new GType(TouchpadGesturePhaseGType.gdk_touchpad_gesture_phase_get_type());
			}
		}

		// Token: 0x04000596 RID: 1430
		private static TouchpadGesturePhaseGType.d_gdk_touchpad_gesture_phase_get_type gdk_touchpad_gesture_phase_get_type = FuncLoader.LoadFunction<TouchpadGesturePhaseGType.d_gdk_touchpad_gesture_phase_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_touchpad_gesture_phase_get_type"));

		// Token: 0x02000413 RID: 1043
		// (Invoke) Token: 0x060016CE RID: 5838
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_touchpad_gesture_phase_get_type();
	}
}
