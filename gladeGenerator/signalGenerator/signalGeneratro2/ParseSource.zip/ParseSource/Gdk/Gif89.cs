﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x02000092 RID: 146
	public class Gif89 : Opaque
	{
		// Token: 0x06000617 RID: 1559 RVA: 0x00012196 File Offset: 0x00010396
		public Gif89(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700018C RID: 396
		// (get) Token: 0x06000618 RID: 1560 RVA: 0x0001219F File Offset: 0x0001039F
		public static AbiStruct abi_info
		{
			get
			{
				if (Gif89._abi_info == null)
				{
					Gif89._abi_info = new AbiStruct(new List<AbiField>());
				}
				return Gif89._abi_info;
			}
		}

		// Token: 0x04000332 RID: 818
		private static AbiStruct _abi_info;
	}
}
