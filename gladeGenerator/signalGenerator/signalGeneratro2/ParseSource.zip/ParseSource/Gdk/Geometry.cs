﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000091 RID: 145
	public struct Geometry : IEquatable<Geometry>
	{
		// Token: 0x06000611 RID: 1553 RVA: 0x00011FA0 File Offset: 0x000101A0
		public static Geometry New(IntPtr raw)
		{
			if (raw == IntPtr.Zero)
			{
				return Geometry.Zero;
			}
			return (Geometry)Marshal.PtrToStructure(raw, typeof(Geometry));
		}

		// Token: 0x06000612 RID: 1554 RVA: 0x00011FCC File Offset: 0x000101CC
		public bool Equals(Geometry other)
		{
			return this.MinWidth.Equals(other.MinWidth) && this.MinHeight.Equals(other.MinHeight) && this.MaxWidth.Equals(other.MaxWidth) && this.MaxHeight.Equals(other.MaxHeight) && this.BaseWidth.Equals(other.BaseWidth) && this.BaseHeight.Equals(other.BaseHeight) && this.WidthInc.Equals(other.WidthInc) && this.HeightInc.Equals(other.HeightInc) && this.MinAspect.Equals(other.MinAspect) && this.MaxAspect.Equals(other.MaxAspect) && this.WinGravity.Equals(other.WinGravity);
		}

		// Token: 0x06000613 RID: 1555 RVA: 0x000120C1 File Offset: 0x000102C1
		public override bool Equals(object other)
		{
			return other is Geometry && this.Equals((Geometry)other);
		}

		// Token: 0x06000614 RID: 1556 RVA: 0x000120DC File Offset: 0x000102DC
		public override int GetHashCode()
		{
			return base.GetType().FullName.GetHashCode() ^ this.MinWidth.GetHashCode() ^ this.MinHeight.GetHashCode() ^ this.MaxWidth.GetHashCode() ^ this.MaxHeight.GetHashCode() ^ this.BaseWidth.GetHashCode() ^ this.BaseHeight.GetHashCode() ^ this.WidthInc.GetHashCode() ^ this.HeightInc.GetHashCode() ^ this.MinAspect.GetHashCode() ^ this.MaxAspect.GetHashCode() ^ this.WinGravity.GetHashCode();
		}

		// Token: 0x1700018B RID: 395
		// (get) Token: 0x06000615 RID: 1557 RVA: 0x0001218D File Offset: 0x0001038D
		private static GType GType
		{
			get
			{
				return GType.Pointer;
			}
		}

		// Token: 0x04000326 RID: 806
		public int MinWidth;

		// Token: 0x04000327 RID: 807
		public int MinHeight;

		// Token: 0x04000328 RID: 808
		public int MaxWidth;

		// Token: 0x04000329 RID: 809
		public int MaxHeight;

		// Token: 0x0400032A RID: 810
		public int BaseWidth;

		// Token: 0x0400032B RID: 811
		public int BaseHeight;

		// Token: 0x0400032C RID: 812
		public int WidthInc;

		// Token: 0x0400032D RID: 813
		public int HeightInc;

		// Token: 0x0400032E RID: 814
		public double MinAspect;

		// Token: 0x0400032F RID: 815
		public double MaxAspect;

		// Token: 0x04000330 RID: 816
		public Gravity WinGravity;

		// Token: 0x04000331 RID: 817
		public static Geometry Zero;
	}
}
