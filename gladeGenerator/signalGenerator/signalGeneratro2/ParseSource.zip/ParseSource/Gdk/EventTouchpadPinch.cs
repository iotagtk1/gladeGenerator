﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000080 RID: 128
	public struct EventTouchpadPinch : IEquatable<EventTouchpadPinch>
	{
		// Token: 0x1700015F RID: 351
		// (get) Token: 0x06000568 RID: 1384 RVA: 0x000105AE File Offset: 0x0000E7AE
		// (set) Token: 0x06000569 RID: 1385 RVA: 0x000105C0 File Offset: 0x0000E7C0
		public Window Window
		{
			get
			{
				return Object.GetObject(this._window) as Window;
			}
			set
			{
				this._window = ((value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x0600056A RID: 1386 RVA: 0x000105D8 File Offset: 0x0000E7D8
		public static EventTouchpadPinch New(IntPtr raw)
		{
			if (raw == IntPtr.Zero)
			{
				return EventTouchpadPinch.Zero;
			}
			return (EventTouchpadPinch)Marshal.PtrToStructure(raw, typeof(EventTouchpadPinch));
		}

		// Token: 0x0600056B RID: 1387 RVA: 0x00010604 File Offset: 0x0000E804
		public bool Equals(EventTouchpadPinch other)
		{
			return this.Type.Equals(other.Type) && this.Window.Equals(other.Window) && this.SendEvent.Equals(other.SendEvent) && this.Phase.Equals(other.Phase) && this.NFingers.Equals(other.NFingers) && this.Time.Equals(other.Time) && this.X.Equals(other.X) && this.Y.Equals(other.Y) && this.Dx.Equals(other.Dx) && this.Dy.Equals(other.Dy) && this.AngleDelta.Equals(other.AngleDelta) && this.Scale.Equals(other.Scale) && this.XRoot.Equals(other.XRoot) && this.YRoot.Equals(other.YRoot) && this.State.Equals(other.State);
		}

		// Token: 0x0600056C RID: 1388 RVA: 0x00010752 File Offset: 0x0000E952
		public override bool Equals(object other)
		{
			return other is EventTouchpadPinch && this.Equals((EventTouchpadPinch)other);
		}

		// Token: 0x0600056D RID: 1389 RVA: 0x0001076C File Offset: 0x0000E96C
		public override int GetHashCode()
		{
			return base.GetType().FullName.GetHashCode() ^ this.Type.GetHashCode() ^ this.Window.GetHashCode() ^ this.SendEvent.GetHashCode() ^ this.Phase.GetHashCode() ^ this.NFingers.GetHashCode() ^ this.Time.GetHashCode() ^ this.X.GetHashCode() ^ this.Y.GetHashCode() ^ this.Dx.GetHashCode() ^ this.Dy.GetHashCode() ^ this.AngleDelta.GetHashCode() ^ this.Scale.GetHashCode() ^ this.XRoot.GetHashCode() ^ this.YRoot.GetHashCode() ^ this.State.GetHashCode();
		}

		// Token: 0x17000160 RID: 352
		// (get) Token: 0x0600056E RID: 1390 RVA: 0x0001084D File Offset: 0x0000EA4D
		private static GType GType
		{
			get
			{
				return GType.Pointer;
			}
		}

		// Token: 0x04000299 RID: 665
		public EventType Type;

		// Token: 0x0400029A RID: 666
		private IntPtr _window;

		// Token: 0x0400029B RID: 667
		public sbyte SendEvent;

		// Token: 0x0400029C RID: 668
		public sbyte Phase;

		// Token: 0x0400029D RID: 669
		public sbyte NFingers;

		// Token: 0x0400029E RID: 670
		public uint Time;

		// Token: 0x0400029F RID: 671
		public double X;

		// Token: 0x040002A0 RID: 672
		public double Y;

		// Token: 0x040002A1 RID: 673
		public double Dx;

		// Token: 0x040002A2 RID: 674
		public double Dy;

		// Token: 0x040002A3 RID: 675
		public double AngleDelta;

		// Token: 0x040002A4 RID: 676
		public double Scale;

		// Token: 0x040002A5 RID: 677
		public double XRoot;

		// Token: 0x040002A6 RID: 678
		public double YRoot;

		// Token: 0x040002A7 RID: 679
		public uint State;

		// Token: 0x040002A8 RID: 680
		public static EventTouchpadPinch Zero;
	}
}
