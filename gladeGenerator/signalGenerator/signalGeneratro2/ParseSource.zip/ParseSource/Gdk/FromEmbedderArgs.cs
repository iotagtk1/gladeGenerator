﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x0200008D RID: 141
	public class FromEmbedderArgs : SignalArgs
	{
		// Token: 0x17000185 RID: 389
		// (get) Token: 0x06000607 RID: 1543 RVA: 0x00011EFD File Offset: 0x000100FD
		public double EmbedderX
		{
			get
			{
				return (double)base.Args[0];
			}
		}

		// Token: 0x17000186 RID: 390
		// (get) Token: 0x06000608 RID: 1544 RVA: 0x00011F0C File Offset: 0x0001010C
		public double EmbedderY
		{
			get
			{
				return (double)base.Args[1];
			}
		}

		// Token: 0x17000187 RID: 391
		// (set) Token: 0x06000609 RID: 1545 RVA: 0x00011F1B File Offset: 0x0001011B
		public double OffscreenX
		{
			set
			{
				base.Args[2] = value;
			}
		}

		// Token: 0x17000188 RID: 392
		// (set) Token: 0x0600060A RID: 1546 RVA: 0x00011F2C File Offset: 0x0001012C
		public double OffscreenY
		{
			set
			{
				base.Args[3] = value;
			}
		}
	}
}
