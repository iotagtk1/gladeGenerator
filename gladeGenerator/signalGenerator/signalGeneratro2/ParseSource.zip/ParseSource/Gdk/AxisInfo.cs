﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x02000042 RID: 66
	public class AxisInfo : Opaque
	{
		// Token: 0x06000397 RID: 919 RVA: 0x0000B8B6 File Offset: 0x00009AB6
		public AxisInfo(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x06000398 RID: 920 RVA: 0x0000B8BF File Offset: 0x00009ABF
		public static AbiStruct abi_info
		{
			get
			{
				if (AxisInfo._abi_info == null)
				{
					AxisInfo._abi_info = new AbiStruct(new List<AbiField>());
				}
				return AxisInfo._abi_info;
			}
		}

		// Token: 0x04000123 RID: 291
		private static AbiStruct _abi_info;
	}
}
