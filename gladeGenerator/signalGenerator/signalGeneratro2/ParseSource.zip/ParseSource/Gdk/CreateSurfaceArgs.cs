﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000051 RID: 81
	public class CreateSurfaceArgs : SignalArgs
	{
		// Token: 0x170000FD RID: 253
		// (get) Token: 0x060003C4 RID: 964 RVA: 0x0000BDB2 File Offset: 0x00009FB2
		public int Width
		{
			get
			{
				return (int)base.Args[0];
			}
		}

		// Token: 0x170000FE RID: 254
		// (get) Token: 0x060003C5 RID: 965 RVA: 0x0000BDC1 File Offset: 0x00009FC1
		public int Height
		{
			get
			{
				return (int)base.Args[1];
			}
		}
	}
}
