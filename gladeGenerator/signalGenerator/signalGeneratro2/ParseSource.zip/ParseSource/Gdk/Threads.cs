﻿using System;
using System.Runtime.InteropServices;
using GLib;
using GLibSharp;

namespace Gdk
{
	// Token: 0x02000106 RID: 262
	public class Threads
	{
		// Token: 0x06000A1E RID: 2590 RVA: 0x0001DC20 File Offset: 0x0001BE20
		public static uint AddIdle(int priority, GSourceFunc function)
		{
			GSourceFuncWrapper gsourceFuncWrapper = new GSourceFuncWrapper(function);
			IntPtr data;
			DestroyNotify notify;
			if (function == null)
			{
				data = IntPtr.Zero;
				notify = null;
			}
			else
			{
				data = (IntPtr)GCHandle.Alloc(gsourceFuncWrapper);
				notify = DestroyHelper.NotifyHandler;
			}
			return Threads.gdk_threads_add_idle_full(priority, gsourceFuncWrapper.NativeDelegate, data, notify);
		}

		// Token: 0x06000A1F RID: 2591 RVA: 0x0001DC68 File Offset: 0x0001BE68
		public static uint AddTimeout(int priority, uint interval, GSourceFunc function)
		{
			GSourceFuncWrapper gsourceFuncWrapper = new GSourceFuncWrapper(function);
			IntPtr data;
			DestroyNotify notify;
			if (function == null)
			{
				data = IntPtr.Zero;
				notify = null;
			}
			else
			{
				data = (IntPtr)GCHandle.Alloc(gsourceFuncWrapper);
				notify = DestroyHelper.NotifyHandler;
			}
			return Threads.gdk_threads_add_timeout_full(priority, interval, gsourceFuncWrapper.NativeDelegate, data, notify);
		}

		// Token: 0x06000A20 RID: 2592 RVA: 0x0001DCB0 File Offset: 0x0001BEB0
		public static uint AddTimeoutSeconds(int priority, uint interval, GSourceFunc function)
		{
			GSourceFuncWrapper gsourceFuncWrapper = new GSourceFuncWrapper(function);
			IntPtr data;
			DestroyNotify notify;
			if (function == null)
			{
				data = IntPtr.Zero;
				notify = null;
			}
			else
			{
				data = (IntPtr)GCHandle.Alloc(gsourceFuncWrapper);
				notify = DestroyHelper.NotifyHandler;
			}
			return Threads.gdk_threads_add_timeout_seconds_full(priority, interval, gsourceFuncWrapper.NativeDelegate, data, notify);
		}

		// Token: 0x06000A21 RID: 2593 RVA: 0x0001DCF7 File Offset: 0x0001BEF7
		[Obsolete]
		public static void Enter()
		{
			Threads.gdk_threads_enter();
		}

		// Token: 0x06000A22 RID: 2594 RVA: 0x0001DD03 File Offset: 0x0001BF03
		[Obsolete]
		public static void Init()
		{
			Threads.gdk_threads_init();
		}

		// Token: 0x06000A23 RID: 2595 RVA: 0x0001DD0F File Offset: 0x0001BF0F
		[Obsolete]
		public static void Leave()
		{
			Threads.gdk_threads_leave();
		}

		// Token: 0x04000586 RID: 1414
		private static Threads.d_gdk_threads_add_idle_full gdk_threads_add_idle_full = FuncLoader.LoadFunction<Threads.d_gdk_threads_add_idle_full>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_threads_add_idle_full"));

		// Token: 0x04000587 RID: 1415
		private static Threads.d_gdk_threads_add_timeout_full gdk_threads_add_timeout_full = FuncLoader.LoadFunction<Threads.d_gdk_threads_add_timeout_full>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_threads_add_timeout_full"));

		// Token: 0x04000588 RID: 1416
		private static Threads.d_gdk_threads_add_timeout_seconds_full gdk_threads_add_timeout_seconds_full = FuncLoader.LoadFunction<Threads.d_gdk_threads_add_timeout_seconds_full>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_threads_add_timeout_seconds_full"));

		// Token: 0x04000589 RID: 1417
		private static Threads.d_gdk_threads_enter gdk_threads_enter = FuncLoader.LoadFunction<Threads.d_gdk_threads_enter>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_threads_enter"));

		// Token: 0x0400058A RID: 1418
		private static Threads.d_gdk_threads_init gdk_threads_init = FuncLoader.LoadFunction<Threads.d_gdk_threads_init>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_threads_init"));

		// Token: 0x0400058B RID: 1419
		private static Threads.d_gdk_threads_leave gdk_threads_leave = FuncLoader.LoadFunction<Threads.d_gdk_threads_leave>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_threads_leave"));

		// Token: 0x0200040D RID: 1037
		// (Invoke) Token: 0x060016B6 RID: 5814
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gdk_threads_add_idle_full(int priority, GSourceFuncNative function, IntPtr data, DestroyNotify notify);

		// Token: 0x0200040E RID: 1038
		// (Invoke) Token: 0x060016BA RID: 5818
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gdk_threads_add_timeout_full(int priority, uint interval, GSourceFuncNative function, IntPtr data, DestroyNotify notify);

		// Token: 0x0200040F RID: 1039
		// (Invoke) Token: 0x060016BE RID: 5822
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gdk_threads_add_timeout_seconds_full(int priority, uint interval, GSourceFuncNative function, IntPtr data, DestroyNotify notify);

		// Token: 0x02000410 RID: 1040
		// (Invoke) Token: 0x060016C2 RID: 5826
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_threads_enter();

		// Token: 0x02000411 RID: 1041
		// (Invoke) Token: 0x060016C6 RID: 5830
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_threads_init();

		// Token: 0x02000412 RID: 1042
		// (Invoke) Token: 0x060016CA RID: 5834
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_threads_leave();
	}
}
