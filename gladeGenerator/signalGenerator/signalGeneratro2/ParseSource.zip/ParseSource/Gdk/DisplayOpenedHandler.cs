﻿using System;

namespace Gdk
{
	// Token: 0x02000066 RID: 102
	// (Invoke) Token: 0x06000448 RID: 1096
	public delegate void DisplayOpenedHandler(object o, DisplayOpenedArgs args);
}
