﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000EA RID: 234
	public struct RGBA : IEquatable<RGBA>
	{
		// Token: 0x060008A4 RID: 2212 RVA: 0x00019837 File Offset: 0x00017A37
		public static RGBA New(IntPtr raw)
		{
			if (raw == IntPtr.Zero)
			{
				return RGBA.Zero;
			}
			return (RGBA)Marshal.PtrToStructure(raw, typeof(RGBA));
		}

		// Token: 0x060008A5 RID: 2213 RVA: 0x00019864 File Offset: 0x00017A64
		public RGBA Copy()
		{
			IntPtr intPtr = Marshal.AllocHGlobal(Marshal.SizeOf<RGBA>(this));
			Marshal.StructureToPtr<RGBA>(this, intPtr, false);
			RGBA result = RGBA.New(RGBA.gdk_rgba_copy(intPtr));
			RGBA.ReadNative(intPtr, ref this);
			Marshal.FreeHGlobal(intPtr);
			return result;
		}

		// Token: 0x060008A6 RID: 2214 RVA: 0x000198AC File Offset: 0x00017AAC
		public static bool Equal(IntPtr p1, IntPtr p2)
		{
			return RGBA.gdk_rgba_equal(p1, p2);
		}

		// Token: 0x060008A7 RID: 2215 RVA: 0x000198BC File Offset: 0x00017ABC
		public void Free()
		{
			IntPtr intPtr = Marshal.AllocHGlobal(Marshal.SizeOf<RGBA>(this));
			Marshal.StructureToPtr<RGBA>(this, intPtr, false);
			RGBA.gdk_rgba_free(intPtr);
			RGBA.ReadNative(intPtr, ref this);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x17000239 RID: 569
		// (get) Token: 0x060008A8 RID: 2216 RVA: 0x00019900 File Offset: 0x00017B00
		public static GType GType
		{
			get
			{
				IntPtr val = RGBA.gdk_rgba_get_type();
				return new GType(val);
			}
		}

		// Token: 0x060008A9 RID: 2217 RVA: 0x0001991E File Offset: 0x00017B1E
		public static uint Hash(IntPtr p)
		{
			return RGBA.gdk_rgba_hash(p);
		}

		// Token: 0x060008AA RID: 2218 RVA: 0x0001992C File Offset: 0x00017B2C
		public bool Parse(string spec)
		{
			IntPtr intPtr = Marshal.AllocHGlobal(Marshal.SizeOf<RGBA>(this));
			Marshal.StructureToPtr<RGBA>(this, intPtr, false);
			IntPtr intPtr2 = Marshaller.StringToPtrGStrdup(spec);
			bool result = RGBA.gdk_rgba_parse(intPtr, intPtr2);
			RGBA.ReadNative(intPtr, ref this);
			Marshal.FreeHGlobal(intPtr);
			Marshaller.Free(intPtr2);
			return result;
		}

		// Token: 0x060008AB RID: 2219 RVA: 0x00019980 File Offset: 0x00017B80
		public override string ToString()
		{
			IntPtr intPtr = Marshal.AllocHGlobal(Marshal.SizeOf<RGBA>(this));
			Marshal.StructureToPtr<RGBA>(this, intPtr, false);
			string result = Marshaller.PtrToStringGFree(RGBA.gdk_rgba_to_string(intPtr));
			RGBA.ReadNative(intPtr, ref this);
			Marshal.FreeHGlobal(intPtr);
			return result;
		}

		// Token: 0x060008AC RID: 2220 RVA: 0x000199C8 File Offset: 0x00017BC8
		private static void ReadNative(IntPtr native, ref RGBA target)
		{
			target = RGBA.New(native);
		}

		// Token: 0x060008AD RID: 2221 RVA: 0x000199D8 File Offset: 0x00017BD8
		public bool Equals(RGBA other)
		{
			return this.Red.Equals(other.Red) && this.Green.Equals(other.Green) && this.Blue.Equals(other.Blue) && this.Alpha.Equals(other.Alpha);
		}

		// Token: 0x060008AE RID: 2222 RVA: 0x00019A31 File Offset: 0x00017C31
		public override bool Equals(object other)
		{
			return other is RGBA && this.Equals((RGBA)other);
		}

		// Token: 0x060008AF RID: 2223 RVA: 0x00019A4C File Offset: 0x00017C4C
		public override int GetHashCode()
		{
			return base.GetType().FullName.GetHashCode() ^ this.Red.GetHashCode() ^ this.Green.GetHashCode() ^ this.Blue.GetHashCode() ^ this.Alpha.GetHashCode();
		}

		// Token: 0x060008B0 RID: 2224 RVA: 0x00019AA4 File Offset: 0x00017CA4
		public static explicit operator Value(RGBA boxed)
		{
			Value empty = Value.Empty;
			empty.Init(RGBA.GType);
			empty.Val = boxed;
			return empty;
		}

		// Token: 0x060008B1 RID: 2225 RVA: 0x00019AD1 File Offset: 0x00017CD1
		public static explicit operator RGBA(Value val)
		{
			return (RGBA)val.Val;
		}

		// Token: 0x040004F0 RID: 1264
		public double Red;

		// Token: 0x040004F1 RID: 1265
		public double Green;

		// Token: 0x040004F2 RID: 1266
		public double Blue;

		// Token: 0x040004F3 RID: 1267
		public double Alpha;

		// Token: 0x040004F4 RID: 1268
		public static RGBA Zero = default(RGBA);

		// Token: 0x040004F5 RID: 1269
		private static RGBA.d_gdk_rgba_copy gdk_rgba_copy = FuncLoader.LoadFunction<RGBA.d_gdk_rgba_copy>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_rgba_copy"));

		// Token: 0x040004F6 RID: 1270
		private static RGBA.d_gdk_rgba_equal gdk_rgba_equal = FuncLoader.LoadFunction<RGBA.d_gdk_rgba_equal>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_rgba_equal"));

		// Token: 0x040004F7 RID: 1271
		private static RGBA.d_gdk_rgba_free gdk_rgba_free = FuncLoader.LoadFunction<RGBA.d_gdk_rgba_free>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_rgba_free"));

		// Token: 0x040004F8 RID: 1272
		private static RGBA.d_gdk_rgba_get_type gdk_rgba_get_type = FuncLoader.LoadFunction<RGBA.d_gdk_rgba_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_rgba_get_type"));

		// Token: 0x040004F9 RID: 1273
		private static RGBA.d_gdk_rgba_hash gdk_rgba_hash = FuncLoader.LoadFunction<RGBA.d_gdk_rgba_hash>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_rgba_hash"));

		// Token: 0x040004FA RID: 1274
		private static RGBA.d_gdk_rgba_parse gdk_rgba_parse = FuncLoader.LoadFunction<RGBA.d_gdk_rgba_parse>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_rgba_parse"));

		// Token: 0x040004FB RID: 1275
		private static RGBA.d_gdk_rgba_to_string gdk_rgba_to_string = FuncLoader.LoadFunction<RGBA.d_gdk_rgba_to_string>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_rgba_to_string"));

		// Token: 0x020003A9 RID: 937
		// (Invoke) Token: 0x06001526 RID: 5414
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_rgba_copy(IntPtr raw);

		// Token: 0x020003AA RID: 938
		// (Invoke) Token: 0x0600152A RID: 5418
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_rgba_equal(IntPtr p1, IntPtr p2);

		// Token: 0x020003AB RID: 939
		// (Invoke) Token: 0x0600152E RID: 5422
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_rgba_free(IntPtr raw);

		// Token: 0x020003AC RID: 940
		// (Invoke) Token: 0x06001532 RID: 5426
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_rgba_get_type();

		// Token: 0x020003AD RID: 941
		// (Invoke) Token: 0x06001536 RID: 5430
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gdk_rgba_hash(IntPtr p);

		// Token: 0x020003AE RID: 942
		// (Invoke) Token: 0x0600153A RID: 5434
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_rgba_parse(IntPtr raw, IntPtr spec);

		// Token: 0x020003AF RID: 943
		// (Invoke) Token: 0x0600153E RID: 5438
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_rgba_to_string(IntPtr raw);
	}
}
