﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000F0 RID: 240
	public class SeatAddedArgs : SignalArgs
	{
		// Token: 0x17000280 RID: 640
		// (get) Token: 0x060009E8 RID: 2536 RVA: 0x0001D71D File Offset: 0x0001B91D
		public Seat P0
		{
			get
			{
				return (Seat)base.Args[0];
			}
		}
	}
}
