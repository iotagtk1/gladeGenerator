﻿using System;

namespace Gdk
{
	// Token: 0x0200004C RID: 76
	// (Invoke) Token: 0x060003B8 RID: 952
	public delegate void ClosedHandler(object o, ClosedArgs args);
}
