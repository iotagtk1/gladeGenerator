﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000109 RID: 265
	public struct TimeCoord : IEquatable<TimeCoord>
	{
		// Token: 0x06000A2A RID: 2602 RVA: 0x0001DE19 File Offset: 0x0001C019
		public static TimeCoord New(IntPtr raw)
		{
			if (raw == IntPtr.Zero)
			{
				return TimeCoord.Zero;
			}
			return (TimeCoord)Marshal.PtrToStructure(raw, typeof(TimeCoord));
		}

		// Token: 0x06000A2B RID: 2603 RVA: 0x0001DE43 File Offset: 0x0001C043
		public bool Equals(TimeCoord other)
		{
			return this.Time.Equals(other.Time) && this.Axes.Equals(other.Axes);
		}

		// Token: 0x06000A2C RID: 2604 RVA: 0x0001DE6B File Offset: 0x0001C06B
		public override bool Equals(object other)
		{
			return other is TimeCoord && this.Equals((TimeCoord)other);
		}

		// Token: 0x06000A2D RID: 2605 RVA: 0x0001DE83 File Offset: 0x0001C083
		public override int GetHashCode()
		{
			return base.GetType().FullName.GetHashCode() ^ this.Time.GetHashCode() ^ this.Axes.GetHashCode();
		}

		// Token: 0x17000291 RID: 657
		// (get) Token: 0x06000A2E RID: 2606 RVA: 0x0001DEB7 File Offset: 0x0001C0B7
		private static GType GType
		{
			get
			{
				return GType.Pointer;
			}
		}

		// Token: 0x0400058E RID: 1422
		public uint Time;

		// Token: 0x0400058F RID: 1423
		[MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
		public double[] Axes;

		// Token: 0x04000590 RID: 1424
		public static TimeCoord Zero;
	}
}
