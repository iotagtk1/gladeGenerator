﻿using System;
using System.Runtime.InteropServices;
using Cairo;
using GLib;
using Pango;

namespace Gdk
{
	// Token: 0x020000BF RID: 191
	public class PangoHelper
	{
		// Token: 0x0600075A RID: 1882 RVA: 0x000152B8 File Offset: 0x000134B8
		public static Pango.Context ContextGet()
		{
			return Object.GetObject(PangoHelper.gdk_pango_context_get()) as Pango.Context;
		}

		// Token: 0x0600075B RID: 1883 RVA: 0x000152CE File Offset: 0x000134CE
		public static Pango.Context ContextGetForDisplay(Display display)
		{
			return Object.GetObject(PangoHelper.gdk_pango_context_get_for_display((display == null) ? IntPtr.Zero : display.Handle)) as Pango.Context;
		}

		// Token: 0x0600075C RID: 1884 RVA: 0x000152F4 File Offset: 0x000134F4
		public static Pango.Context ContextGetForScreen(Screen screen)
		{
			return Object.GetObject(PangoHelper.gdk_pango_context_get_for_screen((screen == null) ? IntPtr.Zero : screen.Handle)) as Pango.Context;
		}

		// Token: 0x0600075D RID: 1885 RVA: 0x0001531A File Offset: 0x0001351A
		public static Region LayoutGetClipRegion(Layout layout, int x_origin, int y_origin, out int index_ranges, int n_ranges)
		{
			return new Region(PangoHelper.gdk_pango_layout_get_clip_region((layout == null) ? IntPtr.Zero : layout.Handle, x_origin, y_origin, out index_ranges, n_ranges));
		}

		// Token: 0x0600075E RID: 1886 RVA: 0x00015340 File Offset: 0x00013540
		public static Region LayoutLineGetClipRegion(LayoutLine line, int x_origin, int y_origin, out int index_ranges, int n_ranges)
		{
			return new Region(PangoHelper.gdk_pango_layout_line_get_clip_region((line == null) ? IntPtr.Zero : line.Handle, x_origin, y_origin, out index_ranges, n_ranges));
		}

		// Token: 0x04000414 RID: 1044
		private static PangoHelper.d_gdk_pango_context_get gdk_pango_context_get = FuncLoader.LoadFunction<PangoHelper.d_gdk_pango_context_get>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_pango_context_get"));

		// Token: 0x04000415 RID: 1045
		private static PangoHelper.d_gdk_pango_context_get_for_display gdk_pango_context_get_for_display = FuncLoader.LoadFunction<PangoHelper.d_gdk_pango_context_get_for_display>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_pango_context_get_for_display"));

		// Token: 0x04000416 RID: 1046
		private static PangoHelper.d_gdk_pango_context_get_for_screen gdk_pango_context_get_for_screen = FuncLoader.LoadFunction<PangoHelper.d_gdk_pango_context_get_for_screen>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_pango_context_get_for_screen"));

		// Token: 0x04000417 RID: 1047
		private static PangoHelper.d_gdk_pango_layout_get_clip_region gdk_pango_layout_get_clip_region = FuncLoader.LoadFunction<PangoHelper.d_gdk_pango_layout_get_clip_region>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_pango_layout_get_clip_region"));

		// Token: 0x04000418 RID: 1048
		private static PangoHelper.d_gdk_pango_layout_line_get_clip_region gdk_pango_layout_line_get_clip_region = FuncLoader.LoadFunction<PangoHelper.d_gdk_pango_layout_line_get_clip_region>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_pango_layout_line_get_clip_region"));

		// Token: 0x0200031D RID: 797
		// (Invoke) Token: 0x060012F9 RID: 4857
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pango_context_get();

		// Token: 0x0200031E RID: 798
		// (Invoke) Token: 0x060012FD RID: 4861
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pango_context_get_for_display(IntPtr display);

		// Token: 0x0200031F RID: 799
		// (Invoke) Token: 0x06001301 RID: 4865
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pango_context_get_for_screen(IntPtr screen);

		// Token: 0x02000320 RID: 800
		// (Invoke) Token: 0x06001305 RID: 4869
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pango_layout_get_clip_region(IntPtr layout, int x_origin, int y_origin, out int index_ranges, int n_ranges);

		// Token: 0x02000321 RID: 801
		// (Invoke) Token: 0x06001309 RID: 4873
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pango_layout_line_get_clip_region(IntPtr line, int x_origin, int y_origin, out int index_ranges, int n_ranges);
	}
}
