﻿using System;

namespace Gdk
{
	// Token: 0x02000072 RID: 114
	// (Invoke) Token: 0x06000503 RID: 1283
	public delegate void DropPerformedHandler(object o, DropPerformedArgs args);
}
