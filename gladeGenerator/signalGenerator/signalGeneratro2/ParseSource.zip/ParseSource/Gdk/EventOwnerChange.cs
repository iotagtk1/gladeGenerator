﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200002F RID: 47
	public class EventOwnerChange : Event
	{
		// Token: 0x06000327 RID: 807 RVA: 0x0000AC6D File Offset: 0x00008E6D
		public EventOwnerChange(IntPtr handle) : base(handle)
		{
		}

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x06000328 RID: 808 RVA: 0x0000AC76 File Offset: 0x00008E76
		private EventOwnerChange.NativeStruct Native
		{
			get
			{
				return (EventOwnerChange.NativeStruct)Marshal.PtrToStructure(base.Handle, typeof(EventOwnerChange.NativeStruct));
			}
		}

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x06000329 RID: 809 RVA: 0x0000AC92 File Offset: 0x00008E92
		// (set) Token: 0x0600032A RID: 810 RVA: 0x0000ACA0 File Offset: 0x00008EA0
		public uint Owner
		{
			get
			{
				return this.Native.owner;
			}
			set
			{
				EventOwnerChange.NativeStruct native = this.Native;
				native.owner = value;
				Marshal.StructureToPtr<EventOwnerChange.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x0600032B RID: 811 RVA: 0x0000ACC9 File Offset: 0x00008EC9
		// (set) Token: 0x0600032C RID: 812 RVA: 0x0000ACD8 File Offset: 0x00008ED8
		public OwnerChange Reason
		{
			get
			{
				return this.Native.reason;
			}
			set
			{
				EventOwnerChange.NativeStruct native = this.Native;
				native.reason = value;
				Marshal.StructureToPtr<EventOwnerChange.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x0600032D RID: 813 RVA: 0x0000AD04 File Offset: 0x00008F04
		// (set) Token: 0x0600032E RID: 814 RVA: 0x0000AD44 File Offset: 0x00008F44
		public Atom Selection
		{
			get
			{
				IntPtr selection = this.Native.selection;
				if (!(selection == IntPtr.Zero))
				{
					return (Atom)Opaque.GetOpaque(selection, typeof(Atom), false);
				}
				return null;
			}
			set
			{
				EventOwnerChange.NativeStruct native = this.Native;
				native.selection = ((value == null) ? IntPtr.Zero : value.Handle);
				Marshal.StructureToPtr<EventOwnerChange.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x0600032F RID: 815 RVA: 0x0000AD7C File Offset: 0x00008F7C
		// (set) Token: 0x06000330 RID: 816 RVA: 0x0000AD8C File Offset: 0x00008F8C
		public uint SelectionTime
		{
			get
			{
				return this.Native.selection_time;
			}
			set
			{
				EventOwnerChange.NativeStruct native = this.Native;
				native.selection_time = value;
				Marshal.StructureToPtr<EventOwnerChange.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x06000331 RID: 817 RVA: 0x0000ADB5 File Offset: 0x00008FB5
		// (set) Token: 0x06000332 RID: 818 RVA: 0x0000ADC4 File Offset: 0x00008FC4
		public uint Time
		{
			get
			{
				return this.Native.time;
			}
			set
			{
				EventOwnerChange.NativeStruct native = this.Native;
				native.time = value;
				Marshal.StructureToPtr<EventOwnerChange.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x020001E2 RID: 482
		private struct NativeStruct
		{
			// Token: 0x04000C5C RID: 3164
			public EventType type;

			// Token: 0x04000C5D RID: 3165
			public IntPtr window;

			// Token: 0x04000C5E RID: 3166
			public sbyte send_event;

			// Token: 0x04000C5F RID: 3167
			public uint owner;

			// Token: 0x04000C60 RID: 3168
			public OwnerChange reason;

			// Token: 0x04000C61 RID: 3169
			public IntPtr selection;

			// Token: 0x04000C62 RID: 3170
			public uint time;

			// Token: 0x04000C63 RID: 3171
			public uint selection_time;
		}
	}
}
