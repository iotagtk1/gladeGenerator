﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000053 RID: 83
	internal class CrossingModeGType
	{
		// Token: 0x170000FF RID: 255
		// (get) Token: 0x060003C7 RID: 967 RVA: 0x0000BDD8 File Offset: 0x00009FD8
		public static GType GType
		{
			get
			{
				return new GType(CrossingModeGType.gdk_crossing_mode_get_type());
			}
		}

		// Token: 0x04000150 RID: 336
		private static CrossingModeGType.d_gdk_crossing_mode_get_type gdk_crossing_mode_get_type = FuncLoader.LoadFunction<CrossingModeGType.d_gdk_crossing_mode_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_crossing_mode_get_type"));

		// Token: 0x02000203 RID: 515
		// (Invoke) Token: 0x06000E97 RID: 3735
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_crossing_mode_get_type();
	}
}
