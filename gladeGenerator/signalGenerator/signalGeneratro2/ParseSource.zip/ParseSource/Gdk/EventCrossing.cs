﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000028 RID: 40
	public class EventCrossing : Event
	{
		// Token: 0x060002D2 RID: 722 RVA: 0x0000A2CD File Offset: 0x000084CD
		public EventCrossing(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x060002D3 RID: 723 RVA: 0x0000A2D6 File Offset: 0x000084D6
		private EventCrossing.NativeStruct Native
		{
			get
			{
				return (EventCrossing.NativeStruct)Marshal.PtrToStructure(base.Handle, typeof(EventCrossing.NativeStruct));
			}
		}

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x060002D4 RID: 724 RVA: 0x0000A2F2 File Offset: 0x000084F2
		// (set) Token: 0x060002D5 RID: 725 RVA: 0x0000A300 File Offset: 0x00008500
		public NotifyType Detail
		{
			get
			{
				return this.Native.detail;
			}
			set
			{
				EventCrossing.NativeStruct native = this.Native;
				native.detail = value;
				Marshal.StructureToPtr<EventCrossing.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x060002D6 RID: 726 RVA: 0x0000A329 File Offset: 0x00008529
		// (set) Token: 0x060002D7 RID: 727 RVA: 0x0000A338 File Offset: 0x00008538
		public bool Focus
		{
			get
			{
				return this.Native.focus;
			}
			set
			{
				EventCrossing.NativeStruct native = this.Native;
				native.focus = value;
				Marshal.StructureToPtr<EventCrossing.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x060002D8 RID: 728 RVA: 0x0000A361 File Offset: 0x00008561
		// (set) Token: 0x060002D9 RID: 729 RVA: 0x0000A370 File Offset: 0x00008570
		public CrossingMode Mode
		{
			get
			{
				return this.Native.mode;
			}
			set
			{
				EventCrossing.NativeStruct native = this.Native;
				native.mode = value;
				Marshal.StructureToPtr<EventCrossing.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x060002DA RID: 730 RVA: 0x0000A399 File Offset: 0x00008599
		// (set) Token: 0x060002DB RID: 731 RVA: 0x0000A3A8 File Offset: 0x000085A8
		public ModifierType State
		{
			get
			{
				return (ModifierType)this.Native.state;
			}
			set
			{
				EventCrossing.NativeStruct native = this.Native;
				native.state = (uint)value;
				Marshal.StructureToPtr<EventCrossing.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x17000099 RID: 153
		// (get) Token: 0x060002DC RID: 732 RVA: 0x0000A3D1 File Offset: 0x000085D1
		// (set) Token: 0x060002DD RID: 733 RVA: 0x0000A3EC File Offset: 0x000085EC
		public Window SubWindow
		{
			get
			{
				return Object.GetObject(this.Native.subwindow, false) as Window;
			}
			set
			{
				EventCrossing.NativeStruct native = this.Native;
				native.subwindow = ((value == null) ? IntPtr.Zero : value.Handle);
				Marshal.StructureToPtr<EventCrossing.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x1700009A RID: 154
		// (get) Token: 0x060002DE RID: 734 RVA: 0x0000A424 File Offset: 0x00008624
		// (set) Token: 0x060002DF RID: 735 RVA: 0x0000A434 File Offset: 0x00008634
		public uint Time
		{
			get
			{
				return this.Native.time;
			}
			set
			{
				EventCrossing.NativeStruct native = this.Native;
				native.time = value;
				Marshal.StructureToPtr<EventCrossing.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x1700009B RID: 155
		// (get) Token: 0x060002E0 RID: 736 RVA: 0x0000A45D File Offset: 0x0000865D
		// (set) Token: 0x060002E1 RID: 737 RVA: 0x0000A46C File Offset: 0x0000866C
		public double X
		{
			get
			{
				return this.Native.x;
			}
			set
			{
				EventCrossing.NativeStruct native = this.Native;
				native.x = value;
				Marshal.StructureToPtr<EventCrossing.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x1700009C RID: 156
		// (get) Token: 0x060002E2 RID: 738 RVA: 0x0000A495 File Offset: 0x00008695
		// (set) Token: 0x060002E3 RID: 739 RVA: 0x0000A4A4 File Offset: 0x000086A4
		public double XRoot
		{
			get
			{
				return this.Native.x_root;
			}
			set
			{
				EventCrossing.NativeStruct native = this.Native;
				native.x_root = value;
				Marshal.StructureToPtr<EventCrossing.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x1700009D RID: 157
		// (get) Token: 0x060002E4 RID: 740 RVA: 0x0000A4CD File Offset: 0x000086CD
		// (set) Token: 0x060002E5 RID: 741 RVA: 0x0000A4DC File Offset: 0x000086DC
		public double Y
		{
			get
			{
				return this.Native.y;
			}
			set
			{
				EventCrossing.NativeStruct native = this.Native;
				native.y = value;
				Marshal.StructureToPtr<EventCrossing.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x060002E6 RID: 742 RVA: 0x0000A505 File Offset: 0x00008705
		// (set) Token: 0x060002E7 RID: 743 RVA: 0x0000A514 File Offset: 0x00008714
		public double YRoot
		{
			get
			{
				return this.Native.y_root;
			}
			set
			{
				EventCrossing.NativeStruct native = this.Native;
				native.y_root = value;
				Marshal.StructureToPtr<EventCrossing.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x020001DB RID: 475
		private struct NativeStruct
		{
			// Token: 0x04000C22 RID: 3106
			private EventType type;

			// Token: 0x04000C23 RID: 3107
			private IntPtr window;

			// Token: 0x04000C24 RID: 3108
			private sbyte send_event;

			// Token: 0x04000C25 RID: 3109
			public IntPtr subwindow;

			// Token: 0x04000C26 RID: 3110
			public uint time;

			// Token: 0x04000C27 RID: 3111
			public double x;

			// Token: 0x04000C28 RID: 3112
			public double y;

			// Token: 0x04000C29 RID: 3113
			public double x_root;

			// Token: 0x04000C2A RID: 3114
			public double y_root;

			// Token: 0x04000C2B RID: 3115
			public CrossingMode mode;

			// Token: 0x04000C2C RID: 3116
			public NotifyType detail;

			// Token: 0x04000C2D RID: 3117
			public bool focus;

			// Token: 0x04000C2E RID: 3118
			public uint state;
		}
	}
}
