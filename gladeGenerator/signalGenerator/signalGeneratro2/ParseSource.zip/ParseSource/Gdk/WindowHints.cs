﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x0200011C RID: 284
	[Flags]
	[GType(typeof(WindowHintsGType))]
	public enum WindowHints
	{
		// Token: 0x04000681 RID: 1665
		Pos = 1,
		// Token: 0x04000682 RID: 1666
		MinSize = 2,
		// Token: 0x04000683 RID: 1667
		MaxSize = 4,
		// Token: 0x04000684 RID: 1668
		BaseSize = 8,
		// Token: 0x04000685 RID: 1669
		Aspect = 16,
		// Token: 0x04000686 RID: 1670
		ResizeInc = 32,
		// Token: 0x04000687 RID: 1671
		WinGravity = 64,
		// Token: 0x04000688 RID: 1672
		UserPos = 128,
		// Token: 0x04000689 RID: 1673
		UserSize = 256
	}
}
