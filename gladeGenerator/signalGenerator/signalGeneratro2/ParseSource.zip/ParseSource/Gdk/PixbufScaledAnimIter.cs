﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x020000DA RID: 218
	public class PixbufScaledAnimIter : Opaque
	{
		// Token: 0x06000862 RID: 2146 RVA: 0x00018CCE File Offset: 0x00016ECE
		public PixbufScaledAnimIter(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700022B RID: 555
		// (get) Token: 0x06000863 RID: 2147 RVA: 0x00018CD7 File Offset: 0x00016ED7
		public static AbiStruct abi_info
		{
			get
			{
				if (PixbufScaledAnimIter._abi_info == null)
				{
					PixbufScaledAnimIter._abi_info = new AbiStruct(new List<AbiField>());
				}
				return PixbufScaledAnimIter._abi_info;
			}
		}

		// Token: 0x040004B7 RID: 1207
		private static AbiStruct _abi_info;
	}
}
