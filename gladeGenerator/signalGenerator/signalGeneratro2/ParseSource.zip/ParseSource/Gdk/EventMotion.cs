﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200002E RID: 46
	public class EventMotion : Event
	{
		// Token: 0x06000313 RID: 787 RVA: 0x0000A9D1 File Offset: 0x00008BD1
		public EventMotion(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x06000314 RID: 788 RVA: 0x0000A9DA File Offset: 0x00008BDA
		private EventMotion.NativeStruct Native
		{
			get
			{
				return (EventMotion.NativeStruct)Marshal.PtrToStructure(base.Handle, typeof(EventMotion.NativeStruct));
			}
		}

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x06000315 RID: 789 RVA: 0x0000A9F8 File Offset: 0x00008BF8
		// (set) Token: 0x06000316 RID: 790 RVA: 0x0000AA40 File Offset: 0x00008C40
		public double[] Axes
		{
			get
			{
				double[] array = null;
				IntPtr axes = this.Native.axes;
				if (axes != IntPtr.Zero)
				{
					array = new double[this.Device.NumAxes];
					Marshal.Copy(axes, array, 0, array.Length);
				}
				return array;
			}
			set
			{
				EventMotion.NativeStruct native = this.Native;
				if (native.axes == IntPtr.Zero || value.Length != this.Device.NumAxes)
				{
					throw new InvalidOperationException();
				}
				Marshal.Copy(value, 0, native.axes, value.Length);
			}
		}

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x06000317 RID: 791 RVA: 0x0000AA8C File Offset: 0x00008C8C
		// (set) Token: 0x06000318 RID: 792 RVA: 0x0000AAA4 File Offset: 0x00008CA4
		public Device Device
		{
			get
			{
				return Object.GetObject(this.Native.device, false) as Device;
			}
			set
			{
				EventMotion.NativeStruct native = this.Native;
				native.device = ((value == null) ? IntPtr.Zero : value.Handle);
				Marshal.StructureToPtr<EventMotion.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x06000319 RID: 793 RVA: 0x0000AADC File Offset: 0x00008CDC
		// (set) Token: 0x0600031A RID: 794 RVA: 0x0000AAEC File Offset: 0x00008CEC
		public bool IsHint
		{
			get
			{
				return this.Native.is_hint != 0;
			}
			set
			{
				EventMotion.NativeStruct native = this.Native;
				native.is_hint = (value ? 1 : 0);
				Marshal.StructureToPtr<EventMotion.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x0600031B RID: 795 RVA: 0x0000AB1C File Offset: 0x00008D1C
		// (set) Token: 0x0600031C RID: 796 RVA: 0x0000AB2C File Offset: 0x00008D2C
		public ModifierType State
		{
			get
			{
				return (ModifierType)this.Native.state;
			}
			set
			{
				EventMotion.NativeStruct native = this.Native;
				native.state = (uint)value;
				Marshal.StructureToPtr<EventMotion.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x0600031D RID: 797 RVA: 0x0000AB55 File Offset: 0x00008D55
		// (set) Token: 0x0600031E RID: 798 RVA: 0x0000AB64 File Offset: 0x00008D64
		public uint Time
		{
			get
			{
				return this.Native.time;
			}
			set
			{
				EventMotion.NativeStruct native = this.Native;
				native.time = value;
				Marshal.StructureToPtr<EventMotion.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x0600031F RID: 799 RVA: 0x0000AB8D File Offset: 0x00008D8D
		// (set) Token: 0x06000320 RID: 800 RVA: 0x0000AB9C File Offset: 0x00008D9C
		public double X
		{
			get
			{
				return this.Native.x;
			}
			set
			{
				EventMotion.NativeStruct native = this.Native;
				native.x = value;
				Marshal.StructureToPtr<EventMotion.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x06000321 RID: 801 RVA: 0x0000ABC5 File Offset: 0x00008DC5
		// (set) Token: 0x06000322 RID: 802 RVA: 0x0000ABD4 File Offset: 0x00008DD4
		public double XRoot
		{
			get
			{
				return this.Native.x_root;
			}
			set
			{
				EventMotion.NativeStruct native = this.Native;
				native.x_root = value;
				Marshal.StructureToPtr<EventMotion.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x06000323 RID: 803 RVA: 0x0000ABFD File Offset: 0x00008DFD
		// (set) Token: 0x06000324 RID: 804 RVA: 0x0000AC0C File Offset: 0x00008E0C
		public double Y
		{
			get
			{
				return this.Native.y;
			}
			set
			{
				EventMotion.NativeStruct native = this.Native;
				native.y = value;
				Marshal.StructureToPtr<EventMotion.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000BE RID: 190
		// (get) Token: 0x06000325 RID: 805 RVA: 0x0000AC35 File Offset: 0x00008E35
		// (set) Token: 0x06000326 RID: 806 RVA: 0x0000AC44 File Offset: 0x00008E44
		public double YRoot
		{
			get
			{
				return this.Native.y_root;
			}
			set
			{
				EventMotion.NativeStruct native = this.Native;
				native.y_root = value;
				Marshal.StructureToPtr<EventMotion.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x020001E1 RID: 481
		private struct NativeStruct
		{
			// Token: 0x04000C50 RID: 3152
			private EventType type;

			// Token: 0x04000C51 RID: 3153
			private IntPtr window;

			// Token: 0x04000C52 RID: 3154
			private sbyte send_event;

			// Token: 0x04000C53 RID: 3155
			public uint time;

			// Token: 0x04000C54 RID: 3156
			public double x;

			// Token: 0x04000C55 RID: 3157
			public double y;

			// Token: 0x04000C56 RID: 3158
			public IntPtr axes;

			// Token: 0x04000C57 RID: 3159
			public uint state;

			// Token: 0x04000C58 RID: 3160
			public short is_hint;

			// Token: 0x04000C59 RID: 3161
			public IntPtr device;

			// Token: 0x04000C5A RID: 3162
			public double x_root;

			// Token: 0x04000C5B RID: 3163
			public double y_root;
		}
	}
}
