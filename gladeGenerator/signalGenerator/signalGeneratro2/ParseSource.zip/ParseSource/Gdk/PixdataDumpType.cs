﻿using System;

namespace Gdk
{
	// Token: 0x020000E0 RID: 224
	[Flags]
	public enum PixdataDumpType
	{
		// Token: 0x040004CB RID: 1227
		PixdataStream = 0,
		// Token: 0x040004CC RID: 1228
		PixdataStruct = 1,
		// Token: 0x040004CD RID: 1229
		Macros = 2,
		// Token: 0x040004CE RID: 1230
		Gtypes = 3,
		// Token: 0x040004CF RID: 1231
		Ctypes = 256,
		// Token: 0x040004D0 RID: 1232
		Static = 512,
		// Token: 0x040004D1 RID: 1233
		Const = 1024,
		// Token: 0x040004D2 RID: 1234
		RleDecoder = 65536
	}
}
