﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000034 RID: 52
	public class EventSetting : Event
	{
		// Token: 0x06000363 RID: 867 RVA: 0x0000B3B1 File Offset: 0x000095B1
		public EventSetting(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170000DD RID: 221
		// (get) Token: 0x06000364 RID: 868 RVA: 0x0000B3BA File Offset: 0x000095BA
		private EventSetting.NativeStruct Native
		{
			get
			{
				return (EventSetting.NativeStruct)Marshal.PtrToStructure(base.Handle, typeof(EventSetting.NativeStruct));
			}
		}

		// Token: 0x170000DE RID: 222
		// (get) Token: 0x06000365 RID: 869 RVA: 0x0000B3D6 File Offset: 0x000095D6
		// (set) Token: 0x06000366 RID: 870 RVA: 0x0000B3E4 File Offset: 0x000095E4
		public SettingAction Action
		{
			get
			{
				return this.Native.action;
			}
			set
			{
				EventSetting.NativeStruct native = this.Native;
				native.action = value;
				Marshal.StructureToPtr<EventSetting.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x06000367 RID: 871 RVA: 0x0000B40D File Offset: 0x0000960D
		// (set) Token: 0x06000368 RID: 872 RVA: 0x0000B420 File Offset: 0x00009620
		public string Name
		{
			get
			{
				return Marshaller.Utf8PtrToString(this.Native.name);
			}
			set
			{
				EventSetting.NativeStruct native = this.Native;
				Marshaller.Free(native.name);
				native.name = Marshaller.StringToPtrGStrdup(value);
				Marshal.StructureToPtr<EventSetting.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x020001E7 RID: 487
		private struct NativeStruct
		{
			// Token: 0x04000C84 RID: 3204
			private EventType type;

			// Token: 0x04000C85 RID: 3205
			private IntPtr window;

			// Token: 0x04000C86 RID: 3206
			private sbyte send_event;

			// Token: 0x04000C87 RID: 3207
			public SettingAction action;

			// Token: 0x04000C88 RID: 3208
			public IntPtr name;
		}
	}
}
