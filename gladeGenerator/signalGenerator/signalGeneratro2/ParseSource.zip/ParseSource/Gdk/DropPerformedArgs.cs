﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000073 RID: 115
	public class DropPerformedArgs : SignalArgs
	{
		// Token: 0x1700014F RID: 335
		// (get) Token: 0x06000506 RID: 1286 RVA: 0x0000F389 File Offset: 0x0000D589
		public uint Time
		{
			get
			{
				return (uint)base.Args[0];
			}
		}
	}
}
