﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000032 RID: 50
	public class EventScroll : Event
	{
		// Token: 0x06000341 RID: 833 RVA: 0x0000AF8D File Offset: 0x0000918D
		public EventScroll(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170000CC RID: 204
		// (get) Token: 0x06000342 RID: 834 RVA: 0x0000AF96 File Offset: 0x00009196
		private EventScroll.NativeStruct Native
		{
			get
			{
				return (EventScroll.NativeStruct)Marshal.PtrToStructure(base.Handle, typeof(EventScroll.NativeStruct));
			}
		}

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x06000343 RID: 835 RVA: 0x0000AFB2 File Offset: 0x000091B2
		// (set) Token: 0x06000344 RID: 836 RVA: 0x0000AFCC File Offset: 0x000091CC
		public Device Device
		{
			get
			{
				return Object.GetObject(this.Native.device, false) as Device;
			}
			set
			{
				EventScroll.NativeStruct native = this.Native;
				native.device = ((value == null) ? IntPtr.Zero : value.Handle);
				Marshal.StructureToPtr<EventScroll.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x06000345 RID: 837 RVA: 0x0000B004 File Offset: 0x00009204
		// (set) Token: 0x06000346 RID: 838 RVA: 0x0000B014 File Offset: 0x00009214
		public ScrollDirection Direction
		{
			get
			{
				return this.Native.direction;
			}
			set
			{
				EventScroll.NativeStruct native = this.Native;
				native.direction = value;
				Marshal.StructureToPtr<EventScroll.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x06000347 RID: 839 RVA: 0x0000B03D File Offset: 0x0000923D
		// (set) Token: 0x06000348 RID: 840 RVA: 0x0000B04C File Offset: 0x0000924C
		public ModifierType State
		{
			get
			{
				return (ModifierType)this.Native.state;
			}
			set
			{
				EventScroll.NativeStruct native = this.Native;
				native.state = (uint)value;
				Marshal.StructureToPtr<EventScroll.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x06000349 RID: 841 RVA: 0x0000B075 File Offset: 0x00009275
		// (set) Token: 0x0600034A RID: 842 RVA: 0x0000B084 File Offset: 0x00009284
		public uint Time
		{
			get
			{
				return this.Native.time;
			}
			set
			{
				EventScroll.NativeStruct native = this.Native;
				native.time = value;
				Marshal.StructureToPtr<EventScroll.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x0600034B RID: 843 RVA: 0x0000B0AD File Offset: 0x000092AD
		// (set) Token: 0x0600034C RID: 844 RVA: 0x0000B0BC File Offset: 0x000092BC
		public double X
		{
			get
			{
				return this.Native.x;
			}
			set
			{
				EventScroll.NativeStruct native = this.Native;
				native.x = value;
				Marshal.StructureToPtr<EventScroll.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x0600034D RID: 845 RVA: 0x0000B0E5 File Offset: 0x000092E5
		// (set) Token: 0x0600034E RID: 846 RVA: 0x0000B0F4 File Offset: 0x000092F4
		public double XRoot
		{
			get
			{
				return this.Native.x_root;
			}
			set
			{
				EventScroll.NativeStruct native = this.Native;
				native.x_root = value;
				Marshal.StructureToPtr<EventScroll.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x0600034F RID: 847 RVA: 0x0000B11D File Offset: 0x0000931D
		// (set) Token: 0x06000350 RID: 848 RVA: 0x0000B12C File Offset: 0x0000932C
		public double DeltaX
		{
			get
			{
				return this.Native.delta_x;
			}
			set
			{
				EventScroll.NativeStruct native = this.Native;
				native.delta_x = value;
				Marshal.StructureToPtr<EventScroll.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x06000351 RID: 849 RVA: 0x0000B155 File Offset: 0x00009355
		// (set) Token: 0x06000352 RID: 850 RVA: 0x0000B164 File Offset: 0x00009364
		public double Y
		{
			get
			{
				return this.Native.y;
			}
			set
			{
				EventScroll.NativeStruct native = this.Native;
				native.y = value;
				Marshal.StructureToPtr<EventScroll.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x06000353 RID: 851 RVA: 0x0000B18D File Offset: 0x0000938D
		// (set) Token: 0x06000354 RID: 852 RVA: 0x0000B19C File Offset: 0x0000939C
		public double YRoot
		{
			get
			{
				return this.Native.y_root;
			}
			set
			{
				EventScroll.NativeStruct native = this.Native;
				native.y_root = value;
				Marshal.StructureToPtr<EventScroll.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x06000355 RID: 853 RVA: 0x0000B1C5 File Offset: 0x000093C5
		// (set) Token: 0x06000356 RID: 854 RVA: 0x0000B1D4 File Offset: 0x000093D4
		public double DeltaY
		{
			get
			{
				return this.Native.delta_y;
			}
			set
			{
				EventScroll.NativeStruct native = this.Native;
				native.delta_y = value;
				Marshal.StructureToPtr<EventScroll.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x020001E5 RID: 485
		private struct NativeStruct
		{
			// Token: 0x04000C6F RID: 3183
			private EventType type;

			// Token: 0x04000C70 RID: 3184
			private IntPtr window;

			// Token: 0x04000C71 RID: 3185
			private sbyte send_event;

			// Token: 0x04000C72 RID: 3186
			public uint time;

			// Token: 0x04000C73 RID: 3187
			public double x;

			// Token: 0x04000C74 RID: 3188
			public double y;

			// Token: 0x04000C75 RID: 3189
			public uint state;

			// Token: 0x04000C76 RID: 3190
			public ScrollDirection direction;

			// Token: 0x04000C77 RID: 3191
			public IntPtr device;

			// Token: 0x04000C78 RID: 3192
			public double x_root;

			// Token: 0x04000C79 RID: 3193
			public double y_root;

			// Token: 0x04000C7A RID: 3194
			public double delta_x;

			// Token: 0x04000C7B RID: 3195
			public double delta_y;
		}
	}
}
