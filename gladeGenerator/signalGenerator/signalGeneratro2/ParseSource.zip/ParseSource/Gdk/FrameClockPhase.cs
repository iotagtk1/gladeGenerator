﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000089 RID: 137
	[Flags]
	[GType(typeof(FrameClockPhaseGType))]
	public enum FrameClockPhase
	{
		// Token: 0x0400030E RID: 782
		None = 0,
		// Token: 0x0400030F RID: 783
		FlushEvents = 1,
		// Token: 0x04000310 RID: 784
		BeforePaint = 2,
		// Token: 0x04000311 RID: 785
		Update = 4,
		// Token: 0x04000312 RID: 786
		Layout = 8,
		// Token: 0x04000313 RID: 787
		Paint = 16,
		// Token: 0x04000314 RID: 788
		ResumeEvents = 32,
		// Token: 0x04000315 RID: 789
		AfterPaint = 64
	}
}
