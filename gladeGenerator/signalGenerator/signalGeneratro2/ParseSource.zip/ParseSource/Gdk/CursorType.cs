﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000055 RID: 85
	[GType(typeof(CursorTypeGType))]
	public enum CursorType
	{
		// Token: 0x0400015F RID: 351
		XCursor,
		// Token: 0x04000160 RID: 352
		Arrow = 2,
		// Token: 0x04000161 RID: 353
		BasedArrowDown = 4,
		// Token: 0x04000162 RID: 354
		BasedArrowUp = 6,
		// Token: 0x04000163 RID: 355
		Boat = 8,
		// Token: 0x04000164 RID: 356
		Bogosity = 10,
		// Token: 0x04000165 RID: 357
		BottomLeftCorner = 12,
		// Token: 0x04000166 RID: 358
		BottomRightCorner = 14,
		// Token: 0x04000167 RID: 359
		BottomSide = 16,
		// Token: 0x04000168 RID: 360
		BottomTee = 18,
		// Token: 0x04000169 RID: 361
		BoxSpiral = 20,
		// Token: 0x0400016A RID: 362
		CenterPtr = 22,
		// Token: 0x0400016B RID: 363
		Circle = 24,
		// Token: 0x0400016C RID: 364
		Clock = 26,
		// Token: 0x0400016D RID: 365
		CoffeeMug = 28,
		// Token: 0x0400016E RID: 366
		Cross = 30,
		// Token: 0x0400016F RID: 367
		CrossReverse = 32,
		// Token: 0x04000170 RID: 368
		Crosshair = 34,
		// Token: 0x04000171 RID: 369
		DiamondCross = 36,
		// Token: 0x04000172 RID: 370
		Dot = 38,
		// Token: 0x04000173 RID: 371
		Dotbox = 40,
		// Token: 0x04000174 RID: 372
		DoubleArrow = 42,
		// Token: 0x04000175 RID: 373
		DraftLarge = 44,
		// Token: 0x04000176 RID: 374
		DraftSmall = 46,
		// Token: 0x04000177 RID: 375
		DrapedBox = 48,
		// Token: 0x04000178 RID: 376
		Exchange = 50,
		// Token: 0x04000179 RID: 377
		Fleur = 52,
		// Token: 0x0400017A RID: 378
		Gobbler = 54,
		// Token: 0x0400017B RID: 379
		Gumby = 56,
		// Token: 0x0400017C RID: 380
		Hand1 = 58,
		// Token: 0x0400017D RID: 381
		Hand2 = 60,
		// Token: 0x0400017E RID: 382
		Heart = 62,
		// Token: 0x0400017F RID: 383
		Icon = 64,
		// Token: 0x04000180 RID: 384
		IronCross = 66,
		// Token: 0x04000181 RID: 385
		LeftPtr = 68,
		// Token: 0x04000182 RID: 386
		LeftSide = 70,
		// Token: 0x04000183 RID: 387
		LeftTee = 72,
		// Token: 0x04000184 RID: 388
		Leftbutton = 74,
		// Token: 0x04000185 RID: 389
		LlAngle = 76,
		// Token: 0x04000186 RID: 390
		LrAngle = 78,
		// Token: 0x04000187 RID: 391
		Man = 80,
		// Token: 0x04000188 RID: 392
		Middlebutton = 82,
		// Token: 0x04000189 RID: 393
		Mouse = 84,
		// Token: 0x0400018A RID: 394
		Pencil = 86,
		// Token: 0x0400018B RID: 395
		Pirate = 88,
		// Token: 0x0400018C RID: 396
		Plus = 90,
		// Token: 0x0400018D RID: 397
		QuestionArrow = 92,
		// Token: 0x0400018E RID: 398
		RightPtr = 94,
		// Token: 0x0400018F RID: 399
		RightSide = 96,
		// Token: 0x04000190 RID: 400
		RightTee = 98,
		// Token: 0x04000191 RID: 401
		Rightbutton = 100,
		// Token: 0x04000192 RID: 402
		RtlLogo = 102,
		// Token: 0x04000193 RID: 403
		Sailboat = 104,
		// Token: 0x04000194 RID: 404
		SbDownArrow = 106,
		// Token: 0x04000195 RID: 405
		SbHDoubleArrow = 108,
		// Token: 0x04000196 RID: 406
		SbLeftArrow = 110,
		// Token: 0x04000197 RID: 407
		SbRightArrow = 112,
		// Token: 0x04000198 RID: 408
		SbUpArrow = 114,
		// Token: 0x04000199 RID: 409
		SbVDoubleArrow = 116,
		// Token: 0x0400019A RID: 410
		Shuttle = 118,
		// Token: 0x0400019B RID: 411
		Sizing = 120,
		// Token: 0x0400019C RID: 412
		Spider = 122,
		// Token: 0x0400019D RID: 413
		Spraycan = 124,
		// Token: 0x0400019E RID: 414
		Star = 126,
		// Token: 0x0400019F RID: 415
		Target = 128,
		// Token: 0x040001A0 RID: 416
		Tcross = 130,
		// Token: 0x040001A1 RID: 417
		TopLeftArrow = 132,
		// Token: 0x040001A2 RID: 418
		TopLeftCorner = 134,
		// Token: 0x040001A3 RID: 419
		TopRightCorner = 136,
		// Token: 0x040001A4 RID: 420
		TopSide = 138,
		// Token: 0x040001A5 RID: 421
		TopTee = 140,
		// Token: 0x040001A6 RID: 422
		Trek = 142,
		// Token: 0x040001A7 RID: 423
		UlAngle = 144,
		// Token: 0x040001A8 RID: 424
		Umbrella = 146,
		// Token: 0x040001A9 RID: 425
		UrAngle = 148,
		// Token: 0x040001AA RID: 426
		Watch = 150,
		// Token: 0x040001AB RID: 427
		Xterm = 152,
		// Token: 0x040001AC RID: 428
		LastCursor,
		// Token: 0x040001AD RID: 429
		BlankCursor = -2,
		// Token: 0x040001AE RID: 430
		CursorIsPixmap
	}
}
