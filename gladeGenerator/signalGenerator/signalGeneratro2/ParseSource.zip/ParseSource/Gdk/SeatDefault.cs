﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000F3 RID: 243
	public class SeatDefault : Seat
	{
		// Token: 0x060009ED RID: 2541 RVA: 0x0001D769 File Offset: 0x0001B969
		public SeatDefault(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000282 RID: 642
		// (get) Token: 0x060009EE RID: 2542 RVA: 0x0001D772 File Offset: 0x0001B972
		public new static AbiStruct abi_info
		{
			get
			{
				if (SeatDefault._abi_info == null)
				{
					SeatDefault._abi_info = new AbiStruct(Seat.abi_info.Fields);
				}
				return SeatDefault._abi_info;
			}
		}

		// Token: 0x04000561 RID: 1377
		private static AbiStruct _abi_info;
	}
}
