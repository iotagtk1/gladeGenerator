﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000B0 RID: 176
	[Flags]
	[GType(typeof(ModifierTypeGType))]
	public enum ModifierType
	{
		// Token: 0x040003D0 RID: 976
		ShiftMask = 1,
		// Token: 0x040003D1 RID: 977
		LockMask = 2,
		// Token: 0x040003D2 RID: 978
		ControlMask = 4,
		// Token: 0x040003D3 RID: 979
		Mod1Mask = 8,
		// Token: 0x040003D4 RID: 980
		Mod2Mask = 16,
		// Token: 0x040003D5 RID: 981
		Mod3Mask = 32,
		// Token: 0x040003D6 RID: 982
		Mod4Mask = 64,
		// Token: 0x040003D7 RID: 983
		Mod5Mask = 128,
		// Token: 0x040003D8 RID: 984
		Button1Mask = 256,
		// Token: 0x040003D9 RID: 985
		Button2Mask = 512,
		// Token: 0x040003DA RID: 986
		Button3Mask = 1024,
		// Token: 0x040003DB RID: 987
		Button4Mask = 2048,
		// Token: 0x040003DC RID: 988
		Button5Mask = 4096,
		// Token: 0x040003DD RID: 989
		ModifierReserved13Mask = 8192,
		// Token: 0x040003DE RID: 990
		ModifierReserved14Mask = 16384,
		// Token: 0x040003DF RID: 991
		ModifierReserved15Mask = 32768,
		// Token: 0x040003E0 RID: 992
		ModifierReserved16Mask = 65536,
		// Token: 0x040003E1 RID: 993
		ModifierReserved17Mask = 131072,
		// Token: 0x040003E2 RID: 994
		ModifierReserved18Mask = 262144,
		// Token: 0x040003E3 RID: 995
		ModifierReserved19Mask = 524288,
		// Token: 0x040003E4 RID: 996
		ModifierReserved20Mask = 1048576,
		// Token: 0x040003E5 RID: 997
		ModifierReserved21Mask = 2097152,
		// Token: 0x040003E6 RID: 998
		ModifierReserved22Mask = 4194304,
		// Token: 0x040003E7 RID: 999
		ModifierReserved23Mask = 8388608,
		// Token: 0x040003E8 RID: 1000
		ModifierReserved24Mask = 16777216,
		// Token: 0x040003E9 RID: 1001
		ModifierReserved25Mask = 33554432,
		// Token: 0x040003EA RID: 1002
		SuperMask = 67108864,
		// Token: 0x040003EB RID: 1003
		HyperMask = 134217728,
		// Token: 0x040003EC RID: 1004
		MetaMask = 268435456,
		// Token: 0x040003ED RID: 1005
		ModifierReserved29Mask = 536870912,
		// Token: 0x040003EE RID: 1006
		ReleaseMask = 1073741824,
		// Token: 0x040003EF RID: 1007
		ModifierMask = 1073750015,
		// Token: 0x040003F0 RID: 1008
		None = 0
	}
}
