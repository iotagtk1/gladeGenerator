﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x0200010B RID: 267
	public class ToEmbedderArgs : SignalArgs
	{
		// Token: 0x17000292 RID: 658
		// (get) Token: 0x06000A34 RID: 2612 RVA: 0x0001DEC0 File Offset: 0x0001C0C0
		public double OffscreenX
		{
			get
			{
				return (double)base.Args[0];
			}
		}

		// Token: 0x17000293 RID: 659
		// (get) Token: 0x06000A35 RID: 2613 RVA: 0x0001DECF File Offset: 0x0001C0CF
		public double OffscreenY
		{
			get
			{
				return (double)base.Args[1];
			}
		}

		// Token: 0x17000294 RID: 660
		// (set) Token: 0x06000A36 RID: 2614 RVA: 0x0001DEDE File Offset: 0x0001C0DE
		public double EmbedderX
		{
			set
			{
				base.Args[2] = value;
			}
		}

		// Token: 0x17000295 RID: 661
		// (set) Token: 0x06000A37 RID: 2615 RVA: 0x0001DEEF File Offset: 0x0001C0EF
		public double EmbedderY
		{
			set
			{
				base.Args[3] = value;
			}
		}
	}
}
