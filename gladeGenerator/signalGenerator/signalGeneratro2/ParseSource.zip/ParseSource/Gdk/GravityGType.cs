﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200009D RID: 157
	internal class GravityGType
	{
		// Token: 0x170001A9 RID: 425
		// (get) Token: 0x06000665 RID: 1637 RVA: 0x00012F7F File Offset: 0x0001117F
		public static GType GType
		{
			get
			{
				return new GType(GravityGType.gdk_gravity_get_type());
			}
		}

		// Token: 0x0400037B RID: 891
		private static GravityGType.d_gdk_gravity_get_type gdk_gravity_get_type = FuncLoader.LoadFunction<GravityGType.d_gdk_gravity_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gravity_get_type"));

		// Token: 0x020002DA RID: 730
		// (Invoke) Token: 0x060011ED RID: 4589
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_gravity_get_type();
	}
}
