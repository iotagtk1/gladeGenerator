﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000FF RID: 255
	[GType(typeof(SubpixelLayoutGType))]
	public enum SubpixelLayout
	{
		// Token: 0x0400057A RID: 1402
		Unknown,
		// Token: 0x0400057B RID: 1403
		None,
		// Token: 0x0400057C RID: 1404
		HorizontalRgb,
		// Token: 0x0400057D RID: 1405
		HorizontalBgr,
		// Token: 0x0400057E RID: 1406
		VerticalRgb,
		// Token: 0x0400057F RID: 1407
		VerticalBgr
	}
}
