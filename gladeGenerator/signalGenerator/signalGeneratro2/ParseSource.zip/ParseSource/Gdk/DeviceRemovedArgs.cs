﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000060 RID: 96
	public class DeviceRemovedArgs : SignalArgs
	{
		// Token: 0x1700011B RID: 283
		// (get) Token: 0x06000435 RID: 1077 RVA: 0x0000D0A9 File Offset: 0x0000B2A9
		public Device Device
		{
			get
			{
				return (Device)base.Args[0];
			}
		}
	}
}
