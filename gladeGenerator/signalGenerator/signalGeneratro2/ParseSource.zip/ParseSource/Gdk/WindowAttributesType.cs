﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000117 RID: 279
	[Flags]
	[GType(typeof(WindowAttributesTypeGType))]
	public enum WindowAttributesType
	{
		// Token: 0x0400066D RID: 1645
		Title = 2,
		// Token: 0x0400066E RID: 1646
		X = 4,
		// Token: 0x0400066F RID: 1647
		Y = 8,
		// Token: 0x04000670 RID: 1648
		Cursor = 16,
		// Token: 0x04000671 RID: 1649
		Visual = 32,
		// Token: 0x04000672 RID: 1650
		Wmclass = 64,
		// Token: 0x04000673 RID: 1651
		Noredir = 128,
		// Token: 0x04000674 RID: 1652
		TypeHint = 256
	}
}
