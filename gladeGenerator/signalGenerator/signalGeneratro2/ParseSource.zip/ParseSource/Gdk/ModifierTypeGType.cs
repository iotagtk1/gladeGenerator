﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000B1 RID: 177
	internal class ModifierTypeGType
	{
		// Token: 0x170001CE RID: 462
		// (get) Token: 0x06000713 RID: 1811 RVA: 0x00014AF0 File Offset: 0x00012CF0
		public static GType GType
		{
			get
			{
				return new GType(ModifierTypeGType.gdk_modifier_type_get_type());
			}
		}

		// Token: 0x040003F1 RID: 1009
		private static ModifierTypeGType.d_gdk_modifier_type_get_type gdk_modifier_type_get_type = FuncLoader.LoadFunction<ModifierTypeGType.d_gdk_modifier_type_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_modifier_type_get_type"));

		// Token: 0x02000309 RID: 777
		// (Invoke) Token: 0x060012A9 RID: 4777
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_modifier_type_get_type();
	}
}
