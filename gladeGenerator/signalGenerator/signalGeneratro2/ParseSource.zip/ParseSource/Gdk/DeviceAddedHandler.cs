﻿using System;

namespace Gdk
{
	// Token: 0x02000057 RID: 87
	// (Invoke) Token: 0x060003E2 RID: 994
	public delegate void DeviceAddedHandler(object o, DeviceAddedArgs args);
}
