﻿using System;
using System.Runtime.InteropServices;

namespace Gdk
{
	// Token: 0x02000071 RID: 113
	public class Drop
	{
		// Token: 0x060004FE RID: 1278 RVA: 0x0000F30F File Offset: 0x0000D50F
		public static void Finish(DragContext context, bool success, uint time_)
		{
			Drop.gdk_drop_finish((context == null) ? IntPtr.Zero : context.Handle, success, time_);
		}

		// Token: 0x060004FF RID: 1279 RVA: 0x0000F32D File Offset: 0x0000D52D
		public static void Reply(DragContext context, bool accepted, uint time_)
		{
			Drop.gdk_drop_reply((context == null) ? IntPtr.Zero : context.Handle, accepted, time_);
		}

		// Token: 0x04000229 RID: 553
		private static Drop.d_gdk_drop_finish gdk_drop_finish = FuncLoader.LoadFunction<Drop.d_gdk_drop_finish>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drop_finish"));

		// Token: 0x0400022A RID: 554
		private static Drop.d_gdk_drop_reply gdk_drop_reply = FuncLoader.LoadFunction<Drop.d_gdk_drop_reply>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drop_reply"));

		// Token: 0x0200025D RID: 605
		// (Invoke) Token: 0x06000FFB RID: 4091
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_drop_finish(IntPtr context, bool success, uint time_);

		// Token: 0x0200025E RID: 606
		// (Invoke) Token: 0x06000FFF RID: 4095
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_drop_reply(IntPtr context, bool accepted, uint time_);
	}
}
