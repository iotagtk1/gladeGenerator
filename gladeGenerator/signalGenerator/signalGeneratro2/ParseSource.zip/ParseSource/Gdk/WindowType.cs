﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000123 RID: 291
	[GType(typeof(WindowTypeGType))]
	public enum WindowType
	{
		// Token: 0x04000699 RID: 1689
		Root,
		// Token: 0x0400069A RID: 1690
		Toplevel,
		// Token: 0x0400069B RID: 1691
		Child,
		// Token: 0x0400069C RID: 1692
		Temp,
		// Token: 0x0400069D RID: 1693
		Foreign,
		// Token: 0x0400069E RID: 1694
		Offscreen,
		// Token: 0x0400069F RID: 1695
		Subsurface
	}
}
