﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000079 RID: 121
	internal class EventMaskGType
	{
		// Token: 0x17000152 RID: 338
		// (get) Token: 0x06000537 RID: 1335 RVA: 0x0000FC57 File Offset: 0x0000DE57
		public static GType GType
		{
			get
			{
				return new GType(EventMaskGType.gdk_event_mask_get_type());
			}
		}

		// Token: 0x0400026C RID: 620
		private static EventMaskGType.d_gdk_event_mask_get_type gdk_event_mask_get_type = FuncLoader.LoadFunction<EventMaskGType.d_gdk_event_mask_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_mask_get_type"));

		// Token: 0x02000284 RID: 644
		// (Invoke) Token: 0x06001097 RID: 4247
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_event_mask_get_type();
	}
}
