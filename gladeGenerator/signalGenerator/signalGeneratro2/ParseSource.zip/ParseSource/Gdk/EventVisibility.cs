﻿using System;
using System.Runtime.InteropServices;

namespace Gdk
{
	// Token: 0x02000035 RID: 53
	public class EventVisibility : Event
	{
		// Token: 0x06000369 RID: 873 RVA: 0x0000B459 File Offset: 0x00009659
		public EventVisibility(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x0600036A RID: 874 RVA: 0x0000B462 File Offset: 0x00009662
		private EventVisibility.NativeStruct Native
		{
			get
			{
				return (EventVisibility.NativeStruct)Marshal.PtrToStructure(base.Handle, typeof(EventVisibility.NativeStruct));
			}
		}

		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x0600036B RID: 875 RVA: 0x0000B47E File Offset: 0x0000967E
		// (set) Token: 0x0600036C RID: 876 RVA: 0x0000B48C File Offset: 0x0000968C
		public VisibilityState State
		{
			get
			{
				return this.Native.state;
			}
			set
			{
				EventVisibility.NativeStruct native = this.Native;
				native.state = value;
				Marshal.StructureToPtr<EventVisibility.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x020001E8 RID: 488
		private struct NativeStruct
		{
			// Token: 0x04000C89 RID: 3209
			private EventType type;

			// Token: 0x04000C8A RID: 3210
			private IntPtr window;

			// Token: 0x04000C8B RID: 3211
			private sbyte send_event;

			// Token: 0x04000C8C RID: 3212
			public VisibilityState state;
		}
	}
}
