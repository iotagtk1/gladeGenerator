﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000C5 RID: 197
	public class PixbufAniAnim : PixbufAnimation
	{
		// Token: 0x060007C0 RID: 1984 RVA: 0x000172A6 File Offset: 0x000154A6
		public PixbufAniAnim(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x060007C1 RID: 1985 RVA: 0x000172AF File Offset: 0x000154AF
		protected PixbufAniAnim() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x170001FB RID: 507
		// (get) Token: 0x060007C2 RID: 1986 RVA: 0x000172D0 File Offset: 0x000154D0
		public new static GType GType
		{
			get
			{
				IntPtr val = PixbufAniAnim.gdk_pixbuf_ani_anim_get_type();
				return new GType(val);
			}
		}

		// Token: 0x04000460 RID: 1120
		private static PixbufAniAnim.d_gdk_pixbuf_ani_anim_get_type gdk_pixbuf_ani_anim_get_type = FuncLoader.LoadFunction<PixbufAniAnim.d_gdk_pixbuf_ani_anim_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_ani_anim_get_type"));

		// Token: 0x02000365 RID: 869
		// (Invoke) Token: 0x06001418 RID: 5144
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_ani_anim_get_type();
	}
}
