﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x02000104 RID: 260
	public class TGAFooter : Opaque
	{
		// Token: 0x06000A1A RID: 2586 RVA: 0x0001DBD3 File Offset: 0x0001BDD3
		public TGAFooter(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700028D RID: 653
		// (get) Token: 0x06000A1B RID: 2587 RVA: 0x0001DBDC File Offset: 0x0001BDDC
		public static AbiStruct abi_info
		{
			get
			{
				if (TGAFooter._abi_info == null)
				{
					TGAFooter._abi_info = new AbiStruct(new List<AbiField>());
				}
				return TGAFooter._abi_info;
			}
		}

		// Token: 0x04000584 RID: 1412
		private static AbiStruct _abi_info;
	}
}
