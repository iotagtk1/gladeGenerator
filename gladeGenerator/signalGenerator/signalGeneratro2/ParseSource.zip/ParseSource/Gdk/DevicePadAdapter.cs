﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200005C RID: 92
	public class DevicePadAdapter : GInterfaceAdapter, IDevicePad, IWrapper
	{
		// Token: 0x0600041A RID: 1050 RVA: 0x0000CCA0 File Offset: 0x0000AEA0
		static DevicePadAdapter()
		{
			GType.Register(DevicePadAdapter._gtype, typeof(DevicePadAdapter));
			DevicePadAdapter.iface.GetNGroups = new DevicePadAdapter.GetNGroupsNativeDelegate(DevicePadAdapter.GetNGroups_cb);
			DevicePadAdapter.iface.GetGroupNModes = new DevicePadAdapter.GetGroupNModesNativeDelegate(DevicePadAdapter.GetGroupNModes_cb);
			DevicePadAdapter.iface.GetNFeatures = new DevicePadAdapter.GetNFeaturesNativeDelegate(DevicePadAdapter.GetNFeatures_cb);
			DevicePadAdapter.iface.GetFeatureGroup = new DevicePadAdapter.GetFeatureGroupNativeDelegate(DevicePadAdapter.GetFeatureGroup_cb);
		}

		// Token: 0x0600041B RID: 1051 RVA: 0x0000CDBC File Offset: 0x0000AFBC
		private static int GetNGroups_cb(IntPtr inst)
		{
			int ngroups;
			try
			{
				ngroups = (Object.GetObject(inst, false) as IDevicePadImplementor).NGroups;
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return ngroups;
		}

		// Token: 0x0600041C RID: 1052 RVA: 0x0000CDF8 File Offset: 0x0000AFF8
		private static int GetGroupNModes_cb(IntPtr inst, int group)
		{
			int groupNModes;
			try
			{
				groupNModes = (Object.GetObject(inst, false) as IDevicePadImplementor).GetGroupNModes(group);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return groupNModes;
		}

		// Token: 0x0600041D RID: 1053 RVA: 0x0000CE34 File Offset: 0x0000B034
		private static int GetNFeatures_cb(IntPtr inst, int feature)
		{
			int nfeatures;
			try
			{
				nfeatures = (Object.GetObject(inst, false) as IDevicePadImplementor).GetNFeatures((DevicePadFeature)feature);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return nfeatures;
		}

		// Token: 0x0600041E RID: 1054 RVA: 0x0000CE70 File Offset: 0x0000B070
		private static int GetFeatureGroup_cb(IntPtr inst, int feature, int idx)
		{
			int featureGroup;
			try
			{
				featureGroup = (Object.GetObject(inst, false) as IDevicePadImplementor).GetFeatureGroup((DevicePadFeature)feature, idx);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return featureGroup;
		}

		// Token: 0x0600041F RID: 1055 RVA: 0x0000CEAC File Offset: 0x0000B0AC
		private static void Initialize(IntPtr ptr, IntPtr data)
		{
			IntPtr ptr2 = new IntPtr(ptr.ToInt64() + (long)DevicePadAdapter.class_offset);
			DevicePadAdapter.GdkDevicePadInterface structure = (DevicePadAdapter.GdkDevicePadInterface)Marshal.PtrToStructure(ptr2, typeof(DevicePadAdapter.GdkDevicePadInterface));
			structure.GetNGroups = DevicePadAdapter.iface.GetNGroups;
			structure.GetGroupNModes = DevicePadAdapter.iface.GetGroupNModes;
			structure.GetNFeatures = DevicePadAdapter.iface.GetNFeatures;
			structure.GetFeatureGroup = DevicePadAdapter.iface.GetFeatureGroup;
			Marshal.StructureToPtr<DevicePadAdapter.GdkDevicePadInterface>(structure, ptr2, false);
		}

		// Token: 0x06000420 RID: 1056 RVA: 0x0000CF30 File Offset: 0x0000B130
		public DevicePadAdapter()
		{
			base.InitHandler = new GInterfaceInitHandler(DevicePadAdapter.Initialize);
		}

		// Token: 0x06000421 RID: 1057 RVA: 0x0000CF4A File Offset: 0x0000B14A
		public DevicePadAdapter(IDevicePadImplementor implementor)
		{
			if (implementor == null)
			{
				throw new ArgumentNullException("implementor");
			}
			if (!(implementor is Object))
			{
				throw new ArgumentException("implementor must be a subclass of GLib.Object");
			}
			this.implementor = (implementor as Object);
		}

		// Token: 0x06000422 RID: 1058 RVA: 0x0000CF7F File Offset: 0x0000B17F
		public DevicePadAdapter(IntPtr handle)
		{
			if (!DevicePadAdapter._gtype.IsInstance(handle))
			{
				throw new ArgumentException("The gobject doesn't implement the GInterface of this adapter", "handle");
			}
			this.implementor = Object.GetObject(handle);
		}

		// Token: 0x17000114 RID: 276
		// (get) Token: 0x06000423 RID: 1059 RVA: 0x0000CFB0 File Offset: 0x0000B1B0
		public static GType GType
		{
			get
			{
				return DevicePadAdapter._gtype;
			}
		}

		// Token: 0x17000115 RID: 277
		// (get) Token: 0x06000424 RID: 1060 RVA: 0x0000CFB7 File Offset: 0x0000B1B7
		public override GType GInterfaceGType
		{
			get
			{
				return DevicePadAdapter._gtype;
			}
		}

		// Token: 0x17000116 RID: 278
		// (get) Token: 0x06000425 RID: 1061 RVA: 0x0000CFBE File Offset: 0x0000B1BE
		public override IntPtr Handle
		{
			get
			{
				return this.implementor.Handle;
			}
		}

		// Token: 0x17000117 RID: 279
		// (get) Token: 0x06000426 RID: 1062 RVA: 0x0000CFCB File Offset: 0x0000B1CB
		public IntPtr OwnedHandle
		{
			get
			{
				return this.implementor.OwnedHandle;
			}
		}

		// Token: 0x06000427 RID: 1063 RVA: 0x0000CFD8 File Offset: 0x0000B1D8
		public static IDevicePad GetObject(IntPtr handle, bool owned)
		{
			return DevicePadAdapter.GetObject(Object.GetObject(handle, owned));
		}

		// Token: 0x06000428 RID: 1064 RVA: 0x0000CFE6 File Offset: 0x0000B1E6
		public static IDevicePad GetObject(Object obj)
		{
			if (obj == null)
			{
				return null;
			}
			if (obj is IDevicePadImplementor)
			{
				return new DevicePadAdapter(obj as IDevicePadImplementor);
			}
			if (!(obj is IDevicePad))
			{
				return new DevicePadAdapter(obj.Handle);
			}
			return obj as IDevicePad;
		}

		// Token: 0x17000118 RID: 280
		// (get) Token: 0x06000429 RID: 1065 RVA: 0x0000D01B File Offset: 0x0000B21B
		public IDevicePadImplementor Implementor
		{
			get
			{
				return this.implementor as IDevicePadImplementor;
			}
		}

		// Token: 0x0600042A RID: 1066 RVA: 0x0000D028 File Offset: 0x0000B228
		public int GetFeatureGroup(DevicePadFeature feature, int feature_idx)
		{
			return DevicePadAdapter.gdk_device_pad_get_feature_group(this.Handle, (int)feature, feature_idx);
		}

		// Token: 0x0600042B RID: 1067 RVA: 0x0000D03C File Offset: 0x0000B23C
		public int GetGroupNModes(int group_idx)
		{
			return DevicePadAdapter.gdk_device_pad_get_group_n_modes(this.Handle, group_idx);
		}

		// Token: 0x0600042C RID: 1068 RVA: 0x0000D04F File Offset: 0x0000B24F
		public int GetNFeatures(DevicePadFeature feature)
		{
			return DevicePadAdapter.gdk_device_pad_get_n_features(this.Handle, (int)feature);
		}

		// Token: 0x17000119 RID: 281
		// (get) Token: 0x0600042D RID: 1069 RVA: 0x0000D062 File Offset: 0x0000B262
		public int NGroups
		{
			get
			{
				return DevicePadAdapter.gdk_device_pad_get_n_groups(this.Handle);
			}
		}

		// Token: 0x040001BB RID: 443
		private static DevicePadAdapter.GdkDevicePadInterface iface;

		// Token: 0x040001BC RID: 444
		private static int class_offset = 2 * IntPtr.Size;

		// Token: 0x040001BD RID: 445
		private Object implementor;

		// Token: 0x040001BE RID: 446
		private static DevicePadAdapter.d_gdk_device_pad_get_type gdk_device_pad_get_type = FuncLoader.LoadFunction<DevicePadAdapter.d_gdk_device_pad_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_pad_get_type"));

		// Token: 0x040001BF RID: 447
		private static GType _gtype = new GType(DevicePadAdapter.gdk_device_pad_get_type());

		// Token: 0x040001C0 RID: 448
		private static DevicePadAdapter.d_gdk_device_pad_get_feature_group gdk_device_pad_get_feature_group = FuncLoader.LoadFunction<DevicePadAdapter.d_gdk_device_pad_get_feature_group>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_pad_get_feature_group"));

		// Token: 0x040001C1 RID: 449
		private static DevicePadAdapter.d_gdk_device_pad_get_group_n_modes gdk_device_pad_get_group_n_modes = FuncLoader.LoadFunction<DevicePadAdapter.d_gdk_device_pad_get_group_n_modes>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_pad_get_group_n_modes"));

		// Token: 0x040001C2 RID: 450
		private static DevicePadAdapter.d_gdk_device_pad_get_n_features gdk_device_pad_get_n_features = FuncLoader.LoadFunction<DevicePadAdapter.d_gdk_device_pad_get_n_features>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_pad_get_n_features"));

		// Token: 0x040001C3 RID: 451
		private static DevicePadAdapter.d_gdk_device_pad_get_n_groups gdk_device_pad_get_n_groups = FuncLoader.LoadFunction<DevicePadAdapter.d_gdk_device_pad_get_n_groups>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_pad_get_n_groups"));

		// Token: 0x02000219 RID: 537
		private struct GdkDevicePadInterface
		{
			// Token: 0x04000C92 RID: 3218
			public DevicePadAdapter.GetNGroupsNativeDelegate GetNGroups;

			// Token: 0x04000C93 RID: 3219
			public DevicePadAdapter.GetGroupNModesNativeDelegate GetGroupNModes;

			// Token: 0x04000C94 RID: 3220
			public DevicePadAdapter.GetNFeaturesNativeDelegate GetNFeatures;

			// Token: 0x04000C95 RID: 3221
			public DevicePadAdapter.GetFeatureGroupNativeDelegate GetFeatureGroup;
		}

		// Token: 0x0200021A RID: 538
		// (Invoke) Token: 0x06000EEF RID: 3823
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetNGroupsNativeDelegate(IntPtr inst);

		// Token: 0x0200021B RID: 539
		// (Invoke) Token: 0x06000EF3 RID: 3827
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetGroupNModesNativeDelegate(IntPtr inst, int group);

		// Token: 0x0200021C RID: 540
		// (Invoke) Token: 0x06000EF7 RID: 3831
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetNFeaturesNativeDelegate(IntPtr inst, int feature);

		// Token: 0x0200021D RID: 541
		// (Invoke) Token: 0x06000EFB RID: 3835
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetFeatureGroupNativeDelegate(IntPtr inst, int feature, int idx);

		// Token: 0x0200021E RID: 542
		// (Invoke) Token: 0x06000EFF RID: 3839
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_pad_get_type();

		// Token: 0x0200021F RID: 543
		// (Invoke) Token: 0x06000F03 RID: 3843
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_device_pad_get_feature_group(IntPtr raw, int feature, int feature_idx);

		// Token: 0x02000220 RID: 544
		// (Invoke) Token: 0x06000F07 RID: 3847
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_device_pad_get_group_n_modes(IntPtr raw, int group_idx);

		// Token: 0x02000221 RID: 545
		// (Invoke) Token: 0x06000F0B RID: 3851
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_device_pad_get_n_features(IntPtr raw, int feature);

		// Token: 0x02000222 RID: 546
		// (Invoke) Token: 0x06000F0F RID: 3855
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_device_pad_get_n_groups(IntPtr raw);
	}
}
