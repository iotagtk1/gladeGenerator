﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Cairo;
using GdkSharp;
using GLib;

namespace Gdk
{
	// Token: 0x02000115 RID: 277
	public class Window : Object
	{
		// Token: 0x06000A5E RID: 2654 RVA: 0x0001E35C File Offset: 0x0001C55C
		public Window(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000A5F RID: 2655 RVA: 0x0001E368 File Offset: 0x0001C568
		public Window(Window parent, WindowAttr attributes, int attributes_mask) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Window))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(attributes);
			this.Raw = Window.gdk_window_new((parent == null) ? IntPtr.Zero : parent.Handle, intPtr, attributes_mask);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x170002A7 RID: 679
		// (get) Token: 0x06000A60 RID: 2656 RVA: 0x0001E3EA File Offset: 0x0001C5EA
		// (set) Token: 0x06000A61 RID: 2657 RVA: 0x0001E406 File Offset: 0x0001C606
		[Property("cursor")]
		public Cursor Cursor
		{
			get
			{
				return Object.GetObject(Window.gdk_window_get_cursor(base.Handle)) as Cursor;
			}
			set
			{
				Window.gdk_window_set_cursor(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x06000A62 RID: 2658 RVA: 0x0001E428 File Offset: 0x0001C628
		private static void ToEmbedderSignalCallback(IntPtr inst, double arg0, double arg1, out double arg2, out double arg3, IntPtr gch)
		{
			ToEmbedderArgs toEmbedderArgs = new ToEmbedderArgs();
			try
			{
				Signal signal = ((GCHandle)gch).Target as Signal;
				if (signal == null)
				{
					throw new Exception("Unknown signal GC handle received " + gch.ToString());
				}
				toEmbedderArgs.Args = new object[4];
				toEmbedderArgs.Args[0] = arg0;
				toEmbedderArgs.Args[1] = arg1;
				((ToEmbedderHandler)signal.Handler)(Object.GetObject(inst), toEmbedderArgs);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
			try
			{
				arg2 = (double)toEmbedderArgs.Args[2];
				arg3 = (double)toEmbedderArgs.Args[3];
			}
			catch (Exception)
			{
				Exception ex = new Exception("args.RetVal or 'out' property unset or set to incorrect type in Gdk.ToEmbedderHandler callback");
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
		}

		// Token: 0x14000023 RID: 35
		// (add) Token: 0x06000A63 RID: 2659 RVA: 0x0001E504 File Offset: 0x0001C704
		// (remove) Token: 0x06000A64 RID: 2660 RVA: 0x0001E51E File Offset: 0x0001C71E
		[Signal("to-embedder")]
		public event ToEmbedderHandler ToEmbedder
		{
			add
			{
				base.AddSignalHandler("to-embedder", value, new Window.ToEmbedderSignalDelegate(Window.ToEmbedderSignalCallback));
			}
			remove
			{
				base.RemoveSignalHandler("to-embedder", value);
			}
		}

		// Token: 0x06000A65 RID: 2661 RVA: 0x0001E52C File Offset: 0x0001C72C
		private static void FromEmbedderSignalCallback(IntPtr inst, double arg0, double arg1, out double arg2, out double arg3, IntPtr gch)
		{
			FromEmbedderArgs fromEmbedderArgs = new FromEmbedderArgs();
			try
			{
				Signal signal = ((GCHandle)gch).Target as Signal;
				if (signal == null)
				{
					throw new Exception("Unknown signal GC handle received " + gch.ToString());
				}
				fromEmbedderArgs.Args = new object[4];
				fromEmbedderArgs.Args[0] = arg0;
				fromEmbedderArgs.Args[1] = arg1;
				((FromEmbedderHandler)signal.Handler)(Object.GetObject(inst), fromEmbedderArgs);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
			try
			{
				arg2 = (double)fromEmbedderArgs.Args[2];
				arg3 = (double)fromEmbedderArgs.Args[3];
			}
			catch (Exception)
			{
				Exception ex = new Exception("args.RetVal or 'out' property unset or set to incorrect type in Gdk.FromEmbedderHandler callback");
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
		}

		// Token: 0x14000024 RID: 36
		// (add) Token: 0x06000A66 RID: 2662 RVA: 0x0001E608 File Offset: 0x0001C808
		// (remove) Token: 0x06000A67 RID: 2663 RVA: 0x0001E622 File Offset: 0x0001C822
		[Signal("from-embedder")]
		public event FromEmbedderHandler FromEmbedder
		{
			add
			{
				base.AddSignalHandler("from-embedder", value, new Window.FromEmbedderSignalDelegate(Window.FromEmbedderSignalCallback));
			}
			remove
			{
				base.RemoveSignalHandler("from-embedder", value);
			}
		}

		// Token: 0x06000A68 RID: 2664 RVA: 0x0001E630 File Offset: 0x0001C830
		private static void MovedToRectSignalCallback(IntPtr inst, IntPtr arg0, IntPtr arg1, bool arg2, bool arg3, IntPtr gch)
		{
			MovedToRectArgs movedToRectArgs = new MovedToRectArgs();
			try
			{
				Signal signal = ((GCHandle)gch).Target as Signal;
				if (signal == null)
				{
					throw new Exception("Unknown signal GC handle received " + gch.ToString());
				}
				movedToRectArgs.Args = new object[4];
				movedToRectArgs.Args[0] = arg0;
				movedToRectArgs.Args[1] = arg1;
				movedToRectArgs.Args[2] = arg2;
				movedToRectArgs.Args[3] = arg3;
				((MovedToRectHandler)signal.Handler)(Object.GetObject(inst), movedToRectArgs);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x14000025 RID: 37
		// (add) Token: 0x06000A69 RID: 2665 RVA: 0x0001E6E8 File Offset: 0x0001C8E8
		// (remove) Token: 0x06000A6A RID: 2666 RVA: 0x0001E702 File Offset: 0x0001C902
		[Signal("moved-to-rect")]
		public event MovedToRectHandler MovedToRect
		{
			add
			{
				base.AddSignalHandler("moved-to-rect", value, new Window.MovedToRectSignalDelegate(Window.MovedToRectSignalCallback));
			}
			remove
			{
				base.RemoveSignalHandler("moved-to-rect", value);
			}
		}

		// Token: 0x14000026 RID: 38
		// (add) Token: 0x06000A6B RID: 2667 RVA: 0x0001E710 File Offset: 0x0001C910
		// (remove) Token: 0x06000A6C RID: 2668 RVA: 0x0001E728 File Offset: 0x0001C928
		[Signal("create-surface")]
		public event CreateSurfaceHandler CreateSurface
		{
			add
			{
				base.AddSignalHandler("create-surface", value, typeof(CreateSurfaceArgs));
			}
			remove
			{
				base.RemoveSignalHandler("create-surface", value);
			}
		}

		// Token: 0x14000027 RID: 39
		// (add) Token: 0x06000A6D RID: 2669 RVA: 0x0001E736 File Offset: 0x0001C936
		// (remove) Token: 0x06000A6E RID: 2670 RVA: 0x0001E74E File Offset: 0x0001C94E
		[Signal("pick-embedded-child")]
		public event PickEmbeddedChildHandler PickEmbeddedChild
		{
			add
			{
				base.AddSignalHandler("pick-embedded-child", value, typeof(PickEmbeddedChildArgs));
			}
			remove
			{
				base.RemoveSignalHandler("pick-embedded-child", value);
			}
		}

		// Token: 0x170002A8 RID: 680
		// (get) Token: 0x06000A6F RID: 2671 RVA: 0x0001E75C File Offset: 0x0001C95C
		private static Window.MovedToRectNativeDelegate MovedToRectVMCallback
		{
			get
			{
				if (Window.MovedToRect_cb_delegate == null)
				{
					Window.MovedToRect_cb_delegate = new Window.MovedToRectNativeDelegate(Window.MovedToRect_cb);
				}
				return Window.MovedToRect_cb_delegate;
			}
		}

		// Token: 0x06000A70 RID: 2672 RVA: 0x0001E77B File Offset: 0x0001C97B
		private static void OverrideMovedToRect(GType gtype)
		{
			Window.OverrideMovedToRect(gtype, Window.MovedToRectVMCallback);
		}

		// Token: 0x06000A71 RID: 2673 RVA: 0x0001E788 File Offset: 0x0001C988
		private static void OverrideMovedToRect(GType gtype, Window.MovedToRectNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "moved-to-rect", callback);
		}

		// Token: 0x06000A72 RID: 2674 RVA: 0x0001E798 File Offset: 0x0001C998
		private static void MovedToRect_cb(IntPtr inst, IntPtr p0, IntPtr p1, bool p2, bool p3)
		{
			try
			{
				(Object.GetObject(inst, false) as Window).OnMovedToRect(p0, p1, p2, p3);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000A73 RID: 2675 RVA: 0x0001E7D8 File Offset: 0x0001C9D8
		[DefaultSignalHandler(Type = typeof(Window), ConnectionMethod = "OverrideMovedToRect")]
		protected virtual void OnMovedToRect(IntPtr p0, IntPtr p1, bool p2, bool p3)
		{
			this.InternalMovedToRect(p0, p1, p2, p3);
		}

		// Token: 0x06000A74 RID: 2676 RVA: 0x0001E7E8 File Offset: 0x0001C9E8
		private void InternalMovedToRect(IntPtr p0, IntPtr p1, bool p2, bool p3)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(5U);
			Value[] array = new Value[5];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(p0);
			valueArray.Append(array[1]);
			array[2] = new Value(p1);
			valueArray.Append(array[2]);
			array[3] = new Value(p2);
			valueArray.Append(array[3]);
			array[4] = new Value(p3);
			valueArray.Append(array[4]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x170002A9 RID: 681
		// (get) Token: 0x06000A75 RID: 2677 RVA: 0x0001E8C3 File Offset: 0x0001CAC3
		private static Window.PickEmbeddedChildNativeDelegate PickEmbeddedChildVMCallback
		{
			get
			{
				if (Window.PickEmbeddedChild_cb_delegate == null)
				{
					Window.PickEmbeddedChild_cb_delegate = new Window.PickEmbeddedChildNativeDelegate(Window.PickEmbeddedChild_cb);
				}
				return Window.PickEmbeddedChild_cb_delegate;
			}
		}

		// Token: 0x06000A76 RID: 2678 RVA: 0x0001E8E2 File Offset: 0x0001CAE2
		private static void OverridePickEmbeddedChild(GType gtype)
		{
			Window.OverridePickEmbeddedChild(gtype, Window.PickEmbeddedChildVMCallback);
		}

		// Token: 0x06000A77 RID: 2679 RVA: 0x0001E8F0 File Offset: 0x0001CAF0
		private unsafe static void OverridePickEmbeddedChild(GType gtype, Window.PickEmbeddedChildNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Window.class_abi.GetFieldOffset("pick_embedded_child");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000A78 RID: 2680 RVA: 0x0001E924 File Offset: 0x0001CB24
		private static IntPtr PickEmbeddedChild_cb(IntPtr inst, double x, double y)
		{
			IntPtr result;
			try
			{
				Window window = (Object.GetObject(inst, false) as Window).OnPickEmbeddedChild(x, y);
				result = ((window == null) ? IntPtr.Zero : window.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000A79 RID: 2681 RVA: 0x0001E974 File Offset: 0x0001CB74
		[DefaultSignalHandler(Type = typeof(Window), ConnectionMethod = "OverridePickEmbeddedChild")]
		protected virtual Window OnPickEmbeddedChild(double x, double y)
		{
			return this.InternalPickEmbeddedChild(x, y);
		}

		// Token: 0x06000A7A RID: 2682 RVA: 0x0001E980 File Offset: 0x0001CB80
		private Window InternalPickEmbeddedChild(double x, double y)
		{
			Window.PickEmbeddedChildNativeDelegate pickEmbeddedChildNativeDelegate = Window.class_abi.BaseOverride(base.LookupGType(), "pick_embedded_child");
			if (pickEmbeddedChildNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(pickEmbeddedChildNativeDelegate(base.Handle, x, y)) as Window;
		}

		// Token: 0x170002AA RID: 682
		// (get) Token: 0x06000A7B RID: 2683 RVA: 0x0001E9C0 File Offset: 0x0001CBC0
		private static Window.ToEmbedderNativeDelegate ToEmbedderVMCallback
		{
			get
			{
				if (Window.ToEmbedder_cb_delegate == null)
				{
					Window.ToEmbedder_cb_delegate = new Window.ToEmbedderNativeDelegate(Window.ToEmbedder_cb);
				}
				return Window.ToEmbedder_cb_delegate;
			}
		}

		// Token: 0x06000A7C RID: 2684 RVA: 0x0001E9DF File Offset: 0x0001CBDF
		private static void OverrideToEmbedder(GType gtype)
		{
			Window.OverrideToEmbedder(gtype, Window.ToEmbedderVMCallback);
		}

		// Token: 0x06000A7D RID: 2685 RVA: 0x0001E9EC File Offset: 0x0001CBEC
		private unsafe static void OverrideToEmbedder(GType gtype, Window.ToEmbedderNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Window.class_abi.GetFieldOffset("to_embedder");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000A7E RID: 2686 RVA: 0x0001EA20 File Offset: 0x0001CC20
		private static void ToEmbedder_cb(IntPtr inst, double offscreen_x, double offscreen_y, out double embedder_x, out double embedder_y)
		{
			try
			{
				(Object.GetObject(inst, false) as Window).OnToEmbedder(offscreen_x, offscreen_y, out embedder_x, out embedder_y);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
		}

		// Token: 0x06000A7F RID: 2687 RVA: 0x0001EA60 File Offset: 0x0001CC60
		[DefaultSignalHandler(Type = typeof(Window), ConnectionMethod = "OverrideToEmbedder")]
		protected virtual void OnToEmbedder(double offscreen_x, double offscreen_y, out double embedder_x, out double embedder_y)
		{
			this.InternalToEmbedder(offscreen_x, offscreen_y, out embedder_x, out embedder_y);
		}

		// Token: 0x06000A80 RID: 2688 RVA: 0x0001EA6D File Offset: 0x0001CC6D
		private void InternalToEmbedder(double offscreen_x, double offscreen_y, out double embedder_x, out double embedder_y)
		{
			Window.ToEmbedderNativeDelegate toEmbedderNativeDelegate = Window.class_abi.BaseOverride(base.LookupGType(), "to_embedder");
			if (toEmbedderNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			toEmbedderNativeDelegate(base.Handle, offscreen_x, offscreen_y, out embedder_x, out embedder_y);
		}

		// Token: 0x170002AB RID: 683
		// (get) Token: 0x06000A81 RID: 2689 RVA: 0x0001EAA2 File Offset: 0x0001CCA2
		private static Window.FromEmbedderNativeDelegate FromEmbedderVMCallback
		{
			get
			{
				if (Window.FromEmbedder_cb_delegate == null)
				{
					Window.FromEmbedder_cb_delegate = new Window.FromEmbedderNativeDelegate(Window.FromEmbedder_cb);
				}
				return Window.FromEmbedder_cb_delegate;
			}
		}

		// Token: 0x06000A82 RID: 2690 RVA: 0x0001EAC1 File Offset: 0x0001CCC1
		private static void OverrideFromEmbedder(GType gtype)
		{
			Window.OverrideFromEmbedder(gtype, Window.FromEmbedderVMCallback);
		}

		// Token: 0x06000A83 RID: 2691 RVA: 0x0001EAD0 File Offset: 0x0001CCD0
		private unsafe static void OverrideFromEmbedder(GType gtype, Window.FromEmbedderNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Window.class_abi.GetFieldOffset("from_embedder");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000A84 RID: 2692 RVA: 0x0001EB04 File Offset: 0x0001CD04
		private static void FromEmbedder_cb(IntPtr inst, double embedder_x, double embedder_y, out double offscreen_x, out double offscreen_y)
		{
			try
			{
				(Object.GetObject(inst, false) as Window).OnFromEmbedder(embedder_x, embedder_y, out offscreen_x, out offscreen_y);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
		}

		// Token: 0x06000A85 RID: 2693 RVA: 0x0001EB44 File Offset: 0x0001CD44
		[DefaultSignalHandler(Type = typeof(Window), ConnectionMethod = "OverrideFromEmbedder")]
		protected virtual void OnFromEmbedder(double embedder_x, double embedder_y, out double offscreen_x, out double offscreen_y)
		{
			this.InternalFromEmbedder(embedder_x, embedder_y, out offscreen_x, out offscreen_y);
		}

		// Token: 0x06000A86 RID: 2694 RVA: 0x0001EB51 File Offset: 0x0001CD51
		private void InternalFromEmbedder(double embedder_x, double embedder_y, out double offscreen_x, out double offscreen_y)
		{
			Window.FromEmbedderNativeDelegate fromEmbedderNativeDelegate = Window.class_abi.BaseOverride(base.LookupGType(), "from_embedder");
			if (fromEmbedderNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			fromEmbedderNativeDelegate(base.Handle, embedder_x, embedder_y, out offscreen_x, out offscreen_y);
		}

		// Token: 0x170002AC RID: 684
		// (get) Token: 0x06000A87 RID: 2695 RVA: 0x0001EB86 File Offset: 0x0001CD86
		private static Window.CreateSurfaceNativeDelegate CreateSurfaceVMCallback
		{
			get
			{
				if (Window.CreateSurface_cb_delegate == null)
				{
					Window.CreateSurface_cb_delegate = new Window.CreateSurfaceNativeDelegate(Window.CreateSurface_cb);
				}
				return Window.CreateSurface_cb_delegate;
			}
		}

		// Token: 0x06000A88 RID: 2696 RVA: 0x0001EBA5 File Offset: 0x0001CDA5
		private static void OverrideCreateSurface(GType gtype)
		{
			Window.OverrideCreateSurface(gtype, Window.CreateSurfaceVMCallback);
		}

		// Token: 0x06000A89 RID: 2697 RVA: 0x0001EBB4 File Offset: 0x0001CDB4
		private unsafe static void OverrideCreateSurface(GType gtype, Window.CreateSurfaceNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Window.class_abi.GetFieldOffset("create_surface");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000A8A RID: 2698 RVA: 0x0001EBE8 File Offset: 0x0001CDE8
		private static IntPtr CreateSurface_cb(IntPtr inst, int width, int height)
		{
			IntPtr handle;
			try
			{
				handle = (Object.GetObject(inst, false) as Window).OnCreateSurface(width, height).Handle;
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return handle;
		}

		// Token: 0x06000A8B RID: 2699 RVA: 0x0001EC2C File Offset: 0x0001CE2C
		[DefaultSignalHandler(Type = typeof(Window), ConnectionMethod = "OverrideCreateSurface")]
		protected virtual Surface OnCreateSurface(int width, int height)
		{
			return this.InternalCreateSurface(width, height);
		}

		// Token: 0x06000A8C RID: 2700 RVA: 0x0001EC38 File Offset: 0x0001CE38
		private Surface InternalCreateSurface(int width, int height)
		{
			Window.CreateSurfaceNativeDelegate createSurfaceNativeDelegate = Window.class_abi.BaseOverride(base.LookupGType(), "create_surface");
			if (createSurfaceNativeDelegate == null)
			{
				return null;
			}
			return Surface.Lookup(createSurfaceNativeDelegate(base.Handle, width, height), true);
		}

		// Token: 0x170002AD RID: 685
		// (get) Token: 0x06000A8D RID: 2701 RVA: 0x0001EC74 File Offset: 0x0001CE74
		public new static AbiStruct class_abi
		{
			get
			{
				if (Window._class_abi == null)
				{
					Window._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("pick_embedded_child", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "to_embedder", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("to_embedder", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "pick_embedded_child", "from_embedder", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("from_embedder", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "to_embedder", "create_surface", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("create_surface", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "from_embedder", "_gdk_reserved1", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gdk_reserved1", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "create_surface", "_gdk_reserved2", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gdk_reserved2", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gdk_reserved1", "_gdk_reserved3", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gdk_reserved3", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gdk_reserved2", "_gdk_reserved4", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gdk_reserved4", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gdk_reserved3", "_gdk_reserved5", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gdk_reserved5", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gdk_reserved4", "_gdk_reserved6", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gdk_reserved6", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gdk_reserved5", "_gdk_reserved7", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gdk_reserved7", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gdk_reserved6", "_gdk_reserved8", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("_gdk_reserved8", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "_gdk_reserved7", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Window._class_abi;
			}
		}

		// Token: 0x06000A8E RID: 2702 RVA: 0x0001EF6F File Offset: 0x0001D16F
		[Obsolete]
		public static Window AtPointer(out int win_x, out int win_y)
		{
			return Object.GetObject(Window.gdk_window_at_pointer(out win_x, out win_y)) as Window;
		}

		// Token: 0x06000A8F RID: 2703 RVA: 0x0001EF87 File Offset: 0x0001D187
		public void Beep()
		{
			Window.gdk_window_beep(base.Handle);
		}

		// Token: 0x06000A90 RID: 2704 RVA: 0x0001EF99 File Offset: 0x0001D199
		public DrawingContext BeginDrawFrame(Region region)
		{
			return Object.GetObject(Window.gdk_window_begin_draw_frame(base.Handle, (region == null) ? IntPtr.Zero : region.Handle)) as DrawingContext;
		}

		// Token: 0x06000A91 RID: 2705 RVA: 0x0001EFC5 File Offset: 0x0001D1C5
		public void BeginMoveDrag(int button, int root_x, int root_y, uint timestamp)
		{
			Window.gdk_window_begin_move_drag(base.Handle, button, root_x, root_y, timestamp);
		}

		// Token: 0x06000A92 RID: 2706 RVA: 0x0001EFDC File Offset: 0x0001D1DC
		public void BeginMoveDragForDevice(Device device, int button, int root_x, int root_y, uint timestamp)
		{
			Window.gdk_window_begin_move_drag_for_device(base.Handle, (device == null) ? IntPtr.Zero : device.Handle, button, root_x, root_y, timestamp);
		}

		// Token: 0x06000A93 RID: 2707 RVA: 0x0001F004 File Offset: 0x0001D204
		[Obsolete]
		public void BeginPaintRect(Rectangle rectangle)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(rectangle);
			Window.gdk_window_begin_paint_rect(base.Handle, intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x06000A94 RID: 2708 RVA: 0x0001F034 File Offset: 0x0001D234
		[Obsolete]
		public void BeginPaintRegion(Region region)
		{
			Window.gdk_window_begin_paint_region(base.Handle, (region == null) ? IntPtr.Zero : region.Handle);
		}

		// Token: 0x06000A95 RID: 2709 RVA: 0x0001F056 File Offset: 0x0001D256
		public void BeginResizeDrag(WindowEdge edge, int button, int root_x, int root_y, uint timestamp)
		{
			Window.gdk_window_begin_resize_drag(base.Handle, (int)edge, button, root_x, root_y, timestamp);
		}

		// Token: 0x06000A96 RID: 2710 RVA: 0x0001F06F File Offset: 0x0001D26F
		public void BeginResizeDragForDevice(WindowEdge edge, Device device, int button, int root_x, int root_y, uint timestamp)
		{
			Window.gdk_window_begin_resize_drag_for_device(base.Handle, (int)edge, (device == null) ? IntPtr.Zero : device.Handle, button, root_x, root_y, timestamp);
		}

		// Token: 0x06000A97 RID: 2711 RVA: 0x0001F099 File Offset: 0x0001D299
		[Obsolete]
		public void ConfigureFinished()
		{
			Window.gdk_window_configure_finished(base.Handle);
		}

		// Token: 0x06000A98 RID: 2712 RVA: 0x0001F0AC File Offset: 0x0001D2AC
		public static void ConstrainSize(Geometry geometry, WindowHints flags, int width, int height, out int new_width, out int new_height)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(geometry);
			Window.gdk_window_constrain_size(intPtr, (int)flags, width, height, out new_width, out new_height);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x06000A99 RID: 2713 RVA: 0x0001F0DD File Offset: 0x0001D2DD
		public void CoordsFromParent(double parent_x, double parent_y, out double x, out double y)
		{
			Window.gdk_window_coords_from_parent(base.Handle, parent_x, parent_y, out x, out y);
		}

		// Token: 0x06000A9A RID: 2714 RVA: 0x0001F0F4 File Offset: 0x0001D2F4
		public void CoordsToParent(double x, double y, out double parent_x, out double parent_y)
		{
			Window.gdk_window_coords_to_parent(base.Handle, x, y, out parent_x, out parent_y);
		}

		// Token: 0x06000A9B RID: 2715 RVA: 0x0001F10C File Offset: 0x0001D30C
		public GLContext CreateGlContext()
		{
			IntPtr zero = IntPtr.Zero;
			GLContext result = Object.GetObject(Window.gdk_window_create_gl_context(base.Handle, out zero)) as GLContext;
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x06000A9C RID: 2716 RVA: 0x0001F14F File Offset: 0x0001D34F
		public Surface CreateSimilarSurface(Content content, int width, int height)
		{
			return Surface.Lookup(Window.gdk_window_create_similar_surface(base.Handle, (int)content, width, height), true);
		}

		// Token: 0x06000A9D RID: 2717 RVA: 0x0001F16A File Offset: 0x0001D36A
		public void Deiconify()
		{
			Window.gdk_window_deiconify(base.Handle);
		}

		// Token: 0x06000A9E RID: 2718 RVA: 0x0001F17C File Offset: 0x0001D37C
		[Obsolete]
		public void EnableSynchronizedConfigure()
		{
			Window.gdk_window_enable_synchronized_configure(base.Handle);
		}

		// Token: 0x06000A9F RID: 2719 RVA: 0x0001F18E File Offset: 0x0001D38E
		public void EndDrawFrame(DrawingContext context)
		{
			Window.gdk_window_end_draw_frame(base.Handle, (context == null) ? IntPtr.Zero : context.Handle);
		}

		// Token: 0x06000AA0 RID: 2720 RVA: 0x0001F1B0 File Offset: 0x0001D3B0
		[Obsolete]
		public void EndPaint()
		{
			Window.gdk_window_end_paint(base.Handle);
		}

		// Token: 0x06000AA1 RID: 2721 RVA: 0x0001F1C2 File Offset: 0x0001D3C2
		public bool EnsureNative()
		{
			return Window.gdk_window_ensure_native(base.Handle);
		}

		// Token: 0x06000AA2 RID: 2722 RVA: 0x0001F1D4 File Offset: 0x0001D3D4
		[Obsolete]
		public void Flush()
		{
			Window.gdk_window_flush(base.Handle);
		}

		// Token: 0x06000AA3 RID: 2723 RVA: 0x0001F1E6 File Offset: 0x0001D3E6
		public void Focus(uint timestamp)
		{
			Window.gdk_window_focus(base.Handle, timestamp);
		}

		// Token: 0x06000AA4 RID: 2724 RVA: 0x0001F1F9 File Offset: 0x0001D3F9
		public void FreezeUpdates()
		{
			Window.gdk_window_freeze_updates(base.Handle);
		}

		// Token: 0x06000AA5 RID: 2725 RVA: 0x0001F20B File Offset: 0x0001D40B
		public void Fullscreen()
		{
			Window.gdk_window_fullscreen(base.Handle);
		}

		// Token: 0x06000AA6 RID: 2726 RVA: 0x0001F21D File Offset: 0x0001D41D
		public void FullscreenOnMonitor(int monitor)
		{
			Window.gdk_window_fullscreen_on_monitor(base.Handle, monitor);
		}

		// Token: 0x06000AA7 RID: 2727 RVA: 0x0001F230 File Offset: 0x0001D430
		public void GeometryChanged()
		{
			Window.gdk_window_geometry_changed(base.Handle);
		}

		// Token: 0x170002AE RID: 686
		// (get) Token: 0x06000AA8 RID: 2728 RVA: 0x0001F242 File Offset: 0x0001D442
		// (set) Token: 0x06000AA9 RID: 2729 RVA: 0x0001F254 File Offset: 0x0001D454
		public bool AcceptFocus
		{
			get
			{
				return Window.gdk_window_get_accept_focus(base.Handle);
			}
			set
			{
				Window.gdk_window_set_accept_focus(base.Handle, value);
			}
		}

		// Token: 0x06000AAA RID: 2730 RVA: 0x0001F267 File Offset: 0x0001D467
		public List GetChildrenWithUserData(IntPtr user_data)
		{
			return new List(Window.gdk_window_get_children_with_user_data(base.Handle, user_data));
		}

		// Token: 0x170002AF RID: 687
		// (get) Token: 0x06000AAB RID: 2731 RVA: 0x0001F27F File Offset: 0x0001D47F
		public Region ClipRegion
		{
			get
			{
				return new Region(Window.gdk_window_get_clip_region(base.Handle));
			}
		}

		// Token: 0x170002B0 RID: 688
		// (get) Token: 0x06000AAC RID: 2732 RVA: 0x0001F296 File Offset: 0x0001D496
		// (set) Token: 0x06000AAD RID: 2733 RVA: 0x0001F2A8 File Offset: 0x0001D4A8
		[Obsolete]
		public bool Composited
		{
			get
			{
				return Window.gdk_window_get_composited(base.Handle);
			}
			set
			{
				Window.gdk_window_set_composited(base.Handle, value);
			}
		}

		// Token: 0x06000AAE RID: 2734 RVA: 0x0001F2BC File Offset: 0x0001D4BC
		public bool GetDecorations(out WMDecoration decorations)
		{
			int num;
			bool result = Window.gdk_window_get_decorations(base.Handle, out num);
			decorations = (WMDecoration)num;
			return result;
		}

		// Token: 0x06000AAF RID: 2735 RVA: 0x0001F2DE File Offset: 0x0001D4DE
		public Cursor GetDeviceCursor(Device device)
		{
			return Object.GetObject(Window.gdk_window_get_device_cursor(base.Handle, (device == null) ? IntPtr.Zero : device.Handle)) as Cursor;
		}

		// Token: 0x06000AB0 RID: 2736 RVA: 0x0001F30A File Offset: 0x0001D50A
		public EventMask GetDeviceEvents(Device device)
		{
			return (EventMask)Window.gdk_window_get_device_events(base.Handle, (device == null) ? IntPtr.Zero : device.Handle);
		}

		// Token: 0x06000AB1 RID: 2737 RVA: 0x0001F32C File Offset: 0x0001D52C
		public Window GetDevicePosition(Device device, out int x, out int y, out ModifierType mask)
		{
			int num;
			Window result = Object.GetObject(Window.gdk_window_get_device_position(base.Handle, (device == null) ? IntPtr.Zero : device.Handle, out x, out y, out num)) as Window;
			mask = (ModifierType)num;
			return result;
		}

		// Token: 0x06000AB2 RID: 2738 RVA: 0x0001F36C File Offset: 0x0001D56C
		public Window GetDevicePositionDouble(Device device, out double x, out double y, out ModifierType mask)
		{
			int num;
			Window result = Object.GetObject(Window.gdk_window_get_device_position_double(base.Handle, (device == null) ? IntPtr.Zero : device.Handle, out x, out y, out num)) as Window;
			mask = (ModifierType)num;
			return result;
		}

		// Token: 0x170002B1 RID: 689
		// (get) Token: 0x06000AB3 RID: 2739 RVA: 0x0001F3AB File Offset: 0x0001D5AB
		public Display Display
		{
			get
			{
				return Object.GetObject(Window.gdk_window_get_display(base.Handle)) as Display;
			}
		}

		// Token: 0x06000AB4 RID: 2740 RVA: 0x0001F3C7 File Offset: 0x0001D5C7
		public DragProtocol GetDragProtocol(Window target)
		{
			return (DragProtocol)Window.gdk_window_get_drag_protocol(base.Handle, (target == null) ? IntPtr.Zero : target.Handle);
		}

		// Token: 0x170002B2 RID: 690
		// (get) Token: 0x06000AB5 RID: 2741 RVA: 0x0001F3E9 File Offset: 0x0001D5E9
		public Window EffectiveParent
		{
			get
			{
				return Object.GetObject(Window.gdk_window_get_effective_parent(base.Handle)) as Window;
			}
		}

		// Token: 0x170002B3 RID: 691
		// (get) Token: 0x06000AB6 RID: 2742 RVA: 0x0001F405 File Offset: 0x0001D605
		public Window EffectiveToplevel
		{
			get
			{
				return Object.GetObject(Window.gdk_window_get_effective_toplevel(base.Handle)) as Window;
			}
		}

		// Token: 0x170002B4 RID: 692
		// (get) Token: 0x06000AB7 RID: 2743 RVA: 0x0001F421 File Offset: 0x0001D621
		// (set) Token: 0x06000AB8 RID: 2744 RVA: 0x0001F433 File Offset: 0x0001D633
		public bool EventCompression
		{
			get
			{
				return Window.gdk_window_get_event_compression(base.Handle);
			}
			set
			{
				Window.gdk_window_set_event_compression(base.Handle, value);
			}
		}

		// Token: 0x170002B5 RID: 693
		// (get) Token: 0x06000AB9 RID: 2745 RVA: 0x0001F446 File Offset: 0x0001D646
		// (set) Token: 0x06000ABA RID: 2746 RVA: 0x0001F458 File Offset: 0x0001D658
		public EventMask Events
		{
			get
			{
				return (EventMask)Window.gdk_window_get_events(base.Handle);
			}
			set
			{
				Window.gdk_window_set_events(base.Handle, (int)value);
			}
		}

		// Token: 0x170002B6 RID: 694
		// (get) Token: 0x06000ABB RID: 2747 RVA: 0x0001F46B File Offset: 0x0001D66B
		// (set) Token: 0x06000ABC RID: 2748 RVA: 0x0001F47D File Offset: 0x0001D67D
		public bool FocusOnMap
		{
			get
			{
				return Window.gdk_window_get_focus_on_map(base.Handle);
			}
			set
			{
				Window.gdk_window_set_focus_on_map(base.Handle, value);
			}
		}

		// Token: 0x170002B7 RID: 695
		// (get) Token: 0x06000ABD RID: 2749 RVA: 0x0001F490 File Offset: 0x0001D690
		public FrameClock FrameClock
		{
			get
			{
				return Object.GetObject(Window.gdk_window_get_frame_clock(base.Handle)) as FrameClock;
			}
		}

		// Token: 0x170002B8 RID: 696
		// (get) Token: 0x06000ABE RID: 2750 RVA: 0x0001F4AC File Offset: 0x0001D6AC
		public Rectangle FrameExtents
		{
			get
			{
				IntPtr intPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(Rectangle)));
				Window.gdk_window_get_frame_extents(base.Handle, intPtr);
				Rectangle result = (Rectangle)Marshal.PtrToStructure(intPtr, typeof(Rectangle));
				Marshal.FreeHGlobal(intPtr);
				return result;
			}
		}

		// Token: 0x170002B9 RID: 697
		// (get) Token: 0x06000ABF RID: 2751 RVA: 0x0001F4FA File Offset: 0x0001D6FA
		// (set) Token: 0x06000AC0 RID: 2752 RVA: 0x0001F50C File Offset: 0x0001D70C
		public FullscreenMode FullscreenMode
		{
			get
			{
				return (FullscreenMode)Window.gdk_window_get_fullscreen_mode(base.Handle);
			}
			set
			{
				Window.gdk_window_set_fullscreen_mode(base.Handle, (int)value);
			}
		}

		// Token: 0x06000AC1 RID: 2753 RVA: 0x0001F51F File Offset: 0x0001D71F
		public void GetGeometry(out int x, out int y, out int width, out int height)
		{
			Window.gdk_window_get_geometry(base.Handle, out x, out y, out width, out height);
		}

		// Token: 0x170002BA RID: 698
		// (get) Token: 0x06000AC2 RID: 2754 RVA: 0x0001F536 File Offset: 0x0001D736
		// (set) Token: 0x06000AC3 RID: 2755 RVA: 0x0001F552 File Offset: 0x0001D752
		public Window Group
		{
			get
			{
				return Object.GetObject(Window.gdk_window_get_group(base.Handle)) as Window;
			}
			set
			{
				Window.gdk_window_set_group(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x170002BB RID: 699
		// (get) Token: 0x06000AC4 RID: 2756 RVA: 0x0001F574 File Offset: 0x0001D774
		public int Height
		{
			get
			{
				return Window.gdk_window_get_height(base.Handle);
			}
		}

		// Token: 0x170002BC RID: 700
		// (get) Token: 0x06000AC5 RID: 2757 RVA: 0x0001F586 File Offset: 0x0001D786
		// (set) Token: 0x06000AC6 RID: 2758 RVA: 0x0001F598 File Offset: 0x0001D798
		public bool ModalHint
		{
			get
			{
				return Window.gdk_window_get_modal_hint(base.Handle);
			}
			set
			{
				Window.gdk_window_set_modal_hint(base.Handle, value);
			}
		}

		// Token: 0x06000AC7 RID: 2759 RVA: 0x0001F5AB File Offset: 0x0001D7AB
		public int GetOrigin(out int x, out int y)
		{
			return Window.gdk_window_get_origin(base.Handle, out x, out y);
		}

		// Token: 0x170002BD RID: 701
		// (get) Token: 0x06000AC8 RID: 2760 RVA: 0x0001F5BF File Offset: 0x0001D7BF
		public Window Parent
		{
			get
			{
				return Object.GetObject(Window.gdk_window_get_parent(base.Handle)) as Window;
			}
		}

		// Token: 0x170002BE RID: 702
		// (get) Token: 0x06000AC9 RID: 2761 RVA: 0x0001F5DB File Offset: 0x0001D7DB
		// (set) Token: 0x06000ACA RID: 2762 RVA: 0x0001F5ED File Offset: 0x0001D7ED
		public bool PassThrough
		{
			get
			{
				return Window.gdk_window_get_pass_through(base.Handle);
			}
			set
			{
				Window.gdk_window_set_pass_through(base.Handle, value);
			}
		}

		// Token: 0x06000ACB RID: 2763 RVA: 0x0001F600 File Offset: 0x0001D800
		[Obsolete]
		public Window GetPointer(out int x, out int y, out ModifierType mask)
		{
			int num;
			Window result = Object.GetObject(Window.gdk_window_get_pointer(base.Handle, out x, out y, out num)) as Window;
			mask = (ModifierType)num;
			return result;
		}

		// Token: 0x06000ACC RID: 2764 RVA: 0x0001F62E File Offset: 0x0001D82E
		public void GetPosition(out int x, out int y)
		{
			Window.gdk_window_get_position(base.Handle, out x, out y);
		}

		// Token: 0x06000ACD RID: 2765 RVA: 0x0001F642 File Offset: 0x0001D842
		public void GetRootCoords(int x, int y, out int root_x, out int root_y)
		{
			Window.gdk_window_get_root_coords(base.Handle, x, y, out root_x, out root_y);
		}

		// Token: 0x06000ACE RID: 2766 RVA: 0x0001F659 File Offset: 0x0001D859
		public void GetRootOrigin(out int x, out int y)
		{
			Window.gdk_window_get_root_origin(base.Handle, out x, out y);
		}

		// Token: 0x170002BF RID: 703
		// (get) Token: 0x06000ACF RID: 2767 RVA: 0x0001F66D File Offset: 0x0001D86D
		public int ScaleFactor
		{
			get
			{
				return Window.gdk_window_get_scale_factor(base.Handle);
			}
		}

		// Token: 0x170002C0 RID: 704
		// (get) Token: 0x06000AD0 RID: 2768 RVA: 0x0001F67F File Offset: 0x0001D87F
		public Screen Screen
		{
			get
			{
				return Object.GetObject(Window.gdk_window_get_screen(base.Handle)) as Screen;
			}
		}

		// Token: 0x06000AD1 RID: 2769 RVA: 0x0001F69B File Offset: 0x0001D89B
		public EventMask GetSourceEvents(InputSource source)
		{
			return (EventMask)Window.gdk_window_get_source_events(base.Handle, (int)source);
		}

		// Token: 0x170002C1 RID: 705
		// (get) Token: 0x06000AD2 RID: 2770 RVA: 0x0001F6AE File Offset: 0x0001D8AE
		public WindowState State
		{
			get
			{
				return (WindowState)Window.gdk_window_get_state(base.Handle);
			}
		}

		// Token: 0x170002C2 RID: 706
		// (get) Token: 0x06000AD3 RID: 2771 RVA: 0x0001F6C0 File Offset: 0x0001D8C0
		// (set) Token: 0x06000AD4 RID: 2772 RVA: 0x0001F6D2 File Offset: 0x0001D8D2
		public bool SupportMultidevice
		{
			get
			{
				return Window.gdk_window_get_support_multidevice(base.Handle);
			}
			set
			{
				Window.gdk_window_set_support_multidevice(base.Handle, value);
			}
		}

		// Token: 0x170002C3 RID: 707
		// (get) Token: 0x06000AD5 RID: 2773 RVA: 0x0001F6E5 File Offset: 0x0001D8E5
		public Window Toplevel
		{
			get
			{
				return Object.GetObject(Window.gdk_window_get_toplevel(base.Handle)) as Window;
			}
		}

		// Token: 0x170002C4 RID: 708
		// (get) Token: 0x06000AD6 RID: 2774 RVA: 0x0001F704 File Offset: 0x0001D904
		public new static GType GType
		{
			get
			{
				IntPtr val = Window.gdk_window_get_type();
				return new GType(val);
			}
		}

		// Token: 0x170002C5 RID: 709
		// (get) Token: 0x06000AD7 RID: 2775 RVA: 0x0001F722 File Offset: 0x0001D922
		// (set) Token: 0x06000AD8 RID: 2776 RVA: 0x0001F734 File Offset: 0x0001D934
		public WindowTypeHint TypeHint
		{
			get
			{
				return (WindowTypeHint)Window.gdk_window_get_type_hint(base.Handle);
			}
			set
			{
				Window.gdk_window_set_type_hint(base.Handle, (int)value);
			}
		}

		// Token: 0x170002C6 RID: 710
		// (get) Token: 0x06000AD9 RID: 2777 RVA: 0x0001F747 File Offset: 0x0001D947
		public Region UpdateArea
		{
			get
			{
				return new Region(Window.gdk_window_get_update_area(base.Handle));
			}
		}

		// Token: 0x170002C7 RID: 711
		// (get) Token: 0x06000ADA RID: 2778 RVA: 0x0001F75E File Offset: 0x0001D95E
		public Region VisibleRegion
		{
			get
			{
				return new Region(Window.gdk_window_get_visible_region(base.Handle));
			}
		}

		// Token: 0x170002C8 RID: 712
		// (get) Token: 0x06000ADB RID: 2779 RVA: 0x0001F775 File Offset: 0x0001D975
		public Visual Visual
		{
			get
			{
				return Object.GetObject(Window.gdk_window_get_visual(base.Handle)) as Visual;
			}
		}

		// Token: 0x170002C9 RID: 713
		// (get) Token: 0x06000ADC RID: 2780 RVA: 0x0001F791 File Offset: 0x0001D991
		public int Width
		{
			get
			{
				return Window.gdk_window_get_width(base.Handle);
			}
		}

		// Token: 0x170002CA RID: 714
		// (get) Token: 0x06000ADD RID: 2781 RVA: 0x0001F7A3 File Offset: 0x0001D9A3
		public WindowType WindowType
		{
			get
			{
				return (WindowType)Window.gdk_window_get_window_type(base.Handle);
			}
		}

		// Token: 0x170002CB RID: 715
		// (get) Token: 0x06000ADE RID: 2782 RVA: 0x0001F7B5 File Offset: 0x0001D9B5
		public bool HasNative
		{
			get
			{
				return Window.gdk_window_has_native(base.Handle);
			}
		}

		// Token: 0x06000ADF RID: 2783 RVA: 0x0001F7C7 File Offset: 0x0001D9C7
		public void Hide()
		{
			Window.gdk_window_hide(base.Handle);
		}

		// Token: 0x06000AE0 RID: 2784 RVA: 0x0001F7D9 File Offset: 0x0001D9D9
		public void Iconify()
		{
			Window.gdk_window_iconify(base.Handle);
		}

		// Token: 0x06000AE1 RID: 2785 RVA: 0x0001F7EB File Offset: 0x0001D9EB
		public void InputShapeCombineRegion(Region shape_region, int offset_x, int offset_y)
		{
			Window.gdk_window_input_shape_combine_region(base.Handle, (shape_region == null) ? IntPtr.Zero : shape_region.Handle, offset_x, offset_y);
		}

		// Token: 0x06000AE2 RID: 2786 RVA: 0x0001F810 File Offset: 0x0001DA10
		public void InvalidateMaybeRecurse(Region region, WindowChildFunc child_func)
		{
			WindowChildFuncWrapper windowChildFuncWrapper = new WindowChildFuncWrapper(child_func);
			Window.gdk_window_invalidate_maybe_recurse(base.Handle, (region == null) ? IntPtr.Zero : region.Handle, windowChildFuncWrapper.NativeDelegate, IntPtr.Zero);
		}

		// Token: 0x06000AE3 RID: 2787 RVA: 0x0001F850 File Offset: 0x0001DA50
		public void InvalidateRect(Rectangle rect, bool invalidate_children)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(rect);
			Window.gdk_window_invalidate_rect(base.Handle, intPtr, invalidate_children);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x06000AE4 RID: 2788 RVA: 0x0001F881 File Offset: 0x0001DA81
		public void InvalidateRegion(Region region, bool invalidate_children)
		{
			Window.gdk_window_invalidate_region(base.Handle, (region == null) ? IntPtr.Zero : region.Handle, invalidate_children);
		}

		// Token: 0x170002CC RID: 716
		// (get) Token: 0x06000AE5 RID: 2789 RVA: 0x0001F8A4 File Offset: 0x0001DAA4
		public bool IsDestroyed
		{
			get
			{
				return Window.gdk_window_is_destroyed(base.Handle);
			}
		}

		// Token: 0x170002CD RID: 717
		// (get) Token: 0x06000AE6 RID: 2790 RVA: 0x0001F8B6 File Offset: 0x0001DAB6
		public bool IsInputOnly
		{
			get
			{
				return Window.gdk_window_is_input_only(base.Handle);
			}
		}

		// Token: 0x170002CE RID: 718
		// (get) Token: 0x06000AE7 RID: 2791 RVA: 0x0001F8C8 File Offset: 0x0001DAC8
		public bool IsShaped
		{
			get
			{
				return Window.gdk_window_is_shaped(base.Handle);
			}
		}

		// Token: 0x170002CF RID: 719
		// (get) Token: 0x06000AE8 RID: 2792 RVA: 0x0001F8DA File Offset: 0x0001DADA
		public bool IsViewable
		{
			get
			{
				return Window.gdk_window_is_viewable(base.Handle);
			}
		}

		// Token: 0x170002D0 RID: 720
		// (get) Token: 0x06000AE9 RID: 2793 RVA: 0x0001F8EC File Offset: 0x0001DAEC
		public bool IsVisible
		{
			get
			{
				return Window.gdk_window_is_visible(base.Handle);
			}
		}

		// Token: 0x06000AEA RID: 2794 RVA: 0x0001F8FE File Offset: 0x0001DAFE
		public void Lower()
		{
			Window.gdk_window_lower(base.Handle);
		}

		// Token: 0x06000AEB RID: 2795 RVA: 0x0001F910 File Offset: 0x0001DB10
		public void MarkPaintFromClip(Context cr)
		{
			Window.gdk_window_mark_paint_from_clip(base.Handle, (cr == null) ? IntPtr.Zero : cr.Handle);
		}

		// Token: 0x06000AEC RID: 2796 RVA: 0x0001F932 File Offset: 0x0001DB32
		public void Maximize()
		{
			Window.gdk_window_maximize(base.Handle);
		}

		// Token: 0x06000AED RID: 2797 RVA: 0x0001F944 File Offset: 0x0001DB44
		public void MergeChildInputShapes()
		{
			Window.gdk_window_merge_child_input_shapes(base.Handle);
		}

		// Token: 0x06000AEE RID: 2798 RVA: 0x0001F956 File Offset: 0x0001DB56
		public void MergeChildShapes()
		{
			Window.gdk_window_merge_child_shapes(base.Handle);
		}

		// Token: 0x06000AEF RID: 2799 RVA: 0x0001F968 File Offset: 0x0001DB68
		public void Move(int x, int y)
		{
			Window.gdk_window_move(base.Handle, x, y);
		}

		// Token: 0x06000AF0 RID: 2800 RVA: 0x0001F97C File Offset: 0x0001DB7C
		public void MoveRegion(Region region, int dx, int dy)
		{
			Window.gdk_window_move_region(base.Handle, (region == null) ? IntPtr.Zero : region.Handle, dx, dy);
		}

		// Token: 0x06000AF1 RID: 2801 RVA: 0x0001F9A0 File Offset: 0x0001DBA0
		public void MoveResize(int x, int y, int width, int height)
		{
			Window.gdk_window_move_resize(base.Handle, x, y, width, height);
		}

		// Token: 0x06000AF2 RID: 2802 RVA: 0x0001F9B7 File Offset: 0x0001DBB7
		public static void ProcessAllUpdates()
		{
			Window.gdk_window_process_all_updates();
		}

		// Token: 0x06000AF3 RID: 2803 RVA: 0x0001F9C3 File Offset: 0x0001DBC3
		public void ProcessUpdates(bool update_children)
		{
			Window.gdk_window_process_updates(base.Handle, update_children);
		}

		// Token: 0x06000AF4 RID: 2804 RVA: 0x0001F9D6 File Offset: 0x0001DBD6
		public void Raise()
		{
			Window.gdk_window_raise(base.Handle);
		}

		// Token: 0x06000AF5 RID: 2805 RVA: 0x0001F9E8 File Offset: 0x0001DBE8
		public void RegisterDnd()
		{
			Window.gdk_window_register_dnd(base.Handle);
		}

		// Token: 0x06000AF6 RID: 2806 RVA: 0x0001F9FA File Offset: 0x0001DBFA
		public void Reparent(Window new_parent, int x, int y)
		{
			Window.gdk_window_reparent(base.Handle, (new_parent == null) ? IntPtr.Zero : new_parent.Handle, x, y);
		}

		// Token: 0x06000AF7 RID: 2807 RVA: 0x0001FA1E File Offset: 0x0001DC1E
		public void Resize(int width, int height)
		{
			Window.gdk_window_resize(base.Handle, width, height);
		}

		// Token: 0x06000AF8 RID: 2808 RVA: 0x0001FA32 File Offset: 0x0001DC32
		public void Restack(Window sibling, bool above)
		{
			Window.gdk_window_restack(base.Handle, (sibling == null) ? IntPtr.Zero : sibling.Handle, above);
		}

		// Token: 0x06000AF9 RID: 2809 RVA: 0x0001FA55 File Offset: 0x0001DC55
		public void Scroll(int dx, int dy)
		{
			Window.gdk_window_scroll(base.Handle, dx, dy);
		}

		// Token: 0x170002D1 RID: 721
		// (set) Token: 0x06000AFA RID: 2810 RVA: 0x0001FA6C File Offset: 0x0001DC6C
		[Obsolete]
		public Color Background
		{
			set
			{
				IntPtr intPtr = Marshaller.StructureToPtrAlloc(value);
				Window.gdk_window_set_background(base.Handle, intPtr);
				Marshal.FreeHGlobal(intPtr);
			}
		}

		// Token: 0x170002D2 RID: 722
		// (set) Token: 0x06000AFB RID: 2811 RVA: 0x0001FA9C File Offset: 0x0001DC9C
		[Obsolete]
		public RGBA BackgroundRgba
		{
			set
			{
				IntPtr intPtr = Marshaller.StructureToPtrAlloc(value);
				Window.gdk_window_set_background_rgba(base.Handle, intPtr);
				Marshal.FreeHGlobal(intPtr);
			}
		}

		// Token: 0x06000AFC RID: 2812 RVA: 0x0001FACC File Offset: 0x0001DCCC
		public void SetChildInputShapes()
		{
			Window.gdk_window_set_child_input_shapes(base.Handle);
		}

		// Token: 0x06000AFD RID: 2813 RVA: 0x0001FADE File Offset: 0x0001DCDE
		public void SetChildShapes()
		{
			Window.gdk_window_set_child_shapes(base.Handle);
		}

		// Token: 0x170002D3 RID: 723
		// (set) Token: 0x06000AFE RID: 2814 RVA: 0x0001FAF0 File Offset: 0x0001DCF0
		[Obsolete]
		public static bool DebugUpdates
		{
			set
			{
				Window.gdk_window_set_debug_updates(value);
			}
		}

		// Token: 0x06000AFF RID: 2815 RVA: 0x0001FAFD File Offset: 0x0001DCFD
		public void SetDecorations(WMDecoration decorations)
		{
			Window.gdk_window_set_decorations(base.Handle, (int)decorations);
		}

		// Token: 0x06000B00 RID: 2816 RVA: 0x0001FB10 File Offset: 0x0001DD10
		public void SetDeviceCursor(Device device, Cursor cursor)
		{
			Window.gdk_window_set_device_cursor(base.Handle, (device == null) ? IntPtr.Zero : device.Handle, (cursor == null) ? IntPtr.Zero : cursor.Handle);
		}

		// Token: 0x06000B01 RID: 2817 RVA: 0x0001FB42 File Offset: 0x0001DD42
		public void SetDeviceEvents(Device device, EventMask event_mask)
		{
			Window.gdk_window_set_device_events(base.Handle, (device == null) ? IntPtr.Zero : device.Handle, (int)event_mask);
		}

		// Token: 0x170002D4 RID: 724
		// (set) Token: 0x06000B02 RID: 2818 RVA: 0x0001FB65 File Offset: 0x0001DD65
		public WMFunction Functions
		{
			set
			{
				Window.gdk_window_set_functions(base.Handle, (int)value);
			}
		}

		// Token: 0x06000B03 RID: 2819 RVA: 0x0001FB78 File Offset: 0x0001DD78
		public void SetGeometryHints(Geometry geometry, WindowHints geom_mask)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(geometry);
			Window.gdk_window_set_geometry_hints(base.Handle, intPtr, (int)geom_mask);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x170002D5 RID: 725
		// (set) Token: 0x06000B04 RID: 2820 RVA: 0x0001FBAC File Offset: 0x0001DDAC
		public string IconName
		{
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				Window.gdk_window_set_icon_name(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x170002D6 RID: 726
		// (set) Token: 0x06000B05 RID: 2821 RVA: 0x0001FBD8 File Offset: 0x0001DDD8
		public WindowInvalidateHandlerFunc InvalidateHandler
		{
			set
			{
				WindowInvalidateHandlerFuncWrapper windowInvalidateHandlerFuncWrapper = new WindowInvalidateHandlerFuncWrapper(value);
				Window.gdk_window_set_invalidate_handler(base.Handle, windowInvalidateHandlerFuncWrapper.NativeDelegate);
			}
		}

		// Token: 0x170002D7 RID: 727
		// (set) Token: 0x06000B06 RID: 2822 RVA: 0x0001FC02 File Offset: 0x0001DE02
		public bool KeepAbove
		{
			set
			{
				Window.gdk_window_set_keep_above(base.Handle, value);
			}
		}

		// Token: 0x170002D8 RID: 728
		// (set) Token: 0x06000B07 RID: 2823 RVA: 0x0001FC15 File Offset: 0x0001DE15
		public bool KeepBelow
		{
			set
			{
				Window.gdk_window_set_keep_below(base.Handle, value);
			}
		}

		// Token: 0x170002D9 RID: 729
		// (set) Token: 0x06000B08 RID: 2824 RVA: 0x0001FC28 File Offset: 0x0001DE28
		public double Opacity
		{
			set
			{
				Window.gdk_window_set_opacity(base.Handle, value);
			}
		}

		// Token: 0x170002DA RID: 730
		// (set) Token: 0x06000B09 RID: 2825 RVA: 0x0001FC3B File Offset: 0x0001DE3B
		public Region OpaqueRegion
		{
			set
			{
				Window.gdk_window_set_opaque_region(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x170002DB RID: 731
		// (set) Token: 0x06000B0A RID: 2826 RVA: 0x0001FC5D File Offset: 0x0001DE5D
		public bool OverrideRedirect
		{
			set
			{
				Window.gdk_window_set_override_redirect(base.Handle, value);
			}
		}

		// Token: 0x170002DC RID: 732
		// (set) Token: 0x06000B0B RID: 2827 RVA: 0x0001FC70 File Offset: 0x0001DE70
		public string Role
		{
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				Window.gdk_window_set_role(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x06000B0C RID: 2828 RVA: 0x0001FC9B File Offset: 0x0001DE9B
		public void SetShadowWidth(int left, int right, int top, int bottom)
		{
			Window.gdk_window_set_shadow_width(base.Handle, left, right, top, bottom);
		}

		// Token: 0x170002DD RID: 733
		// (set) Token: 0x06000B0D RID: 2829 RVA: 0x0001FCB2 File Offset: 0x0001DEB2
		public bool SkipPagerHint
		{
			set
			{
				Window.gdk_window_set_skip_pager_hint(base.Handle, value);
			}
		}

		// Token: 0x170002DE RID: 734
		// (set) Token: 0x06000B0E RID: 2830 RVA: 0x0001FCC5 File Offset: 0x0001DEC5
		public bool SkipTaskbarHint
		{
			set
			{
				Window.gdk_window_set_skip_taskbar_hint(base.Handle, value);
			}
		}

		// Token: 0x06000B0F RID: 2831 RVA: 0x0001FCD8 File Offset: 0x0001DED8
		public void SetSourceEvents(InputSource source, EventMask event_mask)
		{
			Window.gdk_window_set_source_events(base.Handle, (int)source, (int)event_mask);
		}

		// Token: 0x170002DF RID: 735
		// (set) Token: 0x06000B10 RID: 2832 RVA: 0x0001FCEC File Offset: 0x0001DEEC
		public string StartupId
		{
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				Window.gdk_window_set_startup_id(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x06000B11 RID: 2833 RVA: 0x0001FD17 File Offset: 0x0001DF17
		[Obsolete]
		public bool SetStaticGravities(bool use_static)
		{
			return Window.gdk_window_set_static_gravities(base.Handle, use_static);
		}

		// Token: 0x170002E0 RID: 736
		// (set) Token: 0x06000B12 RID: 2834 RVA: 0x0001FD2C File Offset: 0x0001DF2C
		public string Title
		{
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				Window.gdk_window_set_title(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x170002E1 RID: 737
		// (set) Token: 0x06000B13 RID: 2835 RVA: 0x0001FD57 File Offset: 0x0001DF57
		public Window TransientFor
		{
			set
			{
				Window.gdk_window_set_transient_for(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x170002E2 RID: 738
		// (set) Token: 0x06000B14 RID: 2836 RVA: 0x0001FD79 File Offset: 0x0001DF79
		public bool UrgencyHint
		{
			set
			{
				Window.gdk_window_set_urgency_hint(base.Handle, value);
			}
		}

		// Token: 0x06000B15 RID: 2837 RVA: 0x0001FD8C File Offset: 0x0001DF8C
		public void ShapeCombineRegion(Region shape_region, int offset_x, int offset_y)
		{
			Window.gdk_window_shape_combine_region(base.Handle, (shape_region == null) ? IntPtr.Zero : shape_region.Handle, offset_x, offset_y);
		}

		// Token: 0x06000B16 RID: 2838 RVA: 0x0001FDB0 File Offset: 0x0001DFB0
		public void Show()
		{
			Window.gdk_window_show(base.Handle);
		}

		// Token: 0x06000B17 RID: 2839 RVA: 0x0001FDC2 File Offset: 0x0001DFC2
		public void ShowUnraised()
		{
			Window.gdk_window_show_unraised(base.Handle);
		}

		// Token: 0x06000B18 RID: 2840 RVA: 0x0001FDD4 File Offset: 0x0001DFD4
		public bool ShowWindowMenu(Event evnt)
		{
			return Window.gdk_window_show_window_menu(base.Handle, (evnt == null) ? IntPtr.Zero : evnt.Handle);
		}

		// Token: 0x06000B19 RID: 2841 RVA: 0x0001FDF6 File Offset: 0x0001DFF6
		public void Stick()
		{
			Window.gdk_window_stick(base.Handle);
		}

		// Token: 0x06000B1A RID: 2842 RVA: 0x0001FE08 File Offset: 0x0001E008
		public void ThawUpdates()
		{
			Window.gdk_window_thaw_updates(base.Handle);
		}

		// Token: 0x06000B1B RID: 2843 RVA: 0x0001FE1A File Offset: 0x0001E01A
		public void Unfullscreen()
		{
			Window.gdk_window_unfullscreen(base.Handle);
		}

		// Token: 0x06000B1C RID: 2844 RVA: 0x0001FE2C File Offset: 0x0001E02C
		public void Unmaximize()
		{
			Window.gdk_window_unmaximize(base.Handle);
		}

		// Token: 0x06000B1D RID: 2845 RVA: 0x0001FE3E File Offset: 0x0001E03E
		public void Unstick()
		{
			Window.gdk_window_unstick(base.Handle);
		}

		// Token: 0x06000B1E RID: 2846 RVA: 0x0001FE50 File Offset: 0x0001E050
		public void Withdraw()
		{
			Window.gdk_window_withdraw(base.Handle);
		}

		// Token: 0x170002E3 RID: 739
		// (get) Token: 0x06000B1F RID: 2847 RVA: 0x0001FE62 File Offset: 0x0001E062
		public new static AbiStruct abi_info
		{
			get
			{
				if (Window._abi_info == null)
				{
					Window._abi_info = new AbiStruct(Object.abi_info.Fields);
				}
				return Window._abi_info;
			}
		}

		// Token: 0x06000B20 RID: 2848 RVA: 0x0001FE84 File Offset: 0x0001E084
		public Window(Window parent, WindowAttr attributes, WindowAttributesType attributes_mask) : this(parent, attributes, (int)attributes_mask)
		{
		}

		// Token: 0x170002E4 RID: 740
		// (get) Token: 0x06000B21 RID: 2849 RVA: 0x0001FE8F File Offset: 0x0001E08F
		// (set) Token: 0x06000B22 RID: 2850 RVA: 0x0001FEA7 File Offset: 0x0001E0A7
		public Pattern BackgroundPattern
		{
			get
			{
				return Pattern.Lookup(Window.gdk_window_get_background_pattern(base.Handle), true);
			}
			set
			{
				Window.gdk_window_set_background_pattern(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x170002E5 RID: 741
		// (get) Token: 0x06000B23 RID: 2851 RVA: 0x0001FECC File Offset: 0x0001E0CC
		public Window[] Children
		{
			get
			{
				IntPtr intPtr = Window.gdk_window_get_children(base.Handle);
				if (intPtr == IntPtr.Zero)
				{
					return new Window[0];
				}
				List list = new List(intPtr);
				Window[] array = new Window[list.Count];
				for (int i = 0; i < list.Count; i++)
				{
					array[i] = (list[i] as Window);
				}
				return array;
			}
		}

		// Token: 0x170002E6 RID: 742
		// (set) Token: 0x06000B24 RID: 2852 RVA: 0x0001FF34 File Offset: 0x0001E134
		public Pixbuf[] IconList
		{
			set
			{
				List list = new List(IntPtr.Zero);
				for (int i = 0; i < value.Length; i++)
				{
					Pixbuf pixbuf = value[i];
					list.Append(pixbuf.Handle);
				}
				Window.gdk_window_set_icon_list(base.Handle, list.Handle);
			}
		}

		// Token: 0x06000B25 RID: 2853 RVA: 0x0001FF82 File Offset: 0x0001E182
		public void Destroy()
		{
			Window.g_object_ref(base.Handle);
			Window.gdk_window_destroy(base.Handle);
			base.Dispose();
		}

		// Token: 0x06000B26 RID: 2854 RVA: 0x0001FFAB File Offset: 0x0001E1AB
		public void MoveResize(Rectangle rect)
		{
			Window.gdk_window_move_resize(base.Handle, rect.X, rect.Y, rect.Width, rect.Height);
		}

		// Token: 0x170002E7 RID: 743
		// (get) Token: 0x06000B27 RID: 2855 RVA: 0x0001FFD8 File Offset: 0x0001E1D8
		// (set) Token: 0x06000B28 RID: 2856 RVA: 0x0001FFF8 File Offset: 0x0001E1F8
		public IntPtr UserData
		{
			get
			{
				IntPtr result;
				Window.gdk_window_get_user_data(base.Handle, out result);
				return result;
			}
			set
			{
				Window.gdk_window_set_user_data(base.Handle, value);
			}
		}

		// Token: 0x170002E8 RID: 744
		// (get) Token: 0x06000B29 RID: 2857 RVA: 0x0002000B File Offset: 0x0001E20B
		private static IDictionary<FilterFunc, FilterFuncWrapper> FilterAllHash
		{
			get
			{
				if (Window.filter_all_hash == null)
				{
					Window.filter_all_hash = new Dictionary<FilterFunc, FilterFuncWrapper>();
				}
				return Window.filter_all_hash;
			}
		}

		// Token: 0x06000B2A RID: 2858 RVA: 0x00020024 File Offset: 0x0001E224
		public static void AddFilterForAll(FilterFunc func)
		{
			FilterFuncWrapper filterFuncWrapper = new FilterFuncWrapper(func);
			Window.FilterAllHash[func] = filterFuncWrapper;
			Window.gdk_window_add_filter(IntPtr.Zero, filterFuncWrapper.NativeDelegate, IntPtr.Zero);
		}

		// Token: 0x06000B2B RID: 2859 RVA: 0x00020060 File Offset: 0x0001E260
		public static void RemoveFilterForAll(FilterFunc func)
		{
			FilterFuncWrapper filterFuncWrapper = null;
			if (Window.FilterAllHash.TryGetValue(func, out filterFuncWrapper))
			{
				Window.FilterAllHash.Remove(func);
				Window.gdk_window_remove_filter(IntPtr.Zero, filterFuncWrapper.NativeDelegate, IntPtr.Zero);
			}
		}

		// Token: 0x06000B2C RID: 2860 RVA: 0x000200A4 File Offset: 0x0001E2A4
		public void AddFilter(FilterFunc function)
		{
			if (!base.Data.ContainsKey("filter_func_hash"))
			{
				base.Data["filter_func_hash"] = new Dictionary<FilterFunc, FilterFuncWrapper>();
			}
			Dictionary<FilterFunc, FilterFuncWrapper> dictionary = base.Data["filter_func_hash"] as Dictionary<FilterFunc, FilterFuncWrapper>;
			FilterFuncWrapper filterFuncWrapper = new FilterFuncWrapper(function);
			dictionary[function] = filterFuncWrapper;
			Window.gdk_window_add_filter(base.Handle, filterFuncWrapper.NativeDelegate, IntPtr.Zero);
		}

		// Token: 0x06000B2D RID: 2861 RVA: 0x00020118 File Offset: 0x0001E318
		public void RemoveFilter(FilterFunc function)
		{
			Dictionary<FilterFunc, FilterFuncWrapper> dictionary = base.Data["filter_func_hash"] as Dictionary<FilterFunc, FilterFuncWrapper>;
			FilterFuncWrapper filterFuncWrapper = null;
			if (dictionary.TryGetValue(function, out filterFuncWrapper))
			{
				dictionary.Remove(function);
				Window.gdk_window_remove_filter(base.Handle, filterFuncWrapper.NativeDelegate, IntPtr.Zero);
			}
		}

		// Token: 0x040005B7 RID: 1463
		private static Window.d_gdk_window_new gdk_window_new = FuncLoader.LoadFunction<Window.d_gdk_window_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_new"));

		// Token: 0x040005B8 RID: 1464
		private static Window.d_gdk_window_get_cursor gdk_window_get_cursor = FuncLoader.LoadFunction<Window.d_gdk_window_get_cursor>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_cursor"));

		// Token: 0x040005B9 RID: 1465
		private static Window.d_gdk_window_set_cursor gdk_window_set_cursor = FuncLoader.LoadFunction<Window.d_gdk_window_set_cursor>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_cursor"));

		// Token: 0x040005BA RID: 1466
		private static Window.MovedToRectNativeDelegate MovedToRect_cb_delegate;

		// Token: 0x040005BB RID: 1467
		private static Window.PickEmbeddedChildNativeDelegate PickEmbeddedChild_cb_delegate;

		// Token: 0x040005BC RID: 1468
		private static Window.ToEmbedderNativeDelegate ToEmbedder_cb_delegate;

		// Token: 0x040005BD RID: 1469
		private static Window.FromEmbedderNativeDelegate FromEmbedder_cb_delegate;

		// Token: 0x040005BE RID: 1470
		private static Window.CreateSurfaceNativeDelegate CreateSurface_cb_delegate;

		// Token: 0x040005BF RID: 1471
		private static AbiStruct _class_abi = null;

		// Token: 0x040005C0 RID: 1472
		private static Window.d_gdk_window_at_pointer gdk_window_at_pointer = FuncLoader.LoadFunction<Window.d_gdk_window_at_pointer>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_at_pointer"));

		// Token: 0x040005C1 RID: 1473
		private static Window.d_gdk_window_beep gdk_window_beep = FuncLoader.LoadFunction<Window.d_gdk_window_beep>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_beep"));

		// Token: 0x040005C2 RID: 1474
		private static Window.d_gdk_window_begin_draw_frame gdk_window_begin_draw_frame = FuncLoader.LoadFunction<Window.d_gdk_window_begin_draw_frame>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_begin_draw_frame"));

		// Token: 0x040005C3 RID: 1475
		private static Window.d_gdk_window_begin_move_drag gdk_window_begin_move_drag = FuncLoader.LoadFunction<Window.d_gdk_window_begin_move_drag>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_begin_move_drag"));

		// Token: 0x040005C4 RID: 1476
		private static Window.d_gdk_window_begin_move_drag_for_device gdk_window_begin_move_drag_for_device = FuncLoader.LoadFunction<Window.d_gdk_window_begin_move_drag_for_device>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_begin_move_drag_for_device"));

		// Token: 0x040005C5 RID: 1477
		private static Window.d_gdk_window_begin_paint_rect gdk_window_begin_paint_rect = FuncLoader.LoadFunction<Window.d_gdk_window_begin_paint_rect>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_begin_paint_rect"));

		// Token: 0x040005C6 RID: 1478
		private static Window.d_gdk_window_begin_paint_region gdk_window_begin_paint_region = FuncLoader.LoadFunction<Window.d_gdk_window_begin_paint_region>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_begin_paint_region"));

		// Token: 0x040005C7 RID: 1479
		private static Window.d_gdk_window_begin_resize_drag gdk_window_begin_resize_drag = FuncLoader.LoadFunction<Window.d_gdk_window_begin_resize_drag>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_begin_resize_drag"));

		// Token: 0x040005C8 RID: 1480
		private static Window.d_gdk_window_begin_resize_drag_for_device gdk_window_begin_resize_drag_for_device = FuncLoader.LoadFunction<Window.d_gdk_window_begin_resize_drag_for_device>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_begin_resize_drag_for_device"));

		// Token: 0x040005C9 RID: 1481
		private static Window.d_gdk_window_configure_finished gdk_window_configure_finished = FuncLoader.LoadFunction<Window.d_gdk_window_configure_finished>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_configure_finished"));

		// Token: 0x040005CA RID: 1482
		private static Window.d_gdk_window_constrain_size gdk_window_constrain_size = FuncLoader.LoadFunction<Window.d_gdk_window_constrain_size>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_constrain_size"));

		// Token: 0x040005CB RID: 1483
		private static Window.d_gdk_window_coords_from_parent gdk_window_coords_from_parent = FuncLoader.LoadFunction<Window.d_gdk_window_coords_from_parent>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_coords_from_parent"));

		// Token: 0x040005CC RID: 1484
		private static Window.d_gdk_window_coords_to_parent gdk_window_coords_to_parent = FuncLoader.LoadFunction<Window.d_gdk_window_coords_to_parent>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_coords_to_parent"));

		// Token: 0x040005CD RID: 1485
		private static Window.d_gdk_window_create_gl_context gdk_window_create_gl_context = FuncLoader.LoadFunction<Window.d_gdk_window_create_gl_context>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_create_gl_context"));

		// Token: 0x040005CE RID: 1486
		private static Window.d_gdk_window_create_similar_surface gdk_window_create_similar_surface = FuncLoader.LoadFunction<Window.d_gdk_window_create_similar_surface>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_create_similar_surface"));

		// Token: 0x040005CF RID: 1487
		private static Window.d_gdk_window_deiconify gdk_window_deiconify = FuncLoader.LoadFunction<Window.d_gdk_window_deiconify>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_deiconify"));

		// Token: 0x040005D0 RID: 1488
		private static Window.d_gdk_window_enable_synchronized_configure gdk_window_enable_synchronized_configure = FuncLoader.LoadFunction<Window.d_gdk_window_enable_synchronized_configure>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_enable_synchronized_configure"));

		// Token: 0x040005D1 RID: 1489
		private static Window.d_gdk_window_end_draw_frame gdk_window_end_draw_frame = FuncLoader.LoadFunction<Window.d_gdk_window_end_draw_frame>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_end_draw_frame"));

		// Token: 0x040005D2 RID: 1490
		private static Window.d_gdk_window_end_paint gdk_window_end_paint = FuncLoader.LoadFunction<Window.d_gdk_window_end_paint>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_end_paint"));

		// Token: 0x040005D3 RID: 1491
		private static Window.d_gdk_window_ensure_native gdk_window_ensure_native = FuncLoader.LoadFunction<Window.d_gdk_window_ensure_native>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_ensure_native"));

		// Token: 0x040005D4 RID: 1492
		private static Window.d_gdk_window_flush gdk_window_flush = FuncLoader.LoadFunction<Window.d_gdk_window_flush>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_flush"));

		// Token: 0x040005D5 RID: 1493
		private static Window.d_gdk_window_focus gdk_window_focus = FuncLoader.LoadFunction<Window.d_gdk_window_focus>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_focus"));

		// Token: 0x040005D6 RID: 1494
		private static Window.d_gdk_window_freeze_updates gdk_window_freeze_updates = FuncLoader.LoadFunction<Window.d_gdk_window_freeze_updates>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_freeze_updates"));

		// Token: 0x040005D7 RID: 1495
		private static Window.d_gdk_window_fullscreen gdk_window_fullscreen = FuncLoader.LoadFunction<Window.d_gdk_window_fullscreen>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_fullscreen"));

		// Token: 0x040005D8 RID: 1496
		private static Window.d_gdk_window_fullscreen_on_monitor gdk_window_fullscreen_on_monitor = FuncLoader.LoadFunction<Window.d_gdk_window_fullscreen_on_monitor>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_fullscreen_on_monitor"));

		// Token: 0x040005D9 RID: 1497
		private static Window.d_gdk_window_geometry_changed gdk_window_geometry_changed = FuncLoader.LoadFunction<Window.d_gdk_window_geometry_changed>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_geometry_changed"));

		// Token: 0x040005DA RID: 1498
		private static Window.d_gdk_window_get_accept_focus gdk_window_get_accept_focus = FuncLoader.LoadFunction<Window.d_gdk_window_get_accept_focus>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_accept_focus"));

		// Token: 0x040005DB RID: 1499
		private static Window.d_gdk_window_set_accept_focus gdk_window_set_accept_focus = FuncLoader.LoadFunction<Window.d_gdk_window_set_accept_focus>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_accept_focus"));

		// Token: 0x040005DC RID: 1500
		private static Window.d_gdk_window_get_children_with_user_data gdk_window_get_children_with_user_data = FuncLoader.LoadFunction<Window.d_gdk_window_get_children_with_user_data>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_children_with_user_data"));

		// Token: 0x040005DD RID: 1501
		private static Window.d_gdk_window_get_clip_region gdk_window_get_clip_region = FuncLoader.LoadFunction<Window.d_gdk_window_get_clip_region>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_clip_region"));

		// Token: 0x040005DE RID: 1502
		private static Window.d_gdk_window_get_composited gdk_window_get_composited = FuncLoader.LoadFunction<Window.d_gdk_window_get_composited>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_composited"));

		// Token: 0x040005DF RID: 1503
		private static Window.d_gdk_window_set_composited gdk_window_set_composited = FuncLoader.LoadFunction<Window.d_gdk_window_set_composited>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_composited"));

		// Token: 0x040005E0 RID: 1504
		private static Window.d_gdk_window_get_decorations gdk_window_get_decorations = FuncLoader.LoadFunction<Window.d_gdk_window_get_decorations>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_decorations"));

		// Token: 0x040005E1 RID: 1505
		private static Window.d_gdk_window_get_device_cursor gdk_window_get_device_cursor = FuncLoader.LoadFunction<Window.d_gdk_window_get_device_cursor>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_device_cursor"));

		// Token: 0x040005E2 RID: 1506
		private static Window.d_gdk_window_get_device_events gdk_window_get_device_events = FuncLoader.LoadFunction<Window.d_gdk_window_get_device_events>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_device_events"));

		// Token: 0x040005E3 RID: 1507
		private static Window.d_gdk_window_get_device_position gdk_window_get_device_position = FuncLoader.LoadFunction<Window.d_gdk_window_get_device_position>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_device_position"));

		// Token: 0x040005E4 RID: 1508
		private static Window.d_gdk_window_get_device_position_double gdk_window_get_device_position_double = FuncLoader.LoadFunction<Window.d_gdk_window_get_device_position_double>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_device_position_double"));

		// Token: 0x040005E5 RID: 1509
		private static Window.d_gdk_window_get_display gdk_window_get_display = FuncLoader.LoadFunction<Window.d_gdk_window_get_display>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_display"));

		// Token: 0x040005E6 RID: 1510
		private static Window.d_gdk_window_get_drag_protocol gdk_window_get_drag_protocol = FuncLoader.LoadFunction<Window.d_gdk_window_get_drag_protocol>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_drag_protocol"));

		// Token: 0x040005E7 RID: 1511
		private static Window.d_gdk_window_get_effective_parent gdk_window_get_effective_parent = FuncLoader.LoadFunction<Window.d_gdk_window_get_effective_parent>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_effective_parent"));

		// Token: 0x040005E8 RID: 1512
		private static Window.d_gdk_window_get_effective_toplevel gdk_window_get_effective_toplevel = FuncLoader.LoadFunction<Window.d_gdk_window_get_effective_toplevel>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_effective_toplevel"));

		// Token: 0x040005E9 RID: 1513
		private static Window.d_gdk_window_get_event_compression gdk_window_get_event_compression = FuncLoader.LoadFunction<Window.d_gdk_window_get_event_compression>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_event_compression"));

		// Token: 0x040005EA RID: 1514
		private static Window.d_gdk_window_set_event_compression gdk_window_set_event_compression = FuncLoader.LoadFunction<Window.d_gdk_window_set_event_compression>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_event_compression"));

		// Token: 0x040005EB RID: 1515
		private static Window.d_gdk_window_get_events gdk_window_get_events = FuncLoader.LoadFunction<Window.d_gdk_window_get_events>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_events"));

		// Token: 0x040005EC RID: 1516
		private static Window.d_gdk_window_set_events gdk_window_set_events = FuncLoader.LoadFunction<Window.d_gdk_window_set_events>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_events"));

		// Token: 0x040005ED RID: 1517
		private static Window.d_gdk_window_get_focus_on_map gdk_window_get_focus_on_map = FuncLoader.LoadFunction<Window.d_gdk_window_get_focus_on_map>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_focus_on_map"));

		// Token: 0x040005EE RID: 1518
		private static Window.d_gdk_window_set_focus_on_map gdk_window_set_focus_on_map = FuncLoader.LoadFunction<Window.d_gdk_window_set_focus_on_map>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_focus_on_map"));

		// Token: 0x040005EF RID: 1519
		private static Window.d_gdk_window_get_frame_clock gdk_window_get_frame_clock = FuncLoader.LoadFunction<Window.d_gdk_window_get_frame_clock>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_frame_clock"));

		// Token: 0x040005F0 RID: 1520
		private static Window.d_gdk_window_get_frame_extents gdk_window_get_frame_extents = FuncLoader.LoadFunction<Window.d_gdk_window_get_frame_extents>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_frame_extents"));

		// Token: 0x040005F1 RID: 1521
		private static Window.d_gdk_window_get_fullscreen_mode gdk_window_get_fullscreen_mode = FuncLoader.LoadFunction<Window.d_gdk_window_get_fullscreen_mode>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_fullscreen_mode"));

		// Token: 0x040005F2 RID: 1522
		private static Window.d_gdk_window_set_fullscreen_mode gdk_window_set_fullscreen_mode = FuncLoader.LoadFunction<Window.d_gdk_window_set_fullscreen_mode>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_fullscreen_mode"));

		// Token: 0x040005F3 RID: 1523
		private static Window.d_gdk_window_get_geometry gdk_window_get_geometry = FuncLoader.LoadFunction<Window.d_gdk_window_get_geometry>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_geometry"));

		// Token: 0x040005F4 RID: 1524
		private static Window.d_gdk_window_get_group gdk_window_get_group = FuncLoader.LoadFunction<Window.d_gdk_window_get_group>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_group"));

		// Token: 0x040005F5 RID: 1525
		private static Window.d_gdk_window_set_group gdk_window_set_group = FuncLoader.LoadFunction<Window.d_gdk_window_set_group>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_group"));

		// Token: 0x040005F6 RID: 1526
		private static Window.d_gdk_window_get_height gdk_window_get_height = FuncLoader.LoadFunction<Window.d_gdk_window_get_height>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_height"));

		// Token: 0x040005F7 RID: 1527
		private static Window.d_gdk_window_get_modal_hint gdk_window_get_modal_hint = FuncLoader.LoadFunction<Window.d_gdk_window_get_modal_hint>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_modal_hint"));

		// Token: 0x040005F8 RID: 1528
		private static Window.d_gdk_window_set_modal_hint gdk_window_set_modal_hint = FuncLoader.LoadFunction<Window.d_gdk_window_set_modal_hint>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_modal_hint"));

		// Token: 0x040005F9 RID: 1529
		private static Window.d_gdk_window_get_origin gdk_window_get_origin = FuncLoader.LoadFunction<Window.d_gdk_window_get_origin>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_origin"));

		// Token: 0x040005FA RID: 1530
		private static Window.d_gdk_window_get_parent gdk_window_get_parent = FuncLoader.LoadFunction<Window.d_gdk_window_get_parent>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_parent"));

		// Token: 0x040005FB RID: 1531
		private static Window.d_gdk_window_get_pass_through gdk_window_get_pass_through = FuncLoader.LoadFunction<Window.d_gdk_window_get_pass_through>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_pass_through"));

		// Token: 0x040005FC RID: 1532
		private static Window.d_gdk_window_set_pass_through gdk_window_set_pass_through = FuncLoader.LoadFunction<Window.d_gdk_window_set_pass_through>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_pass_through"));

		// Token: 0x040005FD RID: 1533
		private static Window.d_gdk_window_get_pointer gdk_window_get_pointer = FuncLoader.LoadFunction<Window.d_gdk_window_get_pointer>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_pointer"));

		// Token: 0x040005FE RID: 1534
		private static Window.d_gdk_window_get_position gdk_window_get_position = FuncLoader.LoadFunction<Window.d_gdk_window_get_position>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_position"));

		// Token: 0x040005FF RID: 1535
		private static Window.d_gdk_window_get_root_coords gdk_window_get_root_coords = FuncLoader.LoadFunction<Window.d_gdk_window_get_root_coords>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_root_coords"));

		// Token: 0x04000600 RID: 1536
		private static Window.d_gdk_window_get_root_origin gdk_window_get_root_origin = FuncLoader.LoadFunction<Window.d_gdk_window_get_root_origin>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_root_origin"));

		// Token: 0x04000601 RID: 1537
		private static Window.d_gdk_window_get_scale_factor gdk_window_get_scale_factor = FuncLoader.LoadFunction<Window.d_gdk_window_get_scale_factor>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_scale_factor"));

		// Token: 0x04000602 RID: 1538
		private static Window.d_gdk_window_get_screen gdk_window_get_screen = FuncLoader.LoadFunction<Window.d_gdk_window_get_screen>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_screen"));

		// Token: 0x04000603 RID: 1539
		private static Window.d_gdk_window_get_source_events gdk_window_get_source_events = FuncLoader.LoadFunction<Window.d_gdk_window_get_source_events>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_source_events"));

		// Token: 0x04000604 RID: 1540
		private static Window.d_gdk_window_get_state gdk_window_get_state = FuncLoader.LoadFunction<Window.d_gdk_window_get_state>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_state"));

		// Token: 0x04000605 RID: 1541
		private static Window.d_gdk_window_get_support_multidevice gdk_window_get_support_multidevice = FuncLoader.LoadFunction<Window.d_gdk_window_get_support_multidevice>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_support_multidevice"));

		// Token: 0x04000606 RID: 1542
		private static Window.d_gdk_window_set_support_multidevice gdk_window_set_support_multidevice = FuncLoader.LoadFunction<Window.d_gdk_window_set_support_multidevice>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_support_multidevice"));

		// Token: 0x04000607 RID: 1543
		private static Window.d_gdk_window_get_toplevel gdk_window_get_toplevel = FuncLoader.LoadFunction<Window.d_gdk_window_get_toplevel>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_toplevel"));

		// Token: 0x04000608 RID: 1544
		private static Window.d_gdk_window_get_type gdk_window_get_type = FuncLoader.LoadFunction<Window.d_gdk_window_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_type"));

		// Token: 0x04000609 RID: 1545
		private static Window.d_gdk_window_get_type_hint gdk_window_get_type_hint = FuncLoader.LoadFunction<Window.d_gdk_window_get_type_hint>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_type_hint"));

		// Token: 0x0400060A RID: 1546
		private static Window.d_gdk_window_set_type_hint gdk_window_set_type_hint = FuncLoader.LoadFunction<Window.d_gdk_window_set_type_hint>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_type_hint"));

		// Token: 0x0400060B RID: 1547
		private static Window.d_gdk_window_get_update_area gdk_window_get_update_area = FuncLoader.LoadFunction<Window.d_gdk_window_get_update_area>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_update_area"));

		// Token: 0x0400060C RID: 1548
		private static Window.d_gdk_window_get_visible_region gdk_window_get_visible_region = FuncLoader.LoadFunction<Window.d_gdk_window_get_visible_region>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_visible_region"));

		// Token: 0x0400060D RID: 1549
		private static Window.d_gdk_window_get_visual gdk_window_get_visual = FuncLoader.LoadFunction<Window.d_gdk_window_get_visual>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_visual"));

		// Token: 0x0400060E RID: 1550
		private static Window.d_gdk_window_get_width gdk_window_get_width = FuncLoader.LoadFunction<Window.d_gdk_window_get_width>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_width"));

		// Token: 0x0400060F RID: 1551
		private static Window.d_gdk_window_get_window_type gdk_window_get_window_type = FuncLoader.LoadFunction<Window.d_gdk_window_get_window_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_window_type"));

		// Token: 0x04000610 RID: 1552
		private static Window.d_gdk_window_has_native gdk_window_has_native = FuncLoader.LoadFunction<Window.d_gdk_window_has_native>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_has_native"));

		// Token: 0x04000611 RID: 1553
		private static Window.d_gdk_window_hide gdk_window_hide = FuncLoader.LoadFunction<Window.d_gdk_window_hide>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_hide"));

		// Token: 0x04000612 RID: 1554
		private static Window.d_gdk_window_iconify gdk_window_iconify = FuncLoader.LoadFunction<Window.d_gdk_window_iconify>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_iconify"));

		// Token: 0x04000613 RID: 1555
		private static Window.d_gdk_window_input_shape_combine_region gdk_window_input_shape_combine_region = FuncLoader.LoadFunction<Window.d_gdk_window_input_shape_combine_region>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_input_shape_combine_region"));

		// Token: 0x04000614 RID: 1556
		private static Window.d_gdk_window_invalidate_maybe_recurse gdk_window_invalidate_maybe_recurse = FuncLoader.LoadFunction<Window.d_gdk_window_invalidate_maybe_recurse>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_invalidate_maybe_recurse"));

		// Token: 0x04000615 RID: 1557
		private static Window.d_gdk_window_invalidate_rect gdk_window_invalidate_rect = FuncLoader.LoadFunction<Window.d_gdk_window_invalidate_rect>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_invalidate_rect"));

		// Token: 0x04000616 RID: 1558
		private static Window.d_gdk_window_invalidate_region gdk_window_invalidate_region = FuncLoader.LoadFunction<Window.d_gdk_window_invalidate_region>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_invalidate_region"));

		// Token: 0x04000617 RID: 1559
		private static Window.d_gdk_window_is_destroyed gdk_window_is_destroyed = FuncLoader.LoadFunction<Window.d_gdk_window_is_destroyed>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_is_destroyed"));

		// Token: 0x04000618 RID: 1560
		private static Window.d_gdk_window_is_input_only gdk_window_is_input_only = FuncLoader.LoadFunction<Window.d_gdk_window_is_input_only>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_is_input_only"));

		// Token: 0x04000619 RID: 1561
		private static Window.d_gdk_window_is_shaped gdk_window_is_shaped = FuncLoader.LoadFunction<Window.d_gdk_window_is_shaped>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_is_shaped"));

		// Token: 0x0400061A RID: 1562
		private static Window.d_gdk_window_is_viewable gdk_window_is_viewable = FuncLoader.LoadFunction<Window.d_gdk_window_is_viewable>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_is_viewable"));

		// Token: 0x0400061B RID: 1563
		private static Window.d_gdk_window_is_visible gdk_window_is_visible = FuncLoader.LoadFunction<Window.d_gdk_window_is_visible>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_is_visible"));

		// Token: 0x0400061C RID: 1564
		private static Window.d_gdk_window_lower gdk_window_lower = FuncLoader.LoadFunction<Window.d_gdk_window_lower>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_lower"));

		// Token: 0x0400061D RID: 1565
		private static Window.d_gdk_window_mark_paint_from_clip gdk_window_mark_paint_from_clip = FuncLoader.LoadFunction<Window.d_gdk_window_mark_paint_from_clip>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_mark_paint_from_clip"));

		// Token: 0x0400061E RID: 1566
		private static Window.d_gdk_window_maximize gdk_window_maximize = FuncLoader.LoadFunction<Window.d_gdk_window_maximize>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_maximize"));

		// Token: 0x0400061F RID: 1567
		private static Window.d_gdk_window_merge_child_input_shapes gdk_window_merge_child_input_shapes = FuncLoader.LoadFunction<Window.d_gdk_window_merge_child_input_shapes>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_merge_child_input_shapes"));

		// Token: 0x04000620 RID: 1568
		private static Window.d_gdk_window_merge_child_shapes gdk_window_merge_child_shapes = FuncLoader.LoadFunction<Window.d_gdk_window_merge_child_shapes>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_merge_child_shapes"));

		// Token: 0x04000621 RID: 1569
		private static Window.d_gdk_window_move gdk_window_move = FuncLoader.LoadFunction<Window.d_gdk_window_move>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_move"));

		// Token: 0x04000622 RID: 1570
		private static Window.d_gdk_window_move_region gdk_window_move_region = FuncLoader.LoadFunction<Window.d_gdk_window_move_region>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_move_region"));

		// Token: 0x04000623 RID: 1571
		private static Window.d_gdk_window_move_resize gdk_window_move_resize = FuncLoader.LoadFunction<Window.d_gdk_window_move_resize>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_move_resize"));

		// Token: 0x04000624 RID: 1572
		private static Window.d_gdk_window_process_all_updates gdk_window_process_all_updates = FuncLoader.LoadFunction<Window.d_gdk_window_process_all_updates>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_process_all_updates"));

		// Token: 0x04000625 RID: 1573
		private static Window.d_gdk_window_process_updates gdk_window_process_updates = FuncLoader.LoadFunction<Window.d_gdk_window_process_updates>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_process_updates"));

		// Token: 0x04000626 RID: 1574
		private static Window.d_gdk_window_raise gdk_window_raise = FuncLoader.LoadFunction<Window.d_gdk_window_raise>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_raise"));

		// Token: 0x04000627 RID: 1575
		private static Window.d_gdk_window_register_dnd gdk_window_register_dnd = FuncLoader.LoadFunction<Window.d_gdk_window_register_dnd>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_register_dnd"));

		// Token: 0x04000628 RID: 1576
		private static Window.d_gdk_window_reparent gdk_window_reparent = FuncLoader.LoadFunction<Window.d_gdk_window_reparent>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_reparent"));

		// Token: 0x04000629 RID: 1577
		private static Window.d_gdk_window_resize gdk_window_resize = FuncLoader.LoadFunction<Window.d_gdk_window_resize>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_resize"));

		// Token: 0x0400062A RID: 1578
		private static Window.d_gdk_window_restack gdk_window_restack = FuncLoader.LoadFunction<Window.d_gdk_window_restack>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_restack"));

		// Token: 0x0400062B RID: 1579
		private static Window.d_gdk_window_scroll gdk_window_scroll = FuncLoader.LoadFunction<Window.d_gdk_window_scroll>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_scroll"));

		// Token: 0x0400062C RID: 1580
		private static Window.d_gdk_window_set_background gdk_window_set_background = FuncLoader.LoadFunction<Window.d_gdk_window_set_background>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_background"));

		// Token: 0x0400062D RID: 1581
		private static Window.d_gdk_window_set_background_rgba gdk_window_set_background_rgba = FuncLoader.LoadFunction<Window.d_gdk_window_set_background_rgba>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_background_rgba"));

		// Token: 0x0400062E RID: 1582
		private static Window.d_gdk_window_set_child_input_shapes gdk_window_set_child_input_shapes = FuncLoader.LoadFunction<Window.d_gdk_window_set_child_input_shapes>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_child_input_shapes"));

		// Token: 0x0400062F RID: 1583
		private static Window.d_gdk_window_set_child_shapes gdk_window_set_child_shapes = FuncLoader.LoadFunction<Window.d_gdk_window_set_child_shapes>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_child_shapes"));

		// Token: 0x04000630 RID: 1584
		private static Window.d_gdk_window_set_debug_updates gdk_window_set_debug_updates = FuncLoader.LoadFunction<Window.d_gdk_window_set_debug_updates>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_debug_updates"));

		// Token: 0x04000631 RID: 1585
		private static Window.d_gdk_window_set_decorations gdk_window_set_decorations = FuncLoader.LoadFunction<Window.d_gdk_window_set_decorations>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_decorations"));

		// Token: 0x04000632 RID: 1586
		private static Window.d_gdk_window_set_device_cursor gdk_window_set_device_cursor = FuncLoader.LoadFunction<Window.d_gdk_window_set_device_cursor>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_device_cursor"));

		// Token: 0x04000633 RID: 1587
		private static Window.d_gdk_window_set_device_events gdk_window_set_device_events = FuncLoader.LoadFunction<Window.d_gdk_window_set_device_events>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_device_events"));

		// Token: 0x04000634 RID: 1588
		private static Window.d_gdk_window_set_functions gdk_window_set_functions = FuncLoader.LoadFunction<Window.d_gdk_window_set_functions>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_functions"));

		// Token: 0x04000635 RID: 1589
		private static Window.d_gdk_window_set_geometry_hints gdk_window_set_geometry_hints = FuncLoader.LoadFunction<Window.d_gdk_window_set_geometry_hints>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_geometry_hints"));

		// Token: 0x04000636 RID: 1590
		private static Window.d_gdk_window_set_icon_name gdk_window_set_icon_name = FuncLoader.LoadFunction<Window.d_gdk_window_set_icon_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_icon_name"));

		// Token: 0x04000637 RID: 1591
		private static Window.d_gdk_window_set_invalidate_handler gdk_window_set_invalidate_handler = FuncLoader.LoadFunction<Window.d_gdk_window_set_invalidate_handler>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_invalidate_handler"));

		// Token: 0x04000638 RID: 1592
		private static Window.d_gdk_window_set_keep_above gdk_window_set_keep_above = FuncLoader.LoadFunction<Window.d_gdk_window_set_keep_above>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_keep_above"));

		// Token: 0x04000639 RID: 1593
		private static Window.d_gdk_window_set_keep_below gdk_window_set_keep_below = FuncLoader.LoadFunction<Window.d_gdk_window_set_keep_below>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_keep_below"));

		// Token: 0x0400063A RID: 1594
		private static Window.d_gdk_window_set_opacity gdk_window_set_opacity = FuncLoader.LoadFunction<Window.d_gdk_window_set_opacity>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_opacity"));

		// Token: 0x0400063B RID: 1595
		private static Window.d_gdk_window_set_opaque_region gdk_window_set_opaque_region = FuncLoader.LoadFunction<Window.d_gdk_window_set_opaque_region>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_opaque_region"));

		// Token: 0x0400063C RID: 1596
		private static Window.d_gdk_window_set_override_redirect gdk_window_set_override_redirect = FuncLoader.LoadFunction<Window.d_gdk_window_set_override_redirect>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_override_redirect"));

		// Token: 0x0400063D RID: 1597
		private static Window.d_gdk_window_set_role gdk_window_set_role = FuncLoader.LoadFunction<Window.d_gdk_window_set_role>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_role"));

		// Token: 0x0400063E RID: 1598
		private static Window.d_gdk_window_set_shadow_width gdk_window_set_shadow_width = FuncLoader.LoadFunction<Window.d_gdk_window_set_shadow_width>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_shadow_width"));

		// Token: 0x0400063F RID: 1599
		private static Window.d_gdk_window_set_skip_pager_hint gdk_window_set_skip_pager_hint = FuncLoader.LoadFunction<Window.d_gdk_window_set_skip_pager_hint>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_skip_pager_hint"));

		// Token: 0x04000640 RID: 1600
		private static Window.d_gdk_window_set_skip_taskbar_hint gdk_window_set_skip_taskbar_hint = FuncLoader.LoadFunction<Window.d_gdk_window_set_skip_taskbar_hint>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_skip_taskbar_hint"));

		// Token: 0x04000641 RID: 1601
		private static Window.d_gdk_window_set_source_events gdk_window_set_source_events = FuncLoader.LoadFunction<Window.d_gdk_window_set_source_events>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_source_events"));

		// Token: 0x04000642 RID: 1602
		private static Window.d_gdk_window_set_startup_id gdk_window_set_startup_id = FuncLoader.LoadFunction<Window.d_gdk_window_set_startup_id>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_startup_id"));

		// Token: 0x04000643 RID: 1603
		private static Window.d_gdk_window_set_static_gravities gdk_window_set_static_gravities = FuncLoader.LoadFunction<Window.d_gdk_window_set_static_gravities>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_static_gravities"));

		// Token: 0x04000644 RID: 1604
		private static Window.d_gdk_window_set_title gdk_window_set_title = FuncLoader.LoadFunction<Window.d_gdk_window_set_title>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_title"));

		// Token: 0x04000645 RID: 1605
		private static Window.d_gdk_window_set_transient_for gdk_window_set_transient_for = FuncLoader.LoadFunction<Window.d_gdk_window_set_transient_for>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_transient_for"));

		// Token: 0x04000646 RID: 1606
		private static Window.d_gdk_window_set_urgency_hint gdk_window_set_urgency_hint = FuncLoader.LoadFunction<Window.d_gdk_window_set_urgency_hint>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_urgency_hint"));

		// Token: 0x04000647 RID: 1607
		private static Window.d_gdk_window_shape_combine_region gdk_window_shape_combine_region = FuncLoader.LoadFunction<Window.d_gdk_window_shape_combine_region>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_shape_combine_region"));

		// Token: 0x04000648 RID: 1608
		private static Window.d_gdk_window_show gdk_window_show = FuncLoader.LoadFunction<Window.d_gdk_window_show>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_show"));

		// Token: 0x04000649 RID: 1609
		private static Window.d_gdk_window_show_unraised gdk_window_show_unraised = FuncLoader.LoadFunction<Window.d_gdk_window_show_unraised>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_show_unraised"));

		// Token: 0x0400064A RID: 1610
		private static Window.d_gdk_window_show_window_menu gdk_window_show_window_menu = FuncLoader.LoadFunction<Window.d_gdk_window_show_window_menu>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_show_window_menu"));

		// Token: 0x0400064B RID: 1611
		private static Window.d_gdk_window_stick gdk_window_stick = FuncLoader.LoadFunction<Window.d_gdk_window_stick>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_stick"));

		// Token: 0x0400064C RID: 1612
		private static Window.d_gdk_window_thaw_updates gdk_window_thaw_updates = FuncLoader.LoadFunction<Window.d_gdk_window_thaw_updates>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_thaw_updates"));

		// Token: 0x0400064D RID: 1613
		private static Window.d_gdk_window_unfullscreen gdk_window_unfullscreen = FuncLoader.LoadFunction<Window.d_gdk_window_unfullscreen>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_unfullscreen"));

		// Token: 0x0400064E RID: 1614
		private static Window.d_gdk_window_unmaximize gdk_window_unmaximize = FuncLoader.LoadFunction<Window.d_gdk_window_unmaximize>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_unmaximize"));

		// Token: 0x0400064F RID: 1615
		private static Window.d_gdk_window_unstick gdk_window_unstick = FuncLoader.LoadFunction<Window.d_gdk_window_unstick>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_unstick"));

		// Token: 0x04000650 RID: 1616
		private static Window.d_gdk_window_withdraw gdk_window_withdraw = FuncLoader.LoadFunction<Window.d_gdk_window_withdraw>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_withdraw"));

		// Token: 0x04000651 RID: 1617
		private static AbiStruct _abi_info = null;

		// Token: 0x04000652 RID: 1618
		private static Window.d_gdk_window_get_background_pattern gdk_window_get_background_pattern = FuncLoader.LoadFunction<Window.d_gdk_window_get_background_pattern>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_background_pattern"));

		// Token: 0x04000653 RID: 1619
		private static Window.d_gdk_window_set_background_pattern gdk_window_set_background_pattern = FuncLoader.LoadFunction<Window.d_gdk_window_set_background_pattern>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_background_pattern"));

		// Token: 0x04000654 RID: 1620
		private static Window.d_gdk_window_get_children gdk_window_get_children = FuncLoader.LoadFunction<Window.d_gdk_window_get_children>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_children"));

		// Token: 0x04000655 RID: 1621
		private static Window.d_gdk_window_set_icon_list gdk_window_set_icon_list = FuncLoader.LoadFunction<Window.d_gdk_window_set_icon_list>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_icon_list"));

		// Token: 0x04000656 RID: 1622
		private static Window.d_g_object_ref g_object_ref = FuncLoader.LoadFunction<Window.d_g_object_ref>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GObject), "g_object_ref"));

		// Token: 0x04000657 RID: 1623
		private static Window.d_gdk_window_destroy gdk_window_destroy = FuncLoader.LoadFunction<Window.d_gdk_window_destroy>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_destroy"));

		// Token: 0x04000658 RID: 1624
		private static Window.d_gdk_window_get_user_data gdk_window_get_user_data = FuncLoader.LoadFunction<Window.d_gdk_window_get_user_data>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_get_user_data"));

		// Token: 0x04000659 RID: 1625
		private static Window.d_gdk_window_set_user_data gdk_window_set_user_data = FuncLoader.LoadFunction<Window.d_gdk_window_set_user_data>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_set_user_data"));

		// Token: 0x0400065A RID: 1626
		private static Window.d_gdk_window_add_filter gdk_window_add_filter = FuncLoader.LoadFunction<Window.d_gdk_window_add_filter>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_add_filter"));

		// Token: 0x0400065B RID: 1627
		private static Window.d_gdk_window_remove_filter gdk_window_remove_filter = FuncLoader.LoadFunction<Window.d_gdk_window_remove_filter>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_remove_filter"));

		// Token: 0x0400065C RID: 1628
		private static IDictionary<FilterFunc, FilterFuncWrapper> filter_all_hash;

		// Token: 0x02000427 RID: 1063
		// (Invoke) Token: 0x0600171E RID: 5918
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_new(IntPtr parent, IntPtr attributes, int attributes_mask);

		// Token: 0x02000428 RID: 1064
		// (Invoke) Token: 0x06001722 RID: 5922
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_cursor(IntPtr raw);

		// Token: 0x02000429 RID: 1065
		// (Invoke) Token: 0x06001726 RID: 5926
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_cursor(IntPtr raw, IntPtr cursor);

		// Token: 0x0200042A RID: 1066
		// (Invoke) Token: 0x0600172A RID: 5930
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ToEmbedderSignalDelegate(IntPtr inst, double arg0, double arg1, out double arg2, out double arg3, IntPtr gch);

		// Token: 0x0200042B RID: 1067
		// (Invoke) Token: 0x0600172E RID: 5934
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void FromEmbedderSignalDelegate(IntPtr inst, double arg0, double arg1, out double arg2, out double arg3, IntPtr gch);

		// Token: 0x0200042C RID: 1068
		// (Invoke) Token: 0x06001732 RID: 5938
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void MovedToRectSignalDelegate(IntPtr inst, IntPtr arg0, IntPtr arg1, bool arg2, bool arg3, IntPtr gch);

		// Token: 0x0200042D RID: 1069
		// (Invoke) Token: 0x06001736 RID: 5942
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void MovedToRectNativeDelegate(IntPtr inst, IntPtr p0, IntPtr p1, bool p2, bool p3);

		// Token: 0x0200042E RID: 1070
		// (Invoke) Token: 0x0600173A RID: 5946
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr PickEmbeddedChildNativeDelegate(IntPtr inst, double x, double y);

		// Token: 0x0200042F RID: 1071
		// (Invoke) Token: 0x0600173E RID: 5950
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ToEmbedderNativeDelegate(IntPtr inst, double offscreen_x, double offscreen_y, out double embedder_x, out double embedder_y);

		// Token: 0x02000430 RID: 1072
		// (Invoke) Token: 0x06001742 RID: 5954
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void FromEmbedderNativeDelegate(IntPtr inst, double embedder_x, double embedder_y, out double offscreen_x, out double offscreen_y);

		// Token: 0x02000431 RID: 1073
		// (Invoke) Token: 0x06001746 RID: 5958
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr CreateSurfaceNativeDelegate(IntPtr inst, int width, int height);

		// Token: 0x02000432 RID: 1074
		// (Invoke) Token: 0x0600174A RID: 5962
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_at_pointer(out int win_x, out int win_y);

		// Token: 0x02000433 RID: 1075
		// (Invoke) Token: 0x0600174E RID: 5966
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_beep(IntPtr raw);

		// Token: 0x02000434 RID: 1076
		// (Invoke) Token: 0x06001752 RID: 5970
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_begin_draw_frame(IntPtr raw, IntPtr region);

		// Token: 0x02000435 RID: 1077
		// (Invoke) Token: 0x06001756 RID: 5974
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_begin_move_drag(IntPtr raw, int button, int root_x, int root_y, uint timestamp);

		// Token: 0x02000436 RID: 1078
		// (Invoke) Token: 0x0600175A RID: 5978
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_begin_move_drag_for_device(IntPtr raw, IntPtr device, int button, int root_x, int root_y, uint timestamp);

		// Token: 0x02000437 RID: 1079
		// (Invoke) Token: 0x0600175E RID: 5982
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_begin_paint_rect(IntPtr raw, IntPtr rectangle);

		// Token: 0x02000438 RID: 1080
		// (Invoke) Token: 0x06001762 RID: 5986
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_begin_paint_region(IntPtr raw, IntPtr region);

		// Token: 0x02000439 RID: 1081
		// (Invoke) Token: 0x06001766 RID: 5990
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_begin_resize_drag(IntPtr raw, int edge, int button, int root_x, int root_y, uint timestamp);

		// Token: 0x0200043A RID: 1082
		// (Invoke) Token: 0x0600176A RID: 5994
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_begin_resize_drag_for_device(IntPtr raw, int edge, IntPtr device, int button, int root_x, int root_y, uint timestamp);

		// Token: 0x0200043B RID: 1083
		// (Invoke) Token: 0x0600176E RID: 5998
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_configure_finished(IntPtr raw);

		// Token: 0x0200043C RID: 1084
		// (Invoke) Token: 0x06001772 RID: 6002
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_constrain_size(IntPtr geometry, int flags, int width, int height, out int new_width, out int new_height);

		// Token: 0x0200043D RID: 1085
		// (Invoke) Token: 0x06001776 RID: 6006
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_coords_from_parent(IntPtr raw, double parent_x, double parent_y, out double x, out double y);

		// Token: 0x0200043E RID: 1086
		// (Invoke) Token: 0x0600177A RID: 6010
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_coords_to_parent(IntPtr raw, double x, double y, out double parent_x, out double parent_y);

		// Token: 0x0200043F RID: 1087
		// (Invoke) Token: 0x0600177E RID: 6014
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_create_gl_context(IntPtr raw, out IntPtr error);

		// Token: 0x02000440 RID: 1088
		// (Invoke) Token: 0x06001782 RID: 6018
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_create_similar_surface(IntPtr raw, int content, int width, int height);

		// Token: 0x02000441 RID: 1089
		// (Invoke) Token: 0x06001786 RID: 6022
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_deiconify(IntPtr raw);

		// Token: 0x02000442 RID: 1090
		// (Invoke) Token: 0x0600178A RID: 6026
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_enable_synchronized_configure(IntPtr raw);

		// Token: 0x02000443 RID: 1091
		// (Invoke) Token: 0x0600178E RID: 6030
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_end_draw_frame(IntPtr raw, IntPtr context);

		// Token: 0x02000444 RID: 1092
		// (Invoke) Token: 0x06001792 RID: 6034
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_end_paint(IntPtr raw);

		// Token: 0x02000445 RID: 1093
		// (Invoke) Token: 0x06001796 RID: 6038
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_window_ensure_native(IntPtr raw);

		// Token: 0x02000446 RID: 1094
		// (Invoke) Token: 0x0600179A RID: 6042
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_flush(IntPtr raw);

		// Token: 0x02000447 RID: 1095
		// (Invoke) Token: 0x0600179E RID: 6046
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_focus(IntPtr raw, uint timestamp);

		// Token: 0x02000448 RID: 1096
		// (Invoke) Token: 0x060017A2 RID: 6050
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_freeze_updates(IntPtr raw);

		// Token: 0x02000449 RID: 1097
		// (Invoke) Token: 0x060017A6 RID: 6054
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_fullscreen(IntPtr raw);

		// Token: 0x0200044A RID: 1098
		// (Invoke) Token: 0x060017AA RID: 6058
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_fullscreen_on_monitor(IntPtr raw, int monitor);

		// Token: 0x0200044B RID: 1099
		// (Invoke) Token: 0x060017AE RID: 6062
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_geometry_changed(IntPtr raw);

		// Token: 0x0200044C RID: 1100
		// (Invoke) Token: 0x060017B2 RID: 6066
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_window_get_accept_focus(IntPtr raw);

		// Token: 0x0200044D RID: 1101
		// (Invoke) Token: 0x060017B6 RID: 6070
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_accept_focus(IntPtr raw, bool accept_focus);

		// Token: 0x0200044E RID: 1102
		// (Invoke) Token: 0x060017BA RID: 6074
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_children_with_user_data(IntPtr raw, IntPtr user_data);

		// Token: 0x0200044F RID: 1103
		// (Invoke) Token: 0x060017BE RID: 6078
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_clip_region(IntPtr raw);

		// Token: 0x02000450 RID: 1104
		// (Invoke) Token: 0x060017C2 RID: 6082
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_window_get_composited(IntPtr raw);

		// Token: 0x02000451 RID: 1105
		// (Invoke) Token: 0x060017C6 RID: 6086
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_composited(IntPtr raw, bool composited);

		// Token: 0x02000452 RID: 1106
		// (Invoke) Token: 0x060017CA RID: 6090
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_window_get_decorations(IntPtr raw, out int decorations);

		// Token: 0x02000453 RID: 1107
		// (Invoke) Token: 0x060017CE RID: 6094
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_device_cursor(IntPtr raw, IntPtr device);

		// Token: 0x02000454 RID: 1108
		// (Invoke) Token: 0x060017D2 RID: 6098
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_window_get_device_events(IntPtr raw, IntPtr device);

		// Token: 0x02000455 RID: 1109
		// (Invoke) Token: 0x060017D6 RID: 6102
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_device_position(IntPtr raw, IntPtr device, out int x, out int y, out int mask);

		// Token: 0x02000456 RID: 1110
		// (Invoke) Token: 0x060017DA RID: 6106
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_device_position_double(IntPtr raw, IntPtr device, out double x, out double y, out int mask);

		// Token: 0x02000457 RID: 1111
		// (Invoke) Token: 0x060017DE RID: 6110
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_display(IntPtr raw);

		// Token: 0x02000458 RID: 1112
		// (Invoke) Token: 0x060017E2 RID: 6114
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_window_get_drag_protocol(IntPtr raw, IntPtr target);

		// Token: 0x02000459 RID: 1113
		// (Invoke) Token: 0x060017E6 RID: 6118
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_effective_parent(IntPtr raw);

		// Token: 0x0200045A RID: 1114
		// (Invoke) Token: 0x060017EA RID: 6122
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_effective_toplevel(IntPtr raw);

		// Token: 0x0200045B RID: 1115
		// (Invoke) Token: 0x060017EE RID: 6126
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_window_get_event_compression(IntPtr raw);

		// Token: 0x0200045C RID: 1116
		// (Invoke) Token: 0x060017F2 RID: 6130
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_event_compression(IntPtr raw, bool event_compression);

		// Token: 0x0200045D RID: 1117
		// (Invoke) Token: 0x060017F6 RID: 6134
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_window_get_events(IntPtr raw);

		// Token: 0x0200045E RID: 1118
		// (Invoke) Token: 0x060017FA RID: 6138
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_events(IntPtr raw, int event_mask);

		// Token: 0x0200045F RID: 1119
		// (Invoke) Token: 0x060017FE RID: 6142
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_window_get_focus_on_map(IntPtr raw);

		// Token: 0x02000460 RID: 1120
		// (Invoke) Token: 0x06001802 RID: 6146
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_focus_on_map(IntPtr raw, bool focus_on_map);

		// Token: 0x02000461 RID: 1121
		// (Invoke) Token: 0x06001806 RID: 6150
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_frame_clock(IntPtr raw);

		// Token: 0x02000462 RID: 1122
		// (Invoke) Token: 0x0600180A RID: 6154
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_get_frame_extents(IntPtr raw, IntPtr rect);

		// Token: 0x02000463 RID: 1123
		// (Invoke) Token: 0x0600180E RID: 6158
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_window_get_fullscreen_mode(IntPtr raw);

		// Token: 0x02000464 RID: 1124
		// (Invoke) Token: 0x06001812 RID: 6162
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_fullscreen_mode(IntPtr raw, int mode);

		// Token: 0x02000465 RID: 1125
		// (Invoke) Token: 0x06001816 RID: 6166
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_get_geometry(IntPtr raw, out int x, out int y, out int width, out int height);

		// Token: 0x02000466 RID: 1126
		// (Invoke) Token: 0x0600181A RID: 6170
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_group(IntPtr raw);

		// Token: 0x02000467 RID: 1127
		// (Invoke) Token: 0x0600181E RID: 6174
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_group(IntPtr raw, IntPtr leader);

		// Token: 0x02000468 RID: 1128
		// (Invoke) Token: 0x06001822 RID: 6178
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_window_get_height(IntPtr raw);

		// Token: 0x02000469 RID: 1129
		// (Invoke) Token: 0x06001826 RID: 6182
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_window_get_modal_hint(IntPtr raw);

		// Token: 0x0200046A RID: 1130
		// (Invoke) Token: 0x0600182A RID: 6186
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_modal_hint(IntPtr raw, bool modal);

		// Token: 0x0200046B RID: 1131
		// (Invoke) Token: 0x0600182E RID: 6190
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_window_get_origin(IntPtr raw, out int x, out int y);

		// Token: 0x0200046C RID: 1132
		// (Invoke) Token: 0x06001832 RID: 6194
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_parent(IntPtr raw);

		// Token: 0x0200046D RID: 1133
		// (Invoke) Token: 0x06001836 RID: 6198
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_window_get_pass_through(IntPtr raw);

		// Token: 0x0200046E RID: 1134
		// (Invoke) Token: 0x0600183A RID: 6202
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_pass_through(IntPtr raw, bool pass_through);

		// Token: 0x0200046F RID: 1135
		// (Invoke) Token: 0x0600183E RID: 6206
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_pointer(IntPtr raw, out int x, out int y, out int mask);

		// Token: 0x02000470 RID: 1136
		// (Invoke) Token: 0x06001842 RID: 6210
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_get_position(IntPtr raw, out int x, out int y);

		// Token: 0x02000471 RID: 1137
		// (Invoke) Token: 0x06001846 RID: 6214
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_get_root_coords(IntPtr raw, int x, int y, out int root_x, out int root_y);

		// Token: 0x02000472 RID: 1138
		// (Invoke) Token: 0x0600184A RID: 6218
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_get_root_origin(IntPtr raw, out int x, out int y);

		// Token: 0x02000473 RID: 1139
		// (Invoke) Token: 0x0600184E RID: 6222
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_window_get_scale_factor(IntPtr raw);

		// Token: 0x02000474 RID: 1140
		// (Invoke) Token: 0x06001852 RID: 6226
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_screen(IntPtr raw);

		// Token: 0x02000475 RID: 1141
		// (Invoke) Token: 0x06001856 RID: 6230
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_window_get_source_events(IntPtr raw, int source);

		// Token: 0x02000476 RID: 1142
		// (Invoke) Token: 0x0600185A RID: 6234
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_window_get_state(IntPtr raw);

		// Token: 0x02000477 RID: 1143
		// (Invoke) Token: 0x0600185E RID: 6238
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_window_get_support_multidevice(IntPtr raw);

		// Token: 0x02000478 RID: 1144
		// (Invoke) Token: 0x06001862 RID: 6242
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_support_multidevice(IntPtr raw, bool support_multidevice);

		// Token: 0x02000479 RID: 1145
		// (Invoke) Token: 0x06001866 RID: 6246
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_toplevel(IntPtr raw);

		// Token: 0x0200047A RID: 1146
		// (Invoke) Token: 0x0600186A RID: 6250
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_type();

		// Token: 0x0200047B RID: 1147
		// (Invoke) Token: 0x0600186E RID: 6254
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_window_get_type_hint(IntPtr raw);

		// Token: 0x0200047C RID: 1148
		// (Invoke) Token: 0x06001872 RID: 6258
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_type_hint(IntPtr raw, int hint);

		// Token: 0x0200047D RID: 1149
		// (Invoke) Token: 0x06001876 RID: 6262
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_update_area(IntPtr raw);

		// Token: 0x0200047E RID: 1150
		// (Invoke) Token: 0x0600187A RID: 6266
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_visible_region(IntPtr raw);

		// Token: 0x0200047F RID: 1151
		// (Invoke) Token: 0x0600187E RID: 6270
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_visual(IntPtr raw);

		// Token: 0x02000480 RID: 1152
		// (Invoke) Token: 0x06001882 RID: 6274
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_window_get_width(IntPtr raw);

		// Token: 0x02000481 RID: 1153
		// (Invoke) Token: 0x06001886 RID: 6278
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_window_get_window_type(IntPtr raw);

		// Token: 0x02000482 RID: 1154
		// (Invoke) Token: 0x0600188A RID: 6282
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_window_has_native(IntPtr raw);

		// Token: 0x02000483 RID: 1155
		// (Invoke) Token: 0x0600188E RID: 6286
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_hide(IntPtr raw);

		// Token: 0x02000484 RID: 1156
		// (Invoke) Token: 0x06001892 RID: 6290
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_iconify(IntPtr raw);

		// Token: 0x02000485 RID: 1157
		// (Invoke) Token: 0x06001896 RID: 6294
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_input_shape_combine_region(IntPtr raw, IntPtr shape_region, int offset_x, int offset_y);

		// Token: 0x02000486 RID: 1158
		// (Invoke) Token: 0x0600189A RID: 6298
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_invalidate_maybe_recurse(IntPtr raw, IntPtr region, WindowChildFuncNative child_func, IntPtr user_data);

		// Token: 0x02000487 RID: 1159
		// (Invoke) Token: 0x0600189E RID: 6302
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_invalidate_rect(IntPtr raw, IntPtr rect, bool invalidate_children);

		// Token: 0x02000488 RID: 1160
		// (Invoke) Token: 0x060018A2 RID: 6306
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_invalidate_region(IntPtr raw, IntPtr region, bool invalidate_children);

		// Token: 0x02000489 RID: 1161
		// (Invoke) Token: 0x060018A6 RID: 6310
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_window_is_destroyed(IntPtr raw);

		// Token: 0x0200048A RID: 1162
		// (Invoke) Token: 0x060018AA RID: 6314
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_window_is_input_only(IntPtr raw);

		// Token: 0x0200048B RID: 1163
		// (Invoke) Token: 0x060018AE RID: 6318
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_window_is_shaped(IntPtr raw);

		// Token: 0x0200048C RID: 1164
		// (Invoke) Token: 0x060018B2 RID: 6322
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_window_is_viewable(IntPtr raw);

		// Token: 0x0200048D RID: 1165
		// (Invoke) Token: 0x060018B6 RID: 6326
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_window_is_visible(IntPtr raw);

		// Token: 0x0200048E RID: 1166
		// (Invoke) Token: 0x060018BA RID: 6330
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_lower(IntPtr raw);

		// Token: 0x0200048F RID: 1167
		// (Invoke) Token: 0x060018BE RID: 6334
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_mark_paint_from_clip(IntPtr raw, IntPtr cr);

		// Token: 0x02000490 RID: 1168
		// (Invoke) Token: 0x060018C2 RID: 6338
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_maximize(IntPtr raw);

		// Token: 0x02000491 RID: 1169
		// (Invoke) Token: 0x060018C6 RID: 6342
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_merge_child_input_shapes(IntPtr raw);

		// Token: 0x02000492 RID: 1170
		// (Invoke) Token: 0x060018CA RID: 6346
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_merge_child_shapes(IntPtr raw);

		// Token: 0x02000493 RID: 1171
		// (Invoke) Token: 0x060018CE RID: 6350
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_move(IntPtr raw, int x, int y);

		// Token: 0x02000494 RID: 1172
		// (Invoke) Token: 0x060018D2 RID: 6354
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_move_region(IntPtr raw, IntPtr region, int dx, int dy);

		// Token: 0x02000495 RID: 1173
		// (Invoke) Token: 0x060018D6 RID: 6358
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_move_resize(IntPtr raw, int x, int y, int width, int height);

		// Token: 0x02000496 RID: 1174
		// (Invoke) Token: 0x060018DA RID: 6362
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_process_all_updates();

		// Token: 0x02000497 RID: 1175
		// (Invoke) Token: 0x060018DE RID: 6366
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_process_updates(IntPtr raw, bool update_children);

		// Token: 0x02000498 RID: 1176
		// (Invoke) Token: 0x060018E2 RID: 6370
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_raise(IntPtr raw);

		// Token: 0x02000499 RID: 1177
		// (Invoke) Token: 0x060018E6 RID: 6374
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_register_dnd(IntPtr raw);

		// Token: 0x0200049A RID: 1178
		// (Invoke) Token: 0x060018EA RID: 6378
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_reparent(IntPtr raw, IntPtr new_parent, int x, int y);

		// Token: 0x0200049B RID: 1179
		// (Invoke) Token: 0x060018EE RID: 6382
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_resize(IntPtr raw, int width, int height);

		// Token: 0x0200049C RID: 1180
		// (Invoke) Token: 0x060018F2 RID: 6386
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_restack(IntPtr raw, IntPtr sibling, bool above);

		// Token: 0x0200049D RID: 1181
		// (Invoke) Token: 0x060018F6 RID: 6390
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_scroll(IntPtr raw, int dx, int dy);

		// Token: 0x0200049E RID: 1182
		// (Invoke) Token: 0x060018FA RID: 6394
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_background(IntPtr raw, IntPtr value);

		// Token: 0x0200049F RID: 1183
		// (Invoke) Token: 0x060018FE RID: 6398
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_background_rgba(IntPtr raw, IntPtr value);

		// Token: 0x020004A0 RID: 1184
		// (Invoke) Token: 0x06001902 RID: 6402
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_child_input_shapes(IntPtr raw);

		// Token: 0x020004A1 RID: 1185
		// (Invoke) Token: 0x06001906 RID: 6406
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_child_shapes(IntPtr raw);

		// Token: 0x020004A2 RID: 1186
		// (Invoke) Token: 0x0600190A RID: 6410
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_debug_updates(bool setting);

		// Token: 0x020004A3 RID: 1187
		// (Invoke) Token: 0x0600190E RID: 6414
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_decorations(IntPtr raw, int decorations);

		// Token: 0x020004A4 RID: 1188
		// (Invoke) Token: 0x06001912 RID: 6418
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_device_cursor(IntPtr raw, IntPtr device, IntPtr cursor);

		// Token: 0x020004A5 RID: 1189
		// (Invoke) Token: 0x06001916 RID: 6422
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_device_events(IntPtr raw, IntPtr device, int event_mask);

		// Token: 0x020004A6 RID: 1190
		// (Invoke) Token: 0x0600191A RID: 6426
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_functions(IntPtr raw, int functions);

		// Token: 0x020004A7 RID: 1191
		// (Invoke) Token: 0x0600191E RID: 6430
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_geometry_hints(IntPtr raw, IntPtr geometry, int geom_mask);

		// Token: 0x020004A8 RID: 1192
		// (Invoke) Token: 0x06001922 RID: 6434
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_icon_name(IntPtr raw, IntPtr name);

		// Token: 0x020004A9 RID: 1193
		// (Invoke) Token: 0x06001926 RID: 6438
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_invalidate_handler(IntPtr raw, WindowInvalidateHandlerFuncNative handler);

		// Token: 0x020004AA RID: 1194
		// (Invoke) Token: 0x0600192A RID: 6442
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_keep_above(IntPtr raw, bool setting);

		// Token: 0x020004AB RID: 1195
		// (Invoke) Token: 0x0600192E RID: 6446
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_keep_below(IntPtr raw, bool setting);

		// Token: 0x020004AC RID: 1196
		// (Invoke) Token: 0x06001932 RID: 6450
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_opacity(IntPtr raw, double opacity);

		// Token: 0x020004AD RID: 1197
		// (Invoke) Token: 0x06001936 RID: 6454
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_opaque_region(IntPtr raw, IntPtr region);

		// Token: 0x020004AE RID: 1198
		// (Invoke) Token: 0x0600193A RID: 6458
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_override_redirect(IntPtr raw, bool override_redirect);

		// Token: 0x020004AF RID: 1199
		// (Invoke) Token: 0x0600193E RID: 6462
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_role(IntPtr raw, IntPtr role);

		// Token: 0x020004B0 RID: 1200
		// (Invoke) Token: 0x06001942 RID: 6466
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_shadow_width(IntPtr raw, int left, int right, int top, int bottom);

		// Token: 0x020004B1 RID: 1201
		// (Invoke) Token: 0x06001946 RID: 6470
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_skip_pager_hint(IntPtr raw, bool skips_pager);

		// Token: 0x020004B2 RID: 1202
		// (Invoke) Token: 0x0600194A RID: 6474
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_skip_taskbar_hint(IntPtr raw, bool skips_taskbar);

		// Token: 0x020004B3 RID: 1203
		// (Invoke) Token: 0x0600194E RID: 6478
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_source_events(IntPtr raw, int source, int event_mask);

		// Token: 0x020004B4 RID: 1204
		// (Invoke) Token: 0x06001952 RID: 6482
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_startup_id(IntPtr raw, IntPtr startup_id);

		// Token: 0x020004B5 RID: 1205
		// (Invoke) Token: 0x06001956 RID: 6486
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_window_set_static_gravities(IntPtr raw, bool use_static);

		// Token: 0x020004B6 RID: 1206
		// (Invoke) Token: 0x0600195A RID: 6490
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_title(IntPtr raw, IntPtr title);

		// Token: 0x020004B7 RID: 1207
		// (Invoke) Token: 0x0600195E RID: 6494
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_transient_for(IntPtr raw, IntPtr parent);

		// Token: 0x020004B8 RID: 1208
		// (Invoke) Token: 0x06001962 RID: 6498
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_urgency_hint(IntPtr raw, bool urgent);

		// Token: 0x020004B9 RID: 1209
		// (Invoke) Token: 0x06001966 RID: 6502
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_shape_combine_region(IntPtr raw, IntPtr shape_region, int offset_x, int offset_y);

		// Token: 0x020004BA RID: 1210
		// (Invoke) Token: 0x0600196A RID: 6506
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_show(IntPtr raw);

		// Token: 0x020004BB RID: 1211
		// (Invoke) Token: 0x0600196E RID: 6510
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_show_unraised(IntPtr raw);

		// Token: 0x020004BC RID: 1212
		// (Invoke) Token: 0x06001972 RID: 6514
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_window_show_window_menu(IntPtr raw, IntPtr evnt);

		// Token: 0x020004BD RID: 1213
		// (Invoke) Token: 0x06001976 RID: 6518
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_stick(IntPtr raw);

		// Token: 0x020004BE RID: 1214
		// (Invoke) Token: 0x0600197A RID: 6522
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_thaw_updates(IntPtr raw);

		// Token: 0x020004BF RID: 1215
		// (Invoke) Token: 0x0600197E RID: 6526
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_unfullscreen(IntPtr raw);

		// Token: 0x020004C0 RID: 1216
		// (Invoke) Token: 0x06001982 RID: 6530
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_unmaximize(IntPtr raw);

		// Token: 0x020004C1 RID: 1217
		// (Invoke) Token: 0x06001986 RID: 6534
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_unstick(IntPtr raw);

		// Token: 0x020004C2 RID: 1218
		// (Invoke) Token: 0x0600198A RID: 6538
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_withdraw(IntPtr raw);

		// Token: 0x020004C3 RID: 1219
		// (Invoke) Token: 0x0600198E RID: 6542
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_background_pattern(IntPtr raw);

		// Token: 0x020004C4 RID: 1220
		// (Invoke) Token: 0x06001992 RID: 6546
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_background_pattern(IntPtr raw, IntPtr pattern);

		// Token: 0x020004C5 RID: 1221
		// (Invoke) Token: 0x06001996 RID: 6550
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_get_children(IntPtr raw);

		// Token: 0x020004C6 RID: 1222
		// (Invoke) Token: 0x0600199A RID: 6554
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_icon_list(IntPtr raw, IntPtr pixbufs);

		// Token: 0x020004C7 RID: 1223
		// (Invoke) Token: 0x0600199E RID: 6558
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_g_object_ref(IntPtr raw);

		// Token: 0x020004C8 RID: 1224
		// (Invoke) Token: 0x060019A2 RID: 6562
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_destroy(IntPtr raw);

		// Token: 0x020004C9 RID: 1225
		// (Invoke) Token: 0x060019A6 RID: 6566
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_get_user_data(IntPtr raw, out IntPtr data);

		// Token: 0x020004CA RID: 1226
		// (Invoke) Token: 0x060019AA RID: 6570
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_set_user_data(IntPtr raw, IntPtr user_data);

		// Token: 0x020004CB RID: 1227
		// (Invoke) Token: 0x060019AE RID: 6574
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_add_filter(IntPtr handle, FilterFuncNative wrapper, IntPtr data);

		// Token: 0x020004CC RID: 1228
		// (Invoke) Token: 0x060019B2 RID: 6578
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_window_remove_filter(IntPtr handle, FilterFuncNative wrapper, IntPtr data);
	}
}
