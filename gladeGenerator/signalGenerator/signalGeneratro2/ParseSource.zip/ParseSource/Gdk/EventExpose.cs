﻿using System;
using System.Runtime.InteropServices;
using Cairo;

namespace Gdk
{
	// Token: 0x0200002A RID: 42
	public class EventExpose : Event
	{
		// Token: 0x060002F2 RID: 754 RVA: 0x0000A65D File Offset: 0x0000885D
		public EventExpose(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x060002F3 RID: 755 RVA: 0x0000A666 File Offset: 0x00008866
		private EventExpose.NativeStruct Native
		{
			get
			{
				return (EventExpose.NativeStruct)Marshal.PtrToStructure(base.Handle, typeof(EventExpose.NativeStruct));
			}
		}

		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x060002F4 RID: 756 RVA: 0x0000A682 File Offset: 0x00008882
		// (set) Token: 0x060002F5 RID: 757 RVA: 0x0000A690 File Offset: 0x00008890
		public Rectangle Area
		{
			get
			{
				return this.Native.area;
			}
			set
			{
				EventExpose.NativeStruct native = this.Native;
				native.area = value;
				Marshal.StructureToPtr<EventExpose.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x060002F6 RID: 758 RVA: 0x0000A6B9 File Offset: 0x000088B9
		// (set) Token: 0x060002F7 RID: 759 RVA: 0x0000A6CC File Offset: 0x000088CC
		public Region Region
		{
			get
			{
				return new Region(this.Native.region);
			}
			set
			{
				EventExpose.NativeStruct native = this.Native;
				native.region = ((value == null) ? IntPtr.Zero : value.Handle);
				Marshal.StructureToPtr<EventExpose.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x060002F8 RID: 760 RVA: 0x0000A704 File Offset: 0x00008904
		// (set) Token: 0x060002F9 RID: 761 RVA: 0x0000A714 File Offset: 0x00008914
		public int Count
		{
			get
			{
				return this.Native.count;
			}
			set
			{
				EventExpose.NativeStruct native = this.Native;
				native.count = value;
				Marshal.StructureToPtr<EventExpose.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x020001DD RID: 477
		private struct NativeStruct
		{
			// Token: 0x04000C36 RID: 3126
			private EventType type;

			// Token: 0x04000C37 RID: 3127
			private IntPtr window;

			// Token: 0x04000C38 RID: 3128
			private sbyte send_event;

			// Token: 0x04000C39 RID: 3129
			public Rectangle area;

			// Token: 0x04000C3A RID: 3130
			public IntPtr region;

			// Token: 0x04000C3B RID: 3131
			public int count;
		}
	}
}
