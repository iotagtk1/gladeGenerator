﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x0200005D RID: 93
	[GType(typeof(DevicePadFeatureGType))]
	public enum DevicePadFeature
	{
		// Token: 0x040001C5 RID: 453
		Button,
		// Token: 0x040001C6 RID: 454
		Ring,
		// Token: 0x040001C7 RID: 455
		Strip
	}
}
