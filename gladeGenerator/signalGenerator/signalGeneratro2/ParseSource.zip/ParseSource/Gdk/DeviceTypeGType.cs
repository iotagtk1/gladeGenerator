﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000065 RID: 101
	internal class DeviceTypeGType
	{
		// Token: 0x17000124 RID: 292
		// (get) Token: 0x06000444 RID: 1092 RVA: 0x0000D262 File Offset: 0x0000B462
		public static GType GType
		{
			get
			{
				return new GType(DeviceTypeGType.gdk_device_type_get_type());
			}
		}

		// Token: 0x040001DD RID: 477
		private static DeviceTypeGType.d_gdk_device_type_get_type gdk_device_type_get_type = FuncLoader.LoadFunction<DeviceTypeGType.d_gdk_device_type_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_type_get_type"));

		// Token: 0x02000229 RID: 553
		// (Invoke) Token: 0x06000F2B RID: 3883
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_type_get_type();
	}
}
