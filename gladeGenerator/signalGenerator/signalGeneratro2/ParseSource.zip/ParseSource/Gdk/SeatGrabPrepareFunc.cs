﻿using System;

namespace Gdk
{
	// Token: 0x020000F5 RID: 245
	// (Invoke) Token: 0x060009F2 RID: 2546
	public delegate void SeatGrabPrepareFunc(Seat seat, Window window);
}
