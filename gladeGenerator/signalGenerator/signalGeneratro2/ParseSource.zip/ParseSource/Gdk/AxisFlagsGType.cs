﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000041 RID: 65
	internal class AxisFlagsGType
	{
		// Token: 0x170000F4 RID: 244
		// (get) Token: 0x06000394 RID: 916 RVA: 0x0000B881 File Offset: 0x00009A81
		public static GType GType
		{
			get
			{
				return new GType(AxisFlagsGType.gdk_axis_flags_get_type());
			}
		}

		// Token: 0x04000122 RID: 290
		private static AxisFlagsGType.d_gdk_axis_flags_get_type gdk_axis_flags_get_type = FuncLoader.LoadFunction<AxisFlagsGType.d_gdk_axis_flags_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_axis_flags_get_type"));

		// Token: 0x020001F3 RID: 499
		// (Invoke) Token: 0x06000E57 RID: 3671
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_axis_flags_get_type();
	}
}
