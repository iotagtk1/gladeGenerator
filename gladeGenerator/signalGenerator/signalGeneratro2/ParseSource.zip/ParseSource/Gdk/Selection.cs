﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000F8 RID: 248
	public class Selection
	{
		// Token: 0x060009FB RID: 2555 RVA: 0x0001D7D1 File Offset: 0x0001B9D1
		public static void Convert(Window requestor, Atom selection, Atom target, uint time_)
		{
			Selection.gdk_selection_convert((requestor == null) ? IntPtr.Zero : requestor.Handle, (selection == null) ? IntPtr.Zero : selection.Handle, (target == null) ? IntPtr.Zero : target.Handle, time_);
		}

		// Token: 0x060009FC RID: 2556 RVA: 0x0001D80E File Offset: 0x0001BA0E
		public static Window OwnerGet(Atom selection)
		{
			return Object.GetObject(Selection.gdk_selection_owner_get((selection == null) ? IntPtr.Zero : selection.Handle)) as Window;
		}

		// Token: 0x060009FD RID: 2557 RVA: 0x0001D834 File Offset: 0x0001BA34
		public static Window OwnerGetForDisplay(Display display, Atom selection)
		{
			return Object.GetObject(Selection.gdk_selection_owner_get_for_display((display == null) ? IntPtr.Zero : display.Handle, (selection == null) ? IntPtr.Zero : selection.Handle)) as Window;
		}

		// Token: 0x060009FE RID: 2558 RVA: 0x0001D86A File Offset: 0x0001BA6A
		public static bool OwnerSet(Window owner, Atom selection, uint time_, bool send_event)
		{
			return Selection.gdk_selection_owner_set((owner == null) ? IntPtr.Zero : owner.Handle, (selection == null) ? IntPtr.Zero : selection.Handle, time_, send_event);
		}

		// Token: 0x060009FF RID: 2559 RVA: 0x0001D898 File Offset: 0x0001BA98
		public static bool OwnerSetForDisplay(Display display, Window owner, Atom selection, uint time_, bool send_event)
		{
			return Selection.gdk_selection_owner_set_for_display((display == null) ? IntPtr.Zero : display.Handle, (owner == null) ? IntPtr.Zero : owner.Handle, (selection == null) ? IntPtr.Zero : selection.Handle, time_, send_event);
		}

		// Token: 0x06000A00 RID: 2560 RVA: 0x0001D8D8 File Offset: 0x0001BAD8
		public static void SendNotify(Window requestor, Atom selection, Atom target, Atom property, uint time_)
		{
			Selection.gdk_selection_send_notify((requestor == null) ? IntPtr.Zero : requestor.Handle, (selection == null) ? IntPtr.Zero : selection.Handle, (target == null) ? IntPtr.Zero : target.Handle, (property == null) ? IntPtr.Zero : property.Handle, time_);
		}

		// Token: 0x06000A01 RID: 2561 RVA: 0x0001D934 File Offset: 0x0001BB34
		public static void SendNotifyForDisplay(Display display, Window requestor, Atom selection, Atom target, Atom property, uint time_)
		{
			Selection.gdk_selection_send_notify_for_display((display == null) ? IntPtr.Zero : display.Handle, (requestor == null) ? IntPtr.Zero : requestor.Handle, (selection == null) ? IntPtr.Zero : selection.Handle, (target == null) ? IntPtr.Zero : target.Handle, (property == null) ? IntPtr.Zero : property.Handle, time_);
		}

		// Token: 0x04000563 RID: 1379
		private static Selection.d_gdk_selection_convert gdk_selection_convert = FuncLoader.LoadFunction<Selection.d_gdk_selection_convert>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_selection_convert"));

		// Token: 0x04000564 RID: 1380
		private static Selection.d_gdk_selection_owner_get gdk_selection_owner_get = FuncLoader.LoadFunction<Selection.d_gdk_selection_owner_get>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_selection_owner_get"));

		// Token: 0x04000565 RID: 1381
		private static Selection.d_gdk_selection_owner_get_for_display gdk_selection_owner_get_for_display = FuncLoader.LoadFunction<Selection.d_gdk_selection_owner_get_for_display>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_selection_owner_get_for_display"));

		// Token: 0x04000566 RID: 1382
		private static Selection.d_gdk_selection_owner_set gdk_selection_owner_set = FuncLoader.LoadFunction<Selection.d_gdk_selection_owner_set>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_selection_owner_set"));

		// Token: 0x04000567 RID: 1383
		private static Selection.d_gdk_selection_owner_set_for_display gdk_selection_owner_set_for_display = FuncLoader.LoadFunction<Selection.d_gdk_selection_owner_set_for_display>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_selection_owner_set_for_display"));

		// Token: 0x04000568 RID: 1384
		private static Selection.d_gdk_selection_send_notify gdk_selection_send_notify = FuncLoader.LoadFunction<Selection.d_gdk_selection_send_notify>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_selection_send_notify"));

		// Token: 0x04000569 RID: 1385
		private static Selection.d_gdk_selection_send_notify_for_display gdk_selection_send_notify_for_display = FuncLoader.LoadFunction<Selection.d_gdk_selection_send_notify_for_display>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_selection_send_notify_for_display"));

		// Token: 0x0400056A RID: 1386
		public static Atom Primary = new Atom(new IntPtr(1));

		// Token: 0x0400056B RID: 1387
		public static Atom Secondary = new Atom(new IntPtr(2));

		// Token: 0x0400056C RID: 1388
		public static Atom Clipboard = new Atom(new IntPtr(69));

		// Token: 0x02000403 RID: 1027
		// (Invoke) Token: 0x0600168E RID: 5774
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_selection_convert(IntPtr requestor, IntPtr selection, IntPtr target, uint time_);

		// Token: 0x02000404 RID: 1028
		// (Invoke) Token: 0x06001692 RID: 5778
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_selection_owner_get(IntPtr selection);

		// Token: 0x02000405 RID: 1029
		// (Invoke) Token: 0x06001696 RID: 5782
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_selection_owner_get_for_display(IntPtr display, IntPtr selection);

		// Token: 0x02000406 RID: 1030
		// (Invoke) Token: 0x0600169A RID: 5786
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_selection_owner_set(IntPtr owner, IntPtr selection, uint time_, bool send_event);

		// Token: 0x02000407 RID: 1031
		// (Invoke) Token: 0x0600169E RID: 5790
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_selection_owner_set_for_display(IntPtr display, IntPtr owner, IntPtr selection, uint time_, bool send_event);

		// Token: 0x02000408 RID: 1032
		// (Invoke) Token: 0x060016A2 RID: 5794
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_selection_send_notify(IntPtr requestor, IntPtr selection, IntPtr target, IntPtr property, uint time_);

		// Token: 0x02000409 RID: 1033
		// (Invoke) Token: 0x060016A6 RID: 5798
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_selection_send_notify_for_display(IntPtr display, IntPtr requestor, IntPtr selection, IntPtr target, IntPtr property, uint time_);
	}
}
