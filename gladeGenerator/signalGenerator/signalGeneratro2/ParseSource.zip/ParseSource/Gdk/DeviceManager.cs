﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200005B RID: 91
	public class DeviceManager : Object
	{
		// Token: 0x060003ED RID: 1005 RVA: 0x0000C474 File Offset: 0x0000A674
		public DeviceManager(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x060003EE RID: 1006 RVA: 0x0000C47D File Offset: 0x0000A67D
		protected DeviceManager() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x1700010A RID: 266
		// (get) Token: 0x060003EF RID: 1007 RVA: 0x0000C49C File Offset: 0x0000A69C
		[Property("display")]
		public Display Display
		{
			get
			{
				return Object.GetObject(DeviceManager.gdk_device_manager_get_display(base.Handle)) as Display;
			}
		}

		// Token: 0x1400000A RID: 10
		// (add) Token: 0x060003F0 RID: 1008 RVA: 0x0000C4B8 File Offset: 0x0000A6B8
		// (remove) Token: 0x060003F1 RID: 1009 RVA: 0x0000C4D0 File Offset: 0x0000A6D0
		[Signal("device-added")]
		public event DeviceAddedHandler DeviceAdded
		{
			add
			{
				base.AddSignalHandler("device-added", value, typeof(DeviceAddedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("device-added", value);
			}
		}

		// Token: 0x1400000B RID: 11
		// (add) Token: 0x060003F2 RID: 1010 RVA: 0x0000C4DE File Offset: 0x0000A6DE
		// (remove) Token: 0x060003F3 RID: 1011 RVA: 0x0000C4F6 File Offset: 0x0000A6F6
		[Signal("device-changed")]
		public event DeviceChangedHandler DeviceChanged
		{
			add
			{
				base.AddSignalHandler("device-changed", value, typeof(DeviceChangedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("device-changed", value);
			}
		}

		// Token: 0x1400000C RID: 12
		// (add) Token: 0x060003F4 RID: 1012 RVA: 0x0000C504 File Offset: 0x0000A704
		// (remove) Token: 0x060003F5 RID: 1013 RVA: 0x0000C51C File Offset: 0x0000A71C
		[Signal("device-removed")]
		public event DeviceRemovedHandler DeviceRemoved
		{
			add
			{
				base.AddSignalHandler("device-removed", value, typeof(DeviceRemovedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("device-removed", value);
			}
		}

		// Token: 0x1700010B RID: 267
		// (get) Token: 0x060003F6 RID: 1014 RVA: 0x0000C52A File Offset: 0x0000A72A
		private static DeviceManager.DeviceAddedNativeDelegate DeviceAddedVMCallback
		{
			get
			{
				if (DeviceManager.DeviceAdded_cb_delegate == null)
				{
					DeviceManager.DeviceAdded_cb_delegate = new DeviceManager.DeviceAddedNativeDelegate(DeviceManager.DeviceAdded_cb);
				}
				return DeviceManager.DeviceAdded_cb_delegate;
			}
		}

		// Token: 0x060003F7 RID: 1015 RVA: 0x0000C549 File Offset: 0x0000A749
		private static void OverrideDeviceAdded(GType gtype)
		{
			DeviceManager.OverrideDeviceAdded(gtype, DeviceManager.DeviceAddedVMCallback);
		}

		// Token: 0x060003F8 RID: 1016 RVA: 0x0000C558 File Offset: 0x0000A758
		private unsafe static void OverrideDeviceAdded(GType gtype, DeviceManager.DeviceAddedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DeviceManager.class_abi.GetFieldOffset("device_added");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060003F9 RID: 1017 RVA: 0x0000C58C File Offset: 0x0000A78C
		private static void DeviceAdded_cb(IntPtr inst, IntPtr device)
		{
			try
			{
				(Object.GetObject(inst, false) as DeviceManager).OnDeviceAdded(Object.GetObject(device) as Device);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060003FA RID: 1018 RVA: 0x0000C5D0 File Offset: 0x0000A7D0
		[DefaultSignalHandler(Type = typeof(DeviceManager), ConnectionMethod = "OverrideDeviceAdded")]
		protected virtual void OnDeviceAdded(Device device)
		{
			this.InternalDeviceAdded(device);
		}

		// Token: 0x060003FB RID: 1019 RVA: 0x0000C5DC File Offset: 0x0000A7DC
		private void InternalDeviceAdded(Device device)
		{
			DeviceManager.DeviceAddedNativeDelegate deviceAddedNativeDelegate = DeviceManager.class_abi.BaseOverride(base.LookupGType(), "device_added");
			if (deviceAddedNativeDelegate == null)
			{
				return;
			}
			deviceAddedNativeDelegate(base.Handle, (device == null) ? IntPtr.Zero : device.Handle);
		}

		// Token: 0x1700010C RID: 268
		// (get) Token: 0x060003FC RID: 1020 RVA: 0x0000C61F File Offset: 0x0000A81F
		private static DeviceManager.DeviceRemovedNativeDelegate DeviceRemovedVMCallback
		{
			get
			{
				if (DeviceManager.DeviceRemoved_cb_delegate == null)
				{
					DeviceManager.DeviceRemoved_cb_delegate = new DeviceManager.DeviceRemovedNativeDelegate(DeviceManager.DeviceRemoved_cb);
				}
				return DeviceManager.DeviceRemoved_cb_delegate;
			}
		}

		// Token: 0x060003FD RID: 1021 RVA: 0x0000C63E File Offset: 0x0000A83E
		private static void OverrideDeviceRemoved(GType gtype)
		{
			DeviceManager.OverrideDeviceRemoved(gtype, DeviceManager.DeviceRemovedVMCallback);
		}

		// Token: 0x060003FE RID: 1022 RVA: 0x0000C64C File Offset: 0x0000A84C
		private unsafe static void OverrideDeviceRemoved(GType gtype, DeviceManager.DeviceRemovedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DeviceManager.class_abi.GetFieldOffset("device_removed");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060003FF RID: 1023 RVA: 0x0000C680 File Offset: 0x0000A880
		private static void DeviceRemoved_cb(IntPtr inst, IntPtr device)
		{
			try
			{
				(Object.GetObject(inst, false) as DeviceManager).OnDeviceRemoved(Object.GetObject(device) as Device);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000400 RID: 1024 RVA: 0x0000C6C4 File Offset: 0x0000A8C4
		[DefaultSignalHandler(Type = typeof(DeviceManager), ConnectionMethod = "OverrideDeviceRemoved")]
		protected virtual void OnDeviceRemoved(Device device)
		{
			this.InternalDeviceRemoved(device);
		}

		// Token: 0x06000401 RID: 1025 RVA: 0x0000C6D0 File Offset: 0x0000A8D0
		private void InternalDeviceRemoved(Device device)
		{
			DeviceManager.DeviceRemovedNativeDelegate deviceRemovedNativeDelegate = DeviceManager.class_abi.BaseOverride(base.LookupGType(), "device_removed");
			if (deviceRemovedNativeDelegate == null)
			{
				return;
			}
			deviceRemovedNativeDelegate(base.Handle, (device == null) ? IntPtr.Zero : device.Handle);
		}

		// Token: 0x1700010D RID: 269
		// (get) Token: 0x06000402 RID: 1026 RVA: 0x0000C713 File Offset: 0x0000A913
		private static DeviceManager.DeviceChangedNativeDelegate DeviceChangedVMCallback
		{
			get
			{
				if (DeviceManager.DeviceChanged_cb_delegate == null)
				{
					DeviceManager.DeviceChanged_cb_delegate = new DeviceManager.DeviceChangedNativeDelegate(DeviceManager.DeviceChanged_cb);
				}
				return DeviceManager.DeviceChanged_cb_delegate;
			}
		}

		// Token: 0x06000403 RID: 1027 RVA: 0x0000C732 File Offset: 0x0000A932
		private static void OverrideDeviceChanged(GType gtype)
		{
			DeviceManager.OverrideDeviceChanged(gtype, DeviceManager.DeviceChangedVMCallback);
		}

		// Token: 0x06000404 RID: 1028 RVA: 0x0000C740 File Offset: 0x0000A940
		private unsafe static void OverrideDeviceChanged(GType gtype, DeviceManager.DeviceChangedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DeviceManager.class_abi.GetFieldOffset("device_changed");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000405 RID: 1029 RVA: 0x0000C774 File Offset: 0x0000A974
		private static void DeviceChanged_cb(IntPtr inst, IntPtr device)
		{
			try
			{
				(Object.GetObject(inst, false) as DeviceManager).OnDeviceChanged(Object.GetObject(device) as Device);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000406 RID: 1030 RVA: 0x0000C7B8 File Offset: 0x0000A9B8
		[DefaultSignalHandler(Type = typeof(DeviceManager), ConnectionMethod = "OverrideDeviceChanged")]
		protected virtual void OnDeviceChanged(Device device)
		{
			this.InternalDeviceChanged(device);
		}

		// Token: 0x06000407 RID: 1031 RVA: 0x0000C7C4 File Offset: 0x0000A9C4
		private void InternalDeviceChanged(Device device)
		{
			DeviceManager.DeviceChangedNativeDelegate deviceChangedNativeDelegate = DeviceManager.class_abi.BaseOverride(base.LookupGType(), "device_changed");
			if (deviceChangedNativeDelegate == null)
			{
				return;
			}
			deviceChangedNativeDelegate(base.Handle, (device == null) ? IntPtr.Zero : device.Handle);
		}

		// Token: 0x1700010E RID: 270
		// (get) Token: 0x06000408 RID: 1032 RVA: 0x0000C807 File Offset: 0x0000AA07
		private static DeviceManager.ListDevicesNativeDelegate ListDevicesVMCallback
		{
			get
			{
				if (DeviceManager.ListDevices_cb_delegate == null)
				{
					DeviceManager.ListDevices_cb_delegate = new DeviceManager.ListDevicesNativeDelegate(DeviceManager.ListDevices_cb);
				}
				return DeviceManager.ListDevices_cb_delegate;
			}
		}

		// Token: 0x06000409 RID: 1033 RVA: 0x0000C826 File Offset: 0x0000AA26
		private static void OverrideListDevices(GType gtype)
		{
			DeviceManager.OverrideListDevices(gtype, DeviceManager.ListDevicesVMCallback);
		}

		// Token: 0x0600040A RID: 1034 RVA: 0x0000C834 File Offset: 0x0000AA34
		private unsafe static void OverrideListDevices(GType gtype, DeviceManager.ListDevicesNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DeviceManager.class_abi.GetFieldOffset("list_devices");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600040B RID: 1035 RVA: 0x0000C868 File Offset: 0x0000AA68
		private static IntPtr ListDevices_cb(IntPtr inst, int type)
		{
			IntPtr result;
			try
			{
				Device[] array = (Object.GetObject(inst, false) as DeviceManager).OnListDevices((DeviceType)type);
				object[] elements = array;
				IntPtr intPtr;
				if (new List(elements, typeof(Device), true, false) != null)
				{
					elements = array;
					intPtr = new List(elements, typeof(Device), true, false).Handle;
				}
				else
				{
					intPtr = IntPtr.Zero;
				}
				result = intPtr;
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600040C RID: 1036 RVA: 0x0000C8DC File Offset: 0x0000AADC
		[DefaultSignalHandler(Type = typeof(DeviceManager), ConnectionMethod = "OverrideListDevices")]
		protected virtual Device[] OnListDevices(DeviceType type)
		{
			return this.InternalListDevices(type);
		}

		// Token: 0x0600040D RID: 1037 RVA: 0x0000C8E8 File Offset: 0x0000AAE8
		private Device[] InternalListDevices(DeviceType type)
		{
			DeviceManager.ListDevicesNativeDelegate listDevicesNativeDelegate = DeviceManager.class_abi.BaseOverride(base.LookupGType(), "list_devices");
			if (listDevicesNativeDelegate == null)
			{
				return null;
			}
			return (Device[])Marshaller.ListPtrToArray(listDevicesNativeDelegate(base.Handle, (int)type), typeof(List), true, false, typeof(Device));
		}

		// Token: 0x1700010F RID: 271
		// (get) Token: 0x0600040E RID: 1038 RVA: 0x0000C93D File Offset: 0x0000AB3D
		private static DeviceManager.GetClientPointerNativeDelegate GetClientPointerVMCallback
		{
			get
			{
				if (DeviceManager.GetClientPointer_cb_delegate == null)
				{
					DeviceManager.GetClientPointer_cb_delegate = new DeviceManager.GetClientPointerNativeDelegate(DeviceManager.GetClientPointer_cb);
				}
				return DeviceManager.GetClientPointer_cb_delegate;
			}
		}

		// Token: 0x0600040F RID: 1039 RVA: 0x0000C95C File Offset: 0x0000AB5C
		private static void OverrideGetClientPointer(GType gtype)
		{
			DeviceManager.OverrideGetClientPointer(gtype, DeviceManager.GetClientPointerVMCallback);
		}

		// Token: 0x06000410 RID: 1040 RVA: 0x0000C96C File Offset: 0x0000AB6C
		private unsafe static void OverrideGetClientPointer(GType gtype, DeviceManager.GetClientPointerNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DeviceManager.class_abi.GetFieldOffset("get_client_pointer");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000411 RID: 1041 RVA: 0x0000C9A0 File Offset: 0x0000ABA0
		private static IntPtr GetClientPointer_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				Device device = (Object.GetObject(inst, false) as DeviceManager).OnGetClientPointer();
				result = ((device == null) ? IntPtr.Zero : device.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000412 RID: 1042 RVA: 0x0000C9EC File Offset: 0x0000ABEC
		[DefaultSignalHandler(Type = typeof(DeviceManager), ConnectionMethod = "OverrideGetClientPointer")]
		protected virtual Device OnGetClientPointer()
		{
			return this.InternalGetClientPointer();
		}

		// Token: 0x06000413 RID: 1043 RVA: 0x0000C9F4 File Offset: 0x0000ABF4
		private Device InternalGetClientPointer()
		{
			DeviceManager.GetClientPointerNativeDelegate getClientPointerNativeDelegate = DeviceManager.class_abi.BaseOverride(base.LookupGType(), "get_client_pointer");
			if (getClientPointerNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getClientPointerNativeDelegate(base.Handle)) as Device;
		}

		// Token: 0x17000110 RID: 272
		// (get) Token: 0x06000414 RID: 1044 RVA: 0x0000CA34 File Offset: 0x0000AC34
		public new static AbiStruct class_abi
		{
			get
			{
				if (DeviceManager._class_abi == null)
				{
					DeviceManager._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("device_added", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "device_removed", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("device_removed", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "device_added", "device_changed", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("device_changed", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "device_removed", "list_devices", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("list_devices", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "device_changed", "get_client_pointer", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_client_pointer", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "list_devices", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return DeviceManager._class_abi;
			}
		}

		// Token: 0x17000111 RID: 273
		// (get) Token: 0x06000415 RID: 1045 RVA: 0x0000CB8B File Offset: 0x0000AD8B
		[Obsolete]
		public Device ClientPointer
		{
			get
			{
				return Object.GetObject(DeviceManager.gdk_device_manager_get_client_pointer(base.Handle)) as Device;
			}
		}

		// Token: 0x17000112 RID: 274
		// (get) Token: 0x06000416 RID: 1046 RVA: 0x0000CBA8 File Offset: 0x0000ADA8
		public new static GType GType
		{
			get
			{
				IntPtr val = DeviceManager.gdk_device_manager_get_type();
				return new GType(val);
			}
		}

		// Token: 0x06000417 RID: 1047 RVA: 0x0000CBC6 File Offset: 0x0000ADC6
		[Obsolete]
		public Device[] ListDevices(DeviceType type)
		{
			return (Device[])Marshaller.ListPtrToArray(DeviceManager.gdk_device_manager_list_devices(base.Handle, (int)type), typeof(List), true, false, typeof(Device));
		}

		// Token: 0x17000113 RID: 275
		// (get) Token: 0x06000418 RID: 1048 RVA: 0x0000CBF9 File Offset: 0x0000ADF9
		public new static AbiStruct abi_info
		{
			get
			{
				if (DeviceManager._abi_info == null)
				{
					DeviceManager._abi_info = new AbiStruct(Object.abi_info.Fields);
				}
				return DeviceManager._abi_info;
			}
		}

		// Token: 0x040001B0 RID: 432
		private static DeviceManager.d_gdk_device_manager_get_display gdk_device_manager_get_display = FuncLoader.LoadFunction<DeviceManager.d_gdk_device_manager_get_display>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_manager_get_display"));

		// Token: 0x040001B1 RID: 433
		private static DeviceManager.DeviceAddedNativeDelegate DeviceAdded_cb_delegate;

		// Token: 0x040001B2 RID: 434
		private static DeviceManager.DeviceRemovedNativeDelegate DeviceRemoved_cb_delegate;

		// Token: 0x040001B3 RID: 435
		private static DeviceManager.DeviceChangedNativeDelegate DeviceChanged_cb_delegate;

		// Token: 0x040001B4 RID: 436
		private static DeviceManager.ListDevicesNativeDelegate ListDevices_cb_delegate;

		// Token: 0x040001B5 RID: 437
		private static DeviceManager.GetClientPointerNativeDelegate GetClientPointer_cb_delegate;

		// Token: 0x040001B6 RID: 438
		private static AbiStruct _class_abi = null;

		// Token: 0x040001B7 RID: 439
		private static DeviceManager.d_gdk_device_manager_get_client_pointer gdk_device_manager_get_client_pointer = FuncLoader.LoadFunction<DeviceManager.d_gdk_device_manager_get_client_pointer>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_manager_get_client_pointer"));

		// Token: 0x040001B8 RID: 440
		private static DeviceManager.d_gdk_device_manager_get_type gdk_device_manager_get_type = FuncLoader.LoadFunction<DeviceManager.d_gdk_device_manager_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_manager_get_type"));

		// Token: 0x040001B9 RID: 441
		private static DeviceManager.d_gdk_device_manager_list_devices gdk_device_manager_list_devices = FuncLoader.LoadFunction<DeviceManager.d_gdk_device_manager_list_devices>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_manager_list_devices"));

		// Token: 0x040001BA RID: 442
		private static AbiStruct _abi_info = null;

		// Token: 0x02000210 RID: 528
		// (Invoke) Token: 0x06000ECB RID: 3787
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_manager_get_display(IntPtr raw);

		// Token: 0x02000211 RID: 529
		// (Invoke) Token: 0x06000ECF RID: 3791
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DeviceAddedNativeDelegate(IntPtr inst, IntPtr device);

		// Token: 0x02000212 RID: 530
		// (Invoke) Token: 0x06000ED3 RID: 3795
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DeviceRemovedNativeDelegate(IntPtr inst, IntPtr device);

		// Token: 0x02000213 RID: 531
		// (Invoke) Token: 0x06000ED7 RID: 3799
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DeviceChangedNativeDelegate(IntPtr inst, IntPtr device);

		// Token: 0x02000214 RID: 532
		// (Invoke) Token: 0x06000EDB RID: 3803
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr ListDevicesNativeDelegate(IntPtr inst, int type);

		// Token: 0x02000215 RID: 533
		// (Invoke) Token: 0x06000EDF RID: 3807
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetClientPointerNativeDelegate(IntPtr inst);

		// Token: 0x02000216 RID: 534
		// (Invoke) Token: 0x06000EE3 RID: 3811
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_manager_get_client_pointer(IntPtr raw);

		// Token: 0x02000217 RID: 535
		// (Invoke) Token: 0x06000EE7 RID: 3815
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_manager_get_type();

		// Token: 0x02000218 RID: 536
		// (Invoke) Token: 0x06000EEB RID: 3819
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_manager_list_devices(IntPtr raw, int type);
	}
}
