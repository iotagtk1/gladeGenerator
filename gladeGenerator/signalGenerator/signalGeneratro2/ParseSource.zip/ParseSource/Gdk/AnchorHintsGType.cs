﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200003A RID: 58
	internal class AnchorHintsGType
	{
		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x06000379 RID: 889 RVA: 0x0000B560 File Offset: 0x00009760
		public static GType GType
		{
			get
			{
				return new GType(AnchorHintsGType.gdk_anchor_hints_get_type());
			}
		}

		// Token: 0x0400010D RID: 269
		private static AnchorHintsGType.d_gdk_anchor_hints_get_type gdk_anchor_hints_get_type = FuncLoader.LoadFunction<AnchorHintsGType.d_gdk_anchor_hints_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_anchor_hints_get_type"));

		// Token: 0x020001EA RID: 490
		// (Invoke) Token: 0x06000E33 RID: 3635
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_anchor_hints_get_type();
	}
}
