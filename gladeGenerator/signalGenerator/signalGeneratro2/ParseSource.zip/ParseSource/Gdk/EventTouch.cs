﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200007F RID: 127
	public struct EventTouch : IEquatable<EventTouch>
	{
		// Token: 0x1700015B RID: 347
		// (get) Token: 0x0600055C RID: 1372 RVA: 0x000102CE File Offset: 0x0000E4CE
		// (set) Token: 0x0600055D RID: 1373 RVA: 0x000102E0 File Offset: 0x0000E4E0
		public Window Window
		{
			get
			{
				return Object.GetObject(this._window) as Window;
			}
			set
			{
				this._window = ((value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x1700015C RID: 348
		// (get) Token: 0x0600055E RID: 1374 RVA: 0x000102F8 File Offset: 0x0000E4F8
		// (set) Token: 0x0600055F RID: 1375 RVA: 0x00010329 File Offset: 0x0000E529
		public EventSequence Sequence
		{
			get
			{
				if (!(this._sequence == IntPtr.Zero))
				{
					return (EventSequence)Opaque.GetOpaque(this._sequence, typeof(EventSequence), false);
				}
				return null;
			}
			set
			{
				this._sequence = ((value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x1700015D RID: 349
		// (get) Token: 0x06000560 RID: 1376 RVA: 0x00010341 File Offset: 0x0000E541
		// (set) Token: 0x06000561 RID: 1377 RVA: 0x00010353 File Offset: 0x0000E553
		public Device Device
		{
			get
			{
				return Object.GetObject(this._device) as Device;
			}
			set
			{
				this._device = ((value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x06000562 RID: 1378 RVA: 0x0001036B File Offset: 0x0000E56B
		public static EventTouch New(IntPtr raw)
		{
			if (raw == IntPtr.Zero)
			{
				return EventTouch.Zero;
			}
			return (EventTouch)Marshal.PtrToStructure(raw, typeof(EventTouch));
		}

		// Token: 0x06000563 RID: 1379 RVA: 0x00010398 File Offset: 0x0000E598
		public bool Equals(EventTouch other)
		{
			return this.Type.Equals(other.Type) && this.Window.Equals(other.Window) && this.SendEvent.Equals(other.SendEvent) && this.Time.Equals(other.Time) && this.X.Equals(other.X) && this.Y.Equals(other.Y) && this._axes.Equals(other._axes) && this.State.Equals(other.State) && this.Sequence.Equals(other.Sequence) && this.EmulatingPointer.Equals(other.EmulatingPointer) && this.Device.Equals(other.Device) && this.XRoot.Equals(other.XRoot) && this.YRoot.Equals(other.YRoot);
		}

		// Token: 0x06000564 RID: 1380 RVA: 0x000104C1 File Offset: 0x0000E6C1
		public override bool Equals(object other)
		{
			return other is EventTouch && this.Equals((EventTouch)other);
		}

		// Token: 0x06000565 RID: 1381 RVA: 0x000104DC File Offset: 0x0000E6DC
		public override int GetHashCode()
		{
			return base.GetType().FullName.GetHashCode() ^ this.Type.GetHashCode() ^ this.Window.GetHashCode() ^ this.SendEvent.GetHashCode() ^ this.Time.GetHashCode() ^ this.X.GetHashCode() ^ this.Y.GetHashCode() ^ this._axes.GetHashCode() ^ this.State.GetHashCode() ^ this.Sequence.GetHashCode() ^ this.EmulatingPointer.GetHashCode() ^ this.Device.GetHashCode() ^ this.XRoot.GetHashCode() ^ this.YRoot.GetHashCode();
		}

		// Token: 0x1700015E RID: 350
		// (get) Token: 0x06000566 RID: 1382 RVA: 0x000105A5 File Offset: 0x0000E7A5
		private static GType GType
		{
			get
			{
				return GType.Pointer;
			}
		}

		// Token: 0x0400028B RID: 651
		public EventType Type;

		// Token: 0x0400028C RID: 652
		private IntPtr _window;

		// Token: 0x0400028D RID: 653
		public sbyte SendEvent;

		// Token: 0x0400028E RID: 654
		public uint Time;

		// Token: 0x0400028F RID: 655
		public double X;

		// Token: 0x04000290 RID: 656
		public double Y;

		// Token: 0x04000291 RID: 657
		private IntPtr _axes;

		// Token: 0x04000292 RID: 658
		public uint State;

		// Token: 0x04000293 RID: 659
		private IntPtr _sequence;

		// Token: 0x04000294 RID: 660
		public bool EmulatingPointer;

		// Token: 0x04000295 RID: 661
		private IntPtr _device;

		// Token: 0x04000296 RID: 662
		public double XRoot;

		// Token: 0x04000297 RID: 663
		public double YRoot;

		// Token: 0x04000298 RID: 664
		public static EventTouch Zero;
	}
}
