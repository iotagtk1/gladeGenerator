﻿using System;
using System.Runtime.InteropServices;

namespace Gdk
{
	// Token: 0x0200007D RID: 125
	public class Events
	{
		// Token: 0x06000552 RID: 1362 RVA: 0x00010152 File Offset: 0x0000E352
		public static bool GetAngle(Event event1, Event event2, out double angle)
		{
			return Events.gdk_events_get_angle((event1 == null) ? IntPtr.Zero : event1.Handle, (event2 == null) ? IntPtr.Zero : event2.Handle, out angle);
		}

		// Token: 0x06000553 RID: 1363 RVA: 0x0001017F File Offset: 0x0000E37F
		public static bool GetCenter(Event event1, Event event2, out double x, out double y)
		{
			return Events.gdk_events_get_center((event1 == null) ? IntPtr.Zero : event1.Handle, (event2 == null) ? IntPtr.Zero : event2.Handle, out x, out y);
		}

		// Token: 0x06000554 RID: 1364 RVA: 0x000101AD File Offset: 0x0000E3AD
		public static bool GetDistance(Event event1, Event event2, out double distance)
		{
			return Events.gdk_events_get_distance((event1 == null) ? IntPtr.Zero : event1.Handle, (event2 == null) ? IntPtr.Zero : event2.Handle, out distance);
		}

		// Token: 0x06000555 RID: 1365 RVA: 0x000101DA File Offset: 0x0000E3DA
		public static bool Pending()
		{
			return Events.gdk_events_pending();
		}

		// Token: 0x04000285 RID: 645
		private static Events.d_gdk_events_get_angle gdk_events_get_angle = FuncLoader.LoadFunction<Events.d_gdk_events_get_angle>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_events_get_angle"));

		// Token: 0x04000286 RID: 646
		private static Events.d_gdk_events_get_center gdk_events_get_center = FuncLoader.LoadFunction<Events.d_gdk_events_get_center>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_events_get_center"));

		// Token: 0x04000287 RID: 647
		private static Events.d_gdk_events_get_distance gdk_events_get_distance = FuncLoader.LoadFunction<Events.d_gdk_events_get_distance>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_events_get_distance"));

		// Token: 0x04000288 RID: 648
		private static Events.d_gdk_events_pending gdk_events_pending = FuncLoader.LoadFunction<Events.d_gdk_events_pending>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_events_pending"));

		// Token: 0x02000285 RID: 645
		// (Invoke) Token: 0x0600109B RID: 4251
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_events_get_angle(IntPtr event1, IntPtr event2, out double angle);

		// Token: 0x02000286 RID: 646
		// (Invoke) Token: 0x0600109F RID: 4255
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_events_get_center(IntPtr event1, IntPtr event2, out double x, out double y);

		// Token: 0x02000287 RID: 647
		// (Invoke) Token: 0x060010A3 RID: 4259
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_events_get_distance(IntPtr event1, IntPtr event2, out double distance);

		// Token: 0x02000288 RID: 648
		// (Invoke) Token: 0x060010A7 RID: 4263
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_events_pending();
	}
}
