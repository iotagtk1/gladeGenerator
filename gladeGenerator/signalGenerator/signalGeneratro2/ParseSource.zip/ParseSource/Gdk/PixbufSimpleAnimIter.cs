﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000DD RID: 221
	public class PixbufSimpleAnimIter : Opaque
	{
		// Token: 0x1700022F RID: 559
		// (get) Token: 0x0600086D RID: 2157 RVA: 0x00018E7C File Offset: 0x0001707C
		public static GType GType
		{
			get
			{
				IntPtr val = PixbufSimpleAnimIter.gdk_pixbuf_simple_anim_iter_get_type();
				return new GType(val);
			}
		}

		// Token: 0x0600086E RID: 2158 RVA: 0x00018E9A File Offset: 0x0001709A
		public PixbufSimpleAnimIter(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000230 RID: 560
		// (get) Token: 0x0600086F RID: 2159 RVA: 0x00018EA3 File Offset: 0x000170A3
		public static AbiStruct abi_info
		{
			get
			{
				if (PixbufSimpleAnimIter._abi_info == null)
				{
					PixbufSimpleAnimIter._abi_info = new AbiStruct(new List<AbiField>());
				}
				return PixbufSimpleAnimIter._abi_info;
			}
		}

		// Token: 0x040004BE RID: 1214
		private static PixbufSimpleAnimIter.d_gdk_pixbuf_simple_anim_iter_get_type gdk_pixbuf_simple_anim_iter_get_type = FuncLoader.LoadFunction<PixbufSimpleAnimIter.d_gdk_pixbuf_simple_anim_iter_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_simple_anim_iter_get_type"));

		// Token: 0x040004BF RID: 1215
		private static AbiStruct _abi_info = null;

		// Token: 0x0200039E RID: 926
		// (Invoke) Token: 0x060014FA RID: 5370
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_simple_anim_iter_get_type();
	}
}
