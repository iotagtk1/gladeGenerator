﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000B9 RID: 185
	[GType(typeof(NotifyTypeGType))]
	public enum NotifyType
	{
		// Token: 0x04000403 RID: 1027
		Ancestor,
		// Token: 0x04000404 RID: 1028
		Virtual,
		// Token: 0x04000405 RID: 1029
		Inferior,
		// Token: 0x04000406 RID: 1030
		Nonlinear,
		// Token: 0x04000407 RID: 1031
		NonlinearVirtual,
		// Token: 0x04000408 RID: 1032
		Unknown
	}
}
