﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x02000107 RID: 263
	public class ThreadsDispatch : Opaque
	{
		// Token: 0x06000A26 RID: 2598 RVA: 0x0001DDCD File Offset: 0x0001BFCD
		public ThreadsDispatch(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700028F RID: 655
		// (get) Token: 0x06000A27 RID: 2599 RVA: 0x0001DDD6 File Offset: 0x0001BFD6
		public static AbiStruct abi_info
		{
			get
			{
				if (ThreadsDispatch._abi_info == null)
				{
					ThreadsDispatch._abi_info = new AbiStruct(new List<AbiField>());
				}
				return ThreadsDispatch._abi_info;
			}
		}

		// Token: 0x0400058C RID: 1420
		private static AbiStruct _abi_info;
	}
}
