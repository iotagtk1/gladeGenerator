﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x020000BC RID: 188
	public class OffscreenWindowClass : Opaque
	{
		// Token: 0x06000755 RID: 1877 RVA: 0x0001525D File Offset: 0x0001345D
		public OffscreenWindowClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170001E7 RID: 487
		// (get) Token: 0x06000756 RID: 1878 RVA: 0x00015266 File Offset: 0x00013466
		public static AbiStruct abi_info
		{
			get
			{
				if (OffscreenWindowClass._abi_info == null)
				{
					OffscreenWindowClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return OffscreenWindowClass._abi_info;
			}
		}

		// Token: 0x0400040E RID: 1038
		private static AbiStruct _abi_info;
	}
}
