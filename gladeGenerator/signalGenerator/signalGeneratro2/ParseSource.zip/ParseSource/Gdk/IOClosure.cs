﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x020000A8 RID: 168
	public class IOClosure : Opaque
	{
		// Token: 0x0600067D RID: 1661 RVA: 0x0001309F File Offset: 0x0001129F
		public IOClosure(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170001B1 RID: 433
		// (get) Token: 0x0600067E RID: 1662 RVA: 0x000130A8 File Offset: 0x000112A8
		public static AbiStruct abi_info
		{
			get
			{
				if (IOClosure._abi_info == null)
				{
					IOClosure._abi_info = new AbiStruct(new List<AbiField>());
				}
				return IOClosure._abi_info;
			}
		}

		// Token: 0x04000394 RID: 916
		private static AbiStruct _abi_info;
	}
}
