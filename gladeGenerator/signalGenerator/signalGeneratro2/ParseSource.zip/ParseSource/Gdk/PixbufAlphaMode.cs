﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000C3 RID: 195
	[GType(typeof(PixbufAlphaModeGType))]
	public enum PixbufAlphaMode
	{
		// Token: 0x0400045D RID: 1117
		Bilevel,
		// Token: 0x0400045E RID: 1118
		Full
	}
}
