﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x0200004E RID: 78
	[GType(typeof(ColorspaceGType))]
	public enum Colorspace
	{
		// Token: 0x04000144 RID: 324
		Rgb
	}
}
