﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x020000D6 RID: 214
	public class PixbufNonAnimIterClass : Opaque
	{
		// Token: 0x06000859 RID: 2137 RVA: 0x00018C73 File Offset: 0x00016E73
		public PixbufNonAnimIterClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000229 RID: 553
		// (get) Token: 0x0600085A RID: 2138 RVA: 0x00018C7C File Offset: 0x00016E7C
		public static AbiStruct abi_info
		{
			get
			{
				if (PixbufNonAnimIterClass._abi_info == null)
				{
					PixbufNonAnimIterClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return PixbufNonAnimIterClass._abi_info;
			}
		}

		// Token: 0x040004B0 RID: 1200
		private static AbiStruct _abi_info;
	}
}
