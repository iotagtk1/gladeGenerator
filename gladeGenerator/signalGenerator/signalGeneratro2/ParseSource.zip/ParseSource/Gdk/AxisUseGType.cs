﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000044 RID: 68
	internal class AxisUseGType
	{
		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x06000399 RID: 921 RVA: 0x0000B8DC File Offset: 0x00009ADC
		public static GType GType
		{
			get
			{
				return new GType(AxisUseGType.gdk_axis_use_get_type());
			}
		}

		// Token: 0x04000130 RID: 304
		private static AxisUseGType.d_gdk_axis_use_get_type gdk_axis_use_get_type = FuncLoader.LoadFunction<AxisUseGType.d_gdk_axis_use_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_axis_use_get_type"));

		// Token: 0x020001F4 RID: 500
		// (Invoke) Token: 0x06000E5B RID: 3675
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_axis_use_get_type();
	}
}
