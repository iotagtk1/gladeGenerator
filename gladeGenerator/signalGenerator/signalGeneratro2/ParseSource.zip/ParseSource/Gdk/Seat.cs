﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GdkSharp;
using GLib;

namespace Gdk
{
	// Token: 0x020000EE RID: 238
	public class Seat : Object
	{
		// Token: 0x060009A1 RID: 2465 RVA: 0x0001C95E File Offset: 0x0001AB5E
		public Seat(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x060009A2 RID: 2466 RVA: 0x0001C967 File Offset: 0x0001AB67
		protected Seat() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x17000270 RID: 624
		// (get) Token: 0x060009A3 RID: 2467 RVA: 0x0001C986 File Offset: 0x0001AB86
		private static Seat.DeviceAddedNativeDelegate DeviceAddedVMCallback
		{
			get
			{
				if (Seat.DeviceAdded_cb_delegate == null)
				{
					Seat.DeviceAdded_cb_delegate = new Seat.DeviceAddedNativeDelegate(Seat.DeviceAdded_cb);
				}
				return Seat.DeviceAdded_cb_delegate;
			}
		}

		// Token: 0x060009A4 RID: 2468 RVA: 0x0001C9A5 File Offset: 0x0001ABA5
		private static void OverrideDeviceAdded(GType gtype)
		{
			Seat.OverrideDeviceAdded(gtype, Seat.DeviceAddedVMCallback);
		}

		// Token: 0x060009A5 RID: 2469 RVA: 0x0001C9B4 File Offset: 0x0001ABB4
		private unsafe static void OverrideDeviceAdded(GType gtype, Seat.DeviceAddedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Seat.class_abi.GetFieldOffset("device_added");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060009A6 RID: 2470 RVA: 0x0001C9E8 File Offset: 0x0001ABE8
		private static void DeviceAdded_cb(IntPtr inst, IntPtr device)
		{
			try
			{
				(Object.GetObject(inst, false) as Seat).OnDeviceAdded(Object.GetObject(device) as Device);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060009A7 RID: 2471 RVA: 0x0001CA2C File Offset: 0x0001AC2C
		[DefaultSignalHandler(Type = typeof(Seat), ConnectionMethod = "OverrideDeviceAdded")]
		protected virtual void OnDeviceAdded(Device device)
		{
			this.InternalDeviceAdded(device);
		}

		// Token: 0x060009A8 RID: 2472 RVA: 0x0001CA38 File Offset: 0x0001AC38
		private void InternalDeviceAdded(Device device)
		{
			Seat.DeviceAddedNativeDelegate deviceAddedNativeDelegate = Seat.class_abi.BaseOverride(base.LookupGType(), "device_added");
			if (deviceAddedNativeDelegate == null)
			{
				return;
			}
			deviceAddedNativeDelegate(base.Handle, (device == null) ? IntPtr.Zero : device.Handle);
		}

		// Token: 0x17000271 RID: 625
		// (get) Token: 0x060009A9 RID: 2473 RVA: 0x0001CA7B File Offset: 0x0001AC7B
		private static Seat.DeviceRemovedNativeDelegate DeviceRemovedVMCallback
		{
			get
			{
				if (Seat.DeviceRemoved_cb_delegate == null)
				{
					Seat.DeviceRemoved_cb_delegate = new Seat.DeviceRemovedNativeDelegate(Seat.DeviceRemoved_cb);
				}
				return Seat.DeviceRemoved_cb_delegate;
			}
		}

		// Token: 0x060009AA RID: 2474 RVA: 0x0001CA9A File Offset: 0x0001AC9A
		private static void OverrideDeviceRemoved(GType gtype)
		{
			Seat.OverrideDeviceRemoved(gtype, Seat.DeviceRemovedVMCallback);
		}

		// Token: 0x060009AB RID: 2475 RVA: 0x0001CAA8 File Offset: 0x0001ACA8
		private unsafe static void OverrideDeviceRemoved(GType gtype, Seat.DeviceRemovedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Seat.class_abi.GetFieldOffset("device_removed");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060009AC RID: 2476 RVA: 0x0001CADC File Offset: 0x0001ACDC
		private static void DeviceRemoved_cb(IntPtr inst, IntPtr device)
		{
			try
			{
				(Object.GetObject(inst, false) as Seat).OnDeviceRemoved(Object.GetObject(device) as Device);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060009AD RID: 2477 RVA: 0x0001CB20 File Offset: 0x0001AD20
		[DefaultSignalHandler(Type = typeof(Seat), ConnectionMethod = "OverrideDeviceRemoved")]
		protected virtual void OnDeviceRemoved(Device device)
		{
			this.InternalDeviceRemoved(device);
		}

		// Token: 0x060009AE RID: 2478 RVA: 0x0001CB2C File Offset: 0x0001AD2C
		private void InternalDeviceRemoved(Device device)
		{
			Seat.DeviceRemovedNativeDelegate deviceRemovedNativeDelegate = Seat.class_abi.BaseOverride(base.LookupGType(), "device_removed");
			if (deviceRemovedNativeDelegate == null)
			{
				return;
			}
			deviceRemovedNativeDelegate(base.Handle, (device == null) ? IntPtr.Zero : device.Handle);
		}

		// Token: 0x17000272 RID: 626
		// (get) Token: 0x060009AF RID: 2479 RVA: 0x0001CB6F File Offset: 0x0001AD6F
		private static Seat.DeviceChangedNativeDelegate DeviceChangedVMCallback
		{
			get
			{
				if (Seat.DeviceChanged_cb_delegate == null)
				{
					Seat.DeviceChanged_cb_delegate = new Seat.DeviceChangedNativeDelegate(Seat.DeviceChanged_cb);
				}
				return Seat.DeviceChanged_cb_delegate;
			}
		}

		// Token: 0x060009B0 RID: 2480 RVA: 0x0001CB8E File Offset: 0x0001AD8E
		private static void OverrideDeviceChanged(GType gtype)
		{
			Seat.OverrideDeviceChanged(gtype, Seat.DeviceChangedVMCallback);
		}

		// Token: 0x060009B1 RID: 2481 RVA: 0x0001CB9C File Offset: 0x0001AD9C
		private unsafe static void OverrideDeviceChanged(GType gtype, Seat.DeviceChangedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Seat.class_abi.GetFieldOffset("device_changed");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060009B2 RID: 2482 RVA: 0x0001CBD0 File Offset: 0x0001ADD0
		private static void DeviceChanged_cb(IntPtr inst, IntPtr device)
		{
			try
			{
				(Object.GetObject(inst, false) as Seat).OnDeviceChanged(Object.GetObject(device) as Device);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060009B3 RID: 2483 RVA: 0x0001CC14 File Offset: 0x0001AE14
		[DefaultSignalHandler(Type = typeof(Seat), ConnectionMethod = "OverrideDeviceChanged")]
		protected virtual void OnDeviceChanged(Device device)
		{
			this.InternalDeviceChanged(device);
		}

		// Token: 0x060009B4 RID: 2484 RVA: 0x0001CC20 File Offset: 0x0001AE20
		private void InternalDeviceChanged(Device device)
		{
			Seat.DeviceChangedNativeDelegate deviceChangedNativeDelegate = Seat.class_abi.BaseOverride(base.LookupGType(), "device_changed");
			if (deviceChangedNativeDelegate == null)
			{
				return;
			}
			deviceChangedNativeDelegate(base.Handle, (device == null) ? IntPtr.Zero : device.Handle);
		}

		// Token: 0x17000273 RID: 627
		// (get) Token: 0x060009B5 RID: 2485 RVA: 0x0001CC63 File Offset: 0x0001AE63
		private static Seat.GetCapabilitiesNativeDelegate GetCapabilitiesVMCallback
		{
			get
			{
				if (Seat.GetCapabilities_cb_delegate == null)
				{
					Seat.GetCapabilities_cb_delegate = new Seat.GetCapabilitiesNativeDelegate(Seat.GetCapabilities_cb);
				}
				return Seat.GetCapabilities_cb_delegate;
			}
		}

		// Token: 0x060009B6 RID: 2486 RVA: 0x0001CC82 File Offset: 0x0001AE82
		private static void OverrideGetCapabilities(GType gtype)
		{
			Seat.OverrideGetCapabilities(gtype, Seat.GetCapabilitiesVMCallback);
		}

		// Token: 0x060009B7 RID: 2487 RVA: 0x0001CC90 File Offset: 0x0001AE90
		private unsafe static void OverrideGetCapabilities(GType gtype, Seat.GetCapabilitiesNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Seat.class_abi.GetFieldOffset("get_capabilities");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060009B8 RID: 2488 RVA: 0x0001CCC4 File Offset: 0x0001AEC4
		private static int GetCapabilities_cb(IntPtr inst)
		{
			int result;
			try
			{
				result = (int)(Object.GetObject(inst, false) as Seat).OnGetCapabilities();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060009B9 RID: 2489 RVA: 0x0001CD00 File Offset: 0x0001AF00
		[DefaultSignalHandler(Type = typeof(Seat), ConnectionMethod = "OverrideGetCapabilities")]
		protected virtual SeatCapabilities OnGetCapabilities()
		{
			return this.InternalGetCapabilities();
		}

		// Token: 0x060009BA RID: 2490 RVA: 0x0001CD08 File Offset: 0x0001AF08
		private SeatCapabilities InternalGetCapabilities()
		{
			Seat.GetCapabilitiesNativeDelegate getCapabilitiesNativeDelegate = Seat.class_abi.BaseOverride(base.LookupGType(), "get_capabilities");
			if (getCapabilitiesNativeDelegate == null)
			{
				return SeatCapabilities.None;
			}
			return (SeatCapabilities)getCapabilitiesNativeDelegate(base.Handle);
		}

		// Token: 0x17000274 RID: 628
		// (get) Token: 0x060009BB RID: 2491 RVA: 0x0001CD3C File Offset: 0x0001AF3C
		private static Seat.GrabNativeDelegate GrabVMCallback
		{
			get
			{
				if (Seat.Grab_cb_delegate == null)
				{
					Seat.Grab_cb_delegate = new Seat.GrabNativeDelegate(Seat.Grab_cb);
				}
				return Seat.Grab_cb_delegate;
			}
		}

		// Token: 0x060009BC RID: 2492 RVA: 0x0001CD5B File Offset: 0x0001AF5B
		private static void OverrideGrab(GType gtype)
		{
			Seat.OverrideGrab(gtype, Seat.GrabVMCallback);
		}

		// Token: 0x060009BD RID: 2493 RVA: 0x0001CD68 File Offset: 0x0001AF68
		private unsafe static void OverrideGrab(GType gtype, Seat.GrabNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Seat.class_abi.GetFieldOffset("grab");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060009BE RID: 2494 RVA: 0x0001CD9C File Offset: 0x0001AF9C
		private static int Grab_cb(IntPtr inst, IntPtr window, int capabilities, bool owner_events, IntPtr cursor, IntPtr evnt, SeatGrabPrepareFuncNative prepare_func, IntPtr prepare_func_data)
		{
			int result;
			try
			{
				Seat seat = Object.GetObject(inst, false) as Seat;
				SeatGrabPrepareFuncInvoker seatGrabPrepareFuncInvoker = new SeatGrabPrepareFuncInvoker(prepare_func, prepare_func_data);
				result = (int)seat.OnGrab(Object.GetObject(window) as Window, (SeatCapabilities)capabilities, owner_events, Object.GetObject(cursor) as Cursor, Event.GetEvent(evnt), seatGrabPrepareFuncInvoker.Handler);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060009BF RID: 2495 RVA: 0x0001CE08 File Offset: 0x0001B008
		[DefaultSignalHandler(Type = typeof(Seat), ConnectionMethod = "OverrideGrab")]
		protected virtual GrabStatus OnGrab(Window window, SeatCapabilities capabilities, bool owner_events, Cursor cursor, Event evnt, SeatGrabPrepareFunc prepare_func)
		{
			return this.InternalGrab(window, capabilities, owner_events, cursor, evnt, prepare_func);
		}

		// Token: 0x060009C0 RID: 2496 RVA: 0x0001CE1C File Offset: 0x0001B01C
		private GrabStatus InternalGrab(Window window, SeatCapabilities capabilities, bool owner_events, Cursor cursor, Event evnt, SeatGrabPrepareFunc prepare_func)
		{
			Seat.GrabNativeDelegate grabNativeDelegate = Seat.class_abi.BaseOverride(base.LookupGType(), "grab");
			if (grabNativeDelegate == null)
			{
				return GrabStatus.Success;
			}
			SeatGrabPrepareFuncWrapper seatGrabPrepareFuncWrapper = new SeatGrabPrepareFuncWrapper(prepare_func);
			return (GrabStatus)grabNativeDelegate(base.Handle, (window == null) ? IntPtr.Zero : window.Handle, (int)capabilities, owner_events, (cursor == null) ? IntPtr.Zero : cursor.Handle, (evnt == null) ? IntPtr.Zero : evnt.Handle, seatGrabPrepareFuncWrapper.NativeDelegate, IntPtr.Zero);
		}

		// Token: 0x17000275 RID: 629
		// (get) Token: 0x060009C1 RID: 2497 RVA: 0x0001CE99 File Offset: 0x0001B099
		private static Seat.UngrabNativeDelegate UngrabVMCallback
		{
			get
			{
				if (Seat.Ungrab_cb_delegate == null)
				{
					Seat.Ungrab_cb_delegate = new Seat.UngrabNativeDelegate(Seat.Ungrab_cb);
				}
				return Seat.Ungrab_cb_delegate;
			}
		}

		// Token: 0x060009C2 RID: 2498 RVA: 0x0001CEB8 File Offset: 0x0001B0B8
		private static void OverrideUngrab(GType gtype)
		{
			Seat.OverrideUngrab(gtype, Seat.UngrabVMCallback);
		}

		// Token: 0x060009C3 RID: 2499 RVA: 0x0001CEC8 File Offset: 0x0001B0C8
		private unsafe static void OverrideUngrab(GType gtype, Seat.UngrabNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Seat.class_abi.GetFieldOffset("ungrab");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060009C4 RID: 2500 RVA: 0x0001CEFC File Offset: 0x0001B0FC
		private static void Ungrab_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Seat).OnUngrab();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060009C5 RID: 2501 RVA: 0x0001CF34 File Offset: 0x0001B134
		[DefaultSignalHandler(Type = typeof(Seat), ConnectionMethod = "OverrideUngrab")]
		protected virtual void OnUngrab()
		{
			this.InternalUngrab();
		}

		// Token: 0x060009C6 RID: 2502 RVA: 0x0001CF3C File Offset: 0x0001B13C
		private void InternalUngrab()
		{
			Seat.UngrabNativeDelegate ungrabNativeDelegate = Seat.class_abi.BaseOverride(base.LookupGType(), "ungrab");
			if (ungrabNativeDelegate == null)
			{
				return;
			}
			ungrabNativeDelegate(base.Handle);
		}

		// Token: 0x17000276 RID: 630
		// (get) Token: 0x060009C7 RID: 2503 RVA: 0x0001CF6F File Offset: 0x0001B16F
		private static Seat.GetMasterNativeDelegate GetMasterVMCallback
		{
			get
			{
				if (Seat.GetMaster_cb_delegate == null)
				{
					Seat.GetMaster_cb_delegate = new Seat.GetMasterNativeDelegate(Seat.GetMaster_cb);
				}
				return Seat.GetMaster_cb_delegate;
			}
		}

		// Token: 0x060009C8 RID: 2504 RVA: 0x0001CF8E File Offset: 0x0001B18E
		private static void OverrideGetMaster(GType gtype)
		{
			Seat.OverrideGetMaster(gtype, Seat.GetMasterVMCallback);
		}

		// Token: 0x060009C9 RID: 2505 RVA: 0x0001CF9C File Offset: 0x0001B19C
		private unsafe static void OverrideGetMaster(GType gtype, Seat.GetMasterNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Seat.class_abi.GetFieldOffset("get_master");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060009CA RID: 2506 RVA: 0x0001CFD0 File Offset: 0x0001B1D0
		private static IntPtr GetMaster_cb(IntPtr inst, int capability)
		{
			IntPtr result;
			try
			{
				Device device = (Object.GetObject(inst, false) as Seat).OnGetMaster((SeatCapabilities)capability);
				result = ((device == null) ? IntPtr.Zero : device.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060009CB RID: 2507 RVA: 0x0001D01C File Offset: 0x0001B21C
		[DefaultSignalHandler(Type = typeof(Seat), ConnectionMethod = "OverrideGetMaster")]
		protected virtual Device OnGetMaster(SeatCapabilities capability)
		{
			return this.InternalGetMaster(capability);
		}

		// Token: 0x060009CC RID: 2508 RVA: 0x0001D028 File Offset: 0x0001B228
		private Device InternalGetMaster(SeatCapabilities capability)
		{
			Seat.GetMasterNativeDelegate getMasterNativeDelegate = Seat.class_abi.BaseOverride(base.LookupGType(), "get_master");
			if (getMasterNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getMasterNativeDelegate(base.Handle, (int)capability)) as Device;
		}

		// Token: 0x17000277 RID: 631
		// (get) Token: 0x060009CD RID: 2509 RVA: 0x0001D067 File Offset: 0x0001B267
		private static Seat.GetSlavesNativeDelegate GetSlavesVMCallback
		{
			get
			{
				if (Seat.GetSlaves_cb_delegate == null)
				{
					Seat.GetSlaves_cb_delegate = new Seat.GetSlavesNativeDelegate(Seat.GetSlaves_cb);
				}
				return Seat.GetSlaves_cb_delegate;
			}
		}

		// Token: 0x060009CE RID: 2510 RVA: 0x0001D086 File Offset: 0x0001B286
		private static void OverrideGetSlaves(GType gtype)
		{
			Seat.OverrideGetSlaves(gtype, Seat.GetSlavesVMCallback);
		}

		// Token: 0x060009CF RID: 2511 RVA: 0x0001D094 File Offset: 0x0001B294
		private unsafe static void OverrideGetSlaves(GType gtype, Seat.GetSlavesNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Seat.class_abi.GetFieldOffset("get_slaves");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060009D0 RID: 2512 RVA: 0x0001D0C8 File Offset: 0x0001B2C8
		private static IntPtr GetSlaves_cb(IntPtr inst, int capabilities)
		{
			IntPtr result;
			try
			{
				Device[] array = (Object.GetObject(inst, false) as Seat).OnGetSlaves((SeatCapabilities)capabilities);
				object[] elements = array;
				IntPtr intPtr;
				if (new List(elements, typeof(Device), true, false) != null)
				{
					elements = array;
					intPtr = new List(elements, typeof(Device), true, false).Handle;
				}
				else
				{
					intPtr = IntPtr.Zero;
				}
				result = intPtr;
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060009D1 RID: 2513 RVA: 0x0001D13C File Offset: 0x0001B33C
		[DefaultSignalHandler(Type = typeof(Seat), ConnectionMethod = "OverrideGetSlaves")]
		protected virtual Device[] OnGetSlaves(SeatCapabilities capabilities)
		{
			return this.InternalGetSlaves(capabilities);
		}

		// Token: 0x060009D2 RID: 2514 RVA: 0x0001D148 File Offset: 0x0001B348
		private Device[] InternalGetSlaves(SeatCapabilities capabilities)
		{
			Seat.GetSlavesNativeDelegate getSlavesNativeDelegate = Seat.class_abi.BaseOverride(base.LookupGType(), "get_slaves");
			if (getSlavesNativeDelegate == null)
			{
				return null;
			}
			return (Device[])Marshaller.ListPtrToArray(getSlavesNativeDelegate(base.Handle, (int)capabilities), typeof(List), true, false, typeof(Device));
		}

		// Token: 0x17000278 RID: 632
		// (get) Token: 0x060009D3 RID: 2515 RVA: 0x0001D19D File Offset: 0x0001B39D
		private static Seat.GetToolNativeDelegate GetToolVMCallback
		{
			get
			{
				if (Seat.GetTool_cb_delegate == null)
				{
					Seat.GetTool_cb_delegate = new Seat.GetToolNativeDelegate(Seat.GetTool_cb);
				}
				return Seat.GetTool_cb_delegate;
			}
		}

		// Token: 0x060009D4 RID: 2516 RVA: 0x0001D1BC File Offset: 0x0001B3BC
		private static void OverrideGetTool(GType gtype)
		{
			Seat.OverrideGetTool(gtype, Seat.GetToolVMCallback);
		}

		// Token: 0x060009D5 RID: 2517 RVA: 0x0001D1CC File Offset: 0x0001B3CC
		private unsafe static void OverrideGetTool(GType gtype, Seat.GetToolNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Seat.class_abi.GetFieldOffset("get_tool");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060009D6 RID: 2518 RVA: 0x0001D200 File Offset: 0x0001B400
		private static IntPtr GetTool_cb(IntPtr inst, ulong serial)
		{
			IntPtr result;
			try
			{
				DeviceTool deviceTool = (Object.GetObject(inst, false) as Seat).OnGetTool(serial);
				result = ((deviceTool == null) ? IntPtr.Zero : deviceTool.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060009D7 RID: 2519 RVA: 0x0001D24C File Offset: 0x0001B44C
		[DefaultSignalHandler(Type = typeof(Seat), ConnectionMethod = "OverrideGetTool")]
		protected virtual DeviceTool OnGetTool(ulong serial)
		{
			return this.InternalGetTool(serial);
		}

		// Token: 0x060009D8 RID: 2520 RVA: 0x0001D258 File Offset: 0x0001B458
		private DeviceTool InternalGetTool(ulong serial)
		{
			Seat.GetToolNativeDelegate getToolNativeDelegate = Seat.class_abi.BaseOverride(base.LookupGType(), "get_tool");
			if (getToolNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getToolNativeDelegate(base.Handle, serial)) as DeviceTool;
		}

		// Token: 0x17000279 RID: 633
		// (get) Token: 0x060009D9 RID: 2521 RVA: 0x0001D298 File Offset: 0x0001B498
		public new static AbiStruct class_abi
		{
			get
			{
				if (Seat._class_abi == null)
				{
					Seat._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("device_added", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "device_removed", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("device_removed", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "device_added", "device_changed", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("device_changed", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "device_removed", "get_capabilities", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_capabilities", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "device_changed", "grab", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("grab", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_capabilities", "ungrab", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("ungrab", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "grab", "get_master", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_master", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "ungrab", "get_slaves", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_slaves", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_master", "get_tool", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_tool", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_slaves", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Seat._class_abi;
			}
		}

		// Token: 0x1700027A RID: 634
		// (get) Token: 0x060009DA RID: 2522 RVA: 0x0001D4DF File Offset: 0x0001B6DF
		public SeatCapabilities Capabilities
		{
			get
			{
				return (SeatCapabilities)Seat.gdk_seat_get_capabilities(base.Handle);
			}
		}

		// Token: 0x1700027B RID: 635
		// (get) Token: 0x060009DB RID: 2523 RVA: 0x0001D4F1 File Offset: 0x0001B6F1
		public Display Display
		{
			get
			{
				return Object.GetObject(Seat.gdk_seat_get_display(base.Handle)) as Display;
			}
		}

		// Token: 0x1700027C RID: 636
		// (get) Token: 0x060009DC RID: 2524 RVA: 0x0001D50D File Offset: 0x0001B70D
		public Device Keyboard
		{
			get
			{
				return Object.GetObject(Seat.gdk_seat_get_keyboard(base.Handle)) as Device;
			}
		}

		// Token: 0x1700027D RID: 637
		// (get) Token: 0x060009DD RID: 2525 RVA: 0x0001D529 File Offset: 0x0001B729
		public Device Pointer
		{
			get
			{
				return Object.GetObject(Seat.gdk_seat_get_pointer(base.Handle)) as Device;
			}
		}

		// Token: 0x060009DE RID: 2526 RVA: 0x0001D545 File Offset: 0x0001B745
		public Device[] GetSlaves(SeatCapabilities capabilities)
		{
			return (Device[])Marshaller.ListPtrToArray(Seat.gdk_seat_get_slaves(base.Handle, (int)capabilities), typeof(List), true, false, typeof(Device));
		}

		// Token: 0x1700027E RID: 638
		// (get) Token: 0x060009DF RID: 2527 RVA: 0x0001D578 File Offset: 0x0001B778
		public new static GType GType
		{
			get
			{
				IntPtr val = Seat.gdk_seat_get_type();
				return new GType(val);
			}
		}

		// Token: 0x060009E0 RID: 2528 RVA: 0x0001D598 File Offset: 0x0001B798
		public GrabStatus Grab(Window window, SeatCapabilities capabilities, bool owner_events, Cursor cursor, Event evnt, SeatGrabPrepareFunc prepare_func)
		{
			SeatGrabPrepareFuncWrapper seatGrabPrepareFuncWrapper = new SeatGrabPrepareFuncWrapper(prepare_func);
			return (GrabStatus)Seat.gdk_seat_grab(base.Handle, (window == null) ? IntPtr.Zero : window.Handle, (int)capabilities, owner_events, (cursor == null) ? IntPtr.Zero : cursor.Handle, (evnt == null) ? IntPtr.Zero : evnt.Handle, seatGrabPrepareFuncWrapper.NativeDelegate, IntPtr.Zero);
		}

		// Token: 0x060009E1 RID: 2529 RVA: 0x0001D5FE File Offset: 0x0001B7FE
		public void Ungrab()
		{
			Seat.gdk_seat_ungrab(base.Handle);
		}

		// Token: 0x1700027F RID: 639
		// (get) Token: 0x060009E2 RID: 2530 RVA: 0x0001D610 File Offset: 0x0001B810
		public new static AbiStruct abi_info
		{
			get
			{
				if (Seat._abi_info == null)
				{
					Seat._abi_info = new AbiStruct(Object.abi_info.Fields);
				}
				return Seat._abi_info;
			}
		}

		// Token: 0x04000545 RID: 1349
		private static Seat.DeviceAddedNativeDelegate DeviceAdded_cb_delegate;

		// Token: 0x04000546 RID: 1350
		private static Seat.DeviceRemovedNativeDelegate DeviceRemoved_cb_delegate;

		// Token: 0x04000547 RID: 1351
		private static Seat.DeviceChangedNativeDelegate DeviceChanged_cb_delegate;

		// Token: 0x04000548 RID: 1352
		private static Seat.GetCapabilitiesNativeDelegate GetCapabilities_cb_delegate;

		// Token: 0x04000549 RID: 1353
		private static Seat.GrabNativeDelegate Grab_cb_delegate;

		// Token: 0x0400054A RID: 1354
		private static Seat.UngrabNativeDelegate Ungrab_cb_delegate;

		// Token: 0x0400054B RID: 1355
		private static Seat.GetMasterNativeDelegate GetMaster_cb_delegate;

		// Token: 0x0400054C RID: 1356
		private static Seat.GetSlavesNativeDelegate GetSlaves_cb_delegate;

		// Token: 0x0400054D RID: 1357
		private static Seat.GetToolNativeDelegate GetTool_cb_delegate;

		// Token: 0x0400054E RID: 1358
		private static AbiStruct _class_abi = null;

		// Token: 0x0400054F RID: 1359
		private static Seat.d_gdk_seat_get_capabilities gdk_seat_get_capabilities = FuncLoader.LoadFunction<Seat.d_gdk_seat_get_capabilities>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_seat_get_capabilities"));

		// Token: 0x04000550 RID: 1360
		private static Seat.d_gdk_seat_get_display gdk_seat_get_display = FuncLoader.LoadFunction<Seat.d_gdk_seat_get_display>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_seat_get_display"));

		// Token: 0x04000551 RID: 1361
		private static Seat.d_gdk_seat_get_keyboard gdk_seat_get_keyboard = FuncLoader.LoadFunction<Seat.d_gdk_seat_get_keyboard>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_seat_get_keyboard"));

		// Token: 0x04000552 RID: 1362
		private static Seat.d_gdk_seat_get_pointer gdk_seat_get_pointer = FuncLoader.LoadFunction<Seat.d_gdk_seat_get_pointer>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_seat_get_pointer"));

		// Token: 0x04000553 RID: 1363
		private static Seat.d_gdk_seat_get_slaves gdk_seat_get_slaves = FuncLoader.LoadFunction<Seat.d_gdk_seat_get_slaves>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_seat_get_slaves"));

		// Token: 0x04000554 RID: 1364
		private static Seat.d_gdk_seat_get_type gdk_seat_get_type = FuncLoader.LoadFunction<Seat.d_gdk_seat_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_seat_get_type"));

		// Token: 0x04000555 RID: 1365
		private static Seat.d_gdk_seat_grab gdk_seat_grab = FuncLoader.LoadFunction<Seat.d_gdk_seat_grab>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_seat_grab"));

		// Token: 0x04000556 RID: 1366
		private static Seat.d_gdk_seat_ungrab gdk_seat_ungrab = FuncLoader.LoadFunction<Seat.d_gdk_seat_ungrab>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_seat_ungrab"));

		// Token: 0x04000557 RID: 1367
		private static AbiStruct _abi_info = null;

		// Token: 0x020003F1 RID: 1009
		// (Invoke) Token: 0x06001646 RID: 5702
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DeviceAddedNativeDelegate(IntPtr inst, IntPtr device);

		// Token: 0x020003F2 RID: 1010
		// (Invoke) Token: 0x0600164A RID: 5706
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DeviceRemovedNativeDelegate(IntPtr inst, IntPtr device);

		// Token: 0x020003F3 RID: 1011
		// (Invoke) Token: 0x0600164E RID: 5710
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DeviceChangedNativeDelegate(IntPtr inst, IntPtr device);

		// Token: 0x020003F4 RID: 1012
		// (Invoke) Token: 0x06001652 RID: 5714
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetCapabilitiesNativeDelegate(IntPtr inst);

		// Token: 0x020003F5 RID: 1013
		// (Invoke) Token: 0x06001656 RID: 5718
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GrabNativeDelegate(IntPtr inst, IntPtr window, int capabilities, bool owner_events, IntPtr cursor, IntPtr evnt, SeatGrabPrepareFuncNative prepare_func, IntPtr prepare_func_data);

		// Token: 0x020003F6 RID: 1014
		// (Invoke) Token: 0x0600165A RID: 5722
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void UngrabNativeDelegate(IntPtr inst);

		// Token: 0x020003F7 RID: 1015
		// (Invoke) Token: 0x0600165E RID: 5726
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetMasterNativeDelegate(IntPtr inst, int capability);

		// Token: 0x020003F8 RID: 1016
		// (Invoke) Token: 0x06001662 RID: 5730
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetSlavesNativeDelegate(IntPtr inst, int capabilities);

		// Token: 0x020003F9 RID: 1017
		// (Invoke) Token: 0x06001666 RID: 5734
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetToolNativeDelegate(IntPtr inst, ulong serial);

		// Token: 0x020003FA RID: 1018
		// (Invoke) Token: 0x0600166A RID: 5738
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_seat_get_capabilities(IntPtr raw);

		// Token: 0x020003FB RID: 1019
		// (Invoke) Token: 0x0600166E RID: 5742
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_seat_get_display(IntPtr raw);

		// Token: 0x020003FC RID: 1020
		// (Invoke) Token: 0x06001672 RID: 5746
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_seat_get_keyboard(IntPtr raw);

		// Token: 0x020003FD RID: 1021
		// (Invoke) Token: 0x06001676 RID: 5750
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_seat_get_pointer(IntPtr raw);

		// Token: 0x020003FE RID: 1022
		// (Invoke) Token: 0x0600167A RID: 5754
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_seat_get_slaves(IntPtr raw, int capabilities);

		// Token: 0x020003FF RID: 1023
		// (Invoke) Token: 0x0600167E RID: 5758
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_seat_get_type();

		// Token: 0x02000400 RID: 1024
		// (Invoke) Token: 0x06001682 RID: 5762
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_seat_grab(IntPtr raw, IntPtr window, int capabilities, bool owner_events, IntPtr cursor, IntPtr evnt, SeatGrabPrepareFuncNative prepare_func, IntPtr prepare_func_data);

		// Token: 0x02000401 RID: 1025
		// (Invoke) Token: 0x06001686 RID: 5766
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_seat_ungrab(IntPtr raw);
	}
}
