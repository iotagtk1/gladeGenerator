﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000127 RID: 295
	[GType(typeof(WindowWindowClassGType))]
	public enum WindowWindowClass
	{
		// Token: 0x040006B2 RID: 1714
		InputOutput,
		// Token: 0x040006B3 RID: 1715
		InputOnly
	}
}
