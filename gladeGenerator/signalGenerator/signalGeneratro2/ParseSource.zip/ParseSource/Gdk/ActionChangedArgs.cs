﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000038 RID: 56
	public class ActionChangedArgs : SignalArgs
	{
		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x06000377 RID: 887 RVA: 0x0000B549 File Offset: 0x00009749
		public DragAction Action
		{
			get
			{
				return (DragAction)base.Args[0];
			}
		}
	}
}
