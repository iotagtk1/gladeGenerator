﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x0200009A RID: 154
	[GType(typeof(GrabStatusGType))]
	public enum GrabStatus
	{
		// Token: 0x04000369 RID: 873
		Success,
		// Token: 0x0400036A RID: 874
		AlreadyGrabbed,
		// Token: 0x0400036B RID: 875
		InvalidTime,
		// Token: 0x0400036C RID: 876
		NotViewable,
		// Token: 0x0400036D RID: 877
		Frozen,
		// Token: 0x0400036E RID: 878
		Failed
	}
}
