﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Cairo;
using GLib;

namespace Gdk
{
	// Token: 0x02000094 RID: 148
	public class GLContext : Object
	{
		// Token: 0x0600061B RID: 1563 RVA: 0x000121E2 File Offset: 0x000103E2
		public GLContext(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x0600061C RID: 1564 RVA: 0x000121EB File Offset: 0x000103EB
		protected GLContext() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x1700018E RID: 398
		// (get) Token: 0x0600061D RID: 1565 RVA: 0x0001220A File Offset: 0x0001040A
		[Property("display")]
		public Display Display
		{
			get
			{
				return Object.GetObject(GLContext.gdk_gl_context_get_display(base.Handle)) as Display;
			}
		}

		// Token: 0x1700018F RID: 399
		// (get) Token: 0x0600061E RID: 1566 RVA: 0x00012226 File Offset: 0x00010426
		[Property("window")]
		public Window Window
		{
			get
			{
				return Object.GetObject(GLContext.gdk_gl_context_get_window(base.Handle)) as Window;
			}
		}

		// Token: 0x17000190 RID: 400
		// (get) Token: 0x0600061F RID: 1567 RVA: 0x00012242 File Offset: 0x00010442
		private static GLContext.RealizeNativeDelegate RealizeVMCallback
		{
			get
			{
				if (GLContext.Realize_cb_delegate == null)
				{
					GLContext.Realize_cb_delegate = new GLContext.RealizeNativeDelegate(GLContext.Realize_cb);
				}
				return GLContext.Realize_cb_delegate;
			}
		}

		// Token: 0x06000620 RID: 1568 RVA: 0x00012261 File Offset: 0x00010461
		private static void OverrideRealize(GType gtype)
		{
			GLContext.OverrideRealize(gtype, GLContext.RealizeVMCallback);
		}

		// Token: 0x06000621 RID: 1569 RVA: 0x00012270 File Offset: 0x00010470
		private unsafe static void OverrideRealize(GType gtype, GLContext.RealizeNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + GLContext.class_abi.GetFieldOffset("realize");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000622 RID: 1570 RVA: 0x000122A4 File Offset: 0x000104A4
		private static bool Realize_cb(IntPtr inst, out IntPtr error)
		{
			error = IntPtr.Zero;
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as GLContext).OnRealize();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000623 RID: 1571 RVA: 0x000122E8 File Offset: 0x000104E8
		[DefaultSignalHandler(Type = typeof(GLContext), ConnectionMethod = "OverrideRealize")]
		protected virtual bool OnRealize()
		{
			return this.InternalRealize();
		}

		// Token: 0x06000624 RID: 1572 RVA: 0x000122F0 File Offset: 0x000104F0
		private bool InternalRealize()
		{
			GLContext.RealizeNativeDelegate realizeNativeDelegate = GLContext.class_abi.BaseOverride(base.LookupGType(), "realize");
			if (realizeNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			IntPtr zero = IntPtr.Zero;
			return realizeNativeDelegate(base.Handle, out zero);
		}

		// Token: 0x17000191 RID: 401
		// (get) Token: 0x06000625 RID: 1573 RVA: 0x00012333 File Offset: 0x00010533
		private static GLContext.EndFrameNativeDelegate EndFrameVMCallback
		{
			get
			{
				if (GLContext.EndFrame_cb_delegate == null)
				{
					GLContext.EndFrame_cb_delegate = new GLContext.EndFrameNativeDelegate(GLContext.EndFrame_cb);
				}
				return GLContext.EndFrame_cb_delegate;
			}
		}

		// Token: 0x06000626 RID: 1574 RVA: 0x00012352 File Offset: 0x00010552
		private static void OverrideEndFrame(GType gtype)
		{
			GLContext.OverrideEndFrame(gtype, GLContext.EndFrameVMCallback);
		}

		// Token: 0x06000627 RID: 1575 RVA: 0x00012360 File Offset: 0x00010560
		private unsafe static void OverrideEndFrame(GType gtype, GLContext.EndFrameNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + GLContext.class_abi.GetFieldOffset("end_frame");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000628 RID: 1576 RVA: 0x00012394 File Offset: 0x00010594
		private static void EndFrame_cb(IntPtr inst, IntPtr painted, IntPtr damage)
		{
			try
			{
				(Object.GetObject(inst, false) as GLContext).OnEndFrame(new Region(painted), new Region(damage));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000629 RID: 1577 RVA: 0x000123D8 File Offset: 0x000105D8
		[DefaultSignalHandler(Type = typeof(GLContext), ConnectionMethod = "OverrideEndFrame")]
		protected virtual void OnEndFrame(Region painted, Region damage)
		{
			this.InternalEndFrame(painted, damage);
		}

		// Token: 0x0600062A RID: 1578 RVA: 0x000123E4 File Offset: 0x000105E4
		private void InternalEndFrame(Region painted, Region damage)
		{
			GLContext.EndFrameNativeDelegate endFrameNativeDelegate = GLContext.class_abi.BaseOverride(base.LookupGType(), "end_frame");
			if (endFrameNativeDelegate == null)
			{
				return;
			}
			endFrameNativeDelegate(base.Handle, (painted == null) ? IntPtr.Zero : painted.Handle, (damage == null) ? IntPtr.Zero : damage.Handle);
		}

		// Token: 0x17000192 RID: 402
		// (get) Token: 0x0600062B RID: 1579 RVA: 0x00012437 File Offset: 0x00010637
		private static GLContext.TextureFromSurfaceNativeDelegate TextureFromSurfaceVMCallback
		{
			get
			{
				if (GLContext.TextureFromSurface_cb_delegate == null)
				{
					GLContext.TextureFromSurface_cb_delegate = new GLContext.TextureFromSurfaceNativeDelegate(GLContext.TextureFromSurface_cb);
				}
				return GLContext.TextureFromSurface_cb_delegate;
			}
		}

		// Token: 0x0600062C RID: 1580 RVA: 0x00012456 File Offset: 0x00010656
		private static void OverrideTextureFromSurface(GType gtype)
		{
			GLContext.OverrideTextureFromSurface(gtype, GLContext.TextureFromSurfaceVMCallback);
		}

		// Token: 0x0600062D RID: 1581 RVA: 0x00012464 File Offset: 0x00010664
		private unsafe static void OverrideTextureFromSurface(GType gtype, GLContext.TextureFromSurfaceNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + GLContext.class_abi.GetFieldOffset("texture_from_surface");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600062E RID: 1582 RVA: 0x00012498 File Offset: 0x00010698
		private static bool TextureFromSurface_cb(IntPtr inst, IntPtr surface, IntPtr region)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as GLContext).OnTextureFromSurface(Surface.Lookup(surface, true), new Region(region));
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600062F RID: 1583 RVA: 0x000124E0 File Offset: 0x000106E0
		[DefaultSignalHandler(Type = typeof(GLContext), ConnectionMethod = "OverrideTextureFromSurface")]
		protected virtual bool OnTextureFromSurface(Surface surface, Region region)
		{
			return this.InternalTextureFromSurface(surface, region);
		}

		// Token: 0x06000630 RID: 1584 RVA: 0x000124EC File Offset: 0x000106EC
		private bool InternalTextureFromSurface(Surface surface, Region region)
		{
			GLContext.TextureFromSurfaceNativeDelegate textureFromSurfaceNativeDelegate = GLContext.class_abi.BaseOverride(base.LookupGType(), "texture_from_surface");
			return textureFromSurfaceNativeDelegate != null && textureFromSurfaceNativeDelegate(base.Handle, surface.Handle, (region == null) ? IntPtr.Zero : region.Handle);
		}

		// Token: 0x17000193 RID: 403
		// (get) Token: 0x06000631 RID: 1585 RVA: 0x00012538 File Offset: 0x00010738
		public new static AbiStruct class_abi
		{
			get
			{
				if (GLContext._class_abi == null)
				{
					GLContext._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("realize", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "end_frame", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("end_frame", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "realize", "texture_from_surface", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("texture_from_surface", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "end_frame", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return GLContext._class_abi;
			}
		}

		// Token: 0x06000632 RID: 1586 RVA: 0x00012617 File Offset: 0x00010817
		public static void ClearCurrent()
		{
			GLContext.gdk_gl_context_clear_current();
		}

		// Token: 0x17000194 RID: 404
		// (get) Token: 0x06000633 RID: 1587 RVA: 0x00012623 File Offset: 0x00010823
		public static GLContext Current
		{
			get
			{
				return Object.GetObject(GLContext.gdk_gl_context_get_current()) as GLContext;
			}
		}

		// Token: 0x17000195 RID: 405
		// (get) Token: 0x06000634 RID: 1588 RVA: 0x00012639 File Offset: 0x00010839
		// (set) Token: 0x06000635 RID: 1589 RVA: 0x0001264B File Offset: 0x0001084B
		public bool DebugEnabled
		{
			get
			{
				return GLContext.gdk_gl_context_get_debug_enabled(base.Handle);
			}
			set
			{
				GLContext.gdk_gl_context_set_debug_enabled(base.Handle, value);
			}
		}

		// Token: 0x17000196 RID: 406
		// (get) Token: 0x06000636 RID: 1590 RVA: 0x0001265E File Offset: 0x0001085E
		// (set) Token: 0x06000637 RID: 1591 RVA: 0x00012670 File Offset: 0x00010870
		public bool ForwardCompatible
		{
			get
			{
				return GLContext.gdk_gl_context_get_forward_compatible(base.Handle);
			}
			set
			{
				GLContext.gdk_gl_context_set_forward_compatible(base.Handle, value);
			}
		}

		// Token: 0x06000638 RID: 1592 RVA: 0x00012683 File Offset: 0x00010883
		public void GetRequiredVersion(out int major, out int minor)
		{
			GLContext.gdk_gl_context_get_required_version(base.Handle, out major, out minor);
		}

		// Token: 0x17000197 RID: 407
		// (get) Token: 0x06000639 RID: 1593 RVA: 0x00012697 File Offset: 0x00010897
		public GLContext SharedContext
		{
			get
			{
				return Object.GetObject(GLContext.gdk_gl_context_get_shared_context(base.Handle)) as GLContext;
			}
		}

		// Token: 0x17000198 RID: 408
		// (get) Token: 0x0600063A RID: 1594 RVA: 0x000126B4 File Offset: 0x000108B4
		public new static GType GType
		{
			get
			{
				IntPtr val = GLContext.gdk_gl_context_get_type();
				return new GType(val);
			}
		}

		// Token: 0x17000199 RID: 409
		// (get) Token: 0x0600063B RID: 1595 RVA: 0x000126D2 File Offset: 0x000108D2
		public bool UseEs
		{
			get
			{
				return GLContext.gdk_gl_context_get_use_es(base.Handle);
			}
		}

		// Token: 0x0600063C RID: 1596 RVA: 0x000126E4 File Offset: 0x000108E4
		public void GetVersion(out int major, out int minor)
		{
			GLContext.gdk_gl_context_get_version(base.Handle, out major, out minor);
		}

		// Token: 0x1700019A RID: 410
		// (get) Token: 0x0600063D RID: 1597 RVA: 0x000126F8 File Offset: 0x000108F8
		public bool IsLegacy
		{
			get
			{
				return GLContext.gdk_gl_context_is_legacy(base.Handle);
			}
		}

		// Token: 0x0600063E RID: 1598 RVA: 0x0001270A File Offset: 0x0001090A
		public void MakeCurrent()
		{
			GLContext.gdk_gl_context_make_current(base.Handle);
		}

		// Token: 0x0600063F RID: 1599 RVA: 0x0001271C File Offset: 0x0001091C
		public bool Realize()
		{
			IntPtr zero = IntPtr.Zero;
			bool result = GLContext.gdk_gl_context_realize(base.Handle, out zero);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x06000640 RID: 1600 RVA: 0x00012755 File Offset: 0x00010955
		public void SetRequiredVersion(int major, int minor)
		{
			GLContext.gdk_gl_context_set_required_version(base.Handle, major, minor);
		}

		// Token: 0x06000641 RID: 1601 RVA: 0x00012769 File Offset: 0x00010969
		public void SetUseEs(int use_es)
		{
			GLContext.gdk_gl_context_set_use_es(base.Handle, use_es);
		}

		// Token: 0x1700019B RID: 411
		// (get) Token: 0x06000642 RID: 1602 RVA: 0x0001277C File Offset: 0x0001097C
		public new static AbiStruct abi_info
		{
			get
			{
				if (GLContext._abi_info == null)
				{
					GLContext._abi_info = new AbiStruct(Object.abi_info.Fields);
				}
				return GLContext._abi_info;
			}
		}

		// Token: 0x04000334 RID: 820
		private static GLContext.d_gdk_gl_context_get_display gdk_gl_context_get_display = FuncLoader.LoadFunction<GLContext.d_gdk_gl_context_get_display>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gl_context_get_display"));

		// Token: 0x04000335 RID: 821
		private static GLContext.d_gdk_gl_context_get_window gdk_gl_context_get_window = FuncLoader.LoadFunction<GLContext.d_gdk_gl_context_get_window>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gl_context_get_window"));

		// Token: 0x04000336 RID: 822
		private static GLContext.RealizeNativeDelegate Realize_cb_delegate;

		// Token: 0x04000337 RID: 823
		private static GLContext.EndFrameNativeDelegate EndFrame_cb_delegate;

		// Token: 0x04000338 RID: 824
		private static GLContext.TextureFromSurfaceNativeDelegate TextureFromSurface_cb_delegate;

		// Token: 0x04000339 RID: 825
		private static AbiStruct _class_abi = null;

		// Token: 0x0400033A RID: 826
		private static GLContext.d_gdk_gl_context_clear_current gdk_gl_context_clear_current = FuncLoader.LoadFunction<GLContext.d_gdk_gl_context_clear_current>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gl_context_clear_current"));

		// Token: 0x0400033B RID: 827
		private static GLContext.d_gdk_gl_context_get_current gdk_gl_context_get_current = FuncLoader.LoadFunction<GLContext.d_gdk_gl_context_get_current>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gl_context_get_current"));

		// Token: 0x0400033C RID: 828
		private static GLContext.d_gdk_gl_context_get_debug_enabled gdk_gl_context_get_debug_enabled = FuncLoader.LoadFunction<GLContext.d_gdk_gl_context_get_debug_enabled>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gl_context_get_debug_enabled"));

		// Token: 0x0400033D RID: 829
		private static GLContext.d_gdk_gl_context_set_debug_enabled gdk_gl_context_set_debug_enabled = FuncLoader.LoadFunction<GLContext.d_gdk_gl_context_set_debug_enabled>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gl_context_set_debug_enabled"));

		// Token: 0x0400033E RID: 830
		private static GLContext.d_gdk_gl_context_get_forward_compatible gdk_gl_context_get_forward_compatible = FuncLoader.LoadFunction<GLContext.d_gdk_gl_context_get_forward_compatible>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gl_context_get_forward_compatible"));

		// Token: 0x0400033F RID: 831
		private static GLContext.d_gdk_gl_context_set_forward_compatible gdk_gl_context_set_forward_compatible = FuncLoader.LoadFunction<GLContext.d_gdk_gl_context_set_forward_compatible>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gl_context_set_forward_compatible"));

		// Token: 0x04000340 RID: 832
		private static GLContext.d_gdk_gl_context_get_required_version gdk_gl_context_get_required_version = FuncLoader.LoadFunction<GLContext.d_gdk_gl_context_get_required_version>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gl_context_get_required_version"));

		// Token: 0x04000341 RID: 833
		private static GLContext.d_gdk_gl_context_get_shared_context gdk_gl_context_get_shared_context = FuncLoader.LoadFunction<GLContext.d_gdk_gl_context_get_shared_context>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gl_context_get_shared_context"));

		// Token: 0x04000342 RID: 834
		private static GLContext.d_gdk_gl_context_get_type gdk_gl_context_get_type = FuncLoader.LoadFunction<GLContext.d_gdk_gl_context_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gl_context_get_type"));

		// Token: 0x04000343 RID: 835
		private static GLContext.d_gdk_gl_context_get_use_es gdk_gl_context_get_use_es = FuncLoader.LoadFunction<GLContext.d_gdk_gl_context_get_use_es>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gl_context_get_use_es"));

		// Token: 0x04000344 RID: 836
		private static GLContext.d_gdk_gl_context_get_version gdk_gl_context_get_version = FuncLoader.LoadFunction<GLContext.d_gdk_gl_context_get_version>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gl_context_get_version"));

		// Token: 0x04000345 RID: 837
		private static GLContext.d_gdk_gl_context_is_legacy gdk_gl_context_is_legacy = FuncLoader.LoadFunction<GLContext.d_gdk_gl_context_is_legacy>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gl_context_is_legacy"));

		// Token: 0x04000346 RID: 838
		private static GLContext.d_gdk_gl_context_make_current gdk_gl_context_make_current = FuncLoader.LoadFunction<GLContext.d_gdk_gl_context_make_current>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gl_context_make_current"));

		// Token: 0x04000347 RID: 839
		private static GLContext.d_gdk_gl_context_realize gdk_gl_context_realize = FuncLoader.LoadFunction<GLContext.d_gdk_gl_context_realize>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gl_context_realize"));

		// Token: 0x04000348 RID: 840
		private static GLContext.d_gdk_gl_context_set_required_version gdk_gl_context_set_required_version = FuncLoader.LoadFunction<GLContext.d_gdk_gl_context_set_required_version>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gl_context_set_required_version"));

		// Token: 0x04000349 RID: 841
		private static GLContext.d_gdk_gl_context_set_use_es gdk_gl_context_set_use_es = FuncLoader.LoadFunction<GLContext.d_gdk_gl_context_set_use_es>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gl_context_set_use_es"));

		// Token: 0x0400034A RID: 842
		private static AbiStruct _abi_info = null;

		// Token: 0x020002B0 RID: 688
		// (Invoke) Token: 0x06001145 RID: 4421
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_gl_context_get_display(IntPtr raw);

		// Token: 0x020002B1 RID: 689
		// (Invoke) Token: 0x06001149 RID: 4425
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_gl_context_get_window(IntPtr raw);

		// Token: 0x020002B2 RID: 690
		// (Invoke) Token: 0x0600114D RID: 4429
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool RealizeNativeDelegate(IntPtr inst, out IntPtr error);

		// Token: 0x020002B3 RID: 691
		// (Invoke) Token: 0x06001151 RID: 4433
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void EndFrameNativeDelegate(IntPtr inst, IntPtr painted, IntPtr damage);

		// Token: 0x020002B4 RID: 692
		// (Invoke) Token: 0x06001155 RID: 4437
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool TextureFromSurfaceNativeDelegate(IntPtr inst, IntPtr surface, IntPtr region);

		// Token: 0x020002B5 RID: 693
		// (Invoke) Token: 0x06001159 RID: 4441
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_gl_context_clear_current();

		// Token: 0x020002B6 RID: 694
		// (Invoke) Token: 0x0600115D RID: 4445
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_gl_context_get_current();

		// Token: 0x020002B7 RID: 695
		// (Invoke) Token: 0x06001161 RID: 4449
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_gl_context_get_debug_enabled(IntPtr raw);

		// Token: 0x020002B8 RID: 696
		// (Invoke) Token: 0x06001165 RID: 4453
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_gl_context_set_debug_enabled(IntPtr raw, bool enabled);

		// Token: 0x020002B9 RID: 697
		// (Invoke) Token: 0x06001169 RID: 4457
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_gl_context_get_forward_compatible(IntPtr raw);

		// Token: 0x020002BA RID: 698
		// (Invoke) Token: 0x0600116D RID: 4461
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_gl_context_set_forward_compatible(IntPtr raw, bool compatible);

		// Token: 0x020002BB RID: 699
		// (Invoke) Token: 0x06001171 RID: 4465
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_gl_context_get_required_version(IntPtr raw, out int major, out int minor);

		// Token: 0x020002BC RID: 700
		// (Invoke) Token: 0x06001175 RID: 4469
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_gl_context_get_shared_context(IntPtr raw);

		// Token: 0x020002BD RID: 701
		// (Invoke) Token: 0x06001179 RID: 4473
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_gl_context_get_type();

		// Token: 0x020002BE RID: 702
		// (Invoke) Token: 0x0600117D RID: 4477
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_gl_context_get_use_es(IntPtr raw);

		// Token: 0x020002BF RID: 703
		// (Invoke) Token: 0x06001181 RID: 4481
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_gl_context_get_version(IntPtr raw, out int major, out int minor);

		// Token: 0x020002C0 RID: 704
		// (Invoke) Token: 0x06001185 RID: 4485
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_gl_context_is_legacy(IntPtr raw);

		// Token: 0x020002C1 RID: 705
		// (Invoke) Token: 0x06001189 RID: 4489
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_gl_context_make_current(IntPtr raw);

		// Token: 0x020002C2 RID: 706
		// (Invoke) Token: 0x0600118D RID: 4493
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_gl_context_realize(IntPtr raw, out IntPtr error);

		// Token: 0x020002C3 RID: 707
		// (Invoke) Token: 0x06001191 RID: 4497
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_gl_context_set_required_version(IntPtr raw, int major, int minor);

		// Token: 0x020002C4 RID: 708
		// (Invoke) Token: 0x06001195 RID: 4501
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_gl_context_set_use_es(IntPtr raw, int use_es);
	}
}
