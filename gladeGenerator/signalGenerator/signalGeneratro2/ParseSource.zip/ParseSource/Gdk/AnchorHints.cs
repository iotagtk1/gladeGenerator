﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000039 RID: 57
	[Flags]
	[GType(typeof(AnchorHintsGType))]
	public enum AnchorHints
	{
		// Token: 0x04000104 RID: 260
		FlipX = 1,
		// Token: 0x04000105 RID: 261
		FlipY = 2,
		// Token: 0x04000106 RID: 262
		SlideX = 4,
		// Token: 0x04000107 RID: 263
		SlideY = 8,
		// Token: 0x04000108 RID: 264
		ResizeX = 16,
		// Token: 0x04000109 RID: 265
		ResizeY = 32,
		// Token: 0x0400010A RID: 266
		Flip = 3,
		// Token: 0x0400010B RID: 267
		Slide = 12,
		// Token: 0x0400010C RID: 268
		Resize = 48
	}
}
