﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x0200010D RID: 269
	public class ToolChangedArgs : SignalArgs
	{
		// Token: 0x17000296 RID: 662
		// (get) Token: 0x06000A3D RID: 2621 RVA: 0x0001DF08 File Offset: 0x0001C108
		public DeviceTool P0
		{
			get
			{
				return (DeviceTool)base.Args[0];
			}
		}
	}
}
