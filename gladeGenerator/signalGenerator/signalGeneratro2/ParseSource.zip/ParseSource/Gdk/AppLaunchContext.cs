﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200003B RID: 59
	public class AppLaunchContext : AppLaunchContext
	{
		// Token: 0x0600037C RID: 892 RVA: 0x0000B595 File Offset: 0x00009795
		public AppLaunchContext(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x0600037D RID: 893 RVA: 0x0000B5A0 File Offset: 0x000097A0
		public AppLaunchContext() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(AppLaunchContext))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = AppLaunchContext.gdk_app_launch_context_new();
		}

		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x0600037E RID: 894 RVA: 0x0000B5F4 File Offset: 0x000097F4
		// (set) Token: 0x0600037F RID: 895 RVA: 0x0000B61F File Offset: 0x0000981F
		[Obsolete]
		[Property("display")]
		public Display Display
		{
			get
			{
				Value property = base.GetProperty("display");
				Display result = (Display)((Object)property);
				property.Dispose();
				return result;
			}
			set
			{
				AppLaunchContext.gdk_app_launch_context_set_display(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x06000380 RID: 896 RVA: 0x0000B644 File Offset: 0x00009844
		public new static GType GType
		{
			get
			{
				IntPtr val = AppLaunchContext.gdk_app_launch_context_get_type();
				return new GType(val);
			}
		}

		// Token: 0x170000E9 RID: 233
		// (set) Token: 0x06000381 RID: 897 RVA: 0x0000B662 File Offset: 0x00009862
		public int Desktop
		{
			set
			{
				AppLaunchContext.gdk_app_launch_context_set_desktop(base.Handle, value);
			}
		}

		// Token: 0x170000EA RID: 234
		// (set) Token: 0x06000382 RID: 898 RVA: 0x0000B675 File Offset: 0x00009875
		public IIcon Icon
		{
			set
			{
				AppLaunchContext.gdk_app_launch_context_set_icon(base.Handle, (value == null) ? IntPtr.Zero : ((value is Object) ? (value as Object).Handle : (value as IconAdapter).Handle));
			}
		}

		// Token: 0x170000EB RID: 235
		// (set) Token: 0x06000383 RID: 899 RVA: 0x0000B6B4 File Offset: 0x000098B4
		public string IconName
		{
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				AppLaunchContext.gdk_app_launch_context_set_icon_name(base.Handle, intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x170000EC RID: 236
		// (set) Token: 0x06000384 RID: 900 RVA: 0x0000B6DF File Offset: 0x000098DF
		public Screen Screen
		{
			set
			{
				AppLaunchContext.gdk_app_launch_context_set_screen(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x170000ED RID: 237
		// (set) Token: 0x06000385 RID: 901 RVA: 0x0000B701 File Offset: 0x00009901
		public uint Timestamp
		{
			set
			{
				AppLaunchContext.gdk_app_launch_context_set_timestamp(base.Handle, value);
			}
		}

		// Token: 0x0400010E RID: 270
		private static AppLaunchContext.d_gdk_app_launch_context_new gdk_app_launch_context_new = FuncLoader.LoadFunction<AppLaunchContext.d_gdk_app_launch_context_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_app_launch_context_new"));

		// Token: 0x0400010F RID: 271
		private static AppLaunchContext.d_gdk_app_launch_context_set_display gdk_app_launch_context_set_display = FuncLoader.LoadFunction<AppLaunchContext.d_gdk_app_launch_context_set_display>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_app_launch_context_set_display"));

		// Token: 0x04000110 RID: 272
		private static AppLaunchContext.d_gdk_app_launch_context_get_type gdk_app_launch_context_get_type = FuncLoader.LoadFunction<AppLaunchContext.d_gdk_app_launch_context_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_app_launch_context_get_type"));

		// Token: 0x04000111 RID: 273
		private static AppLaunchContext.d_gdk_app_launch_context_set_desktop gdk_app_launch_context_set_desktop = FuncLoader.LoadFunction<AppLaunchContext.d_gdk_app_launch_context_set_desktop>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_app_launch_context_set_desktop"));

		// Token: 0x04000112 RID: 274
		private static AppLaunchContext.d_gdk_app_launch_context_set_icon gdk_app_launch_context_set_icon = FuncLoader.LoadFunction<AppLaunchContext.d_gdk_app_launch_context_set_icon>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_app_launch_context_set_icon"));

		// Token: 0x04000113 RID: 275
		private static AppLaunchContext.d_gdk_app_launch_context_set_icon_name gdk_app_launch_context_set_icon_name = FuncLoader.LoadFunction<AppLaunchContext.d_gdk_app_launch_context_set_icon_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_app_launch_context_set_icon_name"));

		// Token: 0x04000114 RID: 276
		private static AppLaunchContext.d_gdk_app_launch_context_set_screen gdk_app_launch_context_set_screen = FuncLoader.LoadFunction<AppLaunchContext.d_gdk_app_launch_context_set_screen>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_app_launch_context_set_screen"));

		// Token: 0x04000115 RID: 277
		private static AppLaunchContext.d_gdk_app_launch_context_set_timestamp gdk_app_launch_context_set_timestamp = FuncLoader.LoadFunction<AppLaunchContext.d_gdk_app_launch_context_set_timestamp>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_app_launch_context_set_timestamp"));

		// Token: 0x020001EB RID: 491
		// (Invoke) Token: 0x06000E37 RID: 3639
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_app_launch_context_new();

		// Token: 0x020001EC RID: 492
		// (Invoke) Token: 0x06000E3B RID: 3643
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_app_launch_context_set_display(IntPtr raw, IntPtr display);

		// Token: 0x020001ED RID: 493
		// (Invoke) Token: 0x06000E3F RID: 3647
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_app_launch_context_get_type();

		// Token: 0x020001EE RID: 494
		// (Invoke) Token: 0x06000E43 RID: 3651
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_app_launch_context_set_desktop(IntPtr raw, int desktop);

		// Token: 0x020001EF RID: 495
		// (Invoke) Token: 0x06000E47 RID: 3655
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_app_launch_context_set_icon(IntPtr raw, IntPtr icon);

		// Token: 0x020001F0 RID: 496
		// (Invoke) Token: 0x06000E4B RID: 3659
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_app_launch_context_set_icon_name(IntPtr raw, IntPtr icon_name);

		// Token: 0x020001F1 RID: 497
		// (Invoke) Token: 0x06000E4F RID: 3663
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_app_launch_context_set_screen(IntPtr raw, IntPtr screen);

		// Token: 0x020001F2 RID: 498
		// (Invoke) Token: 0x06000E53 RID: 3667
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_app_launch_context_set_timestamp(IntPtr raw, uint timestamp);
	}
}
