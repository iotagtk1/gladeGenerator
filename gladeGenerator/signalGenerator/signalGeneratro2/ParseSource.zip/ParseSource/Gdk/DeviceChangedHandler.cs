﻿using System;

namespace Gdk
{
	// Token: 0x02000059 RID: 89
	// (Invoke) Token: 0x060003E8 RID: 1000
	public delegate void DeviceChangedHandler(object o, DeviceChangedArgs args);
}
