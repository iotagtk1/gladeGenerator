﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000E7 RID: 231
	internal class PropertyStateGType
	{
		// Token: 0x17000237 RID: 567
		// (get) Token: 0x0600089E RID: 2206 RVA: 0x000197CD File Offset: 0x000179CD
		public static GType GType
		{
			get
			{
				return new GType(PropertyStateGType.gdk_property_state_get_type());
			}
		}

		// Token: 0x040004EA RID: 1258
		private static PropertyStateGType.d_gdk_property_state_get_type gdk_property_state_get_type = FuncLoader.LoadFunction<PropertyStateGType.d_gdk_property_state_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_property_state_get_type"));

		// Token: 0x020003A7 RID: 935
		// (Invoke) Token: 0x0600151E RID: 5406
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_property_state_get_type();
	}
}
