﻿using System;
using System.Runtime.InteropServices;

namespace Gdk
{
	// Token: 0x02000027 RID: 39
	public class EventConfigure : Event
	{
		// Token: 0x060002C8 RID: 712 RVA: 0x0000A1C9 File Offset: 0x000083C9
		public EventConfigure(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x060002C9 RID: 713 RVA: 0x0000A1D2 File Offset: 0x000083D2
		private EventConfigure.NativeStruct Native
		{
			get
			{
				return (EventConfigure.NativeStruct)Marshal.PtrToStructure(base.Handle, typeof(EventConfigure.NativeStruct));
			}
		}

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x060002CA RID: 714 RVA: 0x0000A1EE File Offset: 0x000083EE
		// (set) Token: 0x060002CB RID: 715 RVA: 0x0000A1FC File Offset: 0x000083FC
		public int Height
		{
			get
			{
				return this.Native.height;
			}
			set
			{
				EventConfigure.NativeStruct native = this.Native;
				native.height = value;
				Marshal.StructureToPtr<EventConfigure.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x060002CC RID: 716 RVA: 0x0000A225 File Offset: 0x00008425
		// (set) Token: 0x060002CD RID: 717 RVA: 0x0000A234 File Offset: 0x00008434
		public int Width
		{
			get
			{
				return this.Native.width;
			}
			set
			{
				EventConfigure.NativeStruct native = this.Native;
				native.width = value;
				Marshal.StructureToPtr<EventConfigure.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x060002CE RID: 718 RVA: 0x0000A25D File Offset: 0x0000845D
		// (set) Token: 0x060002CF RID: 719 RVA: 0x0000A26C File Offset: 0x0000846C
		public int X
		{
			get
			{
				return this.Native.x;
			}
			set
			{
				EventConfigure.NativeStruct native = this.Native;
				native.x = value;
				Marshal.StructureToPtr<EventConfigure.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x060002D0 RID: 720 RVA: 0x0000A295 File Offset: 0x00008495
		// (set) Token: 0x060002D1 RID: 721 RVA: 0x0000A2A4 File Offset: 0x000084A4
		public int Y
		{
			get
			{
				return this.Native.y;
			}
			set
			{
				EventConfigure.NativeStruct native = this.Native;
				native.y = value;
				Marshal.StructureToPtr<EventConfigure.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x020001DA RID: 474
		private struct NativeStruct
		{
			// Token: 0x04000C1B RID: 3099
			private EventType type;

			// Token: 0x04000C1C RID: 3100
			private IntPtr window;

			// Token: 0x04000C1D RID: 3101
			private sbyte send_event;

			// Token: 0x04000C1E RID: 3102
			public int x;

			// Token: 0x04000C1F RID: 3103
			public int y;

			// Token: 0x04000C20 RID: 3104
			public int width;

			// Token: 0x04000C21 RID: 3105
			public int height;
		}
	}
}
