﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000033 RID: 51
	public class EventSelection : Event
	{
		// Token: 0x06000357 RID: 855 RVA: 0x0000B1FD File Offset: 0x000093FD
		public EventSelection(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x06000358 RID: 856 RVA: 0x0000B206 File Offset: 0x00009406
		private EventSelection.NativeStruct Native
		{
			get
			{
				return (EventSelection.NativeStruct)Marshal.PtrToStructure(base.Handle, typeof(EventSelection.NativeStruct));
			}
		}

		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x06000359 RID: 857 RVA: 0x0000B222 File Offset: 0x00009422
		// (set) Token: 0x0600035A RID: 858 RVA: 0x0000B244 File Offset: 0x00009444
		public Atom Property
		{
			get
			{
				return Opaque.GetOpaque(this.Native.property, typeof(Atom), false) as Atom;
			}
			set
			{
				EventSelection.NativeStruct native = this.Native;
				native.property = ((value == null) ? IntPtr.Zero : value.Handle);
				Marshal.StructureToPtr<EventSelection.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x0600035B RID: 859 RVA: 0x0000B27C File Offset: 0x0000947C
		// (set) Token: 0x0600035C RID: 860 RVA: 0x0000B28C File Offset: 0x0000948C
		public uint Requestor
		{
			get
			{
				return this.Native.requestor;
			}
			set
			{
				EventSelection.NativeStruct native = this.Native;
				native.requestor = value;
				Marshal.StructureToPtr<EventSelection.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000DA RID: 218
		// (get) Token: 0x0600035D RID: 861 RVA: 0x0000B2B5 File Offset: 0x000094B5
		// (set) Token: 0x0600035E RID: 862 RVA: 0x0000B2D8 File Offset: 0x000094D8
		public Atom Selection
		{
			get
			{
				return Opaque.GetOpaque(this.Native.selection, typeof(Atom), false) as Atom;
			}
			set
			{
				EventSelection.NativeStruct native = this.Native;
				native.selection = ((value == null) ? IntPtr.Zero : value.Handle);
				Marshal.StructureToPtr<EventSelection.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000DB RID: 219
		// (get) Token: 0x0600035F RID: 863 RVA: 0x0000B310 File Offset: 0x00009510
		// (set) Token: 0x06000360 RID: 864 RVA: 0x0000B334 File Offset: 0x00009534
		public Atom Target
		{
			get
			{
				return Opaque.GetOpaque(this.Native.target, typeof(Atom), false) as Atom;
			}
			set
			{
				EventSelection.NativeStruct native = this.Native;
				native.target = value.Handle;
				native.target = ((value == null) ? IntPtr.Zero : value.Handle);
				Marshal.StructureToPtr<EventSelection.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000DC RID: 220
		// (get) Token: 0x06000361 RID: 865 RVA: 0x0000B379 File Offset: 0x00009579
		// (set) Token: 0x06000362 RID: 866 RVA: 0x0000B388 File Offset: 0x00009588
		public uint Time
		{
			get
			{
				return this.Native.time;
			}
			set
			{
				EventSelection.NativeStruct native = this.Native;
				native.time = value;
				Marshal.StructureToPtr<EventSelection.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x020001E6 RID: 486
		private struct NativeStruct
		{
			// Token: 0x04000C7C RID: 3196
			private EventType type;

			// Token: 0x04000C7D RID: 3197
			private IntPtr window;

			// Token: 0x04000C7E RID: 3198
			private sbyte send_event;

			// Token: 0x04000C7F RID: 3199
			public IntPtr selection;

			// Token: 0x04000C80 RID: 3200
			public IntPtr target;

			// Token: 0x04000C81 RID: 3201
			public IntPtr property;

			// Token: 0x04000C82 RID: 3202
			public uint time;

			// Token: 0x04000C83 RID: 3203
			public uint requestor;
		}
	}
}
