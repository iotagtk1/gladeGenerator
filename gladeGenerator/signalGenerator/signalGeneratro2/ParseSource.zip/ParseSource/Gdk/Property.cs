﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000E5 RID: 229
	public class Property
	{
		// Token: 0x06000891 RID: 2193 RVA: 0x00019378 File Offset: 0x00017578
		public static void Change(Window window, Atom property, Atom type, int format, PropMode mode, byte[] data, int nelements)
		{
			Property.gdk_property_change((window == null) ? IntPtr.Zero : window.Handle, (property == null) ? IntPtr.Zero : property.Handle, (type == null) ? IntPtr.Zero : type.Handle, format, (int)mode, data, nelements);
		}

		// Token: 0x06000892 RID: 2194 RVA: 0x000193C6 File Offset: 0x000175C6
		public static void Delete(Window window, Atom property)
		{
			Property.gdk_property_delete((window == null) ? IntPtr.Zero : window.Handle, (property == null) ? IntPtr.Zero : property.Handle);
		}

		// Token: 0x06000893 RID: 2195 RVA: 0x000193F4 File Offset: 0x000175F4
		[Obsolete("Replaced by corrected overload with data parameter")]
		public static byte Change(Window window, Atom property, Atom type, int format, PropMode mode, int nelements)
		{
			byte result;
			Property.gdk_property_change2((window == null) ? IntPtr.Zero : window.Handle, (property == null) ? IntPtr.Zero : property.Handle, (type == null) ? IntPtr.Zero : type.Handle, format, (int)mode, out result, nelements);
			return result;
		}

		// Token: 0x06000894 RID: 2196 RVA: 0x00019444 File Offset: 0x00017644
		public static bool Get(Window window, Atom property, Atom type, ulong offset, ulong length, int pdelete, out Atom actual_property_type, out int actual_format, out int actual_length, out byte[] data)
		{
			IntPtr intPtr;
			IntPtr intPtr2;
			bool flag = Property.gdk_property_get((window == null) ? IntPtr.Zero : window.Handle, (property == null) ? IntPtr.Zero : property.Handle, (type == null) ? IntPtr.Zero : type.Handle, new UIntPtr(offset), new UIntPtr(length), pdelete != 0, out intPtr, out actual_format, out actual_length, out intPtr2);
			data = null;
			if (flag)
			{
				data = new byte[actual_length];
				Marshal.Copy(intPtr2, data, 0, actual_length);
				Marshaller.Free(intPtr2);
			}
			actual_property_type = ((intPtr == IntPtr.Zero) ? null : ((Atom)Opaque.GetOpaque(intPtr, typeof(Atom), false)));
			return flag;
		}

		// Token: 0x06000895 RID: 2197 RVA: 0x000194F8 File Offset: 0x000176F8
		public static bool Get(Window window, Atom property, Atom type, ulong offset, ulong length, bool pdelete, out int[] data)
		{
			IntPtr intPtr;
			int num;
			int num2;
			IntPtr ptr;
			bool flag = Property.gdk_property_get((window == null) ? IntPtr.Zero : window.Handle, (property == null) ? IntPtr.Zero : property.Handle, (type == null) ? IntPtr.Zero : type.Handle, new UIntPtr(offset), new UIntPtr(length), pdelete, out intPtr, out num, out num2, out ptr);
			if (flag)
			{
				try
				{
					int num3;
					if (num == 32)
					{
						num3 = IntPtr.Size;
					}
					else
					{
						if (num != 8 && num != 16)
						{
							throw new NotSupportedException(string.Format("Unable to read properties in {0}-bit format", num));
						}
						num3 = num;
					}
					int num4 = num2 / num3;
					data = new int[num4];
					for (int i = 0; i < num4; i++)
					{
						IntPtr ptr2 = new IntPtr(ptr.ToInt64() + (long)(i * num3));
						if (num != 8)
						{
							if (num != 16)
							{
								if (num == 32)
								{
									data[i] = Marshal.ReadInt32(ptr2);
								}
							}
							else
							{
								data[i] = (int)Marshal.ReadInt16(ptr2);
							}
						}
						else
						{
							data[i] = (int)Marshal.ReadByte(ptr2);
						}
					}
					return flag;
				}
				finally
				{
					Marshaller.Free(ptr);
				}
			}
			data = null;
			return flag;
		}

		// Token: 0x06000896 RID: 2198 RVA: 0x00019624 File Offset: 0x00017824
		public static bool Get(Window window, Atom property, bool pdelete, out int[] data)
		{
			return Property.Get(window, property, 0UL, (ulong)-4, pdelete, out data);
		}

		// Token: 0x06000897 RID: 2199 RVA: 0x00019634 File Offset: 0x00017834
		public static bool Get(Window window, Atom property, ulong offset, ulong length, bool pdelete, out int[] data)
		{
			return Property.Get(window, property, Atom.Intern("CARDINAL", false), offset, length, pdelete, out data);
		}

		// Token: 0x06000898 RID: 2200 RVA: 0x0001964E File Offset: 0x0001784E
		public static bool Get(Window window, Atom property, bool pdelete, out Atom[] data)
		{
			return Property.Get(window, property, 0UL, (ulong)-4, pdelete, out data);
		}

		// Token: 0x06000899 RID: 2201 RVA: 0x00019660 File Offset: 0x00017860
		public static bool Get(Window window, Atom property, ulong offset, ulong length, bool pdelete, out Atom[] atoms)
		{
			int[] array;
			if (!Property.Get(window, property, Atom.Intern("ATOM", false), offset, length, pdelete, out array))
			{
				atoms = null;
				return false;
			}
			atoms = new Atom[array.GetLength(0)];
			for (int i = 0; i < array.GetLength(0); i++)
			{
				atoms[i] = new Atom(new IntPtr(array[i]));
			}
			return true;
		}

		// Token: 0x0600089A RID: 2202 RVA: 0x000196C1 File Offset: 0x000178C1
		public static bool Get(Window window, Atom property, bool pdelete, out Rectangle[] rects)
		{
			return Property.Get(window, property, 0UL, (ulong)-4, pdelete, out rects);
		}

		// Token: 0x0600089B RID: 2203 RVA: 0x000196D4 File Offset: 0x000178D4
		public static bool Get(Window window, Atom property, ulong offset, ulong length, bool pdelete, out Rectangle[] rects)
		{
			int[] array;
			if (!Property.Get(window, property, Atom.Intern("CARDINAL", false), offset, length, pdelete, out array))
			{
				rects = null;
				return false;
			}
			rects = new Rectangle[array.GetLength(0) / 4];
			for (int i = 0; i < rects.GetLength(0); i++)
			{
				rects[i] = new Rectangle(array[i * 4], array[i * 4 + 1], array[i * 4 + 2], array[i * 4 + 3]);
			}
			return true;
		}

		// Token: 0x040004E3 RID: 1251
		private static Property.d_gdk_property_change gdk_property_change = FuncLoader.LoadFunction<Property.d_gdk_property_change>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_property_change"));

		// Token: 0x040004E4 RID: 1252
		private static Property.d_gdk_property_delete gdk_property_delete = FuncLoader.LoadFunction<Property.d_gdk_property_delete>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_property_delete"));

		// Token: 0x040004E5 RID: 1253
		private static Property.d_gdk_property_change2 gdk_property_change2 = FuncLoader.LoadFunction<Property.d_gdk_property_change2>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_property_change"));

		// Token: 0x040004E6 RID: 1254
		private static Property.d_gdk_property_get gdk_property_get = FuncLoader.LoadFunction<Property.d_gdk_property_get>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_property_get"));

		// Token: 0x020003A3 RID: 931
		// (Invoke) Token: 0x0600150E RID: 5390
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_property_change(IntPtr window, IntPtr property, IntPtr type, int format, int mode, byte[] data, int nelements);

		// Token: 0x020003A4 RID: 932
		// (Invoke) Token: 0x06001512 RID: 5394
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_property_delete(IntPtr window, IntPtr property);

		// Token: 0x020003A5 RID: 933
		// (Invoke) Token: 0x06001516 RID: 5398
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_property_change2(IntPtr window, IntPtr property, IntPtr type, int format, int mode, out byte data, int nelements);

		// Token: 0x020003A6 RID: 934
		// (Invoke) Token: 0x0600151A RID: 5402
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_property_get(IntPtr window, IntPtr property, IntPtr type, UIntPtr offset, UIntPtr length, bool pdelete, out IntPtr actual_property_type, out int actual_format, out int actual_length, out IntPtr data);
	}
}
