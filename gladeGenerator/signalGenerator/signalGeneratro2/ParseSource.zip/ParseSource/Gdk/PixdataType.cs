﻿using System;

namespace Gdk
{
	// Token: 0x020000E1 RID: 225
	[Flags]
	public enum PixdataType
	{
		// Token: 0x040004D4 RID: 1236
		ColorTypeRgb = 1,
		// Token: 0x040004D5 RID: 1237
		ColorTypeRgba = 2,
		// Token: 0x040004D6 RID: 1238
		ColorTypeMask = 255,
		// Token: 0x040004D7 RID: 1239
		SampleWidth8 = 65536,
		// Token: 0x040004D8 RID: 1240
		SampleWidthMask = 983040,
		// Token: 0x040004D9 RID: 1241
		EncodingRaw = 16777216,
		// Token: 0x040004DA RID: 1242
		EncodingRle = 33554432,
		// Token: 0x040004DB RID: 1243
		EncodingMask = 251658240
	}
}
