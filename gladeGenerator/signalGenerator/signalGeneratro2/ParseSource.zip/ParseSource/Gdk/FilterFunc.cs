﻿using System;

namespace Gdk
{
	// Token: 0x02000084 RID: 132
	// (Invoke) Token: 0x0600057C RID: 1404
	public delegate FilterReturn FilterFunc(IntPtr xevent, Event evnt);
}
