﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200012E RID: 302
	public struct Rectangle
	{
		// Token: 0x06000B64 RID: 2916 RVA: 0x000216DC File Offset: 0x0001F8DC
		public Rectangle(int x, int y, int width, int height)
		{
			this.X = x;
			this.Y = y;
			this.Width = width;
			this.Height = height;
		}

		// Token: 0x06000B65 RID: 2917 RVA: 0x000216FB File Offset: 0x0001F8FB
		public Rectangle(Point loc, Size sz)
		{
			this = new Rectangle(loc.X, loc.Y, sz.Width, sz.Height);
		}

		// Token: 0x06000B66 RID: 2918 RVA: 0x0002171D File Offset: 0x0001F91D
		public static Rectangle FromLTRB(int left, int top, int right, int bottom)
		{
			return new Rectangle(left, top, right - left, bottom - top);
		}

		// Token: 0x06000B67 RID: 2919 RVA: 0x0002172C File Offset: 0x0001F92C
		public override bool Equals(object o)
		{
			return o is Rectangle && this == (Rectangle)o;
		}

		// Token: 0x06000B68 RID: 2920 RVA: 0x00021749 File Offset: 0x0001F949
		public override int GetHashCode()
		{
			return this.Height + this.Width ^ this.X + this.Y;
		}

		// Token: 0x06000B69 RID: 2921 RVA: 0x00021766 File Offset: 0x0001F966
		public static bool operator ==(Rectangle r1, Rectangle r2)
		{
			return r1.Location == r2.Location && r1.Size == r2.Size;
		}

		// Token: 0x06000B6A RID: 2922 RVA: 0x00021792 File Offset: 0x0001F992
		public static bool operator !=(Rectangle r1, Rectangle r2)
		{
			return !(r1 == r2);
		}

		// Token: 0x06000B6B RID: 2923 RVA: 0x000217A0 File Offset: 0x0001F9A0
		public static explicit operator Value(Rectangle boxed)
		{
			Value empty = Value.Empty;
			empty.Init(Rectangle.GType);
			empty.Val = boxed;
			return empty;
		}

		// Token: 0x06000B6C RID: 2924 RVA: 0x000217CD File Offset: 0x0001F9CD
		public static explicit operator Rectangle(Value val)
		{
			return (Rectangle)val.Val;
		}

		// Token: 0x06000B6D RID: 2925 RVA: 0x000217DC File Offset: 0x0001F9DC
		public override string ToString()
		{
			return string.Format("{0}x{1}+{2}+{3}", new object[]
			{
				this.Width,
				this.Height,
				this.X,
				this.Y
			});
		}

		// Token: 0x06000B6E RID: 2926 RVA: 0x00021831 File Offset: 0x0001FA31
		public bool Contains(Rectangle rect)
		{
			return rect == Rectangle.Intersect(this, rect);
		}

		// Token: 0x06000B6F RID: 2927 RVA: 0x00021845 File Offset: 0x0001FA45
		public bool Contains(Point pt)
		{
			return this.Contains(pt.X, pt.Y);
		}

		// Token: 0x06000B70 RID: 2928 RVA: 0x00021859 File Offset: 0x0001FA59
		public bool Contains(int x, int y)
		{
			return x >= this.Left && x <= this.Right && y >= this.Top && y <= this.Bottom;
		}

		// Token: 0x06000B71 RID: 2929 RVA: 0x00021884 File Offset: 0x0001FA84
		public bool IntersectsWith(Rectangle r)
		{
			return this.Left <= r.Right && this.Right >= r.Left && this.Top <= r.Bottom && this.Bottom >= r.Top;
		}

		// Token: 0x06000B72 RID: 2930 RVA: 0x000218D4 File Offset: 0x0001FAD4
		public static Rectangle Union(Rectangle r1, Rectangle r2)
		{
			return Rectangle.FromLTRB(Math.Min(r1.Left, r2.Left), Math.Min(r1.Top, r2.Top), Math.Max(r1.Right, r2.Right), Math.Max(r1.Bottom, r2.Bottom));
		}

		// Token: 0x06000B73 RID: 2931 RVA: 0x00021932 File Offset: 0x0001FB32
		public void Intersect(Rectangle r)
		{
			this = Rectangle.Intersect(this, r);
		}

		// Token: 0x06000B74 RID: 2932 RVA: 0x00021948 File Offset: 0x0001FB48
		public static Rectangle Intersect(Rectangle r1, Rectangle r2)
		{
			Rectangle result;
			if (!r1.Intersect(r2, out result))
			{
				return default(Rectangle);
			}
			return result;
		}

		// Token: 0x170002FA RID: 762
		// (get) Token: 0x06000B75 RID: 2933 RVA: 0x0002196C File Offset: 0x0001FB6C
		public int Top
		{
			get
			{
				return this.Y;
			}
		}

		// Token: 0x170002FB RID: 763
		// (get) Token: 0x06000B76 RID: 2934 RVA: 0x00021974 File Offset: 0x0001FB74
		public int Bottom
		{
			get
			{
				return this.Y + this.Height - 1;
			}
		}

		// Token: 0x170002FC RID: 764
		// (get) Token: 0x06000B77 RID: 2935 RVA: 0x00021985 File Offset: 0x0001FB85
		public int Right
		{
			get
			{
				return this.X + this.Width - 1;
			}
		}

		// Token: 0x170002FD RID: 765
		// (get) Token: 0x06000B78 RID: 2936 RVA: 0x00021996 File Offset: 0x0001FB96
		public int Left
		{
			get
			{
				return this.X;
			}
		}

		// Token: 0x170002FE RID: 766
		// (get) Token: 0x06000B79 RID: 2937 RVA: 0x0002199E File Offset: 0x0001FB9E
		public bool IsEmpty
		{
			get
			{
				return this.Width == 0 || this.Height == 0;
			}
		}

		// Token: 0x170002FF RID: 767
		// (get) Token: 0x06000B7A RID: 2938 RVA: 0x000219B3 File Offset: 0x0001FBB3
		// (set) Token: 0x06000B7B RID: 2939 RVA: 0x000219C6 File Offset: 0x0001FBC6
		public Size Size
		{
			get
			{
				return new Size(this.Width, this.Height);
			}
			set
			{
				this.Width = value.Width;
				this.Height = value.Height;
			}
		}

		// Token: 0x17000300 RID: 768
		// (get) Token: 0x06000B7C RID: 2940 RVA: 0x000219E2 File Offset: 0x0001FBE2
		// (set) Token: 0x06000B7D RID: 2941 RVA: 0x000219F5 File Offset: 0x0001FBF5
		public Point Location
		{
			get
			{
				return new Point(this.X, this.Y);
			}
			set
			{
				this.X = value.X;
				this.Y = value.Y;
			}
		}

		// Token: 0x06000B7E RID: 2942 RVA: 0x00021A0F File Offset: 0x0001FC0F
		public void Inflate(Size sz)
		{
			this.Inflate(sz.Width, sz.Height);
		}

		// Token: 0x06000B7F RID: 2943 RVA: 0x00021A25 File Offset: 0x0001FC25
		public void Inflate(int width, int height)
		{
			this.X -= width;
			this.Y -= height;
			this.Width += width * 2;
			this.Height += height * 2;
		}

		// Token: 0x06000B80 RID: 2944 RVA: 0x00021A64 File Offset: 0x0001FC64
		public static Rectangle Inflate(Rectangle rect, int x, int y)
		{
			Rectangle result = rect;
			result.Inflate(x, y);
			return result;
		}

		// Token: 0x06000B81 RID: 2945 RVA: 0x00021A7D File Offset: 0x0001FC7D
		public static Rectangle Inflate(Rectangle rect, Size sz)
		{
			return Rectangle.Inflate(rect, sz.Width, sz.Height);
		}

		// Token: 0x06000B82 RID: 2946 RVA: 0x00021A93 File Offset: 0x0001FC93
		public void Offset(int dx, int dy)
		{
			this.X += dx;
			this.Y += dy;
		}

		// Token: 0x06000B83 RID: 2947 RVA: 0x00021AB1 File Offset: 0x0001FCB1
		public void Offset(Point dr)
		{
			this.Offset(dr.X, dr.Y);
		}

		// Token: 0x06000B84 RID: 2948 RVA: 0x00021AC8 File Offset: 0x0001FCC8
		public static Rectangle Offset(Rectangle rect, int dx, int dy)
		{
			Rectangle result = rect;
			result.Offset(dx, dy);
			return result;
		}

		// Token: 0x06000B85 RID: 2949 RVA: 0x00021AE1 File Offset: 0x0001FCE1
		public static Rectangle Offset(Rectangle rect, Point dr)
		{
			return Rectangle.Offset(rect, dr.X, dr.Y);
		}

		// Token: 0x17000301 RID: 769
		// (get) Token: 0x06000B86 RID: 2950 RVA: 0x00021AF8 File Offset: 0x0001FCF8
		public static GType GType
		{
			get
			{
				IntPtr val = Rectangle.gdk_rectangle_get_type();
				return new GType(val);
			}
		}

		// Token: 0x06000B87 RID: 2951 RVA: 0x00021B18 File Offset: 0x0001FD18
		public Rectangle Union(Rectangle src)
		{
			Rectangle result;
			Rectangle.gdk_rectangle_union(ref this, ref src, out result);
			return result;
		}

		// Token: 0x06000B88 RID: 2952 RVA: 0x00021B35 File Offset: 0x0001FD35
		public bool Intersect(Rectangle src, out Rectangle dest)
		{
			return Rectangle.gdk_rectangle_intersect(ref this, ref src, out dest);
		}

		// Token: 0x06000B89 RID: 2953 RVA: 0x00021B45 File Offset: 0x0001FD45
		public static Rectangle New(IntPtr raw)
		{
			return (Rectangle)Marshal.PtrToStructure(raw, typeof(Rectangle));
		}

		// Token: 0x04000BFE RID: 3070
		public int X;

		// Token: 0x04000BFF RID: 3071
		public int Y;

		// Token: 0x04000C00 RID: 3072
		public int Width;

		// Token: 0x04000C01 RID: 3073
		public int Height;

		// Token: 0x04000C02 RID: 3074
		private static Rectangle.d_gdk_rectangle_get_type gdk_rectangle_get_type = FuncLoader.LoadFunction<Rectangle.d_gdk_rectangle_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_rectangle_get_type"));

		// Token: 0x04000C03 RID: 3075
		private static Rectangle.d_gdk_rectangle_union gdk_rectangle_union = FuncLoader.LoadFunction<Rectangle.d_gdk_rectangle_union>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_rectangle_union"));

		// Token: 0x04000C04 RID: 3076
		private static Rectangle.d_gdk_rectangle_intersect gdk_rectangle_intersect = FuncLoader.LoadFunction<Rectangle.d_gdk_rectangle_intersect>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_rectangle_intersect"));

		// Token: 0x04000C05 RID: 3077
		public static Rectangle Zero;

		// Token: 0x020004D4 RID: 1236
		// (Invoke) Token: 0x060019D2 RID: 6610
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_rectangle_get_type();

		// Token: 0x020004D5 RID: 1237
		// (Invoke) Token: 0x060019D6 RID: 6614
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_rectangle_union(ref Rectangle src1, ref Rectangle src2, out Rectangle dest);

		// Token: 0x020004D6 RID: 1238
		// (Invoke) Token: 0x060019DA RID: 6618
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_rectangle_intersect(ref Rectangle src1, ref Rectangle src2, out Rectangle dest);
	}
}
