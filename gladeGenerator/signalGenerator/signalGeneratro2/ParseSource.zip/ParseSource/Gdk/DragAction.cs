﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000069 RID: 105
	[Flags]
	[GType(typeof(DragActionGType))]
	public enum DragAction
	{
		// Token: 0x040001E9 RID: 489
		Default = 1,
		// Token: 0x040001EA RID: 490
		Copy = 2,
		// Token: 0x040001EB RID: 491
		Move = 4,
		// Token: 0x040001EC RID: 492
		Link = 8,
		// Token: 0x040001ED RID: 493
		Private = 16,
		// Token: 0x040001EE RID: 494
		Ask = 32
	}
}
