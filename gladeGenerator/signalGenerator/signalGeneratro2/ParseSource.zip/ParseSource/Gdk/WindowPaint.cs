﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x0200011F RID: 287
	public class WindowPaint : Opaque
	{
		// Token: 0x06000B50 RID: 2896 RVA: 0x00021570 File Offset: 0x0001F770
		public WindowPaint(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170002F2 RID: 754
		// (get) Token: 0x06000B51 RID: 2897 RVA: 0x00021579 File Offset: 0x0001F779
		public static AbiStruct abi_info
		{
			get
			{
				if (WindowPaint._abi_info == null)
				{
					WindowPaint._abi_info = new AbiStruct(new List<AbiField>());
				}
				return WindowPaint._abi_info;
			}
		}

		// Token: 0x0400068B RID: 1675
		private static AbiStruct _abi_info;
	}
}
