﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000D1 RID: 209
	public class PixbufGifAnimIter : PixbufAnimationIter
	{
		// Token: 0x06000810 RID: 2064 RVA: 0x00017FC4 File Offset: 0x000161C4
		public PixbufGifAnimIter(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000811 RID: 2065 RVA: 0x00017FCD File Offset: 0x000161CD
		protected PixbufGifAnimIter() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x17000219 RID: 537
		// (get) Token: 0x06000812 RID: 2066 RVA: 0x00017FEC File Offset: 0x000161EC
		public new static GType GType
		{
			get
			{
				IntPtr val = PixbufGifAnimIter.gdk_pixbuf_gif_anim_iter_get_type();
				return new GType(val);
			}
		}

		// Token: 0x0400049A RID: 1178
		private static PixbufGifAnimIter.d_gdk_pixbuf_gif_anim_iter_get_type gdk_pixbuf_gif_anim_iter_get_type = FuncLoader.LoadFunction<PixbufGifAnimIter.d_gdk_pixbuf_gif_anim_iter_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_gif_anim_iter_get_type"));

		// Token: 0x02000387 RID: 903
		// (Invoke) Token: 0x0600149E RID: 5278
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_gif_anim_iter_get_type();
	}
}
