﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x02000090 RID: 144
	public class GdipContext : Opaque
	{
		// Token: 0x0600060F RID: 1551 RVA: 0x00011F7A File Offset: 0x0001017A
		public GdipContext(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700018A RID: 394
		// (get) Token: 0x06000610 RID: 1552 RVA: 0x00011F83 File Offset: 0x00010183
		public static AbiStruct abi_info
		{
			get
			{
				if (GdipContext._abi_info == null)
				{
					GdipContext._abi_info = new AbiStruct(new List<AbiField>());
				}
				return GdipContext._abi_info;
			}
		}

		// Token: 0x04000325 RID: 805
		private static AbiStruct _abi_info;
	}
}
