﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000114 RID: 276
	internal class VisualTypeGType
	{
		// Token: 0x170002A6 RID: 678
		// (get) Token: 0x06000A5B RID: 2651 RVA: 0x0001E327 File Offset: 0x0001C527
		public static GType GType
		{
			get
			{
				return new GType(VisualTypeGType.gdk_visual_type_get_type());
			}
		}

		// Token: 0x040005B6 RID: 1462
		private static VisualTypeGType.d_gdk_visual_type_get_type gdk_visual_type_get_type = FuncLoader.LoadFunction<VisualTypeGType.d_gdk_visual_type_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_visual_type_get_type"));

		// Token: 0x02000426 RID: 1062
		// (Invoke) Token: 0x0600171A RID: 5914
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_visual_type_get_type();
	}
}
