﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000068 RID: 104
	public class Drag
	{
		// Token: 0x0600044D RID: 1101 RVA: 0x0000D2AE File Offset: 0x0000B4AE
		public static void Abort(DragContext context, uint time_)
		{
			Drag.gdk_drag_abort((context == null) ? IntPtr.Zero : context.Handle, time_);
		}

		// Token: 0x0600044E RID: 1102 RVA: 0x0000D2CC File Offset: 0x0000B4CC
		public static DragContext BeginForDevice(Window window, Device device, List targets)
		{
			return Object.GetObject(Drag.gdk_drag_begin_for_device((window == null) ? IntPtr.Zero : window.Handle, (device == null) ? IntPtr.Zero : device.Handle, (targets == null) ? IntPtr.Zero : targets.Handle)) as DragContext;
		}

		// Token: 0x0600044F RID: 1103 RVA: 0x0000D320 File Offset: 0x0000B520
		public static DragContext BeginFromPoint(Window window, Device device, List targets, int x_root, int y_root)
		{
			return Object.GetObject(Drag.gdk_drag_begin_from_point((window == null) ? IntPtr.Zero : window.Handle, (device == null) ? IntPtr.Zero : device.Handle, (targets == null) ? IntPtr.Zero : targets.Handle, x_root, y_root)) as DragContext;
		}

		// Token: 0x06000450 RID: 1104 RVA: 0x0000D374 File Offset: 0x0000B574
		public static void Drop(DragContext context, uint time_)
		{
			Drag.gdk_drag_drop((context == null) ? IntPtr.Zero : context.Handle, time_);
		}

		// Token: 0x06000451 RID: 1105 RVA: 0x0000D391 File Offset: 0x0000B591
		public static void DropDone(DragContext context, bool success)
		{
			Drag.gdk_drag_drop_done((context == null) ? IntPtr.Zero : context.Handle, success);
		}

		// Token: 0x06000452 RID: 1106 RVA: 0x0000D3AE File Offset: 0x0000B5AE
		public static bool DropSucceeded(DragContext context)
		{
			return Drag.gdk_drag_drop_succeeded((context == null) ? IntPtr.Zero : context.Handle);
		}

		// Token: 0x06000453 RID: 1107 RVA: 0x0000D3CC File Offset: 0x0000B5CC
		public static void FindWindowForScreen(DragContext context, Window drag_window, Screen screen, int x_root, int y_root, out Window dest_window, out DragProtocol protocol)
		{
			IntPtr o;
			int num;
			Drag.gdk_drag_find_window_for_screen((context == null) ? IntPtr.Zero : context.Handle, (drag_window == null) ? IntPtr.Zero : drag_window.Handle, (screen == null) ? IntPtr.Zero : screen.Handle, x_root, y_root, out o, out num);
			dest_window = (Object.GetObject(o) as Window);
			protocol = (DragProtocol)num;
		}

		// Token: 0x06000454 RID: 1108 RVA: 0x0000D42C File Offset: 0x0000B62C
		public static Atom GetSelection(DragContext context)
		{
			IntPtr intPtr = Drag.gdk_drag_get_selection((context == null) ? IntPtr.Zero : context.Handle);
			if (!(intPtr == IntPtr.Zero))
			{
				return (Atom)Opaque.GetOpaque(intPtr, typeof(Atom), false);
			}
			return null;
		}

		// Token: 0x06000455 RID: 1109 RVA: 0x0000D47C File Offset: 0x0000B67C
		public static bool Motion(DragContext context, Window dest_window, DragProtocol protocol, int x_root, int y_root, DragAction suggested_action, DragAction possible_actions, uint time_)
		{
			return Drag.gdk_drag_motion((context == null) ? IntPtr.Zero : context.Handle, (dest_window == null) ? IntPtr.Zero : dest_window.Handle, (int)protocol, x_root, y_root, (int)suggested_action, (int)possible_actions, time_);
		}

		// Token: 0x06000456 RID: 1110 RVA: 0x0000D4BD File Offset: 0x0000B6BD
		public static void Status(DragContext context, DragAction action, uint time_)
		{
			Drag.gdk_drag_status((context == null) ? IntPtr.Zero : context.Handle, (int)action, time_);
		}

		// Token: 0x040001DE RID: 478
		private static Drag.d_gdk_drag_abort gdk_drag_abort = FuncLoader.LoadFunction<Drag.d_gdk_drag_abort>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_abort"));

		// Token: 0x040001DF RID: 479
		private static Drag.d_gdk_drag_begin_for_device gdk_drag_begin_for_device = FuncLoader.LoadFunction<Drag.d_gdk_drag_begin_for_device>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_begin_for_device"));

		// Token: 0x040001E0 RID: 480
		private static Drag.d_gdk_drag_begin_from_point gdk_drag_begin_from_point = FuncLoader.LoadFunction<Drag.d_gdk_drag_begin_from_point>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_begin_from_point"));

		// Token: 0x040001E1 RID: 481
		private static Drag.d_gdk_drag_drop gdk_drag_drop = FuncLoader.LoadFunction<Drag.d_gdk_drag_drop>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_drop"));

		// Token: 0x040001E2 RID: 482
		private static Drag.d_gdk_drag_drop_done gdk_drag_drop_done = FuncLoader.LoadFunction<Drag.d_gdk_drag_drop_done>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_drop_done"));

		// Token: 0x040001E3 RID: 483
		private static Drag.d_gdk_drag_drop_succeeded gdk_drag_drop_succeeded = FuncLoader.LoadFunction<Drag.d_gdk_drag_drop_succeeded>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_drop_succeeded"));

		// Token: 0x040001E4 RID: 484
		private static Drag.d_gdk_drag_find_window_for_screen gdk_drag_find_window_for_screen = FuncLoader.LoadFunction<Drag.d_gdk_drag_find_window_for_screen>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_find_window_for_screen"));

		// Token: 0x040001E5 RID: 485
		private static Drag.d_gdk_drag_get_selection gdk_drag_get_selection = FuncLoader.LoadFunction<Drag.d_gdk_drag_get_selection>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_get_selection"));

		// Token: 0x040001E6 RID: 486
		private static Drag.d_gdk_drag_motion gdk_drag_motion = FuncLoader.LoadFunction<Drag.d_gdk_drag_motion>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_motion"));

		// Token: 0x040001E7 RID: 487
		private static Drag.d_gdk_drag_status gdk_drag_status = FuncLoader.LoadFunction<Drag.d_gdk_drag_status>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_status"));

		// Token: 0x0200022A RID: 554
		// (Invoke) Token: 0x06000F2F RID: 3887
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_drag_abort(IntPtr context, uint time_);

		// Token: 0x0200022B RID: 555
		// (Invoke) Token: 0x06000F33 RID: 3891
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_drag_begin_for_device(IntPtr window, IntPtr device, IntPtr targets);

		// Token: 0x0200022C RID: 556
		// (Invoke) Token: 0x06000F37 RID: 3895
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_drag_begin_from_point(IntPtr window, IntPtr device, IntPtr targets, int x_root, int y_root);

		// Token: 0x0200022D RID: 557
		// (Invoke) Token: 0x06000F3B RID: 3899
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_drag_drop(IntPtr context, uint time_);

		// Token: 0x0200022E RID: 558
		// (Invoke) Token: 0x06000F3F RID: 3903
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_drag_drop_done(IntPtr context, bool success);

		// Token: 0x0200022F RID: 559
		// (Invoke) Token: 0x06000F43 RID: 3907
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_drag_drop_succeeded(IntPtr context);

		// Token: 0x02000230 RID: 560
		// (Invoke) Token: 0x06000F47 RID: 3911
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_drag_find_window_for_screen(IntPtr context, IntPtr drag_window, IntPtr screen, int x_root, int y_root, out IntPtr dest_window, out int protocol);

		// Token: 0x02000231 RID: 561
		// (Invoke) Token: 0x06000F4B RID: 3915
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_drag_get_selection(IntPtr context);

		// Token: 0x02000232 RID: 562
		// (Invoke) Token: 0x06000F4F RID: 3919
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_drag_motion(IntPtr context, IntPtr dest_window, int protocol, int x_root, int y_root, int suggested_action, int possible_actions, uint time_);

		// Token: 0x02000233 RID: 563
		// (Invoke) Token: 0x06000F53 RID: 3923
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_drag_status(IntPtr context, int action, uint time_);
	}
}
