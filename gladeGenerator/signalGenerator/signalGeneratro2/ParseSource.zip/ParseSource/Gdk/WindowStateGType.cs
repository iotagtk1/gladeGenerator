﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000122 RID: 290
	internal class WindowStateGType
	{
		// Token: 0x170002F4 RID: 756
		// (get) Token: 0x06000B54 RID: 2900 RVA: 0x000215BC File Offset: 0x0001F7BC
		public static GType GType
		{
			get
			{
				return new GType(WindowStateGType.gdk_window_state_get_type());
			}
		}

		// Token: 0x04000697 RID: 1687
		private static WindowStateGType.d_gdk_window_state_get_type gdk_window_state_get_type = FuncLoader.LoadFunction<WindowStateGType.d_gdk_window_state_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_state_get_type"));

		// Token: 0x020004D0 RID: 1232
		// (Invoke) Token: 0x060019C2 RID: 6594
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_state_get_type();
	}
}
