﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000B6 RID: 182
	public class MonitorRemovedArgs : SignalArgs
	{
		// Token: 0x170001E0 RID: 480
		// (get) Token: 0x06000741 RID: 1857 RVA: 0x000150D0 File Offset: 0x000132D0
		public Monitor P0
		{
			get
			{
				return (Monitor)base.Args[0];
			}
		}
	}
}
