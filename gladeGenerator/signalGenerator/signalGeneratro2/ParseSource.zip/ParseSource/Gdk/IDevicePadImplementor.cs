﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000A1 RID: 161
	[GInterface(typeof(DevicePadAdapter))]
	public interface IDevicePadImplementor : IWrapper
	{
		// Token: 0x170001AD RID: 429
		// (get) Token: 0x06000670 RID: 1648
		int NGroups { get; }

		// Token: 0x06000671 RID: 1649
		int GetGroupNModes(int group);

		// Token: 0x06000672 RID: 1650
		int GetNFeatures(DevicePadFeature feature);

		// Token: 0x06000673 RID: 1651
		int GetFeatureGroup(DevicePadFeature feature, int idx);
	}
}
