﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000A4 RID: 164
	[GType(typeof(InputSourceGType))]
	public enum InputSource
	{
		// Token: 0x04000384 RID: 900
		Mouse,
		// Token: 0x04000385 RID: 901
		Pen,
		// Token: 0x04000386 RID: 902
		Eraser,
		// Token: 0x04000387 RID: 903
		Cursor,
		// Token: 0x04000388 RID: 904
		Keyboard,
		// Token: 0x04000389 RID: 905
		Touchscreen,
		// Token: 0x0400038A RID: 906
		Touchpad,
		// Token: 0x0400038B RID: 907
		Trackpoint,
		// Token: 0x0400038C RID: 908
		TabletPad
	}
}
