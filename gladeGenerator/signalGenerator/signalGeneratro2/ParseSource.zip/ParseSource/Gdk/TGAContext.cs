﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x02000103 RID: 259
	public class TGAContext : Opaque
	{
		// Token: 0x06000A18 RID: 2584 RVA: 0x0001DBAD File Offset: 0x0001BDAD
		public TGAContext(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700028C RID: 652
		// (get) Token: 0x06000A19 RID: 2585 RVA: 0x0001DBB6 File Offset: 0x0001BDB6
		public static AbiStruct abi_info
		{
			get
			{
				if (TGAContext._abi_info == null)
				{
					TGAContext._abi_info = new AbiStruct(new List<AbiField>());
				}
				return TGAContext._abi_info;
			}
		}

		// Token: 0x04000583 RID: 1411
		private static AbiStruct _abi_info;
	}
}
