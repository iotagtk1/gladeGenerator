﻿using System;

namespace Gdk
{
	// Token: 0x02000076 RID: 118
	// (Invoke) Token: 0x0600050F RID: 1295
	public delegate void EventFunc(Event evnt);
}
