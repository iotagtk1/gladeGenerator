﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x02000108 RID: 264
	public class TiffContext : Opaque
	{
		// Token: 0x06000A28 RID: 2600 RVA: 0x0001DDF3 File Offset: 0x0001BFF3
		public TiffContext(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000290 RID: 656
		// (get) Token: 0x06000A29 RID: 2601 RVA: 0x0001DDFC File Offset: 0x0001BFFC
		public static AbiStruct abi_info
		{
			get
			{
				if (TiffContext._abi_info == null)
				{
					TiffContext._abi_info = new AbiStruct(new List<AbiField>());
				}
				return TiffContext._abi_info;
			}
		}

		// Token: 0x0400058D RID: 1421
		private static AbiStruct _abi_info;
	}
}
