﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000022 RID: 34
	public class Device : Object
	{
		// Token: 0x0600009B RID: 155 RVA: 0x00003568 File Offset: 0x00001768
		public TimeCoord[] GetHistory(Window window, uint start, uint stop)
		{
			IntPtr intPtr;
			int num;
			if (Device.gdk_device_get_history(base.Handle, window.Handle, start, stop, out intPtr, out num))
			{
				TimeCoord[] array = new TimeCoord[num];
				for (int i = 0; i < num; i++)
				{
					IntPtr raw = Marshal.ReadIntPtr(intPtr, i + IntPtr.Size);
					array[i] = TimeCoord.New(raw);
				}
				Device.gdk_device_free_history(intPtr, num);
				return array;
			}
			return new TimeCoord[0];
		}

		// Token: 0x0600009C RID: 156 RVA: 0x000035D7 File Offset: 0x000017D7
		public Device(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x0600009D RID: 157 RVA: 0x000035E0 File Offset: 0x000017E0
		protected Device() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x0600009E RID: 158 RVA: 0x000035FF File Offset: 0x000017FF
		[Property("display")]
		public Display Display
		{
			get
			{
				return Object.GetObject(Device.gdk_device_get_display(base.Handle)) as Display;
			}
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x0600009F RID: 159 RVA: 0x0000361C File Offset: 0x0000181C
		[Property("device-manager")]
		public DeviceManager DeviceManager
		{
			get
			{
				Value property = base.GetProperty("device-manager");
				DeviceManager result = (DeviceManager)((Object)property);
				property.Dispose();
				return result;
			}
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x060000A0 RID: 160 RVA: 0x00003647 File Offset: 0x00001847
		[Property("name")]
		public string Name
		{
			get
			{
				return Marshaller.Utf8PtrToString(Device.gdk_device_get_name(base.Handle));
			}
		}

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x060000A1 RID: 161 RVA: 0x00003660 File Offset: 0x00001860
		[Property("type")]
		public DeviceType Type
		{
			get
			{
				Value property = base.GetProperty("type");
				DeviceType result = (DeviceType)((Enum)property);
				property.Dispose();
				return result;
			}
		}

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x060000A2 RID: 162 RVA: 0x0000368B File Offset: 0x0000188B
		[Property("associated-device")]
		public Device AssociatedDevice
		{
			get
			{
				return Object.GetObject(Device.gdk_device_get_associated_device(base.Handle)) as Device;
			}
		}

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x060000A3 RID: 163 RVA: 0x000036A8 File Offset: 0x000018A8
		[Property("input-source")]
		public InputSource InputSource
		{
			get
			{
				Value property = base.GetProperty("input-source");
				InputSource result = (InputSource)((Enum)property);
				property.Dispose();
				return result;
			}
		}

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x060000A4 RID: 164 RVA: 0x000036D4 File Offset: 0x000018D4
		// (set) Token: 0x060000A5 RID: 165 RVA: 0x00003700 File Offset: 0x00001900
		[Property("input-mode")]
		public InputMode InputMode
		{
			get
			{
				Value property = base.GetProperty("input-mode");
				InputMode result = (InputMode)((Enum)property);
				property.Dispose();
				return result;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("input-mode", val);
				val.Dispose();
			}
		}

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x060000A6 RID: 166 RVA: 0x0000372D File Offset: 0x0000192D
		[Property("has-cursor")]
		public bool HasCursor
		{
			get
			{
				return Device.gdk_device_get_has_cursor(base.Handle);
			}
		}

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x060000A7 RID: 167 RVA: 0x0000373F File Offset: 0x0000193F
		[Property("n-axes")]
		public int NumAxes
		{
			get
			{
				return Device.gdk_device_get_n_axes(base.Handle);
			}
		}

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x060000A8 RID: 168 RVA: 0x00003751 File Offset: 0x00001951
		[Property("vendor-id")]
		public string VendorId
		{
			get
			{
				return Marshaller.Utf8PtrToString(Device.gdk_device_get_vendor_id(base.Handle));
			}
		}

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x060000A9 RID: 169 RVA: 0x00003768 File Offset: 0x00001968
		[Property("product-id")]
		public string ProductId
		{
			get
			{
				return Marshaller.Utf8PtrToString(Device.gdk_device_get_product_id(base.Handle));
			}
		}

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x060000AA RID: 170 RVA: 0x0000377F File Offset: 0x0000197F
		// (set) Token: 0x060000AB RID: 171 RVA: 0x0000379C File Offset: 0x0000199C
		[Property("seat")]
		public Seat Seat
		{
			get
			{
				return Object.GetObject(Device.gdk_device_get_seat(base.Handle)) as Seat;
			}
			set
			{
				Value val = new Value(value);
				base.SetProperty("seat", val);
				val.Dispose();
			}
		}

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x060000AC RID: 172 RVA: 0x000037C4 File Offset: 0x000019C4
		[Property("num-touches")]
		public uint NumTouches
		{
			get
			{
				Value property = base.GetProperty("num-touches");
				uint result = (uint)property;
				property.Dispose();
				return result;
			}
		}

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x060000AD RID: 173 RVA: 0x000037EA File Offset: 0x000019EA
		[Property("axes")]
		public AxisFlags Axes
		{
			get
			{
				return (AxisFlags)Device.gdk_device_get_axes(base.Handle);
			}
		}

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x060000AE RID: 174 RVA: 0x000037FC File Offset: 0x000019FC
		[Property("tool")]
		public DeviceTool Tool
		{
			get
			{
				Value property = base.GetProperty("tool");
				DeviceTool result = (DeviceTool)((Object)property);
				property.Dispose();
				return result;
			}
		}

		// Token: 0x14000001 RID: 1
		// (add) Token: 0x060000AF RID: 175 RVA: 0x00003827 File Offset: 0x00001A27
		// (remove) Token: 0x060000B0 RID: 176 RVA: 0x0000383F File Offset: 0x00001A3F
		[Signal("tool-changed")]
		public event ToolChangedHandler ToolChanged
		{
			add
			{
				base.AddSignalHandler("tool-changed", value, typeof(ToolChangedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("tool-changed", value);
			}
		}

		// Token: 0x14000002 RID: 2
		// (add) Token: 0x060000B1 RID: 177 RVA: 0x0000384D File Offset: 0x00001A4D
		// (remove) Token: 0x060000B2 RID: 178 RVA: 0x0000385B File Offset: 0x00001A5B
		[Signal("changed")]
		public event EventHandler Changed
		{
			add
			{
				base.AddSignalHandler("changed", value);
			}
			remove
			{
				base.RemoveSignalHandler("changed", value);
			}
		}

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x060000B3 RID: 179 RVA: 0x00003869 File Offset: 0x00001A69
		private static Device.ChangedNativeDelegate ChangedVMCallback
		{
			get
			{
				if (Device.Changed_cb_delegate == null)
				{
					Device.Changed_cb_delegate = new Device.ChangedNativeDelegate(Device.Changed_cb);
				}
				return Device.Changed_cb_delegate;
			}
		}

		// Token: 0x060000B4 RID: 180 RVA: 0x00003888 File Offset: 0x00001A88
		private static void OverrideChanged(GType gtype)
		{
			Device.OverrideChanged(gtype, Device.ChangedVMCallback);
		}

		// Token: 0x060000B5 RID: 181 RVA: 0x00003895 File Offset: 0x00001A95
		private static void OverrideChanged(GType gtype, Device.ChangedNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "changed", callback);
		}

		// Token: 0x060000B6 RID: 182 RVA: 0x000038A4 File Offset: 0x00001AA4
		private static void Changed_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Device).OnChanged();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060000B7 RID: 183 RVA: 0x000038DC File Offset: 0x00001ADC
		[DefaultSignalHandler(Type = typeof(Device), ConnectionMethod = "OverrideChanged")]
		protected virtual void OnChanged()
		{
			this.InternalChanged();
		}

		// Token: 0x060000B8 RID: 184 RVA: 0x000038E4 File Offset: 0x00001AE4
		private void InternalChanged()
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(1U);
			Value[] array = new Value[]
			{
				new Value(this)
			};
			valueArray.Append(array[0]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x060000B9 RID: 185 RVA: 0x00003956 File Offset: 0x00001B56
		private static Device.ToolChangedNativeDelegate ToolChangedVMCallback
		{
			get
			{
				if (Device.ToolChanged_cb_delegate == null)
				{
					Device.ToolChanged_cb_delegate = new Device.ToolChangedNativeDelegate(Device.ToolChanged_cb);
				}
				return Device.ToolChanged_cb_delegate;
			}
		}

		// Token: 0x060000BA RID: 186 RVA: 0x00003975 File Offset: 0x00001B75
		private static void OverrideToolChanged(GType gtype)
		{
			Device.OverrideToolChanged(gtype, Device.ToolChangedVMCallback);
		}

		// Token: 0x060000BB RID: 187 RVA: 0x00003982 File Offset: 0x00001B82
		private static void OverrideToolChanged(GType gtype, Device.ToolChangedNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "tool-changed", callback);
		}

		// Token: 0x060000BC RID: 188 RVA: 0x00003990 File Offset: 0x00001B90
		private static void ToolChanged_cb(IntPtr inst, IntPtr p0)
		{
			try
			{
				(Object.GetObject(inst, false) as Device).OnToolChanged(Object.GetObject(p0) as DeviceTool);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060000BD RID: 189 RVA: 0x000039D4 File Offset: 0x00001BD4
		[DefaultSignalHandler(Type = typeof(Device), ConnectionMethod = "OverrideToolChanged")]
		protected virtual void OnToolChanged(DeviceTool p0)
		{
			this.InternalToolChanged(p0);
		}

		// Token: 0x060000BE RID: 190 RVA: 0x000039E0 File Offset: 0x00001BE0
		private void InternalToolChanged(DeviceTool p0)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(2U);
			Value[] array = new Value[2];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(p0);
			valueArray.Append(array[1]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x060000BF RID: 191 RVA: 0x00003A6C File Offset: 0x00001C6C
		private static Device.GetHistoryNativeDelegate GetHistoryVMCallback
		{
			get
			{
				if (Device.GetHistory_cb_delegate == null)
				{
					Device.GetHistory_cb_delegate = new Device.GetHistoryNativeDelegate(Device.GetHistory_cb);
				}
				return Device.GetHistory_cb_delegate;
			}
		}

		// Token: 0x060000C0 RID: 192 RVA: 0x00003A8B File Offset: 0x00001C8B
		private static void OverrideGetHistory(GType gtype)
		{
			Device.OverrideGetHistory(gtype, Device.GetHistoryVMCallback);
		}

		// Token: 0x060000C1 RID: 193 RVA: 0x00003A98 File Offset: 0x00001C98
		private unsafe static void OverrideGetHistory(GType gtype, Device.GetHistoryNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Device.class_abi.GetFieldOffset("get_history");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060000C2 RID: 194 RVA: 0x00003ACC File Offset: 0x00001CCC
		private static bool GetHistory_cb(IntPtr inst, IntPtr window, uint start, uint stop, IntPtr events, out int n_events)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Device).OnGetHistory(Object.GetObject(window) as Window, start, stop, TimeCoord.New(events), out n_events);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060000C3 RID: 195 RVA: 0x00003B1C File Offset: 0x00001D1C
		[DefaultSignalHandler(Type = typeof(Device), ConnectionMethod = "OverrideGetHistory")]
		protected virtual bool OnGetHistory(Window window, uint start, uint stop, TimeCoord events, out int n_events)
		{
			return this.InternalGetHistory(window, start, stop, events, out n_events);
		}

		// Token: 0x060000C4 RID: 196 RVA: 0x00003B2C File Offset: 0x00001D2C
		private bool InternalGetHistory(Window window, uint start, uint stop, TimeCoord events, out int n_events)
		{
			Device.GetHistoryNativeDelegate getHistoryNativeDelegate = Device.class_abi.BaseOverride(base.LookupGType(), "get_history");
			if (getHistoryNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(events);
			bool result = getHistoryNativeDelegate(base.Handle, (window == null) ? IntPtr.Zero : window.Handle, start, stop, intPtr, out n_events);
			Marshal.FreeHGlobal(intPtr);
			return result;
		}

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x060000C5 RID: 197 RVA: 0x00003B8F File Offset: 0x00001D8F
		private static Device.GetStateNativeDelegate GetStateVMCallback
		{
			get
			{
				if (Device.GetState_cb_delegate == null)
				{
					Device.GetState_cb_delegate = new Device.GetStateNativeDelegate(Device.GetState_cb);
				}
				return Device.GetState_cb_delegate;
			}
		}

		// Token: 0x060000C6 RID: 198 RVA: 0x00003BAE File Offset: 0x00001DAE
		private static void OverrideGetState(GType gtype)
		{
			Device.OverrideGetState(gtype, Device.GetStateVMCallback);
		}

		// Token: 0x060000C7 RID: 199 RVA: 0x00003BBC File Offset: 0x00001DBC
		private unsafe static void OverrideGetState(GType gtype, Device.GetStateNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Device.class_abi.GetFieldOffset("get_state");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060000C8 RID: 200 RVA: 0x00003BF0 File Offset: 0x00001DF0
		private static void GetState_cb(IntPtr inst, IntPtr window, out double axes, out int mask)
		{
			try
			{
				ModifierType modifierType;
				(Object.GetObject(inst, false) as Device).OnGetState(Object.GetObject(window) as Window, out axes, out modifierType);
				mask = (int)modifierType;
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
		}

		// Token: 0x060000C9 RID: 201 RVA: 0x00003C3C File Offset: 0x00001E3C
		[DefaultSignalHandler(Type = typeof(Device), ConnectionMethod = "OverrideGetState")]
		protected virtual void OnGetState(Window window, out double axes, out ModifierType mask)
		{
			this.InternalGetState(window, out axes, out mask);
		}

		// Token: 0x060000CA RID: 202 RVA: 0x00003C48 File Offset: 0x00001E48
		private void InternalGetState(Window window, out double axes, out ModifierType mask)
		{
			Device.GetStateNativeDelegate getStateNativeDelegate = Device.class_abi.BaseOverride(base.LookupGType(), "get_state");
			if (getStateNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			int num;
			getStateNativeDelegate(base.Handle, (window == null) ? IntPtr.Zero : window.Handle, out axes, out num);
			mask = (ModifierType)num;
		}

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x060000CB RID: 203 RVA: 0x00003C99 File Offset: 0x00001E99
		private static Device.SetWindowCursorNativeDelegate SetWindowCursorVMCallback
		{
			get
			{
				if (Device.SetWindowCursor_cb_delegate == null)
				{
					Device.SetWindowCursor_cb_delegate = new Device.SetWindowCursorNativeDelegate(Device.SetWindowCursor_cb);
				}
				return Device.SetWindowCursor_cb_delegate;
			}
		}

		// Token: 0x060000CC RID: 204 RVA: 0x00003CB8 File Offset: 0x00001EB8
		private static void OverrideSetWindowCursor(GType gtype)
		{
			Device.OverrideSetWindowCursor(gtype, Device.SetWindowCursorVMCallback);
		}

		// Token: 0x060000CD RID: 205 RVA: 0x00003CC8 File Offset: 0x00001EC8
		private unsafe static void OverrideSetWindowCursor(GType gtype, Device.SetWindowCursorNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Device.class_abi.GetFieldOffset("set_window_cursor");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060000CE RID: 206 RVA: 0x00003CFC File Offset: 0x00001EFC
		private static void SetWindowCursor_cb(IntPtr inst, IntPtr window, IntPtr cursor)
		{
			try
			{
				(Object.GetObject(inst, false) as Device).OnSetWindowCursor(Object.GetObject(window) as Window, Object.GetObject(cursor) as Cursor);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060000CF RID: 207 RVA: 0x00003D4C File Offset: 0x00001F4C
		[DefaultSignalHandler(Type = typeof(Device), ConnectionMethod = "OverrideSetWindowCursor")]
		protected virtual void OnSetWindowCursor(Window window, Cursor cursor)
		{
			this.InternalSetWindowCursor(window, cursor);
		}

		// Token: 0x060000D0 RID: 208 RVA: 0x00003D58 File Offset: 0x00001F58
		private void InternalSetWindowCursor(Window window, Cursor cursor)
		{
			Device.SetWindowCursorNativeDelegate setWindowCursorNativeDelegate = Device.class_abi.BaseOverride(base.LookupGType(), "set_window_cursor");
			if (setWindowCursorNativeDelegate == null)
			{
				return;
			}
			setWindowCursorNativeDelegate(base.Handle, (window == null) ? IntPtr.Zero : window.Handle, (cursor == null) ? IntPtr.Zero : cursor.Handle);
		}

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x060000D1 RID: 209 RVA: 0x00003DAB File Offset: 0x00001FAB
		private static Device.WarpNativeDelegate WarpVMCallback
		{
			get
			{
				if (Device.Warp_cb_delegate == null)
				{
					Device.Warp_cb_delegate = new Device.WarpNativeDelegate(Device.Warp_cb);
				}
				return Device.Warp_cb_delegate;
			}
		}

		// Token: 0x060000D2 RID: 210 RVA: 0x00003DCA File Offset: 0x00001FCA
		private static void OverrideWarp(GType gtype)
		{
			Device.OverrideWarp(gtype, Device.WarpVMCallback);
		}

		// Token: 0x060000D3 RID: 211 RVA: 0x00003DD8 File Offset: 0x00001FD8
		private unsafe static void OverrideWarp(GType gtype, Device.WarpNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Device.class_abi.GetFieldOffset("warp");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060000D4 RID: 212 RVA: 0x00003E0C File Offset: 0x0000200C
		private static void Warp_cb(IntPtr inst, IntPtr screen, double x, double y)
		{
			try
			{
				(Object.GetObject(inst, false) as Device).OnWarp(Object.GetObject(screen) as Screen, x, y);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060000D5 RID: 213 RVA: 0x00003E54 File Offset: 0x00002054
		[DefaultSignalHandler(Type = typeof(Device), ConnectionMethod = "OverrideWarp")]
		protected virtual void OnWarp(Screen screen, double x, double y)
		{
			this.InternalWarp(screen, x, y);
		}

		// Token: 0x060000D6 RID: 214 RVA: 0x00003E60 File Offset: 0x00002060
		private void InternalWarp(Screen screen, double x, double y)
		{
			Device.WarpNativeDelegate warpNativeDelegate = Device.class_abi.BaseOverride(base.LookupGType(), "warp");
			if (warpNativeDelegate == null)
			{
				return;
			}
			warpNativeDelegate(base.Handle, (screen == null) ? IntPtr.Zero : screen.Handle, x, y);
		}

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x060000D7 RID: 215 RVA: 0x00003EA5 File Offset: 0x000020A5
		private static Device.QueryStateNativeDelegate QueryStateVMCallback
		{
			get
			{
				if (Device.QueryState_cb_delegate == null)
				{
					Device.QueryState_cb_delegate = new Device.QueryStateNativeDelegate(Device.QueryState_cb);
				}
				return Device.QueryState_cb_delegate;
			}
		}

		// Token: 0x060000D8 RID: 216 RVA: 0x00003EC4 File Offset: 0x000020C4
		private static void OverrideQueryState(GType gtype)
		{
			Device.OverrideQueryState(gtype, Device.QueryStateVMCallback);
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x00003ED4 File Offset: 0x000020D4
		private unsafe static void OverrideQueryState(GType gtype, Device.QueryStateNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Device.class_abi.GetFieldOffset("query_state");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060000DA RID: 218 RVA: 0x00003F08 File Offset: 0x00002108
		private static void QueryState_cb(IntPtr inst, IntPtr window, IntPtr root_window, IntPtr child_window, out double root_x, out double root_y, out double win_x, out double win_y, out int mask)
		{
			try
			{
				ModifierType modifierType;
				(Object.GetObject(inst, false) as Device).OnQueryState(Object.GetObject(window) as Window, Object.GetObject(root_window) as Window, Object.GetObject(child_window) as Window, out root_x, out root_y, out win_x, out win_y, out modifierType);
				mask = (int)modifierType;
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
		}

		// Token: 0x060000DB RID: 219 RVA: 0x00003F70 File Offset: 0x00002170
		[DefaultSignalHandler(Type = typeof(Device), ConnectionMethod = "OverrideQueryState")]
		protected virtual void OnQueryState(Window window, Window root_window, Window child_window, out double root_x, out double root_y, out double win_x, out double win_y, out ModifierType mask)
		{
			this.InternalQueryState(window, root_window, child_window, out root_x, out root_y, out win_x, out win_y, out mask);
		}

		// Token: 0x060000DC RID: 220 RVA: 0x00003F90 File Offset: 0x00002190
		private void InternalQueryState(Window window, Window root_window, Window child_window, out double root_x, out double root_y, out double win_x, out double win_y, out ModifierType mask)
		{
			Device.QueryStateNativeDelegate queryStateNativeDelegate = Device.class_abi.BaseOverride(base.LookupGType(), "query_state");
			if (queryStateNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			int num;
			queryStateNativeDelegate(base.Handle, (window == null) ? IntPtr.Zero : window.Handle, (root_window == null) ? IntPtr.Zero : root_window.Handle, (child_window == null) ? IntPtr.Zero : child_window.Handle, out root_x, out root_y, out win_x, out win_y, out num);
			mask = (ModifierType)num;
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x060000DD RID: 221 RVA: 0x00004009 File Offset: 0x00002209
		private static Device.GrabNativeDelegate GrabVMCallback
		{
			get
			{
				if (Device.Grab_cb_delegate == null)
				{
					Device.Grab_cb_delegate = new Device.GrabNativeDelegate(Device.Grab_cb);
				}
				return Device.Grab_cb_delegate;
			}
		}

		// Token: 0x060000DE RID: 222 RVA: 0x00004028 File Offset: 0x00002228
		private static void OverrideGrab(GType gtype)
		{
			Device.OverrideGrab(gtype, Device.GrabVMCallback);
		}

		// Token: 0x060000DF RID: 223 RVA: 0x00004038 File Offset: 0x00002238
		private unsafe static void OverrideGrab(GType gtype, Device.GrabNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Device.class_abi.GetFieldOffset("grab");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060000E0 RID: 224 RVA: 0x0000406C File Offset: 0x0000226C
		private static int Grab_cb(IntPtr inst, IntPtr window, bool owner_events, int event_mask, IntPtr confine_to, IntPtr cursor, uint time_)
		{
			int result;
			try
			{
				result = (int)(Object.GetObject(inst, false) as Device).OnGrab(Object.GetObject(window) as Window, owner_events, (EventMask)event_mask, Object.GetObject(confine_to) as Window, Object.GetObject(cursor) as Cursor, time_);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060000E1 RID: 225 RVA: 0x000040D0 File Offset: 0x000022D0
		[DefaultSignalHandler(Type = typeof(Device), ConnectionMethod = "OverrideGrab")]
		protected virtual GrabStatus OnGrab(Window window, bool owner_events, EventMask event_mask, Window confine_to, Cursor cursor, uint time_)
		{
			return this.InternalGrab(window, owner_events, event_mask, confine_to, cursor, time_);
		}

		// Token: 0x060000E2 RID: 226 RVA: 0x000040E4 File Offset: 0x000022E4
		private GrabStatus InternalGrab(Window window, bool owner_events, EventMask event_mask, Window confine_to, Cursor cursor, uint time_)
		{
			Device.GrabNativeDelegate grabNativeDelegate = Device.class_abi.BaseOverride(base.LookupGType(), "grab");
			if (grabNativeDelegate == null)
			{
				return GrabStatus.Success;
			}
			return (GrabStatus)grabNativeDelegate(base.Handle, (window == null) ? IntPtr.Zero : window.Handle, owner_events, (int)event_mask, (confine_to == null) ? IntPtr.Zero : confine_to.Handle, (cursor == null) ? IntPtr.Zero : cursor.Handle, time_);
		}

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x060000E3 RID: 227 RVA: 0x00004150 File Offset: 0x00002350
		private static Device.UngrabNativeDelegate UngrabVMCallback
		{
			get
			{
				if (Device.Ungrab_cb_delegate == null)
				{
					Device.Ungrab_cb_delegate = new Device.UngrabNativeDelegate(Device.Ungrab_cb);
				}
				return Device.Ungrab_cb_delegate;
			}
		}

		// Token: 0x060000E4 RID: 228 RVA: 0x0000416F File Offset: 0x0000236F
		private static void OverrideUngrab(GType gtype)
		{
			Device.OverrideUngrab(gtype, Device.UngrabVMCallback);
		}

		// Token: 0x060000E5 RID: 229 RVA: 0x0000417C File Offset: 0x0000237C
		private unsafe static void OverrideUngrab(GType gtype, Device.UngrabNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Device.class_abi.GetFieldOffset("ungrab");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060000E6 RID: 230 RVA: 0x000041B0 File Offset: 0x000023B0
		private static void Ungrab_cb(IntPtr inst, uint time_)
		{
			try
			{
				(Object.GetObject(inst, false) as Device).OnUngrab(time_);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060000E7 RID: 231 RVA: 0x000041EC File Offset: 0x000023EC
		[DefaultSignalHandler(Type = typeof(Device), ConnectionMethod = "OverrideUngrab")]
		protected virtual void OnUngrab(uint time_)
		{
			this.InternalUngrab(time_);
		}

		// Token: 0x060000E8 RID: 232 RVA: 0x000041F8 File Offset: 0x000023F8
		private void InternalUngrab(uint time_)
		{
			Device.UngrabNativeDelegate ungrabNativeDelegate = Device.class_abi.BaseOverride(base.LookupGType(), "ungrab");
			if (ungrabNativeDelegate == null)
			{
				return;
			}
			ungrabNativeDelegate(base.Handle, time_);
		}

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x060000E9 RID: 233 RVA: 0x0000422C File Offset: 0x0000242C
		private static Device.WindowAtPositionNativeDelegate WindowAtPositionVMCallback
		{
			get
			{
				if (Device.WindowAtPosition_cb_delegate == null)
				{
					Device.WindowAtPosition_cb_delegate = new Device.WindowAtPositionNativeDelegate(Device.WindowAtPosition_cb);
				}
				return Device.WindowAtPosition_cb_delegate;
			}
		}

		// Token: 0x060000EA RID: 234 RVA: 0x0000424B File Offset: 0x0000244B
		private static void OverrideWindowAtPosition(GType gtype)
		{
			Device.OverrideWindowAtPosition(gtype, Device.WindowAtPositionVMCallback);
		}

		// Token: 0x060000EB RID: 235 RVA: 0x00004258 File Offset: 0x00002458
		private unsafe static void OverrideWindowAtPosition(GType gtype, Device.WindowAtPositionNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Device.class_abi.GetFieldOffset("window_at_position");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060000EC RID: 236 RVA: 0x0000428C File Offset: 0x0000248C
		private static IntPtr WindowAtPosition_cb(IntPtr inst, out double win_x, out double win_y, out int mask, bool get_toplevel)
		{
			IntPtr result;
			try
			{
				ModifierType modifierType;
				Window window = (Object.GetObject(inst, false) as Device).OnWindowAtPosition(out win_x, out win_y, out modifierType, get_toplevel);
				mask = (int)modifierType;
				result = ((window == null) ? IntPtr.Zero : window.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060000ED RID: 237 RVA: 0x000042E0 File Offset: 0x000024E0
		[DefaultSignalHandler(Type = typeof(Device), ConnectionMethod = "OverrideWindowAtPosition")]
		protected virtual Window OnWindowAtPosition(out double win_x, out double win_y, out ModifierType mask, bool get_toplevel)
		{
			return this.InternalWindowAtPosition(out win_x, out win_y, out mask, get_toplevel);
		}

		// Token: 0x060000EE RID: 238 RVA: 0x000042F0 File Offset: 0x000024F0
		private Window InternalWindowAtPosition(out double win_x, out double win_y, out ModifierType mask, bool get_toplevel)
		{
			Device.WindowAtPositionNativeDelegate windowAtPositionNativeDelegate = Device.class_abi.BaseOverride(base.LookupGType(), "window_at_position");
			if (windowAtPositionNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			int num;
			IntPtr o = windowAtPositionNativeDelegate(base.Handle, out win_x, out win_y, out num, get_toplevel);
			mask = (ModifierType)num;
			return Object.GetObject(o) as Window;
		}

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x060000EF RID: 239 RVA: 0x0000433E File Offset: 0x0000253E
		private static Device.SelectWindowEventsNativeDelegate SelectWindowEventsVMCallback
		{
			get
			{
				if (Device.SelectWindowEvents_cb_delegate == null)
				{
					Device.SelectWindowEvents_cb_delegate = new Device.SelectWindowEventsNativeDelegate(Device.SelectWindowEvents_cb);
				}
				return Device.SelectWindowEvents_cb_delegate;
			}
		}

		// Token: 0x060000F0 RID: 240 RVA: 0x0000435D File Offset: 0x0000255D
		private static void OverrideSelectWindowEvents(GType gtype)
		{
			Device.OverrideSelectWindowEvents(gtype, Device.SelectWindowEventsVMCallback);
		}

		// Token: 0x060000F1 RID: 241 RVA: 0x0000436C File Offset: 0x0000256C
		private unsafe static void OverrideSelectWindowEvents(GType gtype, Device.SelectWindowEventsNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Device.class_abi.GetFieldOffset("select_window_events");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060000F2 RID: 242 RVA: 0x000043A0 File Offset: 0x000025A0
		private static void SelectWindowEvents_cb(IntPtr inst, IntPtr window, int event_mask)
		{
			try
			{
				(Object.GetObject(inst, false) as Device).OnSelectWindowEvents(Object.GetObject(window) as Window, (EventMask)event_mask);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060000F3 RID: 243 RVA: 0x000043E4 File Offset: 0x000025E4
		[DefaultSignalHandler(Type = typeof(Device), ConnectionMethod = "OverrideSelectWindowEvents")]
		protected virtual void OnSelectWindowEvents(Window window, EventMask event_mask)
		{
			this.InternalSelectWindowEvents(window, event_mask);
		}

		// Token: 0x060000F4 RID: 244 RVA: 0x000043F0 File Offset: 0x000025F0
		private void InternalSelectWindowEvents(Window window, EventMask event_mask)
		{
			Device.SelectWindowEventsNativeDelegate selectWindowEventsNativeDelegate = Device.class_abi.BaseOverride(base.LookupGType(), "select_window_events");
			if (selectWindowEventsNativeDelegate == null)
			{
				return;
			}
			selectWindowEventsNativeDelegate(base.Handle, (window == null) ? IntPtr.Zero : window.Handle, (int)event_mask);
		}

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x060000F5 RID: 245 RVA: 0x00004434 File Offset: 0x00002634
		public new static AbiStruct class_abi
		{
			get
			{
				if (Device._class_abi == null)
				{
					Device._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("get_history", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "get_state", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_state", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_history", "set_window_cursor", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("set_window_cursor", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_state", "warp", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("warp", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "set_window_cursor", "query_state", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("query_state", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "warp", "grab", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("grab", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "query_state", "ungrab", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("ungrab", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "grab", "window_at_position", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("window_at_position", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "ungrab", "select_window_events", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("select_window_events", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "window_at_position", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Device._class_abi;
			}
		}

		// Token: 0x060000F6 RID: 246 RVA: 0x0000467B File Offset: 0x0000287B
		public bool GetAxis(double[] axes, AxisUse use, out double value)
		{
			return Device.gdk_device_get_axis(base.Handle, axes, (int)use, out value);
		}

		// Token: 0x060000F7 RID: 247 RVA: 0x00004690 File Offset: 0x00002890
		public AxisUse GetAxisUse(uint index_)
		{
			return (AxisUse)Device.gdk_device_get_axis_use(base.Handle, index_);
		}

		// Token: 0x060000F8 RID: 248 RVA: 0x000046A3 File Offset: 0x000028A3
		public bool GetAxisValue(out double axes, Atom axis_label, out double value)
		{
			return Device.gdk_device_get_axis_value(base.Handle, out axes, (axis_label == null) ? IntPtr.Zero : axis_label.Handle, out value);
		}

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x060000F9 RID: 249 RVA: 0x000046C7 File Offset: 0x000028C7
		public DeviceType DeviceType
		{
			get
			{
				return (DeviceType)Device.gdk_device_get_device_type(base.Handle);
			}
		}

		// Token: 0x060000FA RID: 250 RVA: 0x000046DC File Offset: 0x000028DC
		public bool GetKey(uint index_, out uint keyval, out ModifierType modifiers)
		{
			int num;
			bool result = Device.gdk_device_get_key(base.Handle, index_, out keyval, out num);
			modifiers = (ModifierType)num;
			return result;
		}

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x060000FB RID: 251 RVA: 0x00004700 File Offset: 0x00002900
		public Window LastEventWindow
		{
			get
			{
				return Object.GetObject(Device.gdk_device_get_last_event_window(base.Handle)) as Window;
			}
		}

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x060000FC RID: 252 RVA: 0x0000471C File Offset: 0x0000291C
		public InputMode Mode
		{
			get
			{
				return (InputMode)Device.gdk_device_get_mode(base.Handle);
			}
		}

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x060000FD RID: 253 RVA: 0x0000472E File Offset: 0x0000292E
		public int NKeys
		{
			get
			{
				return Device.gdk_device_get_n_keys(base.Handle);
			}
		}

		// Token: 0x060000FE RID: 254 RVA: 0x00004740 File Offset: 0x00002940
		public void GetPosition(Screen screen, out int x, out int y)
		{
			Device.gdk_device_get_position(base.Handle, (screen == null) ? IntPtr.Zero : screen.Handle, out x, out y);
		}

		// Token: 0x060000FF RID: 255 RVA: 0x00004764 File Offset: 0x00002964
		public void GetPositionDouble(Screen screen, out double x, out double y)
		{
			Device.gdk_device_get_position_double(base.Handle, (screen == null) ? IntPtr.Zero : screen.Handle, out x, out y);
		}

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x06000100 RID: 256 RVA: 0x00004788 File Offset: 0x00002988
		public InputSource Source
		{
			get
			{
				return (InputSource)Device.gdk_device_get_source(base.Handle);
			}
		}

		// Token: 0x06000101 RID: 257 RVA: 0x0000479C File Offset: 0x0000299C
		public void GetState(Window window, out double axes, out ModifierType mask)
		{
			int num;
			Device.gdk_device_get_state(base.Handle, (window == null) ? IntPtr.Zero : window.Handle, out axes, out num);
			mask = (ModifierType)num;
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x06000102 RID: 258 RVA: 0x000047D0 File Offset: 0x000029D0
		public new static GType GType
		{
			get
			{
				IntPtr val = Device.gdk_device_get_type();
				return new GType(val);
			}
		}

		// Token: 0x06000103 RID: 259 RVA: 0x000047EE File Offset: 0x000029EE
		public Window GetWindowAtPosition(out int win_x, out int win_y)
		{
			return Object.GetObject(Device.gdk_device_get_window_at_position(base.Handle, out win_x, out win_y)) as Window;
		}

		// Token: 0x06000104 RID: 260 RVA: 0x0000480C File Offset: 0x00002A0C
		public Window GetWindowAtPositionDouble(out double win_x, out double win_y)
		{
			return Object.GetObject(Device.gdk_device_get_window_at_position_double(base.Handle, out win_x, out win_y)) as Window;
		}

		// Token: 0x06000105 RID: 261 RVA: 0x0000482A File Offset: 0x00002A2A
		[Obsolete]
		public GrabStatus Grab(Window window, GrabOwnership grab_ownership, bool owner_events, EventMask event_mask, Cursor cursor, uint time_)
		{
			return (GrabStatus)Device.gdk_device_grab(base.Handle, (window == null) ? IntPtr.Zero : window.Handle, (int)grab_ownership, owner_events, (int)event_mask, (cursor == null) ? IntPtr.Zero : cursor.Handle, time_);
		}

		// Token: 0x06000106 RID: 262 RVA: 0x00004864 File Offset: 0x00002A64
		[Obsolete]
		public static bool GrabInfoLibgtkOnly(Display display, Device device, Window grab_window, out bool owner_events)
		{
			return Device.gdk_device_grab_info_libgtk_only((display == null) ? IntPtr.Zero : display.Handle, (device == null) ? IntPtr.Zero : device.Handle, (grab_window == null) ? IntPtr.Zero : grab_window.Handle, out owner_events);
		}

		// Token: 0x06000107 RID: 263 RVA: 0x000048A1 File Offset: 0x00002AA1
		public Atom[] ListAxes()
		{
			return (Atom[])Marshaller.ListPtrToArray(Device.gdk_device_list_axes(base.Handle), typeof(List), true, false, typeof(Atom));
		}

		// Token: 0x06000108 RID: 264 RVA: 0x000048D3 File Offset: 0x00002AD3
		public Device[] ListSlaveDevices()
		{
			return (Device[])Marshaller.ListPtrToArray(Device.gdk_device_list_slave_devices(base.Handle), typeof(List), true, false, typeof(Device));
		}

		// Token: 0x06000109 RID: 265 RVA: 0x00004905 File Offset: 0x00002B05
		public void SetAxisUse(uint index_, AxisUse use)
		{
			Device.gdk_device_set_axis_use(base.Handle, index_, (int)use);
		}

		// Token: 0x0600010A RID: 266 RVA: 0x00004919 File Offset: 0x00002B19
		public void SetKey(uint index_, uint keyval, ModifierType modifiers)
		{
			Device.gdk_device_set_key(base.Handle, index_, keyval, (int)modifiers);
		}

		// Token: 0x0600010B RID: 267 RVA: 0x0000492E File Offset: 0x00002B2E
		public bool SetMode(InputMode mode)
		{
			return Device.gdk_device_set_mode(base.Handle, (int)mode);
		}

		// Token: 0x0600010C RID: 268 RVA: 0x00004941 File Offset: 0x00002B41
		[Obsolete]
		public void Ungrab(uint time_)
		{
			Device.gdk_device_ungrab(base.Handle, time_);
		}

		// Token: 0x0600010D RID: 269 RVA: 0x00004954 File Offset: 0x00002B54
		public void Warp(Screen screen, int x, int y)
		{
			Device.gdk_device_warp(base.Handle, (screen == null) ? IntPtr.Zero : screen.Handle, x, y);
		}

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x0600010E RID: 270 RVA: 0x00004978 File Offset: 0x00002B78
		public new static AbiStruct abi_info
		{
			get
			{
				if (Device._abi_info == null)
				{
					Device._abi_info = new AbiStruct(Object.abi_info.Fields);
				}
				return Device._abi_info;
			}
		}

		// Token: 0x0400005F RID: 95
		private static Device.d_gdk_device_free_history gdk_device_free_history = FuncLoader.LoadFunction<Device.d_gdk_device_free_history>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_free_history"));

		// Token: 0x04000060 RID: 96
		private static Device.d_gdk_device_get_history gdk_device_get_history = FuncLoader.LoadFunction<Device.d_gdk_device_get_history>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_history"));

		// Token: 0x04000061 RID: 97
		private static Device.d_gdk_device_get_display gdk_device_get_display = FuncLoader.LoadFunction<Device.d_gdk_device_get_display>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_display"));

		// Token: 0x04000062 RID: 98
		private static Device.d_gdk_device_get_name gdk_device_get_name = FuncLoader.LoadFunction<Device.d_gdk_device_get_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_name"));

		// Token: 0x04000063 RID: 99
		private static Device.d_gdk_device_get_associated_device gdk_device_get_associated_device = FuncLoader.LoadFunction<Device.d_gdk_device_get_associated_device>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_associated_device"));

		// Token: 0x04000064 RID: 100
		private static Device.d_gdk_device_get_has_cursor gdk_device_get_has_cursor = FuncLoader.LoadFunction<Device.d_gdk_device_get_has_cursor>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_has_cursor"));

		// Token: 0x04000065 RID: 101
		private static Device.d_gdk_device_get_n_axes gdk_device_get_n_axes = FuncLoader.LoadFunction<Device.d_gdk_device_get_n_axes>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_n_axes"));

		// Token: 0x04000066 RID: 102
		private static Device.d_gdk_device_get_vendor_id gdk_device_get_vendor_id = FuncLoader.LoadFunction<Device.d_gdk_device_get_vendor_id>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_vendor_id"));

		// Token: 0x04000067 RID: 103
		private static Device.d_gdk_device_get_product_id gdk_device_get_product_id = FuncLoader.LoadFunction<Device.d_gdk_device_get_product_id>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_product_id"));

		// Token: 0x04000068 RID: 104
		private static Device.d_gdk_device_get_seat gdk_device_get_seat = FuncLoader.LoadFunction<Device.d_gdk_device_get_seat>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_seat"));

		// Token: 0x04000069 RID: 105
		private static Device.d_gdk_device_get_axes gdk_device_get_axes = FuncLoader.LoadFunction<Device.d_gdk_device_get_axes>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_axes"));

		// Token: 0x0400006A RID: 106
		private static Device.ChangedNativeDelegate Changed_cb_delegate;

		// Token: 0x0400006B RID: 107
		private static Device.ToolChangedNativeDelegate ToolChanged_cb_delegate;

		// Token: 0x0400006C RID: 108
		private static Device.GetHistoryNativeDelegate GetHistory_cb_delegate;

		// Token: 0x0400006D RID: 109
		private static Device.GetStateNativeDelegate GetState_cb_delegate;

		// Token: 0x0400006E RID: 110
		private static Device.SetWindowCursorNativeDelegate SetWindowCursor_cb_delegate;

		// Token: 0x0400006F RID: 111
		private static Device.WarpNativeDelegate Warp_cb_delegate;

		// Token: 0x04000070 RID: 112
		private static Device.QueryStateNativeDelegate QueryState_cb_delegate;

		// Token: 0x04000071 RID: 113
		private static Device.GrabNativeDelegate Grab_cb_delegate;

		// Token: 0x04000072 RID: 114
		private static Device.UngrabNativeDelegate Ungrab_cb_delegate;

		// Token: 0x04000073 RID: 115
		private static Device.WindowAtPositionNativeDelegate WindowAtPosition_cb_delegate;

		// Token: 0x04000074 RID: 116
		private static Device.SelectWindowEventsNativeDelegate SelectWindowEvents_cb_delegate;

		// Token: 0x04000075 RID: 117
		private static AbiStruct _class_abi = null;

		// Token: 0x04000076 RID: 118
		private static Device.d_gdk_device_get_axis gdk_device_get_axis = FuncLoader.LoadFunction<Device.d_gdk_device_get_axis>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_axis"));

		// Token: 0x04000077 RID: 119
		private static Device.d_gdk_device_get_axis_use gdk_device_get_axis_use = FuncLoader.LoadFunction<Device.d_gdk_device_get_axis_use>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_axis_use"));

		// Token: 0x04000078 RID: 120
		private static Device.d_gdk_device_get_axis_value gdk_device_get_axis_value = FuncLoader.LoadFunction<Device.d_gdk_device_get_axis_value>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_axis_value"));

		// Token: 0x04000079 RID: 121
		private static Device.d_gdk_device_get_device_type gdk_device_get_device_type = FuncLoader.LoadFunction<Device.d_gdk_device_get_device_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_device_type"));

		// Token: 0x0400007A RID: 122
		private static Device.d_gdk_device_get_key gdk_device_get_key = FuncLoader.LoadFunction<Device.d_gdk_device_get_key>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_key"));

		// Token: 0x0400007B RID: 123
		private static Device.d_gdk_device_get_last_event_window gdk_device_get_last_event_window = FuncLoader.LoadFunction<Device.d_gdk_device_get_last_event_window>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_last_event_window"));

		// Token: 0x0400007C RID: 124
		private static Device.d_gdk_device_get_mode gdk_device_get_mode = FuncLoader.LoadFunction<Device.d_gdk_device_get_mode>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_mode"));

		// Token: 0x0400007D RID: 125
		private static Device.d_gdk_device_get_n_keys gdk_device_get_n_keys = FuncLoader.LoadFunction<Device.d_gdk_device_get_n_keys>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_n_keys"));

		// Token: 0x0400007E RID: 126
		private static Device.d_gdk_device_get_position gdk_device_get_position = FuncLoader.LoadFunction<Device.d_gdk_device_get_position>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_position"));

		// Token: 0x0400007F RID: 127
		private static Device.d_gdk_device_get_position_double gdk_device_get_position_double = FuncLoader.LoadFunction<Device.d_gdk_device_get_position_double>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_position_double"));

		// Token: 0x04000080 RID: 128
		private static Device.d_gdk_device_get_source gdk_device_get_source = FuncLoader.LoadFunction<Device.d_gdk_device_get_source>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_source"));

		// Token: 0x04000081 RID: 129
		private static Device.d_gdk_device_get_state gdk_device_get_state = FuncLoader.LoadFunction<Device.d_gdk_device_get_state>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_state"));

		// Token: 0x04000082 RID: 130
		private static Device.d_gdk_device_get_type gdk_device_get_type = FuncLoader.LoadFunction<Device.d_gdk_device_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_type"));

		// Token: 0x04000083 RID: 131
		private static Device.d_gdk_device_get_window_at_position gdk_device_get_window_at_position = FuncLoader.LoadFunction<Device.d_gdk_device_get_window_at_position>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_window_at_position"));

		// Token: 0x04000084 RID: 132
		private static Device.d_gdk_device_get_window_at_position_double gdk_device_get_window_at_position_double = FuncLoader.LoadFunction<Device.d_gdk_device_get_window_at_position_double>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_get_window_at_position_double"));

		// Token: 0x04000085 RID: 133
		private static Device.d_gdk_device_grab gdk_device_grab = FuncLoader.LoadFunction<Device.d_gdk_device_grab>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_grab"));

		// Token: 0x04000086 RID: 134
		private static Device.d_gdk_device_grab_info_libgtk_only gdk_device_grab_info_libgtk_only = FuncLoader.LoadFunction<Device.d_gdk_device_grab_info_libgtk_only>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_grab_info_libgtk_only"));

		// Token: 0x04000087 RID: 135
		private static Device.d_gdk_device_list_axes gdk_device_list_axes = FuncLoader.LoadFunction<Device.d_gdk_device_list_axes>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_list_axes"));

		// Token: 0x04000088 RID: 136
		private static Device.d_gdk_device_list_slave_devices gdk_device_list_slave_devices = FuncLoader.LoadFunction<Device.d_gdk_device_list_slave_devices>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_list_slave_devices"));

		// Token: 0x04000089 RID: 137
		private static Device.d_gdk_device_set_axis_use gdk_device_set_axis_use = FuncLoader.LoadFunction<Device.d_gdk_device_set_axis_use>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_set_axis_use"));

		// Token: 0x0400008A RID: 138
		private static Device.d_gdk_device_set_key gdk_device_set_key = FuncLoader.LoadFunction<Device.d_gdk_device_set_key>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_set_key"));

		// Token: 0x0400008B RID: 139
		private static Device.d_gdk_device_set_mode gdk_device_set_mode = FuncLoader.LoadFunction<Device.d_gdk_device_set_mode>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_set_mode"));

		// Token: 0x0400008C RID: 140
		private static Device.d_gdk_device_ungrab gdk_device_ungrab = FuncLoader.LoadFunction<Device.d_gdk_device_ungrab>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_ungrab"));

		// Token: 0x0400008D RID: 141
		private static Device.d_gdk_device_warp gdk_device_warp = FuncLoader.LoadFunction<Device.d_gdk_device_warp>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_warp"));

		// Token: 0x0400008E RID: 142
		private static AbiStruct _abi_info = null;

		// Token: 0x0200013A RID: 314
		// (Invoke) Token: 0x06000BBF RID: 3007
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_device_free_history(IntPtr events, int n_events);

		// Token: 0x0200013B RID: 315
		// (Invoke) Token: 0x06000BC3 RID: 3011
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_device_get_history(IntPtr device, IntPtr window, uint start, uint stop, out IntPtr events, out int n_events);

		// Token: 0x0200013C RID: 316
		// (Invoke) Token: 0x06000BC7 RID: 3015
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_get_display(IntPtr raw);

		// Token: 0x0200013D RID: 317
		// (Invoke) Token: 0x06000BCB RID: 3019
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_get_name(IntPtr raw);

		// Token: 0x0200013E RID: 318
		// (Invoke) Token: 0x06000BCF RID: 3023
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_get_associated_device(IntPtr raw);

		// Token: 0x0200013F RID: 319
		// (Invoke) Token: 0x06000BD3 RID: 3027
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_device_get_has_cursor(IntPtr raw);

		// Token: 0x02000140 RID: 320
		// (Invoke) Token: 0x06000BD7 RID: 3031
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_device_get_n_axes(IntPtr raw);

		// Token: 0x02000141 RID: 321
		// (Invoke) Token: 0x06000BDB RID: 3035
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_get_vendor_id(IntPtr raw);

		// Token: 0x02000142 RID: 322
		// (Invoke) Token: 0x06000BDF RID: 3039
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_get_product_id(IntPtr raw);

		// Token: 0x02000143 RID: 323
		// (Invoke) Token: 0x06000BE3 RID: 3043
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_get_seat(IntPtr raw);

		// Token: 0x02000144 RID: 324
		// (Invoke) Token: 0x06000BE7 RID: 3047
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_device_get_axes(IntPtr raw);

		// Token: 0x02000145 RID: 325
		// (Invoke) Token: 0x06000BEB RID: 3051
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ChangedNativeDelegate(IntPtr inst);

		// Token: 0x02000146 RID: 326
		// (Invoke) Token: 0x06000BEF RID: 3055
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ToolChangedNativeDelegate(IntPtr inst, IntPtr p0);

		// Token: 0x02000147 RID: 327
		// (Invoke) Token: 0x06000BF3 RID: 3059
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool GetHistoryNativeDelegate(IntPtr inst, IntPtr window, uint start, uint stop, IntPtr events, out int n_events);

		// Token: 0x02000148 RID: 328
		// (Invoke) Token: 0x06000BF7 RID: 3063
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void GetStateNativeDelegate(IntPtr inst, IntPtr window, out double axes, out int mask);

		// Token: 0x02000149 RID: 329
		// (Invoke) Token: 0x06000BFB RID: 3067
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void SetWindowCursorNativeDelegate(IntPtr inst, IntPtr window, IntPtr cursor);

		// Token: 0x0200014A RID: 330
		// (Invoke) Token: 0x06000BFF RID: 3071
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void WarpNativeDelegate(IntPtr inst, IntPtr screen, double x, double y);

		// Token: 0x0200014B RID: 331
		// (Invoke) Token: 0x06000C03 RID: 3075
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void QueryStateNativeDelegate(IntPtr inst, IntPtr window, IntPtr root_window, IntPtr child_window, out double root_x, out double root_y, out double win_x, out double win_y, out int mask);

		// Token: 0x0200014C RID: 332
		// (Invoke) Token: 0x06000C07 RID: 3079
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GrabNativeDelegate(IntPtr inst, IntPtr window, bool owner_events, int event_mask, IntPtr confine_to, IntPtr cursor, uint time_);

		// Token: 0x0200014D RID: 333
		// (Invoke) Token: 0x06000C0B RID: 3083
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void UngrabNativeDelegate(IntPtr inst, uint time_);

		// Token: 0x0200014E RID: 334
		// (Invoke) Token: 0x06000C0F RID: 3087
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr WindowAtPositionNativeDelegate(IntPtr inst, out double win_x, out double win_y, out int mask, bool get_toplevel);

		// Token: 0x0200014F RID: 335
		// (Invoke) Token: 0x06000C13 RID: 3091
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void SelectWindowEventsNativeDelegate(IntPtr inst, IntPtr window, int event_mask);

		// Token: 0x02000150 RID: 336
		// (Invoke) Token: 0x06000C17 RID: 3095
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_device_get_axis(IntPtr raw, double[] axes, int use, out double value);

		// Token: 0x02000151 RID: 337
		// (Invoke) Token: 0x06000C1B RID: 3099
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_device_get_axis_use(IntPtr raw, uint index_);

		// Token: 0x02000152 RID: 338
		// (Invoke) Token: 0x06000C1F RID: 3103
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_device_get_axis_value(IntPtr raw, out double axes, IntPtr axis_label, out double value);

		// Token: 0x02000153 RID: 339
		// (Invoke) Token: 0x06000C23 RID: 3107
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_device_get_device_type(IntPtr raw);

		// Token: 0x02000154 RID: 340
		// (Invoke) Token: 0x06000C27 RID: 3111
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_device_get_key(IntPtr raw, uint index_, out uint keyval, out int modifiers);

		// Token: 0x02000155 RID: 341
		// (Invoke) Token: 0x06000C2B RID: 3115
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_get_last_event_window(IntPtr raw);

		// Token: 0x02000156 RID: 342
		// (Invoke) Token: 0x06000C2F RID: 3119
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_device_get_mode(IntPtr raw);

		// Token: 0x02000157 RID: 343
		// (Invoke) Token: 0x06000C33 RID: 3123
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_device_get_n_keys(IntPtr raw);

		// Token: 0x02000158 RID: 344
		// (Invoke) Token: 0x06000C37 RID: 3127
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_device_get_position(IntPtr raw, IntPtr screen, out int x, out int y);

		// Token: 0x02000159 RID: 345
		// (Invoke) Token: 0x06000C3B RID: 3131
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_device_get_position_double(IntPtr raw, IntPtr screen, out double x, out double y);

		// Token: 0x0200015A RID: 346
		// (Invoke) Token: 0x06000C3F RID: 3135
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_device_get_source(IntPtr raw);

		// Token: 0x0200015B RID: 347
		// (Invoke) Token: 0x06000C43 RID: 3139
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_device_get_state(IntPtr raw, IntPtr window, out double axes, out int mask);

		// Token: 0x0200015C RID: 348
		// (Invoke) Token: 0x06000C47 RID: 3143
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_get_type();

		// Token: 0x0200015D RID: 349
		// (Invoke) Token: 0x06000C4B RID: 3147
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_get_window_at_position(IntPtr raw, out int win_x, out int win_y);

		// Token: 0x0200015E RID: 350
		// (Invoke) Token: 0x06000C4F RID: 3151
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_get_window_at_position_double(IntPtr raw, out double win_x, out double win_y);

		// Token: 0x0200015F RID: 351
		// (Invoke) Token: 0x06000C53 RID: 3155
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_device_grab(IntPtr raw, IntPtr window, int grab_ownership, bool owner_events, int event_mask, IntPtr cursor, uint time_);

		// Token: 0x02000160 RID: 352
		// (Invoke) Token: 0x06000C57 RID: 3159
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_device_grab_info_libgtk_only(IntPtr display, IntPtr device, IntPtr grab_window, out bool owner_events);

		// Token: 0x02000161 RID: 353
		// (Invoke) Token: 0x06000C5B RID: 3163
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_list_axes(IntPtr raw);

		// Token: 0x02000162 RID: 354
		// (Invoke) Token: 0x06000C5F RID: 3167
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_list_slave_devices(IntPtr raw);

		// Token: 0x02000163 RID: 355
		// (Invoke) Token: 0x06000C63 RID: 3171
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_device_set_axis_use(IntPtr raw, uint index_, int use);

		// Token: 0x02000164 RID: 356
		// (Invoke) Token: 0x06000C67 RID: 3175
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_device_set_key(IntPtr raw, uint index_, uint keyval, int modifiers);

		// Token: 0x02000165 RID: 357
		// (Invoke) Token: 0x06000C6B RID: 3179
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_device_set_mode(IntPtr raw, int mode);

		// Token: 0x02000166 RID: 358
		// (Invoke) Token: 0x06000C6F RID: 3183
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_device_ungrab(IntPtr raw, uint time_);

		// Token: 0x02000167 RID: 359
		// (Invoke) Token: 0x06000C73 RID: 3187
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_device_warp(IntPtr raw, IntPtr screen, int x, int y);
	}
}
