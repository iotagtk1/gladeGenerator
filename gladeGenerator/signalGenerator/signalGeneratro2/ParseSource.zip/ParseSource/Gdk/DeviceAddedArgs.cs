﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000058 RID: 88
	public class DeviceAddedArgs : SignalArgs
	{
		// Token: 0x17000108 RID: 264
		// (get) Token: 0x060003E5 RID: 997 RVA: 0x0000C446 File Offset: 0x0000A646
		public Device Device
		{
			get
			{
				return (Device)base.Args[0];
			}
		}
	}
}
