﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000CE RID: 206
	public struct PixbufFrame : IEquatable<PixbufFrame>
	{
		// Token: 0x17000211 RID: 529
		// (get) Token: 0x060007F9 RID: 2041 RVA: 0x00017C61 File Offset: 0x00015E61
		// (set) Token: 0x060007FA RID: 2042 RVA: 0x00017C73 File Offset: 0x00015E73
		public Pixbuf Pixbuf
		{
			get
			{
				return Object.GetObject(this._pixbuf) as Pixbuf;
			}
			set
			{
				this._pixbuf = ((value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x17000212 RID: 530
		// (get) Token: 0x060007FB RID: 2043 RVA: 0x00017C8B File Offset: 0x00015E8B
		// (set) Token: 0x060007FC RID: 2044 RVA: 0x00017C9D File Offset: 0x00015E9D
		public Pixbuf Composited
		{
			get
			{
				return Object.GetObject(this._composited) as Pixbuf;
			}
			set
			{
				this._composited = ((value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x17000213 RID: 531
		// (get) Token: 0x060007FD RID: 2045 RVA: 0x00017CB5 File Offset: 0x00015EB5
		// (set) Token: 0x060007FE RID: 2046 RVA: 0x00017CC7 File Offset: 0x00015EC7
		public Pixbuf Revert
		{
			get
			{
				return Object.GetObject(this._revert) as Pixbuf;
			}
			set
			{
				this._revert = ((value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x060007FF RID: 2047 RVA: 0x00017CDF File Offset: 0x00015EDF
		public static PixbufFrame New(IntPtr raw)
		{
			if (raw == IntPtr.Zero)
			{
				return PixbufFrame.Zero;
			}
			return (PixbufFrame)Marshal.PtrToStructure(raw, typeof(PixbufFrame));
		}

		// Token: 0x06000800 RID: 2048 RVA: 0x00017D0C File Offset: 0x00015F0C
		public bool Equals(PixbufFrame other)
		{
			return this.Pixbuf.Equals(other.Pixbuf) && this.XOffset.Equals(other.XOffset) && this.YOffset.Equals(other.YOffset) && this.DelayTime.Equals(other.DelayTime) && this.Elapsed.Equals(other.Elapsed) && this.Action.Equals(other.Action) && this.NeedRecomposite.Equals(other.NeedRecomposite) && this.BgTransparent.Equals(other.BgTransparent) && this.Composited.Equals(other.Composited) && this.Revert.Equals(other.Revert);
		}

		// Token: 0x06000801 RID: 2049 RVA: 0x00017DEE File Offset: 0x00015FEE
		public override bool Equals(object other)
		{
			return other is PixbufFrame && this.Equals((PixbufFrame)other);
		}

		// Token: 0x06000802 RID: 2050 RVA: 0x00017E08 File Offset: 0x00016008
		public override int GetHashCode()
		{
			return base.GetType().FullName.GetHashCode() ^ this.Pixbuf.GetHashCode() ^ this.XOffset.GetHashCode() ^ this.YOffset.GetHashCode() ^ this.DelayTime.GetHashCode() ^ this.Elapsed.GetHashCode() ^ this.Action.GetHashCode() ^ this.NeedRecomposite.GetHashCode() ^ this.BgTransparent.GetHashCode() ^ this.Composited.GetHashCode() ^ this.Revert.GetHashCode();
		}

		// Token: 0x17000214 RID: 532
		// (get) Token: 0x06000803 RID: 2051 RVA: 0x00017EAD File Offset: 0x000160AD
		private static GType GType
		{
			get
			{
				return GType.Pointer;
			}
		}

		// Token: 0x17000215 RID: 533
		// (get) Token: 0x06000804 RID: 2052 RVA: 0x00017EB4 File Offset: 0x000160B4
		// (set) Token: 0x06000805 RID: 2053 RVA: 0x00017EC6 File Offset: 0x000160C6
		[Obsolete("Replaced by Pixbuf property.")]
		public Pixbuf pixbuf
		{
			get
			{
				return (Pixbuf)Object.GetObject(this._pixbuf);
			}
			set
			{
				this._pixbuf = value.Handle;
			}
		}

		// Token: 0x17000216 RID: 534
		// (get) Token: 0x06000806 RID: 2054 RVA: 0x00017ED4 File Offset: 0x000160D4
		// (set) Token: 0x06000807 RID: 2055 RVA: 0x00017EE6 File Offset: 0x000160E6
		[Obsolete("Replaced by Composited property.")]
		public Pixbuf composited
		{
			get
			{
				return (Pixbuf)Object.GetObject(this._composited);
			}
			set
			{
				this._composited = value.Handle;
			}
		}

		// Token: 0x17000217 RID: 535
		// (get) Token: 0x06000808 RID: 2056 RVA: 0x00017EF4 File Offset: 0x000160F4
		// (set) Token: 0x06000809 RID: 2057 RVA: 0x00017F06 File Offset: 0x00016106
		[Obsolete("Replaced by Revert property.")]
		public Pixbuf revert
		{
			get
			{
				return (Pixbuf)Object.GetObject(this._revert);
			}
			set
			{
				this._revert = value.Handle;
			}
		}

		// Token: 0x04000489 RID: 1161
		private IntPtr _pixbuf;

		// Token: 0x0400048A RID: 1162
		public int XOffset;

		// Token: 0x0400048B RID: 1163
		public int YOffset;

		// Token: 0x0400048C RID: 1164
		public int DelayTime;

		// Token: 0x0400048D RID: 1165
		public int Elapsed;

		// Token: 0x0400048E RID: 1166
		public PixbufFrameAction Action;

		// Token: 0x0400048F RID: 1167
		public bool NeedRecomposite;

		// Token: 0x04000490 RID: 1168
		public bool BgTransparent;

		// Token: 0x04000491 RID: 1169
		private IntPtr _composited;

		// Token: 0x04000492 RID: 1170
		private IntPtr _revert;

		// Token: 0x04000493 RID: 1171
		public static PixbufFrame Zero;
	}
}
