﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000087 RID: 135
	public class FrameClock : Object
	{
		// Token: 0x06000582 RID: 1410 RVA: 0x00010B24 File Offset: 0x0000ED24
		public FrameClock(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000583 RID: 1411 RVA: 0x00010B2D File Offset: 0x0000ED2D
		protected FrameClock() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x14000011 RID: 17
		// (add) Token: 0x06000584 RID: 1412 RVA: 0x00010B4C File Offset: 0x0000ED4C
		// (remove) Token: 0x06000585 RID: 1413 RVA: 0x00010B5A File Offset: 0x0000ED5A
		[Signal("after-paint")]
		public event EventHandler AfterPaint
		{
			add
			{
				base.AddSignalHandler("after-paint", value);
			}
			remove
			{
				base.RemoveSignalHandler("after-paint", value);
			}
		}

		// Token: 0x14000012 RID: 18
		// (add) Token: 0x06000586 RID: 1414 RVA: 0x00010B68 File Offset: 0x0000ED68
		// (remove) Token: 0x06000587 RID: 1415 RVA: 0x00010B76 File Offset: 0x0000ED76
		[Signal("update")]
		public event EventHandler Update
		{
			add
			{
				base.AddSignalHandler("update", value);
			}
			remove
			{
				base.RemoveSignalHandler("update", value);
			}
		}

		// Token: 0x14000013 RID: 19
		// (add) Token: 0x06000588 RID: 1416 RVA: 0x00010B84 File Offset: 0x0000ED84
		// (remove) Token: 0x06000589 RID: 1417 RVA: 0x00010B92 File Offset: 0x0000ED92
		[Signal("flush-events")]
		public event EventHandler FlushEvents
		{
			add
			{
				base.AddSignalHandler("flush-events", value);
			}
			remove
			{
				base.RemoveSignalHandler("flush-events", value);
			}
		}

		// Token: 0x14000014 RID: 20
		// (add) Token: 0x0600058A RID: 1418 RVA: 0x00010BA0 File Offset: 0x0000EDA0
		// (remove) Token: 0x0600058B RID: 1419 RVA: 0x00010BAE File Offset: 0x0000EDAE
		[Signal("layout")]
		public event EventHandler Layout
		{
			add
			{
				base.AddSignalHandler("layout", value);
			}
			remove
			{
				base.RemoveSignalHandler("layout", value);
			}
		}

		// Token: 0x14000015 RID: 21
		// (add) Token: 0x0600058C RID: 1420 RVA: 0x00010BBC File Offset: 0x0000EDBC
		// (remove) Token: 0x0600058D RID: 1421 RVA: 0x00010BCA File Offset: 0x0000EDCA
		[Signal("before-paint")]
		public event EventHandler BeforePaint
		{
			add
			{
				base.AddSignalHandler("before-paint", value);
			}
			remove
			{
				base.RemoveSignalHandler("before-paint", value);
			}
		}

		// Token: 0x14000016 RID: 22
		// (add) Token: 0x0600058E RID: 1422 RVA: 0x00010BD8 File Offset: 0x0000EDD8
		// (remove) Token: 0x0600058F RID: 1423 RVA: 0x00010BE6 File Offset: 0x0000EDE6
		[Signal("paint")]
		public event EventHandler Paint
		{
			add
			{
				base.AddSignalHandler("paint", value);
			}
			remove
			{
				base.RemoveSignalHandler("paint", value);
			}
		}

		// Token: 0x14000017 RID: 23
		// (add) Token: 0x06000590 RID: 1424 RVA: 0x00010BF4 File Offset: 0x0000EDF4
		// (remove) Token: 0x06000591 RID: 1425 RVA: 0x00010C02 File Offset: 0x0000EE02
		[Signal("resume-events")]
		public event EventHandler ResumeEvents
		{
			add
			{
				base.AddSignalHandler("resume-events", value);
			}
			remove
			{
				base.RemoveSignalHandler("resume-events", value);
			}
		}

		// Token: 0x17000165 RID: 357
		// (get) Token: 0x06000592 RID: 1426 RVA: 0x00010C10 File Offset: 0x0000EE10
		private static FrameClock.FlushEventsNativeDelegate FlushEventsVMCallback
		{
			get
			{
				if (FrameClock.FlushEvents_cb_delegate == null)
				{
					FrameClock.FlushEvents_cb_delegate = new FrameClock.FlushEventsNativeDelegate(FrameClock.FlushEvents_cb);
				}
				return FrameClock.FlushEvents_cb_delegate;
			}
		}

		// Token: 0x06000593 RID: 1427 RVA: 0x00010C2F File Offset: 0x0000EE2F
		private static void OverrideFlushEvents(GType gtype)
		{
			FrameClock.OverrideFlushEvents(gtype, FrameClock.FlushEventsVMCallback);
		}

		// Token: 0x06000594 RID: 1428 RVA: 0x00010C3C File Offset: 0x0000EE3C
		private static void OverrideFlushEvents(GType gtype, FrameClock.FlushEventsNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "flush-events", callback);
		}

		// Token: 0x06000595 RID: 1429 RVA: 0x00010C4C File Offset: 0x0000EE4C
		private static void FlushEvents_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as FrameClock).OnFlushEvents();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000596 RID: 1430 RVA: 0x00010C84 File Offset: 0x0000EE84
		[DefaultSignalHandler(Type = typeof(FrameClock), ConnectionMethod = "OverrideFlushEvents")]
		protected virtual void OnFlushEvents()
		{
			this.InternalFlushEvents();
		}

		// Token: 0x06000597 RID: 1431 RVA: 0x00010C8C File Offset: 0x0000EE8C
		private void InternalFlushEvents()
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(1U);
			Value[] array = new Value[]
			{
				new Value(this)
			};
			valueArray.Append(array[0]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x17000166 RID: 358
		// (get) Token: 0x06000598 RID: 1432 RVA: 0x00010CFE File Offset: 0x0000EEFE
		private static FrameClock.BeforePaintNativeDelegate BeforePaintVMCallback
		{
			get
			{
				if (FrameClock.BeforePaint_cb_delegate == null)
				{
					FrameClock.BeforePaint_cb_delegate = new FrameClock.BeforePaintNativeDelegate(FrameClock.BeforePaint_cb);
				}
				return FrameClock.BeforePaint_cb_delegate;
			}
		}

		// Token: 0x06000599 RID: 1433 RVA: 0x00010D1D File Offset: 0x0000EF1D
		private static void OverrideBeforePaint(GType gtype)
		{
			FrameClock.OverrideBeforePaint(gtype, FrameClock.BeforePaintVMCallback);
		}

		// Token: 0x0600059A RID: 1434 RVA: 0x00010D2A File Offset: 0x0000EF2A
		private static void OverrideBeforePaint(GType gtype, FrameClock.BeforePaintNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "before-paint", callback);
		}

		// Token: 0x0600059B RID: 1435 RVA: 0x00010D38 File Offset: 0x0000EF38
		private static void BeforePaint_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as FrameClock).OnBeforePaint();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x0600059C RID: 1436 RVA: 0x00010D70 File Offset: 0x0000EF70
		[DefaultSignalHandler(Type = typeof(FrameClock), ConnectionMethod = "OverrideBeforePaint")]
		protected virtual void OnBeforePaint()
		{
			this.InternalBeforePaint();
		}

		// Token: 0x0600059D RID: 1437 RVA: 0x00010D78 File Offset: 0x0000EF78
		private void InternalBeforePaint()
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(1U);
			Value[] array = new Value[]
			{
				new Value(this)
			};
			valueArray.Append(array[0]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x17000167 RID: 359
		// (get) Token: 0x0600059E RID: 1438 RVA: 0x00010DEA File Offset: 0x0000EFEA
		private static FrameClock.UpdateNativeDelegate UpdateVMCallback
		{
			get
			{
				if (FrameClock.Update_cb_delegate == null)
				{
					FrameClock.Update_cb_delegate = new FrameClock.UpdateNativeDelegate(FrameClock.Update_cb);
				}
				return FrameClock.Update_cb_delegate;
			}
		}

		// Token: 0x0600059F RID: 1439 RVA: 0x00010E09 File Offset: 0x0000F009
		private static void OverrideUpdate(GType gtype)
		{
			FrameClock.OverrideUpdate(gtype, FrameClock.UpdateVMCallback);
		}

		// Token: 0x060005A0 RID: 1440 RVA: 0x00010E16 File Offset: 0x0000F016
		private static void OverrideUpdate(GType gtype, FrameClock.UpdateNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "update", callback);
		}

		// Token: 0x060005A1 RID: 1441 RVA: 0x00010E24 File Offset: 0x0000F024
		private static void Update_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as FrameClock).OnUpdate();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005A2 RID: 1442 RVA: 0x00010E5C File Offset: 0x0000F05C
		[DefaultSignalHandler(Type = typeof(FrameClock), ConnectionMethod = "OverrideUpdate")]
		protected virtual void OnUpdate()
		{
			this.InternalUpdate();
		}

		// Token: 0x060005A3 RID: 1443 RVA: 0x00010E64 File Offset: 0x0000F064
		private void InternalUpdate()
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(1U);
			Value[] array = new Value[]
			{
				new Value(this)
			};
			valueArray.Append(array[0]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x17000168 RID: 360
		// (get) Token: 0x060005A4 RID: 1444 RVA: 0x00010ED6 File Offset: 0x0000F0D6
		private static FrameClock.LayoutNativeDelegate LayoutVMCallback
		{
			get
			{
				if (FrameClock.Layout_cb_delegate == null)
				{
					FrameClock.Layout_cb_delegate = new FrameClock.LayoutNativeDelegate(FrameClock.Layout_cb);
				}
				return FrameClock.Layout_cb_delegate;
			}
		}

		// Token: 0x060005A5 RID: 1445 RVA: 0x00010EF5 File Offset: 0x0000F0F5
		private static void OverrideLayout(GType gtype)
		{
			FrameClock.OverrideLayout(gtype, FrameClock.LayoutVMCallback);
		}

		// Token: 0x060005A6 RID: 1446 RVA: 0x00010F02 File Offset: 0x0000F102
		private static void OverrideLayout(GType gtype, FrameClock.LayoutNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "layout", callback);
		}

		// Token: 0x060005A7 RID: 1447 RVA: 0x00010F10 File Offset: 0x0000F110
		private static void Layout_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as FrameClock).OnLayout();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005A8 RID: 1448 RVA: 0x00010F48 File Offset: 0x0000F148
		[DefaultSignalHandler(Type = typeof(FrameClock), ConnectionMethod = "OverrideLayout")]
		protected virtual void OnLayout()
		{
			this.InternalLayout();
		}

		// Token: 0x060005A9 RID: 1449 RVA: 0x00010F50 File Offset: 0x0000F150
		private void InternalLayout()
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(1U);
			Value[] array = new Value[]
			{
				new Value(this)
			};
			valueArray.Append(array[0]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x17000169 RID: 361
		// (get) Token: 0x060005AA RID: 1450 RVA: 0x00010FC2 File Offset: 0x0000F1C2
		private static FrameClock.PaintNativeDelegate PaintVMCallback
		{
			get
			{
				if (FrameClock.Paint_cb_delegate == null)
				{
					FrameClock.Paint_cb_delegate = new FrameClock.PaintNativeDelegate(FrameClock.Paint_cb);
				}
				return FrameClock.Paint_cb_delegate;
			}
		}

		// Token: 0x060005AB RID: 1451 RVA: 0x00010FE1 File Offset: 0x0000F1E1
		private static void OverridePaint(GType gtype)
		{
			FrameClock.OverridePaint(gtype, FrameClock.PaintVMCallback);
		}

		// Token: 0x060005AC RID: 1452 RVA: 0x00010FEE File Offset: 0x0000F1EE
		private static void OverridePaint(GType gtype, FrameClock.PaintNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "paint", callback);
		}

		// Token: 0x060005AD RID: 1453 RVA: 0x00010FFC File Offset: 0x0000F1FC
		private static void Paint_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as FrameClock).OnPaint();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005AE RID: 1454 RVA: 0x00011034 File Offset: 0x0000F234
		[DefaultSignalHandler(Type = typeof(FrameClock), ConnectionMethod = "OverridePaint")]
		protected virtual void OnPaint()
		{
			this.InternalPaint();
		}

		// Token: 0x060005AF RID: 1455 RVA: 0x0001103C File Offset: 0x0000F23C
		private void InternalPaint()
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(1U);
			Value[] array = new Value[]
			{
				new Value(this)
			};
			valueArray.Append(array[0]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x1700016A RID: 362
		// (get) Token: 0x060005B0 RID: 1456 RVA: 0x000110AE File Offset: 0x0000F2AE
		private static FrameClock.AfterPaintNativeDelegate AfterPaintVMCallback
		{
			get
			{
				if (FrameClock.AfterPaint_cb_delegate == null)
				{
					FrameClock.AfterPaint_cb_delegate = new FrameClock.AfterPaintNativeDelegate(FrameClock.AfterPaint_cb);
				}
				return FrameClock.AfterPaint_cb_delegate;
			}
		}

		// Token: 0x060005B1 RID: 1457 RVA: 0x000110CD File Offset: 0x0000F2CD
		private static void OverrideAfterPaint(GType gtype)
		{
			FrameClock.OverrideAfterPaint(gtype, FrameClock.AfterPaintVMCallback);
		}

		// Token: 0x060005B2 RID: 1458 RVA: 0x000110DA File Offset: 0x0000F2DA
		private static void OverrideAfterPaint(GType gtype, FrameClock.AfterPaintNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "after-paint", callback);
		}

		// Token: 0x060005B3 RID: 1459 RVA: 0x000110E8 File Offset: 0x0000F2E8
		private static void AfterPaint_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as FrameClock).OnAfterPaint();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005B4 RID: 1460 RVA: 0x00011120 File Offset: 0x0000F320
		[DefaultSignalHandler(Type = typeof(FrameClock), ConnectionMethod = "OverrideAfterPaint")]
		protected virtual void OnAfterPaint()
		{
			this.InternalAfterPaint();
		}

		// Token: 0x060005B5 RID: 1461 RVA: 0x00011128 File Offset: 0x0000F328
		private void InternalAfterPaint()
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(1U);
			Value[] array = new Value[]
			{
				new Value(this)
			};
			valueArray.Append(array[0]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x1700016B RID: 363
		// (get) Token: 0x060005B6 RID: 1462 RVA: 0x0001119A File Offset: 0x0000F39A
		private static FrameClock.ResumeEventsNativeDelegate ResumeEventsVMCallback
		{
			get
			{
				if (FrameClock.ResumeEvents_cb_delegate == null)
				{
					FrameClock.ResumeEvents_cb_delegate = new FrameClock.ResumeEventsNativeDelegate(FrameClock.ResumeEvents_cb);
				}
				return FrameClock.ResumeEvents_cb_delegate;
			}
		}

		// Token: 0x060005B7 RID: 1463 RVA: 0x000111B9 File Offset: 0x0000F3B9
		private static void OverrideResumeEvents(GType gtype)
		{
			FrameClock.OverrideResumeEvents(gtype, FrameClock.ResumeEventsVMCallback);
		}

		// Token: 0x060005B8 RID: 1464 RVA: 0x000111C6 File Offset: 0x0000F3C6
		private static void OverrideResumeEvents(GType gtype, FrameClock.ResumeEventsNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "resume-events", callback);
		}

		// Token: 0x060005B9 RID: 1465 RVA: 0x000111D4 File Offset: 0x0000F3D4
		private static void ResumeEvents_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as FrameClock).OnResumeEvents();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005BA RID: 1466 RVA: 0x0001120C File Offset: 0x0000F40C
		[DefaultSignalHandler(Type = typeof(FrameClock), ConnectionMethod = "OverrideResumeEvents")]
		protected virtual void OnResumeEvents()
		{
			this.InternalResumeEvents();
		}

		// Token: 0x060005BB RID: 1467 RVA: 0x00011214 File Offset: 0x0000F414
		private void InternalResumeEvents()
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(1U);
			Value[] array = new Value[]
			{
				new Value(this)
			};
			valueArray.Append(array[0]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x1700016C RID: 364
		// (get) Token: 0x060005BC RID: 1468 RVA: 0x00011286 File Offset: 0x0000F486
		private static FrameClock.GetFrameTimeNativeDelegate GetFrameTimeVMCallback
		{
			get
			{
				if (FrameClock.GetFrameTime_cb_delegate == null)
				{
					FrameClock.GetFrameTime_cb_delegate = new FrameClock.GetFrameTimeNativeDelegate(FrameClock.GetFrameTime_cb);
				}
				return FrameClock.GetFrameTime_cb_delegate;
			}
		}

		// Token: 0x060005BD RID: 1469 RVA: 0x000112A5 File Offset: 0x0000F4A5
		private static void OverrideGetFrameTime(GType gtype)
		{
			FrameClock.OverrideGetFrameTime(gtype, FrameClock.GetFrameTimeVMCallback);
		}

		// Token: 0x060005BE RID: 1470 RVA: 0x000112B4 File Offset: 0x0000F4B4
		private unsafe static void OverrideGetFrameTime(GType gtype, FrameClock.GetFrameTimeNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + FrameClock.class_abi.GetFieldOffset("get_frame_time");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060005BF RID: 1471 RVA: 0x000112E8 File Offset: 0x0000F4E8
		private static long GetFrameTime_cb(IntPtr inst)
		{
			long result;
			try
			{
				result = (Object.GetObject(inst, false) as FrameClock).OnGetFrameTime();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060005C0 RID: 1472 RVA: 0x00011324 File Offset: 0x0000F524
		[DefaultSignalHandler(Type = typeof(FrameClock), ConnectionMethod = "OverrideGetFrameTime")]
		protected virtual long OnGetFrameTime()
		{
			return this.InternalGetFrameTime();
		}

		// Token: 0x060005C1 RID: 1473 RVA: 0x0001132C File Offset: 0x0000F52C
		private long InternalGetFrameTime()
		{
			FrameClock.GetFrameTimeNativeDelegate getFrameTimeNativeDelegate = FrameClock.class_abi.BaseOverride(base.LookupGType(), "get_frame_time");
			if (getFrameTimeNativeDelegate == null)
			{
				return 0L;
			}
			return getFrameTimeNativeDelegate(base.Handle);
		}

		// Token: 0x1700016D RID: 365
		// (get) Token: 0x060005C2 RID: 1474 RVA: 0x00011361 File Offset: 0x0000F561
		private static FrameClock.RequestPhaseNativeDelegate RequestPhaseVMCallback
		{
			get
			{
				if (FrameClock.RequestPhase_cb_delegate == null)
				{
					FrameClock.RequestPhase_cb_delegate = new FrameClock.RequestPhaseNativeDelegate(FrameClock.RequestPhase_cb);
				}
				return FrameClock.RequestPhase_cb_delegate;
			}
		}

		// Token: 0x060005C3 RID: 1475 RVA: 0x00011380 File Offset: 0x0000F580
		private static void OverrideRequestPhase(GType gtype)
		{
			FrameClock.OverrideRequestPhase(gtype, FrameClock.RequestPhaseVMCallback);
		}

		// Token: 0x060005C4 RID: 1476 RVA: 0x00011390 File Offset: 0x0000F590
		private unsafe static void OverrideRequestPhase(GType gtype, FrameClock.RequestPhaseNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + FrameClock.class_abi.GetFieldOffset("request_phase");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060005C5 RID: 1477 RVA: 0x000113C4 File Offset: 0x0000F5C4
		private static void RequestPhase_cb(IntPtr inst, int phase)
		{
			try
			{
				(Object.GetObject(inst, false) as FrameClock).OnRequestPhase((FrameClockPhase)phase);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005C6 RID: 1478 RVA: 0x00011400 File Offset: 0x0000F600
		[DefaultSignalHandler(Type = typeof(FrameClock), ConnectionMethod = "OverrideRequestPhase")]
		protected virtual void OnRequestPhase(FrameClockPhase phase)
		{
			this.InternalRequestPhase(phase);
		}

		// Token: 0x060005C7 RID: 1479 RVA: 0x0001140C File Offset: 0x0000F60C
		private void InternalRequestPhase(FrameClockPhase phase)
		{
			FrameClock.RequestPhaseNativeDelegate requestPhaseNativeDelegate = FrameClock.class_abi.BaseOverride(base.LookupGType(), "request_phase");
			if (requestPhaseNativeDelegate == null)
			{
				return;
			}
			requestPhaseNativeDelegate(base.Handle, (int)phase);
		}

		// Token: 0x1700016E RID: 366
		// (get) Token: 0x060005C8 RID: 1480 RVA: 0x00011440 File Offset: 0x0000F640
		private static FrameClock.BeginUpdatingNativeDelegate BeginUpdatingVMCallback
		{
			get
			{
				if (FrameClock.BeginUpdating_cb_delegate == null)
				{
					FrameClock.BeginUpdating_cb_delegate = new FrameClock.BeginUpdatingNativeDelegate(FrameClock.BeginUpdating_cb);
				}
				return FrameClock.BeginUpdating_cb_delegate;
			}
		}

		// Token: 0x060005C9 RID: 1481 RVA: 0x0001145F File Offset: 0x0000F65F
		private static void OverrideBeginUpdating(GType gtype)
		{
			FrameClock.OverrideBeginUpdating(gtype, FrameClock.BeginUpdatingVMCallback);
		}

		// Token: 0x060005CA RID: 1482 RVA: 0x0001146C File Offset: 0x0000F66C
		private unsafe static void OverrideBeginUpdating(GType gtype, FrameClock.BeginUpdatingNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + FrameClock.class_abi.GetFieldOffset("begin_updating");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060005CB RID: 1483 RVA: 0x000114A0 File Offset: 0x0000F6A0
		private static void BeginUpdating_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as FrameClock).OnBeginUpdating();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005CC RID: 1484 RVA: 0x000114D8 File Offset: 0x0000F6D8
		[DefaultSignalHandler(Type = typeof(FrameClock), ConnectionMethod = "OverrideBeginUpdating")]
		protected virtual void OnBeginUpdating()
		{
			this.InternalBeginUpdating();
		}

		// Token: 0x060005CD RID: 1485 RVA: 0x000114E0 File Offset: 0x0000F6E0
		private void InternalBeginUpdating()
		{
			FrameClock.BeginUpdatingNativeDelegate beginUpdatingNativeDelegate = FrameClock.class_abi.BaseOverride(base.LookupGType(), "begin_updating");
			if (beginUpdatingNativeDelegate == null)
			{
				return;
			}
			beginUpdatingNativeDelegate(base.Handle);
		}

		// Token: 0x1700016F RID: 367
		// (get) Token: 0x060005CE RID: 1486 RVA: 0x00011513 File Offset: 0x0000F713
		private static FrameClock.EndUpdatingNativeDelegate EndUpdatingVMCallback
		{
			get
			{
				if (FrameClock.EndUpdating_cb_delegate == null)
				{
					FrameClock.EndUpdating_cb_delegate = new FrameClock.EndUpdatingNativeDelegate(FrameClock.EndUpdating_cb);
				}
				return FrameClock.EndUpdating_cb_delegate;
			}
		}

		// Token: 0x060005CF RID: 1487 RVA: 0x00011532 File Offset: 0x0000F732
		private static void OverrideEndUpdating(GType gtype)
		{
			FrameClock.OverrideEndUpdating(gtype, FrameClock.EndUpdatingVMCallback);
		}

		// Token: 0x060005D0 RID: 1488 RVA: 0x00011540 File Offset: 0x0000F740
		private unsafe static void OverrideEndUpdating(GType gtype, FrameClock.EndUpdatingNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + FrameClock.class_abi.GetFieldOffset("end_updating");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060005D1 RID: 1489 RVA: 0x00011574 File Offset: 0x0000F774
		private static void EndUpdating_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as FrameClock).OnEndUpdating();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005D2 RID: 1490 RVA: 0x000115AC File Offset: 0x0000F7AC
		[DefaultSignalHandler(Type = typeof(FrameClock), ConnectionMethod = "OverrideEndUpdating")]
		protected virtual void OnEndUpdating()
		{
			this.InternalEndUpdating();
		}

		// Token: 0x060005D3 RID: 1491 RVA: 0x000115B4 File Offset: 0x0000F7B4
		private void InternalEndUpdating()
		{
			FrameClock.EndUpdatingNativeDelegate endUpdatingNativeDelegate = FrameClock.class_abi.BaseOverride(base.LookupGType(), "end_updating");
			if (endUpdatingNativeDelegate == null)
			{
				return;
			}
			endUpdatingNativeDelegate(base.Handle);
		}

		// Token: 0x17000170 RID: 368
		// (get) Token: 0x060005D4 RID: 1492 RVA: 0x000115E7 File Offset: 0x0000F7E7
		private static FrameClock.FreezeNativeDelegate FreezeVMCallback
		{
			get
			{
				if (FrameClock.Freeze_cb_delegate == null)
				{
					FrameClock.Freeze_cb_delegate = new FrameClock.FreezeNativeDelegate(FrameClock.Freeze_cb);
				}
				return FrameClock.Freeze_cb_delegate;
			}
		}

		// Token: 0x060005D5 RID: 1493 RVA: 0x00011606 File Offset: 0x0000F806
		private static void OverrideFreeze(GType gtype)
		{
			FrameClock.OverrideFreeze(gtype, FrameClock.FreezeVMCallback);
		}

		// Token: 0x060005D6 RID: 1494 RVA: 0x00011614 File Offset: 0x0000F814
		private unsafe static void OverrideFreeze(GType gtype, FrameClock.FreezeNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + FrameClock.class_abi.GetFieldOffset("freeze");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060005D7 RID: 1495 RVA: 0x00011648 File Offset: 0x0000F848
		private static void Freeze_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as FrameClock).OnFreeze();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005D8 RID: 1496 RVA: 0x00011680 File Offset: 0x0000F880
		[DefaultSignalHandler(Type = typeof(FrameClock), ConnectionMethod = "OverrideFreeze")]
		protected virtual void OnFreeze()
		{
			this.InternalFreeze();
		}

		// Token: 0x060005D9 RID: 1497 RVA: 0x00011688 File Offset: 0x0000F888
		private void InternalFreeze()
		{
			FrameClock.FreezeNativeDelegate freezeNativeDelegate = FrameClock.class_abi.BaseOverride(base.LookupGType(), "freeze");
			if (freezeNativeDelegate == null)
			{
				return;
			}
			freezeNativeDelegate(base.Handle);
		}

		// Token: 0x17000171 RID: 369
		// (get) Token: 0x060005DA RID: 1498 RVA: 0x000116BB File Offset: 0x0000F8BB
		private static FrameClock.ThawNativeDelegate ThawVMCallback
		{
			get
			{
				if (FrameClock.Thaw_cb_delegate == null)
				{
					FrameClock.Thaw_cb_delegate = new FrameClock.ThawNativeDelegate(FrameClock.Thaw_cb);
				}
				return FrameClock.Thaw_cb_delegate;
			}
		}

		// Token: 0x060005DB RID: 1499 RVA: 0x000116DA File Offset: 0x0000F8DA
		private static void OverrideThaw(GType gtype)
		{
			FrameClock.OverrideThaw(gtype, FrameClock.ThawVMCallback);
		}

		// Token: 0x060005DC RID: 1500 RVA: 0x000116E8 File Offset: 0x0000F8E8
		private unsafe static void OverrideThaw(GType gtype, FrameClock.ThawNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + FrameClock.class_abi.GetFieldOffset("thaw");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060005DD RID: 1501 RVA: 0x0001171C File Offset: 0x0000F91C
		private static void Thaw_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as FrameClock).OnThaw();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060005DE RID: 1502 RVA: 0x00011754 File Offset: 0x0000F954
		[DefaultSignalHandler(Type = typeof(FrameClock), ConnectionMethod = "OverrideThaw")]
		protected virtual void OnThaw()
		{
			this.InternalThaw();
		}

		// Token: 0x060005DF RID: 1503 RVA: 0x0001175C File Offset: 0x0000F95C
		private void InternalThaw()
		{
			FrameClock.ThawNativeDelegate thawNativeDelegate = FrameClock.class_abi.BaseOverride(base.LookupGType(), "thaw");
			if (thawNativeDelegate == null)
			{
				return;
			}
			thawNativeDelegate(base.Handle);
		}

		// Token: 0x17000172 RID: 370
		// (get) Token: 0x060005E0 RID: 1504 RVA: 0x00011790 File Offset: 0x0000F990
		public new static AbiStruct class_abi
		{
			get
			{
				if (FrameClock._class_abi == null)
				{
					FrameClock._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("get_frame_time", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "request_phase", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("request_phase", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_frame_time", "begin_updating", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("begin_updating", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "request_phase", "end_updating", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("end_updating", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "begin_updating", "freeze", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("freeze", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "end_updating", "thaw", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("thaw", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "freeze", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return FrameClock._class_abi;
			}
		}

		// Token: 0x060005E1 RID: 1505 RVA: 0x00011923 File Offset: 0x0000FB23
		public void BeginUpdating()
		{
			FrameClock.gdk_frame_clock_begin_updating(base.Handle);
		}

		// Token: 0x060005E2 RID: 1506 RVA: 0x00011935 File Offset: 0x0000FB35
		public void EndUpdating()
		{
			FrameClock.gdk_frame_clock_end_updating(base.Handle);
		}

		// Token: 0x17000173 RID: 371
		// (get) Token: 0x060005E3 RID: 1507 RVA: 0x00011948 File Offset: 0x0000FB48
		public FrameTimings CurrentTimings
		{
			get
			{
				IntPtr intPtr = FrameClock.gdk_frame_clock_get_current_timings(base.Handle);
				if (!(intPtr == IntPtr.Zero))
				{
					return (FrameTimings)Opaque.GetOpaque(intPtr, typeof(FrameTimings), false);
				}
				return null;
			}
		}

		// Token: 0x17000174 RID: 372
		// (get) Token: 0x060005E4 RID: 1508 RVA: 0x0001198B File Offset: 0x0000FB8B
		public long FrameCounter
		{
			get
			{
				return FrameClock.gdk_frame_clock_get_frame_counter(base.Handle);
			}
		}

		// Token: 0x17000175 RID: 373
		// (get) Token: 0x060005E5 RID: 1509 RVA: 0x0001199D File Offset: 0x0000FB9D
		public long FrameTime
		{
			get
			{
				return FrameClock.gdk_frame_clock_get_frame_time(base.Handle);
			}
		}

		// Token: 0x17000176 RID: 374
		// (get) Token: 0x060005E6 RID: 1510 RVA: 0x000119AF File Offset: 0x0000FBAF
		public long HistoryStart
		{
			get
			{
				return FrameClock.gdk_frame_clock_get_history_start(base.Handle);
			}
		}

		// Token: 0x060005E7 RID: 1511 RVA: 0x000119C1 File Offset: 0x0000FBC1
		public void GetRefreshInfo(long base_time, out long refresh_interval_return, out long presentation_time_return)
		{
			FrameClock.gdk_frame_clock_get_refresh_info(base.Handle, base_time, out refresh_interval_return, out presentation_time_return);
		}

		// Token: 0x060005E8 RID: 1512 RVA: 0x000119D8 File Offset: 0x0000FBD8
		public FrameTimings GetTimings(long frame_counter)
		{
			IntPtr intPtr = FrameClock.gdk_frame_clock_get_timings(base.Handle, frame_counter);
			if (!(intPtr == IntPtr.Zero))
			{
				return (FrameTimings)Opaque.GetOpaque(intPtr, typeof(FrameTimings), false);
			}
			return null;
		}

		// Token: 0x17000177 RID: 375
		// (get) Token: 0x060005E9 RID: 1513 RVA: 0x00011A1C File Offset: 0x0000FC1C
		public new static GType GType
		{
			get
			{
				IntPtr val = FrameClock.gdk_frame_clock_get_type();
				return new GType(val);
			}
		}

		// Token: 0x060005EA RID: 1514 RVA: 0x00011A3A File Offset: 0x0000FC3A
		public void RequestPhase(FrameClockPhase phase)
		{
			FrameClock.gdk_frame_clock_request_phase(base.Handle, (int)phase);
		}

		// Token: 0x17000178 RID: 376
		// (get) Token: 0x060005EB RID: 1515 RVA: 0x00011A4D File Offset: 0x0000FC4D
		public new static AbiStruct abi_info
		{
			get
			{
				if (FrameClock._abi_info == null)
				{
					FrameClock._abi_info = new AbiStruct(Object.abi_info.Fields);
				}
				return FrameClock._abi_info;
			}
		}

		// Token: 0x040002F1 RID: 753
		private static FrameClock.FlushEventsNativeDelegate FlushEvents_cb_delegate;

		// Token: 0x040002F2 RID: 754
		private static FrameClock.BeforePaintNativeDelegate BeforePaint_cb_delegate;

		// Token: 0x040002F3 RID: 755
		private static FrameClock.UpdateNativeDelegate Update_cb_delegate;

		// Token: 0x040002F4 RID: 756
		private static FrameClock.LayoutNativeDelegate Layout_cb_delegate;

		// Token: 0x040002F5 RID: 757
		private static FrameClock.PaintNativeDelegate Paint_cb_delegate;

		// Token: 0x040002F6 RID: 758
		private static FrameClock.AfterPaintNativeDelegate AfterPaint_cb_delegate;

		// Token: 0x040002F7 RID: 759
		private static FrameClock.ResumeEventsNativeDelegate ResumeEvents_cb_delegate;

		// Token: 0x040002F8 RID: 760
		private static FrameClock.GetFrameTimeNativeDelegate GetFrameTime_cb_delegate;

		// Token: 0x040002F9 RID: 761
		private static FrameClock.RequestPhaseNativeDelegate RequestPhase_cb_delegate;

		// Token: 0x040002FA RID: 762
		private static FrameClock.BeginUpdatingNativeDelegate BeginUpdating_cb_delegate;

		// Token: 0x040002FB RID: 763
		private static FrameClock.EndUpdatingNativeDelegate EndUpdating_cb_delegate;

		// Token: 0x040002FC RID: 764
		private static FrameClock.FreezeNativeDelegate Freeze_cb_delegate;

		// Token: 0x040002FD RID: 765
		private static FrameClock.ThawNativeDelegate Thaw_cb_delegate;

		// Token: 0x040002FE RID: 766
		private static AbiStruct _class_abi = null;

		// Token: 0x040002FF RID: 767
		private static FrameClock.d_gdk_frame_clock_begin_updating gdk_frame_clock_begin_updating = FuncLoader.LoadFunction<FrameClock.d_gdk_frame_clock_begin_updating>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_clock_begin_updating"));

		// Token: 0x04000300 RID: 768
		private static FrameClock.d_gdk_frame_clock_end_updating gdk_frame_clock_end_updating = FuncLoader.LoadFunction<FrameClock.d_gdk_frame_clock_end_updating>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_clock_end_updating"));

		// Token: 0x04000301 RID: 769
		private static FrameClock.d_gdk_frame_clock_get_current_timings gdk_frame_clock_get_current_timings = FuncLoader.LoadFunction<FrameClock.d_gdk_frame_clock_get_current_timings>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_clock_get_current_timings"));

		// Token: 0x04000302 RID: 770
		private static FrameClock.d_gdk_frame_clock_get_frame_counter gdk_frame_clock_get_frame_counter = FuncLoader.LoadFunction<FrameClock.d_gdk_frame_clock_get_frame_counter>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_clock_get_frame_counter"));

		// Token: 0x04000303 RID: 771
		private static FrameClock.d_gdk_frame_clock_get_frame_time gdk_frame_clock_get_frame_time = FuncLoader.LoadFunction<FrameClock.d_gdk_frame_clock_get_frame_time>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_clock_get_frame_time"));

		// Token: 0x04000304 RID: 772
		private static FrameClock.d_gdk_frame_clock_get_history_start gdk_frame_clock_get_history_start = FuncLoader.LoadFunction<FrameClock.d_gdk_frame_clock_get_history_start>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_clock_get_history_start"));

		// Token: 0x04000305 RID: 773
		private static FrameClock.d_gdk_frame_clock_get_refresh_info gdk_frame_clock_get_refresh_info = FuncLoader.LoadFunction<FrameClock.d_gdk_frame_clock_get_refresh_info>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_clock_get_refresh_info"));

		// Token: 0x04000306 RID: 774
		private static FrameClock.d_gdk_frame_clock_get_timings gdk_frame_clock_get_timings = FuncLoader.LoadFunction<FrameClock.d_gdk_frame_clock_get_timings>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_clock_get_timings"));

		// Token: 0x04000307 RID: 775
		private static FrameClock.d_gdk_frame_clock_get_type gdk_frame_clock_get_type = FuncLoader.LoadFunction<FrameClock.d_gdk_frame_clock_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_clock_get_type"));

		// Token: 0x04000308 RID: 776
		private static FrameClock.d_gdk_frame_clock_request_phase gdk_frame_clock_request_phase = FuncLoader.LoadFunction<FrameClock.d_gdk_frame_clock_request_phase>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_frame_clock_request_phase"));

		// Token: 0x04000309 RID: 777
		private static AbiStruct _abi_info = null;

		// Token: 0x0200028C RID: 652
		// (Invoke) Token: 0x060010B7 RID: 4279
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void FlushEventsNativeDelegate(IntPtr inst);

		// Token: 0x0200028D RID: 653
		// (Invoke) Token: 0x060010BB RID: 4283
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void BeforePaintNativeDelegate(IntPtr inst);

		// Token: 0x0200028E RID: 654
		// (Invoke) Token: 0x060010BF RID: 4287
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void UpdateNativeDelegate(IntPtr inst);

		// Token: 0x0200028F RID: 655
		// (Invoke) Token: 0x060010C3 RID: 4291
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void LayoutNativeDelegate(IntPtr inst);

		// Token: 0x02000290 RID: 656
		// (Invoke) Token: 0x060010C7 RID: 4295
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void PaintNativeDelegate(IntPtr inst);

		// Token: 0x02000291 RID: 657
		// (Invoke) Token: 0x060010CB RID: 4299
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void AfterPaintNativeDelegate(IntPtr inst);

		// Token: 0x02000292 RID: 658
		// (Invoke) Token: 0x060010CF RID: 4303
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ResumeEventsNativeDelegate(IntPtr inst);

		// Token: 0x02000293 RID: 659
		// (Invoke) Token: 0x060010D3 RID: 4307
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate long GetFrameTimeNativeDelegate(IntPtr inst);

		// Token: 0x02000294 RID: 660
		// (Invoke) Token: 0x060010D7 RID: 4311
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void RequestPhaseNativeDelegate(IntPtr inst, int phase);

		// Token: 0x02000295 RID: 661
		// (Invoke) Token: 0x060010DB RID: 4315
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void BeginUpdatingNativeDelegate(IntPtr inst);

		// Token: 0x02000296 RID: 662
		// (Invoke) Token: 0x060010DF RID: 4319
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void EndUpdatingNativeDelegate(IntPtr inst);

		// Token: 0x02000297 RID: 663
		// (Invoke) Token: 0x060010E3 RID: 4323
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void FreezeNativeDelegate(IntPtr inst);

		// Token: 0x02000298 RID: 664
		// (Invoke) Token: 0x060010E7 RID: 4327
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ThawNativeDelegate(IntPtr inst);

		// Token: 0x02000299 RID: 665
		// (Invoke) Token: 0x060010EB RID: 4331
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_frame_clock_begin_updating(IntPtr raw);

		// Token: 0x0200029A RID: 666
		// (Invoke) Token: 0x060010EF RID: 4335
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_frame_clock_end_updating(IntPtr raw);

		// Token: 0x0200029B RID: 667
		// (Invoke) Token: 0x060010F3 RID: 4339
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_frame_clock_get_current_timings(IntPtr raw);

		// Token: 0x0200029C RID: 668
		// (Invoke) Token: 0x060010F7 RID: 4343
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate long d_gdk_frame_clock_get_frame_counter(IntPtr raw);

		// Token: 0x0200029D RID: 669
		// (Invoke) Token: 0x060010FB RID: 4347
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate long d_gdk_frame_clock_get_frame_time(IntPtr raw);

		// Token: 0x0200029E RID: 670
		// (Invoke) Token: 0x060010FF RID: 4351
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate long d_gdk_frame_clock_get_history_start(IntPtr raw);

		// Token: 0x0200029F RID: 671
		// (Invoke) Token: 0x06001103 RID: 4355
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_frame_clock_get_refresh_info(IntPtr raw, long base_time, out long refresh_interval_return, out long presentation_time_return);

		// Token: 0x020002A0 RID: 672
		// (Invoke) Token: 0x06001107 RID: 4359
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_frame_clock_get_timings(IntPtr raw, long frame_counter);

		// Token: 0x020002A1 RID: 673
		// (Invoke) Token: 0x0600110B RID: 4363
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_frame_clock_get_type();

		// Token: 0x020002A2 RID: 674
		// (Invoke) Token: 0x0600110F RID: 4367
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_frame_clock_request_phase(IntPtr raw, int phase);
	}
}
