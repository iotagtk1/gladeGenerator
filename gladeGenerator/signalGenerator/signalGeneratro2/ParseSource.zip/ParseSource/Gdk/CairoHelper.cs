﻿using System;
using System.Runtime.InteropServices;
using Cairo;
using GLib;

namespace Gdk
{
	// Token: 0x02000048 RID: 72
	public class CairoHelper
	{
		// Token: 0x060003A1 RID: 929 RVA: 0x0000B96C File Offset: 0x00009B6C
		[Obsolete]
		public static Context Create(Window window)
		{
			return new Context(CairoHelper.gdk_cairo_create((window == null) ? IntPtr.Zero : window.Handle), true);
		}

		// Token: 0x060003A2 RID: 930 RVA: 0x0000B990 File Offset: 0x00009B90
		public static void DrawFromGl(Context cr, Window window, int source, int source_type, int buffer_scale, int x, int y, int width, int height)
		{
			CairoHelper.gdk_cairo_draw_from_gl((cr == null) ? IntPtr.Zero : cr.Handle, (window == null) ? IntPtr.Zero : window.Handle, source, source_type, buffer_scale, x, y, width, height);
		}

		// Token: 0x060003A3 RID: 931 RVA: 0x0000B9D4 File Offset: 0x00009BD4
		public static bool GetClipRectangle(Context cr, out Rectangle rect)
		{
			IntPtr intPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(Rectangle)));
			bool result = CairoHelper.gdk_cairo_get_clip_rectangle((cr == null) ? IntPtr.Zero : cr.Handle, intPtr);
			rect = (Rectangle)Marshal.PtrToStructure(intPtr, typeof(Rectangle));
			Marshal.FreeHGlobal(intPtr);
			return result;
		}

		// Token: 0x060003A4 RID: 932 RVA: 0x0000BA32 File Offset: 0x00009C32
		public static DrawingContext GetDrawingContext(Context cr)
		{
			return Object.GetObject(CairoHelper.gdk_cairo_get_drawing_context((cr == null) ? IntPtr.Zero : cr.Handle)) as DrawingContext;
		}

		// Token: 0x060003A5 RID: 933 RVA: 0x0000BA58 File Offset: 0x00009C58
		public static void Rectangle(Context cr, Rectangle rectangle)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(rectangle);
			CairoHelper.gdk_cairo_rectangle((cr == null) ? IntPtr.Zero : cr.Handle, intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x060003A6 RID: 934 RVA: 0x0000BA92 File Offset: 0x00009C92
		public static void Region(Context cr, Region region)
		{
			CairoHelper.gdk_cairo_region((cr == null) ? IntPtr.Zero : cr.Handle, (region == null) ? IntPtr.Zero : region.Handle);
		}

		// Token: 0x060003A7 RID: 935 RVA: 0x0000BABE File Offset: 0x00009CBE
		public static Region RegionCreateFromSurface(Surface surface)
		{
			return new Region(CairoHelper.gdk_cairo_region_create_from_surface(surface.Handle));
		}

		// Token: 0x060003A8 RID: 936 RVA: 0x0000BAD8 File Offset: 0x00009CD8
		[Obsolete]
		public static void SetSourceColor(Context cr, Color color)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(color);
			CairoHelper.gdk_cairo_set_source_color((cr == null) ? IntPtr.Zero : cr.Handle, intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x060003A9 RID: 937 RVA: 0x0000BB12 File Offset: 0x00009D12
		public static void SetSourcePixbuf(Context cr, Pixbuf pixbuf, double pixbuf_x, double pixbuf_y)
		{
			CairoHelper.gdk_cairo_set_source_pixbuf((cr == null) ? IntPtr.Zero : cr.Handle, (pixbuf == null) ? IntPtr.Zero : pixbuf.Handle, pixbuf_x, pixbuf_y);
		}

		// Token: 0x060003AA RID: 938 RVA: 0x0000BB40 File Offset: 0x00009D40
		public static void SetSourceRgba(Context cr, RGBA rgba)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(rgba);
			CairoHelper.gdk_cairo_set_source_rgba((cr == null) ? IntPtr.Zero : cr.Handle, intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x060003AB RID: 939 RVA: 0x0000BB7A File Offset: 0x00009D7A
		public static void SetSourceWindow(Context cr, Window window, double x, double y)
		{
			CairoHelper.gdk_cairo_set_source_window((cr == null) ? IntPtr.Zero : cr.Handle, (window == null) ? IntPtr.Zero : window.Handle, x, y);
		}

		// Token: 0x060003AC RID: 940 RVA: 0x0000BBA8 File Offset: 0x00009DA8
		public static Surface SurfaceCreateFromPixbuf(Pixbuf pixbuf, int scale, Window for_window)
		{
			return Surface.Lookup(CairoHelper.gdk_cairo_surface_create_from_pixbuf((pixbuf == null) ? IntPtr.Zero : pixbuf.Handle, scale, (for_window == null) ? IntPtr.Zero : for_window.Handle), true);
		}

		// Token: 0x04000136 RID: 310
		private static CairoHelper.d_gdk_cairo_create gdk_cairo_create = FuncLoader.LoadFunction<CairoHelper.d_gdk_cairo_create>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cairo_create"));

		// Token: 0x04000137 RID: 311
		private static CairoHelper.d_gdk_cairo_draw_from_gl gdk_cairo_draw_from_gl = FuncLoader.LoadFunction<CairoHelper.d_gdk_cairo_draw_from_gl>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cairo_draw_from_gl"));

		// Token: 0x04000138 RID: 312
		private static CairoHelper.d_gdk_cairo_get_clip_rectangle gdk_cairo_get_clip_rectangle = FuncLoader.LoadFunction<CairoHelper.d_gdk_cairo_get_clip_rectangle>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cairo_get_clip_rectangle"));

		// Token: 0x04000139 RID: 313
		private static CairoHelper.d_gdk_cairo_get_drawing_context gdk_cairo_get_drawing_context = FuncLoader.LoadFunction<CairoHelper.d_gdk_cairo_get_drawing_context>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cairo_get_drawing_context"));

		// Token: 0x0400013A RID: 314
		private static CairoHelper.d_gdk_cairo_rectangle gdk_cairo_rectangle = FuncLoader.LoadFunction<CairoHelper.d_gdk_cairo_rectangle>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cairo_rectangle"));

		// Token: 0x0400013B RID: 315
		private static CairoHelper.d_gdk_cairo_region gdk_cairo_region = FuncLoader.LoadFunction<CairoHelper.d_gdk_cairo_region>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cairo_region"));

		// Token: 0x0400013C RID: 316
		private static CairoHelper.d_gdk_cairo_region_create_from_surface gdk_cairo_region_create_from_surface = FuncLoader.LoadFunction<CairoHelper.d_gdk_cairo_region_create_from_surface>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cairo_region_create_from_surface"));

		// Token: 0x0400013D RID: 317
		private static CairoHelper.d_gdk_cairo_set_source_color gdk_cairo_set_source_color = FuncLoader.LoadFunction<CairoHelper.d_gdk_cairo_set_source_color>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cairo_set_source_color"));

		// Token: 0x0400013E RID: 318
		private static CairoHelper.d_gdk_cairo_set_source_pixbuf gdk_cairo_set_source_pixbuf = FuncLoader.LoadFunction<CairoHelper.d_gdk_cairo_set_source_pixbuf>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cairo_set_source_pixbuf"));

		// Token: 0x0400013F RID: 319
		private static CairoHelper.d_gdk_cairo_set_source_rgba gdk_cairo_set_source_rgba = FuncLoader.LoadFunction<CairoHelper.d_gdk_cairo_set_source_rgba>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cairo_set_source_rgba"));

		// Token: 0x04000140 RID: 320
		private static CairoHelper.d_gdk_cairo_set_source_window gdk_cairo_set_source_window = FuncLoader.LoadFunction<CairoHelper.d_gdk_cairo_set_source_window>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cairo_set_source_window"));

		// Token: 0x04000141 RID: 321
		private static CairoHelper.d_gdk_cairo_surface_create_from_pixbuf gdk_cairo_surface_create_from_pixbuf = FuncLoader.LoadFunction<CairoHelper.d_gdk_cairo_surface_create_from_pixbuf>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cairo_surface_create_from_pixbuf"));

		// Token: 0x020001F6 RID: 502
		// (Invoke) Token: 0x06000E63 RID: 3683
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_cairo_create(IntPtr window);

		// Token: 0x020001F7 RID: 503
		// (Invoke) Token: 0x06000E67 RID: 3687
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_cairo_draw_from_gl(IntPtr cr, IntPtr window, int source, int source_type, int buffer_scale, int x, int y, int width, int height);

		// Token: 0x020001F8 RID: 504
		// (Invoke) Token: 0x06000E6B RID: 3691
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_cairo_get_clip_rectangle(IntPtr cr, IntPtr rect);

		// Token: 0x020001F9 RID: 505
		// (Invoke) Token: 0x06000E6F RID: 3695
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_cairo_get_drawing_context(IntPtr cr);

		// Token: 0x020001FA RID: 506
		// (Invoke) Token: 0x06000E73 RID: 3699
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_cairo_rectangle(IntPtr cr, IntPtr rectangle);

		// Token: 0x020001FB RID: 507
		// (Invoke) Token: 0x06000E77 RID: 3703
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_cairo_region(IntPtr cr, IntPtr region);

		// Token: 0x020001FC RID: 508
		// (Invoke) Token: 0x06000E7B RID: 3707
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_cairo_region_create_from_surface(IntPtr surface);

		// Token: 0x020001FD RID: 509
		// (Invoke) Token: 0x06000E7F RID: 3711
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_cairo_set_source_color(IntPtr cr, IntPtr color);

		// Token: 0x020001FE RID: 510
		// (Invoke) Token: 0x06000E83 RID: 3715
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_cairo_set_source_pixbuf(IntPtr cr, IntPtr pixbuf, double pixbuf_x, double pixbuf_y);

		// Token: 0x020001FF RID: 511
		// (Invoke) Token: 0x06000E87 RID: 3719
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_cairo_set_source_rgba(IntPtr cr, IntPtr rgba);

		// Token: 0x02000200 RID: 512
		// (Invoke) Token: 0x06000E8B RID: 3723
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_cairo_set_source_window(IntPtr cr, IntPtr window, double x, double y);

		// Token: 0x02000201 RID: 513
		// (Invoke) Token: 0x06000E8F RID: 3727
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_cairo_surface_create_from_pixbuf(IntPtr pixbuf, int scale, IntPtr for_window);
	}
}
