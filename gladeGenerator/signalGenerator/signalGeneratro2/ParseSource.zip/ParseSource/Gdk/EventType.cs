﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000082 RID: 130
	[GType(typeof(EventTypeGType))]
	public enum EventType
	{
		// Token: 0x040002B8 RID: 696
		Nothing = -1,
		// Token: 0x040002B9 RID: 697
		Delete,
		// Token: 0x040002BA RID: 698
		Destroy,
		// Token: 0x040002BB RID: 699
		Expose,
		// Token: 0x040002BC RID: 700
		MotionNotify,
		// Token: 0x040002BD RID: 701
		ButtonPress,
		// Token: 0x040002BE RID: 702
		TwoButtonPress,
		// Token: 0x040002BF RID: 703
		DoubleButtonPress = 5,
		// Token: 0x040002C0 RID: 704
		ThreeButtonPress,
		// Token: 0x040002C1 RID: 705
		TripleButtonPress = 6,
		// Token: 0x040002C2 RID: 706
		ButtonRelease,
		// Token: 0x040002C3 RID: 707
		KeyPress,
		// Token: 0x040002C4 RID: 708
		KeyRelease,
		// Token: 0x040002C5 RID: 709
		EnterNotify,
		// Token: 0x040002C6 RID: 710
		LeaveNotify,
		// Token: 0x040002C7 RID: 711
		FocusChange,
		// Token: 0x040002C8 RID: 712
		Configure,
		// Token: 0x040002C9 RID: 713
		Map,
		// Token: 0x040002CA RID: 714
		Unmap,
		// Token: 0x040002CB RID: 715
		PropertyNotify,
		// Token: 0x040002CC RID: 716
		SelectionClear,
		// Token: 0x040002CD RID: 717
		SelectionRequest,
		// Token: 0x040002CE RID: 718
		SelectionNotify,
		// Token: 0x040002CF RID: 719
		ProximityIn,
		// Token: 0x040002D0 RID: 720
		ProximityOut,
		// Token: 0x040002D1 RID: 721
		DragEnter,
		// Token: 0x040002D2 RID: 722
		DragLeave,
		// Token: 0x040002D3 RID: 723
		DragMotion,
		// Token: 0x040002D4 RID: 724
		DragStatus,
		// Token: 0x040002D5 RID: 725
		DropStart,
		// Token: 0x040002D6 RID: 726
		DropFinished,
		// Token: 0x040002D7 RID: 727
		ClientEvent,
		// Token: 0x040002D8 RID: 728
		VisibilityNotify,
		// Token: 0x040002D9 RID: 729
		Scroll = 31,
		// Token: 0x040002DA RID: 730
		WindowState,
		// Token: 0x040002DB RID: 731
		Setting,
		// Token: 0x040002DC RID: 732
		OwnerChange,
		// Token: 0x040002DD RID: 733
		GrabBroken,
		// Token: 0x040002DE RID: 734
		Damage,
		// Token: 0x040002DF RID: 735
		TouchBegin,
		// Token: 0x040002E0 RID: 736
		TouchUpdate,
		// Token: 0x040002E1 RID: 737
		TouchEnd,
		// Token: 0x040002E2 RID: 738
		TouchCancel,
		// Token: 0x040002E3 RID: 739
		TouchpadSwipe,
		// Token: 0x040002E4 RID: 740
		TouchpadPinch,
		// Token: 0x040002E5 RID: 741
		PadButtonPress,
		// Token: 0x040002E6 RID: 742
		PadButtonRelease,
		// Token: 0x040002E7 RID: 743
		PadRing,
		// Token: 0x040002E8 RID: 744
		PadStrip,
		// Token: 0x040002E9 RID: 745
		PadGroupMode,
		// Token: 0x040002EA RID: 746
		EventLast
	}
}
