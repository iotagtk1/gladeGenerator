﻿using System;

namespace Gdk
{
	// Token: 0x0200010C RID: 268
	// (Invoke) Token: 0x06000A3A RID: 2618
	public delegate void ToolChangedHandler(object o, ToolChangedArgs args);
}
