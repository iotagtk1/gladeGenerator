﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000031 RID: 49
	public class EventProximity : Event
	{
		// Token: 0x0600033B RID: 827 RVA: 0x0000AEDD File Offset: 0x000090DD
		public EventProximity(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x0600033C RID: 828 RVA: 0x0000AEE6 File Offset: 0x000090E6
		private EventProximity.NativeStruct Native
		{
			get
			{
				return (EventProximity.NativeStruct)Marshal.PtrToStructure(base.Handle, typeof(EventProximity.NativeStruct));
			}
		}

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x0600033D RID: 829 RVA: 0x0000AF02 File Offset: 0x00009102
		// (set) Token: 0x0600033E RID: 830 RVA: 0x0000AF1C File Offset: 0x0000911C
		public Device Device
		{
			get
			{
				return Object.GetObject(this.Native.device, false) as Device;
			}
			set
			{
				EventProximity.NativeStruct native = this.Native;
				native.device = ((value == null) ? IntPtr.Zero : value.Handle);
				Marshal.StructureToPtr<EventProximity.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x0600033F RID: 831 RVA: 0x0000AF54 File Offset: 0x00009154
		// (set) Token: 0x06000340 RID: 832 RVA: 0x0000AF64 File Offset: 0x00009164
		public uint Time
		{
			get
			{
				return this.Native.time;
			}
			set
			{
				EventProximity.NativeStruct native = this.Native;
				native.time = value;
				Marshal.StructureToPtr<EventProximity.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x020001E4 RID: 484
		private struct NativeStruct
		{
			// Token: 0x04000C6A RID: 3178
			private EventType type;

			// Token: 0x04000C6B RID: 3179
			private IntPtr window;

			// Token: 0x04000C6C RID: 3180
			private sbyte send_event;

			// Token: 0x04000C6D RID: 3181
			public uint time;

			// Token: 0x04000C6E RID: 3182
			public IntPtr device;
		}
	}
}
