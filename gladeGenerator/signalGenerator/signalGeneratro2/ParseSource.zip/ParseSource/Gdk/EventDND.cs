﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000029 RID: 41
	public class EventDND : Event
	{
		// Token: 0x060002E8 RID: 744 RVA: 0x0000A53D File Offset: 0x0000873D
		public EventDND(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700009F RID: 159
		// (get) Token: 0x060002E9 RID: 745 RVA: 0x0000A546 File Offset: 0x00008746
		private EventDND.NativeStruct Native
		{
			get
			{
				return (EventDND.NativeStruct)Marshal.PtrToStructure(base.Handle, typeof(EventDND.NativeStruct));
			}
		}

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x060002EA RID: 746 RVA: 0x0000A562 File Offset: 0x00008762
		// (set) Token: 0x060002EB RID: 747 RVA: 0x0000A57C File Offset: 0x0000877C
		public DragContext Context
		{
			get
			{
				return Object.GetObject(this.Native.context, false) as DragContext;
			}
			set
			{
				EventDND.NativeStruct native = this.Native;
				native.context = ((value == null) ? IntPtr.Zero : value.Handle);
				Marshal.StructureToPtr<EventDND.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x060002EC RID: 748 RVA: 0x0000A5B4 File Offset: 0x000087B4
		// (set) Token: 0x060002ED RID: 749 RVA: 0x0000A5C4 File Offset: 0x000087C4
		public uint Time
		{
			get
			{
				return this.Native.time;
			}
			set
			{
				EventDND.NativeStruct native = this.Native;
				native.time = value;
				Marshal.StructureToPtr<EventDND.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x060002EE RID: 750 RVA: 0x0000A5ED File Offset: 0x000087ED
		// (set) Token: 0x060002EF RID: 751 RVA: 0x0000A5FC File Offset: 0x000087FC
		public short XRoot
		{
			get
			{
				return this.Native.x_root;
			}
			set
			{
				EventDND.NativeStruct native = this.Native;
				native.x_root = value;
				Marshal.StructureToPtr<EventDND.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x060002F0 RID: 752 RVA: 0x0000A625 File Offset: 0x00008825
		// (set) Token: 0x060002F1 RID: 753 RVA: 0x0000A634 File Offset: 0x00008834
		public short YRoot
		{
			get
			{
				return this.Native.y_root;
			}
			set
			{
				EventDND.NativeStruct native = this.Native;
				native.y_root = value;
				Marshal.StructureToPtr<EventDND.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x020001DC RID: 476
		private struct NativeStruct
		{
			// Token: 0x04000C2F RID: 3119
			private EventType type;

			// Token: 0x04000C30 RID: 3120
			private IntPtr window;

			// Token: 0x04000C31 RID: 3121
			private sbyte send_event;

			// Token: 0x04000C32 RID: 3122
			public IntPtr context;

			// Token: 0x04000C33 RID: 3123
			public uint time;

			// Token: 0x04000C34 RID: 3124
			public short x_root;

			// Token: 0x04000C35 RID: 3125
			public short y_root;
		}
	}
}
