﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000FE RID: 254
	internal class StatusGType
	{
		// Token: 0x17000288 RID: 648
		// (get) Token: 0x06000A0E RID: 2574 RVA: 0x0001DAF7 File Offset: 0x0001BCF7
		public static GType GType
		{
			get
			{
				return new GType(StatusGType.gdk_status_get_type());
			}
		}

		// Token: 0x04000578 RID: 1400
		private static StatusGType.d_gdk_status_get_type gdk_status_get_type = FuncLoader.LoadFunction<StatusGType.d_gdk_status_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_status_get_type"));

		// Token: 0x0200040B RID: 1035
		// (Invoke) Token: 0x060016AE RID: 5806
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_status_get_type();
	}
}
