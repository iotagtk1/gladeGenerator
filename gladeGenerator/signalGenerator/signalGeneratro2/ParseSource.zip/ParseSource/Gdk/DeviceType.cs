﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000064 RID: 100
	[GType(typeof(DeviceTypeGType))]
	public enum DeviceType
	{
		// Token: 0x040001DA RID: 474
		Master,
		// Token: 0x040001DB RID: 475
		Slave,
		// Token: 0x040001DC RID: 476
		Floating
	}
}
