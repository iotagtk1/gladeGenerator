﻿using System;
using System.Runtime.InteropServices;

namespace Gdk
{
	// Token: 0x02000036 RID: 54
	public class EventWindowState : Event
	{
		// Token: 0x0600036D RID: 877 RVA: 0x0000B4B5 File Offset: 0x000096B5
		public EventWindowState(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x0600036E RID: 878 RVA: 0x0000B4BE File Offset: 0x000096BE
		private EventWindowState.NativeStruct Native
		{
			get
			{
				return (EventWindowState.NativeStruct)Marshal.PtrToStructure(base.Handle, typeof(EventWindowState.NativeStruct));
			}
		}

		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x0600036F RID: 879 RVA: 0x0000B4DA File Offset: 0x000096DA
		// (set) Token: 0x06000370 RID: 880 RVA: 0x0000B4E8 File Offset: 0x000096E8
		public WindowState ChangedMask
		{
			get
			{
				return this.Native.changed_mask;
			}
			set
			{
				EventWindowState.NativeStruct native = this.Native;
				native.changed_mask = value;
				Marshal.StructureToPtr<EventWindowState.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x06000371 RID: 881 RVA: 0x0000B511 File Offset: 0x00009711
		// (set) Token: 0x06000372 RID: 882 RVA: 0x0000B520 File Offset: 0x00009720
		public WindowState NewWindowState
		{
			get
			{
				return this.Native.new_window_state;
			}
			set
			{
				EventWindowState.NativeStruct native = this.Native;
				native.new_window_state = value;
				Marshal.StructureToPtr<EventWindowState.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x020001E9 RID: 489
		private struct NativeStruct
		{
			// Token: 0x04000C8D RID: 3213
			private EventType type;

			// Token: 0x04000C8E RID: 3214
			private IntPtr window;

			// Token: 0x04000C8F RID: 3215
			private sbyte send_event;

			// Token: 0x04000C90 RID: 3216
			public WindowState changed_mask;

			// Token: 0x04000C91 RID: 3217
			public WindowState new_window_state;
		}
	}
}
