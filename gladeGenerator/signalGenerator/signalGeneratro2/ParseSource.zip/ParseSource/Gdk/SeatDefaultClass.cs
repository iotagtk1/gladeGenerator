﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x020000F4 RID: 244
	public class SeatDefaultClass : Opaque
	{
		// Token: 0x060009EF RID: 2543 RVA: 0x0001D794 File Offset: 0x0001B994
		public SeatDefaultClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000283 RID: 643
		// (get) Token: 0x060009F0 RID: 2544 RVA: 0x0001D79D File Offset: 0x0001B99D
		public static AbiStruct abi_info
		{
			get
			{
				if (SeatDefaultClass._abi_info == null)
				{
					SeatDefaultClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return SeatDefaultClass._abi_info;
			}
		}

		// Token: 0x04000562 RID: 1378
		private static AbiStruct _abi_info;
	}
}
