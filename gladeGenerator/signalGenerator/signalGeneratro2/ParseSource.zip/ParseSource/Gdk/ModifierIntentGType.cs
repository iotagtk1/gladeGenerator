﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000AF RID: 175
	internal class ModifierIntentGType
	{
		// Token: 0x170001CD RID: 461
		// (get) Token: 0x06000710 RID: 1808 RVA: 0x00014ABB File Offset: 0x00012CBB
		public static GType GType
		{
			get
			{
				return new GType(ModifierIntentGType.gdk_modifier_intent_get_type());
			}
		}

		// Token: 0x040003CE RID: 974
		private static ModifierIntentGType.d_gdk_modifier_intent_get_type gdk_modifier_intent_get_type = FuncLoader.LoadFunction<ModifierIntentGType.d_gdk_modifier_intent_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_modifier_intent_get_type"));

		// Token: 0x02000308 RID: 776
		// (Invoke) Token: 0x060012A5 RID: 4773
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_modifier_intent_get_type();
	}
}
