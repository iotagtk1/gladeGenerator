﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000E6 RID: 230
	[GType(typeof(PropertyStateGType))]
	public enum PropertyState
	{
		// Token: 0x040004E8 RID: 1256
		NewValue,
		// Token: 0x040004E9 RID: 1257
		Delete
	}
}
