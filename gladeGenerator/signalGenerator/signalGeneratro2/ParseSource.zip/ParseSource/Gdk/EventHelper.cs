﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000077 RID: 119
	public class EventHelper
	{
		// Token: 0x06000512 RID: 1298 RVA: 0x0000F41C File Offset: 0x0000D61C
		public static Event Copy(Event evnt)
		{
			return Event.GetEvent(EventHelper.gdk_event_copy((evnt == null) ? IntPtr.Zero : evnt.Handle));
		}

		// Token: 0x06000513 RID: 1299 RVA: 0x0000F43D File Offset: 0x0000D63D
		public static void Free(Event evnt)
		{
			EventHelper.gdk_event_free((evnt == null) ? IntPtr.Zero : evnt.Handle);
		}

		// Token: 0x06000514 RID: 1300 RVA: 0x0000F459 File Offset: 0x0000D659
		public static Event Get()
		{
			return Event.GetEvent(EventHelper.gdk_event_get());
		}

		// Token: 0x06000515 RID: 1301 RVA: 0x0000F46A File Offset: 0x0000D66A
		public static bool GetAxis(Event evnt, AxisUse axis_use, out double value)
		{
			return EventHelper.gdk_event_get_axis((evnt == null) ? IntPtr.Zero : evnt.Handle, (int)axis_use, out value);
		}

		// Token: 0x06000516 RID: 1302 RVA: 0x0000F488 File Offset: 0x0000D688
		public static bool GetButton(Event evnt, out uint button)
		{
			return EventHelper.gdk_event_get_button((evnt == null) ? IntPtr.Zero : evnt.Handle, out button);
		}

		// Token: 0x06000517 RID: 1303 RVA: 0x0000F4A5 File Offset: 0x0000D6A5
		public static bool GetClickCount(Event evnt, out uint click_count)
		{
			return EventHelper.gdk_event_get_click_count((evnt == null) ? IntPtr.Zero : evnt.Handle, out click_count);
		}

		// Token: 0x06000518 RID: 1304 RVA: 0x0000F4C2 File Offset: 0x0000D6C2
		public static bool GetCoords(Event evnt, out double x_win, out double y_win)
		{
			return EventHelper.gdk_event_get_coords((evnt == null) ? IntPtr.Zero : evnt.Handle, out x_win, out y_win);
		}

		// Token: 0x06000519 RID: 1305 RVA: 0x0000F4E0 File Offset: 0x0000D6E0
		public static Device GetDevice(Event evnt)
		{
			return Object.GetObject(EventHelper.gdk_event_get_device((evnt == null) ? IntPtr.Zero : evnt.Handle)) as Device;
		}

		// Token: 0x0600051A RID: 1306 RVA: 0x0000F506 File Offset: 0x0000D706
		public static DeviceTool GetDeviceTool(Event evnt)
		{
			return Object.GetObject(EventHelper.gdk_event_get_device_tool((evnt == null) ? IntPtr.Zero : evnt.Handle)) as DeviceTool;
		}

		// Token: 0x0600051B RID: 1307 RVA: 0x0000F52C File Offset: 0x0000D72C
		public static EventSequence GetEventSequence(Event evnt)
		{
			IntPtr intPtr = EventHelper.gdk_event_get_event_sequence((evnt == null) ? IntPtr.Zero : evnt.Handle);
			if (!(intPtr == IntPtr.Zero))
			{
				return (EventSequence)Opaque.GetOpaque(intPtr, typeof(EventSequence), false);
			}
			return null;
		}

		// Token: 0x0600051C RID: 1308 RVA: 0x0000F579 File Offset: 0x0000D779
		public static EventType GetEventType(Event evnt)
		{
			return (EventType)EventHelper.gdk_event_get_event_type((evnt == null) ? IntPtr.Zero : evnt.Handle);
		}

		// Token: 0x0600051D RID: 1309 RVA: 0x0000F595 File Offset: 0x0000D795
		public static bool GetKeycode(Event evnt, out ushort keycode)
		{
			return EventHelper.gdk_event_get_keycode((evnt == null) ? IntPtr.Zero : evnt.Handle, out keycode);
		}

		// Token: 0x0600051E RID: 1310 RVA: 0x0000F5B2 File Offset: 0x0000D7B2
		public static bool GetKeyval(Event evnt, out uint keyval)
		{
			return EventHelper.gdk_event_get_keyval((evnt == null) ? IntPtr.Zero : evnt.Handle, out keyval);
		}

		// Token: 0x0600051F RID: 1311 RVA: 0x0000F5CF File Offset: 0x0000D7CF
		public static bool GetPointerEmulated(Event evnt)
		{
			return EventHelper.gdk_event_get_pointer_emulated((evnt == null) ? IntPtr.Zero : evnt.Handle);
		}

		// Token: 0x06000520 RID: 1312 RVA: 0x0000F5EB File Offset: 0x0000D7EB
		public static bool GetRootCoords(Event evnt, out double x_root, out double y_root)
		{
			return EventHelper.gdk_event_get_root_coords((evnt == null) ? IntPtr.Zero : evnt.Handle, out x_root, out y_root);
		}

		// Token: 0x06000521 RID: 1313 RVA: 0x0000F609 File Offset: 0x0000D809
		public static int GetScancode(Event evnt)
		{
			return EventHelper.gdk_event_get_scancode((evnt == null) ? IntPtr.Zero : evnt.Handle);
		}

		// Token: 0x06000522 RID: 1314 RVA: 0x0000F625 File Offset: 0x0000D825
		public static Screen GetScreen(Event evnt)
		{
			return Object.GetObject(EventHelper.gdk_event_get_screen((evnt == null) ? IntPtr.Zero : evnt.Handle)) as Screen;
		}

		// Token: 0x06000523 RID: 1315 RVA: 0x0000F64B File Offset: 0x0000D84B
		public static bool GetScrollDeltas(Event evnt, out double delta_x, out double delta_y)
		{
			return EventHelper.gdk_event_get_scroll_deltas((evnt == null) ? IntPtr.Zero : evnt.Handle, out delta_x, out delta_y);
		}

		// Token: 0x06000524 RID: 1316 RVA: 0x0000F66C File Offset: 0x0000D86C
		public static bool GetScrollDirection(Event evnt, out ScrollDirection direction)
		{
			int num;
			bool result = EventHelper.gdk_event_get_scroll_direction((evnt == null) ? IntPtr.Zero : evnt.Handle, out num);
			direction = (ScrollDirection)num;
			return result;
		}

		// Token: 0x06000525 RID: 1317 RVA: 0x0000F698 File Offset: 0x0000D898
		public static Seat GetSeat(Event evnt)
		{
			return Object.GetObject(EventHelper.gdk_event_get_seat((evnt == null) ? IntPtr.Zero : evnt.Handle)) as Seat;
		}

		// Token: 0x06000526 RID: 1318 RVA: 0x0000F6BE File Offset: 0x0000D8BE
		public static Device GetSourceDevice(Event evnt)
		{
			return Object.GetObject(EventHelper.gdk_event_get_source_device((evnt == null) ? IntPtr.Zero : evnt.Handle)) as Device;
		}

		// Token: 0x06000527 RID: 1319 RVA: 0x0000F6E4 File Offset: 0x0000D8E4
		public static bool GetState(Event evnt, out ModifierType state)
		{
			int num;
			bool result = EventHelper.gdk_event_get_state((evnt == null) ? IntPtr.Zero : evnt.Handle, out num);
			state = (ModifierType)num;
			return result;
		}

		// Token: 0x06000528 RID: 1320 RVA: 0x0000F710 File Offset: 0x0000D910
		public static uint GetTime(Event evnt)
		{
			return EventHelper.gdk_event_get_time((evnt == null) ? IntPtr.Zero : evnt.Handle);
		}

		// Token: 0x17000151 RID: 337
		// (get) Token: 0x06000529 RID: 1321 RVA: 0x0000F72C File Offset: 0x0000D92C
		public static GType GType
		{
			get
			{
				IntPtr val = EventHelper.gdk_event_get_type();
				return new GType(val);
			}
		}

		// Token: 0x0600052A RID: 1322 RVA: 0x0000F74A File Offset: 0x0000D94A
		public static Window GetWindow(Event evnt)
		{
			return Object.GetObject(EventHelper.gdk_event_get_window((evnt == null) ? IntPtr.Zero : evnt.Handle)) as Window;
		}

		// Token: 0x0600052B RID: 1323 RVA: 0x0000F770 File Offset: 0x0000D970
		public static bool IsScrollStopEvent(Event evnt)
		{
			return EventHelper.gdk_event_is_scroll_stop_event((evnt == null) ? IntPtr.Zero : evnt.Handle);
		}

		// Token: 0x0600052C RID: 1324 RVA: 0x0000F78C File Offset: 0x0000D98C
		public static Event New(EventType type)
		{
			return Event.GetEvent(EventHelper.gdk_event_new((int)type));
		}

		// Token: 0x0600052D RID: 1325 RVA: 0x0000F79E File Offset: 0x0000D99E
		public static Event Peek()
		{
			return Event.GetEvent(EventHelper.gdk_event_peek());
		}

		// Token: 0x0600052E RID: 1326 RVA: 0x0000F7AF File Offset: 0x0000D9AF
		public static void Put(Event evnt)
		{
			EventHelper.gdk_event_put((evnt == null) ? IntPtr.Zero : evnt.Handle);
		}

		// Token: 0x0600052F RID: 1327 RVA: 0x0000F7CB File Offset: 0x0000D9CB
		public static void RequestMotions(EventMotion evnt)
		{
			EventHelper.gdk_event_request_motions((evnt == null) ? IntPtr.Zero : evnt.Handle);
		}

		// Token: 0x06000530 RID: 1328 RVA: 0x0000F7E7 File Offset: 0x0000D9E7
		public static void SetDevice(Event evnt, Device device)
		{
			EventHelper.gdk_event_set_device((evnt == null) ? IntPtr.Zero : evnt.Handle, (device == null) ? IntPtr.Zero : device.Handle);
		}

		// Token: 0x06000531 RID: 1329 RVA: 0x0000F813 File Offset: 0x0000DA13
		public static void SetDeviceTool(Event evnt, DeviceTool tool)
		{
			EventHelper.gdk_event_set_device_tool((evnt == null) ? IntPtr.Zero : evnt.Handle, (tool == null) ? IntPtr.Zero : tool.Handle);
		}

		// Token: 0x06000532 RID: 1330 RVA: 0x0000F83F File Offset: 0x0000DA3F
		public static void SetScreen(Event evnt, Screen screen)
		{
			EventHelper.gdk_event_set_screen((evnt == null) ? IntPtr.Zero : evnt.Handle, (screen == null) ? IntPtr.Zero : screen.Handle);
		}

		// Token: 0x06000533 RID: 1331 RVA: 0x0000F86B File Offset: 0x0000DA6B
		public static void SetSourceDevice(Event evnt, Device device)
		{
			EventHelper.gdk_event_set_source_device((evnt == null) ? IntPtr.Zero : evnt.Handle, (device == null) ? IntPtr.Zero : device.Handle);
		}

		// Token: 0x06000534 RID: 1332 RVA: 0x0000F897 File Offset: 0x0000DA97
		public static bool TriggersContextMenu(Event evnt)
		{
			return EventHelper.gdk_event_triggers_context_menu((evnt == null) ? IntPtr.Zero : evnt.Handle);
		}

		// Token: 0x0400022E RID: 558
		private static EventHelper.d_gdk_event_copy gdk_event_copy = FuncLoader.LoadFunction<EventHelper.d_gdk_event_copy>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_copy"));

		// Token: 0x0400022F RID: 559
		private static EventHelper.d_gdk_event_free gdk_event_free = FuncLoader.LoadFunction<EventHelper.d_gdk_event_free>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_free"));

		// Token: 0x04000230 RID: 560
		private static EventHelper.d_gdk_event_get gdk_event_get = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get"));

		// Token: 0x04000231 RID: 561
		private static EventHelper.d_gdk_event_get_axis gdk_event_get_axis = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_axis>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_axis"));

		// Token: 0x04000232 RID: 562
		private static EventHelper.d_gdk_event_get_button gdk_event_get_button = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_button>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_button"));

		// Token: 0x04000233 RID: 563
		private static EventHelper.d_gdk_event_get_click_count gdk_event_get_click_count = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_click_count>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_click_count"));

		// Token: 0x04000234 RID: 564
		private static EventHelper.d_gdk_event_get_coords gdk_event_get_coords = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_coords>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_coords"));

		// Token: 0x04000235 RID: 565
		private static EventHelper.d_gdk_event_get_device gdk_event_get_device = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_device>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_device"));

		// Token: 0x04000236 RID: 566
		private static EventHelper.d_gdk_event_get_device_tool gdk_event_get_device_tool = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_device_tool>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_device_tool"));

		// Token: 0x04000237 RID: 567
		private static EventHelper.d_gdk_event_get_event_sequence gdk_event_get_event_sequence = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_event_sequence>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_event_sequence"));

		// Token: 0x04000238 RID: 568
		private static EventHelper.d_gdk_event_get_event_type gdk_event_get_event_type = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_event_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_event_type"));

		// Token: 0x04000239 RID: 569
		private static EventHelper.d_gdk_event_get_keycode gdk_event_get_keycode = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_keycode>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_keycode"));

		// Token: 0x0400023A RID: 570
		private static EventHelper.d_gdk_event_get_keyval gdk_event_get_keyval = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_keyval>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_keyval"));

		// Token: 0x0400023B RID: 571
		private static EventHelper.d_gdk_event_get_pointer_emulated gdk_event_get_pointer_emulated = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_pointer_emulated>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_pointer_emulated"));

		// Token: 0x0400023C RID: 572
		private static EventHelper.d_gdk_event_get_root_coords gdk_event_get_root_coords = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_root_coords>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_root_coords"));

		// Token: 0x0400023D RID: 573
		private static EventHelper.d_gdk_event_get_scancode gdk_event_get_scancode = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_scancode>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_scancode"));

		// Token: 0x0400023E RID: 574
		private static EventHelper.d_gdk_event_get_screen gdk_event_get_screen = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_screen>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_screen"));

		// Token: 0x0400023F RID: 575
		private static EventHelper.d_gdk_event_get_scroll_deltas gdk_event_get_scroll_deltas = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_scroll_deltas>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_scroll_deltas"));

		// Token: 0x04000240 RID: 576
		private static EventHelper.d_gdk_event_get_scroll_direction gdk_event_get_scroll_direction = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_scroll_direction>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_scroll_direction"));

		// Token: 0x04000241 RID: 577
		private static EventHelper.d_gdk_event_get_seat gdk_event_get_seat = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_seat>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_seat"));

		// Token: 0x04000242 RID: 578
		private static EventHelper.d_gdk_event_get_source_device gdk_event_get_source_device = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_source_device>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_source_device"));

		// Token: 0x04000243 RID: 579
		private static EventHelper.d_gdk_event_get_state gdk_event_get_state = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_state>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_state"));

		// Token: 0x04000244 RID: 580
		private static EventHelper.d_gdk_event_get_time gdk_event_get_time = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_time>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_time"));

		// Token: 0x04000245 RID: 581
		private static EventHelper.d_gdk_event_get_type gdk_event_get_type = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_type"));

		// Token: 0x04000246 RID: 582
		private static EventHelper.d_gdk_event_get_window gdk_event_get_window = FuncLoader.LoadFunction<EventHelper.d_gdk_event_get_window>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_window"));

		// Token: 0x04000247 RID: 583
		private static EventHelper.d_gdk_event_is_scroll_stop_event gdk_event_is_scroll_stop_event = FuncLoader.LoadFunction<EventHelper.d_gdk_event_is_scroll_stop_event>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_is_scroll_stop_event"));

		// Token: 0x04000248 RID: 584
		private static EventHelper.d_gdk_event_new gdk_event_new = FuncLoader.LoadFunction<EventHelper.d_gdk_event_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_new"));

		// Token: 0x04000249 RID: 585
		private static EventHelper.d_gdk_event_peek gdk_event_peek = FuncLoader.LoadFunction<EventHelper.d_gdk_event_peek>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_peek"));

		// Token: 0x0400024A RID: 586
		private static EventHelper.d_gdk_event_put gdk_event_put = FuncLoader.LoadFunction<EventHelper.d_gdk_event_put>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_put"));

		// Token: 0x0400024B RID: 587
		private static EventHelper.d_gdk_event_request_motions gdk_event_request_motions = FuncLoader.LoadFunction<EventHelper.d_gdk_event_request_motions>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_request_motions"));

		// Token: 0x0400024C RID: 588
		private static EventHelper.d_gdk_event_set_device gdk_event_set_device = FuncLoader.LoadFunction<EventHelper.d_gdk_event_set_device>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_set_device"));

		// Token: 0x0400024D RID: 589
		private static EventHelper.d_gdk_event_set_device_tool gdk_event_set_device_tool = FuncLoader.LoadFunction<EventHelper.d_gdk_event_set_device_tool>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_set_device_tool"));

		// Token: 0x0400024E RID: 590
		private static EventHelper.d_gdk_event_set_screen gdk_event_set_screen = FuncLoader.LoadFunction<EventHelper.d_gdk_event_set_screen>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_set_screen"));

		// Token: 0x0400024F RID: 591
		private static EventHelper.d_gdk_event_set_source_device gdk_event_set_source_device = FuncLoader.LoadFunction<EventHelper.d_gdk_event_set_source_device>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_set_source_device"));

		// Token: 0x04000250 RID: 592
		private static EventHelper.d_gdk_event_triggers_context_menu gdk_event_triggers_context_menu = FuncLoader.LoadFunction<EventHelper.d_gdk_event_triggers_context_menu>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_triggers_context_menu"));

		// Token: 0x02000261 RID: 609
		// (Invoke) Token: 0x0600100B RID: 4107
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_event_copy(IntPtr evnt);

		// Token: 0x02000262 RID: 610
		// (Invoke) Token: 0x0600100F RID: 4111
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_event_free(IntPtr evnt);

		// Token: 0x02000263 RID: 611
		// (Invoke) Token: 0x06001013 RID: 4115
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_event_get();

		// Token: 0x02000264 RID: 612
		// (Invoke) Token: 0x06001017 RID: 4119
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_event_get_axis(IntPtr evnt, int axis_use, out double value);

		// Token: 0x02000265 RID: 613
		// (Invoke) Token: 0x0600101B RID: 4123
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_event_get_button(IntPtr evnt, out uint button);

		// Token: 0x02000266 RID: 614
		// (Invoke) Token: 0x0600101F RID: 4127
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_event_get_click_count(IntPtr evnt, out uint click_count);

		// Token: 0x02000267 RID: 615
		// (Invoke) Token: 0x06001023 RID: 4131
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_event_get_coords(IntPtr evnt, out double x_win, out double y_win);

		// Token: 0x02000268 RID: 616
		// (Invoke) Token: 0x06001027 RID: 4135
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_event_get_device(IntPtr evnt);

		// Token: 0x02000269 RID: 617
		// (Invoke) Token: 0x0600102B RID: 4139
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_event_get_device_tool(IntPtr evnt);

		// Token: 0x0200026A RID: 618
		// (Invoke) Token: 0x0600102F RID: 4143
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_event_get_event_sequence(IntPtr evnt);

		// Token: 0x0200026B RID: 619
		// (Invoke) Token: 0x06001033 RID: 4147
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_event_get_event_type(IntPtr evnt);

		// Token: 0x0200026C RID: 620
		// (Invoke) Token: 0x06001037 RID: 4151
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_event_get_keycode(IntPtr evnt, out ushort keycode);

		// Token: 0x0200026D RID: 621
		// (Invoke) Token: 0x0600103B RID: 4155
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_event_get_keyval(IntPtr evnt, out uint keyval);

		// Token: 0x0200026E RID: 622
		// (Invoke) Token: 0x0600103F RID: 4159
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_event_get_pointer_emulated(IntPtr evnt);

		// Token: 0x0200026F RID: 623
		// (Invoke) Token: 0x06001043 RID: 4163
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_event_get_root_coords(IntPtr evnt, out double x_root, out double y_root);

		// Token: 0x02000270 RID: 624
		// (Invoke) Token: 0x06001047 RID: 4167
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_event_get_scancode(IntPtr evnt);

		// Token: 0x02000271 RID: 625
		// (Invoke) Token: 0x0600104B RID: 4171
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_event_get_screen(IntPtr evnt);

		// Token: 0x02000272 RID: 626
		// (Invoke) Token: 0x0600104F RID: 4175
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_event_get_scroll_deltas(IntPtr evnt, out double delta_x, out double delta_y);

		// Token: 0x02000273 RID: 627
		// (Invoke) Token: 0x06001053 RID: 4179
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_event_get_scroll_direction(IntPtr evnt, out int direction);

		// Token: 0x02000274 RID: 628
		// (Invoke) Token: 0x06001057 RID: 4183
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_event_get_seat(IntPtr evnt);

		// Token: 0x02000275 RID: 629
		// (Invoke) Token: 0x0600105B RID: 4187
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_event_get_source_device(IntPtr evnt);

		// Token: 0x02000276 RID: 630
		// (Invoke) Token: 0x0600105F RID: 4191
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_event_get_state(IntPtr evnt, out int state);

		// Token: 0x02000277 RID: 631
		// (Invoke) Token: 0x06001063 RID: 4195
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gdk_event_get_time(IntPtr evnt);

		// Token: 0x02000278 RID: 632
		// (Invoke) Token: 0x06001067 RID: 4199
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_event_get_type();

		// Token: 0x02000279 RID: 633
		// (Invoke) Token: 0x0600106B RID: 4203
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_event_get_window(IntPtr evnt);

		// Token: 0x0200027A RID: 634
		// (Invoke) Token: 0x0600106F RID: 4207
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_event_is_scroll_stop_event(IntPtr evnt);

		// Token: 0x0200027B RID: 635
		// (Invoke) Token: 0x06001073 RID: 4211
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_event_new(int type);

		// Token: 0x0200027C RID: 636
		// (Invoke) Token: 0x06001077 RID: 4215
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_event_peek();

		// Token: 0x0200027D RID: 637
		// (Invoke) Token: 0x0600107B RID: 4219
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_event_put(IntPtr evnt);

		// Token: 0x0200027E RID: 638
		// (Invoke) Token: 0x0600107F RID: 4223
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_event_request_motions(IntPtr evnt);

		// Token: 0x0200027F RID: 639
		// (Invoke) Token: 0x06001083 RID: 4227
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_event_set_device(IntPtr evnt, IntPtr device);

		// Token: 0x02000280 RID: 640
		// (Invoke) Token: 0x06001087 RID: 4231
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_event_set_device_tool(IntPtr evnt, IntPtr tool);

		// Token: 0x02000281 RID: 641
		// (Invoke) Token: 0x0600108B RID: 4235
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_event_set_screen(IntPtr evnt, IntPtr screen);

		// Token: 0x02000282 RID: 642
		// (Invoke) Token: 0x0600108F RID: 4239
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_event_set_source_device(IntPtr evnt, IntPtr device);

		// Token: 0x02000283 RID: 643
		// (Invoke) Token: 0x06001093 RID: 4243
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_event_triggers_context_menu(IntPtr evnt);
	}
}
