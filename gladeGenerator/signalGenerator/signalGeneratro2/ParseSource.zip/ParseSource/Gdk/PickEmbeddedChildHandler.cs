﻿using System;

namespace Gdk
{
	// Token: 0x020000C0 RID: 192
	// (Invoke) Token: 0x06000762 RID: 1890
	public delegate void PickEmbeddedChildHandler(object o, PickEmbeddedChildArgs args);
}
