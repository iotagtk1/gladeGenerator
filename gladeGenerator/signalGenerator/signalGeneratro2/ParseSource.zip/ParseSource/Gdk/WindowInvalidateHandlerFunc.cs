﻿using System;
using Cairo;

namespace Gdk
{
	// Token: 0x0200011E RID: 286
	// (Invoke) Token: 0x06000B4D RID: 2893
	public delegate void WindowInvalidateHandlerFunc(Window window, Region region);
}
