﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000113 RID: 275
	[GType(typeof(VisualTypeGType))]
	public enum VisualType
	{
		// Token: 0x040005B0 RID: 1456
		StaticGray,
		// Token: 0x040005B1 RID: 1457
		Grayscale,
		// Token: 0x040005B2 RID: 1458
		StaticColor,
		// Token: 0x040005B3 RID: 1459
		PseudoColor,
		// Token: 0x040005B4 RID: 1460
		TrueColor,
		// Token: 0x040005B5 RID: 1461
		DirectColor
	}
}
