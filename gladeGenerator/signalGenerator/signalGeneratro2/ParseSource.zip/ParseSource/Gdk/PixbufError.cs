﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000CB RID: 203
	[GType(typeof(PixbufErrorGType))]
	public enum PixbufError
	{
		// Token: 0x04000473 RID: 1139
		CorruptImage,
		// Token: 0x04000474 RID: 1140
		InsufficientMemory,
		// Token: 0x04000475 RID: 1141
		BadOption,
		// Token: 0x04000476 RID: 1142
		UnknownType,
		// Token: 0x04000477 RID: 1143
		UnsupportedOperation,
		// Token: 0x04000478 RID: 1144
		Failed,
		// Token: 0x04000479 RID: 1145
		IncompleteAnimation
	}
}
