﻿using System;

namespace Gdk
{
	// Token: 0x020000CA RID: 202
	// (Invoke) Token: 0x060007E2 RID: 2018
	public delegate void PixbufDestroyNotify(byte[] pixels);
}
