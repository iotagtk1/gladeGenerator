﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000052 RID: 82
	[GType(typeof(CrossingModeGType))]
	public enum CrossingMode
	{
		// Token: 0x04000147 RID: 327
		Normal,
		// Token: 0x04000148 RID: 328
		Grab,
		// Token: 0x04000149 RID: 329
		Ungrab,
		// Token: 0x0400014A RID: 330
		GtkGrab,
		// Token: 0x0400014B RID: 331
		GtkUngrab,
		// Token: 0x0400014C RID: 332
		StateChanged,
		// Token: 0x0400014D RID: 333
		TouchBegin,
		// Token: 0x0400014E RID: 334
		TouchEnd,
		// Token: 0x0400014F RID: 335
		DeviceSwitch
	}
}
