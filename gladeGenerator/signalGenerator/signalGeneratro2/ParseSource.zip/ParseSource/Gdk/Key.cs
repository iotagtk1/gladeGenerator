﻿using System;

namespace Gdk
{
	// Token: 0x0200012D RID: 301
	public enum Key
	{
		// Token: 0x040006C7 RID: 1735
		VoidSymbol = 16777215,
		// Token: 0x040006C8 RID: 1736
		BackSpace = 65288,
		// Token: 0x040006C9 RID: 1737
		Tab,
		// Token: 0x040006CA RID: 1738
		Linefeed,
		// Token: 0x040006CB RID: 1739
		Clear,
		// Token: 0x040006CC RID: 1740
		Return = 65293,
		// Token: 0x040006CD RID: 1741
		Pause = 65299,
		// Token: 0x040006CE RID: 1742
		Scroll_Lock,
		// Token: 0x040006CF RID: 1743
		Sys_Req,
		// Token: 0x040006D0 RID: 1744
		Escape = 65307,
		// Token: 0x040006D1 RID: 1745
		Delete = 65535,
		// Token: 0x040006D2 RID: 1746
		Multi_key = 65312,
		// Token: 0x040006D3 RID: 1747
		Codeinput = 65335,
		// Token: 0x040006D4 RID: 1748
		SingleCandidate = 65340,
		// Token: 0x040006D5 RID: 1749
		MultipleCandidate,
		// Token: 0x040006D6 RID: 1750
		PreviousCandidate,
		// Token: 0x040006D7 RID: 1751
		Kanji = 65313,
		// Token: 0x040006D8 RID: 1752
		Muhenkan,
		// Token: 0x040006D9 RID: 1753
		Henkan_Mode,
		// Token: 0x040006DA RID: 1754
		Henkan = 65315,
		// Token: 0x040006DB RID: 1755
		Romaji,
		// Token: 0x040006DC RID: 1756
		Hiragana,
		// Token: 0x040006DD RID: 1757
		Katakana,
		// Token: 0x040006DE RID: 1758
		Hiragana_Katakana,
		// Token: 0x040006DF RID: 1759
		Zenkaku,
		// Token: 0x040006E0 RID: 1760
		Hankaku,
		// Token: 0x040006E1 RID: 1761
		Zenkaku_Hankaku,
		// Token: 0x040006E2 RID: 1762
		Touroku,
		// Token: 0x040006E3 RID: 1763
		Massyo,
		// Token: 0x040006E4 RID: 1764
		Kana_Lock,
		// Token: 0x040006E5 RID: 1765
		Kana_Shift,
		// Token: 0x040006E6 RID: 1766
		Eisu_Shift,
		// Token: 0x040006E7 RID: 1767
		Eisu_toggle,
		// Token: 0x040006E8 RID: 1768
		Kanji_Bangou = 65335,
		// Token: 0x040006E9 RID: 1769
		Zen_Koho = 65341,
		// Token: 0x040006EA RID: 1770
		Mae_Koho,
		// Token: 0x040006EB RID: 1771
		Home = 65360,
		// Token: 0x040006EC RID: 1772
		Left,
		// Token: 0x040006ED RID: 1773
		Up,
		// Token: 0x040006EE RID: 1774
		Right,
		// Token: 0x040006EF RID: 1775
		Down,
		// Token: 0x040006F0 RID: 1776
		Prior,
		// Token: 0x040006F1 RID: 1777
		Page_Up = 65365,
		// Token: 0x040006F2 RID: 1778
		Next,
		// Token: 0x040006F3 RID: 1779
		Page_Down = 65366,
		// Token: 0x040006F4 RID: 1780
		End,
		// Token: 0x040006F5 RID: 1781
		Begin,
		// Token: 0x040006F6 RID: 1782
		Select = 65376,
		// Token: 0x040006F7 RID: 1783
		Print,
		// Token: 0x040006F8 RID: 1784
		Execute,
		// Token: 0x040006F9 RID: 1785
		Insert,
		// Token: 0x040006FA RID: 1786
		Undo = 65381,
		// Token: 0x040006FB RID: 1787
		Redo,
		// Token: 0x040006FC RID: 1788
		Menu,
		// Token: 0x040006FD RID: 1789
		Find,
		// Token: 0x040006FE RID: 1790
		Cancel,
		// Token: 0x040006FF RID: 1791
		Help,
		// Token: 0x04000700 RID: 1792
		Break,
		// Token: 0x04000701 RID: 1793
		Mode_switch = 65406,
		// Token: 0x04000702 RID: 1794
		script_switch = 65406,
		// Token: 0x04000703 RID: 1795
		Num_Lock,
		// Token: 0x04000704 RID: 1796
		KP_Space,
		// Token: 0x04000705 RID: 1797
		KP_Tab = 65417,
		// Token: 0x04000706 RID: 1798
		KP_Enter = 65421,
		// Token: 0x04000707 RID: 1799
		KP_F1 = 65425,
		// Token: 0x04000708 RID: 1800
		KP_F2,
		// Token: 0x04000709 RID: 1801
		KP_F3,
		// Token: 0x0400070A RID: 1802
		KP_F4,
		// Token: 0x0400070B RID: 1803
		KP_Home,
		// Token: 0x0400070C RID: 1804
		KP_Left,
		// Token: 0x0400070D RID: 1805
		KP_Up,
		// Token: 0x0400070E RID: 1806
		KP_Right,
		// Token: 0x0400070F RID: 1807
		KP_Down,
		// Token: 0x04000710 RID: 1808
		KP_Prior,
		// Token: 0x04000711 RID: 1809
		KP_Page_Up = 65434,
		// Token: 0x04000712 RID: 1810
		KP_Next,
		// Token: 0x04000713 RID: 1811
		KP_Page_Down = 65435,
		// Token: 0x04000714 RID: 1812
		KP_End,
		// Token: 0x04000715 RID: 1813
		KP_Begin,
		// Token: 0x04000716 RID: 1814
		KP_Insert,
		// Token: 0x04000717 RID: 1815
		KP_Delete,
		// Token: 0x04000718 RID: 1816
		KP_Equal = 65469,
		// Token: 0x04000719 RID: 1817
		KP_Multiply = 65450,
		// Token: 0x0400071A RID: 1818
		KP_Add,
		// Token: 0x0400071B RID: 1819
		KP_Separator,
		// Token: 0x0400071C RID: 1820
		KP_Subtract,
		// Token: 0x0400071D RID: 1821
		KP_Decimal,
		// Token: 0x0400071E RID: 1822
		KP_Divide,
		// Token: 0x0400071F RID: 1823
		KP_0,
		// Token: 0x04000720 RID: 1824
		KP_1,
		// Token: 0x04000721 RID: 1825
		KP_2,
		// Token: 0x04000722 RID: 1826
		KP_3,
		// Token: 0x04000723 RID: 1827
		KP_4,
		// Token: 0x04000724 RID: 1828
		KP_5,
		// Token: 0x04000725 RID: 1829
		KP_6,
		// Token: 0x04000726 RID: 1830
		KP_7,
		// Token: 0x04000727 RID: 1831
		KP_8,
		// Token: 0x04000728 RID: 1832
		KP_9,
		// Token: 0x04000729 RID: 1833
		F1 = 65470,
		// Token: 0x0400072A RID: 1834
		F2,
		// Token: 0x0400072B RID: 1835
		F3,
		// Token: 0x0400072C RID: 1836
		F4,
		// Token: 0x0400072D RID: 1837
		F5,
		// Token: 0x0400072E RID: 1838
		F6,
		// Token: 0x0400072F RID: 1839
		F7,
		// Token: 0x04000730 RID: 1840
		F8,
		// Token: 0x04000731 RID: 1841
		F9,
		// Token: 0x04000732 RID: 1842
		F10,
		// Token: 0x04000733 RID: 1843
		F11,
		// Token: 0x04000734 RID: 1844
		L1 = 65480,
		// Token: 0x04000735 RID: 1845
		F12,
		// Token: 0x04000736 RID: 1846
		L2 = 65481,
		// Token: 0x04000737 RID: 1847
		F13,
		// Token: 0x04000738 RID: 1848
		L3 = 65482,
		// Token: 0x04000739 RID: 1849
		F14,
		// Token: 0x0400073A RID: 1850
		L4 = 65483,
		// Token: 0x0400073B RID: 1851
		F15,
		// Token: 0x0400073C RID: 1852
		L5 = 65484,
		// Token: 0x0400073D RID: 1853
		F16,
		// Token: 0x0400073E RID: 1854
		L6 = 65485,
		// Token: 0x0400073F RID: 1855
		F17,
		// Token: 0x04000740 RID: 1856
		L7 = 65486,
		// Token: 0x04000741 RID: 1857
		F18,
		// Token: 0x04000742 RID: 1858
		L8 = 65487,
		// Token: 0x04000743 RID: 1859
		F19,
		// Token: 0x04000744 RID: 1860
		L9 = 65488,
		// Token: 0x04000745 RID: 1861
		F20,
		// Token: 0x04000746 RID: 1862
		L10 = 65489,
		// Token: 0x04000747 RID: 1863
		F21,
		// Token: 0x04000748 RID: 1864
		R1 = 65490,
		// Token: 0x04000749 RID: 1865
		F22,
		// Token: 0x0400074A RID: 1866
		R2 = 65491,
		// Token: 0x0400074B RID: 1867
		F23,
		// Token: 0x0400074C RID: 1868
		R3 = 65492,
		// Token: 0x0400074D RID: 1869
		F24,
		// Token: 0x0400074E RID: 1870
		R4 = 65493,
		// Token: 0x0400074F RID: 1871
		F25,
		// Token: 0x04000750 RID: 1872
		R5 = 65494,
		// Token: 0x04000751 RID: 1873
		F26,
		// Token: 0x04000752 RID: 1874
		R6 = 65495,
		// Token: 0x04000753 RID: 1875
		F27,
		// Token: 0x04000754 RID: 1876
		R7 = 65496,
		// Token: 0x04000755 RID: 1877
		F28,
		// Token: 0x04000756 RID: 1878
		R8 = 65497,
		// Token: 0x04000757 RID: 1879
		F29,
		// Token: 0x04000758 RID: 1880
		R9 = 65498,
		// Token: 0x04000759 RID: 1881
		F30,
		// Token: 0x0400075A RID: 1882
		R10 = 65499,
		// Token: 0x0400075B RID: 1883
		F31,
		// Token: 0x0400075C RID: 1884
		R11 = 65500,
		// Token: 0x0400075D RID: 1885
		F32,
		// Token: 0x0400075E RID: 1886
		R12 = 65501,
		// Token: 0x0400075F RID: 1887
		F33,
		// Token: 0x04000760 RID: 1888
		R13 = 65502,
		// Token: 0x04000761 RID: 1889
		F34,
		// Token: 0x04000762 RID: 1890
		R14 = 65503,
		// Token: 0x04000763 RID: 1891
		F35,
		// Token: 0x04000764 RID: 1892
		R15 = 65504,
		// Token: 0x04000765 RID: 1893
		Shift_L,
		// Token: 0x04000766 RID: 1894
		Shift_R,
		// Token: 0x04000767 RID: 1895
		Control_L,
		// Token: 0x04000768 RID: 1896
		Control_R,
		// Token: 0x04000769 RID: 1897
		Caps_Lock,
		// Token: 0x0400076A RID: 1898
		Shift_Lock,
		// Token: 0x0400076B RID: 1899
		Meta_L,
		// Token: 0x0400076C RID: 1900
		Meta_R,
		// Token: 0x0400076D RID: 1901
		Alt_L,
		// Token: 0x0400076E RID: 1902
		Alt_R,
		// Token: 0x0400076F RID: 1903
		Super_L,
		// Token: 0x04000770 RID: 1904
		Super_R,
		// Token: 0x04000771 RID: 1905
		Hyper_L,
		// Token: 0x04000772 RID: 1906
		Hyper_R,
		// Token: 0x04000773 RID: 1907
		ISO_Lock = 65025,
		// Token: 0x04000774 RID: 1908
		ISO_Level2_Latch,
		// Token: 0x04000775 RID: 1909
		ISO_Level3_Shift,
		// Token: 0x04000776 RID: 1910
		ISO_Level3_Latch,
		// Token: 0x04000777 RID: 1911
		ISO_Level3_Lock,
		// Token: 0x04000778 RID: 1912
		ISO_Group_Shift = 65406,
		// Token: 0x04000779 RID: 1913
		ISO_Group_Latch = 65030,
		// Token: 0x0400077A RID: 1914
		ISO_Group_Lock,
		// Token: 0x0400077B RID: 1915
		ISO_Next_Group,
		// Token: 0x0400077C RID: 1916
		ISO_Next_Group_Lock,
		// Token: 0x0400077D RID: 1917
		ISO_Prev_Group,
		// Token: 0x0400077E RID: 1918
		ISO_Prev_Group_Lock,
		// Token: 0x0400077F RID: 1919
		ISO_First_Group,
		// Token: 0x04000780 RID: 1920
		ISO_First_Group_Lock,
		// Token: 0x04000781 RID: 1921
		ISO_Last_Group,
		// Token: 0x04000782 RID: 1922
		ISO_Last_Group_Lock,
		// Token: 0x04000783 RID: 1923
		ISO_Left_Tab = 65056,
		// Token: 0x04000784 RID: 1924
		ISO_Move_Line_Up,
		// Token: 0x04000785 RID: 1925
		ISO_Move_Line_Down,
		// Token: 0x04000786 RID: 1926
		ISO_Partial_Line_Up,
		// Token: 0x04000787 RID: 1927
		ISO_Partial_Line_Down,
		// Token: 0x04000788 RID: 1928
		ISO_Partial_Space_Left,
		// Token: 0x04000789 RID: 1929
		ISO_Partial_Space_Right,
		// Token: 0x0400078A RID: 1930
		ISO_Set_Margin_Left,
		// Token: 0x0400078B RID: 1931
		ISO_Set_Margin_Right,
		// Token: 0x0400078C RID: 1932
		ISO_Release_Margin_Left,
		// Token: 0x0400078D RID: 1933
		ISO_Release_Margin_Right,
		// Token: 0x0400078E RID: 1934
		ISO_Release_Both_Margins,
		// Token: 0x0400078F RID: 1935
		ISO_Fast_Cursor_Left,
		// Token: 0x04000790 RID: 1936
		ISO_Fast_Cursor_Right,
		// Token: 0x04000791 RID: 1937
		ISO_Fast_Cursor_Up,
		// Token: 0x04000792 RID: 1938
		ISO_Fast_Cursor_Down,
		// Token: 0x04000793 RID: 1939
		ISO_Continuous_Underline,
		// Token: 0x04000794 RID: 1940
		ISO_Discontinuous_Underline,
		// Token: 0x04000795 RID: 1941
		ISO_Emphasize,
		// Token: 0x04000796 RID: 1942
		ISO_Center_Object,
		// Token: 0x04000797 RID: 1943
		ISO_Enter,
		// Token: 0x04000798 RID: 1944
		dead_grave = 65104,
		// Token: 0x04000799 RID: 1945
		dead_acute,
		// Token: 0x0400079A RID: 1946
		dead_circumflex,
		// Token: 0x0400079B RID: 1947
		dead_tilde,
		// Token: 0x0400079C RID: 1948
		dead_macron,
		// Token: 0x0400079D RID: 1949
		dead_breve,
		// Token: 0x0400079E RID: 1950
		dead_abovedot,
		// Token: 0x0400079F RID: 1951
		dead_diaeresis,
		// Token: 0x040007A0 RID: 1952
		dead_abovering,
		// Token: 0x040007A1 RID: 1953
		dead_doubleacute,
		// Token: 0x040007A2 RID: 1954
		dead_caron,
		// Token: 0x040007A3 RID: 1955
		dead_cedilla,
		// Token: 0x040007A4 RID: 1956
		dead_ogonek,
		// Token: 0x040007A5 RID: 1957
		dead_iota,
		// Token: 0x040007A6 RID: 1958
		dead_voiced_sound,
		// Token: 0x040007A7 RID: 1959
		dead_semivoiced_sound,
		// Token: 0x040007A8 RID: 1960
		dead_belowdot,
		// Token: 0x040007A9 RID: 1961
		First_Virtual_Screen = 65232,
		// Token: 0x040007AA RID: 1962
		Prev_Virtual_Screen,
		// Token: 0x040007AB RID: 1963
		Next_Virtual_Screen,
		// Token: 0x040007AC RID: 1964
		Last_Virtual_Screen = 65236,
		// Token: 0x040007AD RID: 1965
		Terminate_Server,
		// Token: 0x040007AE RID: 1966
		AccessX_Enable = 65136,
		// Token: 0x040007AF RID: 1967
		AccessX_Feedback_Enable,
		// Token: 0x040007B0 RID: 1968
		RepeatKeys_Enable,
		// Token: 0x040007B1 RID: 1969
		SlowKeys_Enable,
		// Token: 0x040007B2 RID: 1970
		BounceKeys_Enable,
		// Token: 0x040007B3 RID: 1971
		StickyKeys_Enable,
		// Token: 0x040007B4 RID: 1972
		MouseKeys_Enable,
		// Token: 0x040007B5 RID: 1973
		MouseKeys_Accel_Enable,
		// Token: 0x040007B6 RID: 1974
		Overlay1_Enable,
		// Token: 0x040007B7 RID: 1975
		Overlay2_Enable,
		// Token: 0x040007B8 RID: 1976
		AudibleBell_Enable,
		// Token: 0x040007B9 RID: 1977
		Pointer_Left = 65248,
		// Token: 0x040007BA RID: 1978
		Pointer_Right,
		// Token: 0x040007BB RID: 1979
		Pointer_Up,
		// Token: 0x040007BC RID: 1980
		Pointer_Down,
		// Token: 0x040007BD RID: 1981
		Pointer_UpLeft,
		// Token: 0x040007BE RID: 1982
		Pointer_UpRight,
		// Token: 0x040007BF RID: 1983
		Pointer_DownLeft,
		// Token: 0x040007C0 RID: 1984
		Pointer_DownRight,
		// Token: 0x040007C1 RID: 1985
		Pointer_Button_Dflt,
		// Token: 0x040007C2 RID: 1986
		Pointer_Button1,
		// Token: 0x040007C3 RID: 1987
		Pointer_Button2,
		// Token: 0x040007C4 RID: 1988
		Pointer_Button3,
		// Token: 0x040007C5 RID: 1989
		Pointer_Button4,
		// Token: 0x040007C6 RID: 1990
		Pointer_Button5,
		// Token: 0x040007C7 RID: 1991
		Pointer_DblClick_Dflt,
		// Token: 0x040007C8 RID: 1992
		Pointer_DblClick1,
		// Token: 0x040007C9 RID: 1993
		Pointer_DblClick2,
		// Token: 0x040007CA RID: 1994
		Pointer_DblClick3,
		// Token: 0x040007CB RID: 1995
		Pointer_DblClick4,
		// Token: 0x040007CC RID: 1996
		Pointer_DblClick5,
		// Token: 0x040007CD RID: 1997
		Pointer_Drag_Dflt,
		// Token: 0x040007CE RID: 1998
		Pointer_Drag1,
		// Token: 0x040007CF RID: 1999
		Pointer_Drag2,
		// Token: 0x040007D0 RID: 2000
		Pointer_Drag3,
		// Token: 0x040007D1 RID: 2001
		Pointer_Drag4,
		// Token: 0x040007D2 RID: 2002
		Pointer_Drag5 = 65277,
		// Token: 0x040007D3 RID: 2003
		Pointer_EnableKeys = 65273,
		// Token: 0x040007D4 RID: 2004
		Pointer_Accelerate,
		// Token: 0x040007D5 RID: 2005
		Pointer_DfltBtnNext,
		// Token: 0x040007D6 RID: 2006
		Pointer_DfltBtnPrev,
		// Token: 0x040007D7 RID: 2007
		Key_3270_Duplicate = 64769,
		// Token: 0x040007D8 RID: 2008
		Key_3270_FieldMark,
		// Token: 0x040007D9 RID: 2009
		Key_3270_Right2,
		// Token: 0x040007DA RID: 2010
		Key_3270_Left2,
		// Token: 0x040007DB RID: 2011
		Key_3270_BackTab,
		// Token: 0x040007DC RID: 2012
		Key_3270_EraseEOF,
		// Token: 0x040007DD RID: 2013
		Key_3270_EraseInput,
		// Token: 0x040007DE RID: 2014
		Key_3270_Reset,
		// Token: 0x040007DF RID: 2015
		Key_3270_Quit,
		// Token: 0x040007E0 RID: 2016
		Key_3270_PA1,
		// Token: 0x040007E1 RID: 2017
		Key_3270_PA2,
		// Token: 0x040007E2 RID: 2018
		Key_3270_PA3,
		// Token: 0x040007E3 RID: 2019
		Key_3270_Test,
		// Token: 0x040007E4 RID: 2020
		Key_3270_Attn,
		// Token: 0x040007E5 RID: 2021
		Key_3270_CursorBlink,
		// Token: 0x040007E6 RID: 2022
		Key_3270_AltCursor,
		// Token: 0x040007E7 RID: 2023
		Key_3270_KeyClick,
		// Token: 0x040007E8 RID: 2024
		Key_3270_Jump,
		// Token: 0x040007E9 RID: 2025
		Key_3270_Ident,
		// Token: 0x040007EA RID: 2026
		Key_3270_Rule,
		// Token: 0x040007EB RID: 2027
		Key_3270_Copy,
		// Token: 0x040007EC RID: 2028
		Key_3270_Play,
		// Token: 0x040007ED RID: 2029
		Key_3270_Setup,
		// Token: 0x040007EE RID: 2030
		Key_3270_Record,
		// Token: 0x040007EF RID: 2031
		Key_3270_ChangeScreen,
		// Token: 0x040007F0 RID: 2032
		Key_3270_DeleteWord,
		// Token: 0x040007F1 RID: 2033
		Key_3270_ExSelect,
		// Token: 0x040007F2 RID: 2034
		Key_3270_CursorSelect,
		// Token: 0x040007F3 RID: 2035
		Key_3270_PrintScreen,
		// Token: 0x040007F4 RID: 2036
		Key_3270_Enter,
		// Token: 0x040007F5 RID: 2037
		space = 32,
		// Token: 0x040007F6 RID: 2038
		exclam,
		// Token: 0x040007F7 RID: 2039
		quotedbl,
		// Token: 0x040007F8 RID: 2040
		numbersign,
		// Token: 0x040007F9 RID: 2041
		dollar,
		// Token: 0x040007FA RID: 2042
		percent,
		// Token: 0x040007FB RID: 2043
		ampersand,
		// Token: 0x040007FC RID: 2044
		apostrophe,
		// Token: 0x040007FD RID: 2045
		quoteright = 39,
		// Token: 0x040007FE RID: 2046
		parenleft,
		// Token: 0x040007FF RID: 2047
		parenright,
		// Token: 0x04000800 RID: 2048
		asterisk,
		// Token: 0x04000801 RID: 2049
		plus,
		// Token: 0x04000802 RID: 2050
		comma,
		// Token: 0x04000803 RID: 2051
		minus,
		// Token: 0x04000804 RID: 2052
		period,
		// Token: 0x04000805 RID: 2053
		slash,
		// Token: 0x04000806 RID: 2054
		Key_0,
		// Token: 0x04000807 RID: 2055
		Key_1,
		// Token: 0x04000808 RID: 2056
		Key_2,
		// Token: 0x04000809 RID: 2057
		Key_3,
		// Token: 0x0400080A RID: 2058
		Key_4,
		// Token: 0x0400080B RID: 2059
		Key_5,
		// Token: 0x0400080C RID: 2060
		Key_6,
		// Token: 0x0400080D RID: 2061
		Key_7,
		// Token: 0x0400080E RID: 2062
		Key_8,
		// Token: 0x0400080F RID: 2063
		Key_9,
		// Token: 0x04000810 RID: 2064
		colon,
		// Token: 0x04000811 RID: 2065
		semicolon,
		// Token: 0x04000812 RID: 2066
		less,
		// Token: 0x04000813 RID: 2067
		equal,
		// Token: 0x04000814 RID: 2068
		greater,
		// Token: 0x04000815 RID: 2069
		question,
		// Token: 0x04000816 RID: 2070
		at,
		// Token: 0x04000817 RID: 2071
		A,
		// Token: 0x04000818 RID: 2072
		B,
		// Token: 0x04000819 RID: 2073
		C,
		// Token: 0x0400081A RID: 2074
		D,
		// Token: 0x0400081B RID: 2075
		E,
		// Token: 0x0400081C RID: 2076
		F,
		// Token: 0x0400081D RID: 2077
		G,
		// Token: 0x0400081E RID: 2078
		H,
		// Token: 0x0400081F RID: 2079
		I,
		// Token: 0x04000820 RID: 2080
		J,
		// Token: 0x04000821 RID: 2081
		K,
		// Token: 0x04000822 RID: 2082
		L,
		// Token: 0x04000823 RID: 2083
		M,
		// Token: 0x04000824 RID: 2084
		N,
		// Token: 0x04000825 RID: 2085
		O,
		// Token: 0x04000826 RID: 2086
		P,
		// Token: 0x04000827 RID: 2087
		Q,
		// Token: 0x04000828 RID: 2088
		R,
		// Token: 0x04000829 RID: 2089
		S,
		// Token: 0x0400082A RID: 2090
		T,
		// Token: 0x0400082B RID: 2091
		U,
		// Token: 0x0400082C RID: 2092
		V,
		// Token: 0x0400082D RID: 2093
		W,
		// Token: 0x0400082E RID: 2094
		X,
		// Token: 0x0400082F RID: 2095
		Y,
		// Token: 0x04000830 RID: 2096
		Z,
		// Token: 0x04000831 RID: 2097
		bracketleft,
		// Token: 0x04000832 RID: 2098
		backslash,
		// Token: 0x04000833 RID: 2099
		bracketright,
		// Token: 0x04000834 RID: 2100
		asciicircum,
		// Token: 0x04000835 RID: 2101
		underscore,
		// Token: 0x04000836 RID: 2102
		grave,
		// Token: 0x04000837 RID: 2103
		quoteleft = 96,
		// Token: 0x04000838 RID: 2104
		a,
		// Token: 0x04000839 RID: 2105
		b,
		// Token: 0x0400083A RID: 2106
		c,
		// Token: 0x0400083B RID: 2107
		d,
		// Token: 0x0400083C RID: 2108
		e,
		// Token: 0x0400083D RID: 2109
		f,
		// Token: 0x0400083E RID: 2110
		g,
		// Token: 0x0400083F RID: 2111
		h,
		// Token: 0x04000840 RID: 2112
		i,
		// Token: 0x04000841 RID: 2113
		j,
		// Token: 0x04000842 RID: 2114
		k,
		// Token: 0x04000843 RID: 2115
		l,
		// Token: 0x04000844 RID: 2116
		m,
		// Token: 0x04000845 RID: 2117
		n,
		// Token: 0x04000846 RID: 2118
		o,
		// Token: 0x04000847 RID: 2119
		p,
		// Token: 0x04000848 RID: 2120
		q,
		// Token: 0x04000849 RID: 2121
		r,
		// Token: 0x0400084A RID: 2122
		s,
		// Token: 0x0400084B RID: 2123
		t,
		// Token: 0x0400084C RID: 2124
		u,
		// Token: 0x0400084D RID: 2125
		v,
		// Token: 0x0400084E RID: 2126
		w,
		// Token: 0x0400084F RID: 2127
		x,
		// Token: 0x04000850 RID: 2128
		y,
		// Token: 0x04000851 RID: 2129
		z,
		// Token: 0x04000852 RID: 2130
		braceleft,
		// Token: 0x04000853 RID: 2131
		bar,
		// Token: 0x04000854 RID: 2132
		braceright,
		// Token: 0x04000855 RID: 2133
		asciitilde,
		// Token: 0x04000856 RID: 2134
		nobreakspace = 160,
		// Token: 0x04000857 RID: 2135
		exclamdown,
		// Token: 0x04000858 RID: 2136
		cent,
		// Token: 0x04000859 RID: 2137
		sterling,
		// Token: 0x0400085A RID: 2138
		currency,
		// Token: 0x0400085B RID: 2139
		yen,
		// Token: 0x0400085C RID: 2140
		brokenbar,
		// Token: 0x0400085D RID: 2141
		section,
		// Token: 0x0400085E RID: 2142
		diaeresis,
		// Token: 0x0400085F RID: 2143
		copyright,
		// Token: 0x04000860 RID: 2144
		ordfeminine,
		// Token: 0x04000861 RID: 2145
		guillemotleft,
		// Token: 0x04000862 RID: 2146
		notsign,
		// Token: 0x04000863 RID: 2147
		hyphen,
		// Token: 0x04000864 RID: 2148
		registered,
		// Token: 0x04000865 RID: 2149
		macron,
		// Token: 0x04000866 RID: 2150
		degree,
		// Token: 0x04000867 RID: 2151
		plusminus,
		// Token: 0x04000868 RID: 2152
		twosuperior,
		// Token: 0x04000869 RID: 2153
		threesuperior,
		// Token: 0x0400086A RID: 2154
		acute,
		// Token: 0x0400086B RID: 2155
		mu,
		// Token: 0x0400086C RID: 2156
		paragraph,
		// Token: 0x0400086D RID: 2157
		periodcentered,
		// Token: 0x0400086E RID: 2158
		cedilla,
		// Token: 0x0400086F RID: 2159
		onesuperior,
		// Token: 0x04000870 RID: 2160
		masculine,
		// Token: 0x04000871 RID: 2161
		guillemotright,
		// Token: 0x04000872 RID: 2162
		onequarter,
		// Token: 0x04000873 RID: 2163
		onehalf,
		// Token: 0x04000874 RID: 2164
		threequarters,
		// Token: 0x04000875 RID: 2165
		questiondown,
		// Token: 0x04000876 RID: 2166
		Agrave,
		// Token: 0x04000877 RID: 2167
		Aacute,
		// Token: 0x04000878 RID: 2168
		Acircumflex,
		// Token: 0x04000879 RID: 2169
		Atilde,
		// Token: 0x0400087A RID: 2170
		Adiaeresis,
		// Token: 0x0400087B RID: 2171
		Aring,
		// Token: 0x0400087C RID: 2172
		AE,
		// Token: 0x0400087D RID: 2173
		Ccedilla,
		// Token: 0x0400087E RID: 2174
		Egrave,
		// Token: 0x0400087F RID: 2175
		Eacute,
		// Token: 0x04000880 RID: 2176
		Ecircumflex,
		// Token: 0x04000881 RID: 2177
		Ediaeresis,
		// Token: 0x04000882 RID: 2178
		Igrave,
		// Token: 0x04000883 RID: 2179
		Iacute,
		// Token: 0x04000884 RID: 2180
		Icircumflex,
		// Token: 0x04000885 RID: 2181
		Idiaeresis,
		// Token: 0x04000886 RID: 2182
		ETH,
		// Token: 0x04000887 RID: 2183
		Eth = 208,
		// Token: 0x04000888 RID: 2184
		Ntilde,
		// Token: 0x04000889 RID: 2185
		Ograve,
		// Token: 0x0400088A RID: 2186
		Oacute,
		// Token: 0x0400088B RID: 2187
		Ocircumflex,
		// Token: 0x0400088C RID: 2188
		Otilde,
		// Token: 0x0400088D RID: 2189
		Odiaeresis,
		// Token: 0x0400088E RID: 2190
		multiply,
		// Token: 0x0400088F RID: 2191
		Ooblique,
		// Token: 0x04000890 RID: 2192
		Ugrave,
		// Token: 0x04000891 RID: 2193
		Uacute,
		// Token: 0x04000892 RID: 2194
		Ucircumflex,
		// Token: 0x04000893 RID: 2195
		Udiaeresis,
		// Token: 0x04000894 RID: 2196
		Yacute,
		// Token: 0x04000895 RID: 2197
		THORN,
		// Token: 0x04000896 RID: 2198
		Thorn = 222,
		// Token: 0x04000897 RID: 2199
		ssharp,
		// Token: 0x04000898 RID: 2200
		agrave,
		// Token: 0x04000899 RID: 2201
		aacute,
		// Token: 0x0400089A RID: 2202
		acircumflex,
		// Token: 0x0400089B RID: 2203
		atilde,
		// Token: 0x0400089C RID: 2204
		adiaeresis,
		// Token: 0x0400089D RID: 2205
		aring,
		// Token: 0x0400089E RID: 2206
		ae,
		// Token: 0x0400089F RID: 2207
		ccedilla,
		// Token: 0x040008A0 RID: 2208
		egrave,
		// Token: 0x040008A1 RID: 2209
		eacute,
		// Token: 0x040008A2 RID: 2210
		ecircumflex,
		// Token: 0x040008A3 RID: 2211
		ediaeresis,
		// Token: 0x040008A4 RID: 2212
		igrave,
		// Token: 0x040008A5 RID: 2213
		iacute,
		// Token: 0x040008A6 RID: 2214
		icircumflex,
		// Token: 0x040008A7 RID: 2215
		idiaeresis,
		// Token: 0x040008A8 RID: 2216
		eth,
		// Token: 0x040008A9 RID: 2217
		ntilde,
		// Token: 0x040008AA RID: 2218
		ograve,
		// Token: 0x040008AB RID: 2219
		oacute,
		// Token: 0x040008AC RID: 2220
		ocircumflex,
		// Token: 0x040008AD RID: 2221
		otilde,
		// Token: 0x040008AE RID: 2222
		odiaeresis,
		// Token: 0x040008AF RID: 2223
		division,
		// Token: 0x040008B0 RID: 2224
		oslash,
		// Token: 0x040008B1 RID: 2225
		ugrave,
		// Token: 0x040008B2 RID: 2226
		uacute,
		// Token: 0x040008B3 RID: 2227
		ucircumflex,
		// Token: 0x040008B4 RID: 2228
		udiaeresis,
		// Token: 0x040008B5 RID: 2229
		yacute,
		// Token: 0x040008B6 RID: 2230
		thorn,
		// Token: 0x040008B7 RID: 2231
		ydiaeresis,
		// Token: 0x040008B8 RID: 2232
		Aogonek = 417,
		// Token: 0x040008B9 RID: 2233
		breve,
		// Token: 0x040008BA RID: 2234
		Lstroke,
		// Token: 0x040008BB RID: 2235
		Lcaron = 421,
		// Token: 0x040008BC RID: 2236
		Sacute,
		// Token: 0x040008BD RID: 2237
		Scaron = 425,
		// Token: 0x040008BE RID: 2238
		Scedilla,
		// Token: 0x040008BF RID: 2239
		Tcaron,
		// Token: 0x040008C0 RID: 2240
		Zacute,
		// Token: 0x040008C1 RID: 2241
		Zcaron = 430,
		// Token: 0x040008C2 RID: 2242
		Zabovedot,
		// Token: 0x040008C3 RID: 2243
		aogonek = 433,
		// Token: 0x040008C4 RID: 2244
		ogonek,
		// Token: 0x040008C5 RID: 2245
		lstroke,
		// Token: 0x040008C6 RID: 2246
		lcaron = 437,
		// Token: 0x040008C7 RID: 2247
		sacute,
		// Token: 0x040008C8 RID: 2248
		caron,
		// Token: 0x040008C9 RID: 2249
		scaron = 441,
		// Token: 0x040008CA RID: 2250
		scedilla,
		// Token: 0x040008CB RID: 2251
		tcaron,
		// Token: 0x040008CC RID: 2252
		zacute,
		// Token: 0x040008CD RID: 2253
		doubleacute,
		// Token: 0x040008CE RID: 2254
		zcaron,
		// Token: 0x040008CF RID: 2255
		zabovedot,
		// Token: 0x040008D0 RID: 2256
		Racute,
		// Token: 0x040008D1 RID: 2257
		Abreve = 451,
		// Token: 0x040008D2 RID: 2258
		Lacute = 453,
		// Token: 0x040008D3 RID: 2259
		Cacute,
		// Token: 0x040008D4 RID: 2260
		Ccaron = 456,
		// Token: 0x040008D5 RID: 2261
		Eogonek = 458,
		// Token: 0x040008D6 RID: 2262
		Ecaron = 460,
		// Token: 0x040008D7 RID: 2263
		Dcaron = 463,
		// Token: 0x040008D8 RID: 2264
		Dstroke,
		// Token: 0x040008D9 RID: 2265
		Nacute,
		// Token: 0x040008DA RID: 2266
		Ncaron,
		// Token: 0x040008DB RID: 2267
		Odoubleacute = 469,
		// Token: 0x040008DC RID: 2268
		Rcaron = 472,
		// Token: 0x040008DD RID: 2269
		Uring,
		// Token: 0x040008DE RID: 2270
		Udoubleacute = 475,
		// Token: 0x040008DF RID: 2271
		Tcedilla = 478,
		// Token: 0x040008E0 RID: 2272
		racute = 480,
		// Token: 0x040008E1 RID: 2273
		abreve = 483,
		// Token: 0x040008E2 RID: 2274
		lacute = 485,
		// Token: 0x040008E3 RID: 2275
		cacute,
		// Token: 0x040008E4 RID: 2276
		ccaron = 488,
		// Token: 0x040008E5 RID: 2277
		eogonek = 490,
		// Token: 0x040008E6 RID: 2278
		ecaron = 492,
		// Token: 0x040008E7 RID: 2279
		dcaron = 495,
		// Token: 0x040008E8 RID: 2280
		dstroke,
		// Token: 0x040008E9 RID: 2281
		nacute,
		// Token: 0x040008EA RID: 2282
		ncaron,
		// Token: 0x040008EB RID: 2283
		odoubleacute = 501,
		// Token: 0x040008EC RID: 2284
		udoubleacute = 507,
		// Token: 0x040008ED RID: 2285
		rcaron = 504,
		// Token: 0x040008EE RID: 2286
		uring,
		// Token: 0x040008EF RID: 2287
		tcedilla = 510,
		// Token: 0x040008F0 RID: 2288
		abovedot,
		// Token: 0x040008F1 RID: 2289
		Hstroke = 673,
		// Token: 0x040008F2 RID: 2290
		Hcircumflex = 678,
		// Token: 0x040008F3 RID: 2291
		Iabovedot = 681,
		// Token: 0x040008F4 RID: 2292
		Gbreve = 683,
		// Token: 0x040008F5 RID: 2293
		Jcircumflex,
		// Token: 0x040008F6 RID: 2294
		hstroke = 689,
		// Token: 0x040008F7 RID: 2295
		hcircumflex = 694,
		// Token: 0x040008F8 RID: 2296
		idotless = 697,
		// Token: 0x040008F9 RID: 2297
		gbreve = 699,
		// Token: 0x040008FA RID: 2298
		jcircumflex,
		// Token: 0x040008FB RID: 2299
		Cabovedot = 709,
		// Token: 0x040008FC RID: 2300
		Ccircumflex,
		// Token: 0x040008FD RID: 2301
		Gabovedot = 725,
		// Token: 0x040008FE RID: 2302
		Gcircumflex = 728,
		// Token: 0x040008FF RID: 2303
		Ubreve = 733,
		// Token: 0x04000900 RID: 2304
		Scircumflex,
		// Token: 0x04000901 RID: 2305
		cabovedot = 741,
		// Token: 0x04000902 RID: 2306
		ccircumflex,
		// Token: 0x04000903 RID: 2307
		gabovedot = 757,
		// Token: 0x04000904 RID: 2308
		gcircumflex = 760,
		// Token: 0x04000905 RID: 2309
		ubreve = 765,
		// Token: 0x04000906 RID: 2310
		scircumflex,
		// Token: 0x04000907 RID: 2311
		kra = 930,
		// Token: 0x04000908 RID: 2312
		kappa = 930,
		// Token: 0x04000909 RID: 2313
		Rcedilla,
		// Token: 0x0400090A RID: 2314
		Itilde = 933,
		// Token: 0x0400090B RID: 2315
		Lcedilla,
		// Token: 0x0400090C RID: 2316
		Emacron = 938,
		// Token: 0x0400090D RID: 2317
		Gcedilla,
		// Token: 0x0400090E RID: 2318
		Tslash,
		// Token: 0x0400090F RID: 2319
		rcedilla = 947,
		// Token: 0x04000910 RID: 2320
		itilde = 949,
		// Token: 0x04000911 RID: 2321
		lcedilla,
		// Token: 0x04000912 RID: 2322
		emacron = 954,
		// Token: 0x04000913 RID: 2323
		gcedilla,
		// Token: 0x04000914 RID: 2324
		tslash,
		// Token: 0x04000915 RID: 2325
		ENG,
		// Token: 0x04000916 RID: 2326
		eng = 959,
		// Token: 0x04000917 RID: 2327
		Amacron,
		// Token: 0x04000918 RID: 2328
		Iogonek = 967,
		// Token: 0x04000919 RID: 2329
		Eabovedot = 972,
		// Token: 0x0400091A RID: 2330
		Imacron = 975,
		// Token: 0x0400091B RID: 2331
		Ncedilla = 977,
		// Token: 0x0400091C RID: 2332
		Omacron,
		// Token: 0x0400091D RID: 2333
		Kcedilla,
		// Token: 0x0400091E RID: 2334
		Uogonek = 985,
		// Token: 0x0400091F RID: 2335
		Utilde = 989,
		// Token: 0x04000920 RID: 2336
		Umacron,
		// Token: 0x04000921 RID: 2337
		amacron = 992,
		// Token: 0x04000922 RID: 2338
		iogonek = 999,
		// Token: 0x04000923 RID: 2339
		eabovedot = 1004,
		// Token: 0x04000924 RID: 2340
		imacron = 1007,
		// Token: 0x04000925 RID: 2341
		ncedilla = 1009,
		// Token: 0x04000926 RID: 2342
		omacron,
		// Token: 0x04000927 RID: 2343
		kcedilla,
		// Token: 0x04000928 RID: 2344
		uogonek = 1017,
		// Token: 0x04000929 RID: 2345
		utilde = 1021,
		// Token: 0x0400092A RID: 2346
		umacron,
		// Token: 0x0400092B RID: 2347
		OE = 5052,
		// Token: 0x0400092C RID: 2348
		oe,
		// Token: 0x0400092D RID: 2349
		Ydiaeresis,
		// Token: 0x0400092E RID: 2350
		overline = 1150,
		// Token: 0x0400092F RID: 2351
		kana_fullstop = 1185,
		// Token: 0x04000930 RID: 2352
		kana_openingbracket,
		// Token: 0x04000931 RID: 2353
		kana_closingbracket,
		// Token: 0x04000932 RID: 2354
		kana_comma,
		// Token: 0x04000933 RID: 2355
		kana_conjunctive,
		// Token: 0x04000934 RID: 2356
		kana_middledot = 1189,
		// Token: 0x04000935 RID: 2357
		kana_WO,
		// Token: 0x04000936 RID: 2358
		kana_a,
		// Token: 0x04000937 RID: 2359
		kana_i,
		// Token: 0x04000938 RID: 2360
		kana_u,
		// Token: 0x04000939 RID: 2361
		kana_e,
		// Token: 0x0400093A RID: 2362
		kana_o,
		// Token: 0x0400093B RID: 2363
		kana_ya,
		// Token: 0x0400093C RID: 2364
		kana_yu,
		// Token: 0x0400093D RID: 2365
		kana_yo,
		// Token: 0x0400093E RID: 2366
		kana_tsu,
		// Token: 0x0400093F RID: 2367
		kana_tu = 1199,
		// Token: 0x04000940 RID: 2368
		prolongedsound,
		// Token: 0x04000941 RID: 2369
		kana_A,
		// Token: 0x04000942 RID: 2370
		kana_I,
		// Token: 0x04000943 RID: 2371
		kana_U,
		// Token: 0x04000944 RID: 2372
		kana_E,
		// Token: 0x04000945 RID: 2373
		kana_O,
		// Token: 0x04000946 RID: 2374
		kana_KA,
		// Token: 0x04000947 RID: 2375
		kana_KI,
		// Token: 0x04000948 RID: 2376
		kana_KU,
		// Token: 0x04000949 RID: 2377
		kana_KE,
		// Token: 0x0400094A RID: 2378
		kana_KO,
		// Token: 0x0400094B RID: 2379
		kana_SA,
		// Token: 0x0400094C RID: 2380
		kana_SHI,
		// Token: 0x0400094D RID: 2381
		kana_SU,
		// Token: 0x0400094E RID: 2382
		kana_SE,
		// Token: 0x0400094F RID: 2383
		kana_SO,
		// Token: 0x04000950 RID: 2384
		kana_TA,
		// Token: 0x04000951 RID: 2385
		kana_CHI,
		// Token: 0x04000952 RID: 2386
		kana_TI = 1217,
		// Token: 0x04000953 RID: 2387
		kana_TSU,
		// Token: 0x04000954 RID: 2388
		kana_TU = 1218,
		// Token: 0x04000955 RID: 2389
		kana_TE,
		// Token: 0x04000956 RID: 2390
		kana_TO,
		// Token: 0x04000957 RID: 2391
		kana_NA,
		// Token: 0x04000958 RID: 2392
		kana_NI,
		// Token: 0x04000959 RID: 2393
		kana_NU,
		// Token: 0x0400095A RID: 2394
		kana_NE,
		// Token: 0x0400095B RID: 2395
		kana_NO,
		// Token: 0x0400095C RID: 2396
		kana_HA,
		// Token: 0x0400095D RID: 2397
		kana_HI,
		// Token: 0x0400095E RID: 2398
		kana_FU,
		// Token: 0x0400095F RID: 2399
		kana_HU = 1228,
		// Token: 0x04000960 RID: 2400
		kana_HE,
		// Token: 0x04000961 RID: 2401
		kana_HO,
		// Token: 0x04000962 RID: 2402
		kana_MA,
		// Token: 0x04000963 RID: 2403
		kana_MI,
		// Token: 0x04000964 RID: 2404
		kana_MU,
		// Token: 0x04000965 RID: 2405
		kana_ME,
		// Token: 0x04000966 RID: 2406
		kana_MO,
		// Token: 0x04000967 RID: 2407
		kana_YA,
		// Token: 0x04000968 RID: 2408
		kana_YU,
		// Token: 0x04000969 RID: 2409
		kana_YO,
		// Token: 0x0400096A RID: 2410
		kana_RA,
		// Token: 0x0400096B RID: 2411
		kana_RI,
		// Token: 0x0400096C RID: 2412
		kana_RU,
		// Token: 0x0400096D RID: 2413
		kana_RE,
		// Token: 0x0400096E RID: 2414
		kana_RO,
		// Token: 0x0400096F RID: 2415
		kana_WA,
		// Token: 0x04000970 RID: 2416
		kana_N,
		// Token: 0x04000971 RID: 2417
		voicedsound,
		// Token: 0x04000972 RID: 2418
		semivoicedsound,
		// Token: 0x04000973 RID: 2419
		kana_switch = 65406,
		// Token: 0x04000974 RID: 2420
		Arabic_comma = 1452,
		// Token: 0x04000975 RID: 2421
		Arabic_semicolon = 1467,
		// Token: 0x04000976 RID: 2422
		Arabic_question_mark = 1471,
		// Token: 0x04000977 RID: 2423
		Arabic_hamza = 1473,
		// Token: 0x04000978 RID: 2424
		Arabic_maddaonalef,
		// Token: 0x04000979 RID: 2425
		Arabic_hamzaonalef,
		// Token: 0x0400097A RID: 2426
		Arabic_hamzaonwaw,
		// Token: 0x0400097B RID: 2427
		Arabic_hamzaunderalef,
		// Token: 0x0400097C RID: 2428
		Arabic_hamzaonyeh,
		// Token: 0x0400097D RID: 2429
		Arabic_alef,
		// Token: 0x0400097E RID: 2430
		Arabic_beh,
		// Token: 0x0400097F RID: 2431
		Arabic_tehmarbuta,
		// Token: 0x04000980 RID: 2432
		Arabic_teh,
		// Token: 0x04000981 RID: 2433
		Arabic_theh,
		// Token: 0x04000982 RID: 2434
		Arabic_jeem,
		// Token: 0x04000983 RID: 2435
		Arabic_hah,
		// Token: 0x04000984 RID: 2436
		Arabic_khah,
		// Token: 0x04000985 RID: 2437
		Arabic_dal,
		// Token: 0x04000986 RID: 2438
		Arabic_thal,
		// Token: 0x04000987 RID: 2439
		Arabic_ra,
		// Token: 0x04000988 RID: 2440
		Arabic_zain,
		// Token: 0x04000989 RID: 2441
		Arabic_seen,
		// Token: 0x0400098A RID: 2442
		Arabic_sheen,
		// Token: 0x0400098B RID: 2443
		Arabic_sad,
		// Token: 0x0400098C RID: 2444
		Arabic_dad,
		// Token: 0x0400098D RID: 2445
		Arabic_tah,
		// Token: 0x0400098E RID: 2446
		Arabic_zah,
		// Token: 0x0400098F RID: 2447
		Arabic_ain,
		// Token: 0x04000990 RID: 2448
		Arabic_ghain,
		// Token: 0x04000991 RID: 2449
		Arabic_tatweel = 1504,
		// Token: 0x04000992 RID: 2450
		Arabic_feh,
		// Token: 0x04000993 RID: 2451
		Arabic_qaf,
		// Token: 0x04000994 RID: 2452
		Arabic_kaf,
		// Token: 0x04000995 RID: 2453
		Arabic_lam,
		// Token: 0x04000996 RID: 2454
		Arabic_meem,
		// Token: 0x04000997 RID: 2455
		Arabic_noon,
		// Token: 0x04000998 RID: 2456
		Arabic_ha,
		// Token: 0x04000999 RID: 2457
		Arabic_heh = 1511,
		// Token: 0x0400099A RID: 2458
		Arabic_waw,
		// Token: 0x0400099B RID: 2459
		Arabic_alefmaksura,
		// Token: 0x0400099C RID: 2460
		Arabic_yeh,
		// Token: 0x0400099D RID: 2461
		Arabic_fathatan,
		// Token: 0x0400099E RID: 2462
		Arabic_dammatan,
		// Token: 0x0400099F RID: 2463
		Arabic_kasratan,
		// Token: 0x040009A0 RID: 2464
		Arabic_fatha,
		// Token: 0x040009A1 RID: 2465
		Arabic_damma,
		// Token: 0x040009A2 RID: 2466
		Arabic_kasra,
		// Token: 0x040009A3 RID: 2467
		Arabic_shadda,
		// Token: 0x040009A4 RID: 2468
		Arabic_sukun,
		// Token: 0x040009A5 RID: 2469
		Arabic_switch = 65406,
		// Token: 0x040009A6 RID: 2470
		Serbian_dje = 1697,
		// Token: 0x040009A7 RID: 2471
		Macedonia_gje,
		// Token: 0x040009A8 RID: 2472
		Cyrillic_io,
		// Token: 0x040009A9 RID: 2473
		Ukrainian_ie,
		// Token: 0x040009AA RID: 2474
		Ukranian_je = 1700,
		// Token: 0x040009AB RID: 2475
		Macedonia_dse,
		// Token: 0x040009AC RID: 2476
		Ukrainian_i,
		// Token: 0x040009AD RID: 2477
		Ukranian_i = 1702,
		// Token: 0x040009AE RID: 2478
		Ukrainian_yi,
		// Token: 0x040009AF RID: 2479
		Ukranian_yi = 1703,
		// Token: 0x040009B0 RID: 2480
		Cyrillic_je,
		// Token: 0x040009B1 RID: 2481
		Serbian_je = 1704,
		// Token: 0x040009B2 RID: 2482
		Cyrillic_lje,
		// Token: 0x040009B3 RID: 2483
		Serbian_lje = 1705,
		// Token: 0x040009B4 RID: 2484
		Cyrillic_nje,
		// Token: 0x040009B5 RID: 2485
		Serbian_nje = 1706,
		// Token: 0x040009B6 RID: 2486
		Serbian_tshe,
		// Token: 0x040009B7 RID: 2487
		Macedonia_kje,
		// Token: 0x040009B8 RID: 2488
		Byelorussian_shortu = 1710,
		// Token: 0x040009B9 RID: 2489
		Cyrillic_dzhe,
		// Token: 0x040009BA RID: 2490
		Serbian_dze = 1711,
		// Token: 0x040009BB RID: 2491
		numerosign,
		// Token: 0x040009BC RID: 2492
		Serbian_DJE,
		// Token: 0x040009BD RID: 2493
		Macedonia_GJE,
		// Token: 0x040009BE RID: 2494
		Cyrillic_IO,
		// Token: 0x040009BF RID: 2495
		Ukrainian_IE,
		// Token: 0x040009C0 RID: 2496
		Ukranian_JE = 1716,
		// Token: 0x040009C1 RID: 2497
		Macedonia_DSE,
		// Token: 0x040009C2 RID: 2498
		Ukrainian_I,
		// Token: 0x040009C3 RID: 2499
		Ukranian_I = 1718,
		// Token: 0x040009C4 RID: 2500
		Ukrainian_YI,
		// Token: 0x040009C5 RID: 2501
		Ukranian_YI = 1719,
		// Token: 0x040009C6 RID: 2502
		Cyrillic_JE,
		// Token: 0x040009C7 RID: 2503
		Serbian_JE = 1720,
		// Token: 0x040009C8 RID: 2504
		Cyrillic_LJE,
		// Token: 0x040009C9 RID: 2505
		Serbian_LJE = 1721,
		// Token: 0x040009CA RID: 2506
		Cyrillic_NJE,
		// Token: 0x040009CB RID: 2507
		Serbian_NJE = 1722,
		// Token: 0x040009CC RID: 2508
		Serbian_TSHE,
		// Token: 0x040009CD RID: 2509
		Macedonia_KJE,
		// Token: 0x040009CE RID: 2510
		Byelorussian_SHORTU = 1726,
		// Token: 0x040009CF RID: 2511
		Cyrillic_DZHE,
		// Token: 0x040009D0 RID: 2512
		Serbian_DZE = 1727,
		// Token: 0x040009D1 RID: 2513
		Cyrillic_yu,
		// Token: 0x040009D2 RID: 2514
		Cyrillic_a,
		// Token: 0x040009D3 RID: 2515
		Cyrillic_be,
		// Token: 0x040009D4 RID: 2516
		Cyrillic_tse,
		// Token: 0x040009D5 RID: 2517
		Cyrillic_de,
		// Token: 0x040009D6 RID: 2518
		Cyrillic_ie,
		// Token: 0x040009D7 RID: 2519
		Cyrillic_ef,
		// Token: 0x040009D8 RID: 2520
		Cyrillic_ghe,
		// Token: 0x040009D9 RID: 2521
		Cyrillic_ha,
		// Token: 0x040009DA RID: 2522
		Cyrillic_i,
		// Token: 0x040009DB RID: 2523
		Cyrillic_shorti,
		// Token: 0x040009DC RID: 2524
		Cyrillic_ka,
		// Token: 0x040009DD RID: 2525
		Cyrillic_el,
		// Token: 0x040009DE RID: 2526
		Cyrillic_em,
		// Token: 0x040009DF RID: 2527
		Cyrillic_en,
		// Token: 0x040009E0 RID: 2528
		Cyrillic_o,
		// Token: 0x040009E1 RID: 2529
		Cyrillic_pe,
		// Token: 0x040009E2 RID: 2530
		Cyrillic_ya,
		// Token: 0x040009E3 RID: 2531
		Cyrillic_er,
		// Token: 0x040009E4 RID: 2532
		Cyrillic_es,
		// Token: 0x040009E5 RID: 2533
		Cyrillic_te,
		// Token: 0x040009E6 RID: 2534
		Cyrillic_u,
		// Token: 0x040009E7 RID: 2535
		Cyrillic_zhe,
		// Token: 0x040009E8 RID: 2536
		Cyrillic_ve,
		// Token: 0x040009E9 RID: 2537
		Cyrillic_softsign,
		// Token: 0x040009EA RID: 2538
		Cyrillic_yeru,
		// Token: 0x040009EB RID: 2539
		Cyrillic_ze,
		// Token: 0x040009EC RID: 2540
		Cyrillic_sha,
		// Token: 0x040009ED RID: 2541
		Cyrillic_e,
		// Token: 0x040009EE RID: 2542
		Cyrillic_shcha,
		// Token: 0x040009EF RID: 2543
		Cyrillic_che,
		// Token: 0x040009F0 RID: 2544
		Cyrillic_hardsign,
		// Token: 0x040009F1 RID: 2545
		Cyrillic_YU,
		// Token: 0x040009F2 RID: 2546
		Cyrillic_A,
		// Token: 0x040009F3 RID: 2547
		Cyrillic_BE,
		// Token: 0x040009F4 RID: 2548
		Cyrillic_TSE,
		// Token: 0x040009F5 RID: 2549
		Cyrillic_DE,
		// Token: 0x040009F6 RID: 2550
		Cyrillic_IE,
		// Token: 0x040009F7 RID: 2551
		Cyrillic_EF,
		// Token: 0x040009F8 RID: 2552
		Cyrillic_GHE,
		// Token: 0x040009F9 RID: 2553
		Cyrillic_HA,
		// Token: 0x040009FA RID: 2554
		Cyrillic_I,
		// Token: 0x040009FB RID: 2555
		Cyrillic_SHORTI,
		// Token: 0x040009FC RID: 2556
		Cyrillic_KA,
		// Token: 0x040009FD RID: 2557
		Cyrillic_EL,
		// Token: 0x040009FE RID: 2558
		Cyrillic_EM,
		// Token: 0x040009FF RID: 2559
		Cyrillic_EN,
		// Token: 0x04000A00 RID: 2560
		Cyrillic_O,
		// Token: 0x04000A01 RID: 2561
		Cyrillic_PE,
		// Token: 0x04000A02 RID: 2562
		Cyrillic_YA,
		// Token: 0x04000A03 RID: 2563
		Cyrillic_ER,
		// Token: 0x04000A04 RID: 2564
		Cyrillic_ES,
		// Token: 0x04000A05 RID: 2565
		Cyrillic_TE,
		// Token: 0x04000A06 RID: 2566
		Cyrillic_U,
		// Token: 0x04000A07 RID: 2567
		Cyrillic_ZHE,
		// Token: 0x04000A08 RID: 2568
		Cyrillic_VE,
		// Token: 0x04000A09 RID: 2569
		Cyrillic_SOFTSIGN,
		// Token: 0x04000A0A RID: 2570
		Cyrillic_YERU,
		// Token: 0x04000A0B RID: 2571
		Cyrillic_ZE,
		// Token: 0x04000A0C RID: 2572
		Cyrillic_SHA,
		// Token: 0x04000A0D RID: 2573
		Cyrillic_E,
		// Token: 0x04000A0E RID: 2574
		Cyrillic_SHCHA,
		// Token: 0x04000A0F RID: 2575
		Cyrillic_CHE,
		// Token: 0x04000A10 RID: 2576
		Cyrillic_HARDSIGN,
		// Token: 0x04000A11 RID: 2577
		Greek_ALPHAaccent = 1953,
		// Token: 0x04000A12 RID: 2578
		Greek_EPSILONaccent,
		// Token: 0x04000A13 RID: 2579
		Greek_ETAaccent,
		// Token: 0x04000A14 RID: 2580
		Greek_IOTAaccent,
		// Token: 0x04000A15 RID: 2581
		Greek_IOTAdiaeresis,
		// Token: 0x04000A16 RID: 2582
		Greek_OMICRONaccent = 1959,
		// Token: 0x04000A17 RID: 2583
		Greek_UPSILONaccent,
		// Token: 0x04000A18 RID: 2584
		Greek_UPSILONdieresis,
		// Token: 0x04000A19 RID: 2585
		Greek_OMEGAaccent = 1963,
		// Token: 0x04000A1A RID: 2586
		Greek_accentdieresis = 1966,
		// Token: 0x04000A1B RID: 2587
		Greek_horizbar,
		// Token: 0x04000A1C RID: 2588
		Greek_alphaaccent = 1969,
		// Token: 0x04000A1D RID: 2589
		Greek_epsilonaccent,
		// Token: 0x04000A1E RID: 2590
		Greek_etaaccent,
		// Token: 0x04000A1F RID: 2591
		Greek_iotaaccent,
		// Token: 0x04000A20 RID: 2592
		Greek_iotadieresis,
		// Token: 0x04000A21 RID: 2593
		Greek_iotaaccentdieresis,
		// Token: 0x04000A22 RID: 2594
		Greek_omicronaccent,
		// Token: 0x04000A23 RID: 2595
		Greek_upsilonaccent,
		// Token: 0x04000A24 RID: 2596
		Greek_upsilondieresis,
		// Token: 0x04000A25 RID: 2597
		Greek_upsilonaccentdieresis,
		// Token: 0x04000A26 RID: 2598
		Greek_omegaaccent,
		// Token: 0x04000A27 RID: 2599
		Greek_ALPHA = 1985,
		// Token: 0x04000A28 RID: 2600
		Greek_BETA,
		// Token: 0x04000A29 RID: 2601
		Greek_GAMMA,
		// Token: 0x04000A2A RID: 2602
		Greek_DELTA,
		// Token: 0x04000A2B RID: 2603
		Greek_EPSILON,
		// Token: 0x04000A2C RID: 2604
		Greek_ZETA,
		// Token: 0x04000A2D RID: 2605
		Greek_ETA,
		// Token: 0x04000A2E RID: 2606
		Greek_THETA,
		// Token: 0x04000A2F RID: 2607
		Greek_IOTA,
		// Token: 0x04000A30 RID: 2608
		Greek_KAPPA,
		// Token: 0x04000A31 RID: 2609
		Greek_LAMDA,
		// Token: 0x04000A32 RID: 2610
		Greek_LAMBDA = 1995,
		// Token: 0x04000A33 RID: 2611
		Greek_MU,
		// Token: 0x04000A34 RID: 2612
		Greek_NU,
		// Token: 0x04000A35 RID: 2613
		Greek_XI,
		// Token: 0x04000A36 RID: 2614
		Greek_OMICRON,
		// Token: 0x04000A37 RID: 2615
		Greek_PI,
		// Token: 0x04000A38 RID: 2616
		Greek_RHO,
		// Token: 0x04000A39 RID: 2617
		Greek_SIGMA,
		// Token: 0x04000A3A RID: 2618
		Greek_TAU = 2004,
		// Token: 0x04000A3B RID: 2619
		Greek_UPSILON,
		// Token: 0x04000A3C RID: 2620
		Greek_PHI,
		// Token: 0x04000A3D RID: 2621
		Greek_CHI,
		// Token: 0x04000A3E RID: 2622
		Greek_PSI,
		// Token: 0x04000A3F RID: 2623
		Greek_OMEGA,
		// Token: 0x04000A40 RID: 2624
		Greek_alpha = 2017,
		// Token: 0x04000A41 RID: 2625
		Greek_beta,
		// Token: 0x04000A42 RID: 2626
		Greek_gamma,
		// Token: 0x04000A43 RID: 2627
		Greek_delta,
		// Token: 0x04000A44 RID: 2628
		Greek_epsilon,
		// Token: 0x04000A45 RID: 2629
		Greek_zeta,
		// Token: 0x04000A46 RID: 2630
		Greek_eta,
		// Token: 0x04000A47 RID: 2631
		Greek_theta,
		// Token: 0x04000A48 RID: 2632
		Greek_iota,
		// Token: 0x04000A49 RID: 2633
		Greek_kappa,
		// Token: 0x04000A4A RID: 2634
		Greek_lamda,
		// Token: 0x04000A4B RID: 2635
		Greek_lambda = 2027,
		// Token: 0x04000A4C RID: 2636
		Greek_mu,
		// Token: 0x04000A4D RID: 2637
		Greek_nu,
		// Token: 0x04000A4E RID: 2638
		Greek_xi,
		// Token: 0x04000A4F RID: 2639
		Greek_omicron,
		// Token: 0x04000A50 RID: 2640
		Greek_pi,
		// Token: 0x04000A51 RID: 2641
		Greek_rho,
		// Token: 0x04000A52 RID: 2642
		Greek_sigma,
		// Token: 0x04000A53 RID: 2643
		Greek_finalsmallsigma,
		// Token: 0x04000A54 RID: 2644
		Greek_tau,
		// Token: 0x04000A55 RID: 2645
		Greek_upsilon,
		// Token: 0x04000A56 RID: 2646
		Greek_phi,
		// Token: 0x04000A57 RID: 2647
		Greek_chi,
		// Token: 0x04000A58 RID: 2648
		Greek_psi,
		// Token: 0x04000A59 RID: 2649
		Greek_omega,
		// Token: 0x04000A5A RID: 2650
		Greek_switch = 65406,
		// Token: 0x04000A5B RID: 2651
		leftradical = 2209,
		// Token: 0x04000A5C RID: 2652
		topleftradical,
		// Token: 0x04000A5D RID: 2653
		horizconnector,
		// Token: 0x04000A5E RID: 2654
		topintegral,
		// Token: 0x04000A5F RID: 2655
		botintegral,
		// Token: 0x04000A60 RID: 2656
		vertconnector,
		// Token: 0x04000A61 RID: 2657
		topleftsqbracket,
		// Token: 0x04000A62 RID: 2658
		botleftsqbracket,
		// Token: 0x04000A63 RID: 2659
		toprightsqbracket,
		// Token: 0x04000A64 RID: 2660
		botrightsqbracket,
		// Token: 0x04000A65 RID: 2661
		topleftparens,
		// Token: 0x04000A66 RID: 2662
		botleftparens,
		// Token: 0x04000A67 RID: 2663
		toprightparens,
		// Token: 0x04000A68 RID: 2664
		botrightparens,
		// Token: 0x04000A69 RID: 2665
		leftmiddlecurlybrace,
		// Token: 0x04000A6A RID: 2666
		rightmiddlecurlybrace,
		// Token: 0x04000A6B RID: 2667
		topleftsummation,
		// Token: 0x04000A6C RID: 2668
		botleftsummation,
		// Token: 0x04000A6D RID: 2669
		topvertsummationconnector,
		// Token: 0x04000A6E RID: 2670
		botvertsummationconnector,
		// Token: 0x04000A6F RID: 2671
		toprightsummation,
		// Token: 0x04000A70 RID: 2672
		botrightsummation,
		// Token: 0x04000A71 RID: 2673
		rightmiddlesummation,
		// Token: 0x04000A72 RID: 2674
		lessthanequal = 2236,
		// Token: 0x04000A73 RID: 2675
		notequal,
		// Token: 0x04000A74 RID: 2676
		greaterthanequal,
		// Token: 0x04000A75 RID: 2677
		integral,
		// Token: 0x04000A76 RID: 2678
		therefore,
		// Token: 0x04000A77 RID: 2679
		variation,
		// Token: 0x04000A78 RID: 2680
		infinity,
		// Token: 0x04000A79 RID: 2681
		nabla = 2245,
		// Token: 0x04000A7A RID: 2682
		approximate = 2248,
		// Token: 0x04000A7B RID: 2683
		similarequal,
		// Token: 0x04000A7C RID: 2684
		ifonlyif = 2253,
		// Token: 0x04000A7D RID: 2685
		implies,
		// Token: 0x04000A7E RID: 2686
		identical,
		// Token: 0x04000A7F RID: 2687
		radical = 2262,
		// Token: 0x04000A80 RID: 2688
		includedin = 2266,
		// Token: 0x04000A81 RID: 2689
		includes,
		// Token: 0x04000A82 RID: 2690
		intersection,
		// Token: 0x04000A83 RID: 2691
		union,
		// Token: 0x04000A84 RID: 2692
		logicaland,
		// Token: 0x04000A85 RID: 2693
		logicalor,
		// Token: 0x04000A86 RID: 2694
		partialderivative = 2287,
		// Token: 0x04000A87 RID: 2695
		function = 2294,
		// Token: 0x04000A88 RID: 2696
		leftarrow = 2299,
		// Token: 0x04000A89 RID: 2697
		uparrow,
		// Token: 0x04000A8A RID: 2698
		rightarrow,
		// Token: 0x04000A8B RID: 2699
		downarrow,
		// Token: 0x04000A8C RID: 2700
		blank = 2527,
		// Token: 0x04000A8D RID: 2701
		soliddiamond,
		// Token: 0x04000A8E RID: 2702
		checkerboard,
		// Token: 0x04000A8F RID: 2703
		ht,
		// Token: 0x04000A90 RID: 2704
		ff,
		// Token: 0x04000A91 RID: 2705
		cr,
		// Token: 0x04000A92 RID: 2706
		lf,
		// Token: 0x04000A93 RID: 2707
		nl = 2536,
		// Token: 0x04000A94 RID: 2708
		vt,
		// Token: 0x04000A95 RID: 2709
		lowrightcorner,
		// Token: 0x04000A96 RID: 2710
		uprightcorner,
		// Token: 0x04000A97 RID: 2711
		upleftcorner,
		// Token: 0x04000A98 RID: 2712
		lowleftcorner,
		// Token: 0x04000A99 RID: 2713
		crossinglines,
		// Token: 0x04000A9A RID: 2714
		horizlinescan1,
		// Token: 0x04000A9B RID: 2715
		horizlinescan3,
		// Token: 0x04000A9C RID: 2716
		horizlinescan5,
		// Token: 0x04000A9D RID: 2717
		horizlinescan7,
		// Token: 0x04000A9E RID: 2718
		horizlinescan9,
		// Token: 0x04000A9F RID: 2719
		leftt,
		// Token: 0x04000AA0 RID: 2720
		rightt,
		// Token: 0x04000AA1 RID: 2721
		bott,
		// Token: 0x04000AA2 RID: 2722
		topt,
		// Token: 0x04000AA3 RID: 2723
		vertbar,
		// Token: 0x04000AA4 RID: 2724
		emspace = 2721,
		// Token: 0x04000AA5 RID: 2725
		enspace,
		// Token: 0x04000AA6 RID: 2726
		em3space,
		// Token: 0x04000AA7 RID: 2727
		em4space,
		// Token: 0x04000AA8 RID: 2728
		digitspace,
		// Token: 0x04000AA9 RID: 2729
		punctspace,
		// Token: 0x04000AAA RID: 2730
		thinspace,
		// Token: 0x04000AAB RID: 2731
		hairspace,
		// Token: 0x04000AAC RID: 2732
		emdash,
		// Token: 0x04000AAD RID: 2733
		endash,
		// Token: 0x04000AAE RID: 2734
		signifblank = 2732,
		// Token: 0x04000AAF RID: 2735
		ellipsis = 2734,
		// Token: 0x04000AB0 RID: 2736
		doubbaselinedot,
		// Token: 0x04000AB1 RID: 2737
		onethird,
		// Token: 0x04000AB2 RID: 2738
		twothirds,
		// Token: 0x04000AB3 RID: 2739
		onefifth,
		// Token: 0x04000AB4 RID: 2740
		twofifths,
		// Token: 0x04000AB5 RID: 2741
		threefifths,
		// Token: 0x04000AB6 RID: 2742
		fourfifths,
		// Token: 0x04000AB7 RID: 2743
		onesixth,
		// Token: 0x04000AB8 RID: 2744
		fivesixths,
		// Token: 0x04000AB9 RID: 2745
		careof,
		// Token: 0x04000ABA RID: 2746
		figdash = 2747,
		// Token: 0x04000ABB RID: 2747
		leftanglebracket,
		// Token: 0x04000ABC RID: 2748
		decimalpoint,
		// Token: 0x04000ABD RID: 2749
		rightanglebracket,
		// Token: 0x04000ABE RID: 2750
		marker,
		// Token: 0x04000ABF RID: 2751
		oneeighth = 2755,
		// Token: 0x04000AC0 RID: 2752
		threeeighths,
		// Token: 0x04000AC1 RID: 2753
		fiveeighths,
		// Token: 0x04000AC2 RID: 2754
		seveneighths,
		// Token: 0x04000AC3 RID: 2755
		trademark = 2761,
		// Token: 0x04000AC4 RID: 2756
		signaturemark,
		// Token: 0x04000AC5 RID: 2757
		trademarkincircle,
		// Token: 0x04000AC6 RID: 2758
		leftopentriangle,
		// Token: 0x04000AC7 RID: 2759
		rightopentriangle,
		// Token: 0x04000AC8 RID: 2760
		emopencircle,
		// Token: 0x04000AC9 RID: 2761
		emopenrectangle,
		// Token: 0x04000ACA RID: 2762
		leftsinglequotemark,
		// Token: 0x04000ACB RID: 2763
		rightsinglequotemark,
		// Token: 0x04000ACC RID: 2764
		leftdoublequotemark,
		// Token: 0x04000ACD RID: 2765
		rightdoublequotemark,
		// Token: 0x04000ACE RID: 2766
		prescription,
		// Token: 0x04000ACF RID: 2767
		minutes = 2774,
		// Token: 0x04000AD0 RID: 2768
		seconds,
		// Token: 0x04000AD1 RID: 2769
		latincross = 2777,
		// Token: 0x04000AD2 RID: 2770
		hexagram,
		// Token: 0x04000AD3 RID: 2771
		filledrectbullet,
		// Token: 0x04000AD4 RID: 2772
		filledlefttribullet,
		// Token: 0x04000AD5 RID: 2773
		filledrighttribullet,
		// Token: 0x04000AD6 RID: 2774
		emfilledcircle,
		// Token: 0x04000AD7 RID: 2775
		emfilledrect,
		// Token: 0x04000AD8 RID: 2776
		enopencircbullet,
		// Token: 0x04000AD9 RID: 2777
		enopensquarebullet,
		// Token: 0x04000ADA RID: 2778
		openrectbullet,
		// Token: 0x04000ADB RID: 2779
		opentribulletup,
		// Token: 0x04000ADC RID: 2780
		opentribulletdown,
		// Token: 0x04000ADD RID: 2781
		openstar,
		// Token: 0x04000ADE RID: 2782
		enfilledcircbullet,
		// Token: 0x04000ADF RID: 2783
		enfilledsqbullet,
		// Token: 0x04000AE0 RID: 2784
		filledtribulletup,
		// Token: 0x04000AE1 RID: 2785
		filledtribulletdown,
		// Token: 0x04000AE2 RID: 2786
		leftpointer,
		// Token: 0x04000AE3 RID: 2787
		rightpointer,
		// Token: 0x04000AE4 RID: 2788
		club,
		// Token: 0x04000AE5 RID: 2789
		diamond,
		// Token: 0x04000AE6 RID: 2790
		heart,
		// Token: 0x04000AE7 RID: 2791
		maltesecross = 2800,
		// Token: 0x04000AE8 RID: 2792
		dagger,
		// Token: 0x04000AE9 RID: 2793
		doubledagger,
		// Token: 0x04000AEA RID: 2794
		checkmark,
		// Token: 0x04000AEB RID: 2795
		ballotcross,
		// Token: 0x04000AEC RID: 2796
		musicalsharp,
		// Token: 0x04000AED RID: 2797
		musicalflat,
		// Token: 0x04000AEE RID: 2798
		malesymbol,
		// Token: 0x04000AEF RID: 2799
		femalesymbol,
		// Token: 0x04000AF0 RID: 2800
		telephone,
		// Token: 0x04000AF1 RID: 2801
		telephonerecorder,
		// Token: 0x04000AF2 RID: 2802
		phonographcopyright,
		// Token: 0x04000AF3 RID: 2803
		caret,
		// Token: 0x04000AF4 RID: 2804
		singlelowquotemark,
		// Token: 0x04000AF5 RID: 2805
		doublelowquotemark,
		// Token: 0x04000AF6 RID: 2806
		cursor,
		// Token: 0x04000AF7 RID: 2807
		leftcaret = 2979,
		// Token: 0x04000AF8 RID: 2808
		rightcaret = 2982,
		// Token: 0x04000AF9 RID: 2809
		downcaret = 2984,
		// Token: 0x04000AFA RID: 2810
		upcaret,
		// Token: 0x04000AFB RID: 2811
		overbar = 3008,
		// Token: 0x04000AFC RID: 2812
		downtack = 3010,
		// Token: 0x04000AFD RID: 2813
		upshoe,
		// Token: 0x04000AFE RID: 2814
		downstile,
		// Token: 0x04000AFF RID: 2815
		underbar = 3014,
		// Token: 0x04000B00 RID: 2816
		jot = 3018,
		// Token: 0x04000B01 RID: 2817
		quad = 3020,
		// Token: 0x04000B02 RID: 2818
		uptack = 3022,
		// Token: 0x04000B03 RID: 2819
		circle,
		// Token: 0x04000B04 RID: 2820
		upstile = 3027,
		// Token: 0x04000B05 RID: 2821
		downshoe = 3030,
		// Token: 0x04000B06 RID: 2822
		rightshoe = 3032,
		// Token: 0x04000B07 RID: 2823
		leftshoe = 3034,
		// Token: 0x04000B08 RID: 2824
		lefttack = 3036,
		// Token: 0x04000B09 RID: 2825
		righttack = 3068,
		// Token: 0x04000B0A RID: 2826
		hebrew_doublelowline = 3295,
		// Token: 0x04000B0B RID: 2827
		hebrew_aleph,
		// Token: 0x04000B0C RID: 2828
		hebrew_bet,
		// Token: 0x04000B0D RID: 2829
		hebrew_beth = 3297,
		// Token: 0x04000B0E RID: 2830
		hebrew_gimel,
		// Token: 0x04000B0F RID: 2831
		hebrew_gimmel = 3298,
		// Token: 0x04000B10 RID: 2832
		hebrew_dalet,
		// Token: 0x04000B11 RID: 2833
		hebrew_daleth = 3299,
		// Token: 0x04000B12 RID: 2834
		hebrew_he,
		// Token: 0x04000B13 RID: 2835
		hebrew_waw,
		// Token: 0x04000B14 RID: 2836
		hebrew_zain,
		// Token: 0x04000B15 RID: 2837
		hebrew_zayin = 3302,
		// Token: 0x04000B16 RID: 2838
		hebrew_chet,
		// Token: 0x04000B17 RID: 2839
		hebrew_het = 3303,
		// Token: 0x04000B18 RID: 2840
		hebrew_tet,
		// Token: 0x04000B19 RID: 2841
		hebrew_teth = 3304,
		// Token: 0x04000B1A RID: 2842
		hebrew_yod,
		// Token: 0x04000B1B RID: 2843
		hebrew_finalkaph,
		// Token: 0x04000B1C RID: 2844
		hebrew_kaph,
		// Token: 0x04000B1D RID: 2845
		hebrew_lamed,
		// Token: 0x04000B1E RID: 2846
		hebrew_finalmem,
		// Token: 0x04000B1F RID: 2847
		hebrew_mem,
		// Token: 0x04000B20 RID: 2848
		hebrew_finalnun,
		// Token: 0x04000B21 RID: 2849
		hebrew_nun,
		// Token: 0x04000B22 RID: 2850
		hebrew_samech,
		// Token: 0x04000B23 RID: 2851
		hebrew_samekh = 3313,
		// Token: 0x04000B24 RID: 2852
		hebrew_ayin,
		// Token: 0x04000B25 RID: 2853
		hebrew_finalpe,
		// Token: 0x04000B26 RID: 2854
		hebrew_pe,
		// Token: 0x04000B27 RID: 2855
		hebrew_finalzade,
		// Token: 0x04000B28 RID: 2856
		hebrew_finalzadi = 3317,
		// Token: 0x04000B29 RID: 2857
		hebrew_zade,
		// Token: 0x04000B2A RID: 2858
		hebrew_zadi = 3318,
		// Token: 0x04000B2B RID: 2859
		hebrew_qoph,
		// Token: 0x04000B2C RID: 2860
		hebrew_kuf = 3319,
		// Token: 0x04000B2D RID: 2861
		hebrew_resh,
		// Token: 0x04000B2E RID: 2862
		hebrew_shin,
		// Token: 0x04000B2F RID: 2863
		hebrew_taw,
		// Token: 0x04000B30 RID: 2864
		hebrew_taf = 3322,
		// Token: 0x04000B31 RID: 2865
		Hebrew_switch = 65406,
		// Token: 0x04000B32 RID: 2866
		Thai_kokai = 3489,
		// Token: 0x04000B33 RID: 2867
		Thai_khokhai,
		// Token: 0x04000B34 RID: 2868
		Thai_khokhuat,
		// Token: 0x04000B35 RID: 2869
		Thai_khokhwai,
		// Token: 0x04000B36 RID: 2870
		Thai_khokhon,
		// Token: 0x04000B37 RID: 2871
		Thai_khorakhang,
		// Token: 0x04000B38 RID: 2872
		Thai_ngongu,
		// Token: 0x04000B39 RID: 2873
		Thai_chochan,
		// Token: 0x04000B3A RID: 2874
		Thai_choching,
		// Token: 0x04000B3B RID: 2875
		Thai_chochang,
		// Token: 0x04000B3C RID: 2876
		Thai_soso,
		// Token: 0x04000B3D RID: 2877
		Thai_chochoe,
		// Token: 0x04000B3E RID: 2878
		Thai_yoying,
		// Token: 0x04000B3F RID: 2879
		Thai_dochada,
		// Token: 0x04000B40 RID: 2880
		Thai_topatak,
		// Token: 0x04000B41 RID: 2881
		Thai_thothan,
		// Token: 0x04000B42 RID: 2882
		Thai_thonangmontho,
		// Token: 0x04000B43 RID: 2883
		Thai_thophuthao,
		// Token: 0x04000B44 RID: 2884
		Thai_nonen,
		// Token: 0x04000B45 RID: 2885
		Thai_dodek,
		// Token: 0x04000B46 RID: 2886
		Thai_totao,
		// Token: 0x04000B47 RID: 2887
		Thai_thothung,
		// Token: 0x04000B48 RID: 2888
		Thai_thothahan,
		// Token: 0x04000B49 RID: 2889
		Thai_thothong,
		// Token: 0x04000B4A RID: 2890
		Thai_nonu,
		// Token: 0x04000B4B RID: 2891
		Thai_bobaimai,
		// Token: 0x04000B4C RID: 2892
		Thai_popla,
		// Token: 0x04000B4D RID: 2893
		Thai_phophung,
		// Token: 0x04000B4E RID: 2894
		Thai_fofa,
		// Token: 0x04000B4F RID: 2895
		Thai_phophan,
		// Token: 0x04000B50 RID: 2896
		Thai_fofan,
		// Token: 0x04000B51 RID: 2897
		Thai_phosamphao,
		// Token: 0x04000B52 RID: 2898
		Thai_moma,
		// Token: 0x04000B53 RID: 2899
		Thai_yoyak,
		// Token: 0x04000B54 RID: 2900
		Thai_rorua,
		// Token: 0x04000B55 RID: 2901
		Thai_ru,
		// Token: 0x04000B56 RID: 2902
		Thai_loling,
		// Token: 0x04000B57 RID: 2903
		Thai_lu,
		// Token: 0x04000B58 RID: 2904
		Thai_wowaen,
		// Token: 0x04000B59 RID: 2905
		Thai_sosala,
		// Token: 0x04000B5A RID: 2906
		Thai_sorusi,
		// Token: 0x04000B5B RID: 2907
		Thai_sosua,
		// Token: 0x04000B5C RID: 2908
		Thai_hohip,
		// Token: 0x04000B5D RID: 2909
		Thai_lochula,
		// Token: 0x04000B5E RID: 2910
		Thai_oang,
		// Token: 0x04000B5F RID: 2911
		Thai_honokhuk,
		// Token: 0x04000B60 RID: 2912
		Thai_paiyannoi,
		// Token: 0x04000B61 RID: 2913
		Thai_saraa,
		// Token: 0x04000B62 RID: 2914
		Thai_maihanakat,
		// Token: 0x04000B63 RID: 2915
		Thai_saraaa,
		// Token: 0x04000B64 RID: 2916
		Thai_saraam,
		// Token: 0x04000B65 RID: 2917
		Thai_sarai,
		// Token: 0x04000B66 RID: 2918
		Thai_saraii,
		// Token: 0x04000B67 RID: 2919
		Thai_saraue,
		// Token: 0x04000B68 RID: 2920
		Thai_sarauee,
		// Token: 0x04000B69 RID: 2921
		Thai_sarau,
		// Token: 0x04000B6A RID: 2922
		Thai_sarauu,
		// Token: 0x04000B6B RID: 2923
		Thai_phinthu,
		// Token: 0x04000B6C RID: 2924
		Thai_maihanakat_maitho = 3550,
		// Token: 0x04000B6D RID: 2925
		Thai_baht,
		// Token: 0x04000B6E RID: 2926
		Thai_sarae,
		// Token: 0x04000B6F RID: 2927
		Thai_saraae,
		// Token: 0x04000B70 RID: 2928
		Thai_sarao,
		// Token: 0x04000B71 RID: 2929
		Thai_saraaimaimuan,
		// Token: 0x04000B72 RID: 2930
		Thai_saraaimaimalai,
		// Token: 0x04000B73 RID: 2931
		Thai_lakkhangyao,
		// Token: 0x04000B74 RID: 2932
		Thai_maiyamok,
		// Token: 0x04000B75 RID: 2933
		Thai_maitaikhu,
		// Token: 0x04000B76 RID: 2934
		Thai_maiek,
		// Token: 0x04000B77 RID: 2935
		Thai_maitho,
		// Token: 0x04000B78 RID: 2936
		Thai_maitri,
		// Token: 0x04000B79 RID: 2937
		Thai_maichattawa,
		// Token: 0x04000B7A RID: 2938
		Thai_thanthakhat,
		// Token: 0x04000B7B RID: 2939
		Thai_nikhahit,
		// Token: 0x04000B7C RID: 2940
		Thai_leksun = 3568,
		// Token: 0x04000B7D RID: 2941
		Thai_leknung,
		// Token: 0x04000B7E RID: 2942
		Thai_leksong,
		// Token: 0x04000B7F RID: 2943
		Thai_leksam,
		// Token: 0x04000B80 RID: 2944
		Thai_leksi,
		// Token: 0x04000B81 RID: 2945
		Thai_lekha,
		// Token: 0x04000B82 RID: 2946
		Thai_lekhok,
		// Token: 0x04000B83 RID: 2947
		Thai_lekchet,
		// Token: 0x04000B84 RID: 2948
		Thai_lekpaet,
		// Token: 0x04000B85 RID: 2949
		Thai_lekkao,
		// Token: 0x04000B86 RID: 2950
		Hangul = 65329,
		// Token: 0x04000B87 RID: 2951
		Hangul_Start,
		// Token: 0x04000B88 RID: 2952
		Hangul_End,
		// Token: 0x04000B89 RID: 2953
		Hangul_Hanja,
		// Token: 0x04000B8A RID: 2954
		Hangul_Jamo,
		// Token: 0x04000B8B RID: 2955
		Hangul_Romaja,
		// Token: 0x04000B8C RID: 2956
		Hangul_Codeinput,
		// Token: 0x04000B8D RID: 2957
		Hangul_Jeonja,
		// Token: 0x04000B8E RID: 2958
		Hangul_Banja,
		// Token: 0x04000B8F RID: 2959
		Hangul_PreHanja,
		// Token: 0x04000B90 RID: 2960
		Hangul_PostHanja,
		// Token: 0x04000B91 RID: 2961
		Hangul_SingleCandidate,
		// Token: 0x04000B92 RID: 2962
		Hangul_MultipleCandidate,
		// Token: 0x04000B93 RID: 2963
		Hangul_PreviousCandidate,
		// Token: 0x04000B94 RID: 2964
		Hangul_Special,
		// Token: 0x04000B95 RID: 2965
		Hangul_switch = 65406,
		// Token: 0x04000B96 RID: 2966
		Hangul_Kiyeog = 3745,
		// Token: 0x04000B97 RID: 2967
		Hangul_SsangKiyeog,
		// Token: 0x04000B98 RID: 2968
		Hangul_KiyeogSios,
		// Token: 0x04000B99 RID: 2969
		Hangul_Nieun,
		// Token: 0x04000B9A RID: 2970
		Hangul_NieunJieuj,
		// Token: 0x04000B9B RID: 2971
		Hangul_NieunHieuh,
		// Token: 0x04000B9C RID: 2972
		Hangul_Dikeud,
		// Token: 0x04000B9D RID: 2973
		Hangul_SsangDikeud,
		// Token: 0x04000B9E RID: 2974
		Hangul_Rieul,
		// Token: 0x04000B9F RID: 2975
		Hangul_RieulKiyeog,
		// Token: 0x04000BA0 RID: 2976
		Hangul_RieulMieum,
		// Token: 0x04000BA1 RID: 2977
		Hangul_RieulPieub,
		// Token: 0x04000BA2 RID: 2978
		Hangul_RieulSios,
		// Token: 0x04000BA3 RID: 2979
		Hangul_RieulTieut,
		// Token: 0x04000BA4 RID: 2980
		Hangul_RieulPhieuf,
		// Token: 0x04000BA5 RID: 2981
		Hangul_RieulHieuh,
		// Token: 0x04000BA6 RID: 2982
		Hangul_Mieum,
		// Token: 0x04000BA7 RID: 2983
		Hangul_Pieub,
		// Token: 0x04000BA8 RID: 2984
		Hangul_SsangPieub,
		// Token: 0x04000BA9 RID: 2985
		Hangul_PieubSios,
		// Token: 0x04000BAA RID: 2986
		Hangul_Sios,
		// Token: 0x04000BAB RID: 2987
		Hangul_SsangSios,
		// Token: 0x04000BAC RID: 2988
		Hangul_Ieung,
		// Token: 0x04000BAD RID: 2989
		Hangul_Jieuj,
		// Token: 0x04000BAE RID: 2990
		Hangul_SsangJieuj,
		// Token: 0x04000BAF RID: 2991
		Hangul_Cieuc,
		// Token: 0x04000BB0 RID: 2992
		Hangul_Khieuq,
		// Token: 0x04000BB1 RID: 2993
		Hangul_Tieut,
		// Token: 0x04000BB2 RID: 2994
		Hangul_Phieuf,
		// Token: 0x04000BB3 RID: 2995
		Hangul_Hieuh,
		// Token: 0x04000BB4 RID: 2996
		Hangul_A,
		// Token: 0x04000BB5 RID: 2997
		Hangul_AE,
		// Token: 0x04000BB6 RID: 2998
		Hangul_YA,
		// Token: 0x04000BB7 RID: 2999
		Hangul_YAE,
		// Token: 0x04000BB8 RID: 3000
		Hangul_EO,
		// Token: 0x04000BB9 RID: 3001
		Hangul_E,
		// Token: 0x04000BBA RID: 3002
		Hangul_YEO,
		// Token: 0x04000BBB RID: 3003
		Hangul_YE,
		// Token: 0x04000BBC RID: 3004
		Hangul_O,
		// Token: 0x04000BBD RID: 3005
		Hangul_WA,
		// Token: 0x04000BBE RID: 3006
		Hangul_WAE,
		// Token: 0x04000BBF RID: 3007
		Hangul_OE,
		// Token: 0x04000BC0 RID: 3008
		Hangul_YO,
		// Token: 0x04000BC1 RID: 3009
		Hangul_U,
		// Token: 0x04000BC2 RID: 3010
		Hangul_WEO,
		// Token: 0x04000BC3 RID: 3011
		Hangul_WE,
		// Token: 0x04000BC4 RID: 3012
		Hangul_WI,
		// Token: 0x04000BC5 RID: 3013
		Hangul_YU,
		// Token: 0x04000BC6 RID: 3014
		Hangul_EU,
		// Token: 0x04000BC7 RID: 3015
		Hangul_YI,
		// Token: 0x04000BC8 RID: 3016
		Hangul_I,
		// Token: 0x04000BC9 RID: 3017
		Hangul_J_Kiyeog,
		// Token: 0x04000BCA RID: 3018
		Hangul_J_SsangKiyeog,
		// Token: 0x04000BCB RID: 3019
		Hangul_J_KiyeogSios,
		// Token: 0x04000BCC RID: 3020
		Hangul_J_Nieun,
		// Token: 0x04000BCD RID: 3021
		Hangul_J_NieunJieuj,
		// Token: 0x04000BCE RID: 3022
		Hangul_J_NieunHieuh,
		// Token: 0x04000BCF RID: 3023
		Hangul_J_Dikeud,
		// Token: 0x04000BD0 RID: 3024
		Hangul_J_Rieul,
		// Token: 0x04000BD1 RID: 3025
		Hangul_J_RieulKiyeog,
		// Token: 0x04000BD2 RID: 3026
		Hangul_J_RieulMieum,
		// Token: 0x04000BD3 RID: 3027
		Hangul_J_RieulPieub,
		// Token: 0x04000BD4 RID: 3028
		Hangul_J_RieulSios,
		// Token: 0x04000BD5 RID: 3029
		Hangul_J_RieulTieut,
		// Token: 0x04000BD6 RID: 3030
		Hangul_J_RieulPhieuf,
		// Token: 0x04000BD7 RID: 3031
		Hangul_J_RieulHieuh,
		// Token: 0x04000BD8 RID: 3032
		Hangul_J_Mieum,
		// Token: 0x04000BD9 RID: 3033
		Hangul_J_Pieub,
		// Token: 0x04000BDA RID: 3034
		Hangul_J_PieubSios,
		// Token: 0x04000BDB RID: 3035
		Hangul_J_Sios,
		// Token: 0x04000BDC RID: 3036
		Hangul_J_SsangSios,
		// Token: 0x04000BDD RID: 3037
		Hangul_J_Ieung,
		// Token: 0x04000BDE RID: 3038
		Hangul_J_Jieuj,
		// Token: 0x04000BDF RID: 3039
		Hangul_J_Cieuc,
		// Token: 0x04000BE0 RID: 3040
		Hangul_J_Khieuq,
		// Token: 0x04000BE1 RID: 3041
		Hangul_J_Tieut,
		// Token: 0x04000BE2 RID: 3042
		Hangul_J_Phieuf,
		// Token: 0x04000BE3 RID: 3043
		Hangul_J_Hieuh,
		// Token: 0x04000BE4 RID: 3044
		Hangul_RieulYeorinHieuh,
		// Token: 0x04000BE5 RID: 3045
		Hangul_SunkyeongeumMieum,
		// Token: 0x04000BE6 RID: 3046
		Hangul_SunkyeongeumPieub,
		// Token: 0x04000BE7 RID: 3047
		Hangul_PanSios,
		// Token: 0x04000BE8 RID: 3048
		Hangul_KkogjiDalrinIeung,
		// Token: 0x04000BE9 RID: 3049
		Hangul_SunkyeongeumPhieuf,
		// Token: 0x04000BEA RID: 3050
		Hangul_YeorinHieuh,
		// Token: 0x04000BEB RID: 3051
		Hangul_AraeA,
		// Token: 0x04000BEC RID: 3052
		Hangul_AraeAE,
		// Token: 0x04000BED RID: 3053
		Hangul_J_PanSios,
		// Token: 0x04000BEE RID: 3054
		Hangul_J_KkogjiDalrinIeung,
		// Token: 0x04000BEF RID: 3055
		Hangul_J_YeorinHieuh,
		// Token: 0x04000BF0 RID: 3056
		Korean_Won = 3839,
		// Token: 0x04000BF1 RID: 3057
		EcuSign = 8352,
		// Token: 0x04000BF2 RID: 3058
		ColonSign,
		// Token: 0x04000BF3 RID: 3059
		CruzeiroSign,
		// Token: 0x04000BF4 RID: 3060
		FFrancSign,
		// Token: 0x04000BF5 RID: 3061
		LiraSign,
		// Token: 0x04000BF6 RID: 3062
		MillSign,
		// Token: 0x04000BF7 RID: 3063
		NairaSign,
		// Token: 0x04000BF8 RID: 3064
		PesetaSign,
		// Token: 0x04000BF9 RID: 3065
		RupeeSign,
		// Token: 0x04000BFA RID: 3066
		WonSign,
		// Token: 0x04000BFB RID: 3067
		NewSheqelSign,
		// Token: 0x04000BFC RID: 3068
		DongSign,
		// Token: 0x04000BFD RID: 3069
		EuroSign
	}
}
