﻿using System;

namespace Gdk
{
	// Token: 0x020000B7 RID: 183
	// (Invoke) Token: 0x06000744 RID: 1860
	public delegate void MovedToRectHandler(object o, MovedToRectArgs args);
}
