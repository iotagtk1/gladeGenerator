﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000DC RID: 220
	public class PixbufSimpleAnim : PixbufAnimation
	{
		// Token: 0x06000866 RID: 2150 RVA: 0x00018D1A File Offset: 0x00016F1A
		public PixbufSimpleAnim(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000867 RID: 2151 RVA: 0x00018D24 File Offset: 0x00016F24
		public PixbufSimpleAnim(int width, int height, float rate) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(PixbufSimpleAnim))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			this.Raw = PixbufSimpleAnim.gdk_pixbuf_simple_anim_new(width, height, rate);
		}

		// Token: 0x1700022D RID: 557
		// (get) Token: 0x06000868 RID: 2152 RVA: 0x00018D85 File Offset: 0x00016F85
		// (set) Token: 0x06000869 RID: 2153 RVA: 0x00018D97 File Offset: 0x00016F97
		[Property("loop")]
		public bool Loop
		{
			get
			{
				return PixbufSimpleAnim.gdk_pixbuf_simple_anim_get_loop(base.Handle);
			}
			set
			{
				PixbufSimpleAnim.gdk_pixbuf_simple_anim_set_loop(base.Handle, value);
			}
		}

		// Token: 0x0600086A RID: 2154 RVA: 0x00018DAA File Offset: 0x00016FAA
		public void AddFrame(Pixbuf pixbuf)
		{
			PixbufSimpleAnim.gdk_pixbuf_simple_anim_add_frame(base.Handle, (pixbuf == null) ? IntPtr.Zero : pixbuf.Handle);
		}

		// Token: 0x1700022E RID: 558
		// (get) Token: 0x0600086B RID: 2155 RVA: 0x00018DCC File Offset: 0x00016FCC
		public new static GType GType
		{
			get
			{
				IntPtr val = PixbufSimpleAnim.gdk_pixbuf_simple_anim_get_type();
				return new GType(val);
			}
		}

		// Token: 0x040004B9 RID: 1209
		private static PixbufSimpleAnim.d_gdk_pixbuf_simple_anim_new gdk_pixbuf_simple_anim_new = FuncLoader.LoadFunction<PixbufSimpleAnim.d_gdk_pixbuf_simple_anim_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_simple_anim_new"));

		// Token: 0x040004BA RID: 1210
		private static PixbufSimpleAnim.d_gdk_pixbuf_simple_anim_get_loop gdk_pixbuf_simple_anim_get_loop = FuncLoader.LoadFunction<PixbufSimpleAnim.d_gdk_pixbuf_simple_anim_get_loop>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_simple_anim_get_loop"));

		// Token: 0x040004BB RID: 1211
		private static PixbufSimpleAnim.d_gdk_pixbuf_simple_anim_set_loop gdk_pixbuf_simple_anim_set_loop = FuncLoader.LoadFunction<PixbufSimpleAnim.d_gdk_pixbuf_simple_anim_set_loop>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_simple_anim_set_loop"));

		// Token: 0x040004BC RID: 1212
		private static PixbufSimpleAnim.d_gdk_pixbuf_simple_anim_add_frame gdk_pixbuf_simple_anim_add_frame = FuncLoader.LoadFunction<PixbufSimpleAnim.d_gdk_pixbuf_simple_anim_add_frame>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_simple_anim_add_frame"));

		// Token: 0x040004BD RID: 1213
		private static PixbufSimpleAnim.d_gdk_pixbuf_simple_anim_get_type gdk_pixbuf_simple_anim_get_type = FuncLoader.LoadFunction<PixbufSimpleAnim.d_gdk_pixbuf_simple_anim_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_simple_anim_get_type"));

		// Token: 0x02000399 RID: 921
		// (Invoke) Token: 0x060014E6 RID: 5350
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_simple_anim_new(int width, int height, float rate);

		// Token: 0x0200039A RID: 922
		// (Invoke) Token: 0x060014EA RID: 5354
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_simple_anim_get_loop(IntPtr raw);

		// Token: 0x0200039B RID: 923
		// (Invoke) Token: 0x060014EE RID: 5358
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_pixbuf_simple_anim_set_loop(IntPtr raw, bool loop);

		// Token: 0x0200039C RID: 924
		// (Invoke) Token: 0x060014F2 RID: 5362
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_pixbuf_simple_anim_add_frame(IntPtr raw, IntPtr pixbuf);

		// Token: 0x0200039D RID: 925
		// (Invoke) Token: 0x060014F6 RID: 5366
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_simple_anim_get_type();
	}
}
