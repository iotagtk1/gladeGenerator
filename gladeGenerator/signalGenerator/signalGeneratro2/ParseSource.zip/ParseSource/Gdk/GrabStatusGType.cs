﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200009B RID: 155
	internal class GrabStatusGType
	{
		// Token: 0x170001A8 RID: 424
		// (get) Token: 0x06000662 RID: 1634 RVA: 0x00012F4A File Offset: 0x0001114A
		public static GType GType
		{
			get
			{
				return new GType(GrabStatusGType.gdk_grab_status_get_type());
			}
		}

		// Token: 0x0400036F RID: 879
		private static GrabStatusGType.d_gdk_grab_status_get_type gdk_grab_status_get_type = FuncLoader.LoadFunction<GrabStatusGType.d_gdk_grab_status_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_grab_status_get_type"));

		// Token: 0x020002D9 RID: 729
		// (Invoke) Token: 0x060011E9 RID: 4585
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_grab_status_get_type();
	}
}
