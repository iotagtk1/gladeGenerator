﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000116 RID: 278
	public struct WindowAttr : IEquatable<WindowAttr>
	{
		// Token: 0x170002E9 RID: 745
		// (get) Token: 0x06000B2F RID: 2863 RVA: 0x00021191 File Offset: 0x0001F391
		// (set) Token: 0x06000B30 RID: 2864 RVA: 0x000211A3 File Offset: 0x0001F3A3
		public Visual Visual
		{
			get
			{
				return Object.GetObject(this._visual) as Visual;
			}
			set
			{
				this._visual = ((value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x170002EA RID: 746
		// (get) Token: 0x06000B31 RID: 2865 RVA: 0x000211BB File Offset: 0x0001F3BB
		// (set) Token: 0x06000B32 RID: 2866 RVA: 0x000211CD File Offset: 0x0001F3CD
		public Cursor Cursor
		{
			get
			{
				return Object.GetObject(this._cursor) as Cursor;
			}
			set
			{
				this._cursor = ((value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x06000B33 RID: 2867 RVA: 0x000211E5 File Offset: 0x0001F3E5
		public static WindowAttr New(IntPtr raw)
		{
			if (raw == IntPtr.Zero)
			{
				return WindowAttr.Zero;
			}
			return (WindowAttr)Marshal.PtrToStructure(raw, typeof(WindowAttr));
		}

		// Token: 0x06000B34 RID: 2868 RVA: 0x00021210 File Offset: 0x0001F410
		public bool Equals(WindowAttr other)
		{
			return this.Title.Equals(other.Title) && this.EventMask.Equals(other.EventMask) && this.X.Equals(other.X) && this.Y.Equals(other.Y) && this.Width.Equals(other.Width) && this.Height.Equals(other.Height) && this.Wclass.Equals(other.Wclass) && this.Visual.Equals(other.Visual) && this.WindowType.Equals(other.WindowType) && this.Cursor.Equals(other.Cursor) && this.WmclassName.Equals(other.WmclassName) && this.WmclassClass.Equals(other.WmclassClass) && this.OverrideRedirect.Equals(other.OverrideRedirect) && this.TypeHint.Equals(other.TypeHint);
		}

		// Token: 0x06000B35 RID: 2869 RVA: 0x00021362 File Offset: 0x0001F562
		public override bool Equals(object other)
		{
			return other is WindowAttr && this.Equals((WindowAttr)other);
		}

		// Token: 0x06000B36 RID: 2870 RVA: 0x0002137C File Offset: 0x0001F57C
		public override int GetHashCode()
		{
			return base.GetType().FullName.GetHashCode() ^ this.Title.GetHashCode() ^ this.EventMask.GetHashCode() ^ this.X.GetHashCode() ^ this.Y.GetHashCode() ^ this.Width.GetHashCode() ^ this.Height.GetHashCode() ^ this.Wclass.GetHashCode() ^ this.Visual.GetHashCode() ^ this.WindowType.GetHashCode() ^ this.Cursor.GetHashCode() ^ this.WmclassName.GetHashCode() ^ this.WmclassClass.GetHashCode() ^ this.OverrideRedirect.GetHashCode() ^ this.TypeHint.GetHashCode();
		}

		// Token: 0x170002EB RID: 747
		// (get) Token: 0x06000B37 RID: 2871 RVA: 0x0002145D File Offset: 0x0001F65D
		private static GType GType
		{
			get
			{
				return GType.Pointer;
			}
		}

		// Token: 0x170002EC RID: 748
		// (get) Token: 0x06000B38 RID: 2872 RVA: 0x00021464 File Offset: 0x0001F664
		// (set) Token: 0x06000B39 RID: 2873 RVA: 0x0002146C File Offset: 0x0001F66C
		public EventMask Mask
		{
			get
			{
				return (EventMask)this.EventMask;
			}
			set
			{
				this.EventMask = (int)value;
			}
		}

		// Token: 0x170002ED RID: 749
		// (get) Token: 0x06000B3A RID: 2874 RVA: 0x00021475 File Offset: 0x0001F675
		// (set) Token: 0x06000B3B RID: 2875 RVA: 0x00021487 File Offset: 0x0001F687
		[Obsolete("Replaced by Visual property.")]
		public Visual visual
		{
			get
			{
				return (Visual)Object.GetObject(this._visual);
			}
			set
			{
				this._visual = value.Handle;
			}
		}

		// Token: 0x170002EE RID: 750
		// (get) Token: 0x06000B3C RID: 2876 RVA: 0x00021498 File Offset: 0x0001F698
		// (set) Token: 0x06000B3D RID: 2877 RVA: 0x000214C1 File Offset: 0x0001F6C1
		[Obsolete("Replaced by Cursor property.")]
		public Cursor cursor
		{
			get
			{
				Cursor cursor = new Cursor(this._cursor);
				if (cursor == null)
				{
					cursor = new Cursor(this._cursor);
				}
				return cursor;
			}
			set
			{
				this._cursor = value.Handle;
			}
		}

		// Token: 0x0400065D RID: 1629
		public string Title;

		// Token: 0x0400065E RID: 1630
		public int EventMask;

		// Token: 0x0400065F RID: 1631
		public int X;

		// Token: 0x04000660 RID: 1632
		public int Y;

		// Token: 0x04000661 RID: 1633
		public int Width;

		// Token: 0x04000662 RID: 1634
		public int Height;

		// Token: 0x04000663 RID: 1635
		public WindowWindowClass Wclass;

		// Token: 0x04000664 RID: 1636
		private IntPtr _visual;

		// Token: 0x04000665 RID: 1637
		public WindowType WindowType;

		// Token: 0x04000666 RID: 1638
		private IntPtr _cursor;

		// Token: 0x04000667 RID: 1639
		public string WmclassName;

		// Token: 0x04000668 RID: 1640
		public string WmclassClass;

		// Token: 0x04000669 RID: 1641
		public bool OverrideRedirect;

		// Token: 0x0400066A RID: 1642
		public WindowTypeHint TypeHint;

		// Token: 0x0400066B RID: 1643
		public static WindowAttr Zero;
	}
}
