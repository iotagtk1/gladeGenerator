﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000111 RID: 273
	internal class VisibilityStateGType
	{
		// Token: 0x17000298 RID: 664
		// (get) Token: 0x06000A42 RID: 2626 RVA: 0x0001DF54 File Offset: 0x0001C154
		public static GType GType
		{
			get
			{
				return new GType(VisibilityStateGType.gdk_visibility_state_get_type());
			}
		}

		// Token: 0x0400059B RID: 1435
		private static VisibilityStateGType.d_gdk_visibility_state_get_type gdk_visibility_state_get_type = FuncLoader.LoadFunction<VisibilityStateGType.d_gdk_visibility_state_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_visibility_state_get_type"));

		// Token: 0x02000414 RID: 1044
		// (Invoke) Token: 0x060016D2 RID: 5842
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_visibility_state_get_type();
	}
}
