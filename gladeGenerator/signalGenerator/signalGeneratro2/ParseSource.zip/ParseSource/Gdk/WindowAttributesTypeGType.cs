﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000118 RID: 280
	internal class WindowAttributesTypeGType
	{
		// Token: 0x170002EF RID: 751
		// (get) Token: 0x06000B3F RID: 2879 RVA: 0x000214D1 File Offset: 0x0001F6D1
		public static GType GType
		{
			get
			{
				return new GType(WindowAttributesTypeGType.gdk_window_attributes_type_get_type());
			}
		}

		// Token: 0x04000675 RID: 1653
		private static WindowAttributesTypeGType.d_gdk_window_attributes_type_get_type gdk_window_attributes_type_get_type = FuncLoader.LoadFunction<WindowAttributesTypeGType.d_gdk_window_attributes_type_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_attributes_type_get_type"));

		// Token: 0x020004CD RID: 1229
		// (Invoke) Token: 0x060019B6 RID: 6582
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_attributes_type_get_type();
	}
}
