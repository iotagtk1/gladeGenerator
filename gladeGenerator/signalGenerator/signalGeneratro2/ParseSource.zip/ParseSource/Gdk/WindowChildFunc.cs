﻿using System;

namespace Gdk
{
	// Token: 0x02000119 RID: 281
	// (Invoke) Token: 0x06000B43 RID: 2883
	public delegate bool WindowChildFunc(Window window);
}
