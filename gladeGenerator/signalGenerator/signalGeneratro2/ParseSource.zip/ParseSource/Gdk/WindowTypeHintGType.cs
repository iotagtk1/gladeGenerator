﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000126 RID: 294
	internal class WindowTypeHintGType
	{
		// Token: 0x170002F6 RID: 758
		// (get) Token: 0x06000B5A RID: 2906 RVA: 0x00021626 File Offset: 0x0001F826
		public static GType GType
		{
			get
			{
				return new GType(WindowTypeHintGType.gdk_window_type_hint_get_type());
			}
		}

		// Token: 0x040006B0 RID: 1712
		private static WindowTypeHintGType.d_gdk_window_type_hint_get_type gdk_window_type_hint_get_type = FuncLoader.LoadFunction<WindowTypeHintGType.d_gdk_window_type_hint_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_type_hint_get_type"));

		// Token: 0x020004D2 RID: 1234
		// (Invoke) Token: 0x060019CA RID: 6602
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_type_hint_get_type();
	}
}
