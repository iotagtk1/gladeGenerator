﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000E8 RID: 232
	[GType(typeof(PropModeGType))]
	public enum PropMode
	{
		// Token: 0x040004EC RID: 1260
		Replace,
		// Token: 0x040004ED RID: 1261
		Prepend,
		// Token: 0x040004EE RID: 1262
		Append
	}
}
