﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x020000D5 RID: 213
	public class PixbufNonAnimIter : Opaque
	{
		// Token: 0x06000857 RID: 2135 RVA: 0x00018C4D File Offset: 0x00016E4D
		public PixbufNonAnimIter(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000228 RID: 552
		// (get) Token: 0x06000858 RID: 2136 RVA: 0x00018C56 File Offset: 0x00016E56
		public static AbiStruct abi_info
		{
			get
			{
				if (PixbufNonAnimIter._abi_info == null)
				{
					PixbufNonAnimIter._abi_info = new AbiStruct(new List<AbiField>());
				}
				return PixbufNonAnimIter._abi_info;
			}
		}

		// Token: 0x040004AF RID: 1199
		private static AbiStruct _abi_info;
	}
}
