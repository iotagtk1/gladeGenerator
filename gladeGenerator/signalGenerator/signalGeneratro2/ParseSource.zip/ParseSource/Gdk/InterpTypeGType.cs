﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000A7 RID: 167
	internal class InterpTypeGType
	{
		// Token: 0x170001B0 RID: 432
		// (get) Token: 0x0600067A RID: 1658 RVA: 0x0001306A File Offset: 0x0001126A
		public static GType GType
		{
			get
			{
				return new GType(InterpTypeGType.gdk_interp_type_get_type());
			}
		}

		// Token: 0x04000393 RID: 915
		private static InterpTypeGType.d_gdk_interp_type_get_type gdk_interp_type_get_type = FuncLoader.LoadFunction<InterpTypeGType.d_gdk_interp_type_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_interp_type_get_type"));

		// Token: 0x020002DD RID: 733
		// (Invoke) Token: 0x060011F9 RID: 4601
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_interp_type_get_type();
	}
}
