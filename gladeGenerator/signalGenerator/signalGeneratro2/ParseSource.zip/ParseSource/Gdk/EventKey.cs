﻿using System;
using System.Runtime.InteropServices;

namespace Gdk
{
	// Token: 0x0200002D RID: 45
	public class EventKey : Event
	{
		// Token: 0x06000306 RID: 774 RVA: 0x0000A88C File Offset: 0x00008A8C
		public EventKey(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x06000307 RID: 775 RVA: 0x0000A895 File Offset: 0x00008A95
		private EventKey.NativeStruct Native
		{
			get
			{
				return (EventKey.NativeStruct)Marshal.PtrToStructure(base.Handle, typeof(EventKey.NativeStruct));
			}
		}

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x06000308 RID: 776 RVA: 0x0000A8B1 File Offset: 0x00008AB1
		// (set) Token: 0x06000309 RID: 777 RVA: 0x0000A8C0 File Offset: 0x00008AC0
		public byte Group
		{
			get
			{
				return this.Native.group;
			}
			set
			{
				EventKey.NativeStruct native = this.Native;
				native.group = value;
				Marshal.StructureToPtr<EventKey.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x0600030A RID: 778 RVA: 0x0000A8E9 File Offset: 0x00008AE9
		// (set) Token: 0x0600030B RID: 779 RVA: 0x0000A8F8 File Offset: 0x00008AF8
		public ushort HardwareKeycode
		{
			get
			{
				return this.Native.hardware_keycode;
			}
			set
			{
				EventKey.NativeStruct native = this.Native;
				native.hardware_keycode = value;
				Marshal.StructureToPtr<EventKey.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x0600030C RID: 780 RVA: 0x0000A921 File Offset: 0x00008B21
		public Key Key
		{
			get
			{
				return (Key)this.KeyValue;
			}
		}

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x0600030D RID: 781 RVA: 0x0000A929 File Offset: 0x00008B29
		// (set) Token: 0x0600030E RID: 782 RVA: 0x0000A938 File Offset: 0x00008B38
		public uint KeyValue
		{
			get
			{
				return this.Native.keyval;
			}
			set
			{
				EventKey.NativeStruct native = this.Native;
				native.keyval = value;
				Marshal.StructureToPtr<EventKey.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x0600030F RID: 783 RVA: 0x0000A961 File Offset: 0x00008B61
		// (set) Token: 0x06000310 RID: 784 RVA: 0x0000A970 File Offset: 0x00008B70
		public ModifierType State
		{
			get
			{
				return (ModifierType)this.Native.state;
			}
			set
			{
				EventKey.NativeStruct native = this.Native;
				native.state = (uint)value;
				Marshal.StructureToPtr<EventKey.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x06000311 RID: 785 RVA: 0x0000A999 File Offset: 0x00008B99
		// (set) Token: 0x06000312 RID: 786 RVA: 0x0000A9A8 File Offset: 0x00008BA8
		public uint Time
		{
			get
			{
				return this.Native.time;
			}
			set
			{
				EventKey.NativeStruct native = this.Native;
				native.time = value;
				Marshal.StructureToPtr<EventKey.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x020001E0 RID: 480
		private struct NativeStruct
		{
			// Token: 0x04000C46 RID: 3142
			private EventType type;

			// Token: 0x04000C47 RID: 3143
			private IntPtr window;

			// Token: 0x04000C48 RID: 3144
			private sbyte send_event;

			// Token: 0x04000C49 RID: 3145
			public uint time;

			// Token: 0x04000C4A RID: 3146
			public uint state;

			// Token: 0x04000C4B RID: 3147
			public uint keyval;

			// Token: 0x04000C4C RID: 3148
			private int length;

			// Token: 0x04000C4D RID: 3149
			private IntPtr _string;

			// Token: 0x04000C4E RID: 3150
			public ushort hardware_keycode;

			// Token: 0x04000C4F RID: 3151
			public byte group;
		}
	}
}
