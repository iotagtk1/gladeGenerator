﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000100 RID: 256
	internal class SubpixelLayoutGType
	{
		// Token: 0x17000289 RID: 649
		// (get) Token: 0x06000A11 RID: 2577 RVA: 0x0001DB2C File Offset: 0x0001BD2C
		public static GType GType
		{
			get
			{
				return new GType(SubpixelLayoutGType.gdk_subpixel_layout_get_type());
			}
		}

		// Token: 0x04000580 RID: 1408
		private static SubpixelLayoutGType.d_gdk_subpixel_layout_get_type gdk_subpixel_layout_get_type = FuncLoader.LoadFunction<SubpixelLayoutGType.d_gdk_subpixel_layout_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_subpixel_layout_get_type"));

		// Token: 0x0200040C RID: 1036
		// (Invoke) Token: 0x060016B2 RID: 5810
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_subpixel_layout_get_type();
	}
}
