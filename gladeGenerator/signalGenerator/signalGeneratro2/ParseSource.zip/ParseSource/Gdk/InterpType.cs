﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000A6 RID: 166
	[GType(typeof(InterpTypeGType))]
	public enum InterpType
	{
		// Token: 0x0400038F RID: 911
		Nearest,
		// Token: 0x04000390 RID: 912
		Tiles,
		// Token: 0x04000391 RID: 913
		Bilinear,
		// Token: 0x04000392 RID: 914
		Hyper
	}
}
