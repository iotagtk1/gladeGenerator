﻿using System;

namespace Gdk
{
	// Token: 0x0200010A RID: 266
	// (Invoke) Token: 0x06000A31 RID: 2609
	public delegate void ToEmbedderHandler(object o, ToEmbedderArgs args);
}
