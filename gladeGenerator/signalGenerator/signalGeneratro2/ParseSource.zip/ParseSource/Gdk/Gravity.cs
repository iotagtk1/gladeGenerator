﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x0200009C RID: 156
	[GType(typeof(GravityGType))]
	public enum Gravity
	{
		// Token: 0x04000371 RID: 881
		NorthWest = 1,
		// Token: 0x04000372 RID: 882
		North,
		// Token: 0x04000373 RID: 883
		NorthEast,
		// Token: 0x04000374 RID: 884
		West,
		// Token: 0x04000375 RID: 885
		Center,
		// Token: 0x04000376 RID: 886
		East,
		// Token: 0x04000377 RID: 887
		SouthWest,
		// Token: 0x04000378 RID: 888
		South,
		// Token: 0x04000379 RID: 889
		SouthEast,
		// Token: 0x0400037A RID: 890
		Static
	}
}
