﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000040 RID: 64
	[Flags]
	[GType(typeof(AxisFlagsGType))]
	public enum AxisFlags
	{
		// Token: 0x04000119 RID: 281
		X = 1,
		// Token: 0x0400011A RID: 282
		Y = 2,
		// Token: 0x0400011B RID: 283
		Pressure = 3,
		// Token: 0x0400011C RID: 284
		Xtilt = 4,
		// Token: 0x0400011D RID: 285
		Ytilt = 5,
		// Token: 0x0400011E RID: 286
		Wheel = 6,
		// Token: 0x0400011F RID: 287
		Distance = 7,
		// Token: 0x04000120 RID: 288
		Rotation = 8,
		// Token: 0x04000121 RID: 289
		Slider = 9
	}
}
