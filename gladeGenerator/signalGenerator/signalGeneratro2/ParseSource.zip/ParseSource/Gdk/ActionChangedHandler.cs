﻿using System;

namespace Gdk
{
	// Token: 0x02000037 RID: 55
	// (Invoke) Token: 0x06000374 RID: 884
	public delegate void ActionChangedHandler(object o, ActionChangedArgs args);
}
