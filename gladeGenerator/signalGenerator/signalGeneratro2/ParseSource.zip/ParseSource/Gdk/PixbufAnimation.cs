﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using GLib;
using GLibSharp;

namespace Gdk
{
	// Token: 0x020000C7 RID: 199
	public class PixbufAnimation : Object
	{
		// Token: 0x060007C8 RID: 1992 RVA: 0x0001736E File Offset: 0x0001556E
		public PixbufAnimation(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x060007C9 RID: 1993 RVA: 0x00017378 File Offset: 0x00015578
		public PixbufAnimation(InputStream stream, Cancellable cancellable) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(PixbufAnimation))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr zero = IntPtr.Zero;
			this.Raw = PixbufAnimation.gdk_pixbuf_animation_new_from_stream((stream == null) ? IntPtr.Zero : stream.Handle, (cancellable == null) ? IntPtr.Zero : cancellable.Handle, out zero);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
		}

		// Token: 0x060007CA RID: 1994 RVA: 0x00017414 File Offset: 0x00015614
		public PixbufAnimation(InputStream stream, Cancellable cancellable, AsyncReadyCallback cb) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(PixbufAnimation))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			AsyncReadyCallbackWrapper asyncReadyCallbackWrapper = new AsyncReadyCallbackWrapper(cb);
			this.Raw = PixbufAnimation.gdk_pixbuf_animation_new_from_stream_async((stream == null) ? IntPtr.Zero : stream.Handle, (cancellable == null) ? IntPtr.Zero : cancellable.Handle, asyncReadyCallbackWrapper.NativeDelegate, IntPtr.Zero);
		}

		// Token: 0x060007CB RID: 1995 RVA: 0x000174A4 File Offset: 0x000156A4
		public PixbufAnimation(IAsyncResult async_result) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(PixbufAnimation))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr zero = IntPtr.Zero;
			this.Raw = PixbufAnimation.gdk_pixbuf_animation_new_from_stream_finish((async_result == null) ? IntPtr.Zero : ((async_result is Object) ? (async_result as Object).Handle : (async_result as AsyncResultAdapter).Handle), out zero);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
		}

		// Token: 0x170001FD RID: 509
		// (get) Token: 0x060007CC RID: 1996 RVA: 0x00017548 File Offset: 0x00015748
		public int Height
		{
			get
			{
				return PixbufAnimation.gdk_pixbuf_animation_get_height(base.Handle);
			}
		}

		// Token: 0x060007CD RID: 1997 RVA: 0x0001755A File Offset: 0x0001575A
		public PixbufAnimationIter GetIter(IntPtr start_time)
		{
			return Object.GetObject(PixbufAnimation.gdk_pixbuf_animation_get_iter(base.Handle, start_time)) as PixbufAnimationIter;
		}

		// Token: 0x170001FE RID: 510
		// (get) Token: 0x060007CE RID: 1998 RVA: 0x00017577 File Offset: 0x00015777
		public Pixbuf StaticImage
		{
			get
			{
				return Object.GetObject(PixbufAnimation.gdk_pixbuf_animation_get_static_image(base.Handle)) as Pixbuf;
			}
		}

		// Token: 0x170001FF RID: 511
		// (get) Token: 0x060007CF RID: 1999 RVA: 0x00017594 File Offset: 0x00015794
		public new static GType GType
		{
			get
			{
				IntPtr val = PixbufAnimation.gdk_pixbuf_animation_get_type();
				return new GType(val);
			}
		}

		// Token: 0x17000200 RID: 512
		// (get) Token: 0x060007D0 RID: 2000 RVA: 0x000175B2 File Offset: 0x000157B2
		public int Width
		{
			get
			{
				return PixbufAnimation.gdk_pixbuf_animation_get_width(base.Handle);
			}
		}

		// Token: 0x17000201 RID: 513
		// (get) Token: 0x060007D1 RID: 2001 RVA: 0x000175C4 File Offset: 0x000157C4
		public bool IsStaticImage
		{
			get
			{
				return PixbufAnimation.gdk_pixbuf_animation_is_static_image(base.Handle);
			}
		}

		// Token: 0x060007D2 RID: 2002 RVA: 0x000175D8 File Offset: 0x000157D8
		public PixbufAnimation(string filename) : base(IntPtr.Zero)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(filename);
			IntPtr zero = IntPtr.Zero;
			this.Raw = PixbufAnimation.gdk_pixbuf_animation_new_from_file(intPtr, out zero);
			Marshaller.Free(intPtr);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
		}

		// Token: 0x060007D3 RID: 2003 RVA: 0x0001762A File Offset: 0x0001582A
		public PixbufAnimation(Stream stream) : base(new PixbufLoader(stream).AnimationHandle)
		{
		}

		// Token: 0x060007D4 RID: 2004 RVA: 0x0001763D File Offset: 0x0001583D
		public PixbufAnimation(Assembly assembly, string resource) : base(IntPtr.Zero)
		{
			if (assembly == null)
			{
				assembly = Assembly.GetCallingAssembly();
			}
			this.Raw = new PixbufLoader(assembly, resource).AnimationHandle;
		}

		// Token: 0x060007D5 RID: 2005 RVA: 0x0001766C File Offset: 0x0001586C
		public static PixbufAnimation LoadFromResource(string resource)
		{
			return new PixbufAnimation(Assembly.GetCallingAssembly(), resource);
		}

		// Token: 0x04000462 RID: 1122
		private static PixbufAnimation.d_gdk_pixbuf_animation_new_from_stream gdk_pixbuf_animation_new_from_stream = FuncLoader.LoadFunction<PixbufAnimation.d_gdk_pixbuf_animation_new_from_stream>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_animation_new_from_stream"));

		// Token: 0x04000463 RID: 1123
		private static PixbufAnimation.d_gdk_pixbuf_animation_new_from_stream_async gdk_pixbuf_animation_new_from_stream_async = FuncLoader.LoadFunction<PixbufAnimation.d_gdk_pixbuf_animation_new_from_stream_async>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_animation_new_from_stream_async"));

		// Token: 0x04000464 RID: 1124
		private static PixbufAnimation.d_gdk_pixbuf_animation_new_from_stream_finish gdk_pixbuf_animation_new_from_stream_finish = FuncLoader.LoadFunction<PixbufAnimation.d_gdk_pixbuf_animation_new_from_stream_finish>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_animation_new_from_stream_finish"));

		// Token: 0x04000465 RID: 1125
		private static PixbufAnimation.d_gdk_pixbuf_animation_get_height gdk_pixbuf_animation_get_height = FuncLoader.LoadFunction<PixbufAnimation.d_gdk_pixbuf_animation_get_height>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_animation_get_height"));

		// Token: 0x04000466 RID: 1126
		private static PixbufAnimation.d_gdk_pixbuf_animation_get_iter gdk_pixbuf_animation_get_iter = FuncLoader.LoadFunction<PixbufAnimation.d_gdk_pixbuf_animation_get_iter>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_animation_get_iter"));

		// Token: 0x04000467 RID: 1127
		private static PixbufAnimation.d_gdk_pixbuf_animation_get_static_image gdk_pixbuf_animation_get_static_image = FuncLoader.LoadFunction<PixbufAnimation.d_gdk_pixbuf_animation_get_static_image>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_animation_get_static_image"));

		// Token: 0x04000468 RID: 1128
		private static PixbufAnimation.d_gdk_pixbuf_animation_get_type gdk_pixbuf_animation_get_type = FuncLoader.LoadFunction<PixbufAnimation.d_gdk_pixbuf_animation_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_animation_get_type"));

		// Token: 0x04000469 RID: 1129
		private static PixbufAnimation.d_gdk_pixbuf_animation_get_width gdk_pixbuf_animation_get_width = FuncLoader.LoadFunction<PixbufAnimation.d_gdk_pixbuf_animation_get_width>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_animation_get_width"));

		// Token: 0x0400046A RID: 1130
		private static PixbufAnimation.d_gdk_pixbuf_animation_is_static_image gdk_pixbuf_animation_is_static_image = FuncLoader.LoadFunction<PixbufAnimation.d_gdk_pixbuf_animation_is_static_image>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_animation_is_static_image"));

		// Token: 0x0400046B RID: 1131
		private static PixbufAnimation.d_gdk_pixbuf_animation_new_from_file gdk_pixbuf_animation_new_from_file = FuncLoader.LoadFunction<PixbufAnimation.d_gdk_pixbuf_animation_new_from_file>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), FuncLoader.IsWindows ? "gdk_pixbuf_animation_new_from_file_utf8" : "gdk_pixbuf_animation_new_from_file"));

		// Token: 0x02000367 RID: 871
		// (Invoke) Token: 0x06001420 RID: 5152
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_animation_new_from_stream(IntPtr stream, IntPtr cancellable, out IntPtr error);

		// Token: 0x02000368 RID: 872
		// (Invoke) Token: 0x06001424 RID: 5156
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_animation_new_from_stream_async(IntPtr stream, IntPtr cancellable, AsyncReadyCallbackNative cb, IntPtr user_data);

		// Token: 0x02000369 RID: 873
		// (Invoke) Token: 0x06001428 RID: 5160
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_animation_new_from_stream_finish(IntPtr async_result, out IntPtr error);

		// Token: 0x0200036A RID: 874
		// (Invoke) Token: 0x0600142C RID: 5164
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_pixbuf_animation_get_height(IntPtr raw);

		// Token: 0x0200036B RID: 875
		// (Invoke) Token: 0x06001430 RID: 5168
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_animation_get_iter(IntPtr raw, IntPtr start_time);

		// Token: 0x0200036C RID: 876
		// (Invoke) Token: 0x06001434 RID: 5172
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_animation_get_static_image(IntPtr raw);

		// Token: 0x0200036D RID: 877
		// (Invoke) Token: 0x06001438 RID: 5176
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_animation_get_type();

		// Token: 0x0200036E RID: 878
		// (Invoke) Token: 0x0600143C RID: 5180
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_pixbuf_animation_get_width(IntPtr raw);

		// Token: 0x0200036F RID: 879
		// (Invoke) Token: 0x06001440 RID: 5184
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_animation_is_static_image(IntPtr raw);

		// Token: 0x02000370 RID: 880
		// (Invoke) Token: 0x06001444 RID: 5188
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_animation_new_from_file(IntPtr filename, out IntPtr error);
	}
}
