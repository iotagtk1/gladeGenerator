﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000D8 RID: 216
	internal class PixbufRotationGType
	{
		// Token: 0x1700022A RID: 554
		// (get) Token: 0x0600085B RID: 2139 RVA: 0x00018C99 File Offset: 0x00016E99
		public static GType GType
		{
			get
			{
				return new GType(PixbufRotationGType.gdk_pixbuf_rotation_get_type());
			}
		}

		// Token: 0x040004B6 RID: 1206
		private static PixbufRotationGType.d_gdk_pixbuf_rotation_get_type gdk_pixbuf_rotation_get_type = FuncLoader.LoadFunction<PixbufRotationGType.d_gdk_pixbuf_rotation_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_rotation_get_type"));

		// Token: 0x02000398 RID: 920
		// (Invoke) Token: 0x060014E2 RID: 5346
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_rotation_get_type();
	}
}
