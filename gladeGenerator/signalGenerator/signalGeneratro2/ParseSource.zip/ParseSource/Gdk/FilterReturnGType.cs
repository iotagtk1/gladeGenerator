﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000086 RID: 134
	internal class FilterReturnGType
	{
		// Token: 0x17000164 RID: 356
		// (get) Token: 0x0600057F RID: 1407 RVA: 0x00010AEF File Offset: 0x0000ECEF
		public static GType GType
		{
			get
			{
				return new GType(FilterReturnGType.gdk_filter_return_get_type());
			}
		}

		// Token: 0x040002F0 RID: 752
		private static FilterReturnGType.d_gdk_filter_return_get_type gdk_filter_return_get_type = FuncLoader.LoadFunction<FilterReturnGType.d_gdk_filter_return_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_filter_return_get_type"));

		// Token: 0x0200028B RID: 651
		// (Invoke) Token: 0x060010B3 RID: 4275
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_filter_return_get_type();
	}
}
