﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x0200006B RID: 107
	[GType(typeof(DragCancelReasonGType))]
	public enum DragCancelReason
	{
		// Token: 0x040001F1 RID: 497
		NoTarget,
		// Token: 0x040001F2 RID: 498
		UserCancelled,
		// Token: 0x040001F3 RID: 499
		Error
	}
}
