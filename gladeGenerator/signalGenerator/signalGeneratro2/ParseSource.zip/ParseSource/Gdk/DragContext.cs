﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200006D RID: 109
	public class DragContext : Object
	{
		// Token: 0x0600045F RID: 1119 RVA: 0x0000D65F File Offset: 0x0000B85F
		public DragContext(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000460 RID: 1120 RVA: 0x0000D668 File Offset: 0x0000B868
		protected DragContext() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x1400000D RID: 13
		// (add) Token: 0x06000461 RID: 1121 RVA: 0x0000D687 File Offset: 0x0000B887
		// (remove) Token: 0x06000462 RID: 1122 RVA: 0x0000D695 File Offset: 0x0000B895
		[Signal("dnd-finished")]
		public event EventHandler DndFinished
		{
			add
			{
				base.AddSignalHandler("dnd-finished", value);
			}
			remove
			{
				base.RemoveSignalHandler("dnd-finished", value);
			}
		}

		// Token: 0x1400000E RID: 14
		// (add) Token: 0x06000463 RID: 1123 RVA: 0x0000D6A3 File Offset: 0x0000B8A3
		// (remove) Token: 0x06000464 RID: 1124 RVA: 0x0000D6BB File Offset: 0x0000B8BB
		[Signal("drop-performed")]
		public event DropPerformedHandler DropPerformed
		{
			add
			{
				base.AddSignalHandler("drop-performed", value, typeof(DropPerformedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("drop-performed", value);
			}
		}

		// Token: 0x1400000F RID: 15
		// (add) Token: 0x06000465 RID: 1125 RVA: 0x0000D6C9 File Offset: 0x0000B8C9
		// (remove) Token: 0x06000466 RID: 1126 RVA: 0x0000D6E1 File Offset: 0x0000B8E1
		[Signal("cancel")]
		public event CancelHandler Cancel
		{
			add
			{
				base.AddSignalHandler("cancel", value, typeof(CancelArgs));
			}
			remove
			{
				base.RemoveSignalHandler("cancel", value);
			}
		}

		// Token: 0x14000010 RID: 16
		// (add) Token: 0x06000467 RID: 1127 RVA: 0x0000D6EF File Offset: 0x0000B8EF
		// (remove) Token: 0x06000468 RID: 1128 RVA: 0x0000D707 File Offset: 0x0000B907
		[Signal("action-changed")]
		public event ActionChangedHandler ActionChanged
		{
			add
			{
				base.AddSignalHandler("action-changed", value, typeof(ActionChangedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("action-changed", value);
			}
		}

		// Token: 0x17000128 RID: 296
		// (get) Token: 0x06000469 RID: 1129 RVA: 0x0000D715 File Offset: 0x0000B915
		private static DragContext.FindWindowNativeDelegate FindWindowVMCallback
		{
			get
			{
				if (DragContext.FindWindow_cb_delegate == null)
				{
					DragContext.FindWindow_cb_delegate = new DragContext.FindWindowNativeDelegate(DragContext.FindWindow_cb);
				}
				return DragContext.FindWindow_cb_delegate;
			}
		}

		// Token: 0x0600046A RID: 1130 RVA: 0x0000D734 File Offset: 0x0000B934
		private static void OverrideFindWindow(GType gtype)
		{
			DragContext.OverrideFindWindow(gtype, DragContext.FindWindowVMCallback);
		}

		// Token: 0x0600046B RID: 1131 RVA: 0x0000D744 File Offset: 0x0000B944
		private unsafe static void OverrideFindWindow(GType gtype, DragContext.FindWindowNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("find_window");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600046C RID: 1132 RVA: 0x0000D778 File Offset: 0x0000B978
		private static IntPtr FindWindow_cb(IntPtr inst, IntPtr drag_window, IntPtr screen, int x_root, int y_root, out int protocol)
		{
			IntPtr result;
			try
			{
				DragProtocol dragProtocol;
				Window window = (Object.GetObject(inst, false) as DragContext).OnFindWindow(Object.GetObject(drag_window) as Window, Object.GetObject(screen) as Screen, x_root, y_root, out dragProtocol);
				protocol = (int)dragProtocol;
				result = ((window == null) ? IntPtr.Zero : window.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600046D RID: 1133 RVA: 0x0000D7E4 File Offset: 0x0000B9E4
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideFindWindow")]
		protected virtual Window OnFindWindow(Window drag_window, Screen screen, int x_root, int y_root, out DragProtocol protocol)
		{
			return this.InternalFindWindow(drag_window, screen, x_root, y_root, out protocol);
		}

		// Token: 0x0600046E RID: 1134 RVA: 0x0000D7F4 File Offset: 0x0000B9F4
		private Window InternalFindWindow(Window drag_window, Screen screen, int x_root, int y_root, out DragProtocol protocol)
		{
			DragContext.FindWindowNativeDelegate findWindowNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "find_window");
			if (findWindowNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			int num;
			IntPtr o = findWindowNativeDelegate(base.Handle, (drag_window == null) ? IntPtr.Zero : drag_window.Handle, (screen == null) ? IntPtr.Zero : screen.Handle, x_root, y_root, out num);
			protocol = (DragProtocol)num;
			return Object.GetObject(o) as Window;
		}

		// Token: 0x17000129 RID: 297
		// (get) Token: 0x0600046F RID: 1135 RVA: 0x0000D862 File Offset: 0x0000BA62
		private static DragContext.GetSelectionNativeDelegate GetSelectionVMCallback
		{
			get
			{
				if (DragContext.GetSelection_cb_delegate == null)
				{
					DragContext.GetSelection_cb_delegate = new DragContext.GetSelectionNativeDelegate(DragContext.GetSelection_cb);
				}
				return DragContext.GetSelection_cb_delegate;
			}
		}

		// Token: 0x06000470 RID: 1136 RVA: 0x0000D881 File Offset: 0x0000BA81
		private static void OverrideGetSelection(GType gtype)
		{
			DragContext.OverrideGetSelection(gtype, DragContext.GetSelectionVMCallback);
		}

		// Token: 0x06000471 RID: 1137 RVA: 0x0000D890 File Offset: 0x0000BA90
		private unsafe static void OverrideGetSelection(GType gtype, DragContext.GetSelectionNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("get_selection");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000472 RID: 1138 RVA: 0x0000D8C4 File Offset: 0x0000BAC4
		private static IntPtr GetSelection_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				Atom atom = (Object.GetObject(inst, false) as DragContext).OnGetSelection();
				result = ((atom == null) ? IntPtr.Zero : atom.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000473 RID: 1139 RVA: 0x0000D910 File Offset: 0x0000BB10
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideGetSelection")]
		protected virtual Atom OnGetSelection()
		{
			return this.InternalGetSelection();
		}

		// Token: 0x06000474 RID: 1140 RVA: 0x0000D918 File Offset: 0x0000BB18
		private Atom InternalGetSelection()
		{
			DragContext.GetSelectionNativeDelegate getSelectionNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "get_selection");
			if (getSelectionNativeDelegate == null)
			{
				return null;
			}
			IntPtr intPtr = getSelectionNativeDelegate(base.Handle);
			if (!(intPtr == IntPtr.Zero))
			{
				return (Atom)Opaque.GetOpaque(intPtr, typeof(Atom), false);
			}
			return null;
		}

		// Token: 0x1700012A RID: 298
		// (get) Token: 0x06000475 RID: 1141 RVA: 0x0000D972 File Offset: 0x0000BB72
		private static DragContext.DragMotionNativeDelegate DragMotionVMCallback
		{
			get
			{
				if (DragContext.DragMotion_cb_delegate == null)
				{
					DragContext.DragMotion_cb_delegate = new DragContext.DragMotionNativeDelegate(DragContext.DragMotion_cb);
				}
				return DragContext.DragMotion_cb_delegate;
			}
		}

		// Token: 0x06000476 RID: 1142 RVA: 0x0000D991 File Offset: 0x0000BB91
		private static void OverrideDragMotion(GType gtype)
		{
			DragContext.OverrideDragMotion(gtype, DragContext.DragMotionVMCallback);
		}

		// Token: 0x06000477 RID: 1143 RVA: 0x0000D9A0 File Offset: 0x0000BBA0
		private unsafe static void OverrideDragMotion(GType gtype, DragContext.DragMotionNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("drag_motion");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000478 RID: 1144 RVA: 0x0000D9D4 File Offset: 0x0000BBD4
		private static bool DragMotion_cb(IntPtr inst, IntPtr dest_window, int protocol, int root_x, int root_y, int suggested_action, int possible_actions, uint time_)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as DragContext).OnDragMotion(Object.GetObject(dest_window) as Window, (DragProtocol)protocol, root_x, root_y, (DragAction)suggested_action, (DragAction)possible_actions, time_);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000479 RID: 1145 RVA: 0x0000DA24 File Offset: 0x0000BC24
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideDragMotion")]
		protected virtual bool OnDragMotion(Window dest_window, DragProtocol protocol, int root_x, int root_y, DragAction suggested_action, DragAction possible_actions, uint time_)
		{
			return this.InternalDragMotion(dest_window, protocol, root_x, root_y, suggested_action, possible_actions, time_);
		}

		// Token: 0x0600047A RID: 1146 RVA: 0x0000DA38 File Offset: 0x0000BC38
		private bool InternalDragMotion(Window dest_window, DragProtocol protocol, int root_x, int root_y, DragAction suggested_action, DragAction possible_actions, uint time_)
		{
			DragContext.DragMotionNativeDelegate dragMotionNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "drag_motion");
			return dragMotionNativeDelegate != null && dragMotionNativeDelegate(base.Handle, (dest_window == null) ? IntPtr.Zero : dest_window.Handle, (int)protocol, root_x, root_y, (int)suggested_action, (int)possible_actions, time_);
		}

		// Token: 0x1700012B RID: 299
		// (get) Token: 0x0600047B RID: 1147 RVA: 0x0000DA86 File Offset: 0x0000BC86
		private static DragContext.DragStatusNativeDelegate DragStatusVMCallback
		{
			get
			{
				if (DragContext.DragStatus_cb_delegate == null)
				{
					DragContext.DragStatus_cb_delegate = new DragContext.DragStatusNativeDelegate(DragContext.DragStatus_cb);
				}
				return DragContext.DragStatus_cb_delegate;
			}
		}

		// Token: 0x0600047C RID: 1148 RVA: 0x0000DAA5 File Offset: 0x0000BCA5
		private static void OverrideDragStatus(GType gtype)
		{
			DragContext.OverrideDragStatus(gtype, DragContext.DragStatusVMCallback);
		}

		// Token: 0x0600047D RID: 1149 RVA: 0x0000DAB4 File Offset: 0x0000BCB4
		private unsafe static void OverrideDragStatus(GType gtype, DragContext.DragStatusNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("drag_status");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600047E RID: 1150 RVA: 0x0000DAE8 File Offset: 0x0000BCE8
		private static void DragStatus_cb(IntPtr inst, int action, uint time_)
		{
			try
			{
				(Object.GetObject(inst, false) as DragContext).OnDragStatus((DragAction)action, time_);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x0600047F RID: 1151 RVA: 0x0000DB24 File Offset: 0x0000BD24
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideDragStatus")]
		protected virtual void OnDragStatus(DragAction action, uint time_)
		{
			this.InternalDragStatus(action, time_);
		}

		// Token: 0x06000480 RID: 1152 RVA: 0x0000DB30 File Offset: 0x0000BD30
		private void InternalDragStatus(DragAction action, uint time_)
		{
			DragContext.DragStatusNativeDelegate dragStatusNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "drag_status");
			if (dragStatusNativeDelegate == null)
			{
				return;
			}
			dragStatusNativeDelegate(base.Handle, (int)action, time_);
		}

		// Token: 0x1700012C RID: 300
		// (get) Token: 0x06000481 RID: 1153 RVA: 0x0000DB65 File Offset: 0x0000BD65
		private static DragContext.DragAbortNativeDelegate DragAbortVMCallback
		{
			get
			{
				if (DragContext.DragAbort_cb_delegate == null)
				{
					DragContext.DragAbort_cb_delegate = new DragContext.DragAbortNativeDelegate(DragContext.DragAbort_cb);
				}
				return DragContext.DragAbort_cb_delegate;
			}
		}

		// Token: 0x06000482 RID: 1154 RVA: 0x0000DB84 File Offset: 0x0000BD84
		private static void OverrideDragAbort(GType gtype)
		{
			DragContext.OverrideDragAbort(gtype, DragContext.DragAbortVMCallback);
		}

		// Token: 0x06000483 RID: 1155 RVA: 0x0000DB94 File Offset: 0x0000BD94
		private unsafe static void OverrideDragAbort(GType gtype, DragContext.DragAbortNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("drag_abort");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000484 RID: 1156 RVA: 0x0000DBC8 File Offset: 0x0000BDC8
		private static void DragAbort_cb(IntPtr inst, uint time_)
		{
			try
			{
				(Object.GetObject(inst, false) as DragContext).OnDragAbort(time_);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000485 RID: 1157 RVA: 0x0000DC04 File Offset: 0x0000BE04
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideDragAbort")]
		protected virtual void OnDragAbort(uint time_)
		{
			this.InternalDragAbort(time_);
		}

		// Token: 0x06000486 RID: 1158 RVA: 0x0000DC10 File Offset: 0x0000BE10
		private void InternalDragAbort(uint time_)
		{
			DragContext.DragAbortNativeDelegate dragAbortNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "drag_abort");
			if (dragAbortNativeDelegate == null)
			{
				return;
			}
			dragAbortNativeDelegate(base.Handle, time_);
		}

		// Token: 0x1700012D RID: 301
		// (get) Token: 0x06000487 RID: 1159 RVA: 0x0000DC44 File Offset: 0x0000BE44
		private static DragContext.DragDropNativeDelegate DragDropVMCallback
		{
			get
			{
				if (DragContext.DragDrop_cb_delegate == null)
				{
					DragContext.DragDrop_cb_delegate = new DragContext.DragDropNativeDelegate(DragContext.DragDrop_cb);
				}
				return DragContext.DragDrop_cb_delegate;
			}
		}

		// Token: 0x06000488 RID: 1160 RVA: 0x0000DC63 File Offset: 0x0000BE63
		private static void OverrideDragDrop(GType gtype)
		{
			DragContext.OverrideDragDrop(gtype, DragContext.DragDropVMCallback);
		}

		// Token: 0x06000489 RID: 1161 RVA: 0x0000DC70 File Offset: 0x0000BE70
		private unsafe static void OverrideDragDrop(GType gtype, DragContext.DragDropNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("drag_drop");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600048A RID: 1162 RVA: 0x0000DCA4 File Offset: 0x0000BEA4
		private static void DragDrop_cb(IntPtr inst, uint time_)
		{
			try
			{
				(Object.GetObject(inst, false) as DragContext).OnDragDrop(time_);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x0600048B RID: 1163 RVA: 0x0000DCE0 File Offset: 0x0000BEE0
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideDragDrop")]
		protected virtual void OnDragDrop(uint time_)
		{
			this.InternalDragDrop(time_);
		}

		// Token: 0x0600048C RID: 1164 RVA: 0x0000DCEC File Offset: 0x0000BEEC
		private void InternalDragDrop(uint time_)
		{
			DragContext.DragDropNativeDelegate dragDropNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "drag_drop");
			if (dragDropNativeDelegate == null)
			{
				return;
			}
			dragDropNativeDelegate(base.Handle, time_);
		}

		// Token: 0x1700012E RID: 302
		// (get) Token: 0x0600048D RID: 1165 RVA: 0x0000DD20 File Offset: 0x0000BF20
		private static DragContext.DropReplyNativeDelegate DropReplyVMCallback
		{
			get
			{
				if (DragContext.DropReply_cb_delegate == null)
				{
					DragContext.DropReply_cb_delegate = new DragContext.DropReplyNativeDelegate(DragContext.DropReply_cb);
				}
				return DragContext.DropReply_cb_delegate;
			}
		}

		// Token: 0x0600048E RID: 1166 RVA: 0x0000DD3F File Offset: 0x0000BF3F
		private static void OverrideDropReply(GType gtype)
		{
			DragContext.OverrideDropReply(gtype, DragContext.DropReplyVMCallback);
		}

		// Token: 0x0600048F RID: 1167 RVA: 0x0000DD4C File Offset: 0x0000BF4C
		private unsafe static void OverrideDropReply(GType gtype, DragContext.DropReplyNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("drop_reply");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000490 RID: 1168 RVA: 0x0000DD80 File Offset: 0x0000BF80
		private static void DropReply_cb(IntPtr inst, bool accept, uint time_)
		{
			try
			{
				(Object.GetObject(inst, false) as DragContext).OnDropReply(accept, time_);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000491 RID: 1169 RVA: 0x0000DDBC File Offset: 0x0000BFBC
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideDropReply")]
		protected virtual void OnDropReply(bool accept, uint time_)
		{
			this.InternalDropReply(accept, time_);
		}

		// Token: 0x06000492 RID: 1170 RVA: 0x0000DDC8 File Offset: 0x0000BFC8
		private void InternalDropReply(bool accept, uint time_)
		{
			DragContext.DropReplyNativeDelegate dropReplyNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "drop_reply");
			if (dropReplyNativeDelegate == null)
			{
				return;
			}
			dropReplyNativeDelegate(base.Handle, accept, time_);
		}

		// Token: 0x1700012F RID: 303
		// (get) Token: 0x06000493 RID: 1171 RVA: 0x0000DDFD File Offset: 0x0000BFFD
		private static DragContext.DropFinishNativeDelegate DropFinishVMCallback
		{
			get
			{
				if (DragContext.DropFinish_cb_delegate == null)
				{
					DragContext.DropFinish_cb_delegate = new DragContext.DropFinishNativeDelegate(DragContext.DropFinish_cb);
				}
				return DragContext.DropFinish_cb_delegate;
			}
		}

		// Token: 0x06000494 RID: 1172 RVA: 0x0000DE1C File Offset: 0x0000C01C
		private static void OverrideDropFinish(GType gtype)
		{
			DragContext.OverrideDropFinish(gtype, DragContext.DropFinishVMCallback);
		}

		// Token: 0x06000495 RID: 1173 RVA: 0x0000DE2C File Offset: 0x0000C02C
		private unsafe static void OverrideDropFinish(GType gtype, DragContext.DropFinishNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("drop_finish");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000496 RID: 1174 RVA: 0x0000DE60 File Offset: 0x0000C060
		private static void DropFinish_cb(IntPtr inst, bool success, uint time_)
		{
			try
			{
				(Object.GetObject(inst, false) as DragContext).OnDropFinish(success, time_);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000497 RID: 1175 RVA: 0x0000DE9C File Offset: 0x0000C09C
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideDropFinish")]
		protected virtual void OnDropFinish(bool success, uint time_)
		{
			this.InternalDropFinish(success, time_);
		}

		// Token: 0x06000498 RID: 1176 RVA: 0x0000DEA8 File Offset: 0x0000C0A8
		private void InternalDropFinish(bool success, uint time_)
		{
			DragContext.DropFinishNativeDelegate dropFinishNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "drop_finish");
			if (dropFinishNativeDelegate == null)
			{
				return;
			}
			dropFinishNativeDelegate(base.Handle, success, time_);
		}

		// Token: 0x17000130 RID: 304
		// (get) Token: 0x06000499 RID: 1177 RVA: 0x0000DEDD File Offset: 0x0000C0DD
		private static DragContext.DropStatusNativeDelegate DropStatusVMCallback
		{
			get
			{
				if (DragContext.DropStatus_cb_delegate == null)
				{
					DragContext.DropStatus_cb_delegate = new DragContext.DropStatusNativeDelegate(DragContext.DropStatus_cb);
				}
				return DragContext.DropStatus_cb_delegate;
			}
		}

		// Token: 0x0600049A RID: 1178 RVA: 0x0000DEFC File Offset: 0x0000C0FC
		private static void OverrideDropStatus(GType gtype)
		{
			DragContext.OverrideDropStatus(gtype, DragContext.DropStatusVMCallback);
		}

		// Token: 0x0600049B RID: 1179 RVA: 0x0000DF0C File Offset: 0x0000C10C
		private unsafe static void OverrideDropStatus(GType gtype, DragContext.DropStatusNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("drop_status");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600049C RID: 1180 RVA: 0x0000DF40 File Offset: 0x0000C140
		private static bool DropStatus_cb(IntPtr inst)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as DragContext).OnDropStatus();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600049D RID: 1181 RVA: 0x0000DF7C File Offset: 0x0000C17C
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideDropStatus")]
		protected virtual bool OnDropStatus()
		{
			return this.InternalDropStatus();
		}

		// Token: 0x0600049E RID: 1182 RVA: 0x0000DF84 File Offset: 0x0000C184
		private bool InternalDropStatus()
		{
			DragContext.DropStatusNativeDelegate dropStatusNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "drop_status");
			return dropStatusNativeDelegate != null && dropStatusNativeDelegate(base.Handle);
		}

		// Token: 0x17000131 RID: 305
		// (get) Token: 0x0600049F RID: 1183 RVA: 0x0000DFB8 File Offset: 0x0000C1B8
		private static DragContext.GetDragWindowNativeDelegate GetDragWindowVMCallback
		{
			get
			{
				if (DragContext.GetDragWindow_cb_delegate == null)
				{
					DragContext.GetDragWindow_cb_delegate = new DragContext.GetDragWindowNativeDelegate(DragContext.GetDragWindow_cb);
				}
				return DragContext.GetDragWindow_cb_delegate;
			}
		}

		// Token: 0x060004A0 RID: 1184 RVA: 0x0000DFD7 File Offset: 0x0000C1D7
		private static void OverrideGetDragWindow(GType gtype)
		{
			DragContext.OverrideGetDragWindow(gtype, DragContext.GetDragWindowVMCallback);
		}

		// Token: 0x060004A1 RID: 1185 RVA: 0x0000DFE4 File Offset: 0x0000C1E4
		private unsafe static void OverrideGetDragWindow(GType gtype, DragContext.GetDragWindowNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("get_drag_window");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060004A2 RID: 1186 RVA: 0x0000E018 File Offset: 0x0000C218
		private static IntPtr GetDragWindow_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				Window window = (Object.GetObject(inst, false) as DragContext).OnGetDragWindow();
				result = ((window == null) ? IntPtr.Zero : window.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060004A3 RID: 1187 RVA: 0x0000E064 File Offset: 0x0000C264
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideGetDragWindow")]
		protected virtual Window OnGetDragWindow()
		{
			return this.InternalGetDragWindow();
		}

		// Token: 0x060004A4 RID: 1188 RVA: 0x0000E06C File Offset: 0x0000C26C
		private Window InternalGetDragWindow()
		{
			DragContext.GetDragWindowNativeDelegate getDragWindowNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "get_drag_window");
			if (getDragWindowNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getDragWindowNativeDelegate(base.Handle)) as Window;
		}

		// Token: 0x17000132 RID: 306
		// (get) Token: 0x060004A5 RID: 1189 RVA: 0x0000E0AA File Offset: 0x0000C2AA
		private static DragContext.SetHotspotNativeDelegate SetHotspotVMCallback
		{
			get
			{
				if (DragContext.SetHotspot_cb_delegate == null)
				{
					DragContext.SetHotspot_cb_delegate = new DragContext.SetHotspotNativeDelegate(DragContext.SetHotspot_cb);
				}
				return DragContext.SetHotspot_cb_delegate;
			}
		}

		// Token: 0x060004A6 RID: 1190 RVA: 0x0000E0C9 File Offset: 0x0000C2C9
		private static void OverrideSetHotspot(GType gtype)
		{
			DragContext.OverrideSetHotspot(gtype, DragContext.SetHotspotVMCallback);
		}

		// Token: 0x060004A7 RID: 1191 RVA: 0x0000E0D8 File Offset: 0x0000C2D8
		private unsafe static void OverrideSetHotspot(GType gtype, DragContext.SetHotspotNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("set_hotspot");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060004A8 RID: 1192 RVA: 0x0000E10C File Offset: 0x0000C30C
		private static void SetHotspot_cb(IntPtr inst, int hot_x, int hot_y)
		{
			try
			{
				(Object.GetObject(inst, false) as DragContext).OnSetHotspot(hot_x, hot_y);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060004A9 RID: 1193 RVA: 0x0000E148 File Offset: 0x0000C348
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideSetHotspot")]
		protected virtual void OnSetHotspot(int hot_x, int hot_y)
		{
			this.InternalSetHotspot(hot_x, hot_y);
		}

		// Token: 0x060004AA RID: 1194 RVA: 0x0000E154 File Offset: 0x0000C354
		private void InternalSetHotspot(int hot_x, int hot_y)
		{
			DragContext.SetHotspotNativeDelegate setHotspotNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "set_hotspot");
			if (setHotspotNativeDelegate == null)
			{
				return;
			}
			setHotspotNativeDelegate(base.Handle, hot_x, hot_y);
		}

		// Token: 0x17000133 RID: 307
		// (get) Token: 0x060004AB RID: 1195 RVA: 0x0000E189 File Offset: 0x0000C389
		private static DragContext.DropDoneNativeDelegate DropDoneVMCallback
		{
			get
			{
				if (DragContext.DropDone_cb_delegate == null)
				{
					DragContext.DropDone_cb_delegate = new DragContext.DropDoneNativeDelegate(DragContext.DropDone_cb);
				}
				return DragContext.DropDone_cb_delegate;
			}
		}

		// Token: 0x060004AC RID: 1196 RVA: 0x0000E1A8 File Offset: 0x0000C3A8
		private static void OverrideDropDone(GType gtype)
		{
			DragContext.OverrideDropDone(gtype, DragContext.DropDoneVMCallback);
		}

		// Token: 0x060004AD RID: 1197 RVA: 0x0000E1B8 File Offset: 0x0000C3B8
		private unsafe static void OverrideDropDone(GType gtype, DragContext.DropDoneNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("drop_done");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060004AE RID: 1198 RVA: 0x0000E1EC File Offset: 0x0000C3EC
		private static void DropDone_cb(IntPtr inst, bool success)
		{
			try
			{
				(Object.GetObject(inst, false) as DragContext).OnDropDone(success);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060004AF RID: 1199 RVA: 0x0000E228 File Offset: 0x0000C428
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideDropDone")]
		protected virtual void OnDropDone(bool success)
		{
			this.InternalDropDone(success);
		}

		// Token: 0x060004B0 RID: 1200 RVA: 0x0000E234 File Offset: 0x0000C434
		private void InternalDropDone(bool success)
		{
			DragContext.DropDoneNativeDelegate dropDoneNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "drop_done");
			if (dropDoneNativeDelegate == null)
			{
				return;
			}
			dropDoneNativeDelegate(base.Handle, success);
		}

		// Token: 0x17000134 RID: 308
		// (get) Token: 0x060004B1 RID: 1201 RVA: 0x0000E268 File Offset: 0x0000C468
		private static DragContext.ManageDndNativeDelegate ManageDndVMCallback
		{
			get
			{
				if (DragContext.ManageDnd_cb_delegate == null)
				{
					DragContext.ManageDnd_cb_delegate = new DragContext.ManageDndNativeDelegate(DragContext.ManageDnd_cb);
				}
				return DragContext.ManageDnd_cb_delegate;
			}
		}

		// Token: 0x060004B2 RID: 1202 RVA: 0x0000E287 File Offset: 0x0000C487
		private static void OverrideManageDnd(GType gtype)
		{
			DragContext.OverrideManageDnd(gtype, DragContext.ManageDndVMCallback);
		}

		// Token: 0x060004B3 RID: 1203 RVA: 0x0000E294 File Offset: 0x0000C494
		private unsafe static void OverrideManageDnd(GType gtype, DragContext.ManageDndNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("manage_dnd");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060004B4 RID: 1204 RVA: 0x0000E2C8 File Offset: 0x0000C4C8
		private static bool ManageDnd_cb(IntPtr inst, IntPtr ipc_window, int actions)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as DragContext).OnManageDnd(Object.GetObject(ipc_window) as Window, (DragAction)actions);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060004B5 RID: 1205 RVA: 0x0000E310 File Offset: 0x0000C510
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideManageDnd")]
		protected virtual bool OnManageDnd(Window ipc_window, DragAction actions)
		{
			return this.InternalManageDnd(ipc_window, actions);
		}

		// Token: 0x060004B6 RID: 1206 RVA: 0x0000E31C File Offset: 0x0000C51C
		private bool InternalManageDnd(Window ipc_window, DragAction actions)
		{
			DragContext.ManageDndNativeDelegate manageDndNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "manage_dnd");
			return manageDndNativeDelegate != null && manageDndNativeDelegate(base.Handle, (ipc_window == null) ? IntPtr.Zero : ipc_window.Handle, (int)actions);
		}

		// Token: 0x17000135 RID: 309
		// (get) Token: 0x060004B7 RID: 1207 RVA: 0x0000E361 File Offset: 0x0000C561
		private static DragContext.SetCursorNativeDelegate SetCursorVMCallback
		{
			get
			{
				if (DragContext.SetCursor_cb_delegate == null)
				{
					DragContext.SetCursor_cb_delegate = new DragContext.SetCursorNativeDelegate(DragContext.SetCursor_cb);
				}
				return DragContext.SetCursor_cb_delegate;
			}
		}

		// Token: 0x060004B8 RID: 1208 RVA: 0x0000E380 File Offset: 0x0000C580
		private static void OverrideSetCursor(GType gtype)
		{
			DragContext.OverrideSetCursor(gtype, DragContext.SetCursorVMCallback);
		}

		// Token: 0x060004B9 RID: 1209 RVA: 0x0000E390 File Offset: 0x0000C590
		private unsafe static void OverrideSetCursor(GType gtype, DragContext.SetCursorNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("set_cursor");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060004BA RID: 1210 RVA: 0x0000E3C4 File Offset: 0x0000C5C4
		private static void SetCursor_cb(IntPtr inst, IntPtr cursor)
		{
			try
			{
				(Object.GetObject(inst, false) as DragContext).OnSetCursor(Object.GetObject(cursor) as Cursor);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060004BB RID: 1211 RVA: 0x0000E408 File Offset: 0x0000C608
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideSetCursor")]
		protected virtual void OnSetCursor(Cursor cursor)
		{
			this.InternalSetCursor(cursor);
		}

		// Token: 0x060004BC RID: 1212 RVA: 0x0000E414 File Offset: 0x0000C614
		private void InternalSetCursor(Cursor cursor)
		{
			DragContext.SetCursorNativeDelegate setCursorNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "set_cursor");
			if (setCursorNativeDelegate == null)
			{
				return;
			}
			setCursorNativeDelegate(base.Handle, (cursor == null) ? IntPtr.Zero : cursor.Handle);
		}

		// Token: 0x17000136 RID: 310
		// (get) Token: 0x060004BD RID: 1213 RVA: 0x0000E457 File Offset: 0x0000C657
		private static DragContext.CancelNativeDelegate CancelVMCallback
		{
			get
			{
				if (DragContext.Cancel_cb_delegate == null)
				{
					DragContext.Cancel_cb_delegate = new DragContext.CancelNativeDelegate(DragContext.Cancel_cb);
				}
				return DragContext.Cancel_cb_delegate;
			}
		}

		// Token: 0x060004BE RID: 1214 RVA: 0x0000E476 File Offset: 0x0000C676
		private static void OverrideCancel(GType gtype)
		{
			DragContext.OverrideCancel(gtype, DragContext.CancelVMCallback);
		}

		// Token: 0x060004BF RID: 1215 RVA: 0x0000E484 File Offset: 0x0000C684
		private unsafe static void OverrideCancel(GType gtype, DragContext.CancelNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("cancel");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060004C0 RID: 1216 RVA: 0x0000E4B8 File Offset: 0x0000C6B8
		private static void Cancel_cb(IntPtr inst, int reason)
		{
			try
			{
				(Object.GetObject(inst, false) as DragContext).OnCancel((DragCancelReason)reason);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060004C1 RID: 1217 RVA: 0x0000E4F4 File Offset: 0x0000C6F4
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideCancel")]
		protected virtual void OnCancel(DragCancelReason reason)
		{
			this.InternalCancel(reason);
		}

		// Token: 0x060004C2 RID: 1218 RVA: 0x0000E500 File Offset: 0x0000C700
		private void InternalCancel(DragCancelReason reason)
		{
			DragContext.CancelNativeDelegate cancelNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "cancel");
			if (cancelNativeDelegate == null)
			{
				return;
			}
			cancelNativeDelegate(base.Handle, (int)reason);
		}

		// Token: 0x17000137 RID: 311
		// (get) Token: 0x060004C3 RID: 1219 RVA: 0x0000E534 File Offset: 0x0000C734
		private static DragContext.DropPerformedNativeDelegate DropPerformedVMCallback
		{
			get
			{
				if (DragContext.DropPerformed_cb_delegate == null)
				{
					DragContext.DropPerformed_cb_delegate = new DragContext.DropPerformedNativeDelegate(DragContext.DropPerformed_cb);
				}
				return DragContext.DropPerformed_cb_delegate;
			}
		}

		// Token: 0x060004C4 RID: 1220 RVA: 0x0000E553 File Offset: 0x0000C753
		private static void OverrideDropPerformed(GType gtype)
		{
			DragContext.OverrideDropPerformed(gtype, DragContext.DropPerformedVMCallback);
		}

		// Token: 0x060004C5 RID: 1221 RVA: 0x0000E560 File Offset: 0x0000C760
		private unsafe static void OverrideDropPerformed(GType gtype, DragContext.DropPerformedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("drop_performed");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060004C6 RID: 1222 RVA: 0x0000E594 File Offset: 0x0000C794
		private static void DropPerformed_cb(IntPtr inst, uint time)
		{
			try
			{
				(Object.GetObject(inst, false) as DragContext).OnDropPerformed(time);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060004C7 RID: 1223 RVA: 0x0000E5D0 File Offset: 0x0000C7D0
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideDropPerformed")]
		protected virtual void OnDropPerformed(uint time)
		{
			this.InternalDropPerformed(time);
		}

		// Token: 0x060004C8 RID: 1224 RVA: 0x0000E5DC File Offset: 0x0000C7DC
		private void InternalDropPerformed(uint time)
		{
			DragContext.DropPerformedNativeDelegate dropPerformedNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "drop_performed");
			if (dropPerformedNativeDelegate == null)
			{
				return;
			}
			dropPerformedNativeDelegate(base.Handle, time);
		}

		// Token: 0x17000138 RID: 312
		// (get) Token: 0x060004C9 RID: 1225 RVA: 0x0000E610 File Offset: 0x0000C810
		private static DragContext.DndFinishedNativeDelegate DndFinishedVMCallback
		{
			get
			{
				if (DragContext.DndFinished_cb_delegate == null)
				{
					DragContext.DndFinished_cb_delegate = new DragContext.DndFinishedNativeDelegate(DragContext.DndFinished_cb);
				}
				return DragContext.DndFinished_cb_delegate;
			}
		}

		// Token: 0x060004CA RID: 1226 RVA: 0x0000E62F File Offset: 0x0000C82F
		private static void OverrideDndFinished(GType gtype)
		{
			DragContext.OverrideDndFinished(gtype, DragContext.DndFinishedVMCallback);
		}

		// Token: 0x060004CB RID: 1227 RVA: 0x0000E63C File Offset: 0x0000C83C
		private unsafe static void OverrideDndFinished(GType gtype, DragContext.DndFinishedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("dnd_finished");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060004CC RID: 1228 RVA: 0x0000E670 File Offset: 0x0000C870
		private static void DndFinished_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as DragContext).OnDndFinished();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060004CD RID: 1229 RVA: 0x0000E6A8 File Offset: 0x0000C8A8
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideDndFinished")]
		protected virtual void OnDndFinished()
		{
			this.InternalDndFinished();
		}

		// Token: 0x060004CE RID: 1230 RVA: 0x0000E6B0 File Offset: 0x0000C8B0
		private void InternalDndFinished()
		{
			DragContext.DndFinishedNativeDelegate dndFinishedNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "dnd_finished");
			if (dndFinishedNativeDelegate == null)
			{
				return;
			}
			dndFinishedNativeDelegate(base.Handle);
		}

		// Token: 0x17000139 RID: 313
		// (get) Token: 0x060004CF RID: 1231 RVA: 0x0000E6E3 File Offset: 0x0000C8E3
		private static DragContext.HandleEventNativeDelegate HandleEventVMCallback
		{
			get
			{
				if (DragContext.HandleEvent_cb_delegate == null)
				{
					DragContext.HandleEvent_cb_delegate = new DragContext.HandleEventNativeDelegate(DragContext.HandleEvent_cb);
				}
				return DragContext.HandleEvent_cb_delegate;
			}
		}

		// Token: 0x060004D0 RID: 1232 RVA: 0x0000E702 File Offset: 0x0000C902
		private static void OverrideHandleEvent(GType gtype)
		{
			DragContext.OverrideHandleEvent(gtype, DragContext.HandleEventVMCallback);
		}

		// Token: 0x060004D1 RID: 1233 RVA: 0x0000E710 File Offset: 0x0000C910
		private unsafe static void OverrideHandleEvent(GType gtype, DragContext.HandleEventNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("handle_event");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060004D2 RID: 1234 RVA: 0x0000E744 File Offset: 0x0000C944
		private static bool HandleEvent_cb(IntPtr inst, IntPtr evnt)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as DragContext).OnHandleEvent(Event.GetEvent(evnt));
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060004D3 RID: 1235 RVA: 0x0000E784 File Offset: 0x0000C984
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideHandleEvent")]
		protected virtual bool OnHandleEvent(Event evnt)
		{
			return this.InternalHandleEvent(evnt);
		}

		// Token: 0x060004D4 RID: 1236 RVA: 0x0000E790 File Offset: 0x0000C990
		private bool InternalHandleEvent(Event evnt)
		{
			DragContext.HandleEventNativeDelegate handleEventNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "handle_event");
			return handleEventNativeDelegate != null && handleEventNativeDelegate(base.Handle, (evnt == null) ? IntPtr.Zero : evnt.Handle);
		}

		// Token: 0x1700013A RID: 314
		// (get) Token: 0x060004D5 RID: 1237 RVA: 0x0000E7D4 File Offset: 0x0000C9D4
		private static DragContext.ActionChangedNativeDelegate ActionChangedVMCallback
		{
			get
			{
				if (DragContext.ActionChanged_cb_delegate == null)
				{
					DragContext.ActionChanged_cb_delegate = new DragContext.ActionChangedNativeDelegate(DragContext.ActionChanged_cb);
				}
				return DragContext.ActionChanged_cb_delegate;
			}
		}

		// Token: 0x060004D6 RID: 1238 RVA: 0x0000E7F3 File Offset: 0x0000C9F3
		private static void OverrideActionChanged(GType gtype)
		{
			DragContext.OverrideActionChanged(gtype, DragContext.ActionChangedVMCallback);
		}

		// Token: 0x060004D7 RID: 1239 RVA: 0x0000E800 File Offset: 0x0000CA00
		private unsafe static void OverrideActionChanged(GType gtype, DragContext.ActionChangedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("action_changed");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060004D8 RID: 1240 RVA: 0x0000E834 File Offset: 0x0000CA34
		private static void ActionChanged_cb(IntPtr inst, int action)
		{
			try
			{
				(Object.GetObject(inst, false) as DragContext).OnActionChanged((DragAction)action);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060004D9 RID: 1241 RVA: 0x0000E870 File Offset: 0x0000CA70
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideActionChanged")]
		protected virtual void OnActionChanged(DragAction action)
		{
			this.InternalActionChanged(action);
		}

		// Token: 0x060004DA RID: 1242 RVA: 0x0000E87C File Offset: 0x0000CA7C
		private void InternalActionChanged(DragAction action)
		{
			DragContext.ActionChangedNativeDelegate actionChangedNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "action_changed");
			if (actionChangedNativeDelegate == null)
			{
				return;
			}
			actionChangedNativeDelegate(base.Handle, (int)action);
		}

		// Token: 0x1700013B RID: 315
		// (get) Token: 0x060004DB RID: 1243 RVA: 0x0000E8B0 File Offset: 0x0000CAB0
		private static DragContext.CommitDragStatusNativeDelegate CommitDragStatusVMCallback
		{
			get
			{
				if (DragContext.CommitDragStatus_cb_delegate == null)
				{
					DragContext.CommitDragStatus_cb_delegate = new DragContext.CommitDragStatusNativeDelegate(DragContext.CommitDragStatus_cb);
				}
				return DragContext.CommitDragStatus_cb_delegate;
			}
		}

		// Token: 0x060004DC RID: 1244 RVA: 0x0000E8CF File Offset: 0x0000CACF
		private static void OverrideCommitDragStatus(GType gtype)
		{
			DragContext.OverrideCommitDragStatus(gtype, DragContext.CommitDragStatusVMCallback);
		}

		// Token: 0x060004DD RID: 1245 RVA: 0x0000E8DC File Offset: 0x0000CADC
		private unsafe static void OverrideCommitDragStatus(GType gtype, DragContext.CommitDragStatusNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DragContext.class_abi.GetFieldOffset("commit_drag_status");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060004DE RID: 1246 RVA: 0x0000E910 File Offset: 0x0000CB10
		private static void CommitDragStatus_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as DragContext).OnCommitDragStatus();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060004DF RID: 1247 RVA: 0x0000E948 File Offset: 0x0000CB48
		[DefaultSignalHandler(Type = typeof(DragContext), ConnectionMethod = "OverrideCommitDragStatus")]
		protected virtual void OnCommitDragStatus()
		{
			this.InternalCommitDragStatus();
		}

		// Token: 0x060004E0 RID: 1248 RVA: 0x0000E950 File Offset: 0x0000CB50
		private void InternalCommitDragStatus()
		{
			DragContext.CommitDragStatusNativeDelegate commitDragStatusNativeDelegate = DragContext.class_abi.BaseOverride(base.LookupGType(), "commit_drag_status");
			if (commitDragStatusNativeDelegate == null)
			{
				return;
			}
			commitDragStatusNativeDelegate(base.Handle);
		}

		// Token: 0x1700013C RID: 316
		// (get) Token: 0x060004E1 RID: 1249 RVA: 0x0000E984 File Offset: 0x0000CB84
		public new static AbiStruct class_abi
		{
			get
			{
				if (DragContext._class_abi == null)
				{
					DragContext._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("find_window", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "get_selection", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_selection", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "find_window", "drag_motion", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("drag_motion", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_selection", "drag_status", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("drag_status", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "drag_motion", "drag_abort", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("drag_abort", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "drag_status", "drag_drop", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("drag_drop", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "drag_abort", "drop_reply", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("drop_reply", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "drag_drop", "drop_finish", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("drop_finish", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "drop_reply", "drop_status", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("drop_status", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "drop_finish", "get_drag_window", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_drag_window", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "drop_status", "set_hotspot", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("set_hotspot", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_drag_window", "drop_done", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("drop_done", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "set_hotspot", "manage_dnd", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("manage_dnd", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "drop_done", "set_cursor", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("set_cursor", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "manage_dnd", "cancel", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("cancel", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "set_cursor", "drop_performed", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("drop_performed", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "cancel", "dnd_finished", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("dnd_finished", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "drop_performed", "handle_event", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("handle_event", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "dnd_finished", "action_changed", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("action_changed", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "handle_event", "commit_drag_status", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("commit_drag_status", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "action_changed", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return DragContext._class_abi;
			}
		}

		// Token: 0x1700013D RID: 317
		// (get) Token: 0x060004E2 RID: 1250 RVA: 0x0000EE5F File Offset: 0x0000D05F
		public DragAction Actions
		{
			get
			{
				return (DragAction)DragContext.gdk_drag_context_get_actions(base.Handle);
			}
		}

		// Token: 0x1700013E RID: 318
		// (get) Token: 0x060004E3 RID: 1251 RVA: 0x0000EE71 File Offset: 0x0000D071
		public Window DestWindow
		{
			get
			{
				return Object.GetObject(DragContext.gdk_drag_context_get_dest_window(base.Handle)) as Window;
			}
		}

		// Token: 0x1700013F RID: 319
		// (get) Token: 0x060004E4 RID: 1252 RVA: 0x0000EE8D File Offset: 0x0000D08D
		// (set) Token: 0x060004E5 RID: 1253 RVA: 0x0000EEA9 File Offset: 0x0000D0A9
		public Device Device
		{
			get
			{
				return Object.GetObject(DragContext.gdk_drag_context_get_device(base.Handle)) as Device;
			}
			set
			{
				DragContext.gdk_drag_context_set_device(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x17000140 RID: 320
		// (get) Token: 0x060004E6 RID: 1254 RVA: 0x0000EECB File Offset: 0x0000D0CB
		public Window DragWindow
		{
			get
			{
				return Object.GetObject(DragContext.gdk_drag_context_get_drag_window(base.Handle)) as Window;
			}
		}

		// Token: 0x17000141 RID: 321
		// (get) Token: 0x060004E7 RID: 1255 RVA: 0x0000EEE7 File Offset: 0x0000D0E7
		public DragProtocol Protocol
		{
			get
			{
				return (DragProtocol)DragContext.gdk_drag_context_get_protocol(base.Handle);
			}
		}

		// Token: 0x17000142 RID: 322
		// (get) Token: 0x060004E8 RID: 1256 RVA: 0x0000EEF9 File Offset: 0x0000D0F9
		public DragAction SelectedAction
		{
			get
			{
				return (DragAction)DragContext.gdk_drag_context_get_selected_action(base.Handle);
			}
		}

		// Token: 0x17000143 RID: 323
		// (get) Token: 0x060004E9 RID: 1257 RVA: 0x0000EF0B File Offset: 0x0000D10B
		public Window SourceWindow
		{
			get
			{
				return Object.GetObject(DragContext.gdk_drag_context_get_source_window(base.Handle)) as Window;
			}
		}

		// Token: 0x17000144 RID: 324
		// (get) Token: 0x060004EA RID: 1258 RVA: 0x0000EF27 File Offset: 0x0000D127
		public DragAction SuggestedAction
		{
			get
			{
				return (DragAction)DragContext.gdk_drag_context_get_suggested_action(base.Handle);
			}
		}

		// Token: 0x17000145 RID: 325
		// (get) Token: 0x060004EB RID: 1259 RVA: 0x0000EF3C File Offset: 0x0000D13C
		public new static GType GType
		{
			get
			{
				IntPtr val = DragContext.gdk_drag_context_get_type();
				return new GType(val);
			}
		}

		// Token: 0x060004EC RID: 1260 RVA: 0x0000EF5A File Offset: 0x0000D15A
		public Atom[] ListTargets()
		{
			return (Atom[])Marshaller.ListPtrToArray(DragContext.gdk_drag_context_list_targets(base.Handle), typeof(List), false, false, typeof(Atom));
		}

		// Token: 0x060004ED RID: 1261 RVA: 0x0000EF8C File Offset: 0x0000D18C
		public bool ManageDnd(Window ipc_window, DragAction actions)
		{
			return DragContext.gdk_drag_context_manage_dnd(base.Handle, (ipc_window == null) ? IntPtr.Zero : ipc_window.Handle, (int)actions);
		}

		// Token: 0x060004EE RID: 1262 RVA: 0x0000EFAF File Offset: 0x0000D1AF
		public void SetHotspot(int hot_x, int hot_y)
		{
			DragContext.gdk_drag_context_set_hotspot(base.Handle, hot_x, hot_y);
		}

		// Token: 0x17000146 RID: 326
		// (get) Token: 0x060004EF RID: 1263 RVA: 0x0000EFC3 File Offset: 0x0000D1C3
		public new static AbiStruct abi_info
		{
			get
			{
				if (DragContext._abi_info == null)
				{
					DragContext._abi_info = new AbiStruct(Object.abi_info.Fields);
				}
				return DragContext._abi_info;
			}
		}

		// Token: 0x040001F5 RID: 501
		private static DragContext.FindWindowNativeDelegate FindWindow_cb_delegate;

		// Token: 0x040001F6 RID: 502
		private static DragContext.GetSelectionNativeDelegate GetSelection_cb_delegate;

		// Token: 0x040001F7 RID: 503
		private static DragContext.DragMotionNativeDelegate DragMotion_cb_delegate;

		// Token: 0x040001F8 RID: 504
		private static DragContext.DragStatusNativeDelegate DragStatus_cb_delegate;

		// Token: 0x040001F9 RID: 505
		private static DragContext.DragAbortNativeDelegate DragAbort_cb_delegate;

		// Token: 0x040001FA RID: 506
		private static DragContext.DragDropNativeDelegate DragDrop_cb_delegate;

		// Token: 0x040001FB RID: 507
		private static DragContext.DropReplyNativeDelegate DropReply_cb_delegate;

		// Token: 0x040001FC RID: 508
		private static DragContext.DropFinishNativeDelegate DropFinish_cb_delegate;

		// Token: 0x040001FD RID: 509
		private static DragContext.DropStatusNativeDelegate DropStatus_cb_delegate;

		// Token: 0x040001FE RID: 510
		private static DragContext.GetDragWindowNativeDelegate GetDragWindow_cb_delegate;

		// Token: 0x040001FF RID: 511
		private static DragContext.SetHotspotNativeDelegate SetHotspot_cb_delegate;

		// Token: 0x04000200 RID: 512
		private static DragContext.DropDoneNativeDelegate DropDone_cb_delegate;

		// Token: 0x04000201 RID: 513
		private static DragContext.ManageDndNativeDelegate ManageDnd_cb_delegate;

		// Token: 0x04000202 RID: 514
		private static DragContext.SetCursorNativeDelegate SetCursor_cb_delegate;

		// Token: 0x04000203 RID: 515
		private static DragContext.CancelNativeDelegate Cancel_cb_delegate;

		// Token: 0x04000204 RID: 516
		private static DragContext.DropPerformedNativeDelegate DropPerformed_cb_delegate;

		// Token: 0x04000205 RID: 517
		private static DragContext.DndFinishedNativeDelegate DndFinished_cb_delegate;

		// Token: 0x04000206 RID: 518
		private static DragContext.HandleEventNativeDelegate HandleEvent_cb_delegate;

		// Token: 0x04000207 RID: 519
		private static DragContext.ActionChangedNativeDelegate ActionChanged_cb_delegate;

		// Token: 0x04000208 RID: 520
		private static DragContext.CommitDragStatusNativeDelegate CommitDragStatus_cb_delegate;

		// Token: 0x04000209 RID: 521
		private static AbiStruct _class_abi = null;

		// Token: 0x0400020A RID: 522
		private static DragContext.d_gdk_drag_context_get_actions gdk_drag_context_get_actions = FuncLoader.LoadFunction<DragContext.d_gdk_drag_context_get_actions>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_context_get_actions"));

		// Token: 0x0400020B RID: 523
		private static DragContext.d_gdk_drag_context_get_dest_window gdk_drag_context_get_dest_window = FuncLoader.LoadFunction<DragContext.d_gdk_drag_context_get_dest_window>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_context_get_dest_window"));

		// Token: 0x0400020C RID: 524
		private static DragContext.d_gdk_drag_context_get_device gdk_drag_context_get_device = FuncLoader.LoadFunction<DragContext.d_gdk_drag_context_get_device>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_context_get_device"));

		// Token: 0x0400020D RID: 525
		private static DragContext.d_gdk_drag_context_set_device gdk_drag_context_set_device = FuncLoader.LoadFunction<DragContext.d_gdk_drag_context_set_device>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_context_set_device"));

		// Token: 0x0400020E RID: 526
		private static DragContext.d_gdk_drag_context_get_drag_window gdk_drag_context_get_drag_window = FuncLoader.LoadFunction<DragContext.d_gdk_drag_context_get_drag_window>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_context_get_drag_window"));

		// Token: 0x0400020F RID: 527
		private static DragContext.d_gdk_drag_context_get_protocol gdk_drag_context_get_protocol = FuncLoader.LoadFunction<DragContext.d_gdk_drag_context_get_protocol>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_context_get_protocol"));

		// Token: 0x04000210 RID: 528
		private static DragContext.d_gdk_drag_context_get_selected_action gdk_drag_context_get_selected_action = FuncLoader.LoadFunction<DragContext.d_gdk_drag_context_get_selected_action>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_context_get_selected_action"));

		// Token: 0x04000211 RID: 529
		private static DragContext.d_gdk_drag_context_get_source_window gdk_drag_context_get_source_window = FuncLoader.LoadFunction<DragContext.d_gdk_drag_context_get_source_window>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_context_get_source_window"));

		// Token: 0x04000212 RID: 530
		private static DragContext.d_gdk_drag_context_get_suggested_action gdk_drag_context_get_suggested_action = FuncLoader.LoadFunction<DragContext.d_gdk_drag_context_get_suggested_action>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_context_get_suggested_action"));

		// Token: 0x04000213 RID: 531
		private static DragContext.d_gdk_drag_context_get_type gdk_drag_context_get_type = FuncLoader.LoadFunction<DragContext.d_gdk_drag_context_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_context_get_type"));

		// Token: 0x04000214 RID: 532
		private static DragContext.d_gdk_drag_context_list_targets gdk_drag_context_list_targets = FuncLoader.LoadFunction<DragContext.d_gdk_drag_context_list_targets>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_context_list_targets"));

		// Token: 0x04000215 RID: 533
		private static DragContext.d_gdk_drag_context_manage_dnd gdk_drag_context_manage_dnd = FuncLoader.LoadFunction<DragContext.d_gdk_drag_context_manage_dnd>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_context_manage_dnd"));

		// Token: 0x04000216 RID: 534
		private static DragContext.d_gdk_drag_context_set_hotspot gdk_drag_context_set_hotspot = FuncLoader.LoadFunction<DragContext.d_gdk_drag_context_set_hotspot>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_context_set_hotspot"));

		// Token: 0x04000217 RID: 535
		private static AbiStruct _abi_info = null;

		// Token: 0x02000236 RID: 566
		// (Invoke) Token: 0x06000F5F RID: 3935
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr FindWindowNativeDelegate(IntPtr inst, IntPtr drag_window, IntPtr screen, int x_root, int y_root, out int protocol);

		// Token: 0x02000237 RID: 567
		// (Invoke) Token: 0x06000F63 RID: 3939
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetSelectionNativeDelegate(IntPtr inst);

		// Token: 0x02000238 RID: 568
		// (Invoke) Token: 0x06000F67 RID: 3943
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool DragMotionNativeDelegate(IntPtr inst, IntPtr dest_window, int protocol, int root_x, int root_y, int suggested_action, int possible_actions, uint time_);

		// Token: 0x02000239 RID: 569
		// (Invoke) Token: 0x06000F6B RID: 3947
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DragStatusNativeDelegate(IntPtr inst, int action, uint time_);

		// Token: 0x0200023A RID: 570
		// (Invoke) Token: 0x06000F6F RID: 3951
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DragAbortNativeDelegate(IntPtr inst, uint time_);

		// Token: 0x0200023B RID: 571
		// (Invoke) Token: 0x06000F73 RID: 3955
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DragDropNativeDelegate(IntPtr inst, uint time_);

		// Token: 0x0200023C RID: 572
		// (Invoke) Token: 0x06000F77 RID: 3959
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DropReplyNativeDelegate(IntPtr inst, bool accept, uint time_);

		// Token: 0x0200023D RID: 573
		// (Invoke) Token: 0x06000F7B RID: 3963
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DropFinishNativeDelegate(IntPtr inst, bool success, uint time_);

		// Token: 0x0200023E RID: 574
		// (Invoke) Token: 0x06000F7F RID: 3967
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool DropStatusNativeDelegate(IntPtr inst);

		// Token: 0x0200023F RID: 575
		// (Invoke) Token: 0x06000F83 RID: 3971
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetDragWindowNativeDelegate(IntPtr inst);

		// Token: 0x02000240 RID: 576
		// (Invoke) Token: 0x06000F87 RID: 3975
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void SetHotspotNativeDelegate(IntPtr inst, int hot_x, int hot_y);

		// Token: 0x02000241 RID: 577
		// (Invoke) Token: 0x06000F8B RID: 3979
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DropDoneNativeDelegate(IntPtr inst, bool success);

		// Token: 0x02000242 RID: 578
		// (Invoke) Token: 0x06000F8F RID: 3983
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool ManageDndNativeDelegate(IntPtr inst, IntPtr ipc_window, int actions);

		// Token: 0x02000243 RID: 579
		// (Invoke) Token: 0x06000F93 RID: 3987
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void SetCursorNativeDelegate(IntPtr inst, IntPtr cursor);

		// Token: 0x02000244 RID: 580
		// (Invoke) Token: 0x06000F97 RID: 3991
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void CancelNativeDelegate(IntPtr inst, int reason);

		// Token: 0x02000245 RID: 581
		// (Invoke) Token: 0x06000F9B RID: 3995
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DropPerformedNativeDelegate(IntPtr inst, uint time);

		// Token: 0x02000246 RID: 582
		// (Invoke) Token: 0x06000F9F RID: 3999
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DndFinishedNativeDelegate(IntPtr inst);

		// Token: 0x02000247 RID: 583
		// (Invoke) Token: 0x06000FA3 RID: 4003
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool HandleEventNativeDelegate(IntPtr inst, IntPtr evnt);

		// Token: 0x02000248 RID: 584
		// (Invoke) Token: 0x06000FA7 RID: 4007
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ActionChangedNativeDelegate(IntPtr inst, int action);

		// Token: 0x02000249 RID: 585
		// (Invoke) Token: 0x06000FAB RID: 4011
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void CommitDragStatusNativeDelegate(IntPtr inst);

		// Token: 0x0200024A RID: 586
		// (Invoke) Token: 0x06000FAF RID: 4015
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_drag_context_get_actions(IntPtr raw);

		// Token: 0x0200024B RID: 587
		// (Invoke) Token: 0x06000FB3 RID: 4019
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_drag_context_get_dest_window(IntPtr raw);

		// Token: 0x0200024C RID: 588
		// (Invoke) Token: 0x06000FB7 RID: 4023
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_drag_context_get_device(IntPtr raw);

		// Token: 0x0200024D RID: 589
		// (Invoke) Token: 0x06000FBB RID: 4027
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_drag_context_set_device(IntPtr raw, IntPtr device);

		// Token: 0x0200024E RID: 590
		// (Invoke) Token: 0x06000FBF RID: 4031
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_drag_context_get_drag_window(IntPtr raw);

		// Token: 0x0200024F RID: 591
		// (Invoke) Token: 0x06000FC3 RID: 4035
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_drag_context_get_protocol(IntPtr raw);

		// Token: 0x02000250 RID: 592
		// (Invoke) Token: 0x06000FC7 RID: 4039
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_drag_context_get_selected_action(IntPtr raw);

		// Token: 0x02000251 RID: 593
		// (Invoke) Token: 0x06000FCB RID: 4043
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_drag_context_get_source_window(IntPtr raw);

		// Token: 0x02000252 RID: 594
		// (Invoke) Token: 0x06000FCF RID: 4047
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_drag_context_get_suggested_action(IntPtr raw);

		// Token: 0x02000253 RID: 595
		// (Invoke) Token: 0x06000FD3 RID: 4051
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_drag_context_get_type();

		// Token: 0x02000254 RID: 596
		// (Invoke) Token: 0x06000FD7 RID: 4055
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_drag_context_list_targets(IntPtr raw);

		// Token: 0x02000255 RID: 597
		// (Invoke) Token: 0x06000FDB RID: 4059
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_drag_context_manage_dnd(IntPtr raw, IntPtr ipc_window, int actions);

		// Token: 0x02000256 RID: 598
		// (Invoke) Token: 0x06000FDF RID: 4063
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_drag_context_set_hotspot(IntPtr raw, int hot_x, int hot_y);
	}
}
