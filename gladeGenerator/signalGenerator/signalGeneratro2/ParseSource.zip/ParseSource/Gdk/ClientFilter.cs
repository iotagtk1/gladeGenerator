﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x0200004B RID: 75
	public class ClientFilter : Opaque
	{
		// Token: 0x060003B5 RID: 949 RVA: 0x0000BD40 File Offset: 0x00009F40
		public ClientFilter(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170000FA RID: 250
		// (get) Token: 0x060003B6 RID: 950 RVA: 0x0000BD49 File Offset: 0x00009F49
		public static AbiStruct abi_info
		{
			get
			{
				if (ClientFilter._abi_info == null)
				{
					ClientFilter._abi_info = new AbiStruct(new List<AbiField>());
				}
				return ClientFilter._abi_info;
			}
		}

		// Token: 0x04000142 RID: 322
		private static AbiStruct _abi_info;
	}
}
