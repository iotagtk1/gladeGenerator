﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000FD RID: 253
	[GType(typeof(StatusGType))]
	public enum Status
	{
		// Token: 0x04000573 RID: 1395
		Ok,
		// Token: 0x04000574 RID: 1396
		Error = -1,
		// Token: 0x04000575 RID: 1397
		ErrorParam = -2,
		// Token: 0x04000576 RID: 1398
		ErrorFile = -3,
		// Token: 0x04000577 RID: 1399
		ErrorMem = -4
	}
}
