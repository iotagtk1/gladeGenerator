﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000AC RID: 172
	public class Keyval
	{
		// Token: 0x06000704 RID: 1796 RVA: 0x00014927 File Offset: 0x00012B27
		public static void ConvertCase(uint symbol, out uint lower, out uint upper)
		{
			Keyval.gdk_keyval_convert_case(symbol, out lower, out upper);
		}

		// Token: 0x06000705 RID: 1797 RVA: 0x00014938 File Offset: 0x00012B38
		public static uint FromName(string keyval_name)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(keyval_name);
			uint result = Keyval.gdk_keyval_from_name(intPtr);
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x06000706 RID: 1798 RVA: 0x0001495D File Offset: 0x00012B5D
		public static bool IsLower(uint keyval)
		{
			return Keyval.gdk_keyval_is_lower(keyval);
		}

		// Token: 0x06000707 RID: 1799 RVA: 0x0001496A File Offset: 0x00012B6A
		public static bool IsUpper(uint keyval)
		{
			return Keyval.gdk_keyval_is_upper(keyval);
		}

		// Token: 0x06000708 RID: 1800 RVA: 0x00014977 File Offset: 0x00012B77
		public static string Name(uint keyval)
		{
			return Marshaller.Utf8PtrToString(Keyval.gdk_keyval_name(keyval));
		}

		// Token: 0x06000709 RID: 1801 RVA: 0x00014989 File Offset: 0x00012B89
		public static uint ToLower(uint keyval)
		{
			return Keyval.gdk_keyval_to_lower(keyval);
		}

		// Token: 0x0600070A RID: 1802 RVA: 0x00014996 File Offset: 0x00012B96
		public static uint ToUnicode(uint keyval)
		{
			return Keyval.gdk_keyval_to_unicode(keyval);
		}

		// Token: 0x0600070B RID: 1803 RVA: 0x000149A3 File Offset: 0x00012BA3
		public static uint ToUpper(uint keyval)
		{
			return Keyval.gdk_keyval_to_upper(keyval);
		}

		// Token: 0x040003BD RID: 957
		private static Keyval.d_gdk_keyval_convert_case gdk_keyval_convert_case = FuncLoader.LoadFunction<Keyval.d_gdk_keyval_convert_case>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keyval_convert_case"));

		// Token: 0x040003BE RID: 958
		private static Keyval.d_gdk_keyval_from_name gdk_keyval_from_name = FuncLoader.LoadFunction<Keyval.d_gdk_keyval_from_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keyval_from_name"));

		// Token: 0x040003BF RID: 959
		private static Keyval.d_gdk_keyval_is_lower gdk_keyval_is_lower = FuncLoader.LoadFunction<Keyval.d_gdk_keyval_is_lower>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keyval_is_lower"));

		// Token: 0x040003C0 RID: 960
		private static Keyval.d_gdk_keyval_is_upper gdk_keyval_is_upper = FuncLoader.LoadFunction<Keyval.d_gdk_keyval_is_upper>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keyval_is_upper"));

		// Token: 0x040003C1 RID: 961
		private static Keyval.d_gdk_keyval_name gdk_keyval_name = FuncLoader.LoadFunction<Keyval.d_gdk_keyval_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keyval_name"));

		// Token: 0x040003C2 RID: 962
		private static Keyval.d_gdk_keyval_to_lower gdk_keyval_to_lower = FuncLoader.LoadFunction<Keyval.d_gdk_keyval_to_lower>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keyval_to_lower"));

		// Token: 0x040003C3 RID: 963
		private static Keyval.d_gdk_keyval_to_unicode gdk_keyval_to_unicode = FuncLoader.LoadFunction<Keyval.d_gdk_keyval_to_unicode>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keyval_to_unicode"));

		// Token: 0x040003C4 RID: 964
		private static Keyval.d_gdk_keyval_to_upper gdk_keyval_to_upper = FuncLoader.LoadFunction<Keyval.d_gdk_keyval_to_upper>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keyval_to_upper"));

		// Token: 0x02000300 RID: 768
		// (Invoke) Token: 0x06001285 RID: 4741
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_keyval_convert_case(uint symbol, out uint lower, out uint upper);

		// Token: 0x02000301 RID: 769
		// (Invoke) Token: 0x06001289 RID: 4745
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gdk_keyval_from_name(IntPtr keyval_name);

		// Token: 0x02000302 RID: 770
		// (Invoke) Token: 0x0600128D RID: 4749
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_keyval_is_lower(uint keyval);

		// Token: 0x02000303 RID: 771
		// (Invoke) Token: 0x06001291 RID: 4753
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_keyval_is_upper(uint keyval);

		// Token: 0x02000304 RID: 772
		// (Invoke) Token: 0x06001295 RID: 4757
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_keyval_name(uint keyval);

		// Token: 0x02000305 RID: 773
		// (Invoke) Token: 0x06001299 RID: 4761
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gdk_keyval_to_lower(uint keyval);

		// Token: 0x02000306 RID: 774
		// (Invoke) Token: 0x0600129D RID: 4765
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gdk_keyval_to_unicode(uint keyval);

		// Token: 0x02000307 RID: 775
		// (Invoke) Token: 0x060012A1 RID: 4769
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gdk_keyval_to_upper(uint keyval);
	}
}
