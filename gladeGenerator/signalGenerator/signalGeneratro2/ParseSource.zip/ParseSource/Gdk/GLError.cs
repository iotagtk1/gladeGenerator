﻿using System;

namespace Gdk
{
	// Token: 0x02000095 RID: 149
	public enum GLError
	{
		// Token: 0x0400034C RID: 844
		NotAvailable,
		// Token: 0x0400034D RID: 845
		UnsupportedFormat,
		// Token: 0x0400034E RID: 846
		UnsupportedProfile
	}
}
