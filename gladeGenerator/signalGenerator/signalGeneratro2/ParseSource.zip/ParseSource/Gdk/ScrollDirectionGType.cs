﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000ED RID: 237
	internal class ScrollDirectionGType
	{
		// Token: 0x1700026F RID: 623
		// (get) Token: 0x0600099E RID: 2462 RVA: 0x0001C929 File Offset: 0x0001AB29
		public static GType GType
		{
			get
			{
				return new GType(ScrollDirectionGType.gdk_scroll_direction_get_type());
			}
		}

		// Token: 0x04000544 RID: 1348
		private static ScrollDirectionGType.d_gdk_scroll_direction_get_type gdk_scroll_direction_get_type = FuncLoader.LoadFunction<ScrollDirectionGType.d_gdk_scroll_direction_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_scroll_direction_get_type"));

		// Token: 0x020003F0 RID: 1008
		// (Invoke) Token: 0x06001642 RID: 5698
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_scroll_direction_get_type();
	}
}
