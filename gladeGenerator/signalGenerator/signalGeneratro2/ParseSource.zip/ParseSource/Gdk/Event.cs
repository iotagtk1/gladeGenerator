﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000025 RID: 37
	public class Event : IWrapper
	{
		// Token: 0x060002A7 RID: 679 RVA: 0x00009CB1 File Offset: 0x00007EB1
		public Event(IntPtr raw)
		{
			this.raw = raw;
		}

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x060002A8 RID: 680 RVA: 0x00009CC0 File Offset: 0x00007EC0
		public IntPtr Handle
		{
			get
			{
				return this.raw;
			}
		}

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x060002A9 RID: 681 RVA: 0x00009CC8 File Offset: 0x00007EC8
		public static GType GType
		{
			get
			{
				return new GType(Event.gdk_event_get_type());
			}
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x060002AA RID: 682 RVA: 0x00009CD9 File Offset: 0x00007ED9
		private Event.NativeStruct Native
		{
			get
			{
				return (Event.NativeStruct)Marshal.PtrToStructure(this.raw, typeof(Event.NativeStruct));
			}
		}

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x060002AB RID: 683 RVA: 0x00009CF5 File Offset: 0x00007EF5
		// (set) Token: 0x060002AC RID: 684 RVA: 0x00009D04 File Offset: 0x00007F04
		public EventType Type
		{
			get
			{
				return this.Native.type;
			}
			set
			{
				Event.NativeStruct native = this.Native;
				native.type = value;
				Marshal.StructureToPtr<Event.NativeStruct>(native, this.raw, false);
			}
		}

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x060002AD RID: 685 RVA: 0x00009D2D File Offset: 0x00007F2D
		// (set) Token: 0x060002AE RID: 686 RVA: 0x00009D48 File Offset: 0x00007F48
		public Window Window
		{
			get
			{
				return Object.GetObject(this.Native.window, false) as Window;
			}
			set
			{
				Event.NativeStruct native = this.Native;
				native.window = ((value == null) ? IntPtr.Zero : value.Handle);
				Marshal.StructureToPtr<Event.NativeStruct>(native, this.raw, false);
			}
		}

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x060002AF RID: 687 RVA: 0x00009D80 File Offset: 0x00007F80
		// (set) Token: 0x060002B0 RID: 688 RVA: 0x00009D90 File Offset: 0x00007F90
		public bool SendEvent
		{
			get
			{
				return this.Native.send_event != 0;
			}
			set
			{
				Event.NativeStruct native = this.Native;
				native.send_event = (value ? 1 : 0);
				Marshal.StructureToPtr<Event.NativeStruct>(native, this.raw, false);
			}
		}

		// Token: 0x060002B1 RID: 689 RVA: 0x00009DC0 File Offset: 0x00007FC0
		public static Event New(IntPtr raw)
		{
			return Event.GetEvent(raw);
		}

		// Token: 0x060002B2 RID: 690 RVA: 0x00009DC8 File Offset: 0x00007FC8
		public static Event GetEvent(IntPtr raw)
		{
			if (raw == IntPtr.Zero)
			{
				return null;
			}
			switch (((Event.NativeStruct)Marshal.PtrToStructure(raw, typeof(Event.NativeStruct))).type)
			{
			case EventType.Expose:
				return new EventExpose(raw);
			case EventType.MotionNotify:
				return new EventMotion(raw);
			case EventType.ButtonPress:
			case EventType.TwoButtonPress:
			case EventType.ThreeButtonPress:
			case EventType.ButtonRelease:
				return new EventButton(raw);
			case EventType.KeyPress:
			case EventType.KeyRelease:
				return new EventKey(raw);
			case EventType.EnterNotify:
			case EventType.LeaveNotify:
				return new EventCrossing(raw);
			case EventType.FocusChange:
				return new EventFocus(raw);
			case EventType.Configure:
				return new EventConfigure(raw);
			case EventType.PropertyNotify:
				return new EventProperty(raw);
			case EventType.SelectionClear:
			case EventType.SelectionRequest:
			case EventType.SelectionNotify:
				return new EventSelection(raw);
			case EventType.ProximityIn:
			case EventType.ProximityOut:
				return new EventProximity(raw);
			case EventType.DragEnter:
			case EventType.DragLeave:
			case EventType.DragMotion:
			case EventType.DragStatus:
			case EventType.DropStart:
			case EventType.DropFinished:
				return new EventDND(raw);
			case EventType.VisibilityNotify:
				return new EventVisibility(raw);
			case EventType.Scroll:
				return new EventScroll(raw);
			case EventType.WindowState:
				return new EventWindowState(raw);
			case EventType.Setting:
				return new EventSetting(raw);
			case EventType.OwnerChange:
				return new EventOwnerChange(raw);
			case EventType.GrabBroken:
				return new EventGrabBroken(raw);
			}
			return new Event(raw);
		}

		// Token: 0x04000101 RID: 257
		private IntPtr raw;

		// Token: 0x04000102 RID: 258
		private static Event.d_gdk_event_get_type gdk_event_get_type = FuncLoader.LoadFunction<Event.d_gdk_event_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_get_type"));

		// Token: 0x020001D7 RID: 471
		// (Invoke) Token: 0x06000E2F RID: 3631
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_event_get_type();

		// Token: 0x020001D8 RID: 472
		private struct NativeStruct
		{
			// Token: 0x04000C0C RID: 3084
			public EventType type;

			// Token: 0x04000C0D RID: 3085
			public IntPtr window;

			// Token: 0x04000C0E RID: 3086
			public sbyte send_event;
		}
	}
}
