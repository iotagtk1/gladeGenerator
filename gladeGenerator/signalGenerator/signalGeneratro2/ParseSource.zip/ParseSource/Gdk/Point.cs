﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000E2 RID: 226
	public struct Point : IEquatable<Point>
	{
		// Token: 0x0600087A RID: 2170 RVA: 0x000190BF File Offset: 0x000172BF
		public static Point New(IntPtr raw)
		{
			if (raw == IntPtr.Zero)
			{
				return Point.Zero;
			}
			return (Point)Marshal.PtrToStructure(raw, typeof(Point));
		}

		// Token: 0x0600087B RID: 2171 RVA: 0x000190E9 File Offset: 0x000172E9
		public bool Equals(Point other)
		{
			return this.X.Equals(other.X) && this.Y.Equals(other.Y);
		}

		// Token: 0x0600087C RID: 2172 RVA: 0x00019111 File Offset: 0x00017311
		public override bool Equals(object other)
		{
			return other is Point && this.Equals((Point)other);
		}

		// Token: 0x0600087D RID: 2173 RVA: 0x00019129 File Offset: 0x00017329
		public override int GetHashCode()
		{
			return base.GetType().FullName.GetHashCode() ^ this.X.GetHashCode() ^ this.Y.GetHashCode();
		}

		// Token: 0x17000233 RID: 563
		// (get) Token: 0x0600087E RID: 2174 RVA: 0x0001915D File Offset: 0x0001735D
		private static GType GType
		{
			get
			{
				return GType.Pointer;
			}
		}

		// Token: 0x0600087F RID: 2175 RVA: 0x00019164 File Offset: 0x00017364
		public override string ToString()
		{
			return string.Format("({0},{1})", this.X, this.Y);
		}

		// Token: 0x06000880 RID: 2176 RVA: 0x00019186 File Offset: 0x00017386
		public Point(int x, int y)
		{
			this.X = x;
			this.Y = y;
		}

		// Token: 0x06000881 RID: 2177 RVA: 0x00019196 File Offset: 0x00017396
		public Point(Size sz)
		{
			this.X = sz.Width;
			this.Y = sz.Height;
		}

		// Token: 0x06000882 RID: 2178 RVA: 0x000191B2 File Offset: 0x000173B2
		public void Offset(int dx, int dy)
		{
			this.X += dx;
			this.Y += dy;
		}

		// Token: 0x17000234 RID: 564
		// (get) Token: 0x06000883 RID: 2179 RVA: 0x000191D0 File Offset: 0x000173D0
		public bool IsEmpty
		{
			get
			{
				return this.X == 0 && this.Y == 0;
			}
		}

		// Token: 0x06000884 RID: 2180 RVA: 0x000191E5 File Offset: 0x000173E5
		public static explicit operator Size(Point pt)
		{
			return new Size(pt.X, pt.Y);
		}

		// Token: 0x06000885 RID: 2181 RVA: 0x000191F8 File Offset: 0x000173F8
		public static Point operator +(Point pt, Size sz)
		{
			return new Point(pt.X + sz.Width, pt.Y + sz.Height);
		}

		// Token: 0x06000886 RID: 2182 RVA: 0x0001921B File Offset: 0x0001741B
		public static Point operator -(Point pt, Size sz)
		{
			return new Point(pt.X - sz.Width, pt.Y - sz.Height);
		}

		// Token: 0x06000887 RID: 2183 RVA: 0x0001923E File Offset: 0x0001743E
		public static bool operator ==(Point pt_a, Point pt_b)
		{
			return pt_a.X == pt_b.X && pt_a.Y == pt_b.Y;
		}

		// Token: 0x06000888 RID: 2184 RVA: 0x0001925E File Offset: 0x0001745E
		public static bool operator !=(Point pt_a, Point pt_b)
		{
			return pt_a.X != pt_b.X || pt_a.Y != pt_b.Y;
		}

		// Token: 0x040004DC RID: 1244
		public int X;

		// Token: 0x040004DD RID: 1245
		public int Y;

		// Token: 0x040004DE RID: 1246
		public static Point Zero;
	}
}
