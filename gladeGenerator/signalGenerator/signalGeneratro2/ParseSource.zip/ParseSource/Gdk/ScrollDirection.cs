﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000EC RID: 236
	[GType(typeof(ScrollDirectionGType))]
	public enum ScrollDirection
	{
		// Token: 0x0400053F RID: 1343
		Up,
		// Token: 0x04000540 RID: 1344
		Down,
		// Token: 0x04000541 RID: 1345
		Left,
		// Token: 0x04000542 RID: 1346
		Right,
		// Token: 0x04000543 RID: 1347
		Smooth
	}
}
