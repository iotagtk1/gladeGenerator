﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000067 RID: 103
	public class DisplayOpenedArgs : SignalArgs
	{
		// Token: 0x17000125 RID: 293
		// (get) Token: 0x0600044B RID: 1099 RVA: 0x0000D297 File Offset: 0x0000B497
		public Display Display
		{
			get
			{
				return (Display)base.Args[0];
			}
		}
	}
}
