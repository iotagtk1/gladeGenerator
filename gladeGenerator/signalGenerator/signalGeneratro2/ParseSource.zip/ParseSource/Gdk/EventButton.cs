﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000026 RID: 38
	public class EventButton : Event
	{
		// Token: 0x060002B4 RID: 692 RVA: 0x00009F30 File Offset: 0x00008130
		public EventButton(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x060002B5 RID: 693 RVA: 0x00009F39 File Offset: 0x00008139
		private EventButton.NativeStruct Native
		{
			get
			{
				return (EventButton.NativeStruct)Marshal.PtrToStructure(base.Handle, typeof(EventButton.NativeStruct));
			}
		}

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x060002B6 RID: 694 RVA: 0x00009F58 File Offset: 0x00008158
		// (set) Token: 0x060002B7 RID: 695 RVA: 0x00009FA0 File Offset: 0x000081A0
		public double[] Axes
		{
			get
			{
				double[] array = null;
				IntPtr axes = this.Native.axes;
				if (axes != IntPtr.Zero)
				{
					array = new double[this.Device.NumAxes];
					Marshal.Copy(axes, array, 0, array.Length);
				}
				return array;
			}
			set
			{
				EventButton.NativeStruct native = this.Native;
				if (native.axes == IntPtr.Zero || value.Length != this.Device.NumAxes)
				{
					throw new InvalidOperationException();
				}
				Marshal.Copy(value, 0, native.axes, value.Length);
			}
		}

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x060002B8 RID: 696 RVA: 0x00009FEC File Offset: 0x000081EC
		// (set) Token: 0x060002B9 RID: 697 RVA: 0x00009FFC File Offset: 0x000081FC
		public uint Button
		{
			get
			{
				return this.Native.button;
			}
			set
			{
				EventButton.NativeStruct native = this.Native;
				native.button = value;
				Marshal.StructureToPtr<EventButton.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x060002BA RID: 698 RVA: 0x0000A025 File Offset: 0x00008225
		// (set) Token: 0x060002BB RID: 699 RVA: 0x0000A040 File Offset: 0x00008240
		public Device Device
		{
			get
			{
				return Object.GetObject(this.Native.device, false) as Device;
			}
			set
			{
				EventButton.NativeStruct native = this.Native;
				native.device = ((value == null) ? IntPtr.Zero : value.Handle);
				Marshal.StructureToPtr<EventButton.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x060002BC RID: 700 RVA: 0x0000A078 File Offset: 0x00008278
		// (set) Token: 0x060002BD RID: 701 RVA: 0x0000A088 File Offset: 0x00008288
		public ModifierType State
		{
			get
			{
				return (ModifierType)this.Native.state;
			}
			set
			{
				EventButton.NativeStruct native = this.Native;
				native.state = (uint)value;
				Marshal.StructureToPtr<EventButton.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x060002BE RID: 702 RVA: 0x0000A0B1 File Offset: 0x000082B1
		// (set) Token: 0x060002BF RID: 703 RVA: 0x0000A0C0 File Offset: 0x000082C0
		public uint Time
		{
			get
			{
				return this.Native.time;
			}
			set
			{
				EventButton.NativeStruct native = this.Native;
				native.time = value;
				Marshal.StructureToPtr<EventButton.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x060002C0 RID: 704 RVA: 0x0000A0E9 File Offset: 0x000082E9
		// (set) Token: 0x060002C1 RID: 705 RVA: 0x0000A0F8 File Offset: 0x000082F8
		public double X
		{
			get
			{
				return this.Native.x;
			}
			set
			{
				EventButton.NativeStruct native = this.Native;
				native.x = value;
				Marshal.StructureToPtr<EventButton.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x060002C2 RID: 706 RVA: 0x0000A121 File Offset: 0x00008321
		// (set) Token: 0x060002C3 RID: 707 RVA: 0x0000A130 File Offset: 0x00008330
		public double XRoot
		{
			get
			{
				return this.Native.x_root;
			}
			set
			{
				EventButton.NativeStruct native = this.Native;
				native.x_root = value;
				Marshal.StructureToPtr<EventButton.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x060002C4 RID: 708 RVA: 0x0000A159 File Offset: 0x00008359
		// (set) Token: 0x060002C5 RID: 709 RVA: 0x0000A168 File Offset: 0x00008368
		public double Y
		{
			get
			{
				return this.Native.y;
			}
			set
			{
				EventButton.NativeStruct native = this.Native;
				native.y = value;
				Marshal.StructureToPtr<EventButton.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x060002C6 RID: 710 RVA: 0x0000A191 File Offset: 0x00008391
		// (set) Token: 0x060002C7 RID: 711 RVA: 0x0000A1A0 File Offset: 0x000083A0
		public double YRoot
		{
			get
			{
				return this.Native.y_root;
			}
			set
			{
				EventButton.NativeStruct native = this.Native;
				native.y_root = value;
				Marshal.StructureToPtr<EventButton.NativeStruct>(native, base.Handle, false);
			}
		}

		// Token: 0x020001D9 RID: 473
		private struct NativeStruct
		{
			// Token: 0x04000C0F RID: 3087
			private EventType type;

			// Token: 0x04000C10 RID: 3088
			private IntPtr window;

			// Token: 0x04000C11 RID: 3089
			private sbyte send_event;

			// Token: 0x04000C12 RID: 3090
			public uint time;

			// Token: 0x04000C13 RID: 3091
			public double x;

			// Token: 0x04000C14 RID: 3092
			public double y;

			// Token: 0x04000C15 RID: 3093
			public IntPtr axes;

			// Token: 0x04000C16 RID: 3094
			public uint state;

			// Token: 0x04000C17 RID: 3095
			public uint button;

			// Token: 0x04000C18 RID: 3096
			public IntPtr device;

			// Token: 0x04000C19 RID: 3097
			public double x_root;

			// Token: 0x04000C1A RID: 3098
			public double y_root;
		}
	}
}
