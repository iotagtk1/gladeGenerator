﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000BA RID: 186
	internal class NotifyTypeGType
	{
		// Token: 0x170001E5 RID: 485
		// (get) Token: 0x0600074C RID: 1868 RVA: 0x0001512B File Offset: 0x0001332B
		public static GType GType
		{
			get
			{
				return new GType(NotifyTypeGType.gdk_notify_type_get_type());
			}
		}

		// Token: 0x04000409 RID: 1033
		private static NotifyTypeGType.d_gdk_notify_type_get_type gdk_notify_type_get_type = FuncLoader.LoadFunction<NotifyTypeGType.d_gdk_notify_type_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_notify_type_get_type"));

		// Token: 0x02000318 RID: 792
		// (Invoke) Token: 0x060012E5 RID: 4837
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_notify_type_get_type();
	}
}
