﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x020000C9 RID: 201
	public class PixbufBufferQueue : Opaque
	{
		// Token: 0x060007DF RID: 2015 RVA: 0x000178C3 File Offset: 0x00015AC3
		public PixbufBufferQueue(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000205 RID: 517
		// (get) Token: 0x060007E0 RID: 2016 RVA: 0x000178CC File Offset: 0x00015ACC
		public static AbiStruct abi_info
		{
			get
			{
				if (PixbufBufferQueue._abi_info == null)
				{
					PixbufBufferQueue._abi_info = new AbiStruct(new List<AbiField>());
				}
				return PixbufBufferQueue._abi_info;
			}
		}

		// Token: 0x04000471 RID: 1137
		private static AbiStruct _abi_info;
	}
}
