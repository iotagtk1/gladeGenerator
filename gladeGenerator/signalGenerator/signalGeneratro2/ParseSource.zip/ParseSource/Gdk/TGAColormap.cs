﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x02000102 RID: 258
	public class TGAColormap : Opaque
	{
		// Token: 0x06000A16 RID: 2582 RVA: 0x0001DB87 File Offset: 0x0001BD87
		public TGAColormap(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700028B RID: 651
		// (get) Token: 0x06000A17 RID: 2583 RVA: 0x0001DB90 File Offset: 0x0001BD90
		public static AbiStruct abi_info
		{
			get
			{
				if (TGAColormap._abi_info == null)
				{
					TGAColormap._abi_info = new AbiStruct(new List<AbiField>());
				}
				return TGAColormap._abi_info;
			}
		}

		// Token: 0x04000582 RID: 1410
		private static AbiStruct _abi_info;
	}
}
