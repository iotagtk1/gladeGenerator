﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000062 RID: 98
	[GType(typeof(DeviceToolTypeGType))]
	public enum DeviceToolType
	{
		// Token: 0x040001D0 RID: 464
		Unknown,
		// Token: 0x040001D1 RID: 465
		Pen,
		// Token: 0x040001D2 RID: 466
		Eraser,
		// Token: 0x040001D3 RID: 467
		Brush,
		// Token: 0x040001D4 RID: 468
		Pencil,
		// Token: 0x040001D5 RID: 469
		Airbrush,
		// Token: 0x040001D6 RID: 470
		Mouse,
		// Token: 0x040001D7 RID: 471
		Lens
	}
}
