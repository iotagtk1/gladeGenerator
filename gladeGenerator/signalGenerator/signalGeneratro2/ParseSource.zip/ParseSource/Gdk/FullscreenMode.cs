﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x0200008E RID: 142
	[GType(typeof(FullscreenModeGType))]
	public enum FullscreenMode
	{
		// Token: 0x04000322 RID: 802
		CurrentMonitor,
		// Token: 0x04000323 RID: 803
		AllMonitors
	}
}
