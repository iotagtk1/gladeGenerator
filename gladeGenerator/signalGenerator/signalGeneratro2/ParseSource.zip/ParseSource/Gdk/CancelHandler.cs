﻿using System;

namespace Gdk
{
	// Token: 0x02000049 RID: 73
	// (Invoke) Token: 0x060003B0 RID: 944
	public delegate void CancelHandler(object o, CancelArgs args);
}
