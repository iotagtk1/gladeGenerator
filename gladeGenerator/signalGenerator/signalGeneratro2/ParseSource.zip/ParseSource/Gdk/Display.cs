﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Cairo;
using GLib;

namespace Gdk
{
	// Token: 0x02000023 RID: 35
	public class Display : Object
	{
		// Token: 0x06000110 RID: 272 RVA: 0x00004D44 File Offset: 0x00002F44
		[Obsolete]
		public void GetPointer(Screen screen, out int x, out int y, out ModifierType mask)
		{
			int num;
			Display.gdk_display_get_pointer(base.Handle, screen.Handle, out x, out y, out num);
			mask = (ModifierType)num;
		}

		// Token: 0x06000111 RID: 273 RVA: 0x00004D70 File Offset: 0x00002F70
		public void GetPointer(out Screen screen, out int x, out int y, out ModifierType mask)
		{
			IntPtr o;
			int num;
			Display.gdk_display_get_pointer2(base.Handle, out o, out x, out y, out num);
			screen = (Screen)Object.GetObject(o);
			mask = (ModifierType)num;
		}

		// Token: 0x06000112 RID: 274 RVA: 0x00004DA4 File Offset: 0x00002FA4
		public void GetPointer(out int x, out int y)
		{
			Screen screen;
			ModifierType modifierType;
			this.GetPointer(out screen, out x, out y, out modifierType);
		}

		// Token: 0x06000113 RID: 275 RVA: 0x00004DC0 File Offset: 0x00002FC0
		public void GetPointer(out int x, out int y, out ModifierType mod)
		{
			Screen screen;
			this.GetPointer(out screen, out x, out y, out mod);
		}

		// Token: 0x06000114 RID: 276 RVA: 0x00004DD8 File Offset: 0x00002FD8
		public void GetPointer(out Screen screen, out int x, out int y)
		{
			ModifierType modifierType;
			this.GetPointer(out screen, out x, out y, out modifierType);
		}

		// Token: 0x06000115 RID: 277 RVA: 0x00004DF0 File Offset: 0x00002FF0
		public Device[] ListDevices()
		{
			IntPtr intPtr = Display.gdk_display_list_devices(base.Handle);
			if (intPtr == IntPtr.Zero)
			{
				return new Device[0];
			}
			List list = new List(intPtr);
			Device[] array = new Device[list.Count];
			for (int i = 0; i < list.Count; i++)
			{
				array[i] = (list[i] as Device);
			}
			return array;
		}

		// Token: 0x06000116 RID: 278 RVA: 0x00004E56 File Offset: 0x00003056
		public Display(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000117 RID: 279 RVA: 0x00004E5F File Offset: 0x0000305F
		protected Display() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x14000003 RID: 3
		// (add) Token: 0x06000118 RID: 280 RVA: 0x00004E7E File Offset: 0x0000307E
		// (remove) Token: 0x06000119 RID: 281 RVA: 0x00004E96 File Offset: 0x00003096
		[Signal("seat-added")]
		public event SeatAddedHandler SeatAdded
		{
			add
			{
				base.AddSignalHandler("seat-added", value, typeof(SeatAddedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("seat-added", value);
			}
		}

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x0600011A RID: 282 RVA: 0x00004EA4 File Offset: 0x000030A4
		// (remove) Token: 0x0600011B RID: 283 RVA: 0x00004EBC File Offset: 0x000030BC
		[Signal("monitor-added")]
		public event MonitorAddedHandler MonitorAdded
		{
			add
			{
				base.AddSignalHandler("monitor-added", value, typeof(MonitorAddedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("monitor-added", value);
			}
		}

		// Token: 0x14000005 RID: 5
		// (add) Token: 0x0600011C RID: 284 RVA: 0x00004ECA File Offset: 0x000030CA
		// (remove) Token: 0x0600011D RID: 285 RVA: 0x00004EE2 File Offset: 0x000030E2
		[Signal("closed")]
		public event ClosedHandler Closed
		{
			add
			{
				base.AddSignalHandler("closed", value, typeof(ClosedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("closed", value);
			}
		}

		// Token: 0x14000006 RID: 6
		// (add) Token: 0x0600011E RID: 286 RVA: 0x00004EF0 File Offset: 0x000030F0
		// (remove) Token: 0x0600011F RID: 287 RVA: 0x00004EFE File Offset: 0x000030FE
		[Signal("opened")]
		public event EventHandler Opened
		{
			add
			{
				base.AddSignalHandler("opened", value);
			}
			remove
			{
				base.RemoveSignalHandler("opened", value);
			}
		}

		// Token: 0x14000007 RID: 7
		// (add) Token: 0x06000120 RID: 288 RVA: 0x00004F0C File Offset: 0x0000310C
		// (remove) Token: 0x06000121 RID: 289 RVA: 0x00004F24 File Offset: 0x00003124
		[Signal("seat-removed")]
		public event SeatRemovedHandler SeatRemoved
		{
			add
			{
				base.AddSignalHandler("seat-removed", value, typeof(SeatRemovedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("seat-removed", value);
			}
		}

		// Token: 0x14000008 RID: 8
		// (add) Token: 0x06000122 RID: 290 RVA: 0x00004F32 File Offset: 0x00003132
		// (remove) Token: 0x06000123 RID: 291 RVA: 0x00004F4A File Offset: 0x0000314A
		[Signal("monitor-removed")]
		public event MonitorRemovedHandler MonitorRemoved
		{
			add
			{
				base.AddSignalHandler("monitor-removed", value, typeof(MonitorRemovedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("monitor-removed", value);
			}
		}

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x06000124 RID: 292 RVA: 0x00004F58 File Offset: 0x00003158
		private static Display.SeatAddedNativeDelegate SeatAddedVMCallback
		{
			get
			{
				if (Display.SeatAdded_cb_delegate == null)
				{
					Display.SeatAdded_cb_delegate = new Display.SeatAddedNativeDelegate(Display.SeatAdded_cb);
				}
				return Display.SeatAdded_cb_delegate;
			}
		}

		// Token: 0x06000125 RID: 293 RVA: 0x00004F77 File Offset: 0x00003177
		private static void OverrideSeatAdded(GType gtype)
		{
			Display.OverrideSeatAdded(gtype, Display.SeatAddedVMCallback);
		}

		// Token: 0x06000126 RID: 294 RVA: 0x00004F84 File Offset: 0x00003184
		private static void OverrideSeatAdded(GType gtype, Display.SeatAddedNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "seat-added", callback);
		}

		// Token: 0x06000127 RID: 295 RVA: 0x00004F94 File Offset: 0x00003194
		private static void SeatAdded_cb(IntPtr inst, IntPtr p0)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnSeatAdded(Object.GetObject(p0) as Seat);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000128 RID: 296 RVA: 0x00004FD8 File Offset: 0x000031D8
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideSeatAdded")]
		protected virtual void OnSeatAdded(Seat p0)
		{
			this.InternalSeatAdded(p0);
		}

		// Token: 0x06000129 RID: 297 RVA: 0x00004FE4 File Offset: 0x000031E4
		private void InternalSeatAdded(Seat p0)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(2U);
			Value[] array = new Value[2];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(p0);
			valueArray.Append(array[1]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x0600012A RID: 298 RVA: 0x00005070 File Offset: 0x00003270
		private static Display.SeatRemovedNativeDelegate SeatRemovedVMCallback
		{
			get
			{
				if (Display.SeatRemoved_cb_delegate == null)
				{
					Display.SeatRemoved_cb_delegate = new Display.SeatRemovedNativeDelegate(Display.SeatRemoved_cb);
				}
				return Display.SeatRemoved_cb_delegate;
			}
		}

		// Token: 0x0600012B RID: 299 RVA: 0x0000508F File Offset: 0x0000328F
		private static void OverrideSeatRemoved(GType gtype)
		{
			Display.OverrideSeatRemoved(gtype, Display.SeatRemovedVMCallback);
		}

		// Token: 0x0600012C RID: 300 RVA: 0x0000509C File Offset: 0x0000329C
		private static void OverrideSeatRemoved(GType gtype, Display.SeatRemovedNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "seat-removed", callback);
		}

		// Token: 0x0600012D RID: 301 RVA: 0x000050AC File Offset: 0x000032AC
		private static void SeatRemoved_cb(IntPtr inst, IntPtr p0)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnSeatRemoved(Object.GetObject(p0) as Seat);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x0600012E RID: 302 RVA: 0x000050F0 File Offset: 0x000032F0
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideSeatRemoved")]
		protected virtual void OnSeatRemoved(Seat p0)
		{
			this.InternalSeatRemoved(p0);
		}

		// Token: 0x0600012F RID: 303 RVA: 0x000050FC File Offset: 0x000032FC
		private void InternalSeatRemoved(Seat p0)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(2U);
			Value[] array = new Value[2];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(p0);
			valueArray.Append(array[1]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x06000130 RID: 304 RVA: 0x00005188 File Offset: 0x00003388
		private static Display.MonitorAddedNativeDelegate MonitorAddedVMCallback
		{
			get
			{
				if (Display.MonitorAdded_cb_delegate == null)
				{
					Display.MonitorAdded_cb_delegate = new Display.MonitorAddedNativeDelegate(Display.MonitorAdded_cb);
				}
				return Display.MonitorAdded_cb_delegate;
			}
		}

		// Token: 0x06000131 RID: 305 RVA: 0x000051A7 File Offset: 0x000033A7
		private static void OverrideMonitorAdded(GType gtype)
		{
			Display.OverrideMonitorAdded(gtype, Display.MonitorAddedVMCallback);
		}

		// Token: 0x06000132 RID: 306 RVA: 0x000051B4 File Offset: 0x000033B4
		private static void OverrideMonitorAdded(GType gtype, Display.MonitorAddedNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "monitor-added", callback);
		}

		// Token: 0x06000133 RID: 307 RVA: 0x000051C4 File Offset: 0x000033C4
		private static void MonitorAdded_cb(IntPtr inst, IntPtr p0)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnMonitorAdded(Object.GetObject(p0) as Monitor);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000134 RID: 308 RVA: 0x00005208 File Offset: 0x00003408
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideMonitorAdded")]
		protected virtual void OnMonitorAdded(Monitor p0)
		{
			this.InternalMonitorAdded(p0);
		}

		// Token: 0x06000135 RID: 309 RVA: 0x00005214 File Offset: 0x00003414
		private void InternalMonitorAdded(Monitor p0)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(2U);
			Value[] array = new Value[2];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(p0);
			valueArray.Append(array[1]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x06000136 RID: 310 RVA: 0x000052A0 File Offset: 0x000034A0
		private static Display.MonitorRemovedNativeDelegate MonitorRemovedVMCallback
		{
			get
			{
				if (Display.MonitorRemoved_cb_delegate == null)
				{
					Display.MonitorRemoved_cb_delegate = new Display.MonitorRemovedNativeDelegate(Display.MonitorRemoved_cb);
				}
				return Display.MonitorRemoved_cb_delegate;
			}
		}

		// Token: 0x06000137 RID: 311 RVA: 0x000052BF File Offset: 0x000034BF
		private static void OverrideMonitorRemoved(GType gtype)
		{
			Display.OverrideMonitorRemoved(gtype, Display.MonitorRemovedVMCallback);
		}

		// Token: 0x06000138 RID: 312 RVA: 0x000052CC File Offset: 0x000034CC
		private static void OverrideMonitorRemoved(GType gtype, Display.MonitorRemovedNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "monitor-removed", callback);
		}

		// Token: 0x06000139 RID: 313 RVA: 0x000052DC File Offset: 0x000034DC
		private static void MonitorRemoved_cb(IntPtr inst, IntPtr p0)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnMonitorRemoved(Object.GetObject(p0) as Monitor);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x0600013A RID: 314 RVA: 0x00005320 File Offset: 0x00003520
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideMonitorRemoved")]
		protected virtual void OnMonitorRemoved(Monitor p0)
		{
			this.InternalMonitorRemoved(p0);
		}

		// Token: 0x0600013B RID: 315 RVA: 0x0000532C File Offset: 0x0000352C
		private void InternalMonitorRemoved(Monitor p0)
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(2U);
			Value[] array = new Value[2];
			array[0] = new Value(this);
			valueArray.Append(array[0]);
			array[1] = new Value(p0);
			valueArray.Append(array[1]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x0600013C RID: 316 RVA: 0x000053B8 File Offset: 0x000035B8
		private static Display.GetNameNativeDelegate GetNameVMCallback
		{
			get
			{
				if (Display.GetName_cb_delegate == null)
				{
					Display.GetName_cb_delegate = new Display.GetNameNativeDelegate(Display.GetName_cb);
				}
				return Display.GetName_cb_delegate;
			}
		}

		// Token: 0x0600013D RID: 317 RVA: 0x000053D7 File Offset: 0x000035D7
		private static void OverrideGetName(GType gtype)
		{
			Display.OverrideGetName(gtype, Display.GetNameVMCallback);
		}

		// Token: 0x0600013E RID: 318 RVA: 0x000053E4 File Offset: 0x000035E4
		private unsafe static void OverrideGetName(GType gtype, Display.GetNameNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("get_name");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600013F RID: 319 RVA: 0x00005418 File Offset: 0x00003618
		private static IntPtr GetName_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				result = Marshaller.StringToPtrGStrdup((Object.GetObject(inst, false) as Display).OnGetName());
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000140 RID: 320 RVA: 0x00005458 File Offset: 0x00003658
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideGetName")]
		protected virtual string OnGetName()
		{
			return this.InternalGetName();
		}

		// Token: 0x06000141 RID: 321 RVA: 0x00005460 File Offset: 0x00003660
		private string InternalGetName()
		{
			Display.GetNameNativeDelegate getNameNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "get_name");
			if (getNameNativeDelegate == null)
			{
				return null;
			}
			return Marshaller.PtrToStringGFree(getNameNativeDelegate(base.Handle));
		}

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x06000142 RID: 322 RVA: 0x00005499 File Offset: 0x00003699
		private static Display.GetDefaultScreenNativeDelegate GetDefaultScreenVMCallback
		{
			get
			{
				if (Display.GetDefaultScreen_cb_delegate == null)
				{
					Display.GetDefaultScreen_cb_delegate = new Display.GetDefaultScreenNativeDelegate(Display.GetDefaultScreen_cb);
				}
				return Display.GetDefaultScreen_cb_delegate;
			}
		}

		// Token: 0x06000143 RID: 323 RVA: 0x000054B8 File Offset: 0x000036B8
		private static void OverrideGetDefaultScreen(GType gtype)
		{
			Display.OverrideGetDefaultScreen(gtype, Display.GetDefaultScreenVMCallback);
		}

		// Token: 0x06000144 RID: 324 RVA: 0x000054C8 File Offset: 0x000036C8
		private unsafe static void OverrideGetDefaultScreen(GType gtype, Display.GetDefaultScreenNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("get_default_screen");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000145 RID: 325 RVA: 0x000054FC File Offset: 0x000036FC
		private static IntPtr GetDefaultScreen_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				Screen screen = (Object.GetObject(inst, false) as Display).OnGetDefaultScreen();
				result = ((screen == null) ? IntPtr.Zero : screen.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000146 RID: 326 RVA: 0x00005548 File Offset: 0x00003748
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideGetDefaultScreen")]
		protected virtual Screen OnGetDefaultScreen()
		{
			return this.InternalGetDefaultScreen();
		}

		// Token: 0x06000147 RID: 327 RVA: 0x00005550 File Offset: 0x00003750
		private Screen InternalGetDefaultScreen()
		{
			Display.GetDefaultScreenNativeDelegate getDefaultScreenNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "get_default_screen");
			if (getDefaultScreenNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getDefaultScreenNativeDelegate(base.Handle)) as Screen;
		}

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x06000148 RID: 328 RVA: 0x0000558E File Offset: 0x0000378E
		private static Display.BeepNativeDelegate BeepVMCallback
		{
			get
			{
				if (Display.Beep_cb_delegate == null)
				{
					Display.Beep_cb_delegate = new Display.BeepNativeDelegate(Display.Beep_cb);
				}
				return Display.Beep_cb_delegate;
			}
		}

		// Token: 0x06000149 RID: 329 RVA: 0x000055AD File Offset: 0x000037AD
		private static void OverrideBeep(GType gtype)
		{
			Display.OverrideBeep(gtype, Display.BeepVMCallback);
		}

		// Token: 0x0600014A RID: 330 RVA: 0x000055BC File Offset: 0x000037BC
		private unsafe static void OverrideBeep(GType gtype, Display.BeepNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("beep");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600014B RID: 331 RVA: 0x000055F0 File Offset: 0x000037F0
		private static void Beep_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnBeep();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x0600014C RID: 332 RVA: 0x00005628 File Offset: 0x00003828
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideBeep")]
		protected virtual void OnBeep()
		{
			this.InternalBeep();
		}

		// Token: 0x0600014D RID: 333 RVA: 0x00005630 File Offset: 0x00003830
		private void InternalBeep()
		{
			Display.BeepNativeDelegate beepNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "beep");
			if (beepNativeDelegate == null)
			{
				return;
			}
			beepNativeDelegate(base.Handle);
		}

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x0600014E RID: 334 RVA: 0x00005663 File Offset: 0x00003863
		private static Display.SyncNativeDelegate SyncVMCallback
		{
			get
			{
				if (Display.Sync_cb_delegate == null)
				{
					Display.Sync_cb_delegate = new Display.SyncNativeDelegate(Display.Sync_cb);
				}
				return Display.Sync_cb_delegate;
			}
		}

		// Token: 0x0600014F RID: 335 RVA: 0x00005682 File Offset: 0x00003882
		private static void OverrideSync(GType gtype)
		{
			Display.OverrideSync(gtype, Display.SyncVMCallback);
		}

		// Token: 0x06000150 RID: 336 RVA: 0x00005690 File Offset: 0x00003890
		private unsafe static void OverrideSync(GType gtype, Display.SyncNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("sync");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000151 RID: 337 RVA: 0x000056C4 File Offset: 0x000038C4
		private static void Sync_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnSync();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000152 RID: 338 RVA: 0x000056FC File Offset: 0x000038FC
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideSync")]
		protected virtual void OnSync()
		{
			this.InternalSync();
		}

		// Token: 0x06000153 RID: 339 RVA: 0x00005704 File Offset: 0x00003904
		private void InternalSync()
		{
			Display.SyncNativeDelegate syncNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "sync");
			if (syncNativeDelegate == null)
			{
				return;
			}
			syncNativeDelegate(base.Handle);
		}

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x06000154 RID: 340 RVA: 0x00005737 File Offset: 0x00003937
		private static Display.FlushNativeDelegate FlushVMCallback
		{
			get
			{
				if (Display.Flush_cb_delegate == null)
				{
					Display.Flush_cb_delegate = new Display.FlushNativeDelegate(Display.Flush_cb);
				}
				return Display.Flush_cb_delegate;
			}
		}

		// Token: 0x06000155 RID: 341 RVA: 0x00005756 File Offset: 0x00003956
		private static void OverrideFlush(GType gtype)
		{
			Display.OverrideFlush(gtype, Display.FlushVMCallback);
		}

		// Token: 0x06000156 RID: 342 RVA: 0x00005764 File Offset: 0x00003964
		private unsafe static void OverrideFlush(GType gtype, Display.FlushNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("flush");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000157 RID: 343 RVA: 0x00005798 File Offset: 0x00003998
		private static void Flush_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnFlush();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000158 RID: 344 RVA: 0x000057D0 File Offset: 0x000039D0
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideFlush")]
		protected virtual void OnFlush()
		{
			this.InternalFlush();
		}

		// Token: 0x06000159 RID: 345 RVA: 0x000057D8 File Offset: 0x000039D8
		private void InternalFlush()
		{
			Display.FlushNativeDelegate flushNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "flush");
			if (flushNativeDelegate == null)
			{
				return;
			}
			flushNativeDelegate(base.Handle);
		}

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x0600015A RID: 346 RVA: 0x0000580B File Offset: 0x00003A0B
		private static Display.HasPendingNativeDelegate HasPendingVMCallback
		{
			get
			{
				if (Display.HasPending_cb_delegate == null)
				{
					Display.HasPending_cb_delegate = new Display.HasPendingNativeDelegate(Display.HasPending_cb);
				}
				return Display.HasPending_cb_delegate;
			}
		}

		// Token: 0x0600015B RID: 347 RVA: 0x0000582A File Offset: 0x00003A2A
		private static void OverrideHasPending(GType gtype)
		{
			Display.OverrideHasPending(gtype, Display.HasPendingVMCallback);
		}

		// Token: 0x0600015C RID: 348 RVA: 0x00005838 File Offset: 0x00003A38
		private unsafe static void OverrideHasPending(GType gtype, Display.HasPendingNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("has_pending");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600015D RID: 349 RVA: 0x0000586C File Offset: 0x00003A6C
		private static bool HasPending_cb(IntPtr inst)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Display).OnHasPending();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600015E RID: 350 RVA: 0x000058A8 File Offset: 0x00003AA8
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideHasPending")]
		protected virtual bool OnHasPending()
		{
			return this.InternalHasPending();
		}

		// Token: 0x0600015F RID: 351 RVA: 0x000058B0 File Offset: 0x00003AB0
		private bool InternalHasPending()
		{
			Display.HasPendingNativeDelegate hasPendingNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "has_pending");
			return hasPendingNativeDelegate != null && hasPendingNativeDelegate(base.Handle);
		}

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x06000160 RID: 352 RVA: 0x000058E4 File Offset: 0x00003AE4
		private static Display.QueueEventsNativeDelegate QueueEventsVMCallback
		{
			get
			{
				if (Display.QueueEvents_cb_delegate == null)
				{
					Display.QueueEvents_cb_delegate = new Display.QueueEventsNativeDelegate(Display.QueueEvents_cb);
				}
				return Display.QueueEvents_cb_delegate;
			}
		}

		// Token: 0x06000161 RID: 353 RVA: 0x00005903 File Offset: 0x00003B03
		private static void OverrideQueueEvents(GType gtype)
		{
			Display.OverrideQueueEvents(gtype, Display.QueueEventsVMCallback);
		}

		// Token: 0x06000162 RID: 354 RVA: 0x00005910 File Offset: 0x00003B10
		private unsafe static void OverrideQueueEvents(GType gtype, Display.QueueEventsNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("queue_events");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000163 RID: 355 RVA: 0x00005944 File Offset: 0x00003B44
		private static void QueueEvents_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnQueueEvents();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000164 RID: 356 RVA: 0x0000597C File Offset: 0x00003B7C
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideQueueEvents")]
		protected virtual void OnQueueEvents()
		{
			this.InternalQueueEvents();
		}

		// Token: 0x06000165 RID: 357 RVA: 0x00005984 File Offset: 0x00003B84
		private void InternalQueueEvents()
		{
			Display.QueueEventsNativeDelegate queueEventsNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "queue_events");
			if (queueEventsNativeDelegate == null)
			{
				return;
			}
			queueEventsNativeDelegate(base.Handle);
		}

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x06000166 RID: 358 RVA: 0x000059B7 File Offset: 0x00003BB7
		private static Display.MakeDefaultNativeDelegate MakeDefaultVMCallback
		{
			get
			{
				if (Display.MakeDefault_cb_delegate == null)
				{
					Display.MakeDefault_cb_delegate = new Display.MakeDefaultNativeDelegate(Display.MakeDefault_cb);
				}
				return Display.MakeDefault_cb_delegate;
			}
		}

		// Token: 0x06000167 RID: 359 RVA: 0x000059D6 File Offset: 0x00003BD6
		private static void OverrideMakeDefault(GType gtype)
		{
			Display.OverrideMakeDefault(gtype, Display.MakeDefaultVMCallback);
		}

		// Token: 0x06000168 RID: 360 RVA: 0x000059E4 File Offset: 0x00003BE4
		private unsafe static void OverrideMakeDefault(GType gtype, Display.MakeDefaultNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("make_default");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000169 RID: 361 RVA: 0x00005A18 File Offset: 0x00003C18
		private static void MakeDefault_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnMakeDefault();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x0600016A RID: 362 RVA: 0x00005A50 File Offset: 0x00003C50
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideMakeDefault")]
		protected virtual void OnMakeDefault()
		{
			this.InternalMakeDefault();
		}

		// Token: 0x0600016B RID: 363 RVA: 0x00005A58 File Offset: 0x00003C58
		private void InternalMakeDefault()
		{
			Display.MakeDefaultNativeDelegate makeDefaultNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "make_default");
			if (makeDefaultNativeDelegate == null)
			{
				return;
			}
			makeDefaultNativeDelegate(base.Handle);
		}

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x0600016C RID: 364 RVA: 0x00005A8B File Offset: 0x00003C8B
		private static Display.GetDefaultGroupNativeDelegate GetDefaultGroupVMCallback
		{
			get
			{
				if (Display.GetDefaultGroup_cb_delegate == null)
				{
					Display.GetDefaultGroup_cb_delegate = new Display.GetDefaultGroupNativeDelegate(Display.GetDefaultGroup_cb);
				}
				return Display.GetDefaultGroup_cb_delegate;
			}
		}

		// Token: 0x0600016D RID: 365 RVA: 0x00005AAA File Offset: 0x00003CAA
		private static void OverrideGetDefaultGroup(GType gtype)
		{
			Display.OverrideGetDefaultGroup(gtype, Display.GetDefaultGroupVMCallback);
		}

		// Token: 0x0600016E RID: 366 RVA: 0x00005AB8 File Offset: 0x00003CB8
		private unsafe static void OverrideGetDefaultGroup(GType gtype, Display.GetDefaultGroupNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("get_default_group");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600016F RID: 367 RVA: 0x00005AEC File Offset: 0x00003CEC
		private static IntPtr GetDefaultGroup_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				Window window = (Object.GetObject(inst, false) as Display).OnGetDefaultGroup();
				result = ((window == null) ? IntPtr.Zero : window.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000170 RID: 368 RVA: 0x00005B38 File Offset: 0x00003D38
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideGetDefaultGroup")]
		protected virtual Window OnGetDefaultGroup()
		{
			return this.InternalGetDefaultGroup();
		}

		// Token: 0x06000171 RID: 369 RVA: 0x00005B40 File Offset: 0x00003D40
		private Window InternalGetDefaultGroup()
		{
			Display.GetDefaultGroupNativeDelegate getDefaultGroupNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "get_default_group");
			if (getDefaultGroupNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getDefaultGroupNativeDelegate(base.Handle)) as Window;
		}

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x06000172 RID: 370 RVA: 0x00005B7E File Offset: 0x00003D7E
		private static Display.SupportsSelectionNotificationNativeDelegate SupportsSelectionNotificationVMCallback
		{
			get
			{
				if (Display.SupportsSelectionNotification_cb_delegate == null)
				{
					Display.SupportsSelectionNotification_cb_delegate = new Display.SupportsSelectionNotificationNativeDelegate(Display.SupportsSelectionNotification_cb);
				}
				return Display.SupportsSelectionNotification_cb_delegate;
			}
		}

		// Token: 0x06000173 RID: 371 RVA: 0x00005B9D File Offset: 0x00003D9D
		private static void OverrideSupportsSelectionNotification(GType gtype)
		{
			Display.OverrideSupportsSelectionNotification(gtype, Display.SupportsSelectionNotificationVMCallback);
		}

		// Token: 0x06000174 RID: 372 RVA: 0x00005BAC File Offset: 0x00003DAC
		private unsafe static void OverrideSupportsSelectionNotification(GType gtype, Display.SupportsSelectionNotificationNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("supports_selection_notification");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000175 RID: 373 RVA: 0x00005BE0 File Offset: 0x00003DE0
		private static bool SupportsSelectionNotification_cb(IntPtr inst)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Display).OnSupportsSelectionNotification();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000176 RID: 374 RVA: 0x00005C1C File Offset: 0x00003E1C
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideSupportsSelectionNotification")]
		protected virtual bool OnSupportsSelectionNotification()
		{
			return this.InternalSupportsSelectionNotification();
		}

		// Token: 0x06000177 RID: 375 RVA: 0x00005C24 File Offset: 0x00003E24
		private bool InternalSupportsSelectionNotification()
		{
			Display.SupportsSelectionNotificationNativeDelegate supportsSelectionNotificationNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "supports_selection_notification");
			return supportsSelectionNotificationNativeDelegate != null && supportsSelectionNotificationNativeDelegate(base.Handle);
		}

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x06000178 RID: 376 RVA: 0x00005C58 File Offset: 0x00003E58
		private static Display.RequestSelectionNotificationNativeDelegate RequestSelectionNotificationVMCallback
		{
			get
			{
				if (Display.RequestSelectionNotification_cb_delegate == null)
				{
					Display.RequestSelectionNotification_cb_delegate = new Display.RequestSelectionNotificationNativeDelegate(Display.RequestSelectionNotification_cb);
				}
				return Display.RequestSelectionNotification_cb_delegate;
			}
		}

		// Token: 0x06000179 RID: 377 RVA: 0x00005C77 File Offset: 0x00003E77
		private static void OverrideRequestSelectionNotification(GType gtype)
		{
			Display.OverrideRequestSelectionNotification(gtype, Display.RequestSelectionNotificationVMCallback);
		}

		// Token: 0x0600017A RID: 378 RVA: 0x00005C84 File Offset: 0x00003E84
		private unsafe static void OverrideRequestSelectionNotification(GType gtype, Display.RequestSelectionNotificationNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("request_selection_notification");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600017B RID: 379 RVA: 0x00005CB8 File Offset: 0x00003EB8
		private static bool RequestSelectionNotification_cb(IntPtr inst, IntPtr selection)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Display).OnRequestSelectionNotification((selection == IntPtr.Zero) ? null : ((Atom)Opaque.GetOpaque(selection, typeof(Atom), false)));
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600017C RID: 380 RVA: 0x00005D18 File Offset: 0x00003F18
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideRequestSelectionNotification")]
		protected virtual bool OnRequestSelectionNotification(Atom selection)
		{
			return this.InternalRequestSelectionNotification(selection);
		}

		// Token: 0x0600017D RID: 381 RVA: 0x00005D24 File Offset: 0x00003F24
		private bool InternalRequestSelectionNotification(Atom selection)
		{
			Display.RequestSelectionNotificationNativeDelegate requestSelectionNotificationNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "request_selection_notification");
			return requestSelectionNotificationNativeDelegate != null && requestSelectionNotificationNativeDelegate(base.Handle, (selection == null) ? IntPtr.Zero : selection.Handle);
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x0600017E RID: 382 RVA: 0x00005D68 File Offset: 0x00003F68
		private static Display.SupportsShapesNativeDelegate SupportsShapesVMCallback
		{
			get
			{
				if (Display.SupportsShapes_cb_delegate == null)
				{
					Display.SupportsShapes_cb_delegate = new Display.SupportsShapesNativeDelegate(Display.SupportsShapes_cb);
				}
				return Display.SupportsShapes_cb_delegate;
			}
		}

		// Token: 0x0600017F RID: 383 RVA: 0x00005D87 File Offset: 0x00003F87
		private static void OverrideSupportsShapes(GType gtype)
		{
			Display.OverrideSupportsShapes(gtype, Display.SupportsShapesVMCallback);
		}

		// Token: 0x06000180 RID: 384 RVA: 0x00005D94 File Offset: 0x00003F94
		private unsafe static void OverrideSupportsShapes(GType gtype, Display.SupportsShapesNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("supports_shapes");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000181 RID: 385 RVA: 0x00005DC8 File Offset: 0x00003FC8
		private static bool SupportsShapes_cb(IntPtr inst)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Display).OnSupportsShapes();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000182 RID: 386 RVA: 0x00005E04 File Offset: 0x00004004
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideSupportsShapes")]
		protected virtual bool OnSupportsShapes()
		{
			return this.InternalSupportsShapes();
		}

		// Token: 0x06000183 RID: 387 RVA: 0x00005E0C File Offset: 0x0000400C
		private bool InternalSupportsShapes()
		{
			Display.SupportsShapesNativeDelegate supportsShapesNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "supports_shapes");
			return supportsShapesNativeDelegate != null && supportsShapesNativeDelegate(base.Handle);
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x06000184 RID: 388 RVA: 0x00005E40 File Offset: 0x00004040
		private static Display.SupportsInputShapesNativeDelegate SupportsInputShapesVMCallback
		{
			get
			{
				if (Display.SupportsInputShapes_cb_delegate == null)
				{
					Display.SupportsInputShapes_cb_delegate = new Display.SupportsInputShapesNativeDelegate(Display.SupportsInputShapes_cb);
				}
				return Display.SupportsInputShapes_cb_delegate;
			}
		}

		// Token: 0x06000185 RID: 389 RVA: 0x00005E5F File Offset: 0x0000405F
		private static void OverrideSupportsInputShapes(GType gtype)
		{
			Display.OverrideSupportsInputShapes(gtype, Display.SupportsInputShapesVMCallback);
		}

		// Token: 0x06000186 RID: 390 RVA: 0x00005E6C File Offset: 0x0000406C
		private unsafe static void OverrideSupportsInputShapes(GType gtype, Display.SupportsInputShapesNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("supports_input_shapes");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000187 RID: 391 RVA: 0x00005EA0 File Offset: 0x000040A0
		private static bool SupportsInputShapes_cb(IntPtr inst)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Display).OnSupportsInputShapes();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000188 RID: 392 RVA: 0x00005EDC File Offset: 0x000040DC
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideSupportsInputShapes")]
		protected virtual bool OnSupportsInputShapes()
		{
			return this.InternalSupportsInputShapes();
		}

		// Token: 0x06000189 RID: 393 RVA: 0x00005EE4 File Offset: 0x000040E4
		private bool InternalSupportsInputShapes()
		{
			Display.SupportsInputShapesNativeDelegate supportsInputShapesNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "supports_input_shapes");
			return supportsInputShapesNativeDelegate != null && supportsInputShapesNativeDelegate(base.Handle);
		}

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x0600018A RID: 394 RVA: 0x00005F18 File Offset: 0x00004118
		private static Display.SupportsCompositeNativeDelegate SupportsCompositeVMCallback
		{
			get
			{
				if (Display.SupportsComposite_cb_delegate == null)
				{
					Display.SupportsComposite_cb_delegate = new Display.SupportsCompositeNativeDelegate(Display.SupportsComposite_cb);
				}
				return Display.SupportsComposite_cb_delegate;
			}
		}

		// Token: 0x0600018B RID: 395 RVA: 0x00005F37 File Offset: 0x00004137
		private static void OverrideSupportsComposite(GType gtype)
		{
			Display.OverrideSupportsComposite(gtype, Display.SupportsCompositeVMCallback);
		}

		// Token: 0x0600018C RID: 396 RVA: 0x00005F44 File Offset: 0x00004144
		private unsafe static void OverrideSupportsComposite(GType gtype, Display.SupportsCompositeNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("supports_composite");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600018D RID: 397 RVA: 0x00005F78 File Offset: 0x00004178
		private static bool SupportsComposite_cb(IntPtr inst)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Display).OnSupportsComposite();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600018E RID: 398 RVA: 0x00005FB4 File Offset: 0x000041B4
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideSupportsComposite")]
		protected virtual bool OnSupportsComposite()
		{
			return this.InternalSupportsComposite();
		}

		// Token: 0x0600018F RID: 399 RVA: 0x00005FBC File Offset: 0x000041BC
		private bool InternalSupportsComposite()
		{
			Display.SupportsCompositeNativeDelegate supportsCompositeNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "supports_composite");
			return supportsCompositeNativeDelegate != null && supportsCompositeNativeDelegate(base.Handle);
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x06000190 RID: 400 RVA: 0x00005FF0 File Offset: 0x000041F0
		private static Display.SupportsCursorAlphaNativeDelegate SupportsCursorAlphaVMCallback
		{
			get
			{
				if (Display.SupportsCursorAlpha_cb_delegate == null)
				{
					Display.SupportsCursorAlpha_cb_delegate = new Display.SupportsCursorAlphaNativeDelegate(Display.SupportsCursorAlpha_cb);
				}
				return Display.SupportsCursorAlpha_cb_delegate;
			}
		}

		// Token: 0x06000191 RID: 401 RVA: 0x0000600F File Offset: 0x0000420F
		private static void OverrideSupportsCursorAlpha(GType gtype)
		{
			Display.OverrideSupportsCursorAlpha(gtype, Display.SupportsCursorAlphaVMCallback);
		}

		// Token: 0x06000192 RID: 402 RVA: 0x0000601C File Offset: 0x0000421C
		private unsafe static void OverrideSupportsCursorAlpha(GType gtype, Display.SupportsCursorAlphaNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("supports_cursor_alpha");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000193 RID: 403 RVA: 0x00006050 File Offset: 0x00004250
		private static bool SupportsCursorAlpha_cb(IntPtr inst)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Display).OnSupportsCursorAlpha();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000194 RID: 404 RVA: 0x0000608C File Offset: 0x0000428C
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideSupportsCursorAlpha")]
		protected virtual bool OnSupportsCursorAlpha()
		{
			return this.InternalSupportsCursorAlpha();
		}

		// Token: 0x06000195 RID: 405 RVA: 0x00006094 File Offset: 0x00004294
		private bool InternalSupportsCursorAlpha()
		{
			Display.SupportsCursorAlphaNativeDelegate supportsCursorAlphaNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "supports_cursor_alpha");
			return supportsCursorAlphaNativeDelegate != null && supportsCursorAlphaNativeDelegate(base.Handle);
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x06000196 RID: 406 RVA: 0x000060C8 File Offset: 0x000042C8
		private static Display.SupportsCursorColorNativeDelegate SupportsCursorColorVMCallback
		{
			get
			{
				if (Display.SupportsCursorColor_cb_delegate == null)
				{
					Display.SupportsCursorColor_cb_delegate = new Display.SupportsCursorColorNativeDelegate(Display.SupportsCursorColor_cb);
				}
				return Display.SupportsCursorColor_cb_delegate;
			}
		}

		// Token: 0x06000197 RID: 407 RVA: 0x000060E7 File Offset: 0x000042E7
		private static void OverrideSupportsCursorColor(GType gtype)
		{
			Display.OverrideSupportsCursorColor(gtype, Display.SupportsCursorColorVMCallback);
		}

		// Token: 0x06000198 RID: 408 RVA: 0x000060F4 File Offset: 0x000042F4
		private unsafe static void OverrideSupportsCursorColor(GType gtype, Display.SupportsCursorColorNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("supports_cursor_color");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000199 RID: 409 RVA: 0x00006128 File Offset: 0x00004328
		private static bool SupportsCursorColor_cb(IntPtr inst)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Display).OnSupportsCursorColor();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600019A RID: 410 RVA: 0x00006164 File Offset: 0x00004364
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideSupportsCursorColor")]
		protected virtual bool OnSupportsCursorColor()
		{
			return this.InternalSupportsCursorColor();
		}

		// Token: 0x0600019B RID: 411 RVA: 0x0000616C File Offset: 0x0000436C
		private bool InternalSupportsCursorColor()
		{
			Display.SupportsCursorColorNativeDelegate supportsCursorColorNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "supports_cursor_color");
			return supportsCursorColorNativeDelegate != null && supportsCursorColorNativeDelegate(base.Handle);
		}

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x0600019C RID: 412 RVA: 0x000061A0 File Offset: 0x000043A0
		private static Display.SupportsClipboardPersistenceNativeDelegate SupportsClipboardPersistenceVMCallback
		{
			get
			{
				if (Display.SupportsClipboardPersistence_cb_delegate == null)
				{
					Display.SupportsClipboardPersistence_cb_delegate = new Display.SupportsClipboardPersistenceNativeDelegate(Display.SupportsClipboardPersistence_cb);
				}
				return Display.SupportsClipboardPersistence_cb_delegate;
			}
		}

		// Token: 0x0600019D RID: 413 RVA: 0x000061BF File Offset: 0x000043BF
		private static void OverrideSupportsClipboardPersistence(GType gtype)
		{
			Display.OverrideSupportsClipboardPersistence(gtype, Display.SupportsClipboardPersistenceVMCallback);
		}

		// Token: 0x0600019E RID: 414 RVA: 0x000061CC File Offset: 0x000043CC
		private unsafe static void OverrideSupportsClipboardPersistence(GType gtype, Display.SupportsClipboardPersistenceNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("supports_clipboard_persistence");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600019F RID: 415 RVA: 0x00006200 File Offset: 0x00004400
		private static bool SupportsClipboardPersistence_cb(IntPtr inst)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Display).OnSupportsClipboardPersistence();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060001A0 RID: 416 RVA: 0x0000623C File Offset: 0x0000443C
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideSupportsClipboardPersistence")]
		protected virtual bool OnSupportsClipboardPersistence()
		{
			return this.InternalSupportsClipboardPersistence();
		}

		// Token: 0x060001A1 RID: 417 RVA: 0x00006244 File Offset: 0x00004444
		private bool InternalSupportsClipboardPersistence()
		{
			Display.SupportsClipboardPersistenceNativeDelegate supportsClipboardPersistenceNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "supports_clipboard_persistence");
			return supportsClipboardPersistenceNativeDelegate != null && supportsClipboardPersistenceNativeDelegate(base.Handle);
		}

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x060001A2 RID: 418 RVA: 0x00006278 File Offset: 0x00004478
		private static Display.StoreClipboardNativeDelegate StoreClipboardVMCallback
		{
			get
			{
				if (Display.StoreClipboard_cb_delegate == null)
				{
					Display.StoreClipboard_cb_delegate = new Display.StoreClipboardNativeDelegate(Display.StoreClipboard_cb);
				}
				return Display.StoreClipboard_cb_delegate;
			}
		}

		// Token: 0x060001A3 RID: 419 RVA: 0x00006297 File Offset: 0x00004497
		private static void OverrideStoreClipboard(GType gtype)
		{
			Display.OverrideStoreClipboard(gtype, Display.StoreClipboardVMCallback);
		}

		// Token: 0x060001A4 RID: 420 RVA: 0x000062A4 File Offset: 0x000044A4
		private unsafe static void OverrideStoreClipboard(GType gtype, Display.StoreClipboardNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("store_clipboard");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060001A5 RID: 421 RVA: 0x000062D8 File Offset: 0x000044D8
		private static void StoreClipboard_cb(IntPtr inst, IntPtr clipboard_window, uint time_, IntPtr targets, int n_targets)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnStoreClipboard(Object.GetObject(clipboard_window) as Window, time_, (targets == IntPtr.Zero) ? null : ((Atom)Opaque.GetOpaque(targets, typeof(Atom), false)), n_targets);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060001A6 RID: 422 RVA: 0x00006344 File Offset: 0x00004544
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideStoreClipboard")]
		protected virtual void OnStoreClipboard(Window clipboard_window, uint time_, Atom targets, int n_targets)
		{
			this.InternalStoreClipboard(clipboard_window, time_, targets, n_targets);
		}

		// Token: 0x060001A7 RID: 423 RVA: 0x00006354 File Offset: 0x00004554
		private void InternalStoreClipboard(Window clipboard_window, uint time_, Atom targets, int n_targets)
		{
			Display.StoreClipboardNativeDelegate storeClipboardNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "store_clipboard");
			if (storeClipboardNativeDelegate == null)
			{
				return;
			}
			storeClipboardNativeDelegate(base.Handle, (clipboard_window == null) ? IntPtr.Zero : clipboard_window.Handle, time_, (targets == null) ? IntPtr.Zero : targets.Handle, n_targets);
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x060001A8 RID: 424 RVA: 0x000063AA File Offset: 0x000045AA
		private static Display.GetDefaultCursorSizeNativeDelegate GetDefaultCursorSizeVMCallback
		{
			get
			{
				if (Display.GetDefaultCursorSize_cb_delegate == null)
				{
					Display.GetDefaultCursorSize_cb_delegate = new Display.GetDefaultCursorSizeNativeDelegate(Display.GetDefaultCursorSize_cb);
				}
				return Display.GetDefaultCursorSize_cb_delegate;
			}
		}

		// Token: 0x060001A9 RID: 425 RVA: 0x000063C9 File Offset: 0x000045C9
		private static void OverrideGetDefaultCursorSize(GType gtype)
		{
			Display.OverrideGetDefaultCursorSize(gtype, Display.GetDefaultCursorSizeVMCallback);
		}

		// Token: 0x060001AA RID: 426 RVA: 0x000063D8 File Offset: 0x000045D8
		private unsafe static void OverrideGetDefaultCursorSize(GType gtype, Display.GetDefaultCursorSizeNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("get_default_cursor_size");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060001AB RID: 427 RVA: 0x0000640C File Offset: 0x0000460C
		private static void GetDefaultCursorSize_cb(IntPtr inst, out uint width, out uint height)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnGetDefaultCursorSize(out width, out height);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
		}

		// Token: 0x060001AC RID: 428 RVA: 0x00006448 File Offset: 0x00004648
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideGetDefaultCursorSize")]
		protected virtual void OnGetDefaultCursorSize(out uint width, out uint height)
		{
			this.InternalGetDefaultCursorSize(out width, out height);
		}

		// Token: 0x060001AD RID: 429 RVA: 0x00006452 File Offset: 0x00004652
		private void InternalGetDefaultCursorSize(out uint width, out uint height)
		{
			Display.GetDefaultCursorSizeNativeDelegate getDefaultCursorSizeNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "get_default_cursor_size");
			if (getDefaultCursorSizeNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			getDefaultCursorSizeNativeDelegate(base.Handle, out width, out height);
		}

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x060001AE RID: 430 RVA: 0x00006484 File Offset: 0x00004684
		private static Display.GetMaximalCursorSizeNativeDelegate GetMaximalCursorSizeVMCallback
		{
			get
			{
				if (Display.GetMaximalCursorSize_cb_delegate == null)
				{
					Display.GetMaximalCursorSize_cb_delegate = new Display.GetMaximalCursorSizeNativeDelegate(Display.GetMaximalCursorSize_cb);
				}
				return Display.GetMaximalCursorSize_cb_delegate;
			}
		}

		// Token: 0x060001AF RID: 431 RVA: 0x000064A3 File Offset: 0x000046A3
		private static void OverrideGetMaximalCursorSize(GType gtype)
		{
			Display.OverrideGetMaximalCursorSize(gtype, Display.GetMaximalCursorSizeVMCallback);
		}

		// Token: 0x060001B0 RID: 432 RVA: 0x000064B0 File Offset: 0x000046B0
		private unsafe static void OverrideGetMaximalCursorSize(GType gtype, Display.GetMaximalCursorSizeNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("get_maximal_cursor_size");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060001B1 RID: 433 RVA: 0x000064E4 File Offset: 0x000046E4
		private static void GetMaximalCursorSize_cb(IntPtr inst, out uint width, out uint height)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnGetMaximalCursorSize(out width, out height);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
		}

		// Token: 0x060001B2 RID: 434 RVA: 0x00006520 File Offset: 0x00004720
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideGetMaximalCursorSize")]
		protected virtual void OnGetMaximalCursorSize(out uint width, out uint height)
		{
			this.InternalGetMaximalCursorSize(out width, out height);
		}

		// Token: 0x060001B3 RID: 435 RVA: 0x0000652A File Offset: 0x0000472A
		private void InternalGetMaximalCursorSize(out uint width, out uint height)
		{
			Display.GetMaximalCursorSizeNativeDelegate getMaximalCursorSizeNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "get_maximal_cursor_size");
			if (getMaximalCursorSizeNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			getMaximalCursorSizeNativeDelegate(base.Handle, out width, out height);
		}

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x060001B4 RID: 436 RVA: 0x0000655C File Offset: 0x0000475C
		private static Display.GetCursorForTypeNativeDelegate GetCursorForTypeVMCallback
		{
			get
			{
				if (Display.GetCursorForType_cb_delegate == null)
				{
					Display.GetCursorForType_cb_delegate = new Display.GetCursorForTypeNativeDelegate(Display.GetCursorForType_cb);
				}
				return Display.GetCursorForType_cb_delegate;
			}
		}

		// Token: 0x060001B5 RID: 437 RVA: 0x0000657B File Offset: 0x0000477B
		private static void OverrideGetCursorForType(GType gtype)
		{
			Display.OverrideGetCursorForType(gtype, Display.GetCursorForTypeVMCallback);
		}

		// Token: 0x060001B6 RID: 438 RVA: 0x00006588 File Offset: 0x00004788
		private unsafe static void OverrideGetCursorForType(GType gtype, Display.GetCursorForTypeNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("get_cursor_for_type");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060001B7 RID: 439 RVA: 0x000065BC File Offset: 0x000047BC
		private static IntPtr GetCursorForType_cb(IntPtr inst, int type)
		{
			IntPtr result;
			try
			{
				Cursor cursor = (Object.GetObject(inst, false) as Display).OnGetCursorForType((CursorType)type);
				result = ((cursor == null) ? IntPtr.Zero : cursor.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060001B8 RID: 440 RVA: 0x00006608 File Offset: 0x00004808
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideGetCursorForType")]
		protected virtual Cursor OnGetCursorForType(CursorType type)
		{
			return this.InternalGetCursorForType(type);
		}

		// Token: 0x060001B9 RID: 441 RVA: 0x00006614 File Offset: 0x00004814
		private Cursor InternalGetCursorForType(CursorType type)
		{
			Display.GetCursorForTypeNativeDelegate getCursorForTypeNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "get_cursor_for_type");
			if (getCursorForTypeNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getCursorForTypeNativeDelegate(base.Handle, (int)type)) as Cursor;
		}

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x060001BA RID: 442 RVA: 0x00006653 File Offset: 0x00004853
		private static Display.GetCursorForNameNativeDelegate GetCursorForNameVMCallback
		{
			get
			{
				if (Display.GetCursorForName_cb_delegate == null)
				{
					Display.GetCursorForName_cb_delegate = new Display.GetCursorForNameNativeDelegate(Display.GetCursorForName_cb);
				}
				return Display.GetCursorForName_cb_delegate;
			}
		}

		// Token: 0x060001BB RID: 443 RVA: 0x00006672 File Offset: 0x00004872
		private static void OverrideGetCursorForName(GType gtype)
		{
			Display.OverrideGetCursorForName(gtype, Display.GetCursorForNameVMCallback);
		}

		// Token: 0x060001BC RID: 444 RVA: 0x00006680 File Offset: 0x00004880
		private unsafe static void OverrideGetCursorForName(GType gtype, Display.GetCursorForNameNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("get_cursor_for_name");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060001BD RID: 445 RVA: 0x000066B4 File Offset: 0x000048B4
		private static IntPtr GetCursorForName_cb(IntPtr inst, IntPtr name)
		{
			IntPtr result;
			try
			{
				Cursor cursor = (Object.GetObject(inst, false) as Display).OnGetCursorForName(Marshaller.Utf8PtrToString(name));
				result = ((cursor == null) ? IntPtr.Zero : cursor.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060001BE RID: 446 RVA: 0x00006708 File Offset: 0x00004908
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideGetCursorForName")]
		protected virtual Cursor OnGetCursorForName(string name)
		{
			return this.InternalGetCursorForName(name);
		}

		// Token: 0x060001BF RID: 447 RVA: 0x00006714 File Offset: 0x00004914
		private Cursor InternalGetCursorForName(string name)
		{
			Display.GetCursorForNameNativeDelegate getCursorForNameNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "get_cursor_for_name");
			if (getCursorForNameNativeDelegate == null)
			{
				return null;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(name);
			IntPtr o = getCursorForNameNativeDelegate(base.Handle, intPtr);
			Marshaller.Free(intPtr);
			return Object.GetObject(o) as Cursor;
		}

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x060001C0 RID: 448 RVA: 0x00006760 File Offset: 0x00004960
		private static Display.GetCursorForSurfaceNativeDelegate GetCursorForSurfaceVMCallback
		{
			get
			{
				if (Display.GetCursorForSurface_cb_delegate == null)
				{
					Display.GetCursorForSurface_cb_delegate = new Display.GetCursorForSurfaceNativeDelegate(Display.GetCursorForSurface_cb);
				}
				return Display.GetCursorForSurface_cb_delegate;
			}
		}

		// Token: 0x060001C1 RID: 449 RVA: 0x0000677F File Offset: 0x0000497F
		private static void OverrideGetCursorForSurface(GType gtype)
		{
			Display.OverrideGetCursorForSurface(gtype, Display.GetCursorForSurfaceVMCallback);
		}

		// Token: 0x060001C2 RID: 450 RVA: 0x0000678C File Offset: 0x0000498C
		private unsafe static void OverrideGetCursorForSurface(GType gtype, Display.GetCursorForSurfaceNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("get_cursor_for_surface");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060001C3 RID: 451 RVA: 0x000067C0 File Offset: 0x000049C0
		private static IntPtr GetCursorForSurface_cb(IntPtr inst, IntPtr surface, double x, double y)
		{
			IntPtr result;
			try
			{
				Cursor cursor = (Object.GetObject(inst, false) as Display).OnGetCursorForSurface(Surface.Lookup(surface, true), x, y);
				result = ((cursor == null) ? IntPtr.Zero : cursor.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060001C4 RID: 452 RVA: 0x00006814 File Offset: 0x00004A14
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideGetCursorForSurface")]
		protected virtual Cursor OnGetCursorForSurface(Surface surface, double x, double y)
		{
			return this.InternalGetCursorForSurface(surface, x, y);
		}

		// Token: 0x060001C5 RID: 453 RVA: 0x00006820 File Offset: 0x00004A20
		private Cursor InternalGetCursorForSurface(Surface surface, double x, double y)
		{
			Display.GetCursorForSurfaceNativeDelegate getCursorForSurfaceNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "get_cursor_for_surface");
			if (getCursorForSurfaceNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getCursorForSurfaceNativeDelegate(base.Handle, surface.Handle, x, y)) as Cursor;
		}

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x060001C6 RID: 454 RVA: 0x00006866 File Offset: 0x00004A66
		private static Display.GetAppLaunchContextNativeDelegate GetAppLaunchContextVMCallback
		{
			get
			{
				if (Display.GetAppLaunchContext_cb_delegate == null)
				{
					Display.GetAppLaunchContext_cb_delegate = new Display.GetAppLaunchContextNativeDelegate(Display.GetAppLaunchContext_cb);
				}
				return Display.GetAppLaunchContext_cb_delegate;
			}
		}

		// Token: 0x060001C7 RID: 455 RVA: 0x00006885 File Offset: 0x00004A85
		private static void OverrideGetAppLaunchContext(GType gtype)
		{
			Display.OverrideGetAppLaunchContext(gtype, Display.GetAppLaunchContextVMCallback);
		}

		// Token: 0x060001C8 RID: 456 RVA: 0x00006894 File Offset: 0x00004A94
		private unsafe static void OverrideGetAppLaunchContext(GType gtype, Display.GetAppLaunchContextNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("get_app_launch_context");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060001C9 RID: 457 RVA: 0x000068C8 File Offset: 0x00004AC8
		private static IntPtr GetAppLaunchContext_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				AppLaunchContext appLaunchContext = (Object.GetObject(inst, false) as Display).OnGetAppLaunchContext();
				result = ((appLaunchContext == null) ? IntPtr.Zero : appLaunchContext.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060001CA RID: 458 RVA: 0x00006914 File Offset: 0x00004B14
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideGetAppLaunchContext")]
		protected virtual AppLaunchContext OnGetAppLaunchContext()
		{
			return this.InternalGetAppLaunchContext();
		}

		// Token: 0x060001CB RID: 459 RVA: 0x0000691C File Offset: 0x00004B1C
		private AppLaunchContext InternalGetAppLaunchContext()
		{
			Display.GetAppLaunchContextNativeDelegate getAppLaunchContextNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "get_app_launch_context");
			if (getAppLaunchContextNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getAppLaunchContextNativeDelegate(base.Handle)) as AppLaunchContext;
		}

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x060001CC RID: 460 RVA: 0x0000695A File Offset: 0x00004B5A
		private static Display.BeforeProcessAllUpdatesNativeDelegate BeforeProcessAllUpdatesVMCallback
		{
			get
			{
				if (Display.BeforeProcessAllUpdates_cb_delegate == null)
				{
					Display.BeforeProcessAllUpdates_cb_delegate = new Display.BeforeProcessAllUpdatesNativeDelegate(Display.BeforeProcessAllUpdates_cb);
				}
				return Display.BeforeProcessAllUpdates_cb_delegate;
			}
		}

		// Token: 0x060001CD RID: 461 RVA: 0x00006979 File Offset: 0x00004B79
		private static void OverrideBeforeProcessAllUpdates(GType gtype)
		{
			Display.OverrideBeforeProcessAllUpdates(gtype, Display.BeforeProcessAllUpdatesVMCallback);
		}

		// Token: 0x060001CE RID: 462 RVA: 0x00006988 File Offset: 0x00004B88
		private unsafe static void OverrideBeforeProcessAllUpdates(GType gtype, Display.BeforeProcessAllUpdatesNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("before_process_all_updates");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060001CF RID: 463 RVA: 0x000069BC File Offset: 0x00004BBC
		private static void BeforeProcessAllUpdates_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnBeforeProcessAllUpdates();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060001D0 RID: 464 RVA: 0x000069F4 File Offset: 0x00004BF4
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideBeforeProcessAllUpdates")]
		protected virtual void OnBeforeProcessAllUpdates()
		{
			this.InternalBeforeProcessAllUpdates();
		}

		// Token: 0x060001D1 RID: 465 RVA: 0x000069FC File Offset: 0x00004BFC
		private void InternalBeforeProcessAllUpdates()
		{
			Display.BeforeProcessAllUpdatesNativeDelegate beforeProcessAllUpdatesNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "before_process_all_updates");
			if (beforeProcessAllUpdatesNativeDelegate == null)
			{
				return;
			}
			beforeProcessAllUpdatesNativeDelegate(base.Handle);
		}

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x060001D2 RID: 466 RVA: 0x00006A2F File Offset: 0x00004C2F
		private static Display.AfterProcessAllUpdatesNativeDelegate AfterProcessAllUpdatesVMCallback
		{
			get
			{
				if (Display.AfterProcessAllUpdates_cb_delegate == null)
				{
					Display.AfterProcessAllUpdates_cb_delegate = new Display.AfterProcessAllUpdatesNativeDelegate(Display.AfterProcessAllUpdates_cb);
				}
				return Display.AfterProcessAllUpdates_cb_delegate;
			}
		}

		// Token: 0x060001D3 RID: 467 RVA: 0x00006A4E File Offset: 0x00004C4E
		private static void OverrideAfterProcessAllUpdates(GType gtype)
		{
			Display.OverrideAfterProcessAllUpdates(gtype, Display.AfterProcessAllUpdatesVMCallback);
		}

		// Token: 0x060001D4 RID: 468 RVA: 0x00006A5C File Offset: 0x00004C5C
		private unsafe static void OverrideAfterProcessAllUpdates(GType gtype, Display.AfterProcessAllUpdatesNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("after_process_all_updates");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060001D5 RID: 469 RVA: 0x00006A90 File Offset: 0x00004C90
		private static void AfterProcessAllUpdates_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnAfterProcessAllUpdates();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060001D6 RID: 470 RVA: 0x00006AC8 File Offset: 0x00004CC8
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideAfterProcessAllUpdates")]
		protected virtual void OnAfterProcessAllUpdates()
		{
			this.InternalAfterProcessAllUpdates();
		}

		// Token: 0x060001D7 RID: 471 RVA: 0x00006AD0 File Offset: 0x00004CD0
		private void InternalAfterProcessAllUpdates()
		{
			Display.AfterProcessAllUpdatesNativeDelegate afterProcessAllUpdatesNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "after_process_all_updates");
			if (afterProcessAllUpdatesNativeDelegate == null)
			{
				return;
			}
			afterProcessAllUpdatesNativeDelegate(base.Handle);
		}

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x060001D8 RID: 472 RVA: 0x00006B03 File Offset: 0x00004D03
		private static Display.GetNextSerialNativeDelegate GetNextSerialVMCallback
		{
			get
			{
				if (Display.GetNextSerial_cb_delegate == null)
				{
					Display.GetNextSerial_cb_delegate = new Display.GetNextSerialNativeDelegate(Display.GetNextSerial_cb);
				}
				return Display.GetNextSerial_cb_delegate;
			}
		}

		// Token: 0x060001D9 RID: 473 RVA: 0x00006B22 File Offset: 0x00004D22
		private static void OverrideGetNextSerial(GType gtype)
		{
			Display.OverrideGetNextSerial(gtype, Display.GetNextSerialVMCallback);
		}

		// Token: 0x060001DA RID: 474 RVA: 0x00006B30 File Offset: 0x00004D30
		private unsafe static void OverrideGetNextSerial(GType gtype, Display.GetNextSerialNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("get_next_serial");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060001DB RID: 475 RVA: 0x00006B64 File Offset: 0x00004D64
		private static UIntPtr GetNextSerial_cb(IntPtr inst)
		{
			UIntPtr result;
			try
			{
				result = new UIntPtr((Object.GetObject(inst, false) as Display).OnGetNextSerial());
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060001DC RID: 476 RVA: 0x00006BA4 File Offset: 0x00004DA4
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideGetNextSerial")]
		protected virtual ulong OnGetNextSerial()
		{
			return this.InternalGetNextSerial();
		}

		// Token: 0x060001DD RID: 477 RVA: 0x00006BAC File Offset: 0x00004DAC
		private ulong InternalGetNextSerial()
		{
			Display.GetNextSerialNativeDelegate getNextSerialNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "get_next_serial");
			if (getNextSerialNativeDelegate == null)
			{
				return 0UL;
			}
			return (ulong)getNextSerialNativeDelegate(base.Handle);
		}

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x060001DE RID: 478 RVA: 0x00006BE6 File Offset: 0x00004DE6
		private static Display.NotifyStartupCompleteNativeDelegate NotifyStartupCompleteVMCallback
		{
			get
			{
				if (Display.NotifyStartupComplete_cb_delegate == null)
				{
					Display.NotifyStartupComplete_cb_delegate = new Display.NotifyStartupCompleteNativeDelegate(Display.NotifyStartupComplete_cb);
				}
				return Display.NotifyStartupComplete_cb_delegate;
			}
		}

		// Token: 0x060001DF RID: 479 RVA: 0x00006C05 File Offset: 0x00004E05
		private static void OverrideNotifyStartupComplete(GType gtype)
		{
			Display.OverrideNotifyStartupComplete(gtype, Display.NotifyStartupCompleteVMCallback);
		}

		// Token: 0x060001E0 RID: 480 RVA: 0x00006C14 File Offset: 0x00004E14
		private unsafe static void OverrideNotifyStartupComplete(GType gtype, Display.NotifyStartupCompleteNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("notify_startup_complete");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060001E1 RID: 481 RVA: 0x00006C48 File Offset: 0x00004E48
		private static void NotifyStartupComplete_cb(IntPtr inst, IntPtr startup_id)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnNotifyStartupComplete(Marshaller.Utf8PtrToString(startup_id));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060001E2 RID: 482 RVA: 0x00006C88 File Offset: 0x00004E88
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideNotifyStartupComplete")]
		protected virtual void OnNotifyStartupComplete(string startup_id)
		{
			this.InternalNotifyStartupComplete(startup_id);
		}

		// Token: 0x060001E3 RID: 483 RVA: 0x00006C94 File Offset: 0x00004E94
		private void InternalNotifyStartupComplete(string startup_id)
		{
			Display.NotifyStartupCompleteNativeDelegate notifyStartupCompleteNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "notify_startup_complete");
			if (notifyStartupCompleteNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(startup_id);
			notifyStartupCompleteNativeDelegate(base.Handle, intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x060001E4 RID: 484 RVA: 0x00006CD5 File Offset: 0x00004ED5
		private static Display.EventDataCopyNativeDelegate EventDataCopyVMCallback
		{
			get
			{
				if (Display.EventDataCopy_cb_delegate == null)
				{
					Display.EventDataCopy_cb_delegate = new Display.EventDataCopyNativeDelegate(Display.EventDataCopy_cb);
				}
				return Display.EventDataCopy_cb_delegate;
			}
		}

		// Token: 0x060001E5 RID: 485 RVA: 0x00006CF4 File Offset: 0x00004EF4
		private static void OverrideEventDataCopy(GType gtype)
		{
			Display.OverrideEventDataCopy(gtype, Display.EventDataCopyVMCallback);
		}

		// Token: 0x060001E6 RID: 486 RVA: 0x00006D04 File Offset: 0x00004F04
		private unsafe static void OverrideEventDataCopy(GType gtype, Display.EventDataCopyNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("event_data_copy");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060001E7 RID: 487 RVA: 0x00006D38 File Offset: 0x00004F38
		private static void EventDataCopy_cb(IntPtr inst, IntPtr evnt, IntPtr new_event)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnEventDataCopy(Event.GetEvent(evnt), Event.GetEvent(new_event));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060001E8 RID: 488 RVA: 0x00006D7C File Offset: 0x00004F7C
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideEventDataCopy")]
		protected virtual void OnEventDataCopy(Event evnt, Event new_event)
		{
			this.InternalEventDataCopy(evnt, new_event);
		}

		// Token: 0x060001E9 RID: 489 RVA: 0x00006D88 File Offset: 0x00004F88
		private void InternalEventDataCopy(Event evnt, Event new_event)
		{
			Display.EventDataCopyNativeDelegate eventDataCopyNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "event_data_copy");
			if (eventDataCopyNativeDelegate == null)
			{
				return;
			}
			eventDataCopyNativeDelegate(base.Handle, (evnt == null) ? IntPtr.Zero : evnt.Handle, (new_event == null) ? IntPtr.Zero : new_event.Handle);
		}

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x060001EA RID: 490 RVA: 0x00006DDB File Offset: 0x00004FDB
		private static Display.EventDataFreeNativeDelegate EventDataFreeVMCallback
		{
			get
			{
				if (Display.EventDataFree_cb_delegate == null)
				{
					Display.EventDataFree_cb_delegate = new Display.EventDataFreeNativeDelegate(Display.EventDataFree_cb);
				}
				return Display.EventDataFree_cb_delegate;
			}
		}

		// Token: 0x060001EB RID: 491 RVA: 0x00006DFA File Offset: 0x00004FFA
		private static void OverrideEventDataFree(GType gtype)
		{
			Display.OverrideEventDataFree(gtype, Display.EventDataFreeVMCallback);
		}

		// Token: 0x060001EC RID: 492 RVA: 0x00006E08 File Offset: 0x00005008
		private unsafe static void OverrideEventDataFree(GType gtype, Display.EventDataFreeNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("event_data_free");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060001ED RID: 493 RVA: 0x00006E3C File Offset: 0x0000503C
		private static void EventDataFree_cb(IntPtr inst, IntPtr evnt)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnEventDataFree(Event.GetEvent(evnt));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060001EE RID: 494 RVA: 0x00006E7C File Offset: 0x0000507C
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideEventDataFree")]
		protected virtual void OnEventDataFree(Event evnt)
		{
			this.InternalEventDataFree(evnt);
		}

		// Token: 0x060001EF RID: 495 RVA: 0x00006E88 File Offset: 0x00005088
		private void InternalEventDataFree(Event evnt)
		{
			Display.EventDataFreeNativeDelegate eventDataFreeNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "event_data_free");
			if (eventDataFreeNativeDelegate == null)
			{
				return;
			}
			eventDataFreeNativeDelegate(base.Handle, (evnt == null) ? IntPtr.Zero : evnt.Handle);
		}

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x060001F0 RID: 496 RVA: 0x00006ECB File Offset: 0x000050CB
		private static Display.CreateWindowImplNativeDelegate CreateWindowImplVMCallback
		{
			get
			{
				if (Display.CreateWindowImpl_cb_delegate == null)
				{
					Display.CreateWindowImpl_cb_delegate = new Display.CreateWindowImplNativeDelegate(Display.CreateWindowImpl_cb);
				}
				return Display.CreateWindowImpl_cb_delegate;
			}
		}

		// Token: 0x060001F1 RID: 497 RVA: 0x00006EEA File Offset: 0x000050EA
		private static void OverrideCreateWindowImpl(GType gtype)
		{
			Display.OverrideCreateWindowImpl(gtype, Display.CreateWindowImplVMCallback);
		}

		// Token: 0x060001F2 RID: 498 RVA: 0x00006EF8 File Offset: 0x000050F8
		private unsafe static void OverrideCreateWindowImpl(GType gtype, Display.CreateWindowImplNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("create_window_impl");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060001F3 RID: 499 RVA: 0x00006F2C File Offset: 0x0000512C
		private static void CreateWindowImpl_cb(IntPtr inst, IntPtr window, IntPtr real_parent, IntPtr screen, int event_mask, IntPtr attributes, int attributes_mask)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnCreateWindowImpl(Object.GetObject(window) as Window, Object.GetObject(real_parent) as Window, Object.GetObject(screen) as Screen, (EventMask)event_mask, WindowAttr.New(attributes), attributes_mask);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060001F4 RID: 500 RVA: 0x00006F90 File Offset: 0x00005190
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideCreateWindowImpl")]
		protected virtual void OnCreateWindowImpl(Window window, Window real_parent, Screen screen, EventMask event_mask, WindowAttr attributes, int attributes_mask)
		{
			this.InternalCreateWindowImpl(window, real_parent, screen, event_mask, attributes, attributes_mask);
		}

		// Token: 0x060001F5 RID: 501 RVA: 0x00006FA4 File Offset: 0x000051A4
		private void InternalCreateWindowImpl(Window window, Window real_parent, Screen screen, EventMask event_mask, WindowAttr attributes, int attributes_mask)
		{
			Display.CreateWindowImplNativeDelegate createWindowImplNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "create_window_impl");
			if (createWindowImplNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(attributes);
			createWindowImplNativeDelegate(base.Handle, (window == null) ? IntPtr.Zero : window.Handle, (real_parent == null) ? IntPtr.Zero : real_parent.Handle, (screen == null) ? IntPtr.Zero : screen.Handle, (int)event_mask, intPtr, attributes_mask);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x060001F6 RID: 502 RVA: 0x0000701F File Offset: 0x0000521F
		private static Display.GetKeymapNativeDelegate GetKeymapVMCallback
		{
			get
			{
				if (Display.GetKeymap_cb_delegate == null)
				{
					Display.GetKeymap_cb_delegate = new Display.GetKeymapNativeDelegate(Display.GetKeymap_cb);
				}
				return Display.GetKeymap_cb_delegate;
			}
		}

		// Token: 0x060001F7 RID: 503 RVA: 0x0000703E File Offset: 0x0000523E
		private static void OverrideGetKeymap(GType gtype)
		{
			Display.OverrideGetKeymap(gtype, Display.GetKeymapVMCallback);
		}

		// Token: 0x060001F8 RID: 504 RVA: 0x0000704C File Offset: 0x0000524C
		private unsafe static void OverrideGetKeymap(GType gtype, Display.GetKeymapNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("get_keymap");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060001F9 RID: 505 RVA: 0x00007080 File Offset: 0x00005280
		private static IntPtr GetKeymap_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				Keymap keymap = (Object.GetObject(inst, false) as Display).OnGetKeymap();
				result = ((keymap == null) ? IntPtr.Zero : keymap.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060001FA RID: 506 RVA: 0x000070CC File Offset: 0x000052CC
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideGetKeymap")]
		protected virtual Keymap OnGetKeymap()
		{
			return this.InternalGetKeymap();
		}

		// Token: 0x060001FB RID: 507 RVA: 0x000070D4 File Offset: 0x000052D4
		private Keymap InternalGetKeymap()
		{
			Display.GetKeymapNativeDelegate getKeymapNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "get_keymap");
			if (getKeymapNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getKeymapNativeDelegate(base.Handle)) as Keymap;
		}

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x060001FC RID: 508 RVA: 0x00007112 File Offset: 0x00005312
		private static Display.PushErrorTrapNativeDelegate PushErrorTrapVMCallback
		{
			get
			{
				if (Display.PushErrorTrap_cb_delegate == null)
				{
					Display.PushErrorTrap_cb_delegate = new Display.PushErrorTrapNativeDelegate(Display.PushErrorTrap_cb);
				}
				return Display.PushErrorTrap_cb_delegate;
			}
		}

		// Token: 0x060001FD RID: 509 RVA: 0x00007131 File Offset: 0x00005331
		private static void OverridePushErrorTrap(GType gtype)
		{
			Display.OverridePushErrorTrap(gtype, Display.PushErrorTrapVMCallback);
		}

		// Token: 0x060001FE RID: 510 RVA: 0x00007140 File Offset: 0x00005340
		private unsafe static void OverridePushErrorTrap(GType gtype, Display.PushErrorTrapNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("push_error_trap");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060001FF RID: 511 RVA: 0x00007174 File Offset: 0x00005374
		private static void PushErrorTrap_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnPushErrorTrap();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000200 RID: 512 RVA: 0x000071AC File Offset: 0x000053AC
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverridePushErrorTrap")]
		protected virtual void OnPushErrorTrap()
		{
			this.InternalPushErrorTrap();
		}

		// Token: 0x06000201 RID: 513 RVA: 0x000071B4 File Offset: 0x000053B4
		private void InternalPushErrorTrap()
		{
			Display.PushErrorTrapNativeDelegate pushErrorTrapNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "push_error_trap");
			if (pushErrorTrapNativeDelegate == null)
			{
				return;
			}
			pushErrorTrapNativeDelegate(base.Handle);
		}

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x06000202 RID: 514 RVA: 0x000071E7 File Offset: 0x000053E7
		private static Display.PopErrorTrapNativeDelegate PopErrorTrapVMCallback
		{
			get
			{
				if (Display.PopErrorTrap_cb_delegate == null)
				{
					Display.PopErrorTrap_cb_delegate = new Display.PopErrorTrapNativeDelegate(Display.PopErrorTrap_cb);
				}
				return Display.PopErrorTrap_cb_delegate;
			}
		}

		// Token: 0x06000203 RID: 515 RVA: 0x00007206 File Offset: 0x00005406
		private static void OverridePopErrorTrap(GType gtype)
		{
			Display.OverridePopErrorTrap(gtype, Display.PopErrorTrapVMCallback);
		}

		// Token: 0x06000204 RID: 516 RVA: 0x00007214 File Offset: 0x00005414
		private unsafe static void OverridePopErrorTrap(GType gtype, Display.PopErrorTrapNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("pop_error_trap");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000205 RID: 517 RVA: 0x00007248 File Offset: 0x00005448
		private static int PopErrorTrap_cb(IntPtr inst, bool ignore)
		{
			int result;
			try
			{
				result = (Object.GetObject(inst, false) as Display).OnPopErrorTrap(ignore);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000206 RID: 518 RVA: 0x00007284 File Offset: 0x00005484
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverridePopErrorTrap")]
		protected virtual int OnPopErrorTrap(bool ignore)
		{
			return this.InternalPopErrorTrap(ignore);
		}

		// Token: 0x06000207 RID: 519 RVA: 0x00007290 File Offset: 0x00005490
		private int InternalPopErrorTrap(bool ignore)
		{
			Display.PopErrorTrapNativeDelegate popErrorTrapNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "pop_error_trap");
			if (popErrorTrapNativeDelegate == null)
			{
				return 0;
			}
			return popErrorTrapNativeDelegate(base.Handle, ignore);
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x06000208 RID: 520 RVA: 0x000072C5 File Offset: 0x000054C5
		private static Display.GetSelectionOwnerNativeDelegate GetSelectionOwnerVMCallback
		{
			get
			{
				if (Display.GetSelectionOwner_cb_delegate == null)
				{
					Display.GetSelectionOwner_cb_delegate = new Display.GetSelectionOwnerNativeDelegate(Display.GetSelectionOwner_cb);
				}
				return Display.GetSelectionOwner_cb_delegate;
			}
		}

		// Token: 0x06000209 RID: 521 RVA: 0x000072E4 File Offset: 0x000054E4
		private static void OverrideGetSelectionOwner(GType gtype)
		{
			Display.OverrideGetSelectionOwner(gtype, Display.GetSelectionOwnerVMCallback);
		}

		// Token: 0x0600020A RID: 522 RVA: 0x000072F4 File Offset: 0x000054F4
		private unsafe static void OverrideGetSelectionOwner(GType gtype, Display.GetSelectionOwnerNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("get_selection_owner");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600020B RID: 523 RVA: 0x00007328 File Offset: 0x00005528
		private static IntPtr GetSelectionOwner_cb(IntPtr inst, IntPtr selection)
		{
			IntPtr result;
			try
			{
				Window window = (Object.GetObject(inst, false) as Display).OnGetSelectionOwner((selection == IntPtr.Zero) ? null : ((Atom)Opaque.GetOpaque(selection, typeof(Atom), false)));
				result = ((window == null) ? IntPtr.Zero : window.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600020C RID: 524 RVA: 0x0000739C File Offset: 0x0000559C
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideGetSelectionOwner")]
		protected virtual Window OnGetSelectionOwner(Atom selection)
		{
			return this.InternalGetSelectionOwner(selection);
		}

		// Token: 0x0600020D RID: 525 RVA: 0x000073A8 File Offset: 0x000055A8
		private Window InternalGetSelectionOwner(Atom selection)
		{
			Display.GetSelectionOwnerNativeDelegate getSelectionOwnerNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "get_selection_owner");
			if (getSelectionOwnerNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getSelectionOwnerNativeDelegate(base.Handle, (selection == null) ? IntPtr.Zero : selection.Handle)) as Window;
		}

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x0600020E RID: 526 RVA: 0x000073F6 File Offset: 0x000055F6
		private static Display.SetSelectionOwnerNativeDelegate SetSelectionOwnerVMCallback
		{
			get
			{
				if (Display.SetSelectionOwner_cb_delegate == null)
				{
					Display.SetSelectionOwner_cb_delegate = new Display.SetSelectionOwnerNativeDelegate(Display.SetSelectionOwner_cb);
				}
				return Display.SetSelectionOwner_cb_delegate;
			}
		}

		// Token: 0x0600020F RID: 527 RVA: 0x00007415 File Offset: 0x00005615
		private static void OverrideSetSelectionOwner(GType gtype)
		{
			Display.OverrideSetSelectionOwner(gtype, Display.SetSelectionOwnerVMCallback);
		}

		// Token: 0x06000210 RID: 528 RVA: 0x00007424 File Offset: 0x00005624
		private unsafe static void OverrideSetSelectionOwner(GType gtype, Display.SetSelectionOwnerNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("set_selection_owner");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000211 RID: 529 RVA: 0x00007458 File Offset: 0x00005658
		private static bool SetSelectionOwner_cb(IntPtr inst, IntPtr owner, IntPtr selection, uint time, bool send_event)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Display).OnSetSelectionOwner(Object.GetObject(owner) as Window, (selection == IntPtr.Zero) ? null : ((Atom)Opaque.GetOpaque(selection, typeof(Atom), false)), time, send_event);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000212 RID: 530 RVA: 0x000074C8 File Offset: 0x000056C8
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideSetSelectionOwner")]
		protected virtual bool OnSetSelectionOwner(Window owner, Atom selection, uint time, bool send_event)
		{
			return this.InternalSetSelectionOwner(owner, selection, time, send_event);
		}

		// Token: 0x06000213 RID: 531 RVA: 0x000074D8 File Offset: 0x000056D8
		private bool InternalSetSelectionOwner(Window owner, Atom selection, uint time, bool send_event)
		{
			Display.SetSelectionOwnerNativeDelegate setSelectionOwnerNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "set_selection_owner");
			return setSelectionOwnerNativeDelegate != null && setSelectionOwnerNativeDelegate(base.Handle, (owner == null) ? IntPtr.Zero : owner.Handle, (selection == null) ? IntPtr.Zero : selection.Handle, time, send_event);
		}

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x06000214 RID: 532 RVA: 0x0000752F File Offset: 0x0000572F
		private static Display.SendSelectionNotifyNativeDelegate SendSelectionNotifyVMCallback
		{
			get
			{
				if (Display.SendSelectionNotify_cb_delegate == null)
				{
					Display.SendSelectionNotify_cb_delegate = new Display.SendSelectionNotifyNativeDelegate(Display.SendSelectionNotify_cb);
				}
				return Display.SendSelectionNotify_cb_delegate;
			}
		}

		// Token: 0x06000215 RID: 533 RVA: 0x0000754E File Offset: 0x0000574E
		private static void OverrideSendSelectionNotify(GType gtype)
		{
			Display.OverrideSendSelectionNotify(gtype, Display.SendSelectionNotifyVMCallback);
		}

		// Token: 0x06000216 RID: 534 RVA: 0x0000755C File Offset: 0x0000575C
		private unsafe static void OverrideSendSelectionNotify(GType gtype, Display.SendSelectionNotifyNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("send_selection_notify");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000217 RID: 535 RVA: 0x00007590 File Offset: 0x00005790
		private static void SendSelectionNotify_cb(IntPtr inst, IntPtr requestor, IntPtr selection, IntPtr target, IntPtr property, uint time)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnSendSelectionNotify(Object.GetObject(requestor) as Window, (selection == IntPtr.Zero) ? null : ((Atom)Opaque.GetOpaque(selection, typeof(Atom), false)), (target == IntPtr.Zero) ? null : ((Atom)Opaque.GetOpaque(target, typeof(Atom), false)), (property == IntPtr.Zero) ? null : ((Atom)Opaque.GetOpaque(property, typeof(Atom), false)), time);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000218 RID: 536 RVA: 0x0000764C File Offset: 0x0000584C
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideSendSelectionNotify")]
		protected virtual void OnSendSelectionNotify(Window requestor, Atom selection, Atom target, Atom property, uint time)
		{
			this.InternalSendSelectionNotify(requestor, selection, target, property, time);
		}

		// Token: 0x06000219 RID: 537 RVA: 0x0000765C File Offset: 0x0000585C
		private void InternalSendSelectionNotify(Window requestor, Atom selection, Atom target, Atom property, uint time)
		{
			Display.SendSelectionNotifyNativeDelegate sendSelectionNotifyNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "send_selection_notify");
			if (sendSelectionNotifyNativeDelegate == null)
			{
				return;
			}
			sendSelectionNotifyNativeDelegate(base.Handle, (requestor == null) ? IntPtr.Zero : requestor.Handle, (selection == null) ? IntPtr.Zero : selection.Handle, (target == null) ? IntPtr.Zero : target.Handle, (property == null) ? IntPtr.Zero : property.Handle, time);
		}

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x0600021A RID: 538 RVA: 0x000076D3 File Offset: 0x000058D3
		private static Display.GetSelectionPropertyNativeDelegate GetSelectionPropertyVMCallback
		{
			get
			{
				if (Display.GetSelectionProperty_cb_delegate == null)
				{
					Display.GetSelectionProperty_cb_delegate = new Display.GetSelectionPropertyNativeDelegate(Display.GetSelectionProperty_cb);
				}
				return Display.GetSelectionProperty_cb_delegate;
			}
		}

		// Token: 0x0600021B RID: 539 RVA: 0x000076F2 File Offset: 0x000058F2
		private static void OverrideGetSelectionProperty(GType gtype)
		{
			Display.OverrideGetSelectionProperty(gtype, Display.GetSelectionPropertyVMCallback);
		}

		// Token: 0x0600021C RID: 540 RVA: 0x00007700 File Offset: 0x00005900
		private unsafe static void OverrideGetSelectionProperty(GType gtype, Display.GetSelectionPropertyNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("get_selection_property");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600021D RID: 541 RVA: 0x00007734 File Offset: 0x00005934
		private static int GetSelectionProperty_cb(IntPtr inst, IntPtr requestor, out byte data, IntPtr type, out int format)
		{
			int result;
			try
			{
				result = (Object.GetObject(inst, false) as Display).OnGetSelectionProperty(Object.GetObject(requestor) as Window, out data, (type == IntPtr.Zero) ? null : ((Atom)Opaque.GetOpaque(type, typeof(Atom), false)), out format);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600021E RID: 542 RVA: 0x000077A4 File Offset: 0x000059A4
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideGetSelectionProperty")]
		protected virtual int OnGetSelectionProperty(Window requestor, out byte data, Atom type, out int format)
		{
			return this.InternalGetSelectionProperty(requestor, out data, type, out format);
		}

		// Token: 0x0600021F RID: 543 RVA: 0x000077B4 File Offset: 0x000059B4
		private int InternalGetSelectionProperty(Window requestor, out byte data, Atom type, out int format)
		{
			Display.GetSelectionPropertyNativeDelegate getSelectionPropertyNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "get_selection_property");
			if (getSelectionPropertyNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			return getSelectionPropertyNativeDelegate(base.Handle, (requestor == null) ? IntPtr.Zero : requestor.Handle, out data, (type == null) ? IntPtr.Zero : type.Handle, out format);
		}

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x06000220 RID: 544 RVA: 0x00007812 File Offset: 0x00005A12
		private static Display.ConvertSelectionNativeDelegate ConvertSelectionVMCallback
		{
			get
			{
				if (Display.ConvertSelection_cb_delegate == null)
				{
					Display.ConvertSelection_cb_delegate = new Display.ConvertSelectionNativeDelegate(Display.ConvertSelection_cb);
				}
				return Display.ConvertSelection_cb_delegate;
			}
		}

		// Token: 0x06000221 RID: 545 RVA: 0x00007831 File Offset: 0x00005A31
		private static void OverrideConvertSelection(GType gtype)
		{
			Display.OverrideConvertSelection(gtype, Display.ConvertSelectionVMCallback);
		}

		// Token: 0x06000222 RID: 546 RVA: 0x00007840 File Offset: 0x00005A40
		private unsafe static void OverrideConvertSelection(GType gtype, Display.ConvertSelectionNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("convert_selection");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000223 RID: 547 RVA: 0x00007874 File Offset: 0x00005A74
		private static void ConvertSelection_cb(IntPtr inst, IntPtr requestor, IntPtr selection, IntPtr target, uint time)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnConvertSelection(Object.GetObject(requestor) as Window, (selection == IntPtr.Zero) ? null : ((Atom)Opaque.GetOpaque(selection, typeof(Atom), false)), (target == IntPtr.Zero) ? null : ((Atom)Opaque.GetOpaque(target, typeof(Atom), false)), time);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000224 RID: 548 RVA: 0x00007908 File Offset: 0x00005B08
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideConvertSelection")]
		protected virtual void OnConvertSelection(Window requestor, Atom selection, Atom target, uint time)
		{
			this.InternalConvertSelection(requestor, selection, target, time);
		}

		// Token: 0x06000225 RID: 549 RVA: 0x00007918 File Offset: 0x00005B18
		private void InternalConvertSelection(Window requestor, Atom selection, Atom target, uint time)
		{
			Display.ConvertSelectionNativeDelegate convertSelectionNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "convert_selection");
			if (convertSelectionNativeDelegate == null)
			{
				return;
			}
			convertSelectionNativeDelegate(base.Handle, (requestor == null) ? IntPtr.Zero : requestor.Handle, (selection == null) ? IntPtr.Zero : selection.Handle, (target == null) ? IntPtr.Zero : target.Handle, time);
		}

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x06000226 RID: 550 RVA: 0x0000797D File Offset: 0x00005B7D
		private static Display.TextPropertyToUtf8ListNativeDelegate TextPropertyToUtf8ListVMCallback
		{
			get
			{
				if (Display.TextPropertyToUtf8List_cb_delegate == null)
				{
					Display.TextPropertyToUtf8List_cb_delegate = new Display.TextPropertyToUtf8ListNativeDelegate(Display.TextPropertyToUtf8List_cb);
				}
				return Display.TextPropertyToUtf8List_cb_delegate;
			}
		}

		// Token: 0x06000227 RID: 551 RVA: 0x0000799C File Offset: 0x00005B9C
		private static void OverrideTextPropertyToUtf8List(GType gtype)
		{
			Display.OverrideTextPropertyToUtf8List(gtype, Display.TextPropertyToUtf8ListVMCallback);
		}

		// Token: 0x06000228 RID: 552 RVA: 0x000079AC File Offset: 0x00005BAC
		private unsafe static void OverrideTextPropertyToUtf8List(GType gtype, Display.TextPropertyToUtf8ListNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("text_property_to_utf8_list");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000229 RID: 553 RVA: 0x000079E0 File Offset: 0x00005BE0
		private static int TextPropertyToUtf8List_cb(IntPtr inst, IntPtr encoding, int format, out byte text, int length, IntPtr list)
		{
			int result;
			try
			{
				result = (Object.GetObject(inst, false) as Display).OnTextPropertyToUtf8List((encoding == IntPtr.Zero) ? null : ((Atom)Opaque.GetOpaque(encoding, typeof(Atom), false)), format, out text, length, Marshaller.PtrToStringGFree(list));
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600022A RID: 554 RVA: 0x00007A4C File Offset: 0x00005C4C
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideTextPropertyToUtf8List")]
		protected virtual int OnTextPropertyToUtf8List(Atom encoding, int format, out byte text, int length, string list)
		{
			return this.InternalTextPropertyToUtf8List(encoding, format, out text, length, list);
		}

		// Token: 0x0600022B RID: 555 RVA: 0x00007A5C File Offset: 0x00005C5C
		private int InternalTextPropertyToUtf8List(Atom encoding, int format, out byte text, int length, string list)
		{
			Display.TextPropertyToUtf8ListNativeDelegate textPropertyToUtf8ListNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "text_property_to_utf8_list");
			if (textPropertyToUtf8ListNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			return textPropertyToUtf8ListNativeDelegate(base.Handle, (encoding == null) ? IntPtr.Zero : encoding.Handle, format, out text, length, Marshaller.StringToPtrGStrdup(list));
		}

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x0600022C RID: 556 RVA: 0x00007AB2 File Offset: 0x00005CB2
		private static Display.Utf8ToStringTargetNativeDelegate Utf8ToStringTargetVMCallback
		{
			get
			{
				if (Display.Utf8ToStringTarget_cb_delegate == null)
				{
					Display.Utf8ToStringTarget_cb_delegate = new Display.Utf8ToStringTargetNativeDelegate(Display.Utf8ToStringTarget_cb);
				}
				return Display.Utf8ToStringTarget_cb_delegate;
			}
		}

		// Token: 0x0600022D RID: 557 RVA: 0x00007AD1 File Offset: 0x00005CD1
		private static void OverrideUtf8ToStringTarget(GType gtype)
		{
			Display.OverrideUtf8ToStringTarget(gtype, Display.Utf8ToStringTargetVMCallback);
		}

		// Token: 0x0600022E RID: 558 RVA: 0x00007AE0 File Offset: 0x00005CE0
		private unsafe static void OverrideUtf8ToStringTarget(GType gtype, Display.Utf8ToStringTargetNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("utf8_to_string_target");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600022F RID: 559 RVA: 0x00007B14 File Offset: 0x00005D14
		private static IntPtr Utf8ToStringTarget_cb(IntPtr inst, IntPtr text)
		{
			IntPtr result;
			try
			{
				result = Marshaller.StringToPtrGStrdup((Object.GetObject(inst, false) as Display).OnUtf8ToStringTarget(Marshaller.Utf8PtrToString(text)));
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000230 RID: 560 RVA: 0x00007B5C File Offset: 0x00005D5C
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideUtf8ToStringTarget")]
		protected virtual string OnUtf8ToStringTarget(string text)
		{
			return this.InternalUtf8ToStringTarget(text);
		}

		// Token: 0x06000231 RID: 561 RVA: 0x00007B68 File Offset: 0x00005D68
		private string InternalUtf8ToStringTarget(string text)
		{
			Display.Utf8ToStringTargetNativeDelegate utf8ToStringTargetNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "utf8_to_string_target");
			if (utf8ToStringTargetNativeDelegate == null)
			{
				return null;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(text);
			IntPtr ptr = utf8ToStringTargetNativeDelegate(base.Handle, intPtr);
			Marshaller.Free(intPtr);
			return Marshaller.PtrToStringGFree(ptr);
		}

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x06000232 RID: 562 RVA: 0x00007BAF File Offset: 0x00005DAF
		private static Display.MakeGlContextCurrentNativeDelegate MakeGlContextCurrentVMCallback
		{
			get
			{
				if (Display.MakeGlContextCurrent_cb_delegate == null)
				{
					Display.MakeGlContextCurrent_cb_delegate = new Display.MakeGlContextCurrentNativeDelegate(Display.MakeGlContextCurrent_cb);
				}
				return Display.MakeGlContextCurrent_cb_delegate;
			}
		}

		// Token: 0x06000233 RID: 563 RVA: 0x00007BCE File Offset: 0x00005DCE
		private static void OverrideMakeGlContextCurrent(GType gtype)
		{
			Display.OverrideMakeGlContextCurrent(gtype, Display.MakeGlContextCurrentVMCallback);
		}

		// Token: 0x06000234 RID: 564 RVA: 0x00007BDC File Offset: 0x00005DDC
		private unsafe static void OverrideMakeGlContextCurrent(GType gtype, Display.MakeGlContextCurrentNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("make_gl_context_current");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000235 RID: 565 RVA: 0x00007C10 File Offset: 0x00005E10
		private static bool MakeGlContextCurrent_cb(IntPtr inst, IntPtr context)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Display).OnMakeGlContextCurrent(Object.GetObject(context) as GLContext);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000236 RID: 566 RVA: 0x00007C58 File Offset: 0x00005E58
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideMakeGlContextCurrent")]
		protected virtual bool OnMakeGlContextCurrent(GLContext context)
		{
			return this.InternalMakeGlContextCurrent(context);
		}

		// Token: 0x06000237 RID: 567 RVA: 0x00007C64 File Offset: 0x00005E64
		private bool InternalMakeGlContextCurrent(GLContext context)
		{
			Display.MakeGlContextCurrentNativeDelegate makeGlContextCurrentNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "make_gl_context_current");
			return makeGlContextCurrentNativeDelegate != null && makeGlContextCurrentNativeDelegate(base.Handle, (context == null) ? IntPtr.Zero : context.Handle);
		}

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x06000238 RID: 568 RVA: 0x00007CA8 File Offset: 0x00005EA8
		private static Display.GetDefaultSeatNativeDelegate GetDefaultSeatVMCallback
		{
			get
			{
				if (Display.GetDefaultSeat_cb_delegate == null)
				{
					Display.GetDefaultSeat_cb_delegate = new Display.GetDefaultSeatNativeDelegate(Display.GetDefaultSeat_cb);
				}
				return Display.GetDefaultSeat_cb_delegate;
			}
		}

		// Token: 0x06000239 RID: 569 RVA: 0x00007CC7 File Offset: 0x00005EC7
		private static void OverrideGetDefaultSeat(GType gtype)
		{
			Display.OverrideGetDefaultSeat(gtype, Display.GetDefaultSeatVMCallback);
		}

		// Token: 0x0600023A RID: 570 RVA: 0x00007CD4 File Offset: 0x00005ED4
		private unsafe static void OverrideGetDefaultSeat(GType gtype, Display.GetDefaultSeatNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("get_default_seat");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600023B RID: 571 RVA: 0x00007D08 File Offset: 0x00005F08
		private static IntPtr GetDefaultSeat_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				Seat seat = (Object.GetObject(inst, false) as Display).OnGetDefaultSeat();
				result = ((seat == null) ? IntPtr.Zero : seat.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600023C RID: 572 RVA: 0x00007D54 File Offset: 0x00005F54
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideGetDefaultSeat")]
		protected virtual Seat OnGetDefaultSeat()
		{
			return this.InternalGetDefaultSeat();
		}

		// Token: 0x0600023D RID: 573 RVA: 0x00007D5C File Offset: 0x00005F5C
		private Seat InternalGetDefaultSeat()
		{
			Display.GetDefaultSeatNativeDelegate getDefaultSeatNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "get_default_seat");
			if (getDefaultSeatNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getDefaultSeatNativeDelegate(base.Handle)) as Seat;
		}

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x0600023E RID: 574 RVA: 0x00007D9A File Offset: 0x00005F9A
		private static Display.GetNMonitorsNativeDelegate GetNMonitorsVMCallback
		{
			get
			{
				if (Display.GetNMonitors_cb_delegate == null)
				{
					Display.GetNMonitors_cb_delegate = new Display.GetNMonitorsNativeDelegate(Display.GetNMonitors_cb);
				}
				return Display.GetNMonitors_cb_delegate;
			}
		}

		// Token: 0x0600023F RID: 575 RVA: 0x00007DB9 File Offset: 0x00005FB9
		private static void OverrideGetNMonitors(GType gtype)
		{
			Display.OverrideGetNMonitors(gtype, Display.GetNMonitorsVMCallback);
		}

		// Token: 0x06000240 RID: 576 RVA: 0x00007DC8 File Offset: 0x00005FC8
		private unsafe static void OverrideGetNMonitors(GType gtype, Display.GetNMonitorsNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("get_n_monitors");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000241 RID: 577 RVA: 0x00007DFC File Offset: 0x00005FFC
		private static int GetNMonitors_cb(IntPtr inst)
		{
			int result;
			try
			{
				result = (Object.GetObject(inst, false) as Display).OnGetNMonitors();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000242 RID: 578 RVA: 0x00007E38 File Offset: 0x00006038
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideGetNMonitors")]
		protected virtual int OnGetNMonitors()
		{
			return this.InternalGetNMonitors();
		}

		// Token: 0x06000243 RID: 579 RVA: 0x00007E40 File Offset: 0x00006040
		private int InternalGetNMonitors()
		{
			Display.GetNMonitorsNativeDelegate getNMonitorsNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "get_n_monitors");
			if (getNMonitorsNativeDelegate == null)
			{
				return 0;
			}
			return getNMonitorsNativeDelegate(base.Handle);
		}

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x06000244 RID: 580 RVA: 0x00007E74 File Offset: 0x00006074
		private static Display.GetMonitorNativeDelegate GetMonitorVMCallback
		{
			get
			{
				if (Display.GetMonitor_cb_delegate == null)
				{
					Display.GetMonitor_cb_delegate = new Display.GetMonitorNativeDelegate(Display.GetMonitor_cb);
				}
				return Display.GetMonitor_cb_delegate;
			}
		}

		// Token: 0x06000245 RID: 581 RVA: 0x00007E93 File Offset: 0x00006093
		private static void OverrideGetMonitor(GType gtype)
		{
			Display.OverrideGetMonitor(gtype, Display.GetMonitorVMCallback);
		}

		// Token: 0x06000246 RID: 582 RVA: 0x00007EA0 File Offset: 0x000060A0
		private unsafe static void OverrideGetMonitor(GType gtype, Display.GetMonitorNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("get_monitor");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000247 RID: 583 RVA: 0x00007ED4 File Offset: 0x000060D4
		private static IntPtr GetMonitor_cb(IntPtr inst, int index)
		{
			IntPtr result;
			try
			{
				Monitor monitor = (Object.GetObject(inst, false) as Display).OnGetMonitor(index);
				result = ((monitor == null) ? IntPtr.Zero : monitor.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000248 RID: 584 RVA: 0x00007F20 File Offset: 0x00006120
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideGetMonitor")]
		protected virtual Monitor OnGetMonitor(int index)
		{
			return this.InternalGetMonitor(index);
		}

		// Token: 0x06000249 RID: 585 RVA: 0x00007F2C File Offset: 0x0000612C
		private Monitor InternalGetMonitor(int index)
		{
			Display.GetMonitorNativeDelegate getMonitorNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "get_monitor");
			if (getMonitorNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getMonitorNativeDelegate(base.Handle, index)) as Monitor;
		}

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x0600024A RID: 586 RVA: 0x00007F6B File Offset: 0x0000616B
		private static Display.GetPrimaryMonitorNativeDelegate GetPrimaryMonitorVMCallback
		{
			get
			{
				if (Display.GetPrimaryMonitor_cb_delegate == null)
				{
					Display.GetPrimaryMonitor_cb_delegate = new Display.GetPrimaryMonitorNativeDelegate(Display.GetPrimaryMonitor_cb);
				}
				return Display.GetPrimaryMonitor_cb_delegate;
			}
		}

		// Token: 0x0600024B RID: 587 RVA: 0x00007F8A File Offset: 0x0000618A
		private static void OverrideGetPrimaryMonitor(GType gtype)
		{
			Display.OverrideGetPrimaryMonitor(gtype, Display.GetPrimaryMonitorVMCallback);
		}

		// Token: 0x0600024C RID: 588 RVA: 0x00007F98 File Offset: 0x00006198
		private unsafe static void OverrideGetPrimaryMonitor(GType gtype, Display.GetPrimaryMonitorNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("get_primary_monitor");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600024D RID: 589 RVA: 0x00007FCC File Offset: 0x000061CC
		private static IntPtr GetPrimaryMonitor_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				Monitor monitor = (Object.GetObject(inst, false) as Display).OnGetPrimaryMonitor();
				result = ((monitor == null) ? IntPtr.Zero : monitor.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600024E RID: 590 RVA: 0x00008018 File Offset: 0x00006218
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideGetPrimaryMonitor")]
		protected virtual Monitor OnGetPrimaryMonitor()
		{
			return this.InternalGetPrimaryMonitor();
		}

		// Token: 0x0600024F RID: 591 RVA: 0x00008020 File Offset: 0x00006220
		private Monitor InternalGetPrimaryMonitor()
		{
			Display.GetPrimaryMonitorNativeDelegate getPrimaryMonitorNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "get_primary_monitor");
			if (getPrimaryMonitorNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getPrimaryMonitorNativeDelegate(base.Handle)) as Monitor;
		}

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x06000250 RID: 592 RVA: 0x0000805E File Offset: 0x0000625E
		private static Display.GetMonitorAtWindowNativeDelegate GetMonitorAtWindowVMCallback
		{
			get
			{
				if (Display.GetMonitorAtWindow_cb_delegate == null)
				{
					Display.GetMonitorAtWindow_cb_delegate = new Display.GetMonitorAtWindowNativeDelegate(Display.GetMonitorAtWindow_cb);
				}
				return Display.GetMonitorAtWindow_cb_delegate;
			}
		}

		// Token: 0x06000251 RID: 593 RVA: 0x0000807D File Offset: 0x0000627D
		private static void OverrideGetMonitorAtWindow(GType gtype)
		{
			Display.OverrideGetMonitorAtWindow(gtype, Display.GetMonitorAtWindowVMCallback);
		}

		// Token: 0x06000252 RID: 594 RVA: 0x0000808C File Offset: 0x0000628C
		private unsafe static void OverrideGetMonitorAtWindow(GType gtype, Display.GetMonitorAtWindowNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("get_monitor_at_window");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000253 RID: 595 RVA: 0x000080C0 File Offset: 0x000062C0
		private static IntPtr GetMonitorAtWindow_cb(IntPtr inst, IntPtr window)
		{
			IntPtr result;
			try
			{
				Monitor monitor = (Object.GetObject(inst, false) as Display).OnGetMonitorAtWindow(Object.GetObject(window) as Window);
				result = ((monitor == null) ? IntPtr.Zero : monitor.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000254 RID: 596 RVA: 0x00008118 File Offset: 0x00006318
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideGetMonitorAtWindow")]
		protected virtual Monitor OnGetMonitorAtWindow(Window window)
		{
			return this.InternalGetMonitorAtWindow(window);
		}

		// Token: 0x06000255 RID: 597 RVA: 0x00008124 File Offset: 0x00006324
		private Monitor InternalGetMonitorAtWindow(Window window)
		{
			Display.GetMonitorAtWindowNativeDelegate getMonitorAtWindowNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "get_monitor_at_window");
			if (getMonitorAtWindowNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getMonitorAtWindowNativeDelegate(base.Handle, (window == null) ? IntPtr.Zero : window.Handle)) as Monitor;
		}

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x06000256 RID: 598 RVA: 0x00008172 File Offset: 0x00006372
		private static Display.OpenedNativeDelegate OpenedVMCallback
		{
			get
			{
				if (Display.Opened_cb_delegate == null)
				{
					Display.Opened_cb_delegate = new Display.OpenedNativeDelegate(Display.Opened_cb);
				}
				return Display.Opened_cb_delegate;
			}
		}

		// Token: 0x06000257 RID: 599 RVA: 0x00008191 File Offset: 0x00006391
		private static void OverrideOpened(GType gtype)
		{
			Display.OverrideOpened(gtype, Display.OpenedVMCallback);
		}

		// Token: 0x06000258 RID: 600 RVA: 0x000081A0 File Offset: 0x000063A0
		private unsafe static void OverrideOpened(GType gtype, Display.OpenedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("opened");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000259 RID: 601 RVA: 0x000081D4 File Offset: 0x000063D4
		private static void Opened_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnOpened();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x0600025A RID: 602 RVA: 0x0000820C File Offset: 0x0000640C
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideOpened")]
		protected virtual void OnOpened()
		{
			this.InternalOpened();
		}

		// Token: 0x0600025B RID: 603 RVA: 0x00008214 File Offset: 0x00006414
		private void InternalOpened()
		{
			Display.OpenedNativeDelegate openedNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "opened");
			if (openedNativeDelegate == null)
			{
				return;
			}
			openedNativeDelegate(base.Handle);
		}

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x0600025C RID: 604 RVA: 0x00008247 File Offset: 0x00006447
		private static Display.ClosedNativeDelegate ClosedVMCallback
		{
			get
			{
				if (Display.Closed_cb_delegate == null)
				{
					Display.Closed_cb_delegate = new Display.ClosedNativeDelegate(Display.Closed_cb);
				}
				return Display.Closed_cb_delegate;
			}
		}

		// Token: 0x0600025D RID: 605 RVA: 0x00008266 File Offset: 0x00006466
		private static void OverrideClosed(GType gtype)
		{
			Display.OverrideClosed(gtype, Display.ClosedVMCallback);
		}

		// Token: 0x0600025E RID: 606 RVA: 0x00008274 File Offset: 0x00006474
		private unsafe static void OverrideClosed(GType gtype, Display.ClosedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Display.class_abi.GetFieldOffset("closed");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600025F RID: 607 RVA: 0x000082A8 File Offset: 0x000064A8
		private static void Closed_cb(IntPtr inst, bool is_error)
		{
			try
			{
				(Object.GetObject(inst, false) as Display).OnClosed(is_error);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000260 RID: 608 RVA: 0x000082E4 File Offset: 0x000064E4
		[DefaultSignalHandler(Type = typeof(Display), ConnectionMethod = "OverrideClosed")]
		protected virtual void OnClosed(bool is_error)
		{
			this.InternalClosed(is_error);
		}

		// Token: 0x06000261 RID: 609 RVA: 0x000082F0 File Offset: 0x000064F0
		private void InternalClosed(bool is_error)
		{
			Display.ClosedNativeDelegate closedNativeDelegate = Display.class_abi.BaseOverride(base.LookupGType(), "closed");
			if (closedNativeDelegate == null)
			{
				return;
			}
			closedNativeDelegate(base.Handle, is_error);
		}

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x06000262 RID: 610 RVA: 0x00008324 File Offset: 0x00006524
		public new static AbiStruct class_abi
		{
			get
			{
				if (Display._class_abi == null)
				{
					Display._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("window_type", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(GType)), null, "get_name", (long)Marshal.OffsetOf(typeof(Display.GdkDisplay_window_typeAlign), "window_type"), 0U),
						new AbiField("get_name", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "window_type", "get_default_screen", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_default_screen", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_name", "beep", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("beep", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_default_screen", "sync", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("sync", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "beep", "flush", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("flush", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "sync", "has_pending", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("has_pending", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "flush", "queue_events", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("queue_events", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "has_pending", "make_default", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("make_default", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "queue_events", "get_default_group", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_default_group", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "make_default", "supports_selection_notification", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("supports_selection_notification", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_default_group", "request_selection_notification", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("request_selection_notification", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "supports_selection_notification", "supports_shapes", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("supports_shapes", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "request_selection_notification", "supports_input_shapes", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("supports_input_shapes", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "supports_shapes", "supports_composite", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("supports_composite", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "supports_input_shapes", "supports_cursor_alpha", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("supports_cursor_alpha", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "supports_composite", "supports_cursor_color", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("supports_cursor_color", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "supports_cursor_alpha", "supports_clipboard_persistence", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("supports_clipboard_persistence", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "supports_cursor_color", "store_clipboard", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("store_clipboard", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "supports_clipboard_persistence", "get_default_cursor_size", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_default_cursor_size", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "store_clipboard", "get_maximal_cursor_size", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_maximal_cursor_size", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_default_cursor_size", "get_cursor_for_type", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_cursor_for_type", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_maximal_cursor_size", "get_cursor_for_name", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_cursor_for_name", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_cursor_for_type", "get_cursor_for_surface", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_cursor_for_surface", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_cursor_for_name", "get_app_launch_context", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_app_launch_context", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_cursor_for_surface", "before_process_all_updates", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("before_process_all_updates", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_app_launch_context", "after_process_all_updates", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("after_process_all_updates", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "before_process_all_updates", "get_next_serial", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_next_serial", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "after_process_all_updates", "notify_startup_complete", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("notify_startup_complete", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_next_serial", "event_data_copy", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("event_data_copy", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "notify_startup_complete", "event_data_free", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("event_data_free", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "event_data_copy", "create_window_impl", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("create_window_impl", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "event_data_free", "get_keymap", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_keymap", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "create_window_impl", "push_error_trap", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("push_error_trap", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_keymap", "pop_error_trap", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("pop_error_trap", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "push_error_trap", "get_selection_owner", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_selection_owner", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "pop_error_trap", "set_selection_owner", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("set_selection_owner", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_selection_owner", "send_selection_notify", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("send_selection_notify", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "set_selection_owner", "get_selection_property", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_selection_property", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "send_selection_notify", "convert_selection", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("convert_selection", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_selection_property", "text_property_to_utf8_list", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("text_property_to_utf8_list", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "convert_selection", "utf8_to_string_target", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("utf8_to_string_target", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "text_property_to_utf8_list", "make_gl_context_current", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("make_gl_context_current", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "utf8_to_string_target", "get_default_seat", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_default_seat", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "make_gl_context_current", "get_n_monitors", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_n_monitors", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_default_seat", "get_monitor", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_monitor", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_n_monitors", "get_primary_monitor", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_primary_monitor", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_monitor", "get_monitor_at_window", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_monitor_at_window", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_primary_monitor", "opened", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("opened", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_monitor_at_window", "closed", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("closed", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "opened", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Display._class_abi;
			}
		}

		// Token: 0x06000263 RID: 611 RVA: 0x00008F10 File Offset: 0x00007110
		public void Beep()
		{
			Display.gdk_display_beep(base.Handle);
		}

		// Token: 0x06000264 RID: 612 RVA: 0x00008F22 File Offset: 0x00007122
		public void Close()
		{
			Display.gdk_display_close(base.Handle);
		}

		// Token: 0x06000265 RID: 613 RVA: 0x00008F34 File Offset: 0x00007134
		public bool DeviceIsGrabbed(Device device)
		{
			return Display.gdk_display_device_is_grabbed(base.Handle, (device == null) ? IntPtr.Zero : device.Handle);
		}

		// Token: 0x06000266 RID: 614 RVA: 0x00008F56 File Offset: 0x00007156
		public void Flush()
		{
			Display.gdk_display_flush(base.Handle);
		}

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x06000267 RID: 615 RVA: 0x00008F68 File Offset: 0x00007168
		public AppLaunchContext AppLaunchContext
		{
			get
			{
				return Object.GetObject(Display.gdk_display_get_app_launch_context(base.Handle)) as AppLaunchContext;
			}
		}

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x06000268 RID: 616 RVA: 0x00008F84 File Offset: 0x00007184
		public static Display Default
		{
			get
			{
				return Object.GetObject(Display.gdk_display_get_default()) as Display;
			}
		}

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x06000269 RID: 617 RVA: 0x00008F9A File Offset: 0x0000719A
		public uint DefaultCursorSize
		{
			get
			{
				return Display.gdk_display_get_default_cursor_size(base.Handle);
			}
		}

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x0600026A RID: 618 RVA: 0x00008FAC File Offset: 0x000071AC
		public Window DefaultGroup
		{
			get
			{
				return Object.GetObject(Display.gdk_display_get_default_group(base.Handle)) as Window;
			}
		}

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x0600026B RID: 619 RVA: 0x00008FC8 File Offset: 0x000071C8
		public Screen DefaultScreen
		{
			get
			{
				return Object.GetObject(Display.gdk_display_get_default_screen(base.Handle)) as Screen;
			}
		}

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x0600026C RID: 620 RVA: 0x00008FE4 File Offset: 0x000071E4
		public Seat DefaultSeat
		{
			get
			{
				return Object.GetObject(Display.gdk_display_get_default_seat(base.Handle)) as Seat;
			}
		}

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x0600026D RID: 621 RVA: 0x00009000 File Offset: 0x00007200
		[Obsolete]
		public DeviceManager DeviceManager
		{
			get
			{
				return Object.GetObject(Display.gdk_display_get_device_manager(base.Handle)) as DeviceManager;
			}
		}

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x0600026E RID: 622 RVA: 0x0000901C File Offset: 0x0000721C
		public Event Event
		{
			get
			{
				return Event.GetEvent(Display.gdk_display_get_event(base.Handle));
			}
		}

		// Token: 0x0600026F RID: 623 RVA: 0x00009033 File Offset: 0x00007233
		public void GetMaximalCursorSize(out uint width, out uint height)
		{
			Display.gdk_display_get_maximal_cursor_size(base.Handle, out width, out height);
		}

		// Token: 0x06000270 RID: 624 RVA: 0x00009047 File Offset: 0x00007247
		public Monitor GetMonitor(int monitor_num)
		{
			return Object.GetObject(Display.gdk_display_get_monitor(base.Handle, monitor_num)) as Monitor;
		}

		// Token: 0x06000271 RID: 625 RVA: 0x00009064 File Offset: 0x00007264
		public Monitor GetMonitorAtPoint(int x, int y)
		{
			return Object.GetObject(Display.gdk_display_get_monitor_at_point(base.Handle, x, y)) as Monitor;
		}

		// Token: 0x06000272 RID: 626 RVA: 0x00009082 File Offset: 0x00007282
		public Monitor GetMonitorAtWindow(Window window)
		{
			return Object.GetObject(Display.gdk_display_get_monitor_at_window(base.Handle, (window == null) ? IntPtr.Zero : window.Handle)) as Monitor;
		}

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x06000273 RID: 627 RVA: 0x000090AE File Offset: 0x000072AE
		public int NMonitors
		{
			get
			{
				return Display.gdk_display_get_n_monitors(base.Handle);
			}
		}

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x06000274 RID: 628 RVA: 0x000090C0 File Offset: 0x000072C0
		[Obsolete]
		public int NScreens
		{
			get
			{
				return Display.gdk_display_get_n_screens(base.Handle);
			}
		}

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x06000275 RID: 629 RVA: 0x000090D2 File Offset: 0x000072D2
		public string Name
		{
			get
			{
				return Marshaller.Utf8PtrToString(Display.gdk_display_get_name(base.Handle));
			}
		}

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x06000276 RID: 630 RVA: 0x000090E9 File Offset: 0x000072E9
		public Monitor PrimaryMonitor
		{
			get
			{
				return Object.GetObject(Display.gdk_display_get_primary_monitor(base.Handle)) as Monitor;
			}
		}

		// Token: 0x06000277 RID: 631 RVA: 0x00009105 File Offset: 0x00007305
		[Obsolete]
		public Screen GetScreen(int screen_num)
		{
			return Object.GetObject(Display.gdk_display_get_screen(base.Handle, screen_num)) as Screen;
		}

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x06000278 RID: 632 RVA: 0x00009124 File Offset: 0x00007324
		public new static GType GType
		{
			get
			{
				IntPtr val = Display.gdk_display_get_type();
				return new GType(val);
			}
		}

		// Token: 0x06000279 RID: 633 RVA: 0x00009142 File Offset: 0x00007342
		[Obsolete]
		public Window GetWindowAtPointer(out int win_x, out int win_y)
		{
			return Object.GetObject(Display.gdk_display_get_window_at_pointer(base.Handle, out win_x, out win_y)) as Window;
		}

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x0600027A RID: 634 RVA: 0x00009160 File Offset: 0x00007360
		public bool HasPending
		{
			get
			{
				return Display.gdk_display_has_pending(base.Handle);
			}
		}

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x0600027B RID: 635 RVA: 0x00009172 File Offset: 0x00007372
		public bool IsClosed
		{
			get
			{
				return Display.gdk_display_is_closed(base.Handle);
			}
		}

		// Token: 0x0600027C RID: 636 RVA: 0x00009184 File Offset: 0x00007384
		[Obsolete]
		public void KeyboardUngrab(uint time_)
		{
			Display.gdk_display_keyboard_ungrab(base.Handle, time_);
		}

		// Token: 0x0600027D RID: 637 RVA: 0x00009197 File Offset: 0x00007397
		public Seat[] ListSeats()
		{
			return (Seat[])Marshaller.ListPtrToArray(Display.gdk_display_list_seats(base.Handle), typeof(List), true, false, typeof(Seat));
		}

		// Token: 0x0600027E RID: 638 RVA: 0x000091CC File Offset: 0x000073CC
		public void NotifyStartupComplete(string startup_id)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(startup_id);
			Display.gdk_display_notify_startup_complete(base.Handle, intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x0600027F RID: 639 RVA: 0x000091F8 File Offset: 0x000073F8
		public static Display Open(string display_name)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(display_name);
			Display result = Object.GetObject(Display.gdk_display_open(intPtr)) as Display;
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x06000280 RID: 640 RVA: 0x00009227 File Offset: 0x00007427
		[Obsolete]
		public static Display OpenDefaultLibgtkOnly()
		{
			return Object.GetObject(Display.gdk_display_open_default_libgtk_only()) as Display;
		}

		// Token: 0x06000281 RID: 641 RVA: 0x0000923D File Offset: 0x0000743D
		public Event PeekEvent()
		{
			return Event.GetEvent(Display.gdk_display_peek_event(base.Handle));
		}

		// Token: 0x06000282 RID: 642 RVA: 0x00009254 File Offset: 0x00007454
		[Obsolete]
		public bool PointerIsGrabbed()
		{
			return Display.gdk_display_pointer_is_grabbed(base.Handle);
		}

		// Token: 0x06000283 RID: 643 RVA: 0x00009266 File Offset: 0x00007466
		[Obsolete]
		public void PointerUngrab(uint time_)
		{
			Display.gdk_display_pointer_ungrab(base.Handle, time_);
		}

		// Token: 0x06000284 RID: 644 RVA: 0x00009279 File Offset: 0x00007479
		public void PutEvent(Event evnt)
		{
			Display.gdk_display_put_event(base.Handle, (evnt == null) ? IntPtr.Zero : evnt.Handle);
		}

		// Token: 0x06000285 RID: 645 RVA: 0x0000929B File Offset: 0x0000749B
		public bool RequestSelectionNotification(Atom selection)
		{
			return Display.gdk_display_request_selection_notification(base.Handle, (selection == null) ? IntPtr.Zero : selection.Handle);
		}

		// Token: 0x17000074 RID: 116
		// (set) Token: 0x06000286 RID: 646 RVA: 0x000092BD File Offset: 0x000074BD
		public uint DoubleClickDistance
		{
			set
			{
				Display.gdk_display_set_double_click_distance(base.Handle, value);
			}
		}

		// Token: 0x17000075 RID: 117
		// (set) Token: 0x06000287 RID: 647 RVA: 0x000092D0 File Offset: 0x000074D0
		public uint DoubleClickTime
		{
			set
			{
				Display.gdk_display_set_double_click_time(base.Handle, value);
			}
		}

		// Token: 0x06000288 RID: 648 RVA: 0x000092E3 File Offset: 0x000074E3
		public void StoreClipboard(Window clipboard_window, uint time_, Atom targets, int n_targets)
		{
			Display.gdk_display_store_clipboard(base.Handle, (clipboard_window == null) ? IntPtr.Zero : clipboard_window.Handle, time_, (targets == null) ? IntPtr.Zero : targets.Handle, n_targets);
		}

		// Token: 0x06000289 RID: 649 RVA: 0x00009318 File Offset: 0x00007518
		public bool SupportsClipboardPersistence()
		{
			return Display.gdk_display_supports_clipboard_persistence(base.Handle);
		}

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x0600028A RID: 650 RVA: 0x0000932A File Offset: 0x0000752A
		[Obsolete]
		public bool SupportsComposite
		{
			get
			{
				return Display.gdk_display_supports_composite(base.Handle);
			}
		}

		// Token: 0x0600028B RID: 651 RVA: 0x0000933C File Offset: 0x0000753C
		public bool SupportsCursorAlpha()
		{
			return Display.gdk_display_supports_cursor_alpha(base.Handle);
		}

		// Token: 0x0600028C RID: 652 RVA: 0x0000934E File Offset: 0x0000754E
		public bool SupportsCursorColor()
		{
			return Display.gdk_display_supports_cursor_color(base.Handle);
		}

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x0600028D RID: 653 RVA: 0x00009360 File Offset: 0x00007560
		public bool SupportsInputShapes
		{
			get
			{
				return Display.gdk_display_supports_input_shapes(base.Handle);
			}
		}

		// Token: 0x0600028E RID: 654 RVA: 0x00009372 File Offset: 0x00007572
		public bool SupportsSelectionNotification()
		{
			return Display.gdk_display_supports_selection_notification(base.Handle);
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x0600028F RID: 655 RVA: 0x00009384 File Offset: 0x00007584
		public bool SupportsShapes
		{
			get
			{
				return Display.gdk_display_supports_shapes(base.Handle);
			}
		}

		// Token: 0x06000290 RID: 656 RVA: 0x00009396 File Offset: 0x00007596
		public void Sync()
		{
			Display.gdk_display_sync(base.Handle);
		}

		// Token: 0x06000291 RID: 657 RVA: 0x000093A8 File Offset: 0x000075A8
		[Obsolete]
		public void WarpPointer(Screen screen, int x, int y)
		{
			Display.gdk_display_warp_pointer(base.Handle, (screen == null) ? IntPtr.Zero : screen.Handle, x, y);
		}

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x06000292 RID: 658 RVA: 0x000093CC File Offset: 0x000075CC
		public new static AbiStruct abi_info
		{
			get
			{
				if (Display._abi_info == null)
				{
					Display._abi_info = new AbiStruct(Object.abi_info.Fields);
				}
				return Display._abi_info;
			}
		}

		// Token: 0x0400008F RID: 143
		private static Display.d_gdk_display_get_pointer gdk_display_get_pointer = FuncLoader.LoadFunction<Display.d_gdk_display_get_pointer>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_pointer"));

		// Token: 0x04000090 RID: 144
		private static Display.d_gdk_display_get_pointer2 gdk_display_get_pointer2 = FuncLoader.LoadFunction<Display.d_gdk_display_get_pointer2>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_pointer"));

		// Token: 0x04000091 RID: 145
		private static Display.d_gdk_display_list_devices gdk_display_list_devices = FuncLoader.LoadFunction<Display.d_gdk_display_list_devices>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_list_devices"));

		// Token: 0x04000092 RID: 146
		private static Display.SeatAddedNativeDelegate SeatAdded_cb_delegate;

		// Token: 0x04000093 RID: 147
		private static Display.SeatRemovedNativeDelegate SeatRemoved_cb_delegate;

		// Token: 0x04000094 RID: 148
		private static Display.MonitorAddedNativeDelegate MonitorAdded_cb_delegate;

		// Token: 0x04000095 RID: 149
		private static Display.MonitorRemovedNativeDelegate MonitorRemoved_cb_delegate;

		// Token: 0x04000096 RID: 150
		private static Display.GetNameNativeDelegate GetName_cb_delegate;

		// Token: 0x04000097 RID: 151
		private static Display.GetDefaultScreenNativeDelegate GetDefaultScreen_cb_delegate;

		// Token: 0x04000098 RID: 152
		private static Display.BeepNativeDelegate Beep_cb_delegate;

		// Token: 0x04000099 RID: 153
		private static Display.SyncNativeDelegate Sync_cb_delegate;

		// Token: 0x0400009A RID: 154
		private static Display.FlushNativeDelegate Flush_cb_delegate;

		// Token: 0x0400009B RID: 155
		private static Display.HasPendingNativeDelegate HasPending_cb_delegate;

		// Token: 0x0400009C RID: 156
		private static Display.QueueEventsNativeDelegate QueueEvents_cb_delegate;

		// Token: 0x0400009D RID: 157
		private static Display.MakeDefaultNativeDelegate MakeDefault_cb_delegate;

		// Token: 0x0400009E RID: 158
		private static Display.GetDefaultGroupNativeDelegate GetDefaultGroup_cb_delegate;

		// Token: 0x0400009F RID: 159
		private static Display.SupportsSelectionNotificationNativeDelegate SupportsSelectionNotification_cb_delegate;

		// Token: 0x040000A0 RID: 160
		private static Display.RequestSelectionNotificationNativeDelegate RequestSelectionNotification_cb_delegate;

		// Token: 0x040000A1 RID: 161
		private static Display.SupportsShapesNativeDelegate SupportsShapes_cb_delegate;

		// Token: 0x040000A2 RID: 162
		private static Display.SupportsInputShapesNativeDelegate SupportsInputShapes_cb_delegate;

		// Token: 0x040000A3 RID: 163
		private static Display.SupportsCompositeNativeDelegate SupportsComposite_cb_delegate;

		// Token: 0x040000A4 RID: 164
		private static Display.SupportsCursorAlphaNativeDelegate SupportsCursorAlpha_cb_delegate;

		// Token: 0x040000A5 RID: 165
		private static Display.SupportsCursorColorNativeDelegate SupportsCursorColor_cb_delegate;

		// Token: 0x040000A6 RID: 166
		private static Display.SupportsClipboardPersistenceNativeDelegate SupportsClipboardPersistence_cb_delegate;

		// Token: 0x040000A7 RID: 167
		private static Display.StoreClipboardNativeDelegate StoreClipboard_cb_delegate;

		// Token: 0x040000A8 RID: 168
		private static Display.GetDefaultCursorSizeNativeDelegate GetDefaultCursorSize_cb_delegate;

		// Token: 0x040000A9 RID: 169
		private static Display.GetMaximalCursorSizeNativeDelegate GetMaximalCursorSize_cb_delegate;

		// Token: 0x040000AA RID: 170
		private static Display.GetCursorForTypeNativeDelegate GetCursorForType_cb_delegate;

		// Token: 0x040000AB RID: 171
		private static Display.GetCursorForNameNativeDelegate GetCursorForName_cb_delegate;

		// Token: 0x040000AC RID: 172
		private static Display.GetCursorForSurfaceNativeDelegate GetCursorForSurface_cb_delegate;

		// Token: 0x040000AD RID: 173
		private static Display.GetAppLaunchContextNativeDelegate GetAppLaunchContext_cb_delegate;

		// Token: 0x040000AE RID: 174
		private static Display.BeforeProcessAllUpdatesNativeDelegate BeforeProcessAllUpdates_cb_delegate;

		// Token: 0x040000AF RID: 175
		private static Display.AfterProcessAllUpdatesNativeDelegate AfterProcessAllUpdates_cb_delegate;

		// Token: 0x040000B0 RID: 176
		private static Display.GetNextSerialNativeDelegate GetNextSerial_cb_delegate;

		// Token: 0x040000B1 RID: 177
		private static Display.NotifyStartupCompleteNativeDelegate NotifyStartupComplete_cb_delegate;

		// Token: 0x040000B2 RID: 178
		private static Display.EventDataCopyNativeDelegate EventDataCopy_cb_delegate;

		// Token: 0x040000B3 RID: 179
		private static Display.EventDataFreeNativeDelegate EventDataFree_cb_delegate;

		// Token: 0x040000B4 RID: 180
		private static Display.CreateWindowImplNativeDelegate CreateWindowImpl_cb_delegate;

		// Token: 0x040000B5 RID: 181
		private static Display.GetKeymapNativeDelegate GetKeymap_cb_delegate;

		// Token: 0x040000B6 RID: 182
		private static Display.PushErrorTrapNativeDelegate PushErrorTrap_cb_delegate;

		// Token: 0x040000B7 RID: 183
		private static Display.PopErrorTrapNativeDelegate PopErrorTrap_cb_delegate;

		// Token: 0x040000B8 RID: 184
		private static Display.GetSelectionOwnerNativeDelegate GetSelectionOwner_cb_delegate;

		// Token: 0x040000B9 RID: 185
		private static Display.SetSelectionOwnerNativeDelegate SetSelectionOwner_cb_delegate;

		// Token: 0x040000BA RID: 186
		private static Display.SendSelectionNotifyNativeDelegate SendSelectionNotify_cb_delegate;

		// Token: 0x040000BB RID: 187
		private static Display.GetSelectionPropertyNativeDelegate GetSelectionProperty_cb_delegate;

		// Token: 0x040000BC RID: 188
		private static Display.ConvertSelectionNativeDelegate ConvertSelection_cb_delegate;

		// Token: 0x040000BD RID: 189
		private static Display.TextPropertyToUtf8ListNativeDelegate TextPropertyToUtf8List_cb_delegate;

		// Token: 0x040000BE RID: 190
		private static Display.Utf8ToStringTargetNativeDelegate Utf8ToStringTarget_cb_delegate;

		// Token: 0x040000BF RID: 191
		private static Display.MakeGlContextCurrentNativeDelegate MakeGlContextCurrent_cb_delegate;

		// Token: 0x040000C0 RID: 192
		private static Display.GetDefaultSeatNativeDelegate GetDefaultSeat_cb_delegate;

		// Token: 0x040000C1 RID: 193
		private static Display.GetNMonitorsNativeDelegate GetNMonitors_cb_delegate;

		// Token: 0x040000C2 RID: 194
		private static Display.GetMonitorNativeDelegate GetMonitor_cb_delegate;

		// Token: 0x040000C3 RID: 195
		private static Display.GetPrimaryMonitorNativeDelegate GetPrimaryMonitor_cb_delegate;

		// Token: 0x040000C4 RID: 196
		private static Display.GetMonitorAtWindowNativeDelegate GetMonitorAtWindow_cb_delegate;

		// Token: 0x040000C5 RID: 197
		private static Display.OpenedNativeDelegate Opened_cb_delegate;

		// Token: 0x040000C6 RID: 198
		private static Display.ClosedNativeDelegate Closed_cb_delegate;

		// Token: 0x040000C7 RID: 199
		private static AbiStruct _class_abi = null;

		// Token: 0x040000C8 RID: 200
		private static Display.d_gdk_display_beep gdk_display_beep = FuncLoader.LoadFunction<Display.d_gdk_display_beep>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_beep"));

		// Token: 0x040000C9 RID: 201
		private static Display.d_gdk_display_close gdk_display_close = FuncLoader.LoadFunction<Display.d_gdk_display_close>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_close"));

		// Token: 0x040000CA RID: 202
		private static Display.d_gdk_display_device_is_grabbed gdk_display_device_is_grabbed = FuncLoader.LoadFunction<Display.d_gdk_display_device_is_grabbed>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_device_is_grabbed"));

		// Token: 0x040000CB RID: 203
		private static Display.d_gdk_display_flush gdk_display_flush = FuncLoader.LoadFunction<Display.d_gdk_display_flush>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_flush"));

		// Token: 0x040000CC RID: 204
		private static Display.d_gdk_display_get_app_launch_context gdk_display_get_app_launch_context = FuncLoader.LoadFunction<Display.d_gdk_display_get_app_launch_context>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_app_launch_context"));

		// Token: 0x040000CD RID: 205
		private static Display.d_gdk_display_get_default gdk_display_get_default = FuncLoader.LoadFunction<Display.d_gdk_display_get_default>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_default"));

		// Token: 0x040000CE RID: 206
		private static Display.d_gdk_display_get_default_cursor_size gdk_display_get_default_cursor_size = FuncLoader.LoadFunction<Display.d_gdk_display_get_default_cursor_size>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_default_cursor_size"));

		// Token: 0x040000CF RID: 207
		private static Display.d_gdk_display_get_default_group gdk_display_get_default_group = FuncLoader.LoadFunction<Display.d_gdk_display_get_default_group>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_default_group"));

		// Token: 0x040000D0 RID: 208
		private static Display.d_gdk_display_get_default_screen gdk_display_get_default_screen = FuncLoader.LoadFunction<Display.d_gdk_display_get_default_screen>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_default_screen"));

		// Token: 0x040000D1 RID: 209
		private static Display.d_gdk_display_get_default_seat gdk_display_get_default_seat = FuncLoader.LoadFunction<Display.d_gdk_display_get_default_seat>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_default_seat"));

		// Token: 0x040000D2 RID: 210
		private static Display.d_gdk_display_get_device_manager gdk_display_get_device_manager = FuncLoader.LoadFunction<Display.d_gdk_display_get_device_manager>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_device_manager"));

		// Token: 0x040000D3 RID: 211
		private static Display.d_gdk_display_get_event gdk_display_get_event = FuncLoader.LoadFunction<Display.d_gdk_display_get_event>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_event"));

		// Token: 0x040000D4 RID: 212
		private static Display.d_gdk_display_get_maximal_cursor_size gdk_display_get_maximal_cursor_size = FuncLoader.LoadFunction<Display.d_gdk_display_get_maximal_cursor_size>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_maximal_cursor_size"));

		// Token: 0x040000D5 RID: 213
		private static Display.d_gdk_display_get_monitor gdk_display_get_monitor = FuncLoader.LoadFunction<Display.d_gdk_display_get_monitor>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_monitor"));

		// Token: 0x040000D6 RID: 214
		private static Display.d_gdk_display_get_monitor_at_point gdk_display_get_monitor_at_point = FuncLoader.LoadFunction<Display.d_gdk_display_get_monitor_at_point>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_monitor_at_point"));

		// Token: 0x040000D7 RID: 215
		private static Display.d_gdk_display_get_monitor_at_window gdk_display_get_monitor_at_window = FuncLoader.LoadFunction<Display.d_gdk_display_get_monitor_at_window>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_monitor_at_window"));

		// Token: 0x040000D8 RID: 216
		private static Display.d_gdk_display_get_n_monitors gdk_display_get_n_monitors = FuncLoader.LoadFunction<Display.d_gdk_display_get_n_monitors>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_n_monitors"));

		// Token: 0x040000D9 RID: 217
		private static Display.d_gdk_display_get_n_screens gdk_display_get_n_screens = FuncLoader.LoadFunction<Display.d_gdk_display_get_n_screens>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_n_screens"));

		// Token: 0x040000DA RID: 218
		private static Display.d_gdk_display_get_name gdk_display_get_name = FuncLoader.LoadFunction<Display.d_gdk_display_get_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_name"));

		// Token: 0x040000DB RID: 219
		private static Display.d_gdk_display_get_primary_monitor gdk_display_get_primary_monitor = FuncLoader.LoadFunction<Display.d_gdk_display_get_primary_monitor>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_primary_monitor"));

		// Token: 0x040000DC RID: 220
		private static Display.d_gdk_display_get_screen gdk_display_get_screen = FuncLoader.LoadFunction<Display.d_gdk_display_get_screen>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_screen"));

		// Token: 0x040000DD RID: 221
		private static Display.d_gdk_display_get_type gdk_display_get_type = FuncLoader.LoadFunction<Display.d_gdk_display_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_type"));

		// Token: 0x040000DE RID: 222
		private static Display.d_gdk_display_get_window_at_pointer gdk_display_get_window_at_pointer = FuncLoader.LoadFunction<Display.d_gdk_display_get_window_at_pointer>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_get_window_at_pointer"));

		// Token: 0x040000DF RID: 223
		private static Display.d_gdk_display_has_pending gdk_display_has_pending = FuncLoader.LoadFunction<Display.d_gdk_display_has_pending>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_has_pending"));

		// Token: 0x040000E0 RID: 224
		private static Display.d_gdk_display_is_closed gdk_display_is_closed = FuncLoader.LoadFunction<Display.d_gdk_display_is_closed>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_is_closed"));

		// Token: 0x040000E1 RID: 225
		private static Display.d_gdk_display_keyboard_ungrab gdk_display_keyboard_ungrab = FuncLoader.LoadFunction<Display.d_gdk_display_keyboard_ungrab>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_keyboard_ungrab"));

		// Token: 0x040000E2 RID: 226
		private static Display.d_gdk_display_list_seats gdk_display_list_seats = FuncLoader.LoadFunction<Display.d_gdk_display_list_seats>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_list_seats"));

		// Token: 0x040000E3 RID: 227
		private static Display.d_gdk_display_notify_startup_complete gdk_display_notify_startup_complete = FuncLoader.LoadFunction<Display.d_gdk_display_notify_startup_complete>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_notify_startup_complete"));

		// Token: 0x040000E4 RID: 228
		private static Display.d_gdk_display_open gdk_display_open = FuncLoader.LoadFunction<Display.d_gdk_display_open>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_open"));

		// Token: 0x040000E5 RID: 229
		private static Display.d_gdk_display_open_default_libgtk_only gdk_display_open_default_libgtk_only = FuncLoader.LoadFunction<Display.d_gdk_display_open_default_libgtk_only>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_open_default_libgtk_only"));

		// Token: 0x040000E6 RID: 230
		private static Display.d_gdk_display_peek_event gdk_display_peek_event = FuncLoader.LoadFunction<Display.d_gdk_display_peek_event>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_peek_event"));

		// Token: 0x040000E7 RID: 231
		private static Display.d_gdk_display_pointer_is_grabbed gdk_display_pointer_is_grabbed = FuncLoader.LoadFunction<Display.d_gdk_display_pointer_is_grabbed>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_pointer_is_grabbed"));

		// Token: 0x040000E8 RID: 232
		private static Display.d_gdk_display_pointer_ungrab gdk_display_pointer_ungrab = FuncLoader.LoadFunction<Display.d_gdk_display_pointer_ungrab>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_pointer_ungrab"));

		// Token: 0x040000E9 RID: 233
		private static Display.d_gdk_display_put_event gdk_display_put_event = FuncLoader.LoadFunction<Display.d_gdk_display_put_event>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_put_event"));

		// Token: 0x040000EA RID: 234
		private static Display.d_gdk_display_request_selection_notification gdk_display_request_selection_notification = FuncLoader.LoadFunction<Display.d_gdk_display_request_selection_notification>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_request_selection_notification"));

		// Token: 0x040000EB RID: 235
		private static Display.d_gdk_display_set_double_click_distance gdk_display_set_double_click_distance = FuncLoader.LoadFunction<Display.d_gdk_display_set_double_click_distance>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_set_double_click_distance"));

		// Token: 0x040000EC RID: 236
		private static Display.d_gdk_display_set_double_click_time gdk_display_set_double_click_time = FuncLoader.LoadFunction<Display.d_gdk_display_set_double_click_time>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_set_double_click_time"));

		// Token: 0x040000ED RID: 237
		private static Display.d_gdk_display_store_clipboard gdk_display_store_clipboard = FuncLoader.LoadFunction<Display.d_gdk_display_store_clipboard>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_store_clipboard"));

		// Token: 0x040000EE RID: 238
		private static Display.d_gdk_display_supports_clipboard_persistence gdk_display_supports_clipboard_persistence = FuncLoader.LoadFunction<Display.d_gdk_display_supports_clipboard_persistence>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_supports_clipboard_persistence"));

		// Token: 0x040000EF RID: 239
		private static Display.d_gdk_display_supports_composite gdk_display_supports_composite = FuncLoader.LoadFunction<Display.d_gdk_display_supports_composite>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_supports_composite"));

		// Token: 0x040000F0 RID: 240
		private static Display.d_gdk_display_supports_cursor_alpha gdk_display_supports_cursor_alpha = FuncLoader.LoadFunction<Display.d_gdk_display_supports_cursor_alpha>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_supports_cursor_alpha"));

		// Token: 0x040000F1 RID: 241
		private static Display.d_gdk_display_supports_cursor_color gdk_display_supports_cursor_color = FuncLoader.LoadFunction<Display.d_gdk_display_supports_cursor_color>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_supports_cursor_color"));

		// Token: 0x040000F2 RID: 242
		private static Display.d_gdk_display_supports_input_shapes gdk_display_supports_input_shapes = FuncLoader.LoadFunction<Display.d_gdk_display_supports_input_shapes>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_supports_input_shapes"));

		// Token: 0x040000F3 RID: 243
		private static Display.d_gdk_display_supports_selection_notification gdk_display_supports_selection_notification = FuncLoader.LoadFunction<Display.d_gdk_display_supports_selection_notification>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_supports_selection_notification"));

		// Token: 0x040000F4 RID: 244
		private static Display.d_gdk_display_supports_shapes gdk_display_supports_shapes = FuncLoader.LoadFunction<Display.d_gdk_display_supports_shapes>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_supports_shapes"));

		// Token: 0x040000F5 RID: 245
		private static Display.d_gdk_display_sync gdk_display_sync = FuncLoader.LoadFunction<Display.d_gdk_display_sync>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_sync"));

		// Token: 0x040000F6 RID: 246
		private static Display.d_gdk_display_warp_pointer gdk_display_warp_pointer = FuncLoader.LoadFunction<Display.d_gdk_display_warp_pointer>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_warp_pointer"));

		// Token: 0x040000F7 RID: 247
		private static AbiStruct _abi_info = null;

		// Token: 0x02000168 RID: 360
		// (Invoke) Token: 0x06000C77 RID: 3191
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_display_get_pointer(IntPtr raw, IntPtr screen, out int x, out int y, out int mask);

		// Token: 0x02000169 RID: 361
		// (Invoke) Token: 0x06000C7B RID: 3195
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_display_get_pointer2(IntPtr raw, out IntPtr screen, out int x, out int y, out int mask);

		// Token: 0x0200016A RID: 362
		// (Invoke) Token: 0x06000C7F RID: 3199
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_list_devices(IntPtr raw);

		// Token: 0x0200016B RID: 363
		// (Invoke) Token: 0x06000C83 RID: 3203
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void SeatAddedNativeDelegate(IntPtr inst, IntPtr p0);

		// Token: 0x0200016C RID: 364
		// (Invoke) Token: 0x06000C87 RID: 3207
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void SeatRemovedNativeDelegate(IntPtr inst, IntPtr p0);

		// Token: 0x0200016D RID: 365
		// (Invoke) Token: 0x06000C8B RID: 3211
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void MonitorAddedNativeDelegate(IntPtr inst, IntPtr p0);

		// Token: 0x0200016E RID: 366
		// (Invoke) Token: 0x06000C8F RID: 3215
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void MonitorRemovedNativeDelegate(IntPtr inst, IntPtr p0);

		// Token: 0x0200016F RID: 367
		// (Invoke) Token: 0x06000C93 RID: 3219
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetNameNativeDelegate(IntPtr inst);

		// Token: 0x02000170 RID: 368
		// (Invoke) Token: 0x06000C97 RID: 3223
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetDefaultScreenNativeDelegate(IntPtr inst);

		// Token: 0x02000171 RID: 369
		// (Invoke) Token: 0x06000C9B RID: 3227
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void BeepNativeDelegate(IntPtr inst);

		// Token: 0x02000172 RID: 370
		// (Invoke) Token: 0x06000C9F RID: 3231
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void SyncNativeDelegate(IntPtr inst);

		// Token: 0x02000173 RID: 371
		// (Invoke) Token: 0x06000CA3 RID: 3235
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void FlushNativeDelegate(IntPtr inst);

		// Token: 0x02000174 RID: 372
		// (Invoke) Token: 0x06000CA7 RID: 3239
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool HasPendingNativeDelegate(IntPtr inst);

		// Token: 0x02000175 RID: 373
		// (Invoke) Token: 0x06000CAB RID: 3243
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void QueueEventsNativeDelegate(IntPtr inst);

		// Token: 0x02000176 RID: 374
		// (Invoke) Token: 0x06000CAF RID: 3247
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void MakeDefaultNativeDelegate(IntPtr inst);

		// Token: 0x02000177 RID: 375
		// (Invoke) Token: 0x06000CB3 RID: 3251
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetDefaultGroupNativeDelegate(IntPtr inst);

		// Token: 0x02000178 RID: 376
		// (Invoke) Token: 0x06000CB7 RID: 3255
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool SupportsSelectionNotificationNativeDelegate(IntPtr inst);

		// Token: 0x02000179 RID: 377
		// (Invoke) Token: 0x06000CBB RID: 3259
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool RequestSelectionNotificationNativeDelegate(IntPtr inst, IntPtr selection);

		// Token: 0x0200017A RID: 378
		// (Invoke) Token: 0x06000CBF RID: 3263
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool SupportsShapesNativeDelegate(IntPtr inst);

		// Token: 0x0200017B RID: 379
		// (Invoke) Token: 0x06000CC3 RID: 3267
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool SupportsInputShapesNativeDelegate(IntPtr inst);

		// Token: 0x0200017C RID: 380
		// (Invoke) Token: 0x06000CC7 RID: 3271
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool SupportsCompositeNativeDelegate(IntPtr inst);

		// Token: 0x0200017D RID: 381
		// (Invoke) Token: 0x06000CCB RID: 3275
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool SupportsCursorAlphaNativeDelegate(IntPtr inst);

		// Token: 0x0200017E RID: 382
		// (Invoke) Token: 0x06000CCF RID: 3279
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool SupportsCursorColorNativeDelegate(IntPtr inst);

		// Token: 0x0200017F RID: 383
		// (Invoke) Token: 0x06000CD3 RID: 3283
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool SupportsClipboardPersistenceNativeDelegate(IntPtr inst);

		// Token: 0x02000180 RID: 384
		// (Invoke) Token: 0x06000CD7 RID: 3287
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void StoreClipboardNativeDelegate(IntPtr inst, IntPtr clipboard_window, uint time_, IntPtr targets, int n_targets);

		// Token: 0x02000181 RID: 385
		// (Invoke) Token: 0x06000CDB RID: 3291
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void GetDefaultCursorSizeNativeDelegate(IntPtr inst, out uint width, out uint height);

		// Token: 0x02000182 RID: 386
		// (Invoke) Token: 0x06000CDF RID: 3295
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void GetMaximalCursorSizeNativeDelegate(IntPtr inst, out uint width, out uint height);

		// Token: 0x02000183 RID: 387
		// (Invoke) Token: 0x06000CE3 RID: 3299
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetCursorForTypeNativeDelegate(IntPtr inst, int type);

		// Token: 0x02000184 RID: 388
		// (Invoke) Token: 0x06000CE7 RID: 3303
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetCursorForNameNativeDelegate(IntPtr inst, IntPtr name);

		// Token: 0x02000185 RID: 389
		// (Invoke) Token: 0x06000CEB RID: 3307
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetCursorForSurfaceNativeDelegate(IntPtr inst, IntPtr surface, double x, double y);

		// Token: 0x02000186 RID: 390
		// (Invoke) Token: 0x06000CEF RID: 3311
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetAppLaunchContextNativeDelegate(IntPtr inst);

		// Token: 0x02000187 RID: 391
		// (Invoke) Token: 0x06000CF3 RID: 3315
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void BeforeProcessAllUpdatesNativeDelegate(IntPtr inst);

		// Token: 0x02000188 RID: 392
		// (Invoke) Token: 0x06000CF7 RID: 3319
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void AfterProcessAllUpdatesNativeDelegate(IntPtr inst);

		// Token: 0x02000189 RID: 393
		// (Invoke) Token: 0x06000CFB RID: 3323
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate UIntPtr GetNextSerialNativeDelegate(IntPtr inst);

		// Token: 0x0200018A RID: 394
		// (Invoke) Token: 0x06000CFF RID: 3327
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void NotifyStartupCompleteNativeDelegate(IntPtr inst, IntPtr startup_id);

		// Token: 0x0200018B RID: 395
		// (Invoke) Token: 0x06000D03 RID: 3331
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void EventDataCopyNativeDelegate(IntPtr inst, IntPtr evnt, IntPtr new_event);

		// Token: 0x0200018C RID: 396
		// (Invoke) Token: 0x06000D07 RID: 3335
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void EventDataFreeNativeDelegate(IntPtr inst, IntPtr evnt);

		// Token: 0x0200018D RID: 397
		// (Invoke) Token: 0x06000D0B RID: 3339
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void CreateWindowImplNativeDelegate(IntPtr inst, IntPtr window, IntPtr real_parent, IntPtr screen, int event_mask, IntPtr attributes, int attributes_mask);

		// Token: 0x0200018E RID: 398
		// (Invoke) Token: 0x06000D0F RID: 3343
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetKeymapNativeDelegate(IntPtr inst);

		// Token: 0x0200018F RID: 399
		// (Invoke) Token: 0x06000D13 RID: 3347
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void PushErrorTrapNativeDelegate(IntPtr inst);

		// Token: 0x02000190 RID: 400
		// (Invoke) Token: 0x06000D17 RID: 3351
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int PopErrorTrapNativeDelegate(IntPtr inst, bool ignore);

		// Token: 0x02000191 RID: 401
		// (Invoke) Token: 0x06000D1B RID: 3355
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetSelectionOwnerNativeDelegate(IntPtr inst, IntPtr selection);

		// Token: 0x02000192 RID: 402
		// (Invoke) Token: 0x06000D1F RID: 3359
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool SetSelectionOwnerNativeDelegate(IntPtr inst, IntPtr owner, IntPtr selection, uint time, bool send_event);

		// Token: 0x02000193 RID: 403
		// (Invoke) Token: 0x06000D23 RID: 3363
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void SendSelectionNotifyNativeDelegate(IntPtr inst, IntPtr requestor, IntPtr selection, IntPtr target, IntPtr property, uint time);

		// Token: 0x02000194 RID: 404
		// (Invoke) Token: 0x06000D27 RID: 3367
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetSelectionPropertyNativeDelegate(IntPtr inst, IntPtr requestor, out byte data, IntPtr type, out int format);

		// Token: 0x02000195 RID: 405
		// (Invoke) Token: 0x06000D2B RID: 3371
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ConvertSelectionNativeDelegate(IntPtr inst, IntPtr requestor, IntPtr selection, IntPtr target, uint time);

		// Token: 0x02000196 RID: 406
		// (Invoke) Token: 0x06000D2F RID: 3375
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int TextPropertyToUtf8ListNativeDelegate(IntPtr inst, IntPtr encoding, int format, out byte text, int length, IntPtr list);

		// Token: 0x02000197 RID: 407
		// (Invoke) Token: 0x06000D33 RID: 3379
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr Utf8ToStringTargetNativeDelegate(IntPtr inst, IntPtr text);

		// Token: 0x02000198 RID: 408
		// (Invoke) Token: 0x06000D37 RID: 3383
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool MakeGlContextCurrentNativeDelegate(IntPtr inst, IntPtr context);

		// Token: 0x02000199 RID: 409
		// (Invoke) Token: 0x06000D3B RID: 3387
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetDefaultSeatNativeDelegate(IntPtr inst);

		// Token: 0x0200019A RID: 410
		// (Invoke) Token: 0x06000D3F RID: 3391
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetNMonitorsNativeDelegate(IntPtr inst);

		// Token: 0x0200019B RID: 411
		// (Invoke) Token: 0x06000D43 RID: 3395
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetMonitorNativeDelegate(IntPtr inst, int index);

		// Token: 0x0200019C RID: 412
		// (Invoke) Token: 0x06000D47 RID: 3399
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetPrimaryMonitorNativeDelegate(IntPtr inst);

		// Token: 0x0200019D RID: 413
		// (Invoke) Token: 0x06000D4B RID: 3403
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetMonitorAtWindowNativeDelegate(IntPtr inst, IntPtr window);

		// Token: 0x0200019E RID: 414
		// (Invoke) Token: 0x06000D4F RID: 3407
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void OpenedNativeDelegate(IntPtr inst);

		// Token: 0x0200019F RID: 415
		// (Invoke) Token: 0x06000D53 RID: 3411
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ClosedNativeDelegate(IntPtr inst, bool is_error);

		// Token: 0x020001A0 RID: 416
		public struct GdkDisplay_window_typeAlign
		{
			// Token: 0x04000C0A RID: 3082
			private sbyte f1;

			// Token: 0x04000C0B RID: 3083
			private GType window_type;
		}

		// Token: 0x020001A1 RID: 417
		// (Invoke) Token: 0x06000D57 RID: 3415
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_display_beep(IntPtr raw);

		// Token: 0x020001A2 RID: 418
		// (Invoke) Token: 0x06000D5B RID: 3419
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_display_close(IntPtr raw);

		// Token: 0x020001A3 RID: 419
		// (Invoke) Token: 0x06000D5F RID: 3423
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_display_device_is_grabbed(IntPtr raw, IntPtr device);

		// Token: 0x020001A4 RID: 420
		// (Invoke) Token: 0x06000D63 RID: 3427
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_display_flush(IntPtr raw);

		// Token: 0x020001A5 RID: 421
		// (Invoke) Token: 0x06000D67 RID: 3431
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_get_app_launch_context(IntPtr raw);

		// Token: 0x020001A6 RID: 422
		// (Invoke) Token: 0x06000D6B RID: 3435
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_get_default();

		// Token: 0x020001A7 RID: 423
		// (Invoke) Token: 0x06000D6F RID: 3439
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gdk_display_get_default_cursor_size(IntPtr raw);

		// Token: 0x020001A8 RID: 424
		// (Invoke) Token: 0x06000D73 RID: 3443
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_get_default_group(IntPtr raw);

		// Token: 0x020001A9 RID: 425
		// (Invoke) Token: 0x06000D77 RID: 3447
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_get_default_screen(IntPtr raw);

		// Token: 0x020001AA RID: 426
		// (Invoke) Token: 0x06000D7B RID: 3451
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_get_default_seat(IntPtr raw);

		// Token: 0x020001AB RID: 427
		// (Invoke) Token: 0x06000D7F RID: 3455
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_get_device_manager(IntPtr raw);

		// Token: 0x020001AC RID: 428
		// (Invoke) Token: 0x06000D83 RID: 3459
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_get_event(IntPtr raw);

		// Token: 0x020001AD RID: 429
		// (Invoke) Token: 0x06000D87 RID: 3463
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_display_get_maximal_cursor_size(IntPtr raw, out uint width, out uint height);

		// Token: 0x020001AE RID: 430
		// (Invoke) Token: 0x06000D8B RID: 3467
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_get_monitor(IntPtr raw, int monitor_num);

		// Token: 0x020001AF RID: 431
		// (Invoke) Token: 0x06000D8F RID: 3471
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_get_monitor_at_point(IntPtr raw, int x, int y);

		// Token: 0x020001B0 RID: 432
		// (Invoke) Token: 0x06000D93 RID: 3475
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_get_monitor_at_window(IntPtr raw, IntPtr window);

		// Token: 0x020001B1 RID: 433
		// (Invoke) Token: 0x06000D97 RID: 3479
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_display_get_n_monitors(IntPtr raw);

		// Token: 0x020001B2 RID: 434
		// (Invoke) Token: 0x06000D9B RID: 3483
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_display_get_n_screens(IntPtr raw);

		// Token: 0x020001B3 RID: 435
		// (Invoke) Token: 0x06000D9F RID: 3487
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_get_name(IntPtr raw);

		// Token: 0x020001B4 RID: 436
		// (Invoke) Token: 0x06000DA3 RID: 3491
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_get_primary_monitor(IntPtr raw);

		// Token: 0x020001B5 RID: 437
		// (Invoke) Token: 0x06000DA7 RID: 3495
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_get_screen(IntPtr raw, int screen_num);

		// Token: 0x020001B6 RID: 438
		// (Invoke) Token: 0x06000DAB RID: 3499
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_get_type();

		// Token: 0x020001B7 RID: 439
		// (Invoke) Token: 0x06000DAF RID: 3503
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_get_window_at_pointer(IntPtr raw, out int win_x, out int win_y);

		// Token: 0x020001B8 RID: 440
		// (Invoke) Token: 0x06000DB3 RID: 3507
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_display_has_pending(IntPtr raw);

		// Token: 0x020001B9 RID: 441
		// (Invoke) Token: 0x06000DB7 RID: 3511
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_display_is_closed(IntPtr raw);

		// Token: 0x020001BA RID: 442
		// (Invoke) Token: 0x06000DBB RID: 3515
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_display_keyboard_ungrab(IntPtr raw, uint time_);

		// Token: 0x020001BB RID: 443
		// (Invoke) Token: 0x06000DBF RID: 3519
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_list_seats(IntPtr raw);

		// Token: 0x020001BC RID: 444
		// (Invoke) Token: 0x06000DC3 RID: 3523
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_display_notify_startup_complete(IntPtr raw, IntPtr startup_id);

		// Token: 0x020001BD RID: 445
		// (Invoke) Token: 0x06000DC7 RID: 3527
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_open(IntPtr display_name);

		// Token: 0x020001BE RID: 446
		// (Invoke) Token: 0x06000DCB RID: 3531
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_open_default_libgtk_only();

		// Token: 0x020001BF RID: 447
		// (Invoke) Token: 0x06000DCF RID: 3535
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_peek_event(IntPtr raw);

		// Token: 0x020001C0 RID: 448
		// (Invoke) Token: 0x06000DD3 RID: 3539
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_display_pointer_is_grabbed(IntPtr raw);

		// Token: 0x020001C1 RID: 449
		// (Invoke) Token: 0x06000DD7 RID: 3543
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_display_pointer_ungrab(IntPtr raw, uint time_);

		// Token: 0x020001C2 RID: 450
		// (Invoke) Token: 0x06000DDB RID: 3547
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_display_put_event(IntPtr raw, IntPtr evnt);

		// Token: 0x020001C3 RID: 451
		// (Invoke) Token: 0x06000DDF RID: 3551
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_display_request_selection_notification(IntPtr raw, IntPtr selection);

		// Token: 0x020001C4 RID: 452
		// (Invoke) Token: 0x06000DE3 RID: 3555
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_display_set_double_click_distance(IntPtr raw, uint distance);

		// Token: 0x020001C5 RID: 453
		// (Invoke) Token: 0x06000DE7 RID: 3559
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_display_set_double_click_time(IntPtr raw, uint msec);

		// Token: 0x020001C6 RID: 454
		// (Invoke) Token: 0x06000DEB RID: 3563
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_display_store_clipboard(IntPtr raw, IntPtr clipboard_window, uint time_, IntPtr targets, int n_targets);

		// Token: 0x020001C7 RID: 455
		// (Invoke) Token: 0x06000DEF RID: 3567
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_display_supports_clipboard_persistence(IntPtr raw);

		// Token: 0x020001C8 RID: 456
		// (Invoke) Token: 0x06000DF3 RID: 3571
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_display_supports_composite(IntPtr raw);

		// Token: 0x020001C9 RID: 457
		// (Invoke) Token: 0x06000DF7 RID: 3575
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_display_supports_cursor_alpha(IntPtr raw);

		// Token: 0x020001CA RID: 458
		// (Invoke) Token: 0x06000DFB RID: 3579
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_display_supports_cursor_color(IntPtr raw);

		// Token: 0x020001CB RID: 459
		// (Invoke) Token: 0x06000DFF RID: 3583
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_display_supports_input_shapes(IntPtr raw);

		// Token: 0x020001CC RID: 460
		// (Invoke) Token: 0x06000E03 RID: 3587
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_display_supports_selection_notification(IntPtr raw);

		// Token: 0x020001CD RID: 461
		// (Invoke) Token: 0x06000E07 RID: 3591
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_display_supports_shapes(IntPtr raw);

		// Token: 0x020001CE RID: 462
		// (Invoke) Token: 0x06000E0B RID: 3595
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_display_sync(IntPtr raw);

		// Token: 0x020001CF RID: 463
		// (Invoke) Token: 0x06000E0F RID: 3599
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_display_warp_pointer(IntPtr raw, IntPtr screen, int x, int y);
	}
}
