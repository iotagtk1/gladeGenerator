﻿using System;

namespace Gdk
{
	// Token: 0x020000EF RID: 239
	// (Invoke) Token: 0x060009E5 RID: 2533
	public delegate void SeatAddedHandler(object o, SeatAddedArgs args);
}
