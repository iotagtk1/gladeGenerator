﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000121 RID: 289
	[Flags]
	[GType(typeof(WindowStateGType))]
	public enum WindowState
	{
		// Token: 0x0400068E RID: 1678
		Withdrawn = 1,
		// Token: 0x0400068F RID: 1679
		Iconified = 2,
		// Token: 0x04000690 RID: 1680
		Maximized = 4,
		// Token: 0x04000691 RID: 1681
		Sticky = 8,
		// Token: 0x04000692 RID: 1682
		Fullscreen = 16,
		// Token: 0x04000693 RID: 1683
		Above = 32,
		// Token: 0x04000694 RID: 1684
		Below = 64,
		// Token: 0x04000695 RID: 1685
		Focused = 128,
		// Token: 0x04000696 RID: 1686
		Tiled = 256
	}
}
