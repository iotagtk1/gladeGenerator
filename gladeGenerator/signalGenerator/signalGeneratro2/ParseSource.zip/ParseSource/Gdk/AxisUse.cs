﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000043 RID: 67
	[GType(typeof(AxisUseGType))]
	public enum AxisUse
	{
		// Token: 0x04000125 RID: 293
		Ignore,
		// Token: 0x04000126 RID: 294
		X,
		// Token: 0x04000127 RID: 295
		Y,
		// Token: 0x04000128 RID: 296
		Pressure,
		// Token: 0x04000129 RID: 297
		Xtilt,
		// Token: 0x0400012A RID: 298
		Ytilt,
		// Token: 0x0400012B RID: 299
		Wheel,
		// Token: 0x0400012C RID: 300
		Distance,
		// Token: 0x0400012D RID: 301
		Rotation,
		// Token: 0x0400012E RID: 302
		Slider,
		// Token: 0x0400012F RID: 303
		Last
	}
}
