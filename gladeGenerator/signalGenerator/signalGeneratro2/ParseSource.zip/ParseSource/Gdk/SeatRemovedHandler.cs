﻿using System;

namespace Gdk
{
	// Token: 0x020000F6 RID: 246
	// (Invoke) Token: 0x060009F6 RID: 2550
	public delegate void SeatRemovedHandler(object o, SeatRemovedArgs args);
}
