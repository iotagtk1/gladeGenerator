﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000A2 RID: 162
	[GType(typeof(InputModeGType))]
	public enum InputMode
	{
		// Token: 0x0400037F RID: 895
		Disabled,
		// Token: 0x04000380 RID: 896
		Screen,
		// Token: 0x04000381 RID: 897
		Window
	}
}
