﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000130 RID: 304
	public class TextProperty
	{
		// Token: 0x06000B9A RID: 2970 RVA: 0x00021D10 File Offset: 0x0001FF10
		public static string[] ToStringListForDisplay(Display display, Atom encoding, int format, byte[] text, int length)
		{
			IntPtr intPtr;
			int num = TextProperty.gdk_text_property_to_utf8_list_for_display(display.Handle, encoding.Handle, format, text, length, out intPtr);
			if (num == 0)
			{
				return new string[0];
			}
			string[] array = new string[num];
			for (int i = 0; i < num; i++)
			{
				IntPtr ptr = Marshal.ReadIntPtr(intPtr, i * IntPtr.Size);
				array[i] = Marshaller.Utf8PtrToString(ptr);
			}
			Marshaller.StrFreeV(intPtr);
			return array;
		}

		// Token: 0x04000C09 RID: 3081
		private static TextProperty.d_gdk_text_property_to_utf8_list_for_display gdk_text_property_to_utf8_list_for_display = FuncLoader.LoadFunction<TextProperty.d_gdk_text_property_to_utf8_list_for_display>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_text_property_to_utf8_list_for_display"));

		// Token: 0x020004D7 RID: 1239
		// (Invoke) Token: 0x060019DE RID: 6622
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_text_property_to_utf8_list_for_display(IntPtr display, IntPtr encoding, int format, byte[] text, int length, out IntPtr list);
	}
}
