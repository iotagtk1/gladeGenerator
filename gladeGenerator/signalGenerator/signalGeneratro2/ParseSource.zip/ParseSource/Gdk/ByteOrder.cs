﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000046 RID: 70
	[GType(typeof(ByteOrderGType))]
	public enum ByteOrder
	{
		// Token: 0x04000133 RID: 307
		LsbFirst,
		// Token: 0x04000134 RID: 308
		MsbFirst
	}
}
