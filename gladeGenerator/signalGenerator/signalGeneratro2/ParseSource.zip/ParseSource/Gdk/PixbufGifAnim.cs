﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000D0 RID: 208
	public class PixbufGifAnim : PixbufAnimation
	{
		// Token: 0x0600080B RID: 2059 RVA: 0x00017F16 File Offset: 0x00016116
		public PixbufGifAnim(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x0600080C RID: 2060 RVA: 0x00017F1F File Offset: 0x0001611F
		protected PixbufGifAnim() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x0600080D RID: 2061 RVA: 0x00017F40 File Offset: 0x00016140
		public void FrameComposite(PixbufFrame frame)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(frame);
			PixbufGifAnim.gdk_pixbuf_gif_anim_frame_composite(base.Handle, intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x17000218 RID: 536
		// (get) Token: 0x0600080E RID: 2062 RVA: 0x00017F70 File Offset: 0x00016170
		public new static GType GType
		{
			get
			{
				IntPtr val = PixbufGifAnim.gdk_pixbuf_gif_anim_get_type();
				return new GType(val);
			}
		}

		// Token: 0x04000498 RID: 1176
		private static PixbufGifAnim.d_gdk_pixbuf_gif_anim_frame_composite gdk_pixbuf_gif_anim_frame_composite = FuncLoader.LoadFunction<PixbufGifAnim.d_gdk_pixbuf_gif_anim_frame_composite>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_gif_anim_frame_composite"));

		// Token: 0x04000499 RID: 1177
		private static PixbufGifAnim.d_gdk_pixbuf_gif_anim_get_type gdk_pixbuf_gif_anim_get_type = FuncLoader.LoadFunction<PixbufGifAnim.d_gdk_pixbuf_gif_anim_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_gif_anim_get_type"));

		// Token: 0x02000385 RID: 901
		// (Invoke) Token: 0x06001496 RID: 5270
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_pixbuf_gif_anim_frame_composite(IntPtr raw, IntPtr frame);

		// Token: 0x02000386 RID: 902
		// (Invoke) Token: 0x0600149A RID: 5274
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_gif_anim_get_type();
	}
}
