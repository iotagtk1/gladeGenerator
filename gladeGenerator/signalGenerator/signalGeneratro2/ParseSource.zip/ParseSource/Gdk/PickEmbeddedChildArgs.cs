﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000C1 RID: 193
	public class PickEmbeddedChildArgs : SignalArgs
	{
		// Token: 0x170001E9 RID: 489
		// (get) Token: 0x06000765 RID: 1893 RVA: 0x000153FF File Offset: 0x000135FF
		public double X
		{
			get
			{
				return (double)base.Args[0];
			}
		}

		// Token: 0x170001EA RID: 490
		// (get) Token: 0x06000766 RID: 1894 RVA: 0x0001540E File Offset: 0x0001360E
		public double Y
		{
			get
			{
				return (double)base.Args[1];
			}
		}
	}
}
