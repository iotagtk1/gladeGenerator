﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000B2 RID: 178
	public class Monitor : Object
	{
		// Token: 0x06000716 RID: 1814 RVA: 0x00014B25 File Offset: 0x00012D25
		public Monitor(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000717 RID: 1815 RVA: 0x00014B2E File Offset: 0x00012D2E
		protected Monitor() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x170001CF RID: 463
		// (get) Token: 0x06000718 RID: 1816 RVA: 0x00014B4D File Offset: 0x00012D4D
		[Property("display")]
		public Display Display
		{
			get
			{
				return Object.GetObject(Monitor.gdk_monitor_get_display(base.Handle)) as Display;
			}
		}

		// Token: 0x170001D0 RID: 464
		// (get) Token: 0x06000719 RID: 1817 RVA: 0x00014B69 File Offset: 0x00012D69
		[Property("manufacturer")]
		public string Manufacturer
		{
			get
			{
				return Marshaller.Utf8PtrToString(Monitor.gdk_monitor_get_manufacturer(base.Handle));
			}
		}

		// Token: 0x170001D1 RID: 465
		// (get) Token: 0x0600071A RID: 1818 RVA: 0x00014B80 File Offset: 0x00012D80
		[Property("model")]
		public string Model
		{
			get
			{
				return Marshaller.Utf8PtrToString(Monitor.gdk_monitor_get_model(base.Handle));
			}
		}

		// Token: 0x170001D2 RID: 466
		// (get) Token: 0x0600071B RID: 1819 RVA: 0x00014B97 File Offset: 0x00012D97
		[Property("scale-factor")]
		public int ScaleFactor
		{
			get
			{
				return Monitor.gdk_monitor_get_scale_factor(base.Handle);
			}
		}

		// Token: 0x170001D3 RID: 467
		// (get) Token: 0x0600071C RID: 1820 RVA: 0x00014BAC File Offset: 0x00012DAC
		[Property("geometry")]
		public Rectangle Geometry
		{
			get
			{
				Value property = base.GetProperty("geometry");
				Rectangle result = (Rectangle)property;
				property.Dispose();
				return result;
			}
		}

		// Token: 0x170001D4 RID: 468
		// (get) Token: 0x0600071D RID: 1821 RVA: 0x00014BD4 File Offset: 0x00012DD4
		[Property("workarea")]
		public Rectangle Workarea
		{
			get
			{
				Value property = base.GetProperty("workarea");
				Rectangle result = (Rectangle)property;
				property.Dispose();
				return result;
			}
		}

		// Token: 0x170001D5 RID: 469
		// (get) Token: 0x0600071E RID: 1822 RVA: 0x00014BFA File Offset: 0x00012DFA
		[Property("width-mm")]
		public int WidthMm
		{
			get
			{
				return Monitor.gdk_monitor_get_width_mm(base.Handle);
			}
		}

		// Token: 0x170001D6 RID: 470
		// (get) Token: 0x0600071F RID: 1823 RVA: 0x00014C0C File Offset: 0x00012E0C
		[Property("height-mm")]
		public int HeightMm
		{
			get
			{
				return Monitor.gdk_monitor_get_height_mm(base.Handle);
			}
		}

		// Token: 0x170001D7 RID: 471
		// (get) Token: 0x06000720 RID: 1824 RVA: 0x00014C1E File Offset: 0x00012E1E
		[Property("refresh-rate")]
		public int RefreshRate
		{
			get
			{
				return Monitor.gdk_monitor_get_refresh_rate(base.Handle);
			}
		}

		// Token: 0x170001D8 RID: 472
		// (get) Token: 0x06000721 RID: 1825 RVA: 0x00014C30 File Offset: 0x00012E30
		[Property("subpixel-layout")]
		public SubpixelLayout SubpixelLayout
		{
			get
			{
				return (SubpixelLayout)Monitor.gdk_monitor_get_subpixel_layout(base.Handle);
			}
		}

		// Token: 0x1400001B RID: 27
		// (add) Token: 0x06000722 RID: 1826 RVA: 0x00014C42 File Offset: 0x00012E42
		// (remove) Token: 0x06000723 RID: 1827 RVA: 0x00014C50 File Offset: 0x00012E50
		[Signal("invalidate")]
		public event EventHandler Invalidate
		{
			add
			{
				base.AddSignalHandler("invalidate", value);
			}
			remove
			{
				base.RemoveSignalHandler("invalidate", value);
			}
		}

		// Token: 0x170001D9 RID: 473
		// (get) Token: 0x06000724 RID: 1828 RVA: 0x00014C5E File Offset: 0x00012E5E
		private static Monitor.InvalidateNativeDelegate InvalidateVMCallback
		{
			get
			{
				if (Monitor.Invalidate_cb_delegate == null)
				{
					Monitor.Invalidate_cb_delegate = new Monitor.InvalidateNativeDelegate(Monitor.Invalidate_cb);
				}
				return Monitor.Invalidate_cb_delegate;
			}
		}

		// Token: 0x06000725 RID: 1829 RVA: 0x00014C7D File Offset: 0x00012E7D
		private static void OverrideInvalidate(GType gtype)
		{
			Monitor.OverrideInvalidate(gtype, Monitor.InvalidateVMCallback);
		}

		// Token: 0x06000726 RID: 1830 RVA: 0x00014C8A File Offset: 0x00012E8A
		private static void OverrideInvalidate(GType gtype, Monitor.InvalidateNativeDelegate callback)
		{
			Object.OverrideVirtualMethod(gtype, "invalidate", callback);
		}

		// Token: 0x06000727 RID: 1831 RVA: 0x00014C98 File Offset: 0x00012E98
		private static void Invalidate_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Monitor).OnInvalidate();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000728 RID: 1832 RVA: 0x00014CD0 File Offset: 0x00012ED0
		[DefaultSignalHandler(Type = typeof(Monitor), ConnectionMethod = "OverrideInvalidate")]
		protected virtual void OnInvalidate()
		{
			this.InternalInvalidate();
		}

		// Token: 0x06000729 RID: 1833 RVA: 0x00014CD8 File Offset: 0x00012ED8
		private void InternalInvalidate()
		{
			Value empty = Value.Empty;
			ValueArray valueArray = new ValueArray(1U);
			Value[] array = new Value[]
			{
				new Value(this)
			};
			valueArray.Append(array[0]);
			Object.g_signal_chain_from_overridden(valueArray.ArrayPtr, ref empty);
			foreach (Value value in array)
			{
				value.Dispose();
			}
		}

		// Token: 0x170001DA RID: 474
		// (get) Token: 0x0600072A RID: 1834 RVA: 0x00014D4A File Offset: 0x00012F4A
		private static Monitor.GetWorkareaNativeDelegate GetWorkareaVMCallback
		{
			get
			{
				if (Monitor.GetWorkarea_cb_delegate == null)
				{
					Monitor.GetWorkarea_cb_delegate = new Monitor.GetWorkareaNativeDelegate(Monitor.GetWorkarea_cb);
				}
				return Monitor.GetWorkarea_cb_delegate;
			}
		}

		// Token: 0x0600072B RID: 1835 RVA: 0x00014D69 File Offset: 0x00012F69
		private static void OverrideGetWorkarea(GType gtype)
		{
			Monitor.OverrideGetWorkarea(gtype, Monitor.GetWorkareaVMCallback);
		}

		// Token: 0x0600072C RID: 1836 RVA: 0x00014D78 File Offset: 0x00012F78
		private unsafe static void OverrideGetWorkarea(GType gtype, Monitor.GetWorkareaNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Monitor.class_abi.GetFieldOffset("get_workarea");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600072D RID: 1837 RVA: 0x00014DAC File Offset: 0x00012FAC
		private static void GetWorkarea_cb(IntPtr inst, IntPtr geometry)
		{
			try
			{
				(Object.GetObject(inst, false) as Monitor).OnGetWorkarea((Rectangle)Marshal.PtrToStructure(geometry, typeof(Rectangle)));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x0600072E RID: 1838 RVA: 0x00014DFC File Offset: 0x00012FFC
		[DefaultSignalHandler(Type = typeof(Monitor), ConnectionMethod = "OverrideGetWorkarea")]
		protected virtual void OnGetWorkarea(Rectangle geometry)
		{
			this.InternalGetWorkarea(geometry);
		}

		// Token: 0x0600072F RID: 1839 RVA: 0x00014E08 File Offset: 0x00013008
		private void InternalGetWorkarea(Rectangle geometry)
		{
			Monitor.GetWorkareaNativeDelegate getWorkareaNativeDelegate = Monitor.class_abi.BaseOverride(base.LookupGType(), "get_workarea");
			if (getWorkareaNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(geometry);
			getWorkareaNativeDelegate(base.Handle, intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x170001DB RID: 475
		// (get) Token: 0x06000730 RID: 1840 RVA: 0x00014E50 File Offset: 0x00013050
		public new static AbiStruct class_abi
		{
			get
			{
				if (Monitor._class_abi == null)
				{
					Monitor._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("get_workarea", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Monitor._class_abi;
			}
		}

		// Token: 0x06000731 RID: 1841 RVA: 0x00014EB4 File Offset: 0x000130B4
		public void GetGeometry(Rectangle geometry)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(geometry);
			Monitor.gdk_monitor_get_geometry(base.Handle, intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x170001DC RID: 476
		// (get) Token: 0x06000732 RID: 1842 RVA: 0x00014EE4 File Offset: 0x000130E4
		public new static GType GType
		{
			get
			{
				IntPtr val = Monitor.gdk_monitor_get_type();
				return new GType(val);
			}
		}

		// Token: 0x06000733 RID: 1843 RVA: 0x00014F04 File Offset: 0x00013104
		public void GetWorkarea(Rectangle workarea)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(workarea);
			Monitor.gdk_monitor_get_workarea(base.Handle, intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x170001DD RID: 477
		// (get) Token: 0x06000734 RID: 1844 RVA: 0x00014F34 File Offset: 0x00013134
		public bool IsPrimary
		{
			get
			{
				return Monitor.gdk_monitor_is_primary(base.Handle);
			}
		}

		// Token: 0x170001DE RID: 478
		// (get) Token: 0x06000735 RID: 1845 RVA: 0x00014F46 File Offset: 0x00013146
		public new static AbiStruct abi_info
		{
			get
			{
				if (Monitor._abi_info == null)
				{
					Monitor._abi_info = new AbiStruct(Object.abi_info.Fields);
				}
				return Monitor._abi_info;
			}
		}

		// Token: 0x040003F2 RID: 1010
		private static Monitor.d_gdk_monitor_get_display gdk_monitor_get_display = FuncLoader.LoadFunction<Monitor.d_gdk_monitor_get_display>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_monitor_get_display"));

		// Token: 0x040003F3 RID: 1011
		private static Monitor.d_gdk_monitor_get_manufacturer gdk_monitor_get_manufacturer = FuncLoader.LoadFunction<Monitor.d_gdk_monitor_get_manufacturer>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_monitor_get_manufacturer"));

		// Token: 0x040003F4 RID: 1012
		private static Monitor.d_gdk_monitor_get_model gdk_monitor_get_model = FuncLoader.LoadFunction<Monitor.d_gdk_monitor_get_model>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_monitor_get_model"));

		// Token: 0x040003F5 RID: 1013
		private static Monitor.d_gdk_monitor_get_scale_factor gdk_monitor_get_scale_factor = FuncLoader.LoadFunction<Monitor.d_gdk_monitor_get_scale_factor>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_monitor_get_scale_factor"));

		// Token: 0x040003F6 RID: 1014
		private static Monitor.d_gdk_monitor_get_width_mm gdk_monitor_get_width_mm = FuncLoader.LoadFunction<Monitor.d_gdk_monitor_get_width_mm>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_monitor_get_width_mm"));

		// Token: 0x040003F7 RID: 1015
		private static Monitor.d_gdk_monitor_get_height_mm gdk_monitor_get_height_mm = FuncLoader.LoadFunction<Monitor.d_gdk_monitor_get_height_mm>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_monitor_get_height_mm"));

		// Token: 0x040003F8 RID: 1016
		private static Monitor.d_gdk_monitor_get_refresh_rate gdk_monitor_get_refresh_rate = FuncLoader.LoadFunction<Monitor.d_gdk_monitor_get_refresh_rate>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_monitor_get_refresh_rate"));

		// Token: 0x040003F9 RID: 1017
		private static Monitor.d_gdk_monitor_get_subpixel_layout gdk_monitor_get_subpixel_layout = FuncLoader.LoadFunction<Monitor.d_gdk_monitor_get_subpixel_layout>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_monitor_get_subpixel_layout"));

		// Token: 0x040003FA RID: 1018
		private static Monitor.InvalidateNativeDelegate Invalidate_cb_delegate;

		// Token: 0x040003FB RID: 1019
		private static Monitor.GetWorkareaNativeDelegate GetWorkarea_cb_delegate;

		// Token: 0x040003FC RID: 1020
		private static AbiStruct _class_abi = null;

		// Token: 0x040003FD RID: 1021
		private static Monitor.d_gdk_monitor_get_geometry gdk_monitor_get_geometry = FuncLoader.LoadFunction<Monitor.d_gdk_monitor_get_geometry>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_monitor_get_geometry"));

		// Token: 0x040003FE RID: 1022
		private static Monitor.d_gdk_monitor_get_type gdk_monitor_get_type = FuncLoader.LoadFunction<Monitor.d_gdk_monitor_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_monitor_get_type"));

		// Token: 0x040003FF RID: 1023
		private static Monitor.d_gdk_monitor_get_workarea gdk_monitor_get_workarea = FuncLoader.LoadFunction<Monitor.d_gdk_monitor_get_workarea>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_monitor_get_workarea"));

		// Token: 0x04000400 RID: 1024
		private static Monitor.d_gdk_monitor_is_primary gdk_monitor_is_primary = FuncLoader.LoadFunction<Monitor.d_gdk_monitor_is_primary>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_monitor_is_primary"));

		// Token: 0x04000401 RID: 1025
		private static AbiStruct _abi_info = null;

		// Token: 0x0200030A RID: 778
		// (Invoke) Token: 0x060012AD RID: 4781
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_monitor_get_display(IntPtr raw);

		// Token: 0x0200030B RID: 779
		// (Invoke) Token: 0x060012B1 RID: 4785
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_monitor_get_manufacturer(IntPtr raw);

		// Token: 0x0200030C RID: 780
		// (Invoke) Token: 0x060012B5 RID: 4789
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_monitor_get_model(IntPtr raw);

		// Token: 0x0200030D RID: 781
		// (Invoke) Token: 0x060012B9 RID: 4793
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_monitor_get_scale_factor(IntPtr raw);

		// Token: 0x0200030E RID: 782
		// (Invoke) Token: 0x060012BD RID: 4797
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_monitor_get_width_mm(IntPtr raw);

		// Token: 0x0200030F RID: 783
		// (Invoke) Token: 0x060012C1 RID: 4801
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_monitor_get_height_mm(IntPtr raw);

		// Token: 0x02000310 RID: 784
		// (Invoke) Token: 0x060012C5 RID: 4805
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_monitor_get_refresh_rate(IntPtr raw);

		// Token: 0x02000311 RID: 785
		// (Invoke) Token: 0x060012C9 RID: 4809
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_monitor_get_subpixel_layout(IntPtr raw);

		// Token: 0x02000312 RID: 786
		// (Invoke) Token: 0x060012CD RID: 4813
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void InvalidateNativeDelegate(IntPtr inst);

		// Token: 0x02000313 RID: 787
		// (Invoke) Token: 0x060012D1 RID: 4817
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void GetWorkareaNativeDelegate(IntPtr inst, IntPtr geometry);

		// Token: 0x02000314 RID: 788
		// (Invoke) Token: 0x060012D5 RID: 4821
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_monitor_get_geometry(IntPtr raw, IntPtr geometry);

		// Token: 0x02000315 RID: 789
		// (Invoke) Token: 0x060012D9 RID: 4825
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_monitor_get_type();

		// Token: 0x02000316 RID: 790
		// (Invoke) Token: 0x060012DD RID: 4829
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_monitor_get_workarea(IntPtr raw, IntPtr workarea);

		// Token: 0x02000317 RID: 791
		// (Invoke) Token: 0x060012E1 RID: 4833
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_monitor_is_primary(IntPtr raw);
	}
}
