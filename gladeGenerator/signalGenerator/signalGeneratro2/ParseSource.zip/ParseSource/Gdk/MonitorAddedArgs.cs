﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000B4 RID: 180
	public class MonitorAddedArgs : SignalArgs
	{
		// Token: 0x170001DF RID: 479
		// (get) Token: 0x0600073B RID: 1851 RVA: 0x000150B9 File Offset: 0x000132B9
		public Monitor P0
		{
			get
			{
				return (Monitor)base.Args[0];
			}
		}
	}
}
