﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x02000093 RID: 147
	public class GifContext : Opaque
	{
		// Token: 0x06000619 RID: 1561 RVA: 0x000121BC File Offset: 0x000103BC
		public GifContext(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700018D RID: 397
		// (get) Token: 0x0600061A RID: 1562 RVA: 0x000121C5 File Offset: 0x000103C5
		public static AbiStruct abi_info
		{
			get
			{
				if (GifContext._abi_info == null)
				{
					GifContext._abi_info = new AbiStruct(new List<AbiField>());
				}
				return GifContext._abi_info;
			}
		}

		// Token: 0x04000333 RID: 819
		private static AbiStruct _abi_info;
	}
}
