﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000078 RID: 120
	[Flags]
	[GType(typeof(EventMaskGType))]
	public enum EventMask
	{
		// Token: 0x04000252 RID: 594
		ExposureMask = 2,
		// Token: 0x04000253 RID: 595
		PointerMotionMask = 4,
		// Token: 0x04000254 RID: 596
		PointerMotionHintMask = 8,
		// Token: 0x04000255 RID: 597
		ButtonMotionMask = 16,
		// Token: 0x04000256 RID: 598
		Button1MotionMask = 32,
		// Token: 0x04000257 RID: 599
		Button2MotionMask = 64,
		// Token: 0x04000258 RID: 600
		Button3MotionMask = 128,
		// Token: 0x04000259 RID: 601
		ButtonPressMask = 256,
		// Token: 0x0400025A RID: 602
		ButtonReleaseMask = 512,
		// Token: 0x0400025B RID: 603
		KeyPressMask = 1024,
		// Token: 0x0400025C RID: 604
		KeyReleaseMask = 2048,
		// Token: 0x0400025D RID: 605
		EnterNotifyMask = 4096,
		// Token: 0x0400025E RID: 606
		LeaveNotifyMask = 8192,
		// Token: 0x0400025F RID: 607
		FocusChangeMask = 16384,
		// Token: 0x04000260 RID: 608
		StructureMask = 32768,
		// Token: 0x04000261 RID: 609
		PropertyChangeMask = 65536,
		// Token: 0x04000262 RID: 610
		VisibilityNotifyMask = 131072,
		// Token: 0x04000263 RID: 611
		ProximityInMask = 262144,
		// Token: 0x04000264 RID: 612
		ProximityOutMask = 524288,
		// Token: 0x04000265 RID: 613
		SubstructureMask = 1048576,
		// Token: 0x04000266 RID: 614
		ScrollMask = 2097152,
		// Token: 0x04000267 RID: 615
		TouchMask = 4194304,
		// Token: 0x04000268 RID: 616
		SmoothScrollMask = 8388608,
		// Token: 0x04000269 RID: 617
		TouchpadGestureMask = 16777216,
		// Token: 0x0400026A RID: 618
		TabletPadMask = 33554432,
		// Token: 0x0400026B RID: 619
		AllEventsMask = 16777214
	}
}
