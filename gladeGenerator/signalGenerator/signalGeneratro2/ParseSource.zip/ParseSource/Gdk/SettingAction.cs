﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000F9 RID: 249
	[GType(typeof(SettingActionGType))]
	public enum SettingAction
	{
		// Token: 0x0400056E RID: 1390
		New,
		// Token: 0x0400056F RID: 1391
		Changed,
		// Token: 0x04000570 RID: 1392
		Deleted
	}
}
