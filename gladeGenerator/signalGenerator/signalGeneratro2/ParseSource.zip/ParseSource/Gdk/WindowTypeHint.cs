﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000125 RID: 293
	[GType(typeof(WindowTypeHintGType))]
	public enum WindowTypeHint
	{
		// Token: 0x040006A2 RID: 1698
		Normal,
		// Token: 0x040006A3 RID: 1699
		Dialog,
		// Token: 0x040006A4 RID: 1700
		Menu,
		// Token: 0x040006A5 RID: 1701
		Toolbar,
		// Token: 0x040006A6 RID: 1702
		Splashscreen,
		// Token: 0x040006A7 RID: 1703
		Utility,
		// Token: 0x040006A8 RID: 1704
		Dock,
		// Token: 0x040006A9 RID: 1705
		Desktop,
		// Token: 0x040006AA RID: 1706
		DropdownMenu,
		// Token: 0x040006AB RID: 1707
		PopupMenu,
		// Token: 0x040006AC RID: 1708
		Tooltip,
		// Token: 0x040006AD RID: 1709
		Notification,
		// Token: 0x040006AE RID: 1710
		Combo,
		// Token: 0x040006AF RID: 1711
		Dnd
	}
}
