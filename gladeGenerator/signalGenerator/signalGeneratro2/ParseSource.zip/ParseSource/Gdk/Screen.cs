﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using Cairo;
using GLib;

namespace Gdk
{
	// Token: 0x020000EB RID: 235
	public class Screen : Object
	{
		// Token: 0x060008B3 RID: 2227 RVA: 0x00019BAE File Offset: 0x00017DAE
		public Screen(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x060008B4 RID: 2228 RVA: 0x00019BB7 File Offset: 0x00017DB7
		protected Screen() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x14000020 RID: 32
		// (add) Token: 0x060008B5 RID: 2229 RVA: 0x00019BD6 File Offset: 0x00017DD6
		// (remove) Token: 0x060008B6 RID: 2230 RVA: 0x00019BE4 File Offset: 0x00017DE4
		[Signal("size-changed")]
		public event EventHandler SizeChanged
		{
			add
			{
				base.AddSignalHandler("size-changed", value);
			}
			remove
			{
				base.RemoveSignalHandler("size-changed", value);
			}
		}

		// Token: 0x14000021 RID: 33
		// (add) Token: 0x060008B7 RID: 2231 RVA: 0x00019BF2 File Offset: 0x00017DF2
		// (remove) Token: 0x060008B8 RID: 2232 RVA: 0x00019C00 File Offset: 0x00017E00
		[Signal("composited-changed")]
		public event EventHandler CompositedChanged
		{
			add
			{
				base.AddSignalHandler("composited-changed", value);
			}
			remove
			{
				base.RemoveSignalHandler("composited-changed", value);
			}
		}

		// Token: 0x14000022 RID: 34
		// (add) Token: 0x060008B9 RID: 2233 RVA: 0x00019C0E File Offset: 0x00017E0E
		// (remove) Token: 0x060008BA RID: 2234 RVA: 0x00019C1C File Offset: 0x00017E1C
		[Signal("monitors-changed")]
		public event EventHandler MonitorsChanged
		{
			add
			{
				base.AddSignalHandler("monitors-changed", value);
			}
			remove
			{
				base.RemoveSignalHandler("monitors-changed", value);
			}
		}

		// Token: 0x1700023A RID: 570
		// (get) Token: 0x060008BB RID: 2235 RVA: 0x00019C2A File Offset: 0x00017E2A
		private static Screen.GetDisplayNativeDelegate GetDisplayVMCallback
		{
			get
			{
				if (Screen.GetDisplay_cb_delegate == null)
				{
					Screen.GetDisplay_cb_delegate = new Screen.GetDisplayNativeDelegate(Screen.GetDisplay_cb);
				}
				return Screen.GetDisplay_cb_delegate;
			}
		}

		// Token: 0x060008BC RID: 2236 RVA: 0x00019C49 File Offset: 0x00017E49
		private static void OverrideGetDisplay(GType gtype)
		{
			Screen.OverrideGetDisplay(gtype, Screen.GetDisplayVMCallback);
		}

		// Token: 0x060008BD RID: 2237 RVA: 0x00019C58 File Offset: 0x00017E58
		private unsafe static void OverrideGetDisplay(GType gtype, Screen.GetDisplayNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_display");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060008BE RID: 2238 RVA: 0x00019C8C File Offset: 0x00017E8C
		private static IntPtr GetDisplay_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				Display display = (Object.GetObject(inst, false) as Screen).OnGetDisplay();
				result = ((display == null) ? IntPtr.Zero : display.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060008BF RID: 2239 RVA: 0x00019CD8 File Offset: 0x00017ED8
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetDisplay")]
		protected virtual Display OnGetDisplay()
		{
			return this.InternalGetDisplay();
		}

		// Token: 0x060008C0 RID: 2240 RVA: 0x00019CE0 File Offset: 0x00017EE0
		private Display InternalGetDisplay()
		{
			Screen.GetDisplayNativeDelegate getDisplayNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_display");
			if (getDisplayNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getDisplayNativeDelegate(base.Handle)) as Display;
		}

		// Token: 0x1700023B RID: 571
		// (get) Token: 0x060008C1 RID: 2241 RVA: 0x00019D1E File Offset: 0x00017F1E
		private static Screen.GetWidthNativeDelegate GetWidthVMCallback
		{
			get
			{
				if (Screen.GetWidth_cb_delegate == null)
				{
					Screen.GetWidth_cb_delegate = new Screen.GetWidthNativeDelegate(Screen.GetWidth_cb);
				}
				return Screen.GetWidth_cb_delegate;
			}
		}

		// Token: 0x060008C2 RID: 2242 RVA: 0x00019D3D File Offset: 0x00017F3D
		private static void OverrideGetWidth(GType gtype)
		{
			Screen.OverrideGetWidth(gtype, Screen.GetWidthVMCallback);
		}

		// Token: 0x060008C3 RID: 2243 RVA: 0x00019D4C File Offset: 0x00017F4C
		private unsafe static void OverrideGetWidth(GType gtype, Screen.GetWidthNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_width");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060008C4 RID: 2244 RVA: 0x00019D80 File Offset: 0x00017F80
		private static int GetWidth_cb(IntPtr inst)
		{
			int result;
			try
			{
				result = (Object.GetObject(inst, false) as Screen).OnGetWidth();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060008C5 RID: 2245 RVA: 0x00019DBC File Offset: 0x00017FBC
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetWidth")]
		protected virtual int OnGetWidth()
		{
			return this.InternalGetWidth();
		}

		// Token: 0x060008C6 RID: 2246 RVA: 0x00019DC4 File Offset: 0x00017FC4
		private int InternalGetWidth()
		{
			Screen.GetWidthNativeDelegate getWidthNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_width");
			if (getWidthNativeDelegate == null)
			{
				return 0;
			}
			return getWidthNativeDelegate(base.Handle);
		}

		// Token: 0x1700023C RID: 572
		// (get) Token: 0x060008C7 RID: 2247 RVA: 0x00019DF8 File Offset: 0x00017FF8
		private static Screen.GetHeightNativeDelegate GetHeightVMCallback
		{
			get
			{
				if (Screen.GetHeight_cb_delegate == null)
				{
					Screen.GetHeight_cb_delegate = new Screen.GetHeightNativeDelegate(Screen.GetHeight_cb);
				}
				return Screen.GetHeight_cb_delegate;
			}
		}

		// Token: 0x060008C8 RID: 2248 RVA: 0x00019E17 File Offset: 0x00018017
		private static void OverrideGetHeight(GType gtype)
		{
			Screen.OverrideGetHeight(gtype, Screen.GetHeightVMCallback);
		}

		// Token: 0x060008C9 RID: 2249 RVA: 0x00019E24 File Offset: 0x00018024
		private unsafe static void OverrideGetHeight(GType gtype, Screen.GetHeightNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_height");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060008CA RID: 2250 RVA: 0x00019E58 File Offset: 0x00018058
		private static int GetHeight_cb(IntPtr inst)
		{
			int result;
			try
			{
				result = (Object.GetObject(inst, false) as Screen).OnGetHeight();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060008CB RID: 2251 RVA: 0x00019E94 File Offset: 0x00018094
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetHeight")]
		protected virtual int OnGetHeight()
		{
			return this.InternalGetHeight();
		}

		// Token: 0x060008CC RID: 2252 RVA: 0x00019E9C File Offset: 0x0001809C
		private int InternalGetHeight()
		{
			Screen.GetHeightNativeDelegate getHeightNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_height");
			if (getHeightNativeDelegate == null)
			{
				return 0;
			}
			return getHeightNativeDelegate(base.Handle);
		}

		// Token: 0x1700023D RID: 573
		// (get) Token: 0x060008CD RID: 2253 RVA: 0x00019ED0 File Offset: 0x000180D0
		private static Screen.GetWidthMmNativeDelegate GetWidthMmVMCallback
		{
			get
			{
				if (Screen.GetWidthMm_cb_delegate == null)
				{
					Screen.GetWidthMm_cb_delegate = new Screen.GetWidthMmNativeDelegate(Screen.GetWidthMm_cb);
				}
				return Screen.GetWidthMm_cb_delegate;
			}
		}

		// Token: 0x060008CE RID: 2254 RVA: 0x00019EEF File Offset: 0x000180EF
		private static void OverrideGetWidthMm(GType gtype)
		{
			Screen.OverrideGetWidthMm(gtype, Screen.GetWidthMmVMCallback);
		}

		// Token: 0x060008CF RID: 2255 RVA: 0x00019EFC File Offset: 0x000180FC
		private unsafe static void OverrideGetWidthMm(GType gtype, Screen.GetWidthMmNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_width_mm");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060008D0 RID: 2256 RVA: 0x00019F30 File Offset: 0x00018130
		private static int GetWidthMm_cb(IntPtr inst)
		{
			int result;
			try
			{
				result = (Object.GetObject(inst, false) as Screen).OnGetWidthMm();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060008D1 RID: 2257 RVA: 0x00019F6C File Offset: 0x0001816C
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetWidthMm")]
		protected virtual int OnGetWidthMm()
		{
			return this.InternalGetWidthMm();
		}

		// Token: 0x060008D2 RID: 2258 RVA: 0x00019F74 File Offset: 0x00018174
		private int InternalGetWidthMm()
		{
			Screen.GetWidthMmNativeDelegate getWidthMmNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_width_mm");
			if (getWidthMmNativeDelegate == null)
			{
				return 0;
			}
			return getWidthMmNativeDelegate(base.Handle);
		}

		// Token: 0x1700023E RID: 574
		// (get) Token: 0x060008D3 RID: 2259 RVA: 0x00019FA8 File Offset: 0x000181A8
		private static Screen.GetHeightMmNativeDelegate GetHeightMmVMCallback
		{
			get
			{
				if (Screen.GetHeightMm_cb_delegate == null)
				{
					Screen.GetHeightMm_cb_delegate = new Screen.GetHeightMmNativeDelegate(Screen.GetHeightMm_cb);
				}
				return Screen.GetHeightMm_cb_delegate;
			}
		}

		// Token: 0x060008D4 RID: 2260 RVA: 0x00019FC7 File Offset: 0x000181C7
		private static void OverrideGetHeightMm(GType gtype)
		{
			Screen.OverrideGetHeightMm(gtype, Screen.GetHeightMmVMCallback);
		}

		// Token: 0x060008D5 RID: 2261 RVA: 0x00019FD4 File Offset: 0x000181D4
		private unsafe static void OverrideGetHeightMm(GType gtype, Screen.GetHeightMmNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_height_mm");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060008D6 RID: 2262 RVA: 0x0001A008 File Offset: 0x00018208
		private static int GetHeightMm_cb(IntPtr inst)
		{
			int result;
			try
			{
				result = (Object.GetObject(inst, false) as Screen).OnGetHeightMm();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060008D7 RID: 2263 RVA: 0x0001A044 File Offset: 0x00018244
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetHeightMm")]
		protected virtual int OnGetHeightMm()
		{
			return this.InternalGetHeightMm();
		}

		// Token: 0x060008D8 RID: 2264 RVA: 0x0001A04C File Offset: 0x0001824C
		private int InternalGetHeightMm()
		{
			Screen.GetHeightMmNativeDelegate getHeightMmNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_height_mm");
			if (getHeightMmNativeDelegate == null)
			{
				return 0;
			}
			return getHeightMmNativeDelegate(base.Handle);
		}

		// Token: 0x1700023F RID: 575
		// (get) Token: 0x060008D9 RID: 2265 RVA: 0x0001A080 File Offset: 0x00018280
		private static Screen.GetNumberNativeDelegate GetNumberVMCallback
		{
			get
			{
				if (Screen.GetNumber_cb_delegate == null)
				{
					Screen.GetNumber_cb_delegate = new Screen.GetNumberNativeDelegate(Screen.GetNumber_cb);
				}
				return Screen.GetNumber_cb_delegate;
			}
		}

		// Token: 0x060008DA RID: 2266 RVA: 0x0001A09F File Offset: 0x0001829F
		private static void OverrideGetNumber(GType gtype)
		{
			Screen.OverrideGetNumber(gtype, Screen.GetNumberVMCallback);
		}

		// Token: 0x060008DB RID: 2267 RVA: 0x0001A0AC File Offset: 0x000182AC
		private unsafe static void OverrideGetNumber(GType gtype, Screen.GetNumberNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_number");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060008DC RID: 2268 RVA: 0x0001A0E0 File Offset: 0x000182E0
		private static int GetNumber_cb(IntPtr inst)
		{
			int result;
			try
			{
				result = (Object.GetObject(inst, false) as Screen).OnGetNumber();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060008DD RID: 2269 RVA: 0x0001A11C File Offset: 0x0001831C
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetNumber")]
		protected virtual int OnGetNumber()
		{
			return this.InternalGetNumber();
		}

		// Token: 0x060008DE RID: 2270 RVA: 0x0001A124 File Offset: 0x00018324
		private int InternalGetNumber()
		{
			Screen.GetNumberNativeDelegate getNumberNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_number");
			if (getNumberNativeDelegate == null)
			{
				return 0;
			}
			return getNumberNativeDelegate(base.Handle);
		}

		// Token: 0x17000240 RID: 576
		// (get) Token: 0x060008DF RID: 2271 RVA: 0x0001A158 File Offset: 0x00018358
		private static Screen.GetRootWindowNativeDelegate GetRootWindowVMCallback
		{
			get
			{
				if (Screen.GetRootWindow_cb_delegate == null)
				{
					Screen.GetRootWindow_cb_delegate = new Screen.GetRootWindowNativeDelegate(Screen.GetRootWindow_cb);
				}
				return Screen.GetRootWindow_cb_delegate;
			}
		}

		// Token: 0x060008E0 RID: 2272 RVA: 0x0001A177 File Offset: 0x00018377
		private static void OverrideGetRootWindow(GType gtype)
		{
			Screen.OverrideGetRootWindow(gtype, Screen.GetRootWindowVMCallback);
		}

		// Token: 0x060008E1 RID: 2273 RVA: 0x0001A184 File Offset: 0x00018384
		private unsafe static void OverrideGetRootWindow(GType gtype, Screen.GetRootWindowNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_root_window");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060008E2 RID: 2274 RVA: 0x0001A1B8 File Offset: 0x000183B8
		private static IntPtr GetRootWindow_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				Window window = (Object.GetObject(inst, false) as Screen).OnGetRootWindow();
				result = ((window == null) ? IntPtr.Zero : window.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060008E3 RID: 2275 RVA: 0x0001A204 File Offset: 0x00018404
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetRootWindow")]
		protected virtual Window OnGetRootWindow()
		{
			return this.InternalGetRootWindow();
		}

		// Token: 0x060008E4 RID: 2276 RVA: 0x0001A20C File Offset: 0x0001840C
		private Window InternalGetRootWindow()
		{
			Screen.GetRootWindowNativeDelegate getRootWindowNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_root_window");
			if (getRootWindowNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getRootWindowNativeDelegate(base.Handle)) as Window;
		}

		// Token: 0x17000241 RID: 577
		// (get) Token: 0x060008E5 RID: 2277 RVA: 0x0001A24A File Offset: 0x0001844A
		private static Screen.GetNMonitorsNativeDelegate GetNMonitorsVMCallback
		{
			get
			{
				if (Screen.GetNMonitors_cb_delegate == null)
				{
					Screen.GetNMonitors_cb_delegate = new Screen.GetNMonitorsNativeDelegate(Screen.GetNMonitors_cb);
				}
				return Screen.GetNMonitors_cb_delegate;
			}
		}

		// Token: 0x060008E6 RID: 2278 RVA: 0x0001A269 File Offset: 0x00018469
		private static void OverrideGetNMonitors(GType gtype)
		{
			Screen.OverrideGetNMonitors(gtype, Screen.GetNMonitorsVMCallback);
		}

		// Token: 0x060008E7 RID: 2279 RVA: 0x0001A278 File Offset: 0x00018478
		private unsafe static void OverrideGetNMonitors(GType gtype, Screen.GetNMonitorsNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_n_monitors");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060008E8 RID: 2280 RVA: 0x0001A2AC File Offset: 0x000184AC
		private static int GetNMonitors_cb(IntPtr inst)
		{
			int result;
			try
			{
				result = (Object.GetObject(inst, false) as Screen).OnGetNMonitors();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060008E9 RID: 2281 RVA: 0x0001A2E8 File Offset: 0x000184E8
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetNMonitors")]
		protected virtual int OnGetNMonitors()
		{
			return this.InternalGetNMonitors();
		}

		// Token: 0x060008EA RID: 2282 RVA: 0x0001A2F0 File Offset: 0x000184F0
		private int InternalGetNMonitors()
		{
			Screen.GetNMonitorsNativeDelegate getNMonitorsNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_n_monitors");
			if (getNMonitorsNativeDelegate == null)
			{
				return 0;
			}
			return getNMonitorsNativeDelegate(base.Handle);
		}

		// Token: 0x17000242 RID: 578
		// (get) Token: 0x060008EB RID: 2283 RVA: 0x0001A324 File Offset: 0x00018524
		private static Screen.GetPrimaryMonitorNativeDelegate GetPrimaryMonitorVMCallback
		{
			get
			{
				if (Screen.GetPrimaryMonitor_cb_delegate == null)
				{
					Screen.GetPrimaryMonitor_cb_delegate = new Screen.GetPrimaryMonitorNativeDelegate(Screen.GetPrimaryMonitor_cb);
				}
				return Screen.GetPrimaryMonitor_cb_delegate;
			}
		}

		// Token: 0x060008EC RID: 2284 RVA: 0x0001A343 File Offset: 0x00018543
		private static void OverrideGetPrimaryMonitor(GType gtype)
		{
			Screen.OverrideGetPrimaryMonitor(gtype, Screen.GetPrimaryMonitorVMCallback);
		}

		// Token: 0x060008ED RID: 2285 RVA: 0x0001A350 File Offset: 0x00018550
		private unsafe static void OverrideGetPrimaryMonitor(GType gtype, Screen.GetPrimaryMonitorNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_primary_monitor");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060008EE RID: 2286 RVA: 0x0001A384 File Offset: 0x00018584
		private static int GetPrimaryMonitor_cb(IntPtr inst)
		{
			int result;
			try
			{
				result = (Object.GetObject(inst, false) as Screen).OnGetPrimaryMonitor();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060008EF RID: 2287 RVA: 0x0001A3C0 File Offset: 0x000185C0
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetPrimaryMonitor")]
		protected virtual int OnGetPrimaryMonitor()
		{
			return this.InternalGetPrimaryMonitor();
		}

		// Token: 0x060008F0 RID: 2288 RVA: 0x0001A3C8 File Offset: 0x000185C8
		private int InternalGetPrimaryMonitor()
		{
			Screen.GetPrimaryMonitorNativeDelegate getPrimaryMonitorNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_primary_monitor");
			if (getPrimaryMonitorNativeDelegate == null)
			{
				return 0;
			}
			return getPrimaryMonitorNativeDelegate(base.Handle);
		}

		// Token: 0x17000243 RID: 579
		// (get) Token: 0x060008F1 RID: 2289 RVA: 0x0001A3FC File Offset: 0x000185FC
		private static Screen.GetMonitorWidthMmNativeDelegate GetMonitorWidthMmVMCallback
		{
			get
			{
				if (Screen.GetMonitorWidthMm_cb_delegate == null)
				{
					Screen.GetMonitorWidthMm_cb_delegate = new Screen.GetMonitorWidthMmNativeDelegate(Screen.GetMonitorWidthMm_cb);
				}
				return Screen.GetMonitorWidthMm_cb_delegate;
			}
		}

		// Token: 0x060008F2 RID: 2290 RVA: 0x0001A41B File Offset: 0x0001861B
		private static void OverrideGetMonitorWidthMm(GType gtype)
		{
			Screen.OverrideGetMonitorWidthMm(gtype, Screen.GetMonitorWidthMmVMCallback);
		}

		// Token: 0x060008F3 RID: 2291 RVA: 0x0001A428 File Offset: 0x00018628
		private unsafe static void OverrideGetMonitorWidthMm(GType gtype, Screen.GetMonitorWidthMmNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_monitor_width_mm");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060008F4 RID: 2292 RVA: 0x0001A45C File Offset: 0x0001865C
		private static int GetMonitorWidthMm_cb(IntPtr inst, int monitor_num)
		{
			int result;
			try
			{
				result = (Object.GetObject(inst, false) as Screen).OnGetMonitorWidthMm(monitor_num);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060008F5 RID: 2293 RVA: 0x0001A498 File Offset: 0x00018698
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetMonitorWidthMm")]
		protected virtual int OnGetMonitorWidthMm(int monitor_num)
		{
			return this.InternalGetMonitorWidthMm(monitor_num);
		}

		// Token: 0x060008F6 RID: 2294 RVA: 0x0001A4A4 File Offset: 0x000186A4
		private int InternalGetMonitorWidthMm(int monitor_num)
		{
			Screen.GetMonitorWidthMmNativeDelegate getMonitorWidthMmNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_monitor_width_mm");
			if (getMonitorWidthMmNativeDelegate == null)
			{
				return 0;
			}
			return getMonitorWidthMmNativeDelegate(base.Handle, monitor_num);
		}

		// Token: 0x17000244 RID: 580
		// (get) Token: 0x060008F7 RID: 2295 RVA: 0x0001A4D9 File Offset: 0x000186D9
		private static Screen.GetMonitorHeightMmNativeDelegate GetMonitorHeightMmVMCallback
		{
			get
			{
				if (Screen.GetMonitorHeightMm_cb_delegate == null)
				{
					Screen.GetMonitorHeightMm_cb_delegate = new Screen.GetMonitorHeightMmNativeDelegate(Screen.GetMonitorHeightMm_cb);
				}
				return Screen.GetMonitorHeightMm_cb_delegate;
			}
		}

		// Token: 0x060008F8 RID: 2296 RVA: 0x0001A4F8 File Offset: 0x000186F8
		private static void OverrideGetMonitorHeightMm(GType gtype)
		{
			Screen.OverrideGetMonitorHeightMm(gtype, Screen.GetMonitorHeightMmVMCallback);
		}

		// Token: 0x060008F9 RID: 2297 RVA: 0x0001A508 File Offset: 0x00018708
		private unsafe static void OverrideGetMonitorHeightMm(GType gtype, Screen.GetMonitorHeightMmNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_monitor_height_mm");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060008FA RID: 2298 RVA: 0x0001A53C File Offset: 0x0001873C
		private static int GetMonitorHeightMm_cb(IntPtr inst, int monitor_num)
		{
			int result;
			try
			{
				result = (Object.GetObject(inst, false) as Screen).OnGetMonitorHeightMm(monitor_num);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060008FB RID: 2299 RVA: 0x0001A578 File Offset: 0x00018778
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetMonitorHeightMm")]
		protected virtual int OnGetMonitorHeightMm(int monitor_num)
		{
			return this.InternalGetMonitorHeightMm(monitor_num);
		}

		// Token: 0x060008FC RID: 2300 RVA: 0x0001A584 File Offset: 0x00018784
		private int InternalGetMonitorHeightMm(int monitor_num)
		{
			Screen.GetMonitorHeightMmNativeDelegate getMonitorHeightMmNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_monitor_height_mm");
			if (getMonitorHeightMmNativeDelegate == null)
			{
				return 0;
			}
			return getMonitorHeightMmNativeDelegate(base.Handle, monitor_num);
		}

		// Token: 0x17000245 RID: 581
		// (get) Token: 0x060008FD RID: 2301 RVA: 0x0001A5B9 File Offset: 0x000187B9
		private static Screen.GetMonitorPlugNameNativeDelegate GetMonitorPlugNameVMCallback
		{
			get
			{
				if (Screen.GetMonitorPlugName_cb_delegate == null)
				{
					Screen.GetMonitorPlugName_cb_delegate = new Screen.GetMonitorPlugNameNativeDelegate(Screen.GetMonitorPlugName_cb);
				}
				return Screen.GetMonitorPlugName_cb_delegate;
			}
		}

		// Token: 0x060008FE RID: 2302 RVA: 0x0001A5D8 File Offset: 0x000187D8
		private static void OverrideGetMonitorPlugName(GType gtype)
		{
			Screen.OverrideGetMonitorPlugName(gtype, Screen.GetMonitorPlugNameVMCallback);
		}

		// Token: 0x060008FF RID: 2303 RVA: 0x0001A5E8 File Offset: 0x000187E8
		private unsafe static void OverrideGetMonitorPlugName(GType gtype, Screen.GetMonitorPlugNameNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_monitor_plug_name");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000900 RID: 2304 RVA: 0x0001A61C File Offset: 0x0001881C
		private static IntPtr GetMonitorPlugName_cb(IntPtr inst, int monitor_num)
		{
			IntPtr result;
			try
			{
				result = Marshaller.StringToPtrGStrdup((Object.GetObject(inst, false) as Screen).OnGetMonitorPlugName(monitor_num));
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000901 RID: 2305 RVA: 0x0001A65C File Offset: 0x0001885C
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetMonitorPlugName")]
		protected virtual string OnGetMonitorPlugName(int monitor_num)
		{
			return this.InternalGetMonitorPlugName(monitor_num);
		}

		// Token: 0x06000902 RID: 2306 RVA: 0x0001A668 File Offset: 0x00018868
		private string InternalGetMonitorPlugName(int monitor_num)
		{
			Screen.GetMonitorPlugNameNativeDelegate getMonitorPlugNameNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_monitor_plug_name");
			if (getMonitorPlugNameNativeDelegate == null)
			{
				return null;
			}
			return Marshaller.PtrToStringGFree(getMonitorPlugNameNativeDelegate(base.Handle, monitor_num));
		}

		// Token: 0x17000246 RID: 582
		// (get) Token: 0x06000903 RID: 2307 RVA: 0x0001A6A2 File Offset: 0x000188A2
		private static Screen.GetMonitorGeometryNativeDelegate GetMonitorGeometryVMCallback
		{
			get
			{
				if (Screen.GetMonitorGeometry_cb_delegate == null)
				{
					Screen.GetMonitorGeometry_cb_delegate = new Screen.GetMonitorGeometryNativeDelegate(Screen.GetMonitorGeometry_cb);
				}
				return Screen.GetMonitorGeometry_cb_delegate;
			}
		}

		// Token: 0x06000904 RID: 2308 RVA: 0x0001A6C1 File Offset: 0x000188C1
		private static void OverrideGetMonitorGeometry(GType gtype)
		{
			Screen.OverrideGetMonitorGeometry(gtype, Screen.GetMonitorGeometryVMCallback);
		}

		// Token: 0x06000905 RID: 2309 RVA: 0x0001A6D0 File Offset: 0x000188D0
		private unsafe static void OverrideGetMonitorGeometry(GType gtype, Screen.GetMonitorGeometryNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_monitor_geometry");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000906 RID: 2310 RVA: 0x0001A704 File Offset: 0x00018904
		private static void GetMonitorGeometry_cb(IntPtr inst, int monitor_num, IntPtr dest)
		{
			try
			{
				(Object.GetObject(inst, false) as Screen).OnGetMonitorGeometry(monitor_num, (Rectangle)Marshal.PtrToStructure(dest, typeof(Rectangle)));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000907 RID: 2311 RVA: 0x0001A754 File Offset: 0x00018954
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetMonitorGeometry")]
		protected virtual void OnGetMonitorGeometry(int monitor_num, Rectangle dest)
		{
			this.InternalGetMonitorGeometry(monitor_num, dest);
		}

		// Token: 0x06000908 RID: 2312 RVA: 0x0001A760 File Offset: 0x00018960
		private void InternalGetMonitorGeometry(int monitor_num, Rectangle dest)
		{
			Screen.GetMonitorGeometryNativeDelegate getMonitorGeometryNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_monitor_geometry");
			if (getMonitorGeometryNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(dest);
			getMonitorGeometryNativeDelegate(base.Handle, monitor_num, intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x17000247 RID: 583
		// (get) Token: 0x06000909 RID: 2313 RVA: 0x0001A7A7 File Offset: 0x000189A7
		private static Screen.GetMonitorWorkareaNativeDelegate GetMonitorWorkareaVMCallback
		{
			get
			{
				if (Screen.GetMonitorWorkarea_cb_delegate == null)
				{
					Screen.GetMonitorWorkarea_cb_delegate = new Screen.GetMonitorWorkareaNativeDelegate(Screen.GetMonitorWorkarea_cb);
				}
				return Screen.GetMonitorWorkarea_cb_delegate;
			}
		}

		// Token: 0x0600090A RID: 2314 RVA: 0x0001A7C6 File Offset: 0x000189C6
		private static void OverrideGetMonitorWorkarea(GType gtype)
		{
			Screen.OverrideGetMonitorWorkarea(gtype, Screen.GetMonitorWorkareaVMCallback);
		}

		// Token: 0x0600090B RID: 2315 RVA: 0x0001A7D4 File Offset: 0x000189D4
		private unsafe static void OverrideGetMonitorWorkarea(GType gtype, Screen.GetMonitorWorkareaNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_monitor_workarea");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600090C RID: 2316 RVA: 0x0001A808 File Offset: 0x00018A08
		private static void GetMonitorWorkarea_cb(IntPtr inst, int monitor_num, IntPtr dest)
		{
			try
			{
				(Object.GetObject(inst, false) as Screen).OnGetMonitorWorkarea(monitor_num, (Rectangle)Marshal.PtrToStructure(dest, typeof(Rectangle)));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x0600090D RID: 2317 RVA: 0x0001A858 File Offset: 0x00018A58
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetMonitorWorkarea")]
		protected virtual void OnGetMonitorWorkarea(int monitor_num, Rectangle dest)
		{
			this.InternalGetMonitorWorkarea(monitor_num, dest);
		}

		// Token: 0x0600090E RID: 2318 RVA: 0x0001A864 File Offset: 0x00018A64
		private void InternalGetMonitorWorkarea(int monitor_num, Rectangle dest)
		{
			Screen.GetMonitorWorkareaNativeDelegate getMonitorWorkareaNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_monitor_workarea");
			if (getMonitorWorkareaNativeDelegate == null)
			{
				return;
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(dest);
			getMonitorWorkareaNativeDelegate(base.Handle, monitor_num, intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x17000248 RID: 584
		// (get) Token: 0x0600090F RID: 2319 RVA: 0x0001A8AB File Offset: 0x00018AAB
		private static Screen.ListVisualsNativeDelegate ListVisualsVMCallback
		{
			get
			{
				if (Screen.ListVisuals_cb_delegate == null)
				{
					Screen.ListVisuals_cb_delegate = new Screen.ListVisualsNativeDelegate(Screen.ListVisuals_cb);
				}
				return Screen.ListVisuals_cb_delegate;
			}
		}

		// Token: 0x06000910 RID: 2320 RVA: 0x0001A8CA File Offset: 0x00018ACA
		private static void OverrideListVisuals(GType gtype)
		{
			Screen.OverrideListVisuals(gtype, Screen.ListVisualsVMCallback);
		}

		// Token: 0x06000911 RID: 2321 RVA: 0x0001A8D8 File Offset: 0x00018AD8
		private unsafe static void OverrideListVisuals(GType gtype, Screen.ListVisualsNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("list_visuals");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000912 RID: 2322 RVA: 0x0001A90C File Offset: 0x00018B0C
		private static IntPtr ListVisuals_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				List list = (Object.GetObject(inst, false) as Screen).OnListVisuals();
				result = ((list == null) ? IntPtr.Zero : list.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000913 RID: 2323 RVA: 0x0001A958 File Offset: 0x00018B58
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideListVisuals")]
		protected virtual List OnListVisuals()
		{
			return this.InternalListVisuals();
		}

		// Token: 0x06000914 RID: 2324 RVA: 0x0001A960 File Offset: 0x00018B60
		private List InternalListVisuals()
		{
			Screen.ListVisualsNativeDelegate listVisualsNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "list_visuals");
			if (listVisualsNativeDelegate == null)
			{
				return null;
			}
			return new List(listVisualsNativeDelegate(base.Handle));
		}

		// Token: 0x17000249 RID: 585
		// (get) Token: 0x06000915 RID: 2325 RVA: 0x0001A999 File Offset: 0x00018B99
		private static Screen.GetSystemVisualNativeDelegate GetSystemVisualVMCallback
		{
			get
			{
				if (Screen.GetSystemVisual_cb_delegate == null)
				{
					Screen.GetSystemVisual_cb_delegate = new Screen.GetSystemVisualNativeDelegate(Screen.GetSystemVisual_cb);
				}
				return Screen.GetSystemVisual_cb_delegate;
			}
		}

		// Token: 0x06000916 RID: 2326 RVA: 0x0001A9B8 File Offset: 0x00018BB8
		private static void OverrideGetSystemVisual(GType gtype)
		{
			Screen.OverrideGetSystemVisual(gtype, Screen.GetSystemVisualVMCallback);
		}

		// Token: 0x06000917 RID: 2327 RVA: 0x0001A9C8 File Offset: 0x00018BC8
		private unsafe static void OverrideGetSystemVisual(GType gtype, Screen.GetSystemVisualNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_system_visual");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000918 RID: 2328 RVA: 0x0001A9FC File Offset: 0x00018BFC
		private static IntPtr GetSystemVisual_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				Visual visual = (Object.GetObject(inst, false) as Screen).OnGetSystemVisual();
				result = ((visual == null) ? IntPtr.Zero : visual.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000919 RID: 2329 RVA: 0x0001AA48 File Offset: 0x00018C48
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetSystemVisual")]
		protected virtual Visual OnGetSystemVisual()
		{
			return this.InternalGetSystemVisual();
		}

		// Token: 0x0600091A RID: 2330 RVA: 0x0001AA50 File Offset: 0x00018C50
		private Visual InternalGetSystemVisual()
		{
			Screen.GetSystemVisualNativeDelegate getSystemVisualNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_system_visual");
			if (getSystemVisualNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getSystemVisualNativeDelegate(base.Handle)) as Visual;
		}

		// Token: 0x1700024A RID: 586
		// (get) Token: 0x0600091B RID: 2331 RVA: 0x0001AA8E File Offset: 0x00018C8E
		private static Screen.GetRgbaVisualNativeDelegate GetRgbaVisualVMCallback
		{
			get
			{
				if (Screen.GetRgbaVisual_cb_delegate == null)
				{
					Screen.GetRgbaVisual_cb_delegate = new Screen.GetRgbaVisualNativeDelegate(Screen.GetRgbaVisual_cb);
				}
				return Screen.GetRgbaVisual_cb_delegate;
			}
		}

		// Token: 0x0600091C RID: 2332 RVA: 0x0001AAAD File Offset: 0x00018CAD
		private static void OverrideGetRgbaVisual(GType gtype)
		{
			Screen.OverrideGetRgbaVisual(gtype, Screen.GetRgbaVisualVMCallback);
		}

		// Token: 0x0600091D RID: 2333 RVA: 0x0001AABC File Offset: 0x00018CBC
		private unsafe static void OverrideGetRgbaVisual(GType gtype, Screen.GetRgbaVisualNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_rgba_visual");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600091E RID: 2334 RVA: 0x0001AAF0 File Offset: 0x00018CF0
		private static IntPtr GetRgbaVisual_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				Visual visual = (Object.GetObject(inst, false) as Screen).OnGetRgbaVisual();
				result = ((visual == null) ? IntPtr.Zero : visual.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600091F RID: 2335 RVA: 0x0001AB3C File Offset: 0x00018D3C
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetRgbaVisual")]
		protected virtual Visual OnGetRgbaVisual()
		{
			return this.InternalGetRgbaVisual();
		}

		// Token: 0x06000920 RID: 2336 RVA: 0x0001AB44 File Offset: 0x00018D44
		private Visual InternalGetRgbaVisual()
		{
			Screen.GetRgbaVisualNativeDelegate getRgbaVisualNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_rgba_visual");
			if (getRgbaVisualNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getRgbaVisualNativeDelegate(base.Handle)) as Visual;
		}

		// Token: 0x1700024B RID: 587
		// (get) Token: 0x06000921 RID: 2337 RVA: 0x0001AB82 File Offset: 0x00018D82
		private static Screen.IsCompositedNativeDelegate IsCompositedVMCallback
		{
			get
			{
				if (Screen.IsComposited_cb_delegate == null)
				{
					Screen.IsComposited_cb_delegate = new Screen.IsCompositedNativeDelegate(Screen.IsComposited_cb);
				}
				return Screen.IsComposited_cb_delegate;
			}
		}

		// Token: 0x06000922 RID: 2338 RVA: 0x0001ABA1 File Offset: 0x00018DA1
		private static void OverrideIsComposited(GType gtype)
		{
			Screen.OverrideIsComposited(gtype, Screen.IsCompositedVMCallback);
		}

		// Token: 0x06000923 RID: 2339 RVA: 0x0001ABB0 File Offset: 0x00018DB0
		private unsafe static void OverrideIsComposited(GType gtype, Screen.IsCompositedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("is_composited");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000924 RID: 2340 RVA: 0x0001ABE4 File Offset: 0x00018DE4
		private static bool IsComposited_cb(IntPtr inst)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Screen).OnIsComposited();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000925 RID: 2341 RVA: 0x0001AC20 File Offset: 0x00018E20
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideIsComposited")]
		protected virtual bool OnIsComposited()
		{
			return this.InternalIsComposited();
		}

		// Token: 0x06000926 RID: 2342 RVA: 0x0001AC28 File Offset: 0x00018E28
		private bool InternalIsComposited()
		{
			Screen.IsCompositedNativeDelegate isCompositedNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "is_composited");
			return isCompositedNativeDelegate != null && isCompositedNativeDelegate(base.Handle);
		}

		// Token: 0x1700024C RID: 588
		// (get) Token: 0x06000927 RID: 2343 RVA: 0x0001AC5C File Offset: 0x00018E5C
		private static Screen.MakeDisplayNameNativeDelegate MakeDisplayNameVMCallback
		{
			get
			{
				if (Screen.MakeDisplayName_cb_delegate == null)
				{
					Screen.MakeDisplayName_cb_delegate = new Screen.MakeDisplayNameNativeDelegate(Screen.MakeDisplayName_cb);
				}
				return Screen.MakeDisplayName_cb_delegate;
			}
		}

		// Token: 0x06000928 RID: 2344 RVA: 0x0001AC7B File Offset: 0x00018E7B
		private static void OverrideMakeDisplayName(GType gtype)
		{
			Screen.OverrideMakeDisplayName(gtype, Screen.MakeDisplayNameVMCallback);
		}

		// Token: 0x06000929 RID: 2345 RVA: 0x0001AC88 File Offset: 0x00018E88
		private unsafe static void OverrideMakeDisplayName(GType gtype, Screen.MakeDisplayNameNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("make_display_name");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600092A RID: 2346 RVA: 0x0001ACBC File Offset: 0x00018EBC
		private static IntPtr MakeDisplayName_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				result = Marshaller.StringToPtrGStrdup((Object.GetObject(inst, false) as Screen).OnMakeDisplayName());
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600092B RID: 2347 RVA: 0x0001ACFC File Offset: 0x00018EFC
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideMakeDisplayName")]
		protected virtual string OnMakeDisplayName()
		{
			return this.InternalMakeDisplayName();
		}

		// Token: 0x0600092C RID: 2348 RVA: 0x0001AD04 File Offset: 0x00018F04
		private string InternalMakeDisplayName()
		{
			Screen.MakeDisplayNameNativeDelegate makeDisplayNameNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "make_display_name");
			if (makeDisplayNameNativeDelegate == null)
			{
				return null;
			}
			return Marshaller.PtrToStringGFree(makeDisplayNameNativeDelegate(base.Handle));
		}

		// Token: 0x1700024D RID: 589
		// (get) Token: 0x0600092D RID: 2349 RVA: 0x0001AD3D File Offset: 0x00018F3D
		private static Screen.GetActiveWindowNativeDelegate GetActiveWindowVMCallback
		{
			get
			{
				if (Screen.GetActiveWindow_cb_delegate == null)
				{
					Screen.GetActiveWindow_cb_delegate = new Screen.GetActiveWindowNativeDelegate(Screen.GetActiveWindow_cb);
				}
				return Screen.GetActiveWindow_cb_delegate;
			}
		}

		// Token: 0x0600092E RID: 2350 RVA: 0x0001AD5C File Offset: 0x00018F5C
		private static void OverrideGetActiveWindow(GType gtype)
		{
			Screen.OverrideGetActiveWindow(gtype, Screen.GetActiveWindowVMCallback);
		}

		// Token: 0x0600092F RID: 2351 RVA: 0x0001AD6C File Offset: 0x00018F6C
		private unsafe static void OverrideGetActiveWindow(GType gtype, Screen.GetActiveWindowNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_active_window");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000930 RID: 2352 RVA: 0x0001ADA0 File Offset: 0x00018FA0
		private static IntPtr GetActiveWindow_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				Window window = (Object.GetObject(inst, false) as Screen).OnGetActiveWindow();
				result = ((window == null) ? IntPtr.Zero : window.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000931 RID: 2353 RVA: 0x0001ADEC File Offset: 0x00018FEC
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetActiveWindow")]
		protected virtual Window OnGetActiveWindow()
		{
			return this.InternalGetActiveWindow();
		}

		// Token: 0x06000932 RID: 2354 RVA: 0x0001ADF4 File Offset: 0x00018FF4
		private Window InternalGetActiveWindow()
		{
			Screen.GetActiveWindowNativeDelegate getActiveWindowNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_active_window");
			if (getActiveWindowNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(getActiveWindowNativeDelegate(base.Handle)) as Window;
		}

		// Token: 0x1700024E RID: 590
		// (get) Token: 0x06000933 RID: 2355 RVA: 0x0001AE32 File Offset: 0x00019032
		private static Screen.GetWindowStackNativeDelegate GetWindowStackVMCallback
		{
			get
			{
				if (Screen.GetWindowStack_cb_delegate == null)
				{
					Screen.GetWindowStack_cb_delegate = new Screen.GetWindowStackNativeDelegate(Screen.GetWindowStack_cb);
				}
				return Screen.GetWindowStack_cb_delegate;
			}
		}

		// Token: 0x06000934 RID: 2356 RVA: 0x0001AE51 File Offset: 0x00019051
		private static void OverrideGetWindowStack(GType gtype)
		{
			Screen.OverrideGetWindowStack(gtype, Screen.GetWindowStackVMCallback);
		}

		// Token: 0x06000935 RID: 2357 RVA: 0x0001AE60 File Offset: 0x00019060
		private unsafe static void OverrideGetWindowStack(GType gtype, Screen.GetWindowStackNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_window_stack");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000936 RID: 2358 RVA: 0x0001AE94 File Offset: 0x00019094
		private static IntPtr GetWindowStack_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				Window[] array = (Object.GetObject(inst, false) as Screen).OnGetWindowStack();
				object[] elements = array;
				IntPtr intPtr;
				if (new List(elements, typeof(Window), true, true) != null)
				{
					elements = array;
					intPtr = new List(elements, typeof(Window), true, true).Handle;
				}
				else
				{
					intPtr = IntPtr.Zero;
				}
				result = intPtr;
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000937 RID: 2359 RVA: 0x0001AF08 File Offset: 0x00019108
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetWindowStack")]
		protected virtual Window[] OnGetWindowStack()
		{
			return this.InternalGetWindowStack();
		}

		// Token: 0x06000938 RID: 2360 RVA: 0x0001AF10 File Offset: 0x00019110
		private Window[] InternalGetWindowStack()
		{
			Screen.GetWindowStackNativeDelegate getWindowStackNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_window_stack");
			if (getWindowStackNativeDelegate == null)
			{
				return null;
			}
			return (Window[])Marshaller.ListPtrToArray(getWindowStackNativeDelegate(base.Handle), typeof(List), true, true, typeof(Window));
		}

		// Token: 0x1700024F RID: 591
		// (get) Token: 0x06000939 RID: 2361 RVA: 0x0001AF64 File Offset: 0x00019164
		private static Screen.BroadcastClientMessageNativeDelegate BroadcastClientMessageVMCallback
		{
			get
			{
				if (Screen.BroadcastClientMessage_cb_delegate == null)
				{
					Screen.BroadcastClientMessage_cb_delegate = new Screen.BroadcastClientMessageNativeDelegate(Screen.BroadcastClientMessage_cb);
				}
				return Screen.BroadcastClientMessage_cb_delegate;
			}
		}

		// Token: 0x0600093A RID: 2362 RVA: 0x0001AF83 File Offset: 0x00019183
		private static void OverrideBroadcastClientMessage(GType gtype)
		{
			Screen.OverrideBroadcastClientMessage(gtype, Screen.BroadcastClientMessageVMCallback);
		}

		// Token: 0x0600093B RID: 2363 RVA: 0x0001AF90 File Offset: 0x00019190
		private unsafe static void OverrideBroadcastClientMessage(GType gtype, Screen.BroadcastClientMessageNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("broadcast_client_message");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600093C RID: 2364 RVA: 0x0001AFC4 File Offset: 0x000191C4
		private static void BroadcastClientMessage_cb(IntPtr inst, IntPtr evnt)
		{
			try
			{
				(Object.GetObject(inst, false) as Screen).OnBroadcastClientMessage(Event.GetEvent(evnt));
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x0600093D RID: 2365 RVA: 0x0001B004 File Offset: 0x00019204
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideBroadcastClientMessage")]
		protected virtual void OnBroadcastClientMessage(Event evnt)
		{
			this.InternalBroadcastClientMessage(evnt);
		}

		// Token: 0x0600093E RID: 2366 RVA: 0x0001B010 File Offset: 0x00019210
		private void InternalBroadcastClientMessage(Event evnt)
		{
			Screen.BroadcastClientMessageNativeDelegate broadcastClientMessageNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "broadcast_client_message");
			if (broadcastClientMessageNativeDelegate == null)
			{
				return;
			}
			broadcastClientMessageNativeDelegate(base.Handle, (evnt == null) ? IntPtr.Zero : evnt.Handle);
		}

		// Token: 0x17000250 RID: 592
		// (get) Token: 0x0600093F RID: 2367 RVA: 0x0001B053 File Offset: 0x00019253
		private static Screen.GetSettingNativeDelegate GetSettingVMCallback
		{
			get
			{
				if (Screen.GetSetting_cb_delegate == null)
				{
					Screen.GetSetting_cb_delegate = new Screen.GetSettingNativeDelegate(Screen.GetSetting_cb);
				}
				return Screen.GetSetting_cb_delegate;
			}
		}

		// Token: 0x06000940 RID: 2368 RVA: 0x0001B072 File Offset: 0x00019272
		private static void OverrideGetSetting(GType gtype)
		{
			Screen.OverrideGetSetting(gtype, Screen.GetSettingVMCallback);
		}

		// Token: 0x06000941 RID: 2369 RVA: 0x0001B080 File Offset: 0x00019280
		private unsafe static void OverrideGetSetting(GType gtype, Screen.GetSettingNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_setting");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000942 RID: 2370 RVA: 0x0001B0B4 File Offset: 0x000192B4
		private static bool GetSetting_cb(IntPtr inst, IntPtr name, IntPtr value)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Screen).OnGetSetting(Marshaller.Utf8PtrToString(name), (Value)Marshal.PtrToStructure(value, typeof(Value)));
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000943 RID: 2371 RVA: 0x0001B10C File Offset: 0x0001930C
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetSetting")]
		protected virtual bool OnGetSetting(string name, Value value)
		{
			return this.InternalGetSetting(name, value);
		}

		// Token: 0x06000944 RID: 2372 RVA: 0x0001B118 File Offset: 0x00019318
		private bool InternalGetSetting(string name, Value value)
		{
			Screen.GetSettingNativeDelegate getSettingNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_setting");
			if (getSettingNativeDelegate == null)
			{
				return false;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(name);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(value);
			bool result = getSettingNativeDelegate(base.Handle, intPtr, intPtr2);
			Marshaller.Free(intPtr);
			Marshal.FreeHGlobal(intPtr2);
			return result;
		}

		// Token: 0x17000251 RID: 593
		// (get) Token: 0x06000945 RID: 2373 RVA: 0x0001B16D File Offset: 0x0001936D
		private static Screen.VisualGetBestDepthNativeDelegate VisualGetBestDepthVMCallback
		{
			get
			{
				if (Screen.VisualGetBestDepth_cb_delegate == null)
				{
					Screen.VisualGetBestDepth_cb_delegate = new Screen.VisualGetBestDepthNativeDelegate(Screen.VisualGetBestDepth_cb);
				}
				return Screen.VisualGetBestDepth_cb_delegate;
			}
		}

		// Token: 0x06000946 RID: 2374 RVA: 0x0001B18C File Offset: 0x0001938C
		private static void OverrideVisualGetBestDepth(GType gtype)
		{
			Screen.OverrideVisualGetBestDepth(gtype, Screen.VisualGetBestDepthVMCallback);
		}

		// Token: 0x06000947 RID: 2375 RVA: 0x0001B19C File Offset: 0x0001939C
		private unsafe static void OverrideVisualGetBestDepth(GType gtype, Screen.VisualGetBestDepthNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("visual_get_best_depth");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000948 RID: 2376 RVA: 0x0001B1D0 File Offset: 0x000193D0
		private static int VisualGetBestDepth_cb(IntPtr inst)
		{
			int result;
			try
			{
				result = (Object.GetObject(inst, false) as Screen).OnVisualGetBestDepth();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000949 RID: 2377 RVA: 0x0001B20C File Offset: 0x0001940C
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideVisualGetBestDepth")]
		protected virtual int OnVisualGetBestDepth()
		{
			return this.InternalVisualGetBestDepth();
		}

		// Token: 0x0600094A RID: 2378 RVA: 0x0001B214 File Offset: 0x00019414
		private int InternalVisualGetBestDepth()
		{
			Screen.VisualGetBestDepthNativeDelegate visualGetBestDepthNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "visual_get_best_depth");
			if (visualGetBestDepthNativeDelegate == null)
			{
				return 0;
			}
			return visualGetBestDepthNativeDelegate(base.Handle);
		}

		// Token: 0x17000252 RID: 594
		// (get) Token: 0x0600094B RID: 2379 RVA: 0x0001B248 File Offset: 0x00019448
		private static Screen.VisualGetBestTypeNativeDelegate VisualGetBestTypeVMCallback
		{
			get
			{
				if (Screen.VisualGetBestType_cb_delegate == null)
				{
					Screen.VisualGetBestType_cb_delegate = new Screen.VisualGetBestTypeNativeDelegate(Screen.VisualGetBestType_cb);
				}
				return Screen.VisualGetBestType_cb_delegate;
			}
		}

		// Token: 0x0600094C RID: 2380 RVA: 0x0001B267 File Offset: 0x00019467
		private static void OverrideVisualGetBestType(GType gtype)
		{
			Screen.OverrideVisualGetBestType(gtype, Screen.VisualGetBestTypeVMCallback);
		}

		// Token: 0x0600094D RID: 2381 RVA: 0x0001B274 File Offset: 0x00019474
		private unsafe static void OverrideVisualGetBestType(GType gtype, Screen.VisualGetBestTypeNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("visual_get_best_type");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600094E RID: 2382 RVA: 0x0001B2A8 File Offset: 0x000194A8
		private static int VisualGetBestType_cb(IntPtr inst)
		{
			int result;
			try
			{
				result = (int)(Object.GetObject(inst, false) as Screen).OnVisualGetBestType();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600094F RID: 2383 RVA: 0x0001B2E4 File Offset: 0x000194E4
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideVisualGetBestType")]
		protected virtual VisualType OnVisualGetBestType()
		{
			return this.InternalVisualGetBestType();
		}

		// Token: 0x06000950 RID: 2384 RVA: 0x0001B2EC File Offset: 0x000194EC
		private VisualType InternalVisualGetBestType()
		{
			Screen.VisualGetBestTypeNativeDelegate visualGetBestTypeNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "visual_get_best_type");
			if (visualGetBestTypeNativeDelegate == null)
			{
				return VisualType.StaticGray;
			}
			return (VisualType)visualGetBestTypeNativeDelegate(base.Handle);
		}

		// Token: 0x17000253 RID: 595
		// (get) Token: 0x06000951 RID: 2385 RVA: 0x0001B320 File Offset: 0x00019520
		private static Screen.VisualGetBestNativeDelegate VisualGetBestVMCallback
		{
			get
			{
				if (Screen.VisualGetBest_cb_delegate == null)
				{
					Screen.VisualGetBest_cb_delegate = new Screen.VisualGetBestNativeDelegate(Screen.VisualGetBest_cb);
				}
				return Screen.VisualGetBest_cb_delegate;
			}
		}

		// Token: 0x06000952 RID: 2386 RVA: 0x0001B33F File Offset: 0x0001953F
		private static void OverrideVisualGetBest(GType gtype)
		{
			Screen.OverrideVisualGetBest(gtype, Screen.VisualGetBestVMCallback);
		}

		// Token: 0x06000953 RID: 2387 RVA: 0x0001B34C File Offset: 0x0001954C
		private unsafe static void OverrideVisualGetBest(GType gtype, Screen.VisualGetBestNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("visual_get_best");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000954 RID: 2388 RVA: 0x0001B380 File Offset: 0x00019580
		private static IntPtr VisualGetBest_cb(IntPtr inst)
		{
			IntPtr result;
			try
			{
				Visual visual = (Object.GetObject(inst, false) as Screen).OnVisualGetBest();
				result = ((visual == null) ? IntPtr.Zero : visual.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000955 RID: 2389 RVA: 0x0001B3CC File Offset: 0x000195CC
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideVisualGetBest")]
		protected virtual Visual OnVisualGetBest()
		{
			return this.InternalVisualGetBest();
		}

		// Token: 0x06000956 RID: 2390 RVA: 0x0001B3D4 File Offset: 0x000195D4
		private Visual InternalVisualGetBest()
		{
			Screen.VisualGetBestNativeDelegate visualGetBestNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "visual_get_best");
			if (visualGetBestNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(visualGetBestNativeDelegate(base.Handle)) as Visual;
		}

		// Token: 0x17000254 RID: 596
		// (get) Token: 0x06000957 RID: 2391 RVA: 0x0001B412 File Offset: 0x00019612
		private static Screen.VisualGetBestWithDepthNativeDelegate VisualGetBestWithDepthVMCallback
		{
			get
			{
				if (Screen.VisualGetBestWithDepth_cb_delegate == null)
				{
					Screen.VisualGetBestWithDepth_cb_delegate = new Screen.VisualGetBestWithDepthNativeDelegate(Screen.VisualGetBestWithDepth_cb);
				}
				return Screen.VisualGetBestWithDepth_cb_delegate;
			}
		}

		// Token: 0x06000958 RID: 2392 RVA: 0x0001B431 File Offset: 0x00019631
		private static void OverrideVisualGetBestWithDepth(GType gtype)
		{
			Screen.OverrideVisualGetBestWithDepth(gtype, Screen.VisualGetBestWithDepthVMCallback);
		}

		// Token: 0x06000959 RID: 2393 RVA: 0x0001B440 File Offset: 0x00019640
		private unsafe static void OverrideVisualGetBestWithDepth(GType gtype, Screen.VisualGetBestWithDepthNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("visual_get_best_with_depth");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600095A RID: 2394 RVA: 0x0001B474 File Offset: 0x00019674
		private static IntPtr VisualGetBestWithDepth_cb(IntPtr inst, int depth)
		{
			IntPtr result;
			try
			{
				Visual visual = (Object.GetObject(inst, false) as Screen).OnVisualGetBestWithDepth(depth);
				result = ((visual == null) ? IntPtr.Zero : visual.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600095B RID: 2395 RVA: 0x0001B4C0 File Offset: 0x000196C0
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideVisualGetBestWithDepth")]
		protected virtual Visual OnVisualGetBestWithDepth(int depth)
		{
			return this.InternalVisualGetBestWithDepth(depth);
		}

		// Token: 0x0600095C RID: 2396 RVA: 0x0001B4CC File Offset: 0x000196CC
		private Visual InternalVisualGetBestWithDepth(int depth)
		{
			Screen.VisualGetBestWithDepthNativeDelegate visualGetBestWithDepthNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "visual_get_best_with_depth");
			if (visualGetBestWithDepthNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(visualGetBestWithDepthNativeDelegate(base.Handle, depth)) as Visual;
		}

		// Token: 0x17000255 RID: 597
		// (get) Token: 0x0600095D RID: 2397 RVA: 0x0001B50B File Offset: 0x0001970B
		private static Screen.VisualGetBestWithTypeNativeDelegate VisualGetBestWithTypeVMCallback
		{
			get
			{
				if (Screen.VisualGetBestWithType_cb_delegate == null)
				{
					Screen.VisualGetBestWithType_cb_delegate = new Screen.VisualGetBestWithTypeNativeDelegate(Screen.VisualGetBestWithType_cb);
				}
				return Screen.VisualGetBestWithType_cb_delegate;
			}
		}

		// Token: 0x0600095E RID: 2398 RVA: 0x0001B52A File Offset: 0x0001972A
		private static void OverrideVisualGetBestWithType(GType gtype)
		{
			Screen.OverrideVisualGetBestWithType(gtype, Screen.VisualGetBestWithTypeVMCallback);
		}

		// Token: 0x0600095F RID: 2399 RVA: 0x0001B538 File Offset: 0x00019738
		private unsafe static void OverrideVisualGetBestWithType(GType gtype, Screen.VisualGetBestWithTypeNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("visual_get_best_with_type");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000960 RID: 2400 RVA: 0x0001B56C File Offset: 0x0001976C
		private static IntPtr VisualGetBestWithType_cb(IntPtr inst, int visual_type)
		{
			IntPtr result;
			try
			{
				Visual visual = (Object.GetObject(inst, false) as Screen).OnVisualGetBestWithType((VisualType)visual_type);
				result = ((visual == null) ? IntPtr.Zero : visual.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000961 RID: 2401 RVA: 0x0001B5B8 File Offset: 0x000197B8
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideVisualGetBestWithType")]
		protected virtual Visual OnVisualGetBestWithType(VisualType visual_type)
		{
			return this.InternalVisualGetBestWithType(visual_type);
		}

		// Token: 0x06000962 RID: 2402 RVA: 0x0001B5C4 File Offset: 0x000197C4
		private Visual InternalVisualGetBestWithType(VisualType visual_type)
		{
			Screen.VisualGetBestWithTypeNativeDelegate visualGetBestWithTypeNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "visual_get_best_with_type");
			if (visualGetBestWithTypeNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(visualGetBestWithTypeNativeDelegate(base.Handle, (int)visual_type)) as Visual;
		}

		// Token: 0x17000256 RID: 598
		// (get) Token: 0x06000963 RID: 2403 RVA: 0x0001B603 File Offset: 0x00019803
		private static Screen.VisualGetBestWithBothNativeDelegate VisualGetBestWithBothVMCallback
		{
			get
			{
				if (Screen.VisualGetBestWithBoth_cb_delegate == null)
				{
					Screen.VisualGetBestWithBoth_cb_delegate = new Screen.VisualGetBestWithBothNativeDelegate(Screen.VisualGetBestWithBoth_cb);
				}
				return Screen.VisualGetBestWithBoth_cb_delegate;
			}
		}

		// Token: 0x06000964 RID: 2404 RVA: 0x0001B622 File Offset: 0x00019822
		private static void OverrideVisualGetBestWithBoth(GType gtype)
		{
			Screen.OverrideVisualGetBestWithBoth(gtype, Screen.VisualGetBestWithBothVMCallback);
		}

		// Token: 0x06000965 RID: 2405 RVA: 0x0001B630 File Offset: 0x00019830
		private unsafe static void OverrideVisualGetBestWithBoth(GType gtype, Screen.VisualGetBestWithBothNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("visual_get_best_with_both");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000966 RID: 2406 RVA: 0x0001B664 File Offset: 0x00019864
		private static IntPtr VisualGetBestWithBoth_cb(IntPtr inst, int depth, int visual_type)
		{
			IntPtr result;
			try
			{
				Visual visual = (Object.GetObject(inst, false) as Screen).OnVisualGetBestWithBoth(depth, (VisualType)visual_type);
				result = ((visual == null) ? IntPtr.Zero : visual.Handle);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000967 RID: 2407 RVA: 0x0001B6B4 File Offset: 0x000198B4
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideVisualGetBestWithBoth")]
		protected virtual Visual OnVisualGetBestWithBoth(int depth, VisualType visual_type)
		{
			return this.InternalVisualGetBestWithBoth(depth, visual_type);
		}

		// Token: 0x06000968 RID: 2408 RVA: 0x0001B6C0 File Offset: 0x000198C0
		private Visual InternalVisualGetBestWithBoth(int depth, VisualType visual_type)
		{
			Screen.VisualGetBestWithBothNativeDelegate visualGetBestWithBothNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "visual_get_best_with_both");
			if (visualGetBestWithBothNativeDelegate == null)
			{
				return null;
			}
			return Object.GetObject(visualGetBestWithBothNativeDelegate(base.Handle, depth, (int)visual_type)) as Visual;
		}

		// Token: 0x17000257 RID: 599
		// (get) Token: 0x06000969 RID: 2409 RVA: 0x0001B700 File Offset: 0x00019900
		private static Screen.QueryDepthsNativeDelegate QueryDepthsVMCallback
		{
			get
			{
				if (Screen.QueryDepths_cb_delegate == null)
				{
					Screen.QueryDepths_cb_delegate = new Screen.QueryDepthsNativeDelegate(Screen.QueryDepths_cb);
				}
				return Screen.QueryDepths_cb_delegate;
			}
		}

		// Token: 0x0600096A RID: 2410 RVA: 0x0001B71F File Offset: 0x0001991F
		private static void OverrideQueryDepths(GType gtype)
		{
			Screen.OverrideQueryDepths(gtype, Screen.QueryDepthsVMCallback);
		}

		// Token: 0x0600096B RID: 2411 RVA: 0x0001B72C File Offset: 0x0001992C
		private unsafe static void OverrideQueryDepths(GType gtype, Screen.QueryDepthsNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("query_depths");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600096C RID: 2412 RVA: 0x0001B760 File Offset: 0x00019960
		private static void QueryDepths_cb(IntPtr inst, out int depths, out int count)
		{
			try
			{
				(Object.GetObject(inst, false) as Screen).OnQueryDepths(out depths, out count);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
		}

		// Token: 0x0600096D RID: 2413 RVA: 0x0001B79C File Offset: 0x0001999C
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideQueryDepths")]
		protected virtual void OnQueryDepths(out int depths, out int count)
		{
			this.InternalQueryDepths(out depths, out count);
		}

		// Token: 0x0600096E RID: 2414 RVA: 0x0001B7A6 File Offset: 0x000199A6
		private void InternalQueryDepths(out int depths, out int count)
		{
			Screen.QueryDepthsNativeDelegate queryDepthsNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "query_depths");
			if (queryDepthsNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			queryDepthsNativeDelegate(base.Handle, out depths, out count);
		}

		// Token: 0x17000258 RID: 600
		// (get) Token: 0x0600096F RID: 2415 RVA: 0x0001B7D8 File Offset: 0x000199D8
		private static Screen.QueryVisualTypesNativeDelegate QueryVisualTypesVMCallback
		{
			get
			{
				if (Screen.QueryVisualTypes_cb_delegate == null)
				{
					Screen.QueryVisualTypes_cb_delegate = new Screen.QueryVisualTypesNativeDelegate(Screen.QueryVisualTypes_cb);
				}
				return Screen.QueryVisualTypes_cb_delegate;
			}
		}

		// Token: 0x06000970 RID: 2416 RVA: 0x0001B7F7 File Offset: 0x000199F7
		private static void OverrideQueryVisualTypes(GType gtype)
		{
			Screen.OverrideQueryVisualTypes(gtype, Screen.QueryVisualTypesVMCallback);
		}

		// Token: 0x06000971 RID: 2417 RVA: 0x0001B804 File Offset: 0x00019A04
		private unsafe static void OverrideQueryVisualTypes(GType gtype, Screen.QueryVisualTypesNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("query_visual_types");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000972 RID: 2418 RVA: 0x0001B838 File Offset: 0x00019A38
		private static void QueryVisualTypes_cb(IntPtr inst, out int visual_types, out int count)
		{
			try
			{
				VisualType visualType;
				(Object.GetObject(inst, false) as Screen).OnQueryVisualTypes(out visualType, out count);
				visual_types = (int)visualType;
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
		}

		// Token: 0x06000973 RID: 2419 RVA: 0x0001B878 File Offset: 0x00019A78
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideQueryVisualTypes")]
		protected virtual void OnQueryVisualTypes(out VisualType visual_types, out int count)
		{
			this.InternalQueryVisualTypes(out visual_types, out count);
		}

		// Token: 0x06000974 RID: 2420 RVA: 0x0001B884 File Offset: 0x00019A84
		private void InternalQueryVisualTypes(out VisualType visual_types, out int count)
		{
			Screen.QueryVisualTypesNativeDelegate queryVisualTypesNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "query_visual_types");
			if (queryVisualTypesNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			int num;
			queryVisualTypesNativeDelegate(base.Handle, out num, out count);
			visual_types = (VisualType)num;
		}

		// Token: 0x17000259 RID: 601
		// (get) Token: 0x06000975 RID: 2421 RVA: 0x0001B8C5 File Offset: 0x00019AC5
		private static Screen.GetMonitorScaleFactorNativeDelegate GetMonitorScaleFactorVMCallback
		{
			get
			{
				if (Screen.GetMonitorScaleFactor_cb_delegate == null)
				{
					Screen.GetMonitorScaleFactor_cb_delegate = new Screen.GetMonitorScaleFactorNativeDelegate(Screen.GetMonitorScaleFactor_cb);
				}
				return Screen.GetMonitorScaleFactor_cb_delegate;
			}
		}

		// Token: 0x06000976 RID: 2422 RVA: 0x0001B8E4 File Offset: 0x00019AE4
		private static void OverrideGetMonitorScaleFactor(GType gtype)
		{
			Screen.OverrideGetMonitorScaleFactor(gtype, Screen.GetMonitorScaleFactorVMCallback);
		}

		// Token: 0x06000977 RID: 2423 RVA: 0x0001B8F4 File Offset: 0x00019AF4
		private unsafe static void OverrideGetMonitorScaleFactor(GType gtype, Screen.GetMonitorScaleFactorNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Screen.class_abi.GetFieldOffset("get_monitor_scale_factor");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000978 RID: 2424 RVA: 0x0001B928 File Offset: 0x00019B28
		private static int GetMonitorScaleFactor_cb(IntPtr inst, int monitor_num)
		{
			int result;
			try
			{
				result = (Object.GetObject(inst, false) as Screen).OnGetMonitorScaleFactor(monitor_num);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000979 RID: 2425 RVA: 0x0001B964 File Offset: 0x00019B64
		[DefaultSignalHandler(Type = typeof(Screen), ConnectionMethod = "OverrideGetMonitorScaleFactor")]
		protected virtual int OnGetMonitorScaleFactor(int monitor_num)
		{
			return this.InternalGetMonitorScaleFactor(monitor_num);
		}

		// Token: 0x0600097A RID: 2426 RVA: 0x0001B970 File Offset: 0x00019B70
		private int InternalGetMonitorScaleFactor(int monitor_num)
		{
			Screen.GetMonitorScaleFactorNativeDelegate getMonitorScaleFactorNativeDelegate = Screen.class_abi.BaseOverride(base.LookupGType(), "get_monitor_scale_factor");
			if (getMonitorScaleFactorNativeDelegate == null)
			{
				return 0;
			}
			return getMonitorScaleFactorNativeDelegate(base.Handle, monitor_num);
		}

		// Token: 0x1700025A RID: 602
		// (get) Token: 0x0600097B RID: 2427 RVA: 0x0001B9A8 File Offset: 0x00019BA8
		public new static AbiStruct class_abi
		{
			get
			{
				if (Screen._class_abi == null)
				{
					Screen._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("get_display", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "get_width", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_width", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_display", "get_height", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_height", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_width", "get_width_mm", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_width_mm", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_height", "get_height_mm", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_height_mm", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_width_mm", "get_number", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_number", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_height_mm", "get_root_window", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_root_window", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_number", "get_n_monitors", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_n_monitors", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_root_window", "get_primary_monitor", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_primary_monitor", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_n_monitors", "get_monitor_width_mm", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_monitor_width_mm", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_primary_monitor", "get_monitor_height_mm", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_monitor_height_mm", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_monitor_width_mm", "get_monitor_plug_name", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_monitor_plug_name", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_monitor_height_mm", "get_monitor_geometry", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_monitor_geometry", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_monitor_plug_name", "get_monitor_workarea", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_monitor_workarea", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_monitor_geometry", "list_visuals", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("list_visuals", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_monitor_workarea", "get_system_visual", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_system_visual", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "list_visuals", "get_rgba_visual", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_rgba_visual", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_system_visual", "is_composited", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("is_composited", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_rgba_visual", "make_display_name", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("make_display_name", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "is_composited", "get_active_window", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_active_window", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "make_display_name", "get_window_stack", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_window_stack", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_active_window", "broadcast_client_message", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("broadcast_client_message", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_window_stack", "get_setting", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_setting", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "broadcast_client_message", "visual_get_best_depth", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("visual_get_best_depth", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_setting", "visual_get_best_type", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("visual_get_best_type", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "visual_get_best_depth", "visual_get_best", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("visual_get_best", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "visual_get_best_type", "visual_get_best_with_depth", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("visual_get_best_with_depth", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "visual_get_best", "visual_get_best_with_type", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("visual_get_best_with_type", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "visual_get_best_with_depth", "visual_get_best_with_both", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("visual_get_best_with_both", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "visual_get_best_with_type", "query_depths", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("query_depths", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "visual_get_best_with_both", "query_visual_types", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("query_visual_types", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "query_depths", "get_monitor_scale_factor", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_monitor_scale_factor", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "query_visual_types", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Screen._class_abi;
			}
		}

		// Token: 0x1700025B RID: 603
		// (get) Token: 0x0600097C RID: 2428 RVA: 0x0001C153 File Offset: 0x0001A353
		[Obsolete]
		public Window ActiveWindow
		{
			get
			{
				return Object.GetObject(Screen.gdk_screen_get_active_window(base.Handle)) as Window;
			}
		}

		// Token: 0x1700025C RID: 604
		// (get) Token: 0x0600097D RID: 2429 RVA: 0x0001C16F File Offset: 0x0001A36F
		public static Screen Default
		{
			get
			{
				return Object.GetObject(Screen.gdk_screen_get_default()) as Screen;
			}
		}

		// Token: 0x1700025D RID: 605
		// (get) Token: 0x0600097E RID: 2430 RVA: 0x0001C185 File Offset: 0x0001A385
		public Display Display
		{
			get
			{
				return Object.GetObject(Screen.gdk_screen_get_display(base.Handle)) as Display;
			}
		}

		// Token: 0x1700025E RID: 606
		// (get) Token: 0x0600097F RID: 2431 RVA: 0x0001C1A1 File Offset: 0x0001A3A1
		[Obsolete]
		public int Height
		{
			get
			{
				return Screen.gdk_screen_get_height(base.Handle);
			}
		}

		// Token: 0x1700025F RID: 607
		// (get) Token: 0x06000980 RID: 2432 RVA: 0x0001C1B3 File Offset: 0x0001A3B3
		[Obsolete]
		public int HeightMm
		{
			get
			{
				return Screen.gdk_screen_get_height_mm(base.Handle);
			}
		}

		// Token: 0x06000981 RID: 2433 RVA: 0x0001C1C5 File Offset: 0x0001A3C5
		[Obsolete]
		public int GetMonitorAtPoint(int x, int y)
		{
			return Screen.gdk_screen_get_monitor_at_point(base.Handle, x, y);
		}

		// Token: 0x06000982 RID: 2434 RVA: 0x0001C1D9 File Offset: 0x0001A3D9
		[Obsolete]
		public int GetMonitorAtWindow(Window window)
		{
			return Screen.gdk_screen_get_monitor_at_window(base.Handle, (window == null) ? IntPtr.Zero : window.Handle);
		}

		// Token: 0x06000983 RID: 2435 RVA: 0x0001C1FC File Offset: 0x0001A3FC
		[Obsolete]
		public Rectangle GetMonitorGeometry(int monitor_num)
		{
			IntPtr intPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(Rectangle)));
			Screen.gdk_screen_get_monitor_geometry(base.Handle, monitor_num, intPtr);
			Rectangle result = (Rectangle)Marshal.PtrToStructure(intPtr, typeof(Rectangle));
			Marshal.FreeHGlobal(intPtr);
			return result;
		}

		// Token: 0x06000984 RID: 2436 RVA: 0x0001C24B File Offset: 0x0001A44B
		[Obsolete]
		public int GetMonitorHeightMm(int monitor_num)
		{
			return Screen.gdk_screen_get_monitor_height_mm(base.Handle, monitor_num);
		}

		// Token: 0x06000985 RID: 2437 RVA: 0x0001C25E File Offset: 0x0001A45E
		[Obsolete]
		public string GetMonitorPlugName(int monitor_num)
		{
			return Marshaller.PtrToStringGFree(Screen.gdk_screen_get_monitor_plug_name(base.Handle, monitor_num));
		}

		// Token: 0x06000986 RID: 2438 RVA: 0x0001C276 File Offset: 0x0001A476
		[Obsolete]
		public int GetMonitorScaleFactor(int monitor_num)
		{
			return Screen.gdk_screen_get_monitor_scale_factor(base.Handle, monitor_num);
		}

		// Token: 0x06000987 RID: 2439 RVA: 0x0001C289 File Offset: 0x0001A489
		[Obsolete]
		public int GetMonitorWidthMm(int monitor_num)
		{
			return Screen.gdk_screen_get_monitor_width_mm(base.Handle, monitor_num);
		}

		// Token: 0x06000988 RID: 2440 RVA: 0x0001C29C File Offset: 0x0001A49C
		[Obsolete]
		public void GetMonitorWorkarea(int monitor_num, Rectangle dest)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(dest);
			Screen.gdk_screen_get_monitor_workarea(base.Handle, monitor_num, intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x17000260 RID: 608
		// (get) Token: 0x06000989 RID: 2441 RVA: 0x0001C2CD File Offset: 0x0001A4CD
		[Obsolete]
		public int NMonitors
		{
			get
			{
				return Screen.gdk_screen_get_n_monitors(base.Handle);
			}
		}

		// Token: 0x17000261 RID: 609
		// (get) Token: 0x0600098A RID: 2442 RVA: 0x0001C2DF File Offset: 0x0001A4DF
		[Obsolete]
		public int Number
		{
			get
			{
				return Screen.gdk_screen_get_number(base.Handle);
			}
		}

		// Token: 0x17000262 RID: 610
		// (get) Token: 0x0600098B RID: 2443 RVA: 0x0001C2F1 File Offset: 0x0001A4F1
		[Obsolete]
		public int PrimaryMonitor
		{
			get
			{
				return Screen.gdk_screen_get_primary_monitor(base.Handle);
			}
		}

		// Token: 0x17000263 RID: 611
		// (get) Token: 0x0600098C RID: 2444 RVA: 0x0001C303 File Offset: 0x0001A503
		// (set) Token: 0x0600098D RID: 2445 RVA: 0x0001C315 File Offset: 0x0001A515
		public double Resolution
		{
			get
			{
				return Screen.gdk_screen_get_resolution(base.Handle);
			}
			set
			{
				Screen.gdk_screen_set_resolution(base.Handle, value);
			}
		}

		// Token: 0x17000264 RID: 612
		// (get) Token: 0x0600098E RID: 2446 RVA: 0x0001C328 File Offset: 0x0001A528
		public Visual RgbaVisual
		{
			get
			{
				return Object.GetObject(Screen.gdk_screen_get_rgba_visual(base.Handle)) as Visual;
			}
		}

		// Token: 0x17000265 RID: 613
		// (get) Token: 0x0600098F RID: 2447 RVA: 0x0001C344 File Offset: 0x0001A544
		public Window RootWindow
		{
			get
			{
				return Object.GetObject(Screen.gdk_screen_get_root_window(base.Handle)) as Window;
			}
		}

		// Token: 0x06000990 RID: 2448 RVA: 0x0001C360 File Offset: 0x0001A560
		public bool GetSetting(string name, Value value)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(name);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(value);
			bool result = Screen.gdk_screen_get_setting(base.Handle, intPtr, intPtr2);
			Marshaller.Free(intPtr);
			Marshal.FreeHGlobal(intPtr2);
			return result;
		}

		// Token: 0x17000266 RID: 614
		// (get) Token: 0x06000991 RID: 2449 RVA: 0x0001C39E File Offset: 0x0001A59E
		public Visual SystemVisual
		{
			get
			{
				return Object.GetObject(Screen.gdk_screen_get_system_visual(base.Handle)) as Visual;
			}
		}

		// Token: 0x17000267 RID: 615
		// (get) Token: 0x06000992 RID: 2450 RVA: 0x0001C3BC File Offset: 0x0001A5BC
		public new static GType GType
		{
			get
			{
				IntPtr val = Screen.gdk_screen_get_type();
				return new GType(val);
			}
		}

		// Token: 0x17000268 RID: 616
		// (get) Token: 0x06000993 RID: 2451 RVA: 0x0001C3DA File Offset: 0x0001A5DA
		[Obsolete]
		public int Width
		{
			get
			{
				return Screen.gdk_screen_get_width(base.Handle);
			}
		}

		// Token: 0x17000269 RID: 617
		// (get) Token: 0x06000994 RID: 2452 RVA: 0x0001C3EC File Offset: 0x0001A5EC
		[Obsolete]
		public int WidthMm
		{
			get
			{
				return Screen.gdk_screen_get_width_mm(base.Handle);
			}
		}

		// Token: 0x1700026A RID: 618
		// (get) Token: 0x06000995 RID: 2453 RVA: 0x0001C3FE File Offset: 0x0001A5FE
		public Window[] WindowStack
		{
			get
			{
				return (Window[])Marshaller.ListPtrToArray(Screen.gdk_screen_get_window_stack(base.Handle), typeof(List), true, true, typeof(Window));
			}
		}

		// Token: 0x1700026B RID: 619
		// (get) Token: 0x06000996 RID: 2454 RVA: 0x0001C430 File Offset: 0x0001A630
		public bool IsComposited
		{
			get
			{
				return Screen.gdk_screen_is_composited(base.Handle);
			}
		}

		// Token: 0x06000997 RID: 2455 RVA: 0x0001C442 File Offset: 0x0001A642
		[Obsolete]
		public string MakeDisplayName()
		{
			return Marshaller.PtrToStringGFree(Screen.gdk_screen_make_display_name(base.Handle));
		}

		// Token: 0x1700026C RID: 620
		// (get) Token: 0x06000998 RID: 2456 RVA: 0x0001C459 File Offset: 0x0001A659
		public new static AbiStruct abi_info
		{
			get
			{
				if (Screen._abi_info == null)
				{
					Screen._abi_info = new AbiStruct(Object.abi_info.Fields);
				}
				return Screen._abi_info;
			}
		}

		// Token: 0x1700026D RID: 621
		// (get) Token: 0x06000999 RID: 2457 RVA: 0x0001C47C File Offset: 0x0001A67C
		public Window[] ToplevelWindows
		{
			get
			{
				IntPtr intPtr = Screen.gdk_screen_get_toplevel_windows(base.Handle);
				if (intPtr == IntPtr.Zero)
				{
					return new Window[0];
				}
				List list = new List(intPtr);
				Window[] array = new Window[list.Count];
				for (int i = 0; i < list.Count; i++)
				{
					array[i] = (list[i] as Window);
				}
				return array;
			}
		}

		// Token: 0x0600099A RID: 2458 RVA: 0x0001C4E4 File Offset: 0x0001A6E4
		public Visual[] ListVisuals()
		{
			IntPtr intPtr = Screen.gdk_screen_list_visuals(base.Handle);
			if (intPtr == IntPtr.Zero)
			{
				return new Visual[0];
			}
			List list = new List(intPtr);
			Visual[] array = new Visual[list.Count];
			for (int i = 0; i < list.Count; i++)
			{
				array[i] = (list[i] as Visual);
			}
			return array;
		}

		// Token: 0x1700026E RID: 622
		// (get) Token: 0x0600099B RID: 2459 RVA: 0x0001C54C File Offset: 0x0001A74C
		// (set) Token: 0x0600099C RID: 2460 RVA: 0x0001C5A5 File Offset: 0x0001A7A5
		[Property("font-options")]
		public FontOptions FontOptions
		{
			get
			{
				IntPtr intPtr = Screen.gdk_screen_get_font_options(base.Handle);
				if (intPtr == IntPtr.Zero)
				{
					return null;
				}
				BindingFlags bindingAttr = BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.CreateInstance;
				return Activator.CreateInstance(typeof(FontOptions), bindingAttr, null, new object[]
				{
					intPtr
				}, null) as FontOptions;
			}
			set
			{
				Screen.gdk_screen_set_font_options(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x040004FC RID: 1276
		private static Screen.GetDisplayNativeDelegate GetDisplay_cb_delegate;

		// Token: 0x040004FD RID: 1277
		private static Screen.GetWidthNativeDelegate GetWidth_cb_delegate;

		// Token: 0x040004FE RID: 1278
		private static Screen.GetHeightNativeDelegate GetHeight_cb_delegate;

		// Token: 0x040004FF RID: 1279
		private static Screen.GetWidthMmNativeDelegate GetWidthMm_cb_delegate;

		// Token: 0x04000500 RID: 1280
		private static Screen.GetHeightMmNativeDelegate GetHeightMm_cb_delegate;

		// Token: 0x04000501 RID: 1281
		private static Screen.GetNumberNativeDelegate GetNumber_cb_delegate;

		// Token: 0x04000502 RID: 1282
		private static Screen.GetRootWindowNativeDelegate GetRootWindow_cb_delegate;

		// Token: 0x04000503 RID: 1283
		private static Screen.GetNMonitorsNativeDelegate GetNMonitors_cb_delegate;

		// Token: 0x04000504 RID: 1284
		private static Screen.GetPrimaryMonitorNativeDelegate GetPrimaryMonitor_cb_delegate;

		// Token: 0x04000505 RID: 1285
		private static Screen.GetMonitorWidthMmNativeDelegate GetMonitorWidthMm_cb_delegate;

		// Token: 0x04000506 RID: 1286
		private static Screen.GetMonitorHeightMmNativeDelegate GetMonitorHeightMm_cb_delegate;

		// Token: 0x04000507 RID: 1287
		private static Screen.GetMonitorPlugNameNativeDelegate GetMonitorPlugName_cb_delegate;

		// Token: 0x04000508 RID: 1288
		private static Screen.GetMonitorGeometryNativeDelegate GetMonitorGeometry_cb_delegate;

		// Token: 0x04000509 RID: 1289
		private static Screen.GetMonitorWorkareaNativeDelegate GetMonitorWorkarea_cb_delegate;

		// Token: 0x0400050A RID: 1290
		private static Screen.ListVisualsNativeDelegate ListVisuals_cb_delegate;

		// Token: 0x0400050B RID: 1291
		private static Screen.GetSystemVisualNativeDelegate GetSystemVisual_cb_delegate;

		// Token: 0x0400050C RID: 1292
		private static Screen.GetRgbaVisualNativeDelegate GetRgbaVisual_cb_delegate;

		// Token: 0x0400050D RID: 1293
		private static Screen.IsCompositedNativeDelegate IsComposited_cb_delegate;

		// Token: 0x0400050E RID: 1294
		private static Screen.MakeDisplayNameNativeDelegate MakeDisplayName_cb_delegate;

		// Token: 0x0400050F RID: 1295
		private static Screen.GetActiveWindowNativeDelegate GetActiveWindow_cb_delegate;

		// Token: 0x04000510 RID: 1296
		private static Screen.GetWindowStackNativeDelegate GetWindowStack_cb_delegate;

		// Token: 0x04000511 RID: 1297
		private static Screen.BroadcastClientMessageNativeDelegate BroadcastClientMessage_cb_delegate;

		// Token: 0x04000512 RID: 1298
		private static Screen.GetSettingNativeDelegate GetSetting_cb_delegate;

		// Token: 0x04000513 RID: 1299
		private static Screen.VisualGetBestDepthNativeDelegate VisualGetBestDepth_cb_delegate;

		// Token: 0x04000514 RID: 1300
		private static Screen.VisualGetBestTypeNativeDelegate VisualGetBestType_cb_delegate;

		// Token: 0x04000515 RID: 1301
		private static Screen.VisualGetBestNativeDelegate VisualGetBest_cb_delegate;

		// Token: 0x04000516 RID: 1302
		private static Screen.VisualGetBestWithDepthNativeDelegate VisualGetBestWithDepth_cb_delegate;

		// Token: 0x04000517 RID: 1303
		private static Screen.VisualGetBestWithTypeNativeDelegate VisualGetBestWithType_cb_delegate;

		// Token: 0x04000518 RID: 1304
		private static Screen.VisualGetBestWithBothNativeDelegate VisualGetBestWithBoth_cb_delegate;

		// Token: 0x04000519 RID: 1305
		private static Screen.QueryDepthsNativeDelegate QueryDepths_cb_delegate;

		// Token: 0x0400051A RID: 1306
		private static Screen.QueryVisualTypesNativeDelegate QueryVisualTypes_cb_delegate;

		// Token: 0x0400051B RID: 1307
		private static Screen.GetMonitorScaleFactorNativeDelegate GetMonitorScaleFactor_cb_delegate;

		// Token: 0x0400051C RID: 1308
		private static AbiStruct _class_abi = null;

		// Token: 0x0400051D RID: 1309
		private static Screen.d_gdk_screen_get_active_window gdk_screen_get_active_window = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_active_window>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_active_window"));

		// Token: 0x0400051E RID: 1310
		private static Screen.d_gdk_screen_get_default gdk_screen_get_default = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_default>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_default"));

		// Token: 0x0400051F RID: 1311
		private static Screen.d_gdk_screen_get_display gdk_screen_get_display = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_display>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_display"));

		// Token: 0x04000520 RID: 1312
		private static Screen.d_gdk_screen_get_height gdk_screen_get_height = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_height>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_height"));

		// Token: 0x04000521 RID: 1313
		private static Screen.d_gdk_screen_get_height_mm gdk_screen_get_height_mm = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_height_mm>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_height_mm"));

		// Token: 0x04000522 RID: 1314
		private static Screen.d_gdk_screen_get_monitor_at_point gdk_screen_get_monitor_at_point = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_monitor_at_point>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_monitor_at_point"));

		// Token: 0x04000523 RID: 1315
		private static Screen.d_gdk_screen_get_monitor_at_window gdk_screen_get_monitor_at_window = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_monitor_at_window>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_monitor_at_window"));

		// Token: 0x04000524 RID: 1316
		private static Screen.d_gdk_screen_get_monitor_geometry gdk_screen_get_monitor_geometry = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_monitor_geometry>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_monitor_geometry"));

		// Token: 0x04000525 RID: 1317
		private static Screen.d_gdk_screen_get_monitor_height_mm gdk_screen_get_monitor_height_mm = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_monitor_height_mm>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_monitor_height_mm"));

		// Token: 0x04000526 RID: 1318
		private static Screen.d_gdk_screen_get_monitor_plug_name gdk_screen_get_monitor_plug_name = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_monitor_plug_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_monitor_plug_name"));

		// Token: 0x04000527 RID: 1319
		private static Screen.d_gdk_screen_get_monitor_scale_factor gdk_screen_get_monitor_scale_factor = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_monitor_scale_factor>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_monitor_scale_factor"));

		// Token: 0x04000528 RID: 1320
		private static Screen.d_gdk_screen_get_monitor_width_mm gdk_screen_get_monitor_width_mm = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_monitor_width_mm>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_monitor_width_mm"));

		// Token: 0x04000529 RID: 1321
		private static Screen.d_gdk_screen_get_monitor_workarea gdk_screen_get_monitor_workarea = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_monitor_workarea>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_monitor_workarea"));

		// Token: 0x0400052A RID: 1322
		private static Screen.d_gdk_screen_get_n_monitors gdk_screen_get_n_monitors = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_n_monitors>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_n_monitors"));

		// Token: 0x0400052B RID: 1323
		private static Screen.d_gdk_screen_get_number gdk_screen_get_number = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_number>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_number"));

		// Token: 0x0400052C RID: 1324
		private static Screen.d_gdk_screen_get_primary_monitor gdk_screen_get_primary_monitor = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_primary_monitor>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_primary_monitor"));

		// Token: 0x0400052D RID: 1325
		private static Screen.d_gdk_screen_get_resolution gdk_screen_get_resolution = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_resolution>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_resolution"));

		// Token: 0x0400052E RID: 1326
		private static Screen.d_gdk_screen_set_resolution gdk_screen_set_resolution = FuncLoader.LoadFunction<Screen.d_gdk_screen_set_resolution>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_set_resolution"));

		// Token: 0x0400052F RID: 1327
		private static Screen.d_gdk_screen_get_rgba_visual gdk_screen_get_rgba_visual = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_rgba_visual>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_rgba_visual"));

		// Token: 0x04000530 RID: 1328
		private static Screen.d_gdk_screen_get_root_window gdk_screen_get_root_window = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_root_window>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_root_window"));

		// Token: 0x04000531 RID: 1329
		private static Screen.d_gdk_screen_get_setting gdk_screen_get_setting = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_setting>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_setting"));

		// Token: 0x04000532 RID: 1330
		private static Screen.d_gdk_screen_get_system_visual gdk_screen_get_system_visual = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_system_visual>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_system_visual"));

		// Token: 0x04000533 RID: 1331
		private static Screen.d_gdk_screen_get_type gdk_screen_get_type = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_type"));

		// Token: 0x04000534 RID: 1332
		private static Screen.d_gdk_screen_get_width gdk_screen_get_width = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_width>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_width"));

		// Token: 0x04000535 RID: 1333
		private static Screen.d_gdk_screen_get_width_mm gdk_screen_get_width_mm = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_width_mm>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_width_mm"));

		// Token: 0x04000536 RID: 1334
		private static Screen.d_gdk_screen_get_window_stack gdk_screen_get_window_stack = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_window_stack>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_window_stack"));

		// Token: 0x04000537 RID: 1335
		private static Screen.d_gdk_screen_is_composited gdk_screen_is_composited = FuncLoader.LoadFunction<Screen.d_gdk_screen_is_composited>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_is_composited"));

		// Token: 0x04000538 RID: 1336
		private static Screen.d_gdk_screen_make_display_name gdk_screen_make_display_name = FuncLoader.LoadFunction<Screen.d_gdk_screen_make_display_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_make_display_name"));

		// Token: 0x04000539 RID: 1337
		private static AbiStruct _abi_info = null;

		// Token: 0x0400053A RID: 1338
		private static Screen.d_gdk_screen_get_toplevel_windows gdk_screen_get_toplevel_windows = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_toplevel_windows>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_toplevel_windows"));

		// Token: 0x0400053B RID: 1339
		private static Screen.d_gdk_screen_list_visuals gdk_screen_list_visuals = FuncLoader.LoadFunction<Screen.d_gdk_screen_list_visuals>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_list_visuals"));

		// Token: 0x0400053C RID: 1340
		private static Screen.d_gdk_screen_get_font_options gdk_screen_get_font_options = FuncLoader.LoadFunction<Screen.d_gdk_screen_get_font_options>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_get_font_options"));

		// Token: 0x0400053D RID: 1341
		private static Screen.d_gdk_screen_set_font_options gdk_screen_set_font_options = FuncLoader.LoadFunction<Screen.d_gdk_screen_set_font_options>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_screen_set_font_options"));

		// Token: 0x020003B0 RID: 944
		// (Invoke) Token: 0x06001542 RID: 5442
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetDisplayNativeDelegate(IntPtr inst);

		// Token: 0x020003B1 RID: 945
		// (Invoke) Token: 0x06001546 RID: 5446
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetWidthNativeDelegate(IntPtr inst);

		// Token: 0x020003B2 RID: 946
		// (Invoke) Token: 0x0600154A RID: 5450
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetHeightNativeDelegate(IntPtr inst);

		// Token: 0x020003B3 RID: 947
		// (Invoke) Token: 0x0600154E RID: 5454
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetWidthMmNativeDelegate(IntPtr inst);

		// Token: 0x020003B4 RID: 948
		// (Invoke) Token: 0x06001552 RID: 5458
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetHeightMmNativeDelegate(IntPtr inst);

		// Token: 0x020003B5 RID: 949
		// (Invoke) Token: 0x06001556 RID: 5462
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetNumberNativeDelegate(IntPtr inst);

		// Token: 0x020003B6 RID: 950
		// (Invoke) Token: 0x0600155A RID: 5466
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetRootWindowNativeDelegate(IntPtr inst);

		// Token: 0x020003B7 RID: 951
		// (Invoke) Token: 0x0600155E RID: 5470
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetNMonitorsNativeDelegate(IntPtr inst);

		// Token: 0x020003B8 RID: 952
		// (Invoke) Token: 0x06001562 RID: 5474
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetPrimaryMonitorNativeDelegate(IntPtr inst);

		// Token: 0x020003B9 RID: 953
		// (Invoke) Token: 0x06001566 RID: 5478
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetMonitorWidthMmNativeDelegate(IntPtr inst, int monitor_num);

		// Token: 0x020003BA RID: 954
		// (Invoke) Token: 0x0600156A RID: 5482
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetMonitorHeightMmNativeDelegate(IntPtr inst, int monitor_num);

		// Token: 0x020003BB RID: 955
		// (Invoke) Token: 0x0600156E RID: 5486
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetMonitorPlugNameNativeDelegate(IntPtr inst, int monitor_num);

		// Token: 0x020003BC RID: 956
		// (Invoke) Token: 0x06001572 RID: 5490
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void GetMonitorGeometryNativeDelegate(IntPtr inst, int monitor_num, IntPtr dest);

		// Token: 0x020003BD RID: 957
		// (Invoke) Token: 0x06001576 RID: 5494
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void GetMonitorWorkareaNativeDelegate(IntPtr inst, int monitor_num, IntPtr dest);

		// Token: 0x020003BE RID: 958
		// (Invoke) Token: 0x0600157A RID: 5498
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr ListVisualsNativeDelegate(IntPtr inst);

		// Token: 0x020003BF RID: 959
		// (Invoke) Token: 0x0600157E RID: 5502
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetSystemVisualNativeDelegate(IntPtr inst);

		// Token: 0x020003C0 RID: 960
		// (Invoke) Token: 0x06001582 RID: 5506
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetRgbaVisualNativeDelegate(IntPtr inst);

		// Token: 0x020003C1 RID: 961
		// (Invoke) Token: 0x06001586 RID: 5510
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool IsCompositedNativeDelegate(IntPtr inst);

		// Token: 0x020003C2 RID: 962
		// (Invoke) Token: 0x0600158A RID: 5514
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr MakeDisplayNameNativeDelegate(IntPtr inst);

		// Token: 0x020003C3 RID: 963
		// (Invoke) Token: 0x0600158E RID: 5518
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetActiveWindowNativeDelegate(IntPtr inst);

		// Token: 0x020003C4 RID: 964
		// (Invoke) Token: 0x06001592 RID: 5522
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetWindowStackNativeDelegate(IntPtr inst);

		// Token: 0x020003C5 RID: 965
		// (Invoke) Token: 0x06001596 RID: 5526
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void BroadcastClientMessageNativeDelegate(IntPtr inst, IntPtr evnt);

		// Token: 0x020003C6 RID: 966
		// (Invoke) Token: 0x0600159A RID: 5530
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool GetSettingNativeDelegate(IntPtr inst, IntPtr name, IntPtr value);

		// Token: 0x020003C7 RID: 967
		// (Invoke) Token: 0x0600159E RID: 5534
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int VisualGetBestDepthNativeDelegate(IntPtr inst);

		// Token: 0x020003C8 RID: 968
		// (Invoke) Token: 0x060015A2 RID: 5538
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int VisualGetBestTypeNativeDelegate(IntPtr inst);

		// Token: 0x020003C9 RID: 969
		// (Invoke) Token: 0x060015A6 RID: 5542
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr VisualGetBestNativeDelegate(IntPtr inst);

		// Token: 0x020003CA RID: 970
		// (Invoke) Token: 0x060015AA RID: 5546
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr VisualGetBestWithDepthNativeDelegate(IntPtr inst, int depth);

		// Token: 0x020003CB RID: 971
		// (Invoke) Token: 0x060015AE RID: 5550
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr VisualGetBestWithTypeNativeDelegate(IntPtr inst, int visual_type);

		// Token: 0x020003CC RID: 972
		// (Invoke) Token: 0x060015B2 RID: 5554
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr VisualGetBestWithBothNativeDelegate(IntPtr inst, int depth, int visual_type);

		// Token: 0x020003CD RID: 973
		// (Invoke) Token: 0x060015B6 RID: 5558
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void QueryDepthsNativeDelegate(IntPtr inst, out int depths, out int count);

		// Token: 0x020003CE RID: 974
		// (Invoke) Token: 0x060015BA RID: 5562
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void QueryVisualTypesNativeDelegate(IntPtr inst, out int visual_types, out int count);

		// Token: 0x020003CF RID: 975
		// (Invoke) Token: 0x060015BE RID: 5566
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetMonitorScaleFactorNativeDelegate(IntPtr inst, int monitor_num);

		// Token: 0x020003D0 RID: 976
		// (Invoke) Token: 0x060015C2 RID: 5570
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_screen_get_active_window(IntPtr raw);

		// Token: 0x020003D1 RID: 977
		// (Invoke) Token: 0x060015C6 RID: 5574
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_screen_get_default();

		// Token: 0x020003D2 RID: 978
		// (Invoke) Token: 0x060015CA RID: 5578
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_screen_get_display(IntPtr raw);

		// Token: 0x020003D3 RID: 979
		// (Invoke) Token: 0x060015CE RID: 5582
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_screen_get_height(IntPtr raw);

		// Token: 0x020003D4 RID: 980
		// (Invoke) Token: 0x060015D2 RID: 5586
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_screen_get_height_mm(IntPtr raw);

		// Token: 0x020003D5 RID: 981
		// (Invoke) Token: 0x060015D6 RID: 5590
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_screen_get_monitor_at_point(IntPtr raw, int x, int y);

		// Token: 0x020003D6 RID: 982
		// (Invoke) Token: 0x060015DA RID: 5594
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_screen_get_monitor_at_window(IntPtr raw, IntPtr window);

		// Token: 0x020003D7 RID: 983
		// (Invoke) Token: 0x060015DE RID: 5598
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_screen_get_monitor_geometry(IntPtr raw, int monitor_num, IntPtr dest);

		// Token: 0x020003D8 RID: 984
		// (Invoke) Token: 0x060015E2 RID: 5602
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_screen_get_monitor_height_mm(IntPtr raw, int monitor_num);

		// Token: 0x020003D9 RID: 985
		// (Invoke) Token: 0x060015E6 RID: 5606
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_screen_get_monitor_plug_name(IntPtr raw, int monitor_num);

		// Token: 0x020003DA RID: 986
		// (Invoke) Token: 0x060015EA RID: 5610
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_screen_get_monitor_scale_factor(IntPtr raw, int monitor_num);

		// Token: 0x020003DB RID: 987
		// (Invoke) Token: 0x060015EE RID: 5614
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_screen_get_monitor_width_mm(IntPtr raw, int monitor_num);

		// Token: 0x020003DC RID: 988
		// (Invoke) Token: 0x060015F2 RID: 5618
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_screen_get_monitor_workarea(IntPtr raw, int monitor_num, IntPtr dest);

		// Token: 0x020003DD RID: 989
		// (Invoke) Token: 0x060015F6 RID: 5622
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_screen_get_n_monitors(IntPtr raw);

		// Token: 0x020003DE RID: 990
		// (Invoke) Token: 0x060015FA RID: 5626
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_screen_get_number(IntPtr raw);

		// Token: 0x020003DF RID: 991
		// (Invoke) Token: 0x060015FE RID: 5630
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_screen_get_primary_monitor(IntPtr raw);

		// Token: 0x020003E0 RID: 992
		// (Invoke) Token: 0x06001602 RID: 5634
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate double d_gdk_screen_get_resolution(IntPtr raw);

		// Token: 0x020003E1 RID: 993
		// (Invoke) Token: 0x06001606 RID: 5638
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_screen_set_resolution(IntPtr raw, double dpi);

		// Token: 0x020003E2 RID: 994
		// (Invoke) Token: 0x0600160A RID: 5642
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_screen_get_rgba_visual(IntPtr raw);

		// Token: 0x020003E3 RID: 995
		// (Invoke) Token: 0x0600160E RID: 5646
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_screen_get_root_window(IntPtr raw);

		// Token: 0x020003E4 RID: 996
		// (Invoke) Token: 0x06001612 RID: 5650
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_screen_get_setting(IntPtr raw, IntPtr name, IntPtr value);

		// Token: 0x020003E5 RID: 997
		// (Invoke) Token: 0x06001616 RID: 5654
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_screen_get_system_visual(IntPtr raw);

		// Token: 0x020003E6 RID: 998
		// (Invoke) Token: 0x0600161A RID: 5658
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_screen_get_type();

		// Token: 0x020003E7 RID: 999
		// (Invoke) Token: 0x0600161E RID: 5662
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_screen_get_width(IntPtr raw);

		// Token: 0x020003E8 RID: 1000
		// (Invoke) Token: 0x06001622 RID: 5666
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_screen_get_width_mm(IntPtr raw);

		// Token: 0x020003E9 RID: 1001
		// (Invoke) Token: 0x06001626 RID: 5670
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_screen_get_window_stack(IntPtr raw);

		// Token: 0x020003EA RID: 1002
		// (Invoke) Token: 0x0600162A RID: 5674
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_screen_is_composited(IntPtr raw);

		// Token: 0x020003EB RID: 1003
		// (Invoke) Token: 0x0600162E RID: 5678
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_screen_make_display_name(IntPtr raw);

		// Token: 0x020003EC RID: 1004
		// (Invoke) Token: 0x06001632 RID: 5682
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_screen_get_toplevel_windows(IntPtr raw);

		// Token: 0x020003ED RID: 1005
		// (Invoke) Token: 0x06001636 RID: 5686
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_screen_list_visuals(IntPtr raw);

		// Token: 0x020003EE RID: 1006
		// (Invoke) Token: 0x0600163A RID: 5690
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_screen_get_font_options(IntPtr raw);

		// Token: 0x020003EF RID: 1007
		// (Invoke) Token: 0x0600163E RID: 5694
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_screen_set_font_options(IntPtr raw, IntPtr options);
	}
}
