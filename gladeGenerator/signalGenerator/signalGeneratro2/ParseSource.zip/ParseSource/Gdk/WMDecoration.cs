﻿using System;

namespace Gdk
{
	// Token: 0x02000129 RID: 297
	[Flags]
	public enum WMDecoration
	{
		// Token: 0x040006B6 RID: 1718
		All = 1,
		// Token: 0x040006B7 RID: 1719
		Border = 2,
		// Token: 0x040006B8 RID: 1720
		Resizeh = 4,
		// Token: 0x040006B9 RID: 1721
		Title = 8,
		// Token: 0x040006BA RID: 1722
		Menu = 16,
		// Token: 0x040006BB RID: 1723
		Minimize = 32,
		// Token: 0x040006BC RID: 1724
		Maximize = 64
	}
}
