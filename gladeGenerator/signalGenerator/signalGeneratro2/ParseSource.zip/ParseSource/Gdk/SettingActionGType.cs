﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000FA RID: 250
	internal class SettingActionGType
	{
		// Token: 0x17000285 RID: 645
		// (get) Token: 0x06000A04 RID: 2564 RVA: 0x0001DA9C File Offset: 0x0001BC9C
		public static GType GType
		{
			get
			{
				return new GType(SettingActionGType.gdk_setting_action_get_type());
			}
		}

		// Token: 0x04000571 RID: 1393
		private static SettingActionGType.d_gdk_setting_action_get_type gdk_setting_action_get_type = FuncLoader.LoadFunction<SettingActionGType.d_gdk_setting_action_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_setting_action_get_type"));

		// Token: 0x0200040A RID: 1034
		// (Invoke) Token: 0x060016AA RID: 5802
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_setting_action_get_type();
	}
}
