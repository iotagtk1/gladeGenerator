﻿using System;

namespace Gdk
{
	// Token: 0x020000D9 RID: 217
	// (Invoke) Token: 0x0600085F RID: 2143
	public delegate bool PixbufSaveFunc(string buf, ulong count);
}
