﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Cairo;
using GLib;

namespace Gdk
{
	// Token: 0x02000054 RID: 84
	public class Cursor : Object
	{
		// Token: 0x060003CA RID: 970 RVA: 0x0000BE0D File Offset: 0x0000A00D
		public Cursor(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x060003CB RID: 971 RVA: 0x0000BE18 File Offset: 0x0000A018
		public Cursor(CursorType cursor_type) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Cursor))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				list2.Add("cursor_type");
				list.Add(new Value(cursor_type));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			this.Raw = Cursor.gdk_cursor_new((int)cursor_type);
		}

		// Token: 0x060003CC RID: 972 RVA: 0x0000BE94 File Offset: 0x0000A094
		public Cursor(Display display, CursorType cursor_type) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Cursor))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				if (display != null)
				{
					list2.Add("display");
					list.Add(new Value(display));
				}
				list2.Add("cursor_type");
				list.Add(new Value(cursor_type));
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			this.Raw = Cursor.gdk_cursor_new_for_display((display == null) ? IntPtr.Zero : display.Handle, (int)cursor_type);
		}

		// Token: 0x060003CD RID: 973 RVA: 0x0000BF3C File Offset: 0x0000A13C
		public Cursor(Display display, string name) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Cursor))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				if (display != null)
				{
					list2.Add("display");
					list.Add(new Value(display));
				}
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(name);
			this.Raw = Cursor.gdk_cursor_new_from_name((display == null) ? IntPtr.Zero : display.Handle, intPtr);
			Marshaller.Free(intPtr);
		}

		// Token: 0x060003CE RID: 974 RVA: 0x0000BFD4 File Offset: 0x0000A1D4
		public Cursor(Display display, Pixbuf pixbuf, int x, int y) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Cursor))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				if (display != null)
				{
					list2.Add("display");
					list.Add(new Value(display));
				}
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			this.Raw = Cursor.gdk_cursor_new_from_pixbuf((display == null) ? IntPtr.Zero : display.Handle, (pixbuf == null) ? IntPtr.Zero : pixbuf.Handle, x, y);
		}

		// Token: 0x060003CF RID: 975 RVA: 0x0000C070 File Offset: 0x0000A270
		public Cursor(Display display, Surface surface, double x, double y) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(Cursor))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				if (display != null)
				{
					list2.Add("display");
					list.Add(new Value(display));
				}
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			this.Raw = Cursor.gdk_cursor_new_from_surface((display == null) ? IntPtr.Zero : display.Handle, surface.Handle, x, y);
		}

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x060003D0 RID: 976 RVA: 0x0000C101 File Offset: 0x0000A301
		[Property("cursor-type")]
		public CursorType CursorType
		{
			get
			{
				return (CursorType)Cursor.gdk_cursor_get_cursor_type(base.Handle);
			}
		}

		// Token: 0x17000101 RID: 257
		// (get) Token: 0x060003D1 RID: 977 RVA: 0x0000C113 File Offset: 0x0000A313
		[Property("display")]
		public Display Display
		{
			get
			{
				return Object.GetObject(Cursor.gdk_cursor_get_display(base.Handle)) as Display;
			}
		}

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x060003D2 RID: 978 RVA: 0x0000C12F File Offset: 0x0000A32F
		private static Cursor.GetSurfaceNativeDelegate GetSurfaceVMCallback
		{
			get
			{
				if (Cursor.GetSurface_cb_delegate == null)
				{
					Cursor.GetSurface_cb_delegate = new Cursor.GetSurfaceNativeDelegate(Cursor.GetSurface_cb);
				}
				return Cursor.GetSurface_cb_delegate;
			}
		}

		// Token: 0x060003D3 RID: 979 RVA: 0x0000C14E File Offset: 0x0000A34E
		private static void OverrideGetSurface(GType gtype)
		{
			Cursor.OverrideGetSurface(gtype, Cursor.GetSurfaceVMCallback);
		}

		// Token: 0x060003D4 RID: 980 RVA: 0x0000C15C File Offset: 0x0000A35C
		private unsafe static void OverrideGetSurface(GType gtype, Cursor.GetSurfaceNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Cursor.class_abi.GetFieldOffset("get_surface");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060003D5 RID: 981 RVA: 0x0000C190 File Offset: 0x0000A390
		private static IntPtr GetSurface_cb(IntPtr inst, out double x_hot, out double y_hot)
		{
			IntPtr handle;
			try
			{
				handle = (Object.GetObject(inst, false) as Cursor).OnGetSurface(out x_hot, out y_hot).Handle;
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return handle;
		}

		// Token: 0x060003D6 RID: 982 RVA: 0x0000C1D4 File Offset: 0x0000A3D4
		[DefaultSignalHandler(Type = typeof(Cursor), ConnectionMethod = "OverrideGetSurface")]
		protected virtual Surface OnGetSurface(out double x_hot, out double y_hot)
		{
			return this.InternalGetSurface(out x_hot, out y_hot);
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x0000C1DE File Offset: 0x0000A3DE
		private Surface InternalGetSurface(out double x_hot, out double y_hot)
		{
			Cursor.GetSurfaceNativeDelegate getSurfaceNativeDelegate = Cursor.class_abi.BaseOverride(base.LookupGType(), "get_surface");
			if (getSurfaceNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			return Surface.Lookup(getSurfaceNativeDelegate(base.Handle, out x_hot, out y_hot), true);
		}

		// Token: 0x17000103 RID: 259
		// (get) Token: 0x060003D8 RID: 984 RVA: 0x0000C218 File Offset: 0x0000A418
		public new static AbiStruct class_abi
		{
			get
			{
				if (Cursor._class_abi == null)
				{
					Cursor._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("get_surface", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Cursor._class_abi;
			}
		}

		// Token: 0x17000104 RID: 260
		// (get) Token: 0x060003D9 RID: 985 RVA: 0x0000C27C File Offset: 0x0000A47C
		public Pixbuf Image
		{
			get
			{
				return Object.GetObject(Cursor.gdk_cursor_get_image(base.Handle)) as Pixbuf;
			}
		}

		// Token: 0x060003DA RID: 986 RVA: 0x0000C298 File Offset: 0x0000A498
		public Surface GetSurface(out double x_hot, out double y_hot)
		{
			return Surface.Lookup(Cursor.gdk_cursor_get_surface(base.Handle, out x_hot, out y_hot), true);
		}

		// Token: 0x17000105 RID: 261
		// (get) Token: 0x060003DB RID: 987 RVA: 0x0000C2B4 File Offset: 0x0000A4B4
		public new static GType GType
		{
			get
			{
				IntPtr val = Cursor.gdk_cursor_get_type();
				return new GType(val);
			}
		}

		// Token: 0x17000106 RID: 262
		// (get) Token: 0x060003DC RID: 988 RVA: 0x0000C2D2 File Offset: 0x0000A4D2
		public new static AbiStruct abi_info
		{
			get
			{
				if (Cursor._abi_info == null)
				{
					Cursor._abi_info = new AbiStruct(Object.abi_info.Fields);
				}
				return Cursor._abi_info;
			}
		}

		// Token: 0x04000151 RID: 337
		private static Cursor.d_gdk_cursor_new gdk_cursor_new = FuncLoader.LoadFunction<Cursor.d_gdk_cursor_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cursor_new"));

		// Token: 0x04000152 RID: 338
		private static Cursor.d_gdk_cursor_new_for_display gdk_cursor_new_for_display = FuncLoader.LoadFunction<Cursor.d_gdk_cursor_new_for_display>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cursor_new_for_display"));

		// Token: 0x04000153 RID: 339
		private static Cursor.d_gdk_cursor_new_from_name gdk_cursor_new_from_name = FuncLoader.LoadFunction<Cursor.d_gdk_cursor_new_from_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cursor_new_from_name"));

		// Token: 0x04000154 RID: 340
		private static Cursor.d_gdk_cursor_new_from_pixbuf gdk_cursor_new_from_pixbuf = FuncLoader.LoadFunction<Cursor.d_gdk_cursor_new_from_pixbuf>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cursor_new_from_pixbuf"));

		// Token: 0x04000155 RID: 341
		private static Cursor.d_gdk_cursor_new_from_surface gdk_cursor_new_from_surface = FuncLoader.LoadFunction<Cursor.d_gdk_cursor_new_from_surface>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cursor_new_from_surface"));

		// Token: 0x04000156 RID: 342
		private static Cursor.d_gdk_cursor_get_cursor_type gdk_cursor_get_cursor_type = FuncLoader.LoadFunction<Cursor.d_gdk_cursor_get_cursor_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cursor_get_cursor_type"));

		// Token: 0x04000157 RID: 343
		private static Cursor.d_gdk_cursor_get_display gdk_cursor_get_display = FuncLoader.LoadFunction<Cursor.d_gdk_cursor_get_display>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cursor_get_display"));

		// Token: 0x04000158 RID: 344
		private static Cursor.GetSurfaceNativeDelegate GetSurface_cb_delegate;

		// Token: 0x04000159 RID: 345
		private static AbiStruct _class_abi = null;

		// Token: 0x0400015A RID: 346
		private static Cursor.d_gdk_cursor_get_image gdk_cursor_get_image = FuncLoader.LoadFunction<Cursor.d_gdk_cursor_get_image>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cursor_get_image"));

		// Token: 0x0400015B RID: 347
		private static Cursor.d_gdk_cursor_get_surface gdk_cursor_get_surface = FuncLoader.LoadFunction<Cursor.d_gdk_cursor_get_surface>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cursor_get_surface"));

		// Token: 0x0400015C RID: 348
		private static Cursor.d_gdk_cursor_get_type gdk_cursor_get_type = FuncLoader.LoadFunction<Cursor.d_gdk_cursor_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cursor_get_type"));

		// Token: 0x0400015D RID: 349
		private static AbiStruct _abi_info = null;

		// Token: 0x02000204 RID: 516
		// (Invoke) Token: 0x06000E9B RID: 3739
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_cursor_new(int cursor_type);

		// Token: 0x02000205 RID: 517
		// (Invoke) Token: 0x06000E9F RID: 3743
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_cursor_new_for_display(IntPtr display, int cursor_type);

		// Token: 0x02000206 RID: 518
		// (Invoke) Token: 0x06000EA3 RID: 3747
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_cursor_new_from_name(IntPtr display, IntPtr name);

		// Token: 0x02000207 RID: 519
		// (Invoke) Token: 0x06000EA7 RID: 3751
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_cursor_new_from_pixbuf(IntPtr display, IntPtr pixbuf, int x, int y);

		// Token: 0x02000208 RID: 520
		// (Invoke) Token: 0x06000EAB RID: 3755
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_cursor_new_from_surface(IntPtr display, IntPtr surface, double x, double y);

		// Token: 0x02000209 RID: 521
		// (Invoke) Token: 0x06000EAF RID: 3759
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_cursor_get_cursor_type(IntPtr raw);

		// Token: 0x0200020A RID: 522
		// (Invoke) Token: 0x06000EB3 RID: 3763
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_cursor_get_display(IntPtr raw);

		// Token: 0x0200020B RID: 523
		// (Invoke) Token: 0x06000EB7 RID: 3767
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr GetSurfaceNativeDelegate(IntPtr inst, out double x_hot, out double y_hot);

		// Token: 0x0200020C RID: 524
		// (Invoke) Token: 0x06000EBB RID: 3771
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_cursor_get_image(IntPtr raw);

		// Token: 0x0200020D RID: 525
		// (Invoke) Token: 0x06000EBF RID: 3775
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_cursor_get_surface(IntPtr raw, out double x_hot, out double y_hot);

		// Token: 0x0200020E RID: 526
		// (Invoke) Token: 0x06000EC3 RID: 3779
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_cursor_get_type();
	}
}
