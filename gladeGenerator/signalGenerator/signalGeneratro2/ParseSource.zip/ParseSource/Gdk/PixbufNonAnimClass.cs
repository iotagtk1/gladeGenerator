﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x020000D4 RID: 212
	public class PixbufNonAnimClass : Opaque
	{
		// Token: 0x06000855 RID: 2133 RVA: 0x00018C27 File Offset: 0x00016E27
		public PixbufNonAnimClass(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000227 RID: 551
		// (get) Token: 0x06000856 RID: 2134 RVA: 0x00018C30 File Offset: 0x00016E30
		public static AbiStruct abi_info
		{
			get
			{
				if (PixbufNonAnimClass._abi_info == null)
				{
					PixbufNonAnimClass._abi_info = new AbiStruct(new List<AbiField>());
				}
				return PixbufNonAnimClass._abi_info;
			}
		}

		// Token: 0x040004AE RID: 1198
		private static AbiStruct _abi_info;
	}
}
