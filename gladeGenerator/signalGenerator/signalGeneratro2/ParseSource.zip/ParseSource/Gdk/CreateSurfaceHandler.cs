﻿using System;

namespace Gdk
{
	// Token: 0x02000050 RID: 80
	// (Invoke) Token: 0x060003C1 RID: 961
	public delegate void CreateSurfaceHandler(object o, CreateSurfaceArgs args);
}
