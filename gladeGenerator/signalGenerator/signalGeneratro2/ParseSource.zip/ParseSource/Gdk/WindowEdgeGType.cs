﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200011B RID: 283
	internal class WindowEdgeGType
	{
		// Token: 0x170002F0 RID: 752
		// (get) Token: 0x06000B46 RID: 2886 RVA: 0x00021506 File Offset: 0x0001F706
		public static GType GType
		{
			get
			{
				return new GType(WindowEdgeGType.gdk_window_edge_get_type());
			}
		}

		// Token: 0x0400067F RID: 1663
		private static WindowEdgeGType.d_gdk_window_edge_get_type gdk_window_edge_get_type = FuncLoader.LoadFunction<WindowEdgeGType.d_gdk_window_edge_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_edge_get_type"));

		// Token: 0x020004CE RID: 1230
		// (Invoke) Token: 0x060019BA RID: 6586
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_edge_get_type();
	}
}
