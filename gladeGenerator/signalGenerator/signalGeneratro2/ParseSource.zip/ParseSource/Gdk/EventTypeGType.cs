﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000083 RID: 131
	internal class EventTypeGType
	{
		// Token: 0x17000163 RID: 355
		// (get) Token: 0x06000578 RID: 1400 RVA: 0x00010ABA File Offset: 0x0000ECBA
		public static GType GType
		{
			get
			{
				return new GType(EventTypeGType.gdk_event_type_get_type());
			}
		}

		// Token: 0x040002EB RID: 747
		private static EventTypeGType.d_gdk_event_type_get_type gdk_event_type_get_type = FuncLoader.LoadFunction<EventTypeGType.d_gdk_event_type_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_type_get_type"));

		// Token: 0x0200028A RID: 650
		// (Invoke) Token: 0x060010AF RID: 4271
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_event_type_get_type();
	}
}
