﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x020000E4 RID: 228
	public class Predicate : Opaque
	{
		// Token: 0x0600088F RID: 2191 RVA: 0x0001934F File Offset: 0x0001754F
		public Predicate(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x17000236 RID: 566
		// (get) Token: 0x06000890 RID: 2192 RVA: 0x00019358 File Offset: 0x00017558
		public static AbiStruct abi_info
		{
			get
			{
				if (Predicate._abi_info == null)
				{
					Predicate._abi_info = new AbiStruct(new List<AbiField>());
				}
				return Predicate._abi_info;
			}
		}

		// Token: 0x040004E2 RID: 1250
		private static AbiStruct _abi_info;
	}
}
