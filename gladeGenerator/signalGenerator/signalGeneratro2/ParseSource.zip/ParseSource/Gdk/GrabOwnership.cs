﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x02000098 RID: 152
	[GType(typeof(GrabOwnershipGType))]
	public enum GrabOwnership
	{
		// Token: 0x04000364 RID: 868
		None,
		// Token: 0x04000365 RID: 869
		Window,
		// Token: 0x04000366 RID: 870
		Application
	}
}
