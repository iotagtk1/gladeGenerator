﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000DF RID: 223
	[Obsolete]
	public struct Pixdata : IEquatable<Pixdata>
	{
		// Token: 0x06000873 RID: 2163 RVA: 0x00018F08 File Offset: 0x00017108
		public static Pixdata New(IntPtr raw)
		{
			if (raw == IntPtr.Zero)
			{
				return Pixdata.Zero;
			}
			return (Pixdata)Marshal.PtrToStructure(raw, typeof(Pixdata));
		}

		// Token: 0x06000874 RID: 2164 RVA: 0x00018F34 File Offset: 0x00017134
		public bool Equals(Pixdata other)
		{
			return this.Magic.Equals(other.Magic) && this.Length.Equals(other.Length) && this.PixdataType.Equals(other.PixdataType) && this.Rowstride.Equals(other.Rowstride) && this.Width.Equals(other.Width) && this.Height.Equals(other.Height) && this._pixel_data.Equals(other._pixel_data);
		}

		// Token: 0x06000875 RID: 2165 RVA: 0x00018FCB File Offset: 0x000171CB
		public override bool Equals(object other)
		{
			return other is Pixdata && this.Equals((Pixdata)other);
		}

		// Token: 0x06000876 RID: 2166 RVA: 0x00018FE4 File Offset: 0x000171E4
		public override int GetHashCode()
		{
			return base.GetType().FullName.GetHashCode() ^ this.Magic.GetHashCode() ^ this.Length.GetHashCode() ^ this.PixdataType.GetHashCode() ^ this.Rowstride.GetHashCode() ^ this.Width.GetHashCode() ^ this.Height.GetHashCode() ^ this._pixel_data.GetHashCode();
		}

		// Token: 0x17000232 RID: 562
		// (get) Token: 0x06000877 RID: 2167 RVA: 0x0001905F File Offset: 0x0001725F
		private static GType GType
		{
			get
			{
				return GType.Pointer;
			}
		}

		// Token: 0x06000878 RID: 2168 RVA: 0x00019068 File Offset: 0x00017268
		public byte[] Serialize()
		{
			uint num;
			IntPtr intPtr = Pixdata.gdk_pixdata_serialize(ref this, out num);
			byte[] array = new byte[num];
			Marshal.Copy(intPtr, array, 0, (int)num);
			Marshaller.Free(intPtr);
			return array;
		}

		// Token: 0x040004C1 RID: 1217
		public uint Magic;

		// Token: 0x040004C2 RID: 1218
		public int Length;

		// Token: 0x040004C3 RID: 1219
		public uint PixdataType;

		// Token: 0x040004C4 RID: 1220
		public uint Rowstride;

		// Token: 0x040004C5 RID: 1221
		public uint Width;

		// Token: 0x040004C6 RID: 1222
		public uint Height;

		// Token: 0x040004C7 RID: 1223
		private IntPtr _pixel_data;

		// Token: 0x040004C8 RID: 1224
		public static Pixdata Zero = default(Pixdata);

		// Token: 0x040004C9 RID: 1225
		private static Pixdata.d_gdk_pixdata_serialize gdk_pixdata_serialize = FuncLoader.LoadFunction<Pixdata.d_gdk_pixdata_serialize>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixdata_serialize"));

		// Token: 0x0200039F RID: 927
		// (Invoke) Token: 0x060014FE RID: 5374
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixdata_serialize(ref Pixdata raw, out uint len);
	}
}
