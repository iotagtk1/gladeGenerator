﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000063 RID: 99
	internal class DeviceToolTypeGType
	{
		// Token: 0x17000123 RID: 291
		// (get) Token: 0x06000441 RID: 1089 RVA: 0x0000D22D File Offset: 0x0000B42D
		public static GType GType
		{
			get
			{
				return new GType(DeviceToolTypeGType.gdk_device_tool_type_get_type());
			}
		}

		// Token: 0x040001D8 RID: 472
		private static DeviceToolTypeGType.d_gdk_device_tool_type_get_type gdk_device_tool_type_get_type = FuncLoader.LoadFunction<DeviceToolTypeGType.d_gdk_device_tool_type_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_tool_type_get_type"));

		// Token: 0x02000228 RID: 552
		// (Invoke) Token: 0x06000F27 RID: 3879
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_tool_type_get_type();
	}
}
