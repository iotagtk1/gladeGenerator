﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x0200003F RID: 63
	public class ArgDesc : Opaque
	{
		// Token: 0x06000392 RID: 914 RVA: 0x0000B85B File Offset: 0x00009A5B
		public ArgDesc(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x06000393 RID: 915 RVA: 0x0000B864 File Offset: 0x00009A64
		public static AbiStruct abi_info
		{
			get
			{
				if (ArgDesc._abi_info == null)
				{
					ArgDesc._abi_info = new AbiStruct(new List<AbiField>());
				}
				return ArgDesc._abi_info;
			}
		}

		// Token: 0x04000117 RID: 279
		private static AbiStruct _abi_info;
	}
}
