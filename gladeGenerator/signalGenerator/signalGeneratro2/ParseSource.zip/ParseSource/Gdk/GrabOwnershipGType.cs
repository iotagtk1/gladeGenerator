﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000099 RID: 153
	internal class GrabOwnershipGType
	{
		// Token: 0x170001A7 RID: 423
		// (get) Token: 0x0600065F RID: 1631 RVA: 0x00012F15 File Offset: 0x00011115
		public static GType GType
		{
			get
			{
				return new GType(GrabOwnershipGType.gdk_grab_ownership_get_type());
			}
		}

		// Token: 0x04000367 RID: 871
		private static GrabOwnershipGType.d_gdk_grab_ownership_get_type gdk_grab_ownership_get_type = FuncLoader.LoadFunction<GrabOwnershipGType.d_gdk_grab_ownership_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_grab_ownership_get_type"));

		// Token: 0x020002D8 RID: 728
		// (Invoke) Token: 0x060011E5 RID: 4581
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_grab_ownership_get_type();
	}
}
