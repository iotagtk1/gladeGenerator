﻿using System;

namespace Gdk
{
	// Token: 0x020000B5 RID: 181
	// (Invoke) Token: 0x0600073E RID: 1854
	public delegate void MonitorRemovedHandler(object o, MonitorRemovedArgs args);
}
