﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000024 RID: 36
	public class DisplayManager : Object
	{
		// Token: 0x06000294 RID: 660 RVA: 0x00009920 File Offset: 0x00007B20
		public Display[] ListDisplays()
		{
			IntPtr intPtr = DisplayManager.gdk_display_manager_list_displays(base.Handle);
			if (intPtr == IntPtr.Zero)
			{
				return new Display[0];
			}
			SList slist = new SList(intPtr);
			Display[] array = new Display[slist.Count];
			for (int i = 0; i < slist.Count; i++)
			{
				array[i] = (slist[i] as Display);
			}
			return array;
		}

		// Token: 0x06000295 RID: 661 RVA: 0x00009986 File Offset: 0x00007B86
		public DisplayManager(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000296 RID: 662 RVA: 0x0000998F File Offset: 0x00007B8F
		protected DisplayManager() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x06000297 RID: 663 RVA: 0x000099AE File Offset: 0x00007BAE
		// (set) Token: 0x06000298 RID: 664 RVA: 0x000099CA File Offset: 0x00007BCA
		[Property("default-display")]
		public Display DefaultDisplay
		{
			get
			{
				return Object.GetObject(DisplayManager.gdk_display_manager_get_default_display(base.Handle)) as Display;
			}
			set
			{
				DisplayManager.gdk_display_manager_set_default_display(base.Handle, (value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x14000009 RID: 9
		// (add) Token: 0x06000299 RID: 665 RVA: 0x000099EC File Offset: 0x00007BEC
		// (remove) Token: 0x0600029A RID: 666 RVA: 0x00009A04 File Offset: 0x00007C04
		[Signal("display-opened")]
		public event DisplayOpenedHandler DisplayOpened
		{
			add
			{
				base.AddSignalHandler("display-opened", value, typeof(DisplayOpenedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("display-opened", value);
			}
		}

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x0600029B RID: 667 RVA: 0x00009A12 File Offset: 0x00007C12
		private static DisplayManager.DisplayOpenedNativeDelegate DisplayOpenedVMCallback
		{
			get
			{
				if (DisplayManager.DisplayOpened_cb_delegate == null)
				{
					DisplayManager.DisplayOpened_cb_delegate = new DisplayManager.DisplayOpenedNativeDelegate(DisplayManager.DisplayOpened_cb);
				}
				return DisplayManager.DisplayOpened_cb_delegate;
			}
		}

		// Token: 0x0600029C RID: 668 RVA: 0x00009A31 File Offset: 0x00007C31
		private static void OverrideDisplayOpened(GType gtype)
		{
			DisplayManager.OverrideDisplayOpened(gtype, DisplayManager.DisplayOpenedVMCallback);
		}

		// Token: 0x0600029D RID: 669 RVA: 0x00009A40 File Offset: 0x00007C40
		private unsafe static void OverrideDisplayOpened(GType gtype, DisplayManager.DisplayOpenedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + DisplayManager.class_abi.GetFieldOffset("display_opened");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600029E RID: 670 RVA: 0x00009A74 File Offset: 0x00007C74
		private static void DisplayOpened_cb(IntPtr inst, IntPtr display)
		{
			try
			{
				(Object.GetObject(inst, false) as DisplayManager).OnDisplayOpened(Object.GetObject(display) as Display);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x0600029F RID: 671 RVA: 0x00009AB8 File Offset: 0x00007CB8
		[DefaultSignalHandler(Type = typeof(DisplayManager), ConnectionMethod = "OverrideDisplayOpened")]
		protected virtual void OnDisplayOpened(Display display)
		{
			this.InternalDisplayOpened(display);
		}

		// Token: 0x060002A0 RID: 672 RVA: 0x00009AC4 File Offset: 0x00007CC4
		private void InternalDisplayOpened(Display display)
		{
			DisplayManager.DisplayOpenedNativeDelegate displayOpenedNativeDelegate = DisplayManager.class_abi.BaseOverride(base.LookupGType(), "display_opened");
			if (displayOpenedNativeDelegate == null)
			{
				return;
			}
			displayOpenedNativeDelegate(base.Handle, (display == null) ? IntPtr.Zero : display.Handle);
		}

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x060002A1 RID: 673 RVA: 0x00009B08 File Offset: 0x00007D08
		public new static AbiStruct class_abi
		{
			get
			{
				if (DisplayManager._class_abi == null)
				{
					DisplayManager._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("display_opened", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return DisplayManager._class_abi;
			}
		}

		// Token: 0x060002A2 RID: 674 RVA: 0x00009B6C File Offset: 0x00007D6C
		public static DisplayManager Get()
		{
			return Object.GetObject(DisplayManager.gdk_display_manager_get()) as DisplayManager;
		}

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x060002A3 RID: 675 RVA: 0x00009B84 File Offset: 0x00007D84
		public new static GType GType
		{
			get
			{
				IntPtr val = DisplayManager.gdk_display_manager_get_type();
				return new GType(val);
			}
		}

		// Token: 0x060002A4 RID: 676 RVA: 0x00009BA4 File Offset: 0x00007DA4
		public Display OpenDisplay(string name)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(name);
			Display result = Object.GetObject(DisplayManager.gdk_display_manager_open_display(base.Handle, intPtr)) as Display;
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x060002A5 RID: 677 RVA: 0x00009BD9 File Offset: 0x00007DD9
		public new static AbiStruct abi_info
		{
			get
			{
				if (DisplayManager._abi_info == null)
				{
					DisplayManager._abi_info = new AbiStruct(Object.abi_info.Fields);
				}
				return DisplayManager._abi_info;
			}
		}

		// Token: 0x040000F8 RID: 248
		private static DisplayManager.d_gdk_display_manager_list_displays gdk_display_manager_list_displays = FuncLoader.LoadFunction<DisplayManager.d_gdk_display_manager_list_displays>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_manager_list_displays"));

		// Token: 0x040000F9 RID: 249
		private static DisplayManager.d_gdk_display_manager_get_default_display gdk_display_manager_get_default_display = FuncLoader.LoadFunction<DisplayManager.d_gdk_display_manager_get_default_display>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_manager_get_default_display"));

		// Token: 0x040000FA RID: 250
		private static DisplayManager.d_gdk_display_manager_set_default_display gdk_display_manager_set_default_display = FuncLoader.LoadFunction<DisplayManager.d_gdk_display_manager_set_default_display>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_manager_set_default_display"));

		// Token: 0x040000FB RID: 251
		private static DisplayManager.DisplayOpenedNativeDelegate DisplayOpened_cb_delegate;

		// Token: 0x040000FC RID: 252
		private static AbiStruct _class_abi = null;

		// Token: 0x040000FD RID: 253
		private static DisplayManager.d_gdk_display_manager_get gdk_display_manager_get = FuncLoader.LoadFunction<DisplayManager.d_gdk_display_manager_get>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_manager_get"));

		// Token: 0x040000FE RID: 254
		private static DisplayManager.d_gdk_display_manager_get_type gdk_display_manager_get_type = FuncLoader.LoadFunction<DisplayManager.d_gdk_display_manager_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_manager_get_type"));

		// Token: 0x040000FF RID: 255
		private static DisplayManager.d_gdk_display_manager_open_display gdk_display_manager_open_display = FuncLoader.LoadFunction<DisplayManager.d_gdk_display_manager_open_display>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_display_manager_open_display"));

		// Token: 0x04000100 RID: 256
		private static AbiStruct _abi_info = null;

		// Token: 0x020001D0 RID: 464
		// (Invoke) Token: 0x06000E13 RID: 3603
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_manager_list_displays(IntPtr raw);

		// Token: 0x020001D1 RID: 465
		// (Invoke) Token: 0x06000E17 RID: 3607
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_manager_get_default_display(IntPtr raw);

		// Token: 0x020001D2 RID: 466
		// (Invoke) Token: 0x06000E1B RID: 3611
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_display_manager_set_default_display(IntPtr raw, IntPtr display);

		// Token: 0x020001D3 RID: 467
		// (Invoke) Token: 0x06000E1F RID: 3615
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DisplayOpenedNativeDelegate(IntPtr inst, IntPtr display);

		// Token: 0x020001D4 RID: 468
		// (Invoke) Token: 0x06000E23 RID: 3619
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_manager_get();

		// Token: 0x020001D5 RID: 469
		// (Invoke) Token: 0x06000E27 RID: 3623
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_manager_get_type();

		// Token: 0x020001D6 RID: 470
		// (Invoke) Token: 0x06000E2B RID: 3627
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_display_manager_open_display(IntPtr raw, IntPtr name);
	}
}
