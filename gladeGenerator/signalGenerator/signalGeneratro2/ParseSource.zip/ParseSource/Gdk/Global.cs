﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000096 RID: 150
	public class Global
	{
		// Token: 0x06000644 RID: 1604 RVA: 0x0001298D File Offset: 0x00010B8D
		public static void DisableMultidevice()
		{
			Global.gdk_disable_multidevice();
		}

		// Token: 0x1700019C RID: 412
		// (get) Token: 0x06000645 RID: 1605 RVA: 0x00012999 File Offset: 0x00010B99
		public static Window DefaultRootWindow
		{
			get
			{
				return Object.GetObject(Global.gdk_get_default_root_window()) as Window;
			}
		}

		// Token: 0x1700019D RID: 413
		// (get) Token: 0x06000646 RID: 1606 RVA: 0x000129AF File Offset: 0x00010BAF
		public static string DisplayArgName
		{
			get
			{
				return Marshaller.Utf8PtrToString(Global.gdk_get_display_arg_name());
			}
		}

		// Token: 0x1700019E RID: 414
		// (get) Token: 0x06000647 RID: 1607 RVA: 0x000129C0 File Offset: 0x00010BC0
		// (set) Token: 0x06000648 RID: 1608 RVA: 0x000129D4 File Offset: 0x00010BD4
		public static string ProgramClass
		{
			get
			{
				return Marshaller.Utf8PtrToString(Global.gdk_get_program_class());
			}
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				Global.gdk_set_program_class(intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x1700019F RID: 415
		// (get) Token: 0x06000649 RID: 1609 RVA: 0x000129F9 File Offset: 0x00010BF9
		// (set) Token: 0x0600064A RID: 1610 RVA: 0x00012A05 File Offset: 0x00010C05
		public static bool ShowEvents
		{
			get
			{
				return Global.gdk_get_show_events();
			}
			set
			{
				Global.gdk_set_show_events(value);
			}
		}

		// Token: 0x0600064B RID: 1611 RVA: 0x00012A12 File Offset: 0x00010C12
		public static int GlErrorQuark()
		{
			return Global.gdk_gl_error_quark();
		}

		// Token: 0x0600064C RID: 1612 RVA: 0x00012A1E File Offset: 0x00010C1E
		[Obsolete]
		public static void PreParseLibgtkOnly()
		{
			Global.gdk_pre_parse_libgtk_only();
		}

		// Token: 0x170001A0 RID: 416
		// (set) Token: 0x0600064D RID: 1613 RVA: 0x00012A2C File Offset: 0x00010C2C
		public static string AllowedBackends
		{
			set
			{
				IntPtr intPtr = Marshaller.StringToPtrGStrdup(value);
				Global.gdk_set_allowed_backends(intPtr);
				Marshaller.Free(intPtr);
			}
		}

		// Token: 0x170001A1 RID: 417
		// (set) Token: 0x0600064E RID: 1614 RVA: 0x00012A51 File Offset: 0x00010C51
		public static uint DoubleClickTime
		{
			set
			{
				Global.gdk_set_double_click_time(value);
			}
		}

		// Token: 0x0600064F RID: 1615 RVA: 0x00012A60 File Offset: 0x00010C60
		public static bool SettingGet(string name, Value value)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(name);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(value);
			bool result = Global.gdk_setting_get(intPtr, intPtr2);
			Marshaller.Free(intPtr);
			Marshal.FreeHGlobal(intPtr2);
			return result;
		}

		// Token: 0x06000650 RID: 1616 RVA: 0x00012A98 File Offset: 0x00010C98
		public static uint UnicodeToKeyval(uint wc)
		{
			return Global.gdk_unicode_to_keyval(wc);
		}

		// Token: 0x06000651 RID: 1617 RVA: 0x00012AA5 File Offset: 0x00010CA5
		public static void NotifyStartupComplete()
		{
			Global.gdk_notify_startup_complete();
		}

		// Token: 0x06000652 RID: 1618 RVA: 0x00012AB4 File Offset: 0x00010CB4
		public static Visual[] ListVisuals()
		{
			IntPtr intPtr = Global.gdk_list_visuals();
			if (intPtr == IntPtr.Zero)
			{
				return new Visual[0];
			}
			List list = new List(intPtr);
			Visual[] array = new Visual[list.Count];
			for (int i = 0; i < list.Count; i++)
			{
				array[i] = (list[i] as Visual);
			}
			return array;
		}

		// Token: 0x170001A2 RID: 418
		// (get) Token: 0x06000653 RID: 1619 RVA: 0x00012B14 File Offset: 0x00010D14
		public static Atom[] SupportedWindowManagerHints
		{
			get
			{
				Atom[] result;
				if (!Property.Get(Screen.Default.RootWindow, Atom.Intern("_NET_SUPPORTED", false), false, out result))
				{
					throw new ApplicationException("Unable to get _NET_SUPPORTED property");
				}
				return result;
			}
		}

		// Token: 0x170001A3 RID: 419
		// (get) Token: 0x06000654 RID: 1620 RVA: 0x00012B4C File Offset: 0x00010D4C
		public static int NumberOfDesktops
		{
			get
			{
				int[] array;
				if (!Property.Get(Screen.Default.RootWindow, Atom.Intern("_NET_NUMBER_OF_DESKTOPS", false), false, out array))
				{
					throw new ApplicationException("Unable to get _NET_NUMBER_OF_DESKTOPS property");
				}
				return array[0];
			}
		}

		// Token: 0x170001A4 RID: 420
		// (get) Token: 0x06000655 RID: 1621 RVA: 0x00012B88 File Offset: 0x00010D88
		public static int CurrentDesktop
		{
			get
			{
				int[] array;
				if (!Property.Get(Screen.Default.RootWindow, Atom.Intern("_NET_CURRENT_DESKTOP", false), false, out array))
				{
					throw new ApplicationException("Unable to get _NET_CURRENT_DESKTOP property");
				}
				return array[0];
			}
		}

		// Token: 0x170001A5 RID: 421
		// (get) Token: 0x06000656 RID: 1622 RVA: 0x00012BC4 File Offset: 0x00010DC4
		public static Rectangle[] DesktopWorkareas
		{
			get
			{
				Rectangle[] result;
				if (!Property.Get(Screen.Default.RootWindow, Atom.Intern("_NET_WORKAREA", false), false, out result))
				{
					throw new ApplicationException("Unable to get _NET_WORKAREA property");
				}
				return result;
			}
		}

		// Token: 0x06000657 RID: 1623 RVA: 0x00012BFC File Offset: 0x00010DFC
		public static bool InitCheck(ref string[] argv)
		{
			Argv argv2 = new Argv(argv, true);
			IntPtr handle = argv2.Handle;
			int argc = argv.Length + 1;
			bool result = Global.gdk_init_check(ref argc, ref handle);
			argv = argv2.GetArgs(argc);
			return result;
		}

		// Token: 0x06000658 RID: 1624 RVA: 0x00012C38 File Offset: 0x00010E38
		public static void ParseArgs(ref string[] argv)
		{
			Argv argv2 = new Argv(argv, true);
			IntPtr handle = argv2.Handle;
			int argc = argv.Length + 1;
			Global.gdk_parse_args(ref argc, ref handle);
			argv = argv2.GetArgs(argc);
		}

		// Token: 0x06000659 RID: 1625 RVA: 0x00012C74 File Offset: 0x00010E74
		public static int[] QueryDepths()
		{
			IntPtr source;
			int num;
			Global.gdk_query_depths(out source, out num);
			int[] array = new int[num];
			Marshal.Copy(source, array, 0, num);
			return array;
		}

		// Token: 0x0600065A RID: 1626 RVA: 0x00012CA0 File Offset: 0x00010EA0
		public static VisualType[] QueryVisualTypes()
		{
			IntPtr source;
			int num;
			Global.gdk_query_visual_types(out source, out num);
			int[] array = new int[num];
			Marshal.Copy(source, array, 0, num);
			VisualType[] array2 = new VisualType[num];
			for (int i = 0; i < num; i++)
			{
				array2[i] = (VisualType)array[i];
			}
			return array2;
		}

		// Token: 0x0400034F RID: 847
		private static Global.d_gdk_disable_multidevice gdk_disable_multidevice = FuncLoader.LoadFunction<Global.d_gdk_disable_multidevice>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_disable_multidevice"));

		// Token: 0x04000350 RID: 848
		private static Global.d_gdk_get_default_root_window gdk_get_default_root_window = FuncLoader.LoadFunction<Global.d_gdk_get_default_root_window>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_get_default_root_window"));

		// Token: 0x04000351 RID: 849
		private static Global.d_gdk_get_display_arg_name gdk_get_display_arg_name = FuncLoader.LoadFunction<Global.d_gdk_get_display_arg_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_get_display_arg_name"));

		// Token: 0x04000352 RID: 850
		private static Global.d_gdk_get_program_class gdk_get_program_class = FuncLoader.LoadFunction<Global.d_gdk_get_program_class>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_get_program_class"));

		// Token: 0x04000353 RID: 851
		private static Global.d_gdk_set_program_class gdk_set_program_class = FuncLoader.LoadFunction<Global.d_gdk_set_program_class>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_set_program_class"));

		// Token: 0x04000354 RID: 852
		private static Global.d_gdk_get_show_events gdk_get_show_events = FuncLoader.LoadFunction<Global.d_gdk_get_show_events>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_get_show_events"));

		// Token: 0x04000355 RID: 853
		private static Global.d_gdk_set_show_events gdk_set_show_events = FuncLoader.LoadFunction<Global.d_gdk_set_show_events>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_set_show_events"));

		// Token: 0x04000356 RID: 854
		private static Global.d_gdk_gl_error_quark gdk_gl_error_quark = FuncLoader.LoadFunction<Global.d_gdk_gl_error_quark>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_gl_error_quark"));

		// Token: 0x04000357 RID: 855
		private static Global.d_gdk_pre_parse_libgtk_only gdk_pre_parse_libgtk_only = FuncLoader.LoadFunction<Global.d_gdk_pre_parse_libgtk_only>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_pre_parse_libgtk_only"));

		// Token: 0x04000358 RID: 856
		private static Global.d_gdk_set_allowed_backends gdk_set_allowed_backends = FuncLoader.LoadFunction<Global.d_gdk_set_allowed_backends>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_set_allowed_backends"));

		// Token: 0x04000359 RID: 857
		private static Global.d_gdk_set_double_click_time gdk_set_double_click_time = FuncLoader.LoadFunction<Global.d_gdk_set_double_click_time>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_set_double_click_time"));

		// Token: 0x0400035A RID: 858
		private static Global.d_gdk_setting_get gdk_setting_get = FuncLoader.LoadFunction<Global.d_gdk_setting_get>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_setting_get"));

		// Token: 0x0400035B RID: 859
		private static Global.d_gdk_unicode_to_keyval gdk_unicode_to_keyval = FuncLoader.LoadFunction<Global.d_gdk_unicode_to_keyval>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_unicode_to_keyval"));

		// Token: 0x0400035C RID: 860
		private static Global.d_gdk_notify_startup_complete gdk_notify_startup_complete = FuncLoader.LoadFunction<Global.d_gdk_notify_startup_complete>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_notify_startup_complete"));

		// Token: 0x0400035D RID: 861
		private static Global.d_gdk_list_visuals gdk_list_visuals = FuncLoader.LoadFunction<Global.d_gdk_list_visuals>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_list_visuals"));

		// Token: 0x0400035E RID: 862
		private static Global.d_gdk_init_check gdk_init_check = FuncLoader.LoadFunction<Global.d_gdk_init_check>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_init_check"));

		// Token: 0x0400035F RID: 863
		private static Global.d_gdk_parse_args gdk_parse_args = FuncLoader.LoadFunction<Global.d_gdk_parse_args>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_parse_args"));

		// Token: 0x04000360 RID: 864
		private static Global.d_gdk_query_depths gdk_query_depths = FuncLoader.LoadFunction<Global.d_gdk_query_depths>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_query_depths"));

		// Token: 0x04000361 RID: 865
		private static Global.d_gdk_query_visual_types gdk_query_visual_types = FuncLoader.LoadFunction<Global.d_gdk_query_visual_types>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_query_visual_types"));

		// Token: 0x020002C5 RID: 709
		// (Invoke) Token: 0x06001199 RID: 4505
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_disable_multidevice();

		// Token: 0x020002C6 RID: 710
		// (Invoke) Token: 0x0600119D RID: 4509
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_get_default_root_window();

		// Token: 0x020002C7 RID: 711
		// (Invoke) Token: 0x060011A1 RID: 4513
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_get_display_arg_name();

		// Token: 0x020002C8 RID: 712
		// (Invoke) Token: 0x060011A5 RID: 4517
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_get_program_class();

		// Token: 0x020002C9 RID: 713
		// (Invoke) Token: 0x060011A9 RID: 4521
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_set_program_class(IntPtr program_class);

		// Token: 0x020002CA RID: 714
		// (Invoke) Token: 0x060011AD RID: 4525
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_get_show_events();

		// Token: 0x020002CB RID: 715
		// (Invoke) Token: 0x060011B1 RID: 4529
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_set_show_events(bool show_events);

		// Token: 0x020002CC RID: 716
		// (Invoke) Token: 0x060011B5 RID: 4533
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_gl_error_quark();

		// Token: 0x020002CD RID: 717
		// (Invoke) Token: 0x060011B9 RID: 4537
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_pre_parse_libgtk_only();

		// Token: 0x020002CE RID: 718
		// (Invoke) Token: 0x060011BD RID: 4541
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_set_allowed_backends(IntPtr backends);

		// Token: 0x020002CF RID: 719
		// (Invoke) Token: 0x060011C1 RID: 4545
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_set_double_click_time(uint msec);

		// Token: 0x020002D0 RID: 720
		// (Invoke) Token: 0x060011C5 RID: 4549
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_setting_get(IntPtr name, IntPtr value);

		// Token: 0x020002D1 RID: 721
		// (Invoke) Token: 0x060011C9 RID: 4553
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gdk_unicode_to_keyval(uint wc);

		// Token: 0x020002D2 RID: 722
		// (Invoke) Token: 0x060011CD RID: 4557
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_notify_startup_complete();

		// Token: 0x020002D3 RID: 723
		// (Invoke) Token: 0x060011D1 RID: 4561
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_list_visuals();

		// Token: 0x020002D4 RID: 724
		// (Invoke) Token: 0x060011D5 RID: 4565
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_init_check(ref int argc, ref IntPtr argv);

		// Token: 0x020002D5 RID: 725
		// (Invoke) Token: 0x060011D9 RID: 4569
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_parse_args(ref int argc, ref IntPtr argv);

		// Token: 0x020002D6 RID: 726
		// (Invoke) Token: 0x060011DD RID: 4573
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_query_depths(out IntPtr depths, out int n_depths);

		// Token: 0x020002D7 RID: 727
		// (Invoke) Token: 0x060011E1 RID: 4577
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_query_visual_types(out IntPtr types, out int n_types);
	}
}
