﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x0200003D RID: 61
	public class AreaUpdatedArgs : SignalArgs
	{
		// Token: 0x170000EE RID: 238
		// (get) Token: 0x0600038B RID: 907 RVA: 0x0000B7F1 File Offset: 0x000099F1
		public int X
		{
			get
			{
				return (int)base.Args[0];
			}
		}

		// Token: 0x170000EF RID: 239
		// (get) Token: 0x0600038C RID: 908 RVA: 0x0000B800 File Offset: 0x00009A00
		public int Y
		{
			get
			{
				return (int)base.Args[1];
			}
		}

		// Token: 0x170000F0 RID: 240
		// (get) Token: 0x0600038D RID: 909 RVA: 0x0000B80F File Offset: 0x00009A0F
		public int Width
		{
			get
			{
				return (int)base.Args[2];
			}
		}

		// Token: 0x170000F1 RID: 241
		// (get) Token: 0x0600038E RID: 910 RVA: 0x0000B81E File Offset: 0x00009A1E
		public int Height
		{
			get
			{
				return (int)base.Args[3];
			}
		}
	}
}
