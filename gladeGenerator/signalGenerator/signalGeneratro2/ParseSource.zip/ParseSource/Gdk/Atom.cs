﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000020 RID: 32
	public class Atom : Opaque
	{
		// Token: 0x06000089 RID: 137 RVA: 0x00003231 File Offset: 0x00001431
		public static implicit operator string(Atom atom)
		{
			return atom.Name;
		}

		// Token: 0x0600008A RID: 138 RVA: 0x0000323C File Offset: 0x0000143C
		public static Atom Intern(string atom_name, bool only_if_exists)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(atom_name);
			IntPtr intPtr2 = Atom.gdk_atom_intern(intPtr, only_if_exists);
			Atom result = (intPtr2 == IntPtr.Zero) ? null : ((Atom)Opaque.GetOpaque(intPtr2, typeof(Atom), false));
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x0600008B RID: 139 RVA: 0x00003289 File Offset: 0x00001489
		public string Name
		{
			get
			{
				return Marshaller.PtrToStringGFree(Atom.gdk_atom_name(base.Handle));
			}
		}

		// Token: 0x0600008C RID: 140 RVA: 0x000032A0 File Offset: 0x000014A0
		public Atom(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x0600008D RID: 141 RVA: 0x000032A9 File Offset: 0x000014A9
		public static AbiStruct abi_info
		{
			get
			{
				if (Atom._abi_info == null)
				{
					Atom._abi_info = new AbiStruct(new List<AbiField>());
				}
				return Atom._abi_info;
			}
		}

		// Token: 0x04000053 RID: 83
		private static Atom.d_gdk_atom_intern gdk_atom_intern = FuncLoader.LoadFunction<Atom.d_gdk_atom_intern>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_atom_intern"));

		// Token: 0x04000054 RID: 84
		private static Atom.d_gdk_atom_name gdk_atom_name = FuncLoader.LoadFunction<Atom.d_gdk_atom_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_atom_name"));

		// Token: 0x04000055 RID: 85
		private static AbiStruct _abi_info = null;

		// Token: 0x02000134 RID: 308
		// (Invoke) Token: 0x06000BA7 RID: 2983
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_atom_intern(IntPtr atom_name, bool only_if_exists);

		// Token: 0x02000135 RID: 309
		// (Invoke) Token: 0x06000BAB RID: 2987
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_atom_name(IntPtr raw);
	}
}
