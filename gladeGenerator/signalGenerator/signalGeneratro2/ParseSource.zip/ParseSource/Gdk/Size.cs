﻿using System;

namespace Gdk
{
	// Token: 0x0200012F RID: 303
	public struct Size
	{
		// Token: 0x06000B8B RID: 2955 RVA: 0x00021BB7 File Offset: 0x0001FDB7
		public static Size operator +(Size sz1, Size sz2)
		{
			return new Size(sz1.Width + sz2.Width, sz1.Height + sz2.Height);
		}

		// Token: 0x06000B8C RID: 2956 RVA: 0x00021BDC File Offset: 0x0001FDDC
		public static bool operator ==(Size sz_a, Size sz_b)
		{
			return sz_a.Width == sz_b.Width && sz_a.Height == sz_b.Height;
		}

		// Token: 0x06000B8D RID: 2957 RVA: 0x00021C00 File Offset: 0x0001FE00
		public static bool operator !=(Size sz_a, Size sz_b)
		{
			return sz_a.Width != sz_b.Width || sz_a.Height != sz_b.Height;
		}

		// Token: 0x06000B8E RID: 2958 RVA: 0x00021C27 File Offset: 0x0001FE27
		public static Size operator -(Size sz1, Size sz2)
		{
			return new Size(sz1.Width - sz2.Width, sz1.Height - sz2.Height);
		}

		// Token: 0x06000B8F RID: 2959 RVA: 0x00021C4C File Offset: 0x0001FE4C
		public static explicit operator Point(Size sz)
		{
			return new Point(sz.Width, sz.Height);
		}

		// Token: 0x06000B90 RID: 2960 RVA: 0x00021C61 File Offset: 0x0001FE61
		public Size(Point pt)
		{
			this.width = pt.X;
			this.height = pt.Y;
		}

		// Token: 0x06000B91 RID: 2961 RVA: 0x00021C7B File Offset: 0x0001FE7B
		public Size(int width, int height)
		{
			this.width = width;
			this.height = height;
		}

		// Token: 0x17000302 RID: 770
		// (get) Token: 0x06000B92 RID: 2962 RVA: 0x00021C8B File Offset: 0x0001FE8B
		public bool IsEmpty
		{
			get
			{
				return this.width == 0 && this.height == 0;
			}
		}

		// Token: 0x17000303 RID: 771
		// (get) Token: 0x06000B93 RID: 2963 RVA: 0x00021CA0 File Offset: 0x0001FEA0
		// (set) Token: 0x06000B94 RID: 2964 RVA: 0x00021CA8 File Offset: 0x0001FEA8
		public int Width
		{
			get
			{
				return this.width;
			}
			set
			{
				this.width = value;
			}
		}

		// Token: 0x17000304 RID: 772
		// (get) Token: 0x06000B95 RID: 2965 RVA: 0x00021CB1 File Offset: 0x0001FEB1
		// (set) Token: 0x06000B96 RID: 2966 RVA: 0x00021CB9 File Offset: 0x0001FEB9
		public int Height
		{
			get
			{
				return this.height;
			}
			set
			{
				this.height = value;
			}
		}

		// Token: 0x06000B97 RID: 2967 RVA: 0x00021CC2 File Offset: 0x0001FEC2
		public override bool Equals(object o)
		{
			return o is Size && this == (Size)o;
		}

		// Token: 0x06000B98 RID: 2968 RVA: 0x00021CDF File Offset: 0x0001FEDF
		public override int GetHashCode()
		{
			return this.width ^ this.height;
		}

		// Token: 0x06000B99 RID: 2969 RVA: 0x00021CEE File Offset: 0x0001FEEE
		public override string ToString()
		{
			return string.Format("{{Width={0}, Height={1}}}", this.width, this.height);
		}

		// Token: 0x04000C06 RID: 3078
		private int width;

		// Token: 0x04000C07 RID: 3079
		private int height;

		// Token: 0x04000C08 RID: 3080
		public static readonly Size Empty;
	}
}
