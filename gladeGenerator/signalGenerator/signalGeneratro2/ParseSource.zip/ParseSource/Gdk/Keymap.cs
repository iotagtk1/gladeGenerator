﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;
using Pango;

namespace Gdk
{
	// Token: 0x020000AA RID: 170
	public class Keymap : Object
	{
		// Token: 0x06000683 RID: 1667 RVA: 0x0001312E File Offset: 0x0001132E
		public Keymap(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000684 RID: 1668 RVA: 0x00013137 File Offset: 0x00011337
		protected Keymap() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x14000018 RID: 24
		// (add) Token: 0x06000685 RID: 1669 RVA: 0x00013156 File Offset: 0x00011356
		// (remove) Token: 0x06000686 RID: 1670 RVA: 0x00013164 File Offset: 0x00011364
		[Signal("state_changed")]
		public event EventHandler StateChanged
		{
			add
			{
				base.AddSignalHandler("state_changed", value);
			}
			remove
			{
				base.RemoveSignalHandler("state_changed", value);
			}
		}

		// Token: 0x14000019 RID: 25
		// (add) Token: 0x06000687 RID: 1671 RVA: 0x00013172 File Offset: 0x00011372
		// (remove) Token: 0x06000688 RID: 1672 RVA: 0x00013180 File Offset: 0x00011380
		[Signal("keys-changed")]
		public event EventHandler KeysChanged
		{
			add
			{
				base.AddSignalHandler("keys-changed", value);
			}
			remove
			{
				base.RemoveSignalHandler("keys-changed", value);
			}
		}

		// Token: 0x1400001A RID: 26
		// (add) Token: 0x06000689 RID: 1673 RVA: 0x0001318E File Offset: 0x0001138E
		// (remove) Token: 0x0600068A RID: 1674 RVA: 0x0001319C File Offset: 0x0001139C
		[Signal("direction-changed")]
		public event EventHandler DirectionChanged
		{
			add
			{
				base.AddSignalHandler("direction-changed", value);
			}
			remove
			{
				base.RemoveSignalHandler("direction-changed", value);
			}
		}

		// Token: 0x170001B2 RID: 434
		// (get) Token: 0x0600068B RID: 1675 RVA: 0x000131AA File Offset: 0x000113AA
		private static Keymap.GetDirectionNativeDelegate GetDirectionVMCallback
		{
			get
			{
				if (Keymap.GetDirection_cb_delegate == null)
				{
					Keymap.GetDirection_cb_delegate = new Keymap.GetDirectionNativeDelegate(Keymap.GetDirection_cb);
				}
				return Keymap.GetDirection_cb_delegate;
			}
		}

		// Token: 0x0600068C RID: 1676 RVA: 0x000131C9 File Offset: 0x000113C9
		private static void OverrideGetDirection(GType gtype)
		{
			Keymap.OverrideGetDirection(gtype, Keymap.GetDirectionVMCallback);
		}

		// Token: 0x0600068D RID: 1677 RVA: 0x000131D8 File Offset: 0x000113D8
		private unsafe static void OverrideGetDirection(GType gtype, Keymap.GetDirectionNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Keymap.class_abi.GetFieldOffset("get_direction");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600068E RID: 1678 RVA: 0x0001320C File Offset: 0x0001140C
		private static int GetDirection_cb(IntPtr inst)
		{
			int result;
			try
			{
				result = (int)(Object.GetObject(inst, false) as Keymap).OnGetDirection();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600068F RID: 1679 RVA: 0x00013248 File Offset: 0x00011448
		[DefaultSignalHandler(Type = typeof(Keymap), ConnectionMethod = "OverrideGetDirection")]
		protected virtual Direction OnGetDirection()
		{
			return this.InternalGetDirection();
		}

		// Token: 0x06000690 RID: 1680 RVA: 0x00013250 File Offset: 0x00011450
		private Direction InternalGetDirection()
		{
			Keymap.GetDirectionNativeDelegate getDirectionNativeDelegate = Keymap.class_abi.BaseOverride(base.LookupGType(), "get_direction");
			if (getDirectionNativeDelegate == null)
			{
				return Direction.Ltr;
			}
			return (Direction)getDirectionNativeDelegate(base.Handle);
		}

		// Token: 0x170001B3 RID: 435
		// (get) Token: 0x06000691 RID: 1681 RVA: 0x00013284 File Offset: 0x00011484
		private static Keymap.HaveBidiLayoutsNativeDelegate HaveBidiLayoutsVMCallback
		{
			get
			{
				if (Keymap.HaveBidiLayouts_cb_delegate == null)
				{
					Keymap.HaveBidiLayouts_cb_delegate = new Keymap.HaveBidiLayoutsNativeDelegate(Keymap.HaveBidiLayouts_cb);
				}
				return Keymap.HaveBidiLayouts_cb_delegate;
			}
		}

		// Token: 0x06000692 RID: 1682 RVA: 0x000132A3 File Offset: 0x000114A3
		private static void OverrideHaveBidiLayouts(GType gtype)
		{
			Keymap.OverrideHaveBidiLayouts(gtype, Keymap.HaveBidiLayoutsVMCallback);
		}

		// Token: 0x06000693 RID: 1683 RVA: 0x000132B0 File Offset: 0x000114B0
		private unsafe static void OverrideHaveBidiLayouts(GType gtype, Keymap.HaveBidiLayoutsNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Keymap.class_abi.GetFieldOffset("have_bidi_layouts");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000694 RID: 1684 RVA: 0x000132E4 File Offset: 0x000114E4
		private static bool HaveBidiLayouts_cb(IntPtr inst)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Keymap).OnHaveBidiLayouts();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x06000695 RID: 1685 RVA: 0x00013320 File Offset: 0x00011520
		[DefaultSignalHandler(Type = typeof(Keymap), ConnectionMethod = "OverrideHaveBidiLayouts")]
		protected virtual bool OnHaveBidiLayouts()
		{
			return this.InternalHaveBidiLayouts();
		}

		// Token: 0x06000696 RID: 1686 RVA: 0x00013328 File Offset: 0x00011528
		private bool InternalHaveBidiLayouts()
		{
			Keymap.HaveBidiLayoutsNativeDelegate haveBidiLayoutsNativeDelegate = Keymap.class_abi.BaseOverride(base.LookupGType(), "have_bidi_layouts");
			return haveBidiLayoutsNativeDelegate != null && haveBidiLayoutsNativeDelegate(base.Handle);
		}

		// Token: 0x170001B4 RID: 436
		// (get) Token: 0x06000697 RID: 1687 RVA: 0x0001335C File Offset: 0x0001155C
		private static Keymap.GetCapsLockStateNativeDelegate GetCapsLockStateVMCallback
		{
			get
			{
				if (Keymap.GetCapsLockState_cb_delegate == null)
				{
					Keymap.GetCapsLockState_cb_delegate = new Keymap.GetCapsLockStateNativeDelegate(Keymap.GetCapsLockState_cb);
				}
				return Keymap.GetCapsLockState_cb_delegate;
			}
		}

		// Token: 0x06000698 RID: 1688 RVA: 0x0001337B File Offset: 0x0001157B
		private static void OverrideGetCapsLockState(GType gtype)
		{
			Keymap.OverrideGetCapsLockState(gtype, Keymap.GetCapsLockStateVMCallback);
		}

		// Token: 0x06000699 RID: 1689 RVA: 0x00013388 File Offset: 0x00011588
		private unsafe static void OverrideGetCapsLockState(GType gtype, Keymap.GetCapsLockStateNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Keymap.class_abi.GetFieldOffset("get_caps_lock_state");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600069A RID: 1690 RVA: 0x000133BC File Offset: 0x000115BC
		private static bool GetCapsLockState_cb(IntPtr inst)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Keymap).OnGetCapsLockState();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x0600069B RID: 1691 RVA: 0x000133F8 File Offset: 0x000115F8
		[DefaultSignalHandler(Type = typeof(Keymap), ConnectionMethod = "OverrideGetCapsLockState")]
		protected virtual bool OnGetCapsLockState()
		{
			return this.InternalGetCapsLockState();
		}

		// Token: 0x0600069C RID: 1692 RVA: 0x00013400 File Offset: 0x00011600
		private bool InternalGetCapsLockState()
		{
			Keymap.GetCapsLockStateNativeDelegate getCapsLockStateNativeDelegate = Keymap.class_abi.BaseOverride(base.LookupGType(), "get_caps_lock_state");
			return getCapsLockStateNativeDelegate != null && getCapsLockStateNativeDelegate(base.Handle);
		}

		// Token: 0x170001B5 RID: 437
		// (get) Token: 0x0600069D RID: 1693 RVA: 0x00013434 File Offset: 0x00011634
		private static Keymap.GetNumLockStateNativeDelegate GetNumLockStateVMCallback
		{
			get
			{
				if (Keymap.GetNumLockState_cb_delegate == null)
				{
					Keymap.GetNumLockState_cb_delegate = new Keymap.GetNumLockStateNativeDelegate(Keymap.GetNumLockState_cb);
				}
				return Keymap.GetNumLockState_cb_delegate;
			}
		}

		// Token: 0x0600069E RID: 1694 RVA: 0x00013453 File Offset: 0x00011653
		private static void OverrideGetNumLockState(GType gtype)
		{
			Keymap.OverrideGetNumLockState(gtype, Keymap.GetNumLockStateVMCallback);
		}

		// Token: 0x0600069F RID: 1695 RVA: 0x00013460 File Offset: 0x00011660
		private unsafe static void OverrideGetNumLockState(GType gtype, Keymap.GetNumLockStateNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Keymap.class_abi.GetFieldOffset("get_num_lock_state");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060006A0 RID: 1696 RVA: 0x00013494 File Offset: 0x00011694
		private static bool GetNumLockState_cb(IntPtr inst)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Keymap).OnGetNumLockState();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060006A1 RID: 1697 RVA: 0x000134D0 File Offset: 0x000116D0
		[DefaultSignalHandler(Type = typeof(Keymap), ConnectionMethod = "OverrideGetNumLockState")]
		protected virtual bool OnGetNumLockState()
		{
			return this.InternalGetNumLockState();
		}

		// Token: 0x060006A2 RID: 1698 RVA: 0x000134D8 File Offset: 0x000116D8
		private bool InternalGetNumLockState()
		{
			Keymap.GetNumLockStateNativeDelegate getNumLockStateNativeDelegate = Keymap.class_abi.BaseOverride(base.LookupGType(), "get_num_lock_state");
			return getNumLockStateNativeDelegate != null && getNumLockStateNativeDelegate(base.Handle);
		}

		// Token: 0x170001B6 RID: 438
		// (get) Token: 0x060006A3 RID: 1699 RVA: 0x0001350C File Offset: 0x0001170C
		private static Keymap.GetScrollLockStateNativeDelegate GetScrollLockStateVMCallback
		{
			get
			{
				if (Keymap.GetScrollLockState_cb_delegate == null)
				{
					Keymap.GetScrollLockState_cb_delegate = new Keymap.GetScrollLockStateNativeDelegate(Keymap.GetScrollLockState_cb);
				}
				return Keymap.GetScrollLockState_cb_delegate;
			}
		}

		// Token: 0x060006A4 RID: 1700 RVA: 0x0001352B File Offset: 0x0001172B
		private static void OverrideGetScrollLockState(GType gtype)
		{
			Keymap.OverrideGetScrollLockState(gtype, Keymap.GetScrollLockStateVMCallback);
		}

		// Token: 0x060006A5 RID: 1701 RVA: 0x00013538 File Offset: 0x00011738
		private unsafe static void OverrideGetScrollLockState(GType gtype, Keymap.GetScrollLockStateNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Keymap.class_abi.GetFieldOffset("get_scroll_lock_state");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060006A6 RID: 1702 RVA: 0x0001356C File Offset: 0x0001176C
		private static bool GetScrollLockState_cb(IntPtr inst)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Keymap).OnGetScrollLockState();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060006A7 RID: 1703 RVA: 0x000135A8 File Offset: 0x000117A8
		[DefaultSignalHandler(Type = typeof(Keymap), ConnectionMethod = "OverrideGetScrollLockState")]
		protected virtual bool OnGetScrollLockState()
		{
			return this.InternalGetScrollLockState();
		}

		// Token: 0x060006A8 RID: 1704 RVA: 0x000135B0 File Offset: 0x000117B0
		private bool InternalGetScrollLockState()
		{
			Keymap.GetScrollLockStateNativeDelegate getScrollLockStateNativeDelegate = Keymap.class_abi.BaseOverride(base.LookupGType(), "get_scroll_lock_state");
			return getScrollLockStateNativeDelegate != null && getScrollLockStateNativeDelegate(base.Handle);
		}

		// Token: 0x170001B7 RID: 439
		// (get) Token: 0x060006A9 RID: 1705 RVA: 0x000135E4 File Offset: 0x000117E4
		private static Keymap.GetEntriesForKeyvalNativeDelegate GetEntriesForKeyvalVMCallback
		{
			get
			{
				if (Keymap.GetEntriesForKeyval_cb_delegate == null)
				{
					Keymap.GetEntriesForKeyval_cb_delegate = new Keymap.GetEntriesForKeyvalNativeDelegate(Keymap.GetEntriesForKeyval_cb);
				}
				return Keymap.GetEntriesForKeyval_cb_delegate;
			}
		}

		// Token: 0x060006AA RID: 1706 RVA: 0x00013603 File Offset: 0x00011803
		private static void OverrideGetEntriesForKeyval(GType gtype)
		{
			Keymap.OverrideGetEntriesForKeyval(gtype, Keymap.GetEntriesForKeyvalVMCallback);
		}

		// Token: 0x060006AB RID: 1707 RVA: 0x00013610 File Offset: 0x00011810
		private unsafe static void OverrideGetEntriesForKeyval(GType gtype, Keymap.GetEntriesForKeyvalNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Keymap.class_abi.GetFieldOffset("get_entries_for_keyval");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060006AC RID: 1708 RVA: 0x00013644 File Offset: 0x00011844
		private static bool GetEntriesForKeyval_cb(IntPtr inst, uint keyval, IntPtr keys, out int n_keys)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Keymap).OnGetEntriesForKeyval(keyval, KeymapKey.New(keys), out n_keys);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060006AD RID: 1709 RVA: 0x00013688 File Offset: 0x00011888
		[DefaultSignalHandler(Type = typeof(Keymap), ConnectionMethod = "OverrideGetEntriesForKeyval")]
		protected virtual bool OnGetEntriesForKeyval(uint keyval, KeymapKey keys, out int n_keys)
		{
			return this.InternalGetEntriesForKeyval(keyval, keys, out n_keys);
		}

		// Token: 0x060006AE RID: 1710 RVA: 0x00013694 File Offset: 0x00011894
		private bool InternalGetEntriesForKeyval(uint keyval, KeymapKey keys, out int n_keys)
		{
			Keymap.GetEntriesForKeyvalNativeDelegate getEntriesForKeyvalNativeDelegate = Keymap.class_abi.BaseOverride(base.LookupGType(), "get_entries_for_keyval");
			if (getEntriesForKeyvalNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(keys);
			bool result = getEntriesForKeyvalNativeDelegate(base.Handle, keyval, intPtr, out n_keys);
			Marshal.FreeHGlobal(intPtr);
			return result;
		}

		// Token: 0x170001B8 RID: 440
		// (get) Token: 0x060006AF RID: 1711 RVA: 0x000136E4 File Offset: 0x000118E4
		private static Keymap.GetEntriesForKeycodeNativeDelegate GetEntriesForKeycodeVMCallback
		{
			get
			{
				if (Keymap.GetEntriesForKeycode_cb_delegate == null)
				{
					Keymap.GetEntriesForKeycode_cb_delegate = new Keymap.GetEntriesForKeycodeNativeDelegate(Keymap.GetEntriesForKeycode_cb);
				}
				return Keymap.GetEntriesForKeycode_cb_delegate;
			}
		}

		// Token: 0x060006B0 RID: 1712 RVA: 0x00013703 File Offset: 0x00011903
		private static void OverrideGetEntriesForKeycode(GType gtype)
		{
			Keymap.OverrideGetEntriesForKeycode(gtype, Keymap.GetEntriesForKeycodeVMCallback);
		}

		// Token: 0x060006B1 RID: 1713 RVA: 0x00013710 File Offset: 0x00011910
		private unsafe static void OverrideGetEntriesForKeycode(GType gtype, Keymap.GetEntriesForKeycodeNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Keymap.class_abi.GetFieldOffset("get_entries_for_keycode");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060006B2 RID: 1714 RVA: 0x00013744 File Offset: 0x00011944
		private static bool GetEntriesForKeycode_cb(IntPtr inst, uint hardware_keycode, IntPtr keys, out uint keyvals, out int n_entries)
		{
			bool result;
			try
			{
				result = (Object.GetObject(inst, false) as Keymap).OnGetEntriesForKeycode(hardware_keycode, KeymapKey.New(keys), out keyvals, out n_entries);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060006B3 RID: 1715 RVA: 0x00013788 File Offset: 0x00011988
		[DefaultSignalHandler(Type = typeof(Keymap), ConnectionMethod = "OverrideGetEntriesForKeycode")]
		protected virtual bool OnGetEntriesForKeycode(uint hardware_keycode, KeymapKey keys, out uint keyvals, out int n_entries)
		{
			return this.InternalGetEntriesForKeycode(hardware_keycode, keys, out keyvals, out n_entries);
		}

		// Token: 0x060006B4 RID: 1716 RVA: 0x00013798 File Offset: 0x00011998
		private bool InternalGetEntriesForKeycode(uint hardware_keycode, KeymapKey keys, out uint keyvals, out int n_entries)
		{
			Keymap.GetEntriesForKeycodeNativeDelegate getEntriesForKeycodeNativeDelegate = Keymap.class_abi.BaseOverride(base.LookupGType(), "get_entries_for_keycode");
			if (getEntriesForKeycodeNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(keys);
			bool result = getEntriesForKeycodeNativeDelegate(base.Handle, hardware_keycode, intPtr, out keyvals, out n_entries);
			Marshal.FreeHGlobal(intPtr);
			return result;
		}

		// Token: 0x170001B9 RID: 441
		// (get) Token: 0x060006B5 RID: 1717 RVA: 0x000137EA File Offset: 0x000119EA
		private static Keymap.LookupKeyNativeDelegate LookupKeyVMCallback
		{
			get
			{
				if (Keymap.LookupKey_cb_delegate == null)
				{
					Keymap.LookupKey_cb_delegate = new Keymap.LookupKeyNativeDelegate(Keymap.LookupKey_cb);
				}
				return Keymap.LookupKey_cb_delegate;
			}
		}

		// Token: 0x060006B6 RID: 1718 RVA: 0x00013809 File Offset: 0x00011A09
		private static void OverrideLookupKey(GType gtype)
		{
			Keymap.OverrideLookupKey(gtype, Keymap.LookupKeyVMCallback);
		}

		// Token: 0x060006B7 RID: 1719 RVA: 0x00013818 File Offset: 0x00011A18
		private unsafe static void OverrideLookupKey(GType gtype, Keymap.LookupKeyNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Keymap.class_abi.GetFieldOffset("lookup_key");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060006B8 RID: 1720 RVA: 0x0001384C File Offset: 0x00011A4C
		private static uint LookupKey_cb(IntPtr inst, IntPtr key)
		{
			uint result;
			try
			{
				result = (Object.GetObject(inst, false) as Keymap).OnLookupKey(KeymapKey.New(key));
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060006B9 RID: 1721 RVA: 0x0001388C File Offset: 0x00011A8C
		[DefaultSignalHandler(Type = typeof(Keymap), ConnectionMethod = "OverrideLookupKey")]
		protected virtual uint OnLookupKey(KeymapKey key)
		{
			return this.InternalLookupKey(key);
		}

		// Token: 0x060006BA RID: 1722 RVA: 0x00013898 File Offset: 0x00011A98
		private uint InternalLookupKey(KeymapKey key)
		{
			Keymap.LookupKeyNativeDelegate lookupKeyNativeDelegate = Keymap.class_abi.BaseOverride(base.LookupGType(), "lookup_key");
			if (lookupKeyNativeDelegate == null)
			{
				return 0U;
			}
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(key);
			uint result = lookupKeyNativeDelegate(base.Handle, intPtr);
			Marshal.FreeHGlobal(intPtr);
			return result;
		}

		// Token: 0x170001BA RID: 442
		// (get) Token: 0x060006BB RID: 1723 RVA: 0x000138DF File Offset: 0x00011ADF
		private static Keymap.TranslateKeyboardStateNativeDelegate TranslateKeyboardStateVMCallback
		{
			get
			{
				if (Keymap.TranslateKeyboardState_cb_delegate == null)
				{
					Keymap.TranslateKeyboardState_cb_delegate = new Keymap.TranslateKeyboardStateNativeDelegate(Keymap.TranslateKeyboardState_cb);
				}
				return Keymap.TranslateKeyboardState_cb_delegate;
			}
		}

		// Token: 0x060006BC RID: 1724 RVA: 0x000138FE File Offset: 0x00011AFE
		private static void OverrideTranslateKeyboardState(GType gtype)
		{
			Keymap.OverrideTranslateKeyboardState(gtype, Keymap.TranslateKeyboardStateVMCallback);
		}

		// Token: 0x060006BD RID: 1725 RVA: 0x0001390C File Offset: 0x00011B0C
		private unsafe static void OverrideTranslateKeyboardState(GType gtype, Keymap.TranslateKeyboardStateNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Keymap.class_abi.GetFieldOffset("translate_keyboard_state");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060006BE RID: 1726 RVA: 0x00013940 File Offset: 0x00011B40
		private static bool TranslateKeyboardState_cb(IntPtr inst, uint hardware_keycode, int state, int group, out uint keyval, out int effective_group, out int level, out int consumed_modifiers)
		{
			bool result;
			try
			{
				ModifierType modifierType;
				bool flag = (Object.GetObject(inst, false) as Keymap).OnTranslateKeyboardState(hardware_keycode, (ModifierType)state, group, out keyval, out effective_group, out level, out modifierType);
				consumed_modifiers = (int)modifierType;
				result = flag;
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060006BF RID: 1727 RVA: 0x0001398C File Offset: 0x00011B8C
		[DefaultSignalHandler(Type = typeof(Keymap), ConnectionMethod = "OverrideTranslateKeyboardState")]
		protected virtual bool OnTranslateKeyboardState(uint hardware_keycode, ModifierType state, int group, out uint keyval, out int effective_group, out int level, out ModifierType consumed_modifiers)
		{
			return this.InternalTranslateKeyboardState(hardware_keycode, state, group, out keyval, out effective_group, out level, out consumed_modifiers);
		}

		// Token: 0x060006C0 RID: 1728 RVA: 0x000139A0 File Offset: 0x00011BA0
		private bool InternalTranslateKeyboardState(uint hardware_keycode, ModifierType state, int group, out uint keyval, out int effective_group, out int level, out ModifierType consumed_modifiers)
		{
			Keymap.TranslateKeyboardStateNativeDelegate translateKeyboardStateNativeDelegate = Keymap.class_abi.BaseOverride(base.LookupGType(), "translate_keyboard_state");
			if (translateKeyboardStateNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			int num;
			bool result = translateKeyboardStateNativeDelegate(base.Handle, hardware_keycode, (int)state, group, out keyval, out effective_group, out level, out num);
			consumed_modifiers = (ModifierType)num;
			return result;
		}

		// Token: 0x170001BB RID: 443
		// (get) Token: 0x060006C1 RID: 1729 RVA: 0x000139EA File Offset: 0x00011BEA
		private static Keymap.AddVirtualModifiersNativeDelegate AddVirtualModifiersVMCallback
		{
			get
			{
				if (Keymap.AddVirtualModifiers_cb_delegate == null)
				{
					Keymap.AddVirtualModifiers_cb_delegate = new Keymap.AddVirtualModifiersNativeDelegate(Keymap.AddVirtualModifiers_cb);
				}
				return Keymap.AddVirtualModifiers_cb_delegate;
			}
		}

		// Token: 0x060006C2 RID: 1730 RVA: 0x00013A09 File Offset: 0x00011C09
		private static void OverrideAddVirtualModifiers(GType gtype)
		{
			Keymap.OverrideAddVirtualModifiers(gtype, Keymap.AddVirtualModifiersVMCallback);
		}

		// Token: 0x060006C3 RID: 1731 RVA: 0x00013A18 File Offset: 0x00011C18
		private unsafe static void OverrideAddVirtualModifiers(GType gtype, Keymap.AddVirtualModifiersNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Keymap.class_abi.GetFieldOffset("add_virtual_modifiers");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060006C4 RID: 1732 RVA: 0x00013A4C File Offset: 0x00011C4C
		private static void AddVirtualModifiers_cb(IntPtr inst, out int state)
		{
			try
			{
				ModifierType modifierType;
				(Object.GetObject(inst, false) as Keymap).OnAddVirtualModifiers(out modifierType);
				state = (int)modifierType;
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
		}

		// Token: 0x060006C5 RID: 1733 RVA: 0x00013A8C File Offset: 0x00011C8C
		[DefaultSignalHandler(Type = typeof(Keymap), ConnectionMethod = "OverrideAddVirtualModifiers")]
		protected virtual void OnAddVirtualModifiers(out ModifierType state)
		{
			this.InternalAddVirtualModifiers(out state);
		}

		// Token: 0x060006C6 RID: 1734 RVA: 0x00013A98 File Offset: 0x00011C98
		private void InternalAddVirtualModifiers(out ModifierType state)
		{
			Keymap.AddVirtualModifiersNativeDelegate addVirtualModifiersNativeDelegate = Keymap.class_abi.BaseOverride(base.LookupGType(), "add_virtual_modifiers");
			if (addVirtualModifiersNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			int num;
			addVirtualModifiersNativeDelegate(base.Handle, out num);
			state = (ModifierType)num;
		}

		// Token: 0x170001BC RID: 444
		// (get) Token: 0x060006C7 RID: 1735 RVA: 0x00013AD8 File Offset: 0x00011CD8
		private static Keymap.MapVirtualModifiersNativeDelegate MapVirtualModifiersVMCallback
		{
			get
			{
				if (Keymap.MapVirtualModifiers_cb_delegate == null)
				{
					Keymap.MapVirtualModifiers_cb_delegate = new Keymap.MapVirtualModifiersNativeDelegate(Keymap.MapVirtualModifiers_cb);
				}
				return Keymap.MapVirtualModifiers_cb_delegate;
			}
		}

		// Token: 0x060006C8 RID: 1736 RVA: 0x00013AF7 File Offset: 0x00011CF7
		private static void OverrideMapVirtualModifiers(GType gtype)
		{
			Keymap.OverrideMapVirtualModifiers(gtype, Keymap.MapVirtualModifiersVMCallback);
		}

		// Token: 0x060006C9 RID: 1737 RVA: 0x00013B04 File Offset: 0x00011D04
		private unsafe static void OverrideMapVirtualModifiers(GType gtype, Keymap.MapVirtualModifiersNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Keymap.class_abi.GetFieldOffset("map_virtual_modifiers");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060006CA RID: 1738 RVA: 0x00013B38 File Offset: 0x00011D38
		private static bool MapVirtualModifiers_cb(IntPtr inst, out int state)
		{
			bool result;
			try
			{
				ModifierType modifierType;
				bool flag = (Object.GetObject(inst, false) as Keymap).OnMapVirtualModifiers(out modifierType);
				state = (int)modifierType;
				result = flag;
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060006CB RID: 1739 RVA: 0x00013B78 File Offset: 0x00011D78
		[DefaultSignalHandler(Type = typeof(Keymap), ConnectionMethod = "OverrideMapVirtualModifiers")]
		protected virtual bool OnMapVirtualModifiers(out ModifierType state)
		{
			return this.InternalMapVirtualModifiers(out state);
		}

		// Token: 0x060006CC RID: 1740 RVA: 0x00013B84 File Offset: 0x00011D84
		private bool InternalMapVirtualModifiers(out ModifierType state)
		{
			Keymap.MapVirtualModifiersNativeDelegate mapVirtualModifiersNativeDelegate = Keymap.class_abi.BaseOverride(base.LookupGType(), "map_virtual_modifiers");
			if (mapVirtualModifiersNativeDelegate == null)
			{
				throw new InvalidOperationException("No base method to invoke");
			}
			int num;
			bool result = mapVirtualModifiersNativeDelegate(base.Handle, out num);
			state = (ModifierType)num;
			return result;
		}

		// Token: 0x170001BD RID: 445
		// (get) Token: 0x060006CD RID: 1741 RVA: 0x00013BC4 File Offset: 0x00011DC4
		private static Keymap.GetModifierMaskNativeDelegate GetModifierMaskVMCallback
		{
			get
			{
				if (Keymap.GetModifierMask_cb_delegate == null)
				{
					Keymap.GetModifierMask_cb_delegate = new Keymap.GetModifierMaskNativeDelegate(Keymap.GetModifierMask_cb);
				}
				return Keymap.GetModifierMask_cb_delegate;
			}
		}

		// Token: 0x060006CE RID: 1742 RVA: 0x00013BE3 File Offset: 0x00011DE3
		private static void OverrideGetModifierMask(GType gtype)
		{
			Keymap.OverrideGetModifierMask(gtype, Keymap.GetModifierMaskVMCallback);
		}

		// Token: 0x060006CF RID: 1743 RVA: 0x00013BF0 File Offset: 0x00011DF0
		private unsafe static void OverrideGetModifierMask(GType gtype, Keymap.GetModifierMaskNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Keymap.class_abi.GetFieldOffset("get_modifier_mask");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060006D0 RID: 1744 RVA: 0x00013C24 File Offset: 0x00011E24
		private static int GetModifierMask_cb(IntPtr inst, int intent)
		{
			int result;
			try
			{
				result = (int)(Object.GetObject(inst, false) as Keymap).OnGetModifierMask((ModifierIntent)intent);
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060006D1 RID: 1745 RVA: 0x00013C60 File Offset: 0x00011E60
		[DefaultSignalHandler(Type = typeof(Keymap), ConnectionMethod = "OverrideGetModifierMask")]
		protected virtual ModifierType OnGetModifierMask(ModifierIntent intent)
		{
			return this.InternalGetModifierMask(intent);
		}

		// Token: 0x060006D2 RID: 1746 RVA: 0x00013C6C File Offset: 0x00011E6C
		private ModifierType InternalGetModifierMask(ModifierIntent intent)
		{
			Keymap.GetModifierMaskNativeDelegate getModifierMaskNativeDelegate = Keymap.class_abi.BaseOverride(base.LookupGType(), "get_modifier_mask");
			if (getModifierMaskNativeDelegate == null)
			{
				return ModifierType.None;
			}
			return (ModifierType)getModifierMaskNativeDelegate(base.Handle, (int)intent);
		}

		// Token: 0x170001BE RID: 446
		// (get) Token: 0x060006D3 RID: 1747 RVA: 0x00013CA1 File Offset: 0x00011EA1
		private static Keymap.GetModifierStateNativeDelegate GetModifierStateVMCallback
		{
			get
			{
				if (Keymap.GetModifierState_cb_delegate == null)
				{
					Keymap.GetModifierState_cb_delegate = new Keymap.GetModifierStateNativeDelegate(Keymap.GetModifierState_cb);
				}
				return Keymap.GetModifierState_cb_delegate;
			}
		}

		// Token: 0x060006D4 RID: 1748 RVA: 0x00013CC0 File Offset: 0x00011EC0
		private static void OverrideGetModifierState(GType gtype)
		{
			Keymap.OverrideGetModifierState(gtype, Keymap.GetModifierStateVMCallback);
		}

		// Token: 0x060006D5 RID: 1749 RVA: 0x00013CD0 File Offset: 0x00011ED0
		private unsafe static void OverrideGetModifierState(GType gtype, Keymap.GetModifierStateNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Keymap.class_abi.GetFieldOffset("get_modifier_state");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060006D6 RID: 1750 RVA: 0x00013D04 File Offset: 0x00011F04
		private static uint GetModifierState_cb(IntPtr inst)
		{
			uint result;
			try
			{
				result = (Object.GetObject(inst, false) as Keymap).OnGetModifierState();
			}
			catch (Exception ex)
			{
				ExceptionManager.RaiseUnhandledException(ex, true);
				throw ex;
			}
			return result;
		}

		// Token: 0x060006D7 RID: 1751 RVA: 0x00013D40 File Offset: 0x00011F40
		[DefaultSignalHandler(Type = typeof(Keymap), ConnectionMethod = "OverrideGetModifierState")]
		protected virtual uint OnGetModifierState()
		{
			return this.InternalGetModifierState();
		}

		// Token: 0x060006D8 RID: 1752 RVA: 0x00013D48 File Offset: 0x00011F48
		private uint InternalGetModifierState()
		{
			Keymap.GetModifierStateNativeDelegate getModifierStateNativeDelegate = Keymap.class_abi.BaseOverride(base.LookupGType(), "get_modifier_state");
			if (getModifierStateNativeDelegate == null)
			{
				return 0U;
			}
			return getModifierStateNativeDelegate(base.Handle);
		}

		// Token: 0x170001BF RID: 447
		// (get) Token: 0x060006D9 RID: 1753 RVA: 0x00013D7C File Offset: 0x00011F7C
		private static Keymap.DirectionChangedNativeDelegate DirectionChangedVMCallback
		{
			get
			{
				if (Keymap.DirectionChanged_cb_delegate == null)
				{
					Keymap.DirectionChanged_cb_delegate = new Keymap.DirectionChangedNativeDelegate(Keymap.DirectionChanged_cb);
				}
				return Keymap.DirectionChanged_cb_delegate;
			}
		}

		// Token: 0x060006DA RID: 1754 RVA: 0x00013D9B File Offset: 0x00011F9B
		private static void OverrideDirectionChanged(GType gtype)
		{
			Keymap.OverrideDirectionChanged(gtype, Keymap.DirectionChangedVMCallback);
		}

		// Token: 0x060006DB RID: 1755 RVA: 0x00013DA8 File Offset: 0x00011FA8
		private unsafe static void OverrideDirectionChanged(GType gtype, Keymap.DirectionChangedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Keymap.class_abi.GetFieldOffset("direction_changed");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060006DC RID: 1756 RVA: 0x00013DDC File Offset: 0x00011FDC
		private static void DirectionChanged_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Keymap).OnDirectionChanged();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060006DD RID: 1757 RVA: 0x00013E14 File Offset: 0x00012014
		[DefaultSignalHandler(Type = typeof(Keymap), ConnectionMethod = "OverrideDirectionChanged")]
		protected virtual void OnDirectionChanged()
		{
			this.InternalDirectionChanged();
		}

		// Token: 0x060006DE RID: 1758 RVA: 0x00013E1C File Offset: 0x0001201C
		private void InternalDirectionChanged()
		{
			Keymap.DirectionChangedNativeDelegate directionChangedNativeDelegate = Keymap.class_abi.BaseOverride(base.LookupGType(), "direction_changed");
			if (directionChangedNativeDelegate == null)
			{
				return;
			}
			directionChangedNativeDelegate(base.Handle);
		}

		// Token: 0x170001C0 RID: 448
		// (get) Token: 0x060006DF RID: 1759 RVA: 0x00013E4F File Offset: 0x0001204F
		private static Keymap.KeysChangedNativeDelegate KeysChangedVMCallback
		{
			get
			{
				if (Keymap.KeysChanged_cb_delegate == null)
				{
					Keymap.KeysChanged_cb_delegate = new Keymap.KeysChangedNativeDelegate(Keymap.KeysChanged_cb);
				}
				return Keymap.KeysChanged_cb_delegate;
			}
		}

		// Token: 0x060006E0 RID: 1760 RVA: 0x00013E6E File Offset: 0x0001206E
		private static void OverrideKeysChanged(GType gtype)
		{
			Keymap.OverrideKeysChanged(gtype, Keymap.KeysChangedVMCallback);
		}

		// Token: 0x060006E1 RID: 1761 RVA: 0x00013E7C File Offset: 0x0001207C
		private unsafe static void OverrideKeysChanged(GType gtype, Keymap.KeysChangedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Keymap.class_abi.GetFieldOffset("keys_changed");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060006E2 RID: 1762 RVA: 0x00013EB0 File Offset: 0x000120B0
		private static void KeysChanged_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Keymap).OnKeysChanged();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060006E3 RID: 1763 RVA: 0x00013EE8 File Offset: 0x000120E8
		[DefaultSignalHandler(Type = typeof(Keymap), ConnectionMethod = "OverrideKeysChanged")]
		protected virtual void OnKeysChanged()
		{
			this.InternalKeysChanged();
		}

		// Token: 0x060006E4 RID: 1764 RVA: 0x00013EF0 File Offset: 0x000120F0
		private void InternalKeysChanged()
		{
			Keymap.KeysChangedNativeDelegate keysChangedNativeDelegate = Keymap.class_abi.BaseOverride(base.LookupGType(), "keys_changed");
			if (keysChangedNativeDelegate == null)
			{
				return;
			}
			keysChangedNativeDelegate(base.Handle);
		}

		// Token: 0x170001C1 RID: 449
		// (get) Token: 0x060006E5 RID: 1765 RVA: 0x00013F23 File Offset: 0x00012123
		private static Keymap.StateChangedNativeDelegate StateChangedVMCallback
		{
			get
			{
				if (Keymap.StateChanged_cb_delegate == null)
				{
					Keymap.StateChanged_cb_delegate = new Keymap.StateChangedNativeDelegate(Keymap.StateChanged_cb);
				}
				return Keymap.StateChanged_cb_delegate;
			}
		}

		// Token: 0x060006E6 RID: 1766 RVA: 0x00013F42 File Offset: 0x00012142
		private static void OverrideStateChanged(GType gtype)
		{
			Keymap.OverrideStateChanged(gtype, Keymap.StateChangedVMCallback);
		}

		// Token: 0x060006E7 RID: 1767 RVA: 0x00013F50 File Offset: 0x00012150
		private unsafe static void OverrideStateChanged(GType gtype, Keymap.StateChangedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + Keymap.class_abi.GetFieldOffset("state_changed");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x060006E8 RID: 1768 RVA: 0x00013F84 File Offset: 0x00012184
		private static void StateChanged_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as Keymap).OnStateChanged();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x060006E9 RID: 1769 RVA: 0x00013FBC File Offset: 0x000121BC
		[DefaultSignalHandler(Type = typeof(Keymap), ConnectionMethod = "OverrideStateChanged")]
		protected virtual void OnStateChanged()
		{
			this.InternalStateChanged();
		}

		// Token: 0x060006EA RID: 1770 RVA: 0x00013FC4 File Offset: 0x000121C4
		private void InternalStateChanged()
		{
			Keymap.StateChangedNativeDelegate stateChangedNativeDelegate = Keymap.class_abi.BaseOverride(base.LookupGType(), "state_changed");
			if (stateChangedNativeDelegate == null)
			{
				return;
			}
			stateChangedNativeDelegate(base.Handle);
		}

		// Token: 0x170001C2 RID: 450
		// (get) Token: 0x060006EB RID: 1771 RVA: 0x00013FF8 File Offset: 0x000121F8
		public new static AbiStruct class_abi
		{
			get
			{
				if (Keymap._class_abi == null)
				{
					Keymap._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("get_direction", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "have_bidi_layouts", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("have_bidi_layouts", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_direction", "get_caps_lock_state", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_caps_lock_state", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "have_bidi_layouts", "get_num_lock_state", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_num_lock_state", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_caps_lock_state", "get_scroll_lock_state", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_scroll_lock_state", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_num_lock_state", "get_entries_for_keyval", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_entries_for_keyval", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_scroll_lock_state", "get_entries_for_keycode", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_entries_for_keycode", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_entries_for_keyval", "lookup_key", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("lookup_key", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_entries_for_keycode", "translate_keyboard_state", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("translate_keyboard_state", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "lookup_key", "add_virtual_modifiers", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("add_virtual_modifiers", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "translate_keyboard_state", "map_virtual_modifiers", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("map_virtual_modifiers", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "add_virtual_modifiers", "get_modifier_mask", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_modifier_mask", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "map_virtual_modifiers", "get_modifier_state", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("get_modifier_state", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_modifier_mask", "direction_changed", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("direction_changed", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "get_modifier_state", "keys_changed", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("keys_changed", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "direction_changed", "state_changed", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("state_changed", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "keys_changed", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return Keymap._class_abi;
			}
		}

		// Token: 0x060006EC RID: 1772 RVA: 0x000143E4 File Offset: 0x000125E4
		public ModifierType AddVirtualModifiers()
		{
			int result;
			Keymap.gdk_keymap_add_virtual_modifiers(base.Handle, out result);
			return (ModifierType)result;
		}

		// Token: 0x170001C3 RID: 451
		// (get) Token: 0x060006ED RID: 1773 RVA: 0x00014404 File Offset: 0x00012604
		public bool CapsLockState
		{
			get
			{
				return Keymap.gdk_keymap_get_caps_lock_state(base.Handle);
			}
		}

		// Token: 0x170001C4 RID: 452
		// (get) Token: 0x060006EE RID: 1774 RVA: 0x00014416 File Offset: 0x00012616
		public static Keymap Default
		{
			get
			{
				return Object.GetObject(Keymap.gdk_keymap_get_default()) as Keymap;
			}
		}

		// Token: 0x170001C5 RID: 453
		// (get) Token: 0x060006EF RID: 1775 RVA: 0x0001442C File Offset: 0x0001262C
		public Direction Direction
		{
			get
			{
				return (Direction)Keymap.gdk_keymap_get_direction(base.Handle);
			}
		}

		// Token: 0x060006F0 RID: 1776 RVA: 0x0001443E File Offset: 0x0001263E
		public static Keymap GetForDisplay(Display display)
		{
			return Object.GetObject(Keymap.gdk_keymap_get_for_display((display == null) ? IntPtr.Zero : display.Handle)) as Keymap;
		}

		// Token: 0x060006F1 RID: 1777 RVA: 0x00014464 File Offset: 0x00012664
		public ModifierType GetModifierMask(ModifierIntent intent)
		{
			return (ModifierType)Keymap.gdk_keymap_get_modifier_mask(base.Handle, (int)intent);
		}

		// Token: 0x170001C6 RID: 454
		// (get) Token: 0x060006F2 RID: 1778 RVA: 0x00014477 File Offset: 0x00012677
		public uint ModifierState
		{
			get
			{
				return Keymap.gdk_keymap_get_modifier_state(base.Handle);
			}
		}

		// Token: 0x170001C7 RID: 455
		// (get) Token: 0x060006F3 RID: 1779 RVA: 0x00014489 File Offset: 0x00012689
		public bool NumLockState
		{
			get
			{
				return Keymap.gdk_keymap_get_num_lock_state(base.Handle);
			}
		}

		// Token: 0x170001C8 RID: 456
		// (get) Token: 0x060006F4 RID: 1780 RVA: 0x0001449B File Offset: 0x0001269B
		public bool ScrollLockState
		{
			get
			{
				return Keymap.gdk_keymap_get_scroll_lock_state(base.Handle);
			}
		}

		// Token: 0x170001C9 RID: 457
		// (get) Token: 0x060006F5 RID: 1781 RVA: 0x000144B0 File Offset: 0x000126B0
		public new static GType GType
		{
			get
			{
				IntPtr val = Keymap.gdk_keymap_get_type();
				return new GType(val);
			}
		}

		// Token: 0x060006F6 RID: 1782 RVA: 0x000144CE File Offset: 0x000126CE
		public bool HaveBidiLayouts()
		{
			return Keymap.gdk_keymap_have_bidi_layouts(base.Handle);
		}

		// Token: 0x060006F7 RID: 1783 RVA: 0x000144E0 File Offset: 0x000126E0
		public uint LookupKey(KeymapKey key)
		{
			IntPtr intPtr = Marshaller.StructureToPtrAlloc(key);
			uint result = Keymap.gdk_keymap_lookup_key(base.Handle, intPtr);
			Marshal.FreeHGlobal(intPtr);
			return result;
		}

		// Token: 0x060006F8 RID: 1784 RVA: 0x00014510 File Offset: 0x00012710
		public bool MapVirtualModifiers(out ModifierType state)
		{
			int num;
			bool result = Keymap.gdk_keymap_map_virtual_modifiers(base.Handle, out num);
			state = (ModifierType)num;
			return result;
		}

		// Token: 0x060006F9 RID: 1785 RVA: 0x00014534 File Offset: 0x00012734
		public bool TranslateKeyboardState(uint hardware_keycode, ModifierType state, int group, out uint keyval, out int effective_group, out int level, out ModifierType consumed_modifiers)
		{
			int num;
			bool result = Keymap.gdk_keymap_translate_keyboard_state(base.Handle, hardware_keycode, (int)state, group, out keyval, out effective_group, out level, out num);
			consumed_modifiers = (ModifierType)num;
			return result;
		}

		// Token: 0x170001CA RID: 458
		// (get) Token: 0x060006FA RID: 1786 RVA: 0x00014560 File Offset: 0x00012760
		public new static AbiStruct abi_info
		{
			get
			{
				if (Keymap._abi_info == null)
				{
					Keymap._abi_info = new AbiStruct(Object.abi_info.Fields);
				}
				return Keymap._abi_info;
			}
		}

		// Token: 0x060006FB RID: 1787 RVA: 0x00014584 File Offset: 0x00012784
		public void GetEntriesForKeycode(uint hardware_keycode, out KeymapKey[] keys, out uint[] keyvals)
		{
			IntPtr intPtr;
			IntPtr intPtr2;
			int num;
			if (Keymap.gdk_keymap_get_entries_for_keycode(base.Handle, hardware_keycode, out intPtr, out intPtr2, out num))
			{
				keys = new KeymapKey[num];
				keyvals = new uint[num];
				int[] array = new int[num];
				Marshal.Copy(intPtr2, array, 0, num);
				for (int i = 0; i < num; i++)
				{
					IntPtr raw = new IntPtr((long)intPtr + (long)(i * Marshal.SizeOf(typeof(KeymapKey))));
					keyvals[i] = (uint)array[i];
					keys[i] = KeymapKey.New(raw);
				}
				Marshaller.Free(intPtr);
				Marshaller.Free(intPtr2);
				return;
			}
			keys = new KeymapKey[0];
			keyvals = new uint[0];
		}

		// Token: 0x060006FC RID: 1788 RVA: 0x00014634 File Offset: 0x00012834
		public KeymapKey[] GetEntriesForKeyval(uint keyval)
		{
			IntPtr intPtr;
			int num;
			if (Keymap.gdk_keymap_get_entries_for_keyval(base.Handle, keyval, out intPtr, out num))
			{
				KeymapKey[] array = new KeymapKey[num];
				for (int i = 0; i < num; i++)
				{
					IntPtr raw = new IntPtr((long)intPtr + (long)(i * Marshal.SizeOf(typeof(KeymapKey))));
					array[i] = KeymapKey.New(raw);
				}
				Marshaller.Free(intPtr);
				return array;
			}
			return new KeymapKey[0];
		}

		// Token: 0x04000397 RID: 919
		private static Keymap.GetDirectionNativeDelegate GetDirection_cb_delegate;

		// Token: 0x04000398 RID: 920
		private static Keymap.HaveBidiLayoutsNativeDelegate HaveBidiLayouts_cb_delegate;

		// Token: 0x04000399 RID: 921
		private static Keymap.GetCapsLockStateNativeDelegate GetCapsLockState_cb_delegate;

		// Token: 0x0400039A RID: 922
		private static Keymap.GetNumLockStateNativeDelegate GetNumLockState_cb_delegate;

		// Token: 0x0400039B RID: 923
		private static Keymap.GetScrollLockStateNativeDelegate GetScrollLockState_cb_delegate;

		// Token: 0x0400039C RID: 924
		private static Keymap.GetEntriesForKeyvalNativeDelegate GetEntriesForKeyval_cb_delegate;

		// Token: 0x0400039D RID: 925
		private static Keymap.GetEntriesForKeycodeNativeDelegate GetEntriesForKeycode_cb_delegate;

		// Token: 0x0400039E RID: 926
		private static Keymap.LookupKeyNativeDelegate LookupKey_cb_delegate;

		// Token: 0x0400039F RID: 927
		private static Keymap.TranslateKeyboardStateNativeDelegate TranslateKeyboardState_cb_delegate;

		// Token: 0x040003A0 RID: 928
		private static Keymap.AddVirtualModifiersNativeDelegate AddVirtualModifiers_cb_delegate;

		// Token: 0x040003A1 RID: 929
		private static Keymap.MapVirtualModifiersNativeDelegate MapVirtualModifiers_cb_delegate;

		// Token: 0x040003A2 RID: 930
		private static Keymap.GetModifierMaskNativeDelegate GetModifierMask_cb_delegate;

		// Token: 0x040003A3 RID: 931
		private static Keymap.GetModifierStateNativeDelegate GetModifierState_cb_delegate;

		// Token: 0x040003A4 RID: 932
		private static Keymap.DirectionChangedNativeDelegate DirectionChanged_cb_delegate;

		// Token: 0x040003A5 RID: 933
		private static Keymap.KeysChangedNativeDelegate KeysChanged_cb_delegate;

		// Token: 0x040003A6 RID: 934
		private static Keymap.StateChangedNativeDelegate StateChanged_cb_delegate;

		// Token: 0x040003A7 RID: 935
		private static AbiStruct _class_abi = null;

		// Token: 0x040003A8 RID: 936
		private static Keymap.d_gdk_keymap_add_virtual_modifiers gdk_keymap_add_virtual_modifiers = FuncLoader.LoadFunction<Keymap.d_gdk_keymap_add_virtual_modifiers>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keymap_add_virtual_modifiers"));

		// Token: 0x040003A9 RID: 937
		private static Keymap.d_gdk_keymap_get_caps_lock_state gdk_keymap_get_caps_lock_state = FuncLoader.LoadFunction<Keymap.d_gdk_keymap_get_caps_lock_state>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keymap_get_caps_lock_state"));

		// Token: 0x040003AA RID: 938
		private static Keymap.d_gdk_keymap_get_default gdk_keymap_get_default = FuncLoader.LoadFunction<Keymap.d_gdk_keymap_get_default>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keymap_get_default"));

		// Token: 0x040003AB RID: 939
		private static Keymap.d_gdk_keymap_get_direction gdk_keymap_get_direction = FuncLoader.LoadFunction<Keymap.d_gdk_keymap_get_direction>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keymap_get_direction"));

		// Token: 0x040003AC RID: 940
		private static Keymap.d_gdk_keymap_get_for_display gdk_keymap_get_for_display = FuncLoader.LoadFunction<Keymap.d_gdk_keymap_get_for_display>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keymap_get_for_display"));

		// Token: 0x040003AD RID: 941
		private static Keymap.d_gdk_keymap_get_modifier_mask gdk_keymap_get_modifier_mask = FuncLoader.LoadFunction<Keymap.d_gdk_keymap_get_modifier_mask>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keymap_get_modifier_mask"));

		// Token: 0x040003AE RID: 942
		private static Keymap.d_gdk_keymap_get_modifier_state gdk_keymap_get_modifier_state = FuncLoader.LoadFunction<Keymap.d_gdk_keymap_get_modifier_state>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keymap_get_modifier_state"));

		// Token: 0x040003AF RID: 943
		private static Keymap.d_gdk_keymap_get_num_lock_state gdk_keymap_get_num_lock_state = FuncLoader.LoadFunction<Keymap.d_gdk_keymap_get_num_lock_state>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keymap_get_num_lock_state"));

		// Token: 0x040003B0 RID: 944
		private static Keymap.d_gdk_keymap_get_scroll_lock_state gdk_keymap_get_scroll_lock_state = FuncLoader.LoadFunction<Keymap.d_gdk_keymap_get_scroll_lock_state>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keymap_get_scroll_lock_state"));

		// Token: 0x040003B1 RID: 945
		private static Keymap.d_gdk_keymap_get_type gdk_keymap_get_type = FuncLoader.LoadFunction<Keymap.d_gdk_keymap_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keymap_get_type"));

		// Token: 0x040003B2 RID: 946
		private static Keymap.d_gdk_keymap_have_bidi_layouts gdk_keymap_have_bidi_layouts = FuncLoader.LoadFunction<Keymap.d_gdk_keymap_have_bidi_layouts>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keymap_have_bidi_layouts"));

		// Token: 0x040003B3 RID: 947
		private static Keymap.d_gdk_keymap_lookup_key gdk_keymap_lookup_key = FuncLoader.LoadFunction<Keymap.d_gdk_keymap_lookup_key>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keymap_lookup_key"));

		// Token: 0x040003B4 RID: 948
		private static Keymap.d_gdk_keymap_map_virtual_modifiers gdk_keymap_map_virtual_modifiers = FuncLoader.LoadFunction<Keymap.d_gdk_keymap_map_virtual_modifiers>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keymap_map_virtual_modifiers"));

		// Token: 0x040003B5 RID: 949
		private static Keymap.d_gdk_keymap_translate_keyboard_state gdk_keymap_translate_keyboard_state = FuncLoader.LoadFunction<Keymap.d_gdk_keymap_translate_keyboard_state>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keymap_translate_keyboard_state"));

		// Token: 0x040003B6 RID: 950
		private static AbiStruct _abi_info = null;

		// Token: 0x040003B7 RID: 951
		private static Keymap.d_gdk_keymap_get_entries_for_keycode gdk_keymap_get_entries_for_keycode = FuncLoader.LoadFunction<Keymap.d_gdk_keymap_get_entries_for_keycode>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keymap_get_entries_for_keycode"));

		// Token: 0x040003B8 RID: 952
		private static Keymap.d_gdk_keymap_get_entries_for_keyval gdk_keymap_get_entries_for_keyval = FuncLoader.LoadFunction<Keymap.d_gdk_keymap_get_entries_for_keyval>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_keymap_get_entries_for_keyval"));

		// Token: 0x020002E0 RID: 736
		// (Invoke) Token: 0x06001205 RID: 4613
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetDirectionNativeDelegate(IntPtr inst);

		// Token: 0x020002E1 RID: 737
		// (Invoke) Token: 0x06001209 RID: 4617
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool HaveBidiLayoutsNativeDelegate(IntPtr inst);

		// Token: 0x020002E2 RID: 738
		// (Invoke) Token: 0x0600120D RID: 4621
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool GetCapsLockStateNativeDelegate(IntPtr inst);

		// Token: 0x020002E3 RID: 739
		// (Invoke) Token: 0x06001211 RID: 4625
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool GetNumLockStateNativeDelegate(IntPtr inst);

		// Token: 0x020002E4 RID: 740
		// (Invoke) Token: 0x06001215 RID: 4629
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool GetScrollLockStateNativeDelegate(IntPtr inst);

		// Token: 0x020002E5 RID: 741
		// (Invoke) Token: 0x06001219 RID: 4633
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool GetEntriesForKeyvalNativeDelegate(IntPtr inst, uint keyval, IntPtr keys, out int n_keys);

		// Token: 0x020002E6 RID: 742
		// (Invoke) Token: 0x0600121D RID: 4637
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool GetEntriesForKeycodeNativeDelegate(IntPtr inst, uint hardware_keycode, IntPtr keys, out uint keyvals, out int n_entries);

		// Token: 0x020002E7 RID: 743
		// (Invoke) Token: 0x06001221 RID: 4641
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint LookupKeyNativeDelegate(IntPtr inst, IntPtr key);

		// Token: 0x020002E8 RID: 744
		// (Invoke) Token: 0x06001225 RID: 4645
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool TranslateKeyboardStateNativeDelegate(IntPtr inst, uint hardware_keycode, int state, int group, out uint keyval, out int effective_group, out int level, out int consumed_modifiers);

		// Token: 0x020002E9 RID: 745
		// (Invoke) Token: 0x06001229 RID: 4649
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void AddVirtualModifiersNativeDelegate(IntPtr inst, out int state);

		// Token: 0x020002EA RID: 746
		// (Invoke) Token: 0x0600122D RID: 4653
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool MapVirtualModifiersNativeDelegate(IntPtr inst, out int state);

		// Token: 0x020002EB RID: 747
		// (Invoke) Token: 0x06001231 RID: 4657
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int GetModifierMaskNativeDelegate(IntPtr inst, int intent);

		// Token: 0x020002EC RID: 748
		// (Invoke) Token: 0x06001235 RID: 4661
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint GetModifierStateNativeDelegate(IntPtr inst);

		// Token: 0x020002ED RID: 749
		// (Invoke) Token: 0x06001239 RID: 4665
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void DirectionChangedNativeDelegate(IntPtr inst);

		// Token: 0x020002EE RID: 750
		// (Invoke) Token: 0x0600123D RID: 4669
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void KeysChangedNativeDelegate(IntPtr inst);

		// Token: 0x020002EF RID: 751
		// (Invoke) Token: 0x06001241 RID: 4673
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void StateChangedNativeDelegate(IntPtr inst);

		// Token: 0x020002F0 RID: 752
		// (Invoke) Token: 0x06001245 RID: 4677
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_keymap_add_virtual_modifiers(IntPtr raw, out int state);

		// Token: 0x020002F1 RID: 753
		// (Invoke) Token: 0x06001249 RID: 4681
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_keymap_get_caps_lock_state(IntPtr raw);

		// Token: 0x020002F2 RID: 754
		// (Invoke) Token: 0x0600124D RID: 4685
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_keymap_get_default();

		// Token: 0x020002F3 RID: 755
		// (Invoke) Token: 0x06001251 RID: 4689
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_keymap_get_direction(IntPtr raw);

		// Token: 0x020002F4 RID: 756
		// (Invoke) Token: 0x06001255 RID: 4693
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_keymap_get_for_display(IntPtr display);

		// Token: 0x020002F5 RID: 757
		// (Invoke) Token: 0x06001259 RID: 4697
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_keymap_get_modifier_mask(IntPtr raw, int intent);

		// Token: 0x020002F6 RID: 758
		// (Invoke) Token: 0x0600125D RID: 4701
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gdk_keymap_get_modifier_state(IntPtr raw);

		// Token: 0x020002F7 RID: 759
		// (Invoke) Token: 0x06001261 RID: 4705
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_keymap_get_num_lock_state(IntPtr raw);

		// Token: 0x020002F8 RID: 760
		// (Invoke) Token: 0x06001265 RID: 4709
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_keymap_get_scroll_lock_state(IntPtr raw);

		// Token: 0x020002F9 RID: 761
		// (Invoke) Token: 0x06001269 RID: 4713
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_keymap_get_type();

		// Token: 0x020002FA RID: 762
		// (Invoke) Token: 0x0600126D RID: 4717
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_keymap_have_bidi_layouts(IntPtr raw);

		// Token: 0x020002FB RID: 763
		// (Invoke) Token: 0x06001271 RID: 4721
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gdk_keymap_lookup_key(IntPtr raw, IntPtr key);

		// Token: 0x020002FC RID: 764
		// (Invoke) Token: 0x06001275 RID: 4725
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_keymap_map_virtual_modifiers(IntPtr raw, out int state);

		// Token: 0x020002FD RID: 765
		// (Invoke) Token: 0x06001279 RID: 4729
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_keymap_translate_keyboard_state(IntPtr raw, uint hardware_keycode, int state, int group, out uint keyval, out int effective_group, out int level, out int consumed_modifiers);

		// Token: 0x020002FE RID: 766
		// (Invoke) Token: 0x0600127D RID: 4733
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_keymap_get_entries_for_keycode(IntPtr raw, uint hardware_keycode, out IntPtr keys, out IntPtr keyvals, out int n_entries);

		// Token: 0x020002FF RID: 767
		// (Invoke) Token: 0x06001281 RID: 4737
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_keymap_get_entries_for_keyval(IntPtr raw, uint keyval, out IntPtr keys, out int n_keys);
	}
}
