﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x020000AD RID: 173
	public class LoadContext : Opaque
	{
		// Token: 0x0600070E RID: 1806 RVA: 0x00014A95 File Offset: 0x00012C95
		public LoadContext(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170001CC RID: 460
		// (get) Token: 0x0600070F RID: 1807 RVA: 0x00014A9E File Offset: 0x00012C9E
		public static AbiStruct abi_info
		{
			get
			{
				if (LoadContext._abi_info == null)
				{
					LoadContext._abi_info = new AbiStruct(new List<AbiField>());
				}
				return LoadContext._abi_info;
			}
		}

		// Token: 0x040003C5 RID: 965
		private static AbiStruct _abi_info;
	}
}
