﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000056 RID: 86
	internal class CursorTypeGType
	{
		// Token: 0x17000107 RID: 263
		// (get) Token: 0x060003DE RID: 990 RVA: 0x0000C411 File Offset: 0x0000A611
		public static GType GType
		{
			get
			{
				return new GType(CursorTypeGType.gdk_cursor_type_get_type());
			}
		}

		// Token: 0x040001AF RID: 431
		private static CursorTypeGType.d_gdk_cursor_type_get_type gdk_cursor_type_get_type = FuncLoader.LoadFunction<CursorTypeGType.d_gdk_cursor_type_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_cursor_type_get_type"));

		// Token: 0x0200020F RID: 527
		// (Invoke) Token: 0x06000EC7 RID: 3783
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_cursor_type_get_type();
	}
}
