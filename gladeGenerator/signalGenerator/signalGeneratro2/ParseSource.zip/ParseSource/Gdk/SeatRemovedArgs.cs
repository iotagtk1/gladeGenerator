﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000F7 RID: 247
	public class SeatRemovedArgs : SignalArgs
	{
		// Token: 0x17000284 RID: 644
		// (get) Token: 0x060009F9 RID: 2553 RVA: 0x0001D7BA File Offset: 0x0001B9BA
		public Seat P0
		{
			get
			{
				return (Seat)base.Args[0];
			}
		}
	}
}
