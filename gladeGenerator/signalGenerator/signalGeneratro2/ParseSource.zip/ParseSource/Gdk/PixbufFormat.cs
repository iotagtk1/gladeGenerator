﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000CD RID: 205
	public class PixbufFormat : Opaque
	{
		// Token: 0x060007E8 RID: 2024 RVA: 0x00017920 File Offset: 0x00015B20
		public PixbufFormat Copy()
		{
			IntPtr intPtr = PixbufFormat.gdk_pixbuf_format_copy(base.Handle);
			if (!(intPtr == IntPtr.Zero))
			{
				return (PixbufFormat)Opaque.GetOpaque(intPtr, typeof(PixbufFormat), true);
			}
			return null;
		}

		// Token: 0x17000207 RID: 519
		// (get) Token: 0x060007E9 RID: 2025 RVA: 0x00017963 File Offset: 0x00015B63
		public string Description
		{
			get
			{
				return Marshaller.PtrToStringGFree(PixbufFormat.gdk_pixbuf_format_get_description(base.Handle));
			}
		}

		// Token: 0x17000208 RID: 520
		// (get) Token: 0x060007EA RID: 2026 RVA: 0x0001797A File Offset: 0x00015B7A
		public string[] Extensions
		{
			get
			{
				return Marshaller.NullTermPtrToStringArray(PixbufFormat.gdk_pixbuf_format_get_extensions(base.Handle), false);
			}
		}

		// Token: 0x17000209 RID: 521
		// (get) Token: 0x060007EB RID: 2027 RVA: 0x00017992 File Offset: 0x00015B92
		public string License
		{
			get
			{
				return Marshaller.PtrToStringGFree(PixbufFormat.gdk_pixbuf_format_get_license(base.Handle));
			}
		}

		// Token: 0x1700020A RID: 522
		// (get) Token: 0x060007EC RID: 2028 RVA: 0x000179A9 File Offset: 0x00015BA9
		public string[] MimeTypes
		{
			get
			{
				return Marshaller.NullTermPtrToStringArray(PixbufFormat.gdk_pixbuf_format_get_mime_types(base.Handle), false);
			}
		}

		// Token: 0x1700020B RID: 523
		// (get) Token: 0x060007ED RID: 2029 RVA: 0x000179C1 File Offset: 0x00015BC1
		public string Name
		{
			get
			{
				return Marshaller.PtrToStringGFree(PixbufFormat.gdk_pixbuf_format_get_name(base.Handle));
			}
		}

		// Token: 0x1700020C RID: 524
		// (get) Token: 0x060007EE RID: 2030 RVA: 0x000179D8 File Offset: 0x00015BD8
		public static GType GType
		{
			get
			{
				IntPtr val = PixbufFormat.gdk_pixbuf_format_get_type();
				return new GType(val);
			}
		}

		// Token: 0x1700020D RID: 525
		// (get) Token: 0x060007EF RID: 2031 RVA: 0x000179F6 File Offset: 0x00015BF6
		// (set) Token: 0x060007F0 RID: 2032 RVA: 0x00017A08 File Offset: 0x00015C08
		public bool Disabled
		{
			get
			{
				return PixbufFormat.gdk_pixbuf_format_is_disabled(base.Handle);
			}
			set
			{
				PixbufFormat.gdk_pixbuf_format_set_disabled(base.Handle, value);
			}
		}

		// Token: 0x060007F1 RID: 2033 RVA: 0x00017A1C File Offset: 0x00015C1C
		public bool IsSaveOptionSupported(string option_key)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(option_key);
			bool result = PixbufFormat.gdk_pixbuf_format_is_save_option_supported(base.Handle, intPtr);
			Marshaller.Free(intPtr);
			return result;
		}

		// Token: 0x1700020E RID: 526
		// (get) Token: 0x060007F2 RID: 2034 RVA: 0x00017A47 File Offset: 0x00015C47
		public bool IsScalable
		{
			get
			{
				return PixbufFormat.gdk_pixbuf_format_is_scalable(base.Handle);
			}
		}

		// Token: 0x1700020F RID: 527
		// (get) Token: 0x060007F3 RID: 2035 RVA: 0x00017A59 File Offset: 0x00015C59
		public bool IsWritable
		{
			get
			{
				return PixbufFormat.gdk_pixbuf_format_is_writable(base.Handle);
			}
		}

		// Token: 0x060007F4 RID: 2036 RVA: 0x00017A6B File Offset: 0x00015C6B
		public PixbufFormat(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x060007F5 RID: 2037 RVA: 0x00017A74 File Offset: 0x00015C74
		protected override void Free(IntPtr raw)
		{
			PixbufFormat.gdk_pixbuf_format_free(raw);
		}

		// Token: 0x060007F6 RID: 2038 RVA: 0x00017A84 File Offset: 0x00015C84
		protected override void Finalize()
		{
			try
			{
				if (base.Owned)
				{
					PixbufFormat.FinalizerInfo finalizerInfo = new PixbufFormat.FinalizerInfo(base.Handle);
					finalizerInfo.timeoutHandlerId = Timeout.Add(50U, new TimeoutHandler(finalizerInfo.Handler));
				}
			}
			finally
			{
				base.Finalize();
			}
		}

		// Token: 0x17000210 RID: 528
		// (get) Token: 0x060007F7 RID: 2039 RVA: 0x00017ADC File Offset: 0x00015CDC
		public static AbiStruct abi_info
		{
			get
			{
				if (PixbufFormat._abi_info == null)
				{
					PixbufFormat._abi_info = new AbiStruct(new List<AbiField>());
				}
				return PixbufFormat._abi_info;
			}
		}

		// Token: 0x0400047B RID: 1147
		private static PixbufFormat.d_gdk_pixbuf_format_copy gdk_pixbuf_format_copy = FuncLoader.LoadFunction<PixbufFormat.d_gdk_pixbuf_format_copy>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_format_copy"));

		// Token: 0x0400047C RID: 1148
		private static PixbufFormat.d_gdk_pixbuf_format_get_description gdk_pixbuf_format_get_description = FuncLoader.LoadFunction<PixbufFormat.d_gdk_pixbuf_format_get_description>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_format_get_description"));

		// Token: 0x0400047D RID: 1149
		private static PixbufFormat.d_gdk_pixbuf_format_get_extensions gdk_pixbuf_format_get_extensions = FuncLoader.LoadFunction<PixbufFormat.d_gdk_pixbuf_format_get_extensions>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_format_get_extensions"));

		// Token: 0x0400047E RID: 1150
		private static PixbufFormat.d_gdk_pixbuf_format_get_license gdk_pixbuf_format_get_license = FuncLoader.LoadFunction<PixbufFormat.d_gdk_pixbuf_format_get_license>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_format_get_license"));

		// Token: 0x0400047F RID: 1151
		private static PixbufFormat.d_gdk_pixbuf_format_get_mime_types gdk_pixbuf_format_get_mime_types = FuncLoader.LoadFunction<PixbufFormat.d_gdk_pixbuf_format_get_mime_types>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_format_get_mime_types"));

		// Token: 0x04000480 RID: 1152
		private static PixbufFormat.d_gdk_pixbuf_format_get_name gdk_pixbuf_format_get_name = FuncLoader.LoadFunction<PixbufFormat.d_gdk_pixbuf_format_get_name>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_format_get_name"));

		// Token: 0x04000481 RID: 1153
		private static PixbufFormat.d_gdk_pixbuf_format_get_type gdk_pixbuf_format_get_type = FuncLoader.LoadFunction<PixbufFormat.d_gdk_pixbuf_format_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_format_get_type"));

		// Token: 0x04000482 RID: 1154
		private static PixbufFormat.d_gdk_pixbuf_format_is_disabled gdk_pixbuf_format_is_disabled = FuncLoader.LoadFunction<PixbufFormat.d_gdk_pixbuf_format_is_disabled>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_format_is_disabled"));

		// Token: 0x04000483 RID: 1155
		private static PixbufFormat.d_gdk_pixbuf_format_set_disabled gdk_pixbuf_format_set_disabled = FuncLoader.LoadFunction<PixbufFormat.d_gdk_pixbuf_format_set_disabled>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_format_set_disabled"));

		// Token: 0x04000484 RID: 1156
		private static PixbufFormat.d_gdk_pixbuf_format_is_save_option_supported gdk_pixbuf_format_is_save_option_supported = FuncLoader.LoadFunction<PixbufFormat.d_gdk_pixbuf_format_is_save_option_supported>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_format_is_save_option_supported"));

		// Token: 0x04000485 RID: 1157
		private static PixbufFormat.d_gdk_pixbuf_format_is_scalable gdk_pixbuf_format_is_scalable = FuncLoader.LoadFunction<PixbufFormat.d_gdk_pixbuf_format_is_scalable>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_format_is_scalable"));

		// Token: 0x04000486 RID: 1158
		private static PixbufFormat.d_gdk_pixbuf_format_is_writable gdk_pixbuf_format_is_writable = FuncLoader.LoadFunction<PixbufFormat.d_gdk_pixbuf_format_is_writable>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_format_is_writable"));

		// Token: 0x04000487 RID: 1159
		private static PixbufFormat.d_gdk_pixbuf_format_free gdk_pixbuf_format_free = FuncLoader.LoadFunction<PixbufFormat.d_gdk_pixbuf_format_free>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_format_free"));

		// Token: 0x04000488 RID: 1160
		private static AbiStruct _abi_info = null;

		// Token: 0x02000377 RID: 887
		// (Invoke) Token: 0x06001460 RID: 5216
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_format_copy(IntPtr raw);

		// Token: 0x02000378 RID: 888
		// (Invoke) Token: 0x06001464 RID: 5220
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_format_get_description(IntPtr raw);

		// Token: 0x02000379 RID: 889
		// (Invoke) Token: 0x06001468 RID: 5224
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_format_get_extensions(IntPtr raw);

		// Token: 0x0200037A RID: 890
		// (Invoke) Token: 0x0600146C RID: 5228
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_format_get_license(IntPtr raw);

		// Token: 0x0200037B RID: 891
		// (Invoke) Token: 0x06001470 RID: 5232
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_format_get_mime_types(IntPtr raw);

		// Token: 0x0200037C RID: 892
		// (Invoke) Token: 0x06001474 RID: 5236
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_format_get_name(IntPtr raw);

		// Token: 0x0200037D RID: 893
		// (Invoke) Token: 0x06001478 RID: 5240
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_format_get_type();

		// Token: 0x0200037E RID: 894
		// (Invoke) Token: 0x0600147C RID: 5244
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_format_is_disabled(IntPtr raw);

		// Token: 0x0200037F RID: 895
		// (Invoke) Token: 0x06001480 RID: 5248
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_pixbuf_format_set_disabled(IntPtr raw, bool disabled);

		// Token: 0x02000380 RID: 896
		// (Invoke) Token: 0x06001484 RID: 5252
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_format_is_save_option_supported(IntPtr raw, IntPtr option_key);

		// Token: 0x02000381 RID: 897
		// (Invoke) Token: 0x06001488 RID: 5256
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_format_is_scalable(IntPtr raw);

		// Token: 0x02000382 RID: 898
		// (Invoke) Token: 0x0600148C RID: 5260
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_format_is_writable(IntPtr raw);

		// Token: 0x02000383 RID: 899
		// (Invoke) Token: 0x06001490 RID: 5264
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_pixbuf_format_free(IntPtr raw);

		// Token: 0x02000384 RID: 900
		private class FinalizerInfo
		{
			// Token: 0x06001493 RID: 5267 RVA: 0x00021E5D File Offset: 0x0002005D
			public FinalizerInfo(IntPtr handle)
			{
				this.handle = handle;
			}

			// Token: 0x06001494 RID: 5268 RVA: 0x00021E6C File Offset: 0x0002006C
			public bool Handler()
			{
				PixbufFormat.gdk_pixbuf_format_free(this.handle);
				Timeout.Remove(this.timeoutHandlerId);
				return false;
			}

			// Token: 0x04000C9C RID: 3228
			private IntPtr handle;

			// Token: 0x04000C9D RID: 3229
			public uint timeoutHandlerId;
		}
	}
}
