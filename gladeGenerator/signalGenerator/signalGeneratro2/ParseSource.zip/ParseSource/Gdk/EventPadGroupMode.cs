﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200007C RID: 124
	public struct EventPadGroupMode : IEquatable<EventPadGroupMode>
	{
		// Token: 0x17000157 RID: 343
		// (get) Token: 0x0600054A RID: 1354 RVA: 0x0000FFDA File Offset: 0x0000E1DA
		// (set) Token: 0x0600054B RID: 1355 RVA: 0x0000FFEC File Offset: 0x0000E1EC
		public Window Window
		{
			get
			{
				return Object.GetObject(this._window) as Window;
			}
			set
			{
				this._window = ((value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x0600054C RID: 1356 RVA: 0x00010004 File Offset: 0x0000E204
		public static EventPadGroupMode New(IntPtr raw)
		{
			if (raw == IntPtr.Zero)
			{
				return EventPadGroupMode.Zero;
			}
			return (EventPadGroupMode)Marshal.PtrToStructure(raw, typeof(EventPadGroupMode));
		}

		// Token: 0x0600054D RID: 1357 RVA: 0x00010030 File Offset: 0x0000E230
		public bool Equals(EventPadGroupMode other)
		{
			return this.Type.Equals(other.Type) && this.Window.Equals(other.Window) && this.SendEvent.Equals(other.SendEvent) && this.Time.Equals(other.Time) && this.Group.Equals(other.Group) && this.Mode.Equals(other.Mode);
		}

		// Token: 0x0600054E RID: 1358 RVA: 0x000100BB File Offset: 0x0000E2BB
		public override bool Equals(object other)
		{
			return other is EventPadGroupMode && this.Equals((EventPadGroupMode)other);
		}

		// Token: 0x0600054F RID: 1359 RVA: 0x000100D4 File Offset: 0x0000E2D4
		public override int GetHashCode()
		{
			return base.GetType().FullName.GetHashCode() ^ this.Type.GetHashCode() ^ this.Window.GetHashCode() ^ this.SendEvent.GetHashCode() ^ this.Time.GetHashCode() ^ this.Group.GetHashCode() ^ this.Mode.GetHashCode();
		}

		// Token: 0x17000158 RID: 344
		// (get) Token: 0x06000550 RID: 1360 RVA: 0x00010149 File Offset: 0x0000E349
		private static GType GType
		{
			get
			{
				return GType.Pointer;
			}
		}

		// Token: 0x0400027E RID: 638
		public EventType Type;

		// Token: 0x0400027F RID: 639
		private IntPtr _window;

		// Token: 0x04000280 RID: 640
		public sbyte SendEvent;

		// Token: 0x04000281 RID: 641
		public uint Time;

		// Token: 0x04000282 RID: 642
		public uint Group;

		// Token: 0x04000283 RID: 643
		public uint Mode;

		// Token: 0x04000284 RID: 644
		public static EventPadGroupMode Zero;
	}
}
