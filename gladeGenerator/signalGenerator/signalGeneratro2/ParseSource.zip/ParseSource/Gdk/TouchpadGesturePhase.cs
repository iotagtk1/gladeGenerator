﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x0200010E RID: 270
	[GType(typeof(TouchpadGesturePhaseGType))]
	public enum TouchpadGesturePhase
	{
		// Token: 0x04000592 RID: 1426
		Begin,
		// Token: 0x04000593 RID: 1427
		Update,
		// Token: 0x04000594 RID: 1428
		End,
		// Token: 0x04000595 RID: 1429
		Cancel
	}
}
