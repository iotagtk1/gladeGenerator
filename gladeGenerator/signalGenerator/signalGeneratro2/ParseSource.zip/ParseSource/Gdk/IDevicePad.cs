﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000A0 RID: 160
	public interface IDevicePad : IWrapper
	{
		// Token: 0x0600066C RID: 1644
		int GetFeatureGroup(DevicePadFeature feature, int feature_idx);

		// Token: 0x0600066D RID: 1645
		int GetGroupNModes(int group_idx);

		// Token: 0x0600066E RID: 1646
		int GetNFeatures(DevicePadFeature feature);

		// Token: 0x170001AC RID: 428
		// (get) Token: 0x0600066F RID: 1647
		int NGroups { get; }
	}
}
