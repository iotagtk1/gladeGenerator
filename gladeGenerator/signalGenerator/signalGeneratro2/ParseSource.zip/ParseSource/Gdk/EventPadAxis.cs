﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200007A RID: 122
	public struct EventPadAxis : IEquatable<EventPadAxis>
	{
		// Token: 0x17000153 RID: 339
		// (get) Token: 0x0600053A RID: 1338 RVA: 0x0000FC8C File Offset: 0x0000DE8C
		// (set) Token: 0x0600053B RID: 1339 RVA: 0x0000FC9E File Offset: 0x0000DE9E
		public Window Window
		{
			get
			{
				return Object.GetObject(this._window) as Window;
			}
			set
			{
				this._window = ((value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x0600053C RID: 1340 RVA: 0x0000FCB6 File Offset: 0x0000DEB6
		public static EventPadAxis New(IntPtr raw)
		{
			if (raw == IntPtr.Zero)
			{
				return EventPadAxis.Zero;
			}
			return (EventPadAxis)Marshal.PtrToStructure(raw, typeof(EventPadAxis));
		}

		// Token: 0x0600053D RID: 1341 RVA: 0x0000FCE0 File Offset: 0x0000DEE0
		public bool Equals(EventPadAxis other)
		{
			return this.Type.Equals(other.Type) && this.Window.Equals(other.Window) && this.SendEvent.Equals(other.SendEvent) && this.Time.Equals(other.Time) && this.Group.Equals(other.Group) && this.Index.Equals(other.Index) && this.Mode.Equals(other.Mode) && this.Value.Equals(other.Value);
		}

		// Token: 0x0600053E RID: 1342 RVA: 0x0000FD94 File Offset: 0x0000DF94
		public override bool Equals(object other)
		{
			return other is EventPadAxis && this.Equals((EventPadAxis)other);
		}

		// Token: 0x0600053F RID: 1343 RVA: 0x0000FDAC File Offset: 0x0000DFAC
		public override int GetHashCode()
		{
			return base.GetType().FullName.GetHashCode() ^ this.Type.GetHashCode() ^ this.Window.GetHashCode() ^ this.SendEvent.GetHashCode() ^ this.Time.GetHashCode() ^ this.Group.GetHashCode() ^ this.Index.GetHashCode() ^ this.Mode.GetHashCode() ^ this.Value.GetHashCode();
		}

		// Token: 0x17000154 RID: 340
		// (get) Token: 0x06000540 RID: 1344 RVA: 0x0000FE39 File Offset: 0x0000E039
		private static GType GType
		{
			get
			{
				return GType.Pointer;
			}
		}

		// Token: 0x0400026D RID: 621
		public EventType Type;

		// Token: 0x0400026E RID: 622
		private IntPtr _window;

		// Token: 0x0400026F RID: 623
		public sbyte SendEvent;

		// Token: 0x04000270 RID: 624
		public uint Time;

		// Token: 0x04000271 RID: 625
		public uint Group;

		// Token: 0x04000272 RID: 626
		public uint Index;

		// Token: 0x04000273 RID: 627
		public uint Mode;

		// Token: 0x04000274 RID: 628
		public double Value;

		// Token: 0x04000275 RID: 629
		public static EventPadAxis Zero;
	}
}
