﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x0200009F RID: 159
	public class IconEntry : Opaque
	{
		// Token: 0x0600066A RID: 1642 RVA: 0x00012FDA File Offset: 0x000111DA
		public IconEntry(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170001AB RID: 427
		// (get) Token: 0x0600066B RID: 1643 RVA: 0x00012FE3 File Offset: 0x000111E3
		public static AbiStruct abi_info
		{
			get
			{
				if (IconEntry._abi_info == null)
				{
					IconEntry._abi_info = new AbiStruct(new List<AbiField>());
				}
				return IconEntry._abi_info;
			}
		}

		// Token: 0x0400037D RID: 893
		private static AbiStruct _abi_info;
	}
}
