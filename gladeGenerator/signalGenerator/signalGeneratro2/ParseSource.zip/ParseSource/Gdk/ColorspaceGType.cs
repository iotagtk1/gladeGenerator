﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200004F RID: 79
	internal class ColorspaceGType
	{
		// Token: 0x170000FC RID: 252
		// (get) Token: 0x060003BD RID: 957 RVA: 0x0000BD7D File Offset: 0x00009F7D
		public static GType GType
		{
			get
			{
				return new GType(ColorspaceGType.gdk_colorspace_get_type());
			}
		}

		// Token: 0x04000145 RID: 325
		private static ColorspaceGType.d_gdk_colorspace_get_type gdk_colorspace_get_type = FuncLoader.LoadFunction<ColorspaceGType.d_gdk_colorspace_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_colorspace_get_type"));

		// Token: 0x02000202 RID: 514
		// (Invoke) Token: 0x06000E93 RID: 3731
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_colorspace_get_type();
	}
}
