﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000F1 RID: 241
	[Flags]
	[GType(typeof(SeatCapabilitiesGType))]
	public enum SeatCapabilities
	{
		// Token: 0x04000559 RID: 1369
		None = 0,
		// Token: 0x0400055A RID: 1370
		Pointer = 1,
		// Token: 0x0400055B RID: 1371
		Touch = 2,
		// Token: 0x0400055C RID: 1372
		TabletStylus = 4,
		// Token: 0x0400055D RID: 1373
		Keyboard = 8,
		// Token: 0x0400055E RID: 1374
		AllPointing = 7,
		// Token: 0x0400055F RID: 1375
		All = 15
	}
}
