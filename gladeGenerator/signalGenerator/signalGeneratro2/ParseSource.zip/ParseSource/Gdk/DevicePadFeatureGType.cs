﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200005E RID: 94
	internal class DevicePadFeatureGType
	{
		// Token: 0x1700011A RID: 282
		// (get) Token: 0x0600042E RID: 1070 RVA: 0x0000D074 File Offset: 0x0000B274
		public static GType GType
		{
			get
			{
				return new GType(DevicePadFeatureGType.gdk_device_pad_feature_get_type());
			}
		}

		// Token: 0x040001C8 RID: 456
		private static DevicePadFeatureGType.d_gdk_device_pad_feature_get_type gdk_device_pad_feature_get_type = FuncLoader.LoadFunction<DevicePadFeatureGType.d_gdk_device_pad_feature_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_pad_feature_get_type"));

		// Token: 0x02000223 RID: 547
		// (Invoke) Token: 0x06000F13 RID: 3859
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_pad_feature_get_type();
	}
}
