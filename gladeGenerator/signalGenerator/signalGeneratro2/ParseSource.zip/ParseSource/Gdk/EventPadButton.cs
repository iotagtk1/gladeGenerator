﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200007B RID: 123
	public struct EventPadButton : IEquatable<EventPadButton>
	{
		// Token: 0x17000155 RID: 341
		// (get) Token: 0x06000542 RID: 1346 RVA: 0x0000FE42 File Offset: 0x0000E042
		// (set) Token: 0x06000543 RID: 1347 RVA: 0x0000FE54 File Offset: 0x0000E054
		public Window Window
		{
			get
			{
				return Object.GetObject(this._window) as Window;
			}
			set
			{
				this._window = ((value == null) ? IntPtr.Zero : value.Handle);
			}
		}

		// Token: 0x06000544 RID: 1348 RVA: 0x0000FE6C File Offset: 0x0000E06C
		public static EventPadButton New(IntPtr raw)
		{
			if (raw == IntPtr.Zero)
			{
				return EventPadButton.Zero;
			}
			return (EventPadButton)Marshal.PtrToStructure(raw, typeof(EventPadButton));
		}

		// Token: 0x06000545 RID: 1349 RVA: 0x0000FE98 File Offset: 0x0000E098
		public bool Equals(EventPadButton other)
		{
			return this.Type.Equals(other.Type) && this.Window.Equals(other.Window) && this.SendEvent.Equals(other.SendEvent) && this.Time.Equals(other.Time) && this.Group.Equals(other.Group) && this.Button.Equals(other.Button) && this.Mode.Equals(other.Mode);
		}

		// Token: 0x06000546 RID: 1350 RVA: 0x0000FF36 File Offset: 0x0000E136
		public override bool Equals(object other)
		{
			return other is EventPadButton && this.Equals((EventPadButton)other);
		}

		// Token: 0x06000547 RID: 1351 RVA: 0x0000FF50 File Offset: 0x0000E150
		public override int GetHashCode()
		{
			return base.GetType().FullName.GetHashCode() ^ this.Type.GetHashCode() ^ this.Window.GetHashCode() ^ this.SendEvent.GetHashCode() ^ this.Time.GetHashCode() ^ this.Group.GetHashCode() ^ this.Button.GetHashCode() ^ this.Mode.GetHashCode();
		}

		// Token: 0x17000156 RID: 342
		// (get) Token: 0x06000548 RID: 1352 RVA: 0x0000FFD1 File Offset: 0x0000E1D1
		private static GType GType
		{
			get
			{
				return GType.Pointer;
			}
		}

		// Token: 0x04000276 RID: 630
		public EventType Type;

		// Token: 0x04000277 RID: 631
		private IntPtr _window;

		// Token: 0x04000278 RID: 632
		public sbyte SendEvent;

		// Token: 0x04000279 RID: 633
		public uint Time;

		// Token: 0x0400027A RID: 634
		public uint Group;

		// Token: 0x0400027B RID: 635
		public uint Button;

		// Token: 0x0400027C RID: 636
		public uint Mode;

		// Token: 0x0400027D RID: 637
		public static EventPadButton Zero;
	}
}
