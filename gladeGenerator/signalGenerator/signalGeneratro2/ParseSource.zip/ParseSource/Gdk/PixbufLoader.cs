﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000D2 RID: 210
	public class PixbufLoader : Object
	{
		// Token: 0x06000814 RID: 2068 RVA: 0x00018026 File Offset: 0x00016226
		public PixbufLoader(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000815 RID: 2069 RVA: 0x00018030 File Offset: 0x00016230
		public PixbufLoader() : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(PixbufLoader))
			{
				this.CreateNativeObject(new string[0], new Value[0]);
				return;
			}
			this.Raw = PixbufLoader.gdk_pixbuf_loader_new();
		}

		// Token: 0x06000816 RID: 2070 RVA: 0x00018084 File Offset: 0x00016284
		public PixbufLoader(string mime_type) : base(IntPtr.Zero)
		{
			if (base.GetType() != typeof(PixbufLoader))
			{
				List<Value> list = new List<Value>();
				List<string> list2 = new List<string>();
				this.CreateNativeObject(list2.ToArray(), list.ToArray());
				return;
			}
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(mime_type);
			IntPtr zero = IntPtr.Zero;
			this.Raw = PixbufLoader.gdk_pixbuf_loader_new_with_mime_type(intPtr, out zero);
			Marshaller.Free(intPtr);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
		}

		// Token: 0x06000817 RID: 2071 RVA: 0x0001810C File Offset: 0x0001630C
		public static PixbufLoader NewWithType(string image_type)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(image_type);
			IntPtr zero = IntPtr.Zero;
			PixbufLoader result = new PixbufLoader(PixbufLoader.gdk_pixbuf_loader_new_with_type(intPtr, out zero));
			Marshaller.Free(intPtr);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x1400001C RID: 28
		// (add) Token: 0x06000818 RID: 2072 RVA: 0x00018152 File Offset: 0x00016352
		// (remove) Token: 0x06000819 RID: 2073 RVA: 0x0001816A File Offset: 0x0001636A
		[Signal("size-prepared")]
		public event SizePreparedHandler SizePrepared
		{
			add
			{
				base.AddSignalHandler("size-prepared", value, typeof(SizePreparedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("size-prepared", value);
			}
		}

		// Token: 0x1400001D RID: 29
		// (add) Token: 0x0600081A RID: 2074 RVA: 0x00018178 File Offset: 0x00016378
		// (remove) Token: 0x0600081B RID: 2075 RVA: 0x00018190 File Offset: 0x00016390
		[Signal("area-updated")]
		public event AreaUpdatedHandler AreaUpdated
		{
			add
			{
				base.AddSignalHandler("area-updated", value, typeof(AreaUpdatedArgs));
			}
			remove
			{
				base.RemoveSignalHandler("area-updated", value);
			}
		}

		// Token: 0x1400001E RID: 30
		// (add) Token: 0x0600081C RID: 2076 RVA: 0x0001819E File Offset: 0x0001639E
		// (remove) Token: 0x0600081D RID: 2077 RVA: 0x000181AC File Offset: 0x000163AC
		[Signal("closed")]
		public event EventHandler Closed
		{
			add
			{
				base.AddSignalHandler("closed", value);
			}
			remove
			{
				base.RemoveSignalHandler("closed", value);
			}
		}

		// Token: 0x1400001F RID: 31
		// (add) Token: 0x0600081E RID: 2078 RVA: 0x000181BA File Offset: 0x000163BA
		// (remove) Token: 0x0600081F RID: 2079 RVA: 0x000181C8 File Offset: 0x000163C8
		[Signal("area-prepared")]
		public event EventHandler AreaPrepared
		{
			add
			{
				base.AddSignalHandler("area-prepared", value);
			}
			remove
			{
				base.RemoveSignalHandler("area-prepared", value);
			}
		}

		// Token: 0x1700021A RID: 538
		// (get) Token: 0x06000820 RID: 2080 RVA: 0x000181D6 File Offset: 0x000163D6
		private static PixbufLoader.SizePreparedNativeDelegate SizePreparedVMCallback
		{
			get
			{
				if (PixbufLoader.SizePrepared_cb_delegate == null)
				{
					PixbufLoader.SizePrepared_cb_delegate = new PixbufLoader.SizePreparedNativeDelegate(PixbufLoader.SizePrepared_cb);
				}
				return PixbufLoader.SizePrepared_cb_delegate;
			}
		}

		// Token: 0x06000821 RID: 2081 RVA: 0x000181F5 File Offset: 0x000163F5
		private static void OverrideSizePrepared(GType gtype)
		{
			PixbufLoader.OverrideSizePrepared(gtype, PixbufLoader.SizePreparedVMCallback);
		}

		// Token: 0x06000822 RID: 2082 RVA: 0x00018204 File Offset: 0x00016404
		private unsafe static void OverrideSizePrepared(GType gtype, PixbufLoader.SizePreparedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + PixbufLoader.class_abi.GetFieldOffset("size_prepared");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000823 RID: 2083 RVA: 0x00018238 File Offset: 0x00016438
		private static void SizePrepared_cb(IntPtr inst, int width, int height)
		{
			try
			{
				(Object.GetObject(inst, false) as PixbufLoader).OnSizePrepared(width, height);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000824 RID: 2084 RVA: 0x00018274 File Offset: 0x00016474
		[DefaultSignalHandler(Type = typeof(PixbufLoader), ConnectionMethod = "OverrideSizePrepared")]
		protected virtual void OnSizePrepared(int width, int height)
		{
			this.InternalSizePrepared(width, height);
		}

		// Token: 0x06000825 RID: 2085 RVA: 0x00018280 File Offset: 0x00016480
		private void InternalSizePrepared(int width, int height)
		{
			PixbufLoader.SizePreparedNativeDelegate sizePreparedNativeDelegate = PixbufLoader.class_abi.BaseOverride(base.LookupGType(), "size_prepared");
			if (sizePreparedNativeDelegate == null)
			{
				return;
			}
			sizePreparedNativeDelegate(base.Handle, width, height);
		}

		// Token: 0x1700021B RID: 539
		// (get) Token: 0x06000826 RID: 2086 RVA: 0x000182B5 File Offset: 0x000164B5
		private static PixbufLoader.AreaPreparedNativeDelegate AreaPreparedVMCallback
		{
			get
			{
				if (PixbufLoader.AreaPrepared_cb_delegate == null)
				{
					PixbufLoader.AreaPrepared_cb_delegate = new PixbufLoader.AreaPreparedNativeDelegate(PixbufLoader.AreaPrepared_cb);
				}
				return PixbufLoader.AreaPrepared_cb_delegate;
			}
		}

		// Token: 0x06000827 RID: 2087 RVA: 0x000182D4 File Offset: 0x000164D4
		private static void OverrideAreaPrepared(GType gtype)
		{
			PixbufLoader.OverrideAreaPrepared(gtype, PixbufLoader.AreaPreparedVMCallback);
		}

		// Token: 0x06000828 RID: 2088 RVA: 0x000182E4 File Offset: 0x000164E4
		private unsafe static void OverrideAreaPrepared(GType gtype, PixbufLoader.AreaPreparedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + PixbufLoader.class_abi.GetFieldOffset("area_prepared");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000829 RID: 2089 RVA: 0x00018318 File Offset: 0x00016518
		private static void AreaPrepared_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as PixbufLoader).OnAreaPrepared();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x0600082A RID: 2090 RVA: 0x00018350 File Offset: 0x00016550
		[DefaultSignalHandler(Type = typeof(PixbufLoader), ConnectionMethod = "OverrideAreaPrepared")]
		protected virtual void OnAreaPrepared()
		{
			this.InternalAreaPrepared();
		}

		// Token: 0x0600082B RID: 2091 RVA: 0x00018358 File Offset: 0x00016558
		private void InternalAreaPrepared()
		{
			PixbufLoader.AreaPreparedNativeDelegate areaPreparedNativeDelegate = PixbufLoader.class_abi.BaseOverride(base.LookupGType(), "area_prepared");
			if (areaPreparedNativeDelegate == null)
			{
				return;
			}
			areaPreparedNativeDelegate(base.Handle);
		}

		// Token: 0x1700021C RID: 540
		// (get) Token: 0x0600082C RID: 2092 RVA: 0x0001838B File Offset: 0x0001658B
		private static PixbufLoader.AreaUpdatedNativeDelegate AreaUpdatedVMCallback
		{
			get
			{
				if (PixbufLoader.AreaUpdated_cb_delegate == null)
				{
					PixbufLoader.AreaUpdated_cb_delegate = new PixbufLoader.AreaUpdatedNativeDelegate(PixbufLoader.AreaUpdated_cb);
				}
				return PixbufLoader.AreaUpdated_cb_delegate;
			}
		}

		// Token: 0x0600082D RID: 2093 RVA: 0x000183AA File Offset: 0x000165AA
		private static void OverrideAreaUpdated(GType gtype)
		{
			PixbufLoader.OverrideAreaUpdated(gtype, PixbufLoader.AreaUpdatedVMCallback);
		}

		// Token: 0x0600082E RID: 2094 RVA: 0x000183B8 File Offset: 0x000165B8
		private unsafe static void OverrideAreaUpdated(GType gtype, PixbufLoader.AreaUpdatedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + PixbufLoader.class_abi.GetFieldOffset("area_updated");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x0600082F RID: 2095 RVA: 0x000183EC File Offset: 0x000165EC
		private static void AreaUpdated_cb(IntPtr inst, int x, int y, int width, int height)
		{
			try
			{
				(Object.GetObject(inst, false) as PixbufLoader).OnAreaUpdated(x, y, width, height);
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000830 RID: 2096 RVA: 0x0001842C File Offset: 0x0001662C
		[DefaultSignalHandler(Type = typeof(PixbufLoader), ConnectionMethod = "OverrideAreaUpdated")]
		protected virtual void OnAreaUpdated(int x, int y, int width, int height)
		{
			this.InternalAreaUpdated(x, y, width, height);
		}

		// Token: 0x06000831 RID: 2097 RVA: 0x0001843C File Offset: 0x0001663C
		private void InternalAreaUpdated(int x, int y, int width, int height)
		{
			PixbufLoader.AreaUpdatedNativeDelegate areaUpdatedNativeDelegate = PixbufLoader.class_abi.BaseOverride(base.LookupGType(), "area_updated");
			if (areaUpdatedNativeDelegate == null)
			{
				return;
			}
			areaUpdatedNativeDelegate(base.Handle, x, y, width, height);
		}

		// Token: 0x1700021D RID: 541
		// (get) Token: 0x06000832 RID: 2098 RVA: 0x00018474 File Offset: 0x00016674
		private static PixbufLoader.ClosedNativeDelegate ClosedVMCallback
		{
			get
			{
				if (PixbufLoader.Closed_cb_delegate == null)
				{
					PixbufLoader.Closed_cb_delegate = new PixbufLoader.ClosedNativeDelegate(PixbufLoader.Closed_cb);
				}
				return PixbufLoader.Closed_cb_delegate;
			}
		}

		// Token: 0x06000833 RID: 2099 RVA: 0x00018493 File Offset: 0x00016693
		private static void OverrideClosed(GType gtype)
		{
			PixbufLoader.OverrideClosed(gtype, PixbufLoader.ClosedVMCallback);
		}

		// Token: 0x06000834 RID: 2100 RVA: 0x000184A0 File Offset: 0x000166A0
		private unsafe static void OverrideClosed(GType gtype, PixbufLoader.ClosedNativeDelegate callback)
		{
			IntPtr* ptr = (long)gtype.GetClassPtr() / (long)sizeof(IntPtr) + PixbufLoader.class_abi.GetFieldOffset("closed");
			*ptr = Marshal.GetFunctionPointerForDelegate(callback);
		}

		// Token: 0x06000835 RID: 2101 RVA: 0x000184D4 File Offset: 0x000166D4
		private static void Closed_cb(IntPtr inst)
		{
			try
			{
				(Object.GetObject(inst, false) as PixbufLoader).OnClosed();
			}
			catch (Exception e)
			{
				ExceptionManager.RaiseUnhandledException(e, false);
			}
		}

		// Token: 0x06000836 RID: 2102 RVA: 0x0001850C File Offset: 0x0001670C
		[DefaultSignalHandler(Type = typeof(PixbufLoader), ConnectionMethod = "OverrideClosed")]
		protected virtual void OnClosed()
		{
			this.InternalClosed();
		}

		// Token: 0x06000837 RID: 2103 RVA: 0x00018514 File Offset: 0x00016714
		private void InternalClosed()
		{
			PixbufLoader.ClosedNativeDelegate closedNativeDelegate = PixbufLoader.class_abi.BaseOverride(base.LookupGType(), "closed");
			if (closedNativeDelegate == null)
			{
				return;
			}
			closedNativeDelegate(base.Handle);
		}

		// Token: 0x1700021E RID: 542
		// (get) Token: 0x06000838 RID: 2104 RVA: 0x00018548 File Offset: 0x00016748
		public new static AbiStruct class_abi
		{
			get
			{
				if (PixbufLoader._class_abi == null)
				{
					PixbufLoader._class_abi = new AbiStruct(new List<AbiField>
					{
						new AbiField("size_prepared", Object.class_abi.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, "area_prepared", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("area_prepared", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "size_prepared", "area_updated", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("area_updated", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "area_prepared", "closed", (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U),
						new AbiField("closed", -1L, (uint)Marshal.SizeOf(typeof(IntPtr)), "area_updated", null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return PixbufLoader._class_abi;
			}
		}

		// Token: 0x06000839 RID: 2105 RVA: 0x00018664 File Offset: 0x00016864
		public bool Close()
		{
			IntPtr zero = IntPtr.Zero;
			bool result = PixbufLoader.gdk_pixbuf_loader_close(base.Handle, out zero);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x1700021F RID: 543
		// (get) Token: 0x0600083A RID: 2106 RVA: 0x0001869D File Offset: 0x0001689D
		public PixbufAnimation Animation
		{
			get
			{
				return Object.GetObject(PixbufLoader.gdk_pixbuf_loader_get_animation(base.Handle)) as PixbufAnimation;
			}
		}

		// Token: 0x17000220 RID: 544
		// (get) Token: 0x0600083B RID: 2107 RVA: 0x000186BC File Offset: 0x000168BC
		public PixbufFormat Format
		{
			get
			{
				IntPtr intPtr = PixbufLoader.gdk_pixbuf_loader_get_format(base.Handle);
				if (!(intPtr == IntPtr.Zero))
				{
					return (PixbufFormat)Opaque.GetOpaque(intPtr, typeof(PixbufFormat), false);
				}
				return null;
			}
		}

		// Token: 0x17000221 RID: 545
		// (get) Token: 0x0600083C RID: 2108 RVA: 0x000186FF File Offset: 0x000168FF
		public Pixbuf Pixbuf
		{
			get
			{
				return Object.GetObject(PixbufLoader.gdk_pixbuf_loader_get_pixbuf(base.Handle)) as Pixbuf;
			}
		}

		// Token: 0x17000222 RID: 546
		// (get) Token: 0x0600083D RID: 2109 RVA: 0x0001871C File Offset: 0x0001691C
		public new static GType GType
		{
			get
			{
				IntPtr val = PixbufLoader.gdk_pixbuf_loader_get_type();
				return new GType(val);
			}
		}

		// Token: 0x0600083E RID: 2110 RVA: 0x0001873A File Offset: 0x0001693A
		public void SetSize(int width, int height)
		{
			PixbufLoader.gdk_pixbuf_loader_set_size(base.Handle, width, height);
		}

		// Token: 0x0600083F RID: 2111 RVA: 0x00018750 File Offset: 0x00016950
		public bool Write(byte[] buf, ulong count)
		{
			IntPtr zero = IntPtr.Zero;
			bool result = PixbufLoader.gdk_pixbuf_loader_write(base.Handle, buf, new UIntPtr(count), out zero);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x06000840 RID: 2112 RVA: 0x00018790 File Offset: 0x00016990
		public bool WriteBytes(Bytes buffer)
		{
			IntPtr zero = IntPtr.Zero;
			bool result = PixbufLoader.gdk_pixbuf_loader_write_bytes(base.Handle, (buffer == null) ? IntPtr.Zero : buffer.Handle, out zero);
			if (zero != IntPtr.Zero)
			{
				throw new GException(zero);
			}
			return result;
		}

		// Token: 0x17000223 RID: 547
		// (get) Token: 0x06000841 RID: 2113 RVA: 0x000187DC File Offset: 0x000169DC
		public new static AbiStruct abi_info
		{
			get
			{
				if (PixbufLoader._abi_info == null)
				{
					PixbufLoader._abi_info = new AbiStruct(new List<AbiField>
					{
						new AbiField("priv", Object.abi_info.Fields, (uint)Marshal.SizeOf(typeof(IntPtr)), null, null, (long)((ulong)Marshal.SizeOf(typeof(IntPtr))), 0U)
					});
				}
				return PixbufLoader._abi_info;
			}
		}

		// Token: 0x17000224 RID: 548
		// (get) Token: 0x06000842 RID: 2114 RVA: 0x00018840 File Offset: 0x00016A40
		internal IntPtr PixbufHandle
		{
			get
			{
				return PixbufLoader.g_object_ref(PixbufLoader.gdk_pixbuf_loader_get_pixbuf(base.Handle));
			}
		}

		// Token: 0x17000225 RID: 549
		// (get) Token: 0x06000843 RID: 2115 RVA: 0x0001885C File Offset: 0x00016A5C
		internal IntPtr AnimationHandle
		{
			get
			{
				return PixbufLoader.g_object_ref(PixbufLoader.gdk_pixbuf_loader_get_animation(base.Handle));
			}
		}

		// Token: 0x06000844 RID: 2116 RVA: 0x00018878 File Offset: 0x00016A78
		public bool Write(byte[] bytes)
		{
			return this.Write(bytes, (ulong)((long)bytes.Length));
		}

		// Token: 0x06000845 RID: 2117 RVA: 0x00018885 File Offset: 0x00016A85
		[Obsolete("Replaced by Write (byte[], ulong) for 64 bit portability")]
		public bool Write(byte[] bytes, uint count)
		{
			return this.Write(bytes, (ulong)count);
		}

		// Token: 0x06000846 RID: 2118 RVA: 0x00018890 File Offset: 0x00016A90
		private void LoadFromStream(Stream input)
		{
			byte[] array = new byte[8192];
			int count;
			while ((count = input.Read(array, 0, 8192)) != 0)
			{
				this.Write(array, (uint)count);
			}
		}

		// Token: 0x06000847 RID: 2119 RVA: 0x000188C4 File Offset: 0x00016AC4
		public PixbufLoader(string file, int width, int height) : this()
		{
			this.SetSize(width, height);
			using (FileStream fileStream = new FileStream(file, FileMode.Open, FileAccess.Read))
			{
				this.InitFromStream(fileStream);
			}
		}

		// Token: 0x06000848 RID: 2120 RVA: 0x0001890C File Offset: 0x00016B0C
		public PixbufLoader(Stream stream) : this()
		{
			this.InitFromStream(stream);
		}

		// Token: 0x06000849 RID: 2121 RVA: 0x0001891C File Offset: 0x00016B1C
		private void InitFromStream(Stream stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}
			try
			{
				this.LoadFromStream(stream);
			}
			finally
			{
				this.Close();
			}
		}

		// Token: 0x0600084A RID: 2122 RVA: 0x0001895C File Offset: 0x00016B5C
		public PixbufLoader(Stream stream, int width, int height) : this()
		{
			this.SetSize(width, height);
			this.InitFromStream(stream);
		}

		// Token: 0x0600084B RID: 2123 RVA: 0x00018973 File Offset: 0x00016B73
		public PixbufLoader(Assembly assembly, string resource) : this()
		{
			this.InitFromAssemblyResource((assembly == null) ? Assembly.GetCallingAssembly() : assembly, resource);
		}

		// Token: 0x0600084C RID: 2124 RVA: 0x00018994 File Offset: 0x00016B94
		private void InitFromAssemblyResource(Assembly assembly, string resource)
		{
			if (assembly == null)
			{
				throw new ArgumentNullException("assembly");
			}
			Stream manifestResourceStream = assembly.GetManifestResourceStream(resource);
			if (manifestResourceStream == null)
			{
				throw new ArgumentException(string.Concat(new string[]
				{
					"'",
					resource,
					"' is not a valid resource name of assembly '",
					(assembly != null) ? assembly.ToString() : null,
					"'."
				}));
			}
			try
			{
				this.LoadFromStream(manifestResourceStream);
			}
			finally
			{
				this.Close();
			}
		}

		// Token: 0x0600084D RID: 2125 RVA: 0x00018A20 File Offset: 0x00016C20
		public PixbufLoader(Assembly assembly, string resource, int width, int height) : this()
		{
			this.SetSize(width, height);
			this.InitFromAssemblyResource((assembly == null) ? Assembly.GetCallingAssembly() : assembly, resource);
		}

		// Token: 0x0600084E RID: 2126 RVA: 0x00018A49 File Offset: 0x00016C49
		public PixbufLoader(byte[] buffer) : this()
		{
			this.InitFromBuffer(buffer);
		}

		// Token: 0x0600084F RID: 2127 RVA: 0x00018A58 File Offset: 0x00016C58
		private void InitFromBuffer(byte[] buffer)
		{
			try
			{
				this.Write(buffer, (uint)buffer.Length);
			}
			finally
			{
				this.Close();
			}
		}

		// Token: 0x06000850 RID: 2128 RVA: 0x00018A8C File Offset: 0x00016C8C
		public PixbufLoader(byte[] buffer, int width, int height) : this()
		{
			this.SetSize(width, height);
			this.InitFromBuffer(buffer);
		}

		// Token: 0x06000851 RID: 2129 RVA: 0x00018AA3 File Offset: 0x00016CA3
		public static PixbufLoader LoadFromResource(string resource)
		{
			return new PixbufLoader(Assembly.GetCallingAssembly(), resource);
		}

		// Token: 0x0400049B RID: 1179
		private static PixbufLoader.d_gdk_pixbuf_loader_new gdk_pixbuf_loader_new = FuncLoader.LoadFunction<PixbufLoader.d_gdk_pixbuf_loader_new>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_loader_new"));

		// Token: 0x0400049C RID: 1180
		private static PixbufLoader.d_gdk_pixbuf_loader_new_with_mime_type gdk_pixbuf_loader_new_with_mime_type = FuncLoader.LoadFunction<PixbufLoader.d_gdk_pixbuf_loader_new_with_mime_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_loader_new_with_mime_type"));

		// Token: 0x0400049D RID: 1181
		private static PixbufLoader.d_gdk_pixbuf_loader_new_with_type gdk_pixbuf_loader_new_with_type = FuncLoader.LoadFunction<PixbufLoader.d_gdk_pixbuf_loader_new_with_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_loader_new_with_type"));

		// Token: 0x0400049E RID: 1182
		private static PixbufLoader.SizePreparedNativeDelegate SizePrepared_cb_delegate;

		// Token: 0x0400049F RID: 1183
		private static PixbufLoader.AreaPreparedNativeDelegate AreaPrepared_cb_delegate;

		// Token: 0x040004A0 RID: 1184
		private static PixbufLoader.AreaUpdatedNativeDelegate AreaUpdated_cb_delegate;

		// Token: 0x040004A1 RID: 1185
		private static PixbufLoader.ClosedNativeDelegate Closed_cb_delegate;

		// Token: 0x040004A2 RID: 1186
		private static AbiStruct _class_abi = null;

		// Token: 0x040004A3 RID: 1187
		private static PixbufLoader.d_gdk_pixbuf_loader_close gdk_pixbuf_loader_close = FuncLoader.LoadFunction<PixbufLoader.d_gdk_pixbuf_loader_close>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_loader_close"));

		// Token: 0x040004A4 RID: 1188
		private static PixbufLoader.d_gdk_pixbuf_loader_get_animation gdk_pixbuf_loader_get_animation = FuncLoader.LoadFunction<PixbufLoader.d_gdk_pixbuf_loader_get_animation>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_loader_get_animation"));

		// Token: 0x040004A5 RID: 1189
		private static PixbufLoader.d_gdk_pixbuf_loader_get_format gdk_pixbuf_loader_get_format = FuncLoader.LoadFunction<PixbufLoader.d_gdk_pixbuf_loader_get_format>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_loader_get_format"));

		// Token: 0x040004A6 RID: 1190
		private static PixbufLoader.d_gdk_pixbuf_loader_get_pixbuf gdk_pixbuf_loader_get_pixbuf = FuncLoader.LoadFunction<PixbufLoader.d_gdk_pixbuf_loader_get_pixbuf>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_loader_get_pixbuf"));

		// Token: 0x040004A7 RID: 1191
		private static PixbufLoader.d_gdk_pixbuf_loader_get_type gdk_pixbuf_loader_get_type = FuncLoader.LoadFunction<PixbufLoader.d_gdk_pixbuf_loader_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_loader_get_type"));

		// Token: 0x040004A8 RID: 1192
		private static PixbufLoader.d_gdk_pixbuf_loader_set_size gdk_pixbuf_loader_set_size = FuncLoader.LoadFunction<PixbufLoader.d_gdk_pixbuf_loader_set_size>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_loader_set_size"));

		// Token: 0x040004A9 RID: 1193
		private static PixbufLoader.d_gdk_pixbuf_loader_write gdk_pixbuf_loader_write = FuncLoader.LoadFunction<PixbufLoader.d_gdk_pixbuf_loader_write>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_loader_write"));

		// Token: 0x040004AA RID: 1194
		private static PixbufLoader.d_gdk_pixbuf_loader_write_bytes gdk_pixbuf_loader_write_bytes = FuncLoader.LoadFunction<PixbufLoader.d_gdk_pixbuf_loader_write_bytes>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GdkPixbuf), "gdk_pixbuf_loader_write_bytes"));

		// Token: 0x040004AB RID: 1195
		private static AbiStruct _abi_info = null;

		// Token: 0x040004AC RID: 1196
		private static PixbufLoader.d_g_object_ref g_object_ref = FuncLoader.LoadFunction<PixbufLoader.d_g_object_ref>(FuncLoader.GetProcAddress(GLibrary.Load(Library.GObject), "g_object_ref"));

		// Token: 0x02000388 RID: 904
		// (Invoke) Token: 0x060014A2 RID: 5282
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_loader_new();

		// Token: 0x02000389 RID: 905
		// (Invoke) Token: 0x060014A6 RID: 5286
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_loader_new_with_mime_type(IntPtr mime_type, out IntPtr error);

		// Token: 0x0200038A RID: 906
		// (Invoke) Token: 0x060014AA RID: 5290
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_loader_new_with_type(IntPtr image_type, out IntPtr error);

		// Token: 0x0200038B RID: 907
		// (Invoke) Token: 0x060014AE RID: 5294
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void SizePreparedNativeDelegate(IntPtr inst, int width, int height);

		// Token: 0x0200038C RID: 908
		// (Invoke) Token: 0x060014B2 RID: 5298
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void AreaPreparedNativeDelegate(IntPtr inst);

		// Token: 0x0200038D RID: 909
		// (Invoke) Token: 0x060014B6 RID: 5302
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void AreaUpdatedNativeDelegate(IntPtr inst, int x, int y, int width, int height);

		// Token: 0x0200038E RID: 910
		// (Invoke) Token: 0x060014BA RID: 5306
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void ClosedNativeDelegate(IntPtr inst);

		// Token: 0x0200038F RID: 911
		// (Invoke) Token: 0x060014BE RID: 5310
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_loader_close(IntPtr raw, out IntPtr error);

		// Token: 0x02000390 RID: 912
		// (Invoke) Token: 0x060014C2 RID: 5314
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_loader_get_animation(IntPtr raw);

		// Token: 0x02000391 RID: 913
		// (Invoke) Token: 0x060014C6 RID: 5318
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_loader_get_format(IntPtr raw);

		// Token: 0x02000392 RID: 914
		// (Invoke) Token: 0x060014CA RID: 5322
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_loader_get_pixbuf(IntPtr raw);

		// Token: 0x02000393 RID: 915
		// (Invoke) Token: 0x060014CE RID: 5326
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_pixbuf_loader_get_type();

		// Token: 0x02000394 RID: 916
		// (Invoke) Token: 0x060014D2 RID: 5330
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_pixbuf_loader_set_size(IntPtr raw, int width, int height);

		// Token: 0x02000395 RID: 917
		// (Invoke) Token: 0x060014D6 RID: 5334
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_loader_write(IntPtr raw, byte[] buf, UIntPtr count, out IntPtr error);

		// Token: 0x02000396 RID: 918
		// (Invoke) Token: 0x060014DA RID: 5338
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pixbuf_loader_write_bytes(IntPtr raw, IntPtr buffer, out IntPtr error);

		// Token: 0x02000397 RID: 919
		// (Invoke) Token: 0x060014DE RID: 5342
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_g_object_ref(IntPtr handle);
	}
}
