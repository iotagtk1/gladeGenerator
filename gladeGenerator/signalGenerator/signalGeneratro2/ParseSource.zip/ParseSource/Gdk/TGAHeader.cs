﻿using System;
using System.Collections.Generic;
using GLib;

namespace Gdk
{
	// Token: 0x02000105 RID: 261
	public class TGAHeader : Opaque
	{
		// Token: 0x06000A1C RID: 2588 RVA: 0x0001DBF9 File Offset: 0x0001BDF9
		public TGAHeader(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700028E RID: 654
		// (get) Token: 0x06000A1D RID: 2589 RVA: 0x0001DC02 File Offset: 0x0001BE02
		public static AbiStruct abi_info
		{
			get
			{
				if (TGAHeader._abi_info == null)
				{
					TGAHeader._abi_info = new AbiStruct(new List<AbiField>());
				}
				return TGAHeader._abi_info;
			}
		}

		// Token: 0x04000585 RID: 1413
		private static AbiStruct _abi_info;
	}
}
