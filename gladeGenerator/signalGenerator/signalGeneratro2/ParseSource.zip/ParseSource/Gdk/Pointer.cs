﻿using System;
using System.Runtime.InteropServices;

namespace Gdk
{
	// Token: 0x020000E3 RID: 227
	public class Pointer
	{
		// Token: 0x0600088A RID: 2186 RVA: 0x00019284 File Offset: 0x00017484
		[Obsolete]
		public static GrabStatus Grab(Window window, bool owner_events, EventMask event_mask, Window confine_to, Cursor cursor, uint time_)
		{
			return (GrabStatus)Pointer.gdk_pointer_grab((window == null) ? IntPtr.Zero : window.Handle, owner_events, (int)event_mask, (confine_to == null) ? IntPtr.Zero : confine_to.Handle, (cursor == null) ? IntPtr.Zero : cursor.Handle, time_);
		}

		// Token: 0x17000235 RID: 565
		// (get) Token: 0x0600088B RID: 2187 RVA: 0x000192D1 File Offset: 0x000174D1
		[Obsolete]
		public static bool IsGrabbed
		{
			get
			{
				return Pointer.gdk_pointer_is_grabbed();
			}
		}

		// Token: 0x0600088C RID: 2188 RVA: 0x000192DD File Offset: 0x000174DD
		[Obsolete]
		public static void Ungrab(uint time_)
		{
			Pointer.gdk_pointer_ungrab(time_);
		}

		// Token: 0x040004DF RID: 1247
		private static Pointer.d_gdk_pointer_grab gdk_pointer_grab = FuncLoader.LoadFunction<Pointer.d_gdk_pointer_grab>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_pointer_grab"));

		// Token: 0x040004E0 RID: 1248
		private static Pointer.d_gdk_pointer_is_grabbed gdk_pointer_is_grabbed = FuncLoader.LoadFunction<Pointer.d_gdk_pointer_is_grabbed>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_pointer_is_grabbed"));

		// Token: 0x040004E1 RID: 1249
		private static Pointer.d_gdk_pointer_ungrab gdk_pointer_ungrab = FuncLoader.LoadFunction<Pointer.d_gdk_pointer_ungrab>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_pointer_ungrab"));

		// Token: 0x020003A0 RID: 928
		// (Invoke) Token: 0x06001502 RID: 5378
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_pointer_grab(IntPtr window, bool owner_events, int event_mask, IntPtr confine_to, IntPtr cursor, uint time_);

		// Token: 0x020003A1 RID: 929
		// (Invoke) Token: 0x06001506 RID: 5382
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_pointer_is_grabbed();

		// Token: 0x020003A2 RID: 930
		// (Invoke) Token: 0x0600150A RID: 5386
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_pointer_ungrab(uint time_);
	}
}
