﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000021 RID: 33
	public struct Color : IEquatable<Color>
	{
		// Token: 0x0600008F RID: 143 RVA: 0x00003302 File Offset: 0x00001502
		public Color(byte r, byte g, byte b)
		{
			this.Red = (ushort)((int)r << 8 | (int)r);
			this.Green = (ushort)((int)g << 8 | (int)g);
			this.Blue = (ushort)((int)b << 8 | (int)b);
			this.Pixel = 0U;
		}

		// Token: 0x06000090 RID: 144 RVA: 0x0000332F File Offset: 0x0000152F
		public override int GetHashCode()
		{
			return (int)Color.gdk_color_hash(ref this);
		}

		// Token: 0x06000091 RID: 145 RVA: 0x0000333C File Offset: 0x0000153C
		public static Color New(IntPtr raw)
		{
			if (raw == IntPtr.Zero)
			{
				return Color.Zero;
			}
			return (Color)Marshal.PtrToStructure(raw, typeof(Color));
		}

		// Token: 0x06000092 RID: 146 RVA: 0x00003368 File Offset: 0x00001568
		[Obsolete]
		public bool Equal(Color colorb)
		{
			IntPtr intPtr = Marshal.AllocHGlobal(Marshal.SizeOf<Color>(this));
			Marshal.StructureToPtr<Color>(this, intPtr, false);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(colorb);
			bool result = Color.gdk_color_equal(intPtr, intPtr2);
			Color.ReadNative(intPtr, ref this);
			Marshal.FreeHGlobal(intPtr);
			Marshal.FreeHGlobal(intPtr2);
			return result;
		}

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x06000093 RID: 147 RVA: 0x000033C0 File Offset: 0x000015C0
		[Obsolete]
		public static GType GType
		{
			get
			{
				IntPtr val = Color.gdk_color_get_type();
				return new GType(val);
			}
		}

		// Token: 0x06000094 RID: 148 RVA: 0x000033E0 File Offset: 0x000015E0
		[Obsolete]
		public static bool Parse(string spec, ref Color color)
		{
			IntPtr intPtr = Marshaller.StringToPtrGStrdup(spec);
			IntPtr intPtr2 = Marshaller.StructureToPtrAlloc(color);
			bool result = Color.gdk_color_parse(intPtr, intPtr2);
			Marshaller.Free(intPtr);
			color = Color.New(intPtr2);
			Marshal.FreeHGlobal(intPtr2);
			return result;
		}

		// Token: 0x06000095 RID: 149 RVA: 0x00003429 File Offset: 0x00001629
		private static void ReadNative(IntPtr native, ref Color target)
		{
			target = Color.New(native);
		}

		// Token: 0x06000096 RID: 150 RVA: 0x00003438 File Offset: 0x00001638
		public bool Equals(Color other)
		{
			return this.Pixel.Equals(other.Pixel) && this.Red.Equals(other.Red) && this.Green.Equals(other.Green) && this.Blue.Equals(other.Blue);
		}

		// Token: 0x06000097 RID: 151 RVA: 0x00003491 File Offset: 0x00001691
		public override bool Equals(object other)
		{
			return other is Color && this.Equals((Color)other);
		}

		// Token: 0x06000098 RID: 152 RVA: 0x000034AC File Offset: 0x000016AC
		public static explicit operator Value(Color boxed)
		{
			Value empty = Value.Empty;
			empty.Init(Color.GType);
			empty.Val = boxed;
			return empty;
		}

		// Token: 0x06000099 RID: 153 RVA: 0x000034D9 File Offset: 0x000016D9
		public static explicit operator Color(Value val)
		{
			return (Color)val.Val;
		}

		// Token: 0x04000056 RID: 86
		private static Color.d_gdk_color_hash gdk_color_hash = FuncLoader.LoadFunction<Color.d_gdk_color_hash>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_color_hash"));

		// Token: 0x04000057 RID: 87
		public uint Pixel;

		// Token: 0x04000058 RID: 88
		public ushort Red;

		// Token: 0x04000059 RID: 89
		public ushort Green;

		// Token: 0x0400005A RID: 90
		public ushort Blue;

		// Token: 0x0400005B RID: 91
		public static Color Zero = default(Color);

		// Token: 0x0400005C RID: 92
		private static Color.d_gdk_color_equal gdk_color_equal = FuncLoader.LoadFunction<Color.d_gdk_color_equal>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_color_equal"));

		// Token: 0x0400005D RID: 93
		private static Color.d_gdk_color_get_type gdk_color_get_type = FuncLoader.LoadFunction<Color.d_gdk_color_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_color_get_type"));

		// Token: 0x0400005E RID: 94
		private static Color.d_gdk_color_parse gdk_color_parse = FuncLoader.LoadFunction<Color.d_gdk_color_parse>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_color_parse"));

		// Token: 0x02000136 RID: 310
		// (Invoke) Token: 0x06000BAF RID: 2991
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate uint d_gdk_color_hash(ref Color raw);

		// Token: 0x02000137 RID: 311
		// (Invoke) Token: 0x06000BB3 RID: 2995
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_color_equal(IntPtr raw, IntPtr colorb);

		// Token: 0x02000138 RID: 312
		// (Invoke) Token: 0x06000BB7 RID: 2999
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_color_get_type();

		// Token: 0x02000139 RID: 313
		// (Invoke) Token: 0x06000BBB RID: 3003
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate bool d_gdk_color_parse(IntPtr spec, IntPtr color);
	}
}
