﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Cairo;
using GLib;

namespace Gdk
{
	// Token: 0x020000BB RID: 187
	public class OffscreenWindow : Opaque
	{
		// Token: 0x0600074F RID: 1871 RVA: 0x00015160 File Offset: 0x00013360
		public static Window GetEmbedder(Window window)
		{
			return Object.GetObject(OffscreenWindow.gdk_offscreen_window_get_embedder((window == null) ? IntPtr.Zero : window.Handle)) as Window;
		}

		// Token: 0x06000750 RID: 1872 RVA: 0x00015186 File Offset: 0x00013386
		public static Surface GetSurface(Window window)
		{
			return Surface.Lookup(OffscreenWindow.gdk_offscreen_window_get_surface((window == null) ? IntPtr.Zero : window.Handle), true);
		}

		// Token: 0x06000751 RID: 1873 RVA: 0x000151A8 File Offset: 0x000133A8
		public static void SetEmbedder(Window window, Window embedder)
		{
			OffscreenWindow.gdk_offscreen_window_set_embedder((window == null) ? IntPtr.Zero : window.Handle, (embedder == null) ? IntPtr.Zero : embedder.Handle);
		}

		// Token: 0x06000752 RID: 1874 RVA: 0x000151D4 File Offset: 0x000133D4
		public OffscreenWindow(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x170001E6 RID: 486
		// (get) Token: 0x06000753 RID: 1875 RVA: 0x000151DD File Offset: 0x000133DD
		public static AbiStruct abi_info
		{
			get
			{
				if (OffscreenWindow._abi_info == null)
				{
					OffscreenWindow._abi_info = new AbiStruct(new List<AbiField>());
				}
				return OffscreenWindow._abi_info;
			}
		}

		// Token: 0x0400040A RID: 1034
		private static OffscreenWindow.d_gdk_offscreen_window_get_embedder gdk_offscreen_window_get_embedder = FuncLoader.LoadFunction<OffscreenWindow.d_gdk_offscreen_window_get_embedder>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_offscreen_window_get_embedder"));

		// Token: 0x0400040B RID: 1035
		private static OffscreenWindow.d_gdk_offscreen_window_get_surface gdk_offscreen_window_get_surface = FuncLoader.LoadFunction<OffscreenWindow.d_gdk_offscreen_window_get_surface>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_offscreen_window_get_surface"));

		// Token: 0x0400040C RID: 1036
		private static OffscreenWindow.d_gdk_offscreen_window_set_embedder gdk_offscreen_window_set_embedder = FuncLoader.LoadFunction<OffscreenWindow.d_gdk_offscreen_window_set_embedder>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_offscreen_window_set_embedder"));

		// Token: 0x0400040D RID: 1037
		private static AbiStruct _abi_info = null;

		// Token: 0x02000319 RID: 793
		// (Invoke) Token: 0x060012E9 RID: 4841
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_offscreen_window_get_embedder(IntPtr window);

		// Token: 0x0200031A RID: 794
		// (Invoke) Token: 0x060012ED RID: 4845
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_offscreen_window_get_surface(IntPtr window);

		// Token: 0x0200031B RID: 795
		// (Invoke) Token: 0x060012F1 RID: 4849
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate void d_gdk_offscreen_window_set_embedder(IntPtr window, IntPtr embedder);
	}
}
