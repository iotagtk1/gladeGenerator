﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200006F RID: 111
	internal class DragProtocolGType
	{
		// Token: 0x17000147 RID: 327
		// (get) Token: 0x060004F1 RID: 1265 RVA: 0x0000F153 File Offset: 0x0000D353
		public static GType GType
		{
			get
			{
				return new GType(DragProtocolGType.gdk_drag_protocol_get_type());
			}
		}

		// Token: 0x04000221 RID: 545
		private static DragProtocolGType.d_gdk_drag_protocol_get_type gdk_drag_protocol_get_type = FuncLoader.LoadFunction<DragProtocolGType.d_gdk_drag_protocol_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_drag_protocol_get_type"));

		// Token: 0x02000257 RID: 599
		// (Invoke) Token: 0x06000FE3 RID: 4067
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_drag_protocol_get_type();
	}
}
