﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200011D RID: 285
	internal class WindowHintsGType
	{
		// Token: 0x170002F1 RID: 753
		// (get) Token: 0x06000B49 RID: 2889 RVA: 0x0002153B File Offset: 0x0001F73B
		public static GType GType
		{
			get
			{
				return new GType(WindowHintsGType.gdk_window_hints_get_type());
			}
		}

		// Token: 0x0400068A RID: 1674
		private static WindowHintsGType.d_gdk_window_hints_get_type gdk_window_hints_get_type = FuncLoader.LoadFunction<WindowHintsGType.d_gdk_window_hints_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_window_hints_get_type"));

		// Token: 0x020004CF RID: 1231
		// (Invoke) Token: 0x060019BE RID: 6590
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_window_hints_get_type();
	}
}
