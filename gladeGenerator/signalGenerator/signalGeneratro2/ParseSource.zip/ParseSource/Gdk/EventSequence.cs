﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x0200007E RID: 126
	public class EventSequence : Opaque
	{
		// Token: 0x17000159 RID: 345
		// (get) Token: 0x06000558 RID: 1368 RVA: 0x00010268 File Offset: 0x0000E468
		public static GType GType
		{
			get
			{
				IntPtr val = EventSequence.gdk_event_sequence_get_type();
				return new GType(val);
			}
		}

		// Token: 0x06000559 RID: 1369 RVA: 0x00010286 File Offset: 0x0000E486
		public EventSequence(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x1700015A RID: 346
		// (get) Token: 0x0600055A RID: 1370 RVA: 0x0001028F File Offset: 0x0000E48F
		public static AbiStruct abi_info
		{
			get
			{
				if (EventSequence._abi_info == null)
				{
					EventSequence._abi_info = new AbiStruct(new List<AbiField>());
				}
				return EventSequence._abi_info;
			}
		}

		// Token: 0x04000289 RID: 649
		private static EventSequence.d_gdk_event_sequence_get_type gdk_event_sequence_get_type = FuncLoader.LoadFunction<EventSequence.d_gdk_event_sequence_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_event_sequence_get_type"));

		// Token: 0x0400028A RID: 650
		private static AbiStruct _abi_info = null;

		// Token: 0x02000289 RID: 649
		// (Invoke) Token: 0x060010AB RID: 4267
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_event_sequence_get_type();
	}
}
