﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000D7 RID: 215
	[GType(typeof(PixbufRotationGType))]
	public enum PixbufRotation
	{
		// Token: 0x040004B2 RID: 1202
		None,
		// Token: 0x040004B3 RID: 1203
		Counterclockwise = 90,
		// Token: 0x040004B4 RID: 1204
		Upsidedown = 180,
		// Token: 0x040004B5 RID: 1205
		Clockwise = 270
	}
}
