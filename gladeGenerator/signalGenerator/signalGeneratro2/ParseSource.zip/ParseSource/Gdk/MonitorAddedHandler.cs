﻿using System;

namespace Gdk
{
	// Token: 0x020000B3 RID: 179
	// (Invoke) Token: 0x06000738 RID: 1848
	public delegate void MonitorAddedHandler(object o, MonitorAddedArgs args);
}
