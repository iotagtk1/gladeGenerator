﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x02000061 RID: 97
	public class DeviceTool : Object
	{
		// Token: 0x06000437 RID: 1079 RVA: 0x0000D0C0 File Offset: 0x0000B2C0
		public DeviceTool(IntPtr raw) : base(raw)
		{
		}

		// Token: 0x06000438 RID: 1080 RVA: 0x0000D0C9 File Offset: 0x0000B2C9
		protected DeviceTool() : base(IntPtr.Zero)
		{
			this.CreateNativeObject(new string[0], new Value[0]);
		}

		// Token: 0x1700011C RID: 284
		// (get) Token: 0x06000439 RID: 1081 RVA: 0x0000D0E8 File Offset: 0x0000B2E8
		[Property("serial")]
		public ulong Serial
		{
			get
			{
				return DeviceTool.gdk_device_tool_get_serial(base.Handle);
			}
		}

		// Token: 0x1700011D RID: 285
		// (get) Token: 0x0600043A RID: 1082 RVA: 0x0000D0FA File Offset: 0x0000B2FA
		[Property("tool-type")]
		public DeviceToolType ToolType
		{
			get
			{
				return (DeviceToolType)DeviceTool.gdk_device_tool_get_tool_type(base.Handle);
			}
		}

		// Token: 0x1700011E RID: 286
		// (get) Token: 0x0600043B RID: 1083 RVA: 0x0000D10C File Offset: 0x0000B30C
		[Property("axes")]
		public AxisFlags Axes
		{
			get
			{
				Value property = base.GetProperty("axes");
				AxisFlags result = (AxisFlags)((Enum)property);
				property.Dispose();
				return result;
			}
		}

		// Token: 0x1700011F RID: 287
		// (get) Token: 0x0600043C RID: 1084 RVA: 0x0000D137 File Offset: 0x0000B337
		[Property("hardware-id")]
		public ulong HardwareId
		{
			get
			{
				return DeviceTool.gdk_device_tool_get_hardware_id(base.Handle);
			}
		}

		// Token: 0x17000120 RID: 288
		// (get) Token: 0x0600043D RID: 1085 RVA: 0x0000D149 File Offset: 0x0000B349
		public new static AbiStruct class_abi
		{
			get
			{
				if (DeviceTool._class_abi == null)
				{
					DeviceTool._class_abi = new AbiStruct(Object.class_abi.Fields);
				}
				return DeviceTool._class_abi;
			}
		}

		// Token: 0x17000121 RID: 289
		// (get) Token: 0x0600043E RID: 1086 RVA: 0x0000D16C File Offset: 0x0000B36C
		public new static GType GType
		{
			get
			{
				IntPtr val = DeviceTool.gdk_device_tool_get_type();
				return new GType(val);
			}
		}

		// Token: 0x17000122 RID: 290
		// (get) Token: 0x0600043F RID: 1087 RVA: 0x0000D18A File Offset: 0x0000B38A
		public new static AbiStruct abi_info
		{
			get
			{
				if (DeviceTool._abi_info == null)
				{
					DeviceTool._abi_info = new AbiStruct(Object.abi_info.Fields);
				}
				return DeviceTool._abi_info;
			}
		}

		// Token: 0x040001C9 RID: 457
		private static DeviceTool.d_gdk_device_tool_get_serial gdk_device_tool_get_serial = FuncLoader.LoadFunction<DeviceTool.d_gdk_device_tool_get_serial>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_tool_get_serial"));

		// Token: 0x040001CA RID: 458
		private static DeviceTool.d_gdk_device_tool_get_tool_type gdk_device_tool_get_tool_type = FuncLoader.LoadFunction<DeviceTool.d_gdk_device_tool_get_tool_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_tool_get_tool_type"));

		// Token: 0x040001CB RID: 459
		private static DeviceTool.d_gdk_device_tool_get_hardware_id gdk_device_tool_get_hardware_id = FuncLoader.LoadFunction<DeviceTool.d_gdk_device_tool_get_hardware_id>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_tool_get_hardware_id"));

		// Token: 0x040001CC RID: 460
		private static AbiStruct _class_abi = null;

		// Token: 0x040001CD RID: 461
		private static DeviceTool.d_gdk_device_tool_get_type gdk_device_tool_get_type = FuncLoader.LoadFunction<DeviceTool.d_gdk_device_tool_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_device_tool_get_type"));

		// Token: 0x040001CE RID: 462
		private static AbiStruct _abi_info = null;

		// Token: 0x02000224 RID: 548
		// (Invoke) Token: 0x06000F17 RID: 3863
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate ulong d_gdk_device_tool_get_serial(IntPtr raw);

		// Token: 0x02000225 RID: 549
		// (Invoke) Token: 0x06000F1B RID: 3867
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate int d_gdk_device_tool_get_tool_type(IntPtr raw);

		// Token: 0x02000226 RID: 550
		// (Invoke) Token: 0x06000F1F RID: 3871
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate ulong d_gdk_device_tool_get_hardware_id(IntPtr raw);

		// Token: 0x02000227 RID: 551
		// (Invoke) Token: 0x06000F23 RID: 3875
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_device_tool_get_type();
	}
}
