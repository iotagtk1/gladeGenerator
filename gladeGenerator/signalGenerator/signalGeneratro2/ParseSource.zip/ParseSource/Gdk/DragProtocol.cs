﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x0200006E RID: 110
	[GType(typeof(DragProtocolGType))]
	public enum DragProtocol
	{
		// Token: 0x04000219 RID: 537
		None,
		// Token: 0x0400021A RID: 538
		Motif,
		// Token: 0x0400021B RID: 539
		Xdnd,
		// Token: 0x0400021C RID: 540
		Rootwin,
		// Token: 0x0400021D RID: 541
		Win32Dropfiles,
		// Token: 0x0400021E RID: 542
		Ole2,
		// Token: 0x0400021F RID: 543
		Local,
		// Token: 0x04000220 RID: 544
		Wayland
	}
}
