﻿using System;
using GLib;

namespace Gdk
{
	// Token: 0x020000FC RID: 252
	public class SizePreparedArgs : SignalArgs
	{
		// Token: 0x17000286 RID: 646
		// (get) Token: 0x06000A0B RID: 2571 RVA: 0x0001DAD1 File Offset: 0x0001BCD1
		public int Width
		{
			get
			{
				return (int)base.Args[0];
			}
		}

		// Token: 0x17000287 RID: 647
		// (get) Token: 0x06000A0C RID: 2572 RVA: 0x0001DAE0 File Offset: 0x0001BCE0
		public int Height
		{
			get
			{
				return (int)base.Args[1];
			}
		}
	}
}
