﻿using System;
using System.Runtime.InteropServices;
using GLib;

namespace Gdk
{
	// Token: 0x020000A5 RID: 165
	internal class InputSourceGType
	{
		// Token: 0x170001AF RID: 431
		// (get) Token: 0x06000677 RID: 1655 RVA: 0x00013035 File Offset: 0x00011235
		public static GType GType
		{
			get
			{
				return new GType(InputSourceGType.gdk_input_source_get_type());
			}
		}

		// Token: 0x0400038D RID: 909
		private static InputSourceGType.d_gdk_input_source_get_type gdk_input_source_get_type = FuncLoader.LoadFunction<InputSourceGType.d_gdk_input_source_get_type>(FuncLoader.GetProcAddress(GLibrary.Load(Library.Gdk), "gdk_input_source_get_type"));

		// Token: 0x020002DC RID: 732
		// (Invoke) Token: 0x060011F5 RID: 4597
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		private delegate IntPtr d_gdk_input_source_get_type();
	}
}
